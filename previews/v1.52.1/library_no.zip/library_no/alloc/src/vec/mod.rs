//! En sammenhengende dyrkbar matrityp med innhold som er tildelt dynger, skrevet `Vec<T>`
//!
//! Vectors har `O(1)` indeksering, amortisert `O(1)` push (til slutten) og `O(1)` pop (fra slutten).
//!
//!
//! Vectors sørger for at de aldri tildeler mer enn `isize::MAX` byte.
//!
//! # Examples
//!
//! Du kan eksplisitt opprette en [`Vec`] med [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... eller ved å bruke [`vec!`]-makroen:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // ti nuller
//! ```
//!
//! Du kan [`push`]-verdier på slutten av en vector (som vil vokse vector etter behov):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping-verdier fungerer på omtrent samme måte:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors støtter også indeksering (gjennom [`Index`] og [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// En sammenhengende dyrkbar matritype, skrevet som `Vec<T>` og uttalt 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`]-makroen er gitt for å gjøre initialiseringen mer praktisk:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Det kan også initialisere hvert element i en `Vec<T>` med en gitt verdi.
/// Dette kan være mer effektivt enn å utføre tildeling og initialisering i separate trinn, spesielt når du initialiserer en vector med nuller:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Følgende er ekvivalent, men potensielt tregere:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// For mer informasjon, se [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Bruk en `Vec<T>` som en effektiv stack:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Utskrift 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec`-typen gir tilgang til verdier etter indeks, fordi den implementerer [`Index`] trait.Et eksempel vil være mer eksplisitt:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // det vil vise '2'
/// ```
///
/// Vær imidlertid forsiktig: hvis du prøver å få tilgang til en indeks som ikke er i `Vec`, vil programvaren din panic!Du kan ikke gjøre dette:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Bruk [`get`] og [`get_mut`] hvis du vil sjekke om indeksen er i `Vec`.
///
/// # Slicing
///
/// En `Vec` kan endres.På den annen side er skiver skrivebeskyttede objekter.
/// For å få en [slice][prim@slice], bruk [`&`].Eksempel:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... og det er alt!
/// // du kan også gjøre det slik:
/// let u: &[usize] = &v;
/// // eller slik:
/// let u: &[_] = &v;
/// ```
///
/// I Rust er det mer vanlig å sende skiver som argumenter i stedet for vectors når du bare vil gi lesetilgang.Det samme gjelder [`String`] og [`&str`].
///
/// # Kapasitet og omdisponering
///
/// Kapasiteten til en vector er mengden plass som er tildelt for alle future-elementer som skal legges til vector.Dette må ikke forveksles med *lengden* på en vector, som spesifiserer antall faktiske elementer i vector.
/// Hvis lengden på en vector overstiger kapasiteten, vil kapasiteten automatisk økes, men elementene må omdisponeres.
///
/// For eksempel vil en vector med kapasitet 10 og lengde 0 være en tom vector med plass til 10 flere elementer.Hvis du skyver 10 eller færre elementer på vector, vil det ikke endre kapasiteten eller føre til omfordeling.
/// Imidlertid, hvis lengden på vector økes til 11, må den omfordele, noe som kan være tregt.Av denne grunn anbefales det å bruke [`Vec::with_capacity`] når det er mulig for å spesifisere hvor stor vector forventes å bli.
///
/// # Guarantees
///
/// På grunn av sin utrolig grunnleggende natur gir `Vec` mange garantier for designen.Dette sikrer at det er så lite overhead som mulig generelt, og kan manipuleres riktig på primitive måter av usikker kode.Merk at disse garantiene refererer til en ukvalifisert `Vec<T>`.
/// Hvis flere typeparametere legges til (f.eks. For å støtte tilpassede tildelere), kan det føre til at oppførselen overstyres.
///
/// Mest fundamentalt er og vil `Vec` være en (peker, kapasitet, lengde) triplett.Intet mer, intet mindre.Rekkefølgen på disse feltene er helt uspesifisert, og du bør bruke de riktige metodene for å endre disse.
/// Pekeren vil aldri være null, så denne typen er nullpekeroptimalisert.
///
/// Pekeren kan imidlertid ikke peke på tildelt minne.
/// Spesielt hvis du konstruerer en `Vec` med kapasitet 0 via [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], eller ved å ringe [`shrink_to_fit`] på en tom Vec, vil den ikke tildele minne.På samme måte, hvis du lagrer typer av null størrelse i en `Vec`, vil den ikke tildele plass til dem.
/// *Vær oppmerksom på at `Vec` i dette tilfellet ikke kan rapportere en [`capacity`] på 0*.
/// `Vec` vil tildele hvis og bare hvis [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Generelt er `Vec`s tildelingsdetaljer veldig subtile-hvis du har tenkt å tildele minne ved hjelp av en `Vec` og bruke den til noe annet (enten for å overføre til usikker kode, eller for å bygge din egen minnestøttede samling), må du være sikker å fordele dette minnet ved å bruke `from_raw_parts` for å gjenopprette `Vec` og deretter slippe det.
///
/// Hvis en `Vec`*har* tildelt minne, er minnet det peker på på bunken (som definert av allokatoren Rust er konfigurert til å bruke som standard), og pekeren peker på [`len`] initialiserte, sammenhengende elementer i rekkefølge (hva du vil se om du tvang det til et stykke), etterfulgt av [`kapasitet`]`,`[`len`] logisk uinitialiserte, sammenhengende elementer.
///
///
/// En vector som inneholder elementene `'a'` og `'b'` med kapasitet 4 kan visualiseres som nedenfor.Den øverste delen er `Vec`-strukturen, den inneholder en peker til tildelingshodet i dyngen, lengden og kapasiteten.
/// Den nederste delen er tildelingen på bunken, en sammenhengende minneblokk.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** representerer minne som ikke er initialisert, se [`MaybeUninit`].
/// - Note: ABI er ikke stabilt, og `Vec` gir ingen garantier for minneoppsettet (inkludert rekkefølgen på feltene).
///
/// `Vec` vil aldri utføre en "small optimization" der elementene faktisk er lagret på bunken av to grunner:
///
/// * Det ville gjøre det vanskeligere for usikker kode å riktig manipulere en `Vec`.Innholdet i en `Vec` ville ikke ha en stabil adresse hvis den bare ble flyttet, og det ville være vanskeligere å avgjøre om en `Vec` faktisk hadde tildelt minne.
///
/// * Det ville straffe den generelle saken og medføre en ekstra branch for hver tilgang.
///
/// `Vec` vil aldri automatisk krympe seg selv, selv om den er helt tom.Dette sikrer at det ikke forekommer unødvendige tildelinger eller avtaler.Tømming av en `Vec` og deretter fylling av den til samme [`len`] bør ikke føre til anrop til tildeleren.Hvis du vil frigjøre ubrukt minne, bruk [`shrink_to_fit`] eller [`shrink_to`].
///
/// [`push`] og [`insert`] vil aldri (re) allokere hvis den rapporterte kapasiteten er tilstrekkelig.[`push`] og [`insert`]*vil*(re) tildele hvis [`len`]`==`[`kapasitet`].Det vil si at den rapporterte kapasiteten er helt nøyaktig og kan stole på.Den kan til og med brukes til manuelt å frigjøre minnet som er tildelt av en `Vec` hvis ønskelig.
/// Metoder for masseinnsetting *kan* allokere på nytt, selv når det ikke er nødvendig.
///
/// `Vec` garanterer ingen spesiell vekststrategi ved omfordeling når den er full, og heller ikke når [`reserve`] kalles.Den nåværende strategien er grunnleggende, og det kan vise seg ønskelig å bruke en ikke-konstant vekstfaktor.Uansett hvilken strategi som brukes, vil selvfølgelig garantere *O*(1) amortisert [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` og [`Vec::with_capacity(n)`][`Vec::with_capacity`] vil alle produsere en `Vec` med nøyaktig ønsket kapasitet.
/// Hvis [`len`]`==`[`kapasitet`], (som er tilfelle for [`vec!`]-makroen), kan en `Vec<T>` konverteres til og fra en [`Box<[T]>`][owned slice] uten å omfordele eller flytte elementene.
///
/// `Vec` vil ikke spesifikt overskrive data som er fjernet fra den, men vil heller ikke spesifikt bevare den.Det uinitialiserte minnet er skrapeplass som det kan bruke slik det vil.Det vil vanligvis bare gjøre det som er mest effektivt eller ellers enkelt å implementere.Ikke stol på at data som er fjernet, skal slettes av sikkerhetshensyn.
/// Selv om du dropper en `Vec`, kan bufferen rett og slett bli gjenbrukt av en annen `Vec`.
/// Selv om du nullstiller et "Vec"-minne først, kan det faktisk ikke skje fordi optimalisereren ikke anser dette som en bivirkning som må bevares.
/// Det er ett tilfelle som vi ikke vil bryte, men det er alltid gyldig å bruke `unsafe`-kode for å skrive til overflødig kapasitet og deretter øke lengden for å matche.
///
/// For øyeblikket garanterer ikke `Vec` rekkefølgen elementene blir droppet i.
/// Bestillingen har endret seg tidligere og kan endres igjen.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Iboende metoder
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Konstruerer en ny, tom `Vec<T>`.
    ///
    /// vector tildeles ikke før elementene skyves på den.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Konstruerer en ny, tom `Vec<T>` med spesifisert kapasitet.
    ///
    /// vector vil kunne holde nøyaktig `capacity`-elementer uten å omfordele.
    /// Hvis `capacity` er 0, tildeles ikke vector.
    ///
    /// Det er viktig å merke seg at selv om den returnerte vector har *kapasitet* spesifisert, vil vector ha null *lengde*.
    ///
    /// For en forklaring på forskjellen mellom lengde og kapasitet, se *[Kapasitet og omdisponering]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector inneholder ingen gjenstander, selv om den har kapasitet til mer
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Alt dette gjøres uten å omfordele ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... men dette kan gjøre at vector omdisponeres
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Oppretter en `Vec<T>` direkte fra råkomponentene til en annen vector.
    ///
    /// # Safety
    ///
    /// Dette er svært utrygt på grunn av antall invarianter som ikke er sjekket:
    ///
    /// * `ptr` må ha blitt tildelt tidligere via [`String`]/`Vec<T>`` (i det minste er det høyst sannsynlig at det er feil hvis det ikke var det).
    /// * `T` må ha samme størrelse og justering som det `ptr` ble tildelt.
    ///   (`T` med mindre streng tilpasning er ikke tilstrekkelig, innstillingen må virkelig være lik for å tilfredsstille [`dealloc`]-kravet om at minne må tildeles og fordeles med samme layout.)
    ///
    /// * `length` må være mindre enn eller lik `capacity`.
    /// * `capacity` må være kapasiteten som pekeren ble tildelt med.
    ///
    /// Brudd på disse kan føre til problemer som å ødelegge tildelers interne datastrukturer.For eksempel er det **ikke** trygt å bygge en `Vec<u8>` fra en peker til en C `char`-array med lengden `size_t`.
    /// Det er heller ikke trygt å bygge en fra en `Vec<u16>` og dens lengde, fordi fordeleren bryr seg om justeringen, og disse to typene har forskjellige justeringer.
    /// Bufferen ble tildelt justering 2 (for `u16`), men etter at den ble omgjort til en `Vec<u8>`, vil den bli fordelt med justering 1.
    ///
    /// Eierskapet til `ptr` overføres effektivt til `Vec<T>`, som deretter kan omfordele, omdisponere eller endre innholdet i minnet som pekeren peker på.
    /// Forsikre deg om at ingenting annet bruker pekeren etter at du har kalt denne funksjonen.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Oppdater dette når vec_into_raw_parts er stabilisert.
    ///     // Unngå å kjøre `v`s destruktør, så vi har full kontroll over tildelingen.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Trekk ut de forskjellige viktige delene av informasjonen om `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Overskriv minne med 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Sett alt sammen igjen til en Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Konstruerer en ny, tom `Vec<T, A>`.
    ///
    /// vector tildeles ikke før elementene skyves på den.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Konstruerer en ny, tom `Vec<T, A>` med spesifisert kapasitet med den medfølgende tildeleren.
    ///
    /// vector vil kunne holde nøyaktig `capacity`-elementer uten å omfordele.
    /// Hvis `capacity` er 0, tildeles ikke vector.
    ///
    /// Det er viktig å merke seg at selv om den returnerte vector har *kapasitet* spesifisert, vil vector ha null *lengde*.
    ///
    /// For en forklaring på forskjellen mellom lengde og kapasitet, se *[Kapasitet og omdisponering]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector inneholder ingen gjenstander, selv om den har kapasitet til mer
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Alt dette gjøres uten å omfordele ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... men dette kan gjøre at vector omdisponeres
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Oppretter en `Vec<T, A>` direkte fra råkomponentene til en annen vector.
    ///
    /// # Safety
    ///
    /// Dette er svært utrygt på grunn av antall invarianter som ikke er sjekket:
    ///
    /// * `ptr` må ha blitt tildelt tidligere via [`String`]/`Vec<T>`` (i det minste er det høyst sannsynlig at det er feil hvis det ikke var det).
    /// * `T` må ha samme størrelse og justering som det `ptr` ble tildelt.
    ///   (`T` med mindre streng tilpasning er ikke tilstrekkelig, innstillingen må virkelig være lik for å tilfredsstille [`dealloc`]-kravet om at minne må tildeles og fordeles med samme layout.)
    ///
    /// * `length` må være mindre enn eller lik `capacity`.
    /// * `capacity` må være kapasiteten som pekeren ble tildelt med.
    ///
    /// Brudd på disse kan føre til problemer som å ødelegge tildelers interne datastrukturer.For eksempel er det **ikke** trygt å bygge en `Vec<u8>` fra en peker til en C `char`-array med lengden `size_t`.
    /// Det er heller ikke trygt å bygge en fra en `Vec<u16>` og dens lengde, fordi fordeleren bryr seg om justeringen, og disse to typene har forskjellige justeringer.
    /// Bufferen ble tildelt justering 2 (for `u16`), men etter at den ble omgjort til en `Vec<u8>`, vil den bli fordelt med justering 1.
    ///
    /// Eierskapet til `ptr` overføres effektivt til `Vec<T>`, som deretter kan omfordele, omdisponere eller endre innholdet i minnet som pekeren peker på.
    /// Forsikre deg om at ingenting annet bruker pekeren etter at du har kalt denne funksjonen.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Oppdater dette når vec_into_raw_parts er stabilisert.
    ///     // Unngå å kjøre `v`s destruktør, så vi har full kontroll over tildelingen.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Trekk ut de forskjellige viktige delene av informasjonen om `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Overskriv minne med 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Sett alt sammen igjen til en Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Nedbryter en `Vec<T>` i sine rå komponenter.
    ///
    /// Returnerer råpekeren til de underliggende dataene, lengden på vector (i elementer) og den tildelte kapasiteten til dataene (i elementer).
    /// Dette er de samme argumentene i samme rekkefølge som argumentene til [`from_raw_parts`].
    ///
    /// Etter å ha ringt denne funksjonen, er den som ringer ansvarlig for minnet som tidligere ble administrert av `Vec`.
    /// Den eneste måten å gjøre dette på er å konvertere råpekeren, lengden og kapasiteten tilbake til en `Vec` med [`from_raw_parts`]-funksjonen, slik at destruktøren kan utføre oppryddingen.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Vi kan nå gjøre endringer på komponentene, for eksempel å overføre råpekeren til en kompatibel type.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Nedbryter en `Vec<T>` i sine rå komponenter.
    ///
    /// Returnerer råpekeren til de underliggende dataene, lengden på vector (i elementer), den tildelte kapasiteten til dataene (i elementene) og fordeleren.
    /// Dette er de samme argumentene i samme rekkefølge som argumentene til [`from_raw_parts_in`].
    ///
    /// Etter å ha ringt denne funksjonen, er den som ringer ansvarlig for minnet som tidligere ble administrert av `Vec`.
    /// Den eneste måten å gjøre dette på er å konvertere råpekeren, lengden og kapasiteten tilbake til en `Vec` med [`from_raw_parts_in`]-funksjonen, slik at destruktøren kan utføre oppryddingen.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Vi kan nå gjøre endringer på komponentene, for eksempel å overføre råpekeren til en kompatibel type.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Returnerer antall elementer vector kan holde uten å omfordele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Reserverer kapasitet for at minst `additional` flere elementer skal settes inn i den gitte `Vec<T>`.
    /// Samlingen kan reservere mer plass for å unngå hyppige omdisponeringer.
    /// Etter å ha ringt `reserve`, vil kapasiteten være større enn eller lik `self.len() + additional`.
    /// Gjør ingenting hvis kapasiteten allerede er tilstrekkelig.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapasiteten overstiger `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Reserverer minimumskapasiteten for at nøyaktig `additional` flere elementer skal settes inn i den gitte `Vec<T>`.
    ///
    /// Etter å ha ringt `reserve_exact`, vil kapasiteten være større enn eller lik `self.len() + additional`.
    /// Gjør ingenting hvis kapasiteten allerede er tilstrekkelig.
    ///
    /// Merk at tildeleren kan gi samlingen mer plass enn den ber om.
    /// Derfor kan man ikke stole på at kapasiteten er nøyaktig minimal.
    /// Foretrekker `reserve` hvis det forventes innføring av future.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapasiteten renner over `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Prøver å reservere kapasitet for at minst `additional` flere elementer skal settes inn i den gitte `Vec<T>`.
    /// Samlingen kan reservere mer plass for å unngå hyppige omdisponeringer.
    /// Etter å ha ringt `try_reserve`, vil kapasiteten være større enn eller lik `self.len() + additional`.
    /// Gjør ingenting hvis kapasiteten allerede er tilstrekkelig.
    ///
    /// # Errors
    ///
    /// Hvis kapasiteten går over, eller allokeringen rapporterer en feil, returneres en feil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Forhåndsreserver minnet, avslutt hvis vi ikke kan
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nå vet vi at dette ikke kan OOM midt i vårt komplekse arbeid
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // veldig komplisert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Prøver å reservere minimumskapasiteten for nøyaktig `additional`-elementer som skal settes inn i den gitte `Vec<T>`.
    /// Etter å ha ringt `try_reserve_exact`, vil kapasiteten være større enn eller lik `self.len() + additional` hvis den returnerer `Ok(())`.
    ///
    /// Gjør ingenting hvis kapasiteten allerede er tilstrekkelig.
    ///
    /// Merk at tildeleren kan gi samlingen mer plass enn den ber om.
    /// Derfor kan man ikke stole på at kapasiteten er nøyaktig minimal.
    /// Foretrekker `reserve` hvis det forventes innføring av future.
    ///
    /// # Errors
    ///
    /// Hvis kapasiteten går over, eller allokeringen rapporterer en feil, returneres en feil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Forhåndsreserver minnet, avslutt hvis vi ikke kan
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Nå vet vi at dette ikke kan OOM midt i vårt komplekse arbeid
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // veldig komplisert
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Krymper kapasiteten til vector så mye som mulig.
    ///
    /// Den vil falle ned så nær lengden som mulig, men allokereren kan likevel informere vector om at det er plass til noen flere elementer.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kapasiteten er aldri mindre enn lengden, og det er ingenting å gjøre når de er like, så vi kan unngå panic-saken i `RawVec::shrink_to_fit` ved bare å kalle den med større kapasitet.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Krymper kapasiteten til vector med en nedre grense.
    ///
    /// Kapasiteten vil forbli minst like stor som både lengden og den tilførte verdien.
    ///
    ///
    /// Hvis den nåværende kapasiteten er mindre enn den nedre grensen, er dette en no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Konverterer vector til [`Box<[T]>`][owned slice].
    ///
    /// Merk at dette vil redusere overflødig kapasitet.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Eventuell overkapasitet fjernes:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Forkorter vector, holder de første `len`-elementene og slipper resten.
    ///
    /// Hvis `len` er større enn vector s nåværende lengde, har dette ingen effekt.
    ///
    /// [`drain`]-metoden kan etterligne `truncate`, men fører til at overflødige elementer returneres i stedet for å bli droppet.
    ///
    ///
    /// Merk at denne metoden ikke har noen innvirkning på den tildelte kapasiteten til vector.
    ///
    /// # Examples
    ///
    /// Avkorting av et femelement vector til to elementer:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Ingen avkorting oppstår når `len` er større enn vector s nåværende lengde:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Avkortes når `len == 0` tilsvarer å ringe [`clear`]-metoden.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Dette er trygt fordi:
        //
        // * delen som sendes til `drop_in_place` er gyldig;`len > self.len`-saken unngår å lage et ugyldig stykke, og
        // * `len` på vector er krympet før du ringer til `drop_in_place`, slik at ingen verdi vil bli droppet to ganger i tilfelle `drop_in_place` skulle panic en gang (hvis det panics to ganger, avbrytes programmet).
        //
        //
        //
        unsafe {
            // Note: Det er bevisst at dette er `>` og ikke `>=`.
            //       Å endre den til `>=` har i noen tilfeller negative ytelsesimplikasjoner.
            //       Se #78884 for mer.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Pakk ut et stykke som inneholder hele vector.
    ///
    /// Tilsvarer `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Henter ut en foranderlig del av hele vector.
    ///
    /// Tilsvarer `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Returnerer en rå peker til vector s buffer.
    ///
    /// Den som ringer må sørge for at vector overlever pekeren som denne funksjonen returnerer, ellers vil den ende opp med å peke mot søppel.
    /// Endring av vector kan føre til at bufferen omdisponeres, noe som også vil gjøre eventuelle pekere til den ugyldige.
    ///
    /// Innringeren må også sørge for at minnet pekeren (non-transitively) peker på aldri blir skrevet til (unntatt inne i en `UnsafeCell`) ved hjelp av denne pekeren eller en hvilken som helst peker som er hentet fra den.
    /// Hvis du trenger å mutere innholdet i stykket, bruk [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Vi skyggelegger for skivemetoden med samme navn for å unngå å gå gjennom `deref`, noe som skaper en mellomreferanse.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Returnerer en usikker, muterbar peker til vector s buffer.
    ///
    /// Den som ringer må sørge for at vector overlever pekeren som denne funksjonen returnerer, ellers vil den ende opp med å peke mot søppel.
    ///
    /// Endring av vector kan føre til at bufferen omdisponeres, noe som også vil gjøre eventuelle pekere til den ugyldige.
    ///
    /// # Examples
    ///
    /// ```
    /// // Tildel vector som er stor nok til 4 elementer.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialiser elementene via rå peker skriver, og angi deretter lengden.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Vi skyggelegger for skivemetoden med samme navn for å unngå å gå gjennom `deref_mut`, noe som skaper en mellomreferanse.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Returnerer en referanse til den underliggende tildeleren.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Styrker lengden på vector til `new_len`.
    ///
    /// Dette er en operasjon på lavt nivå som ikke opprettholder noen av de normale invarianter av typen.
    /// Normalt endres lengden på en vector ved å bruke en av de sikre operasjonene i stedet, for eksempel [`truncate`], [`resize`], [`extend`] eller [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` må være mindre enn eller lik [`capacity()`].
    /// - Elementene på `old_len..new_len` må initialiseres.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Denne metoden kan være nyttig i situasjoner der vector fungerer som en buffer for annen kode, spesielt over FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Dette er bare et minimalt skjelett for dok. Eksemplet;
    /// # // ikke bruk dette som utgangspunkt for et ekte bibliotek.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // I henhold til dokumentene til FFI-metoden, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SIKKERHET: Når `deflateGetDictionary` returnerer `Z_OK`, gjelder det at:
    ///     // 1. `dict_length` elementene ble initialisert.
    ///     // 2.
    ///     // `dict_length` <=kapasiteten (32_768) som gjør `set_len` trygt å ringe.
    ///     unsafe {
    ///         // Ring FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... og oppdater lengden til det som ble initialisert.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Mens følgende eksempel er lyd, er det en minnelekkasje siden de indre vectors ikke ble frigjort før `set_len`-samtalen:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` er tom så ingen elementer trenger å initialiseres.
    /// // 2. `0 <= capacity` holder alltid hva `capacity` er.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalt, her, vil man bruke [`clear`] i stedet for å slippe innholdet riktig og dermed ikke lekke minne.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Fjerner et element fra vector og returnerer det.
    ///
    /// Det fjernede elementet erstattes av det siste elementet i vector.
    ///
    /// Dette bevarer ikke bestilling, men er O(1).
    ///
    /// # Panics
    ///
    /// Panics hvis `index` er utenfor grensene.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Vi erstatter selv [indeks] med det siste elementet.
            // Merk at hvis grensekontrollen over lykkes, må det være et siste element (som kan være selv [indeks] selv).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Setter inn et element i posisjon `index` i vector, og skyver alle elementene etter det til høyre.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // plass til det nye elementet
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // ufeilbarlig Stedet for å sette den nye verdien
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Flytt alt for å få plass.
                // (Kopiering av indekselementet to steder på rad.)
                ptr::copy(p, p.offset(1), len - index);
                // Skriv den inn, og skriv over den første kopien av `index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Fjerner og returnerer elementet i posisjon `index` i vector, og skyver alle elementene etter det til venstre.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `index` er utenfor grensene.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // stedet vi tar fra.
                let ptr = self.as_mut_ptr().add(index);
                // kopier den ut, og ha en kopi av verdien på bunken og i vector samtidig.
                //
                ret = ptr::read(ptr);

                // Skift alt ned for å fylle ut det stedet.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Beholder bare elementene spesifisert av predikatet.
    ///
    /// Fjern med andre ord alle elementene `e` slik at `f(&e)` returnerer `false`.
    /// Denne metoden fungerer på plass, besøker hvert element nøyaktig en gang i den opprinnelige rekkefølgen, og bevarer rekkefølgen på de beholdte elementene.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Fordi elementene besøkes nøyaktig en gang i den opprinnelige rekkefølgen, kan ekstern tilstand brukes til å bestemme hvilke elementer som skal beholdes.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Unngå dobbelt fall hvis fallbeskyttelsen ikke utføres, siden vi kan lage noen hull under prosessen.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-behandlet len-> |^-ved siden av å sjekke
        //                  | <-slettet cnt-> |
        //      | <-original_len-> |Holdt: Elementer som predikat returnerer sant på.
        //
        // Hull: Flyttet eller droppet elementspor.
        // Ikke merket: Ikke merket av gyldige elementer.
        //
        // Denne slippvakten vil bli påkalt når predikat eller `drop` av element får panikk.
        // Den forskyver ukontrollerte elementer for å dekke hull og `set_len` til riktig lengde.
        // I tilfeller når predikat og `drop` aldri får panikk, blir det optimalisert.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SIKKERHET: Å slepe ukontrollerte gjenstander må være gyldig siden vi aldri berører dem.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SIKKERHET: Etter å ha fylt hull er alle elementene i sammenhengende minne.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SIKKERHET: Element som ikke er merket av må være gyldig.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Gå tidlig for å unngå dobbelt fall hvis `drop_in_place` får panikk.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SIKKERHET: Vi berører aldri dette elementet igjen etter å ha falt.
                unsafe { ptr::drop_in_place(cur) };
                // Vi har allerede avansert telleren.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SIKKERHET: `deleted_cnt`> 0, så hullsporet må ikke overlappe det aktuelle elementet.
                // Vi bruker copy for move, og berører aldri dette elementet igjen.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Alt elementet blir behandlet.Dette kan optimaliseres til `set_len` av LLVM.
        drop(g);
    }

    /// Fjerner alle unntatt de første påfølgende elementene i vector som løser til samme nøkkel.
    ///
    ///
    /// Hvis vector er sortert, fjerner dette alle duplikater.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Fjerner alle unntatt de første av påfølgende elementer i vector som tilfredsstiller en gitt likhetsforhold.
    ///
    /// `same_bucket`-funksjonen sendes referanser til to elementer fra vector og må avgjøre om elementene er like.
    /// Elementene sendes i motsatt rekkefølge fra rekkefølgen i stykket, så hvis `same_bucket(a, b)` returnerer `true`, blir `a` fjernet.
    ///
    ///
    /// Hvis vector er sortert, fjerner dette alle duplikater.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Legger til et element på baksiden av en samling.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapasiteten overstiger `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Dette vil panic eller avbrytes hvis vi tildeler> isize::MAX byte, eller hvis lengdestigningen vil flyte over for nullstørrelsestyper.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Fjerner det siste elementet fra en vector og returnerer det, eller [`None`] hvis det er tomt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Flytter alle elementene i `other` til `Self`, slik at `other` er tom.
    ///
    /// # Panics
    ///
    /// Panics hvis antall elementer i vector flyter over en `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Legger til elementer i `Self` fra annen buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Oppretter en drenerende iterator som fjerner det angitte området i vector og gir de fjernede elementene.
    ///
    /// Når iteratoren ** tappes, blir alle elementene i området fjernet fra vector, selv om iteratoren ikke ble fullstendig fortært.
    /// Hvis iteratoren **ikke** droppes (med for eksempel [`mem::forget`]), er det uspesifisert hvor mange elementer som fjernes.
    ///
    /// # Panics
    ///
    /// Panics hvis startpunktet er større enn sluttpunktet, eller hvis sluttpunktet er større enn lengden på vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Et komplett utvalg rydder vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Minne sikkerhet
        //
        // Når Drain først blir opprettet, forkorter det lengden på kilden vector for å sikre at ingen uinitialiserte eller flyttede elementer er tilgjengelige i det hele tatt hvis Drain s destruktør aldri kommer til å løpe.
        //
        //
        // Drain vil ptr::read ut verdiene som skal fjernes.
        // Når du er ferdig, blir den gjenværende halen av vec kopiert tilbake for å dekke hullet, og vector-lengden blir gjenopprettet til den nye lengden.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // still inn self.vec-lengden for å starte, for å være trygg i tilfelle Drain lekker
            self.set_len(start);
            // Bruk lånet i IterMut for å indikere låneatferd for hele Drain iteratoren (som &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Fjerner vector, og fjerner alle verdier.
    ///
    /// Merk at denne metoden ikke har noen innvirkning på den tildelte kapasiteten til vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Returnerer antall elementer i vector, også referert til som 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Returnerer `true` hvis vector ikke inneholder noen elementer.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Deler samlingen i to ved den gitte indeksen.
    ///
    /// Returnerer en nylig tildelt vector som inneholder elementene i området `[at, len)`.
    /// Etter samtalen blir den originale vector igjen med elementene `[0, at)` med den forrige kapasiteten uendret.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // den nye vector kan ta over den opprinnelige bufferen og unngå kopien
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Usikkert `set_len` og kopier elementene til `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Endrer størrelsen på `Vec` på plass slik at `len` er lik `new_len`.
    ///
    /// Hvis `new_len` er større enn `len`, utvides `Vec` med differansen, med hvert ekstra spor fylt med resultatet av å kalle lukkingen `f`.
    ///
    /// Returverdiene fra `f` vil havne i `Vec` i den rekkefølgen de er generert.
    ///
    /// Hvis `new_len` er mindre enn `len`, blir `Vec` ganske enkelt avkortet.
    ///
    /// Denne metoden bruker en lukking for å skape nye verdier ved hvert trykk.Hvis du heller vil [`Clone`] en gitt verdi, bruk [`Vec::resize`].
    /// Hvis du vil bruke [`Default`] trait til å generere verdier, kan du sende [`Default::default`] som det andre argumentet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Forbruker og lekker `Vec`, og returnerer en foranderlig referanse til innholdet, `&'a mut [T]`.
    /// Merk at typen `T` må overleve den valgte levetiden `'a`.
    /// Hvis typen bare har statiske referanser, eller ingen i det hele tatt, kan dette velges å være `'static`.
    ///
    /// Denne funksjonen ligner på [`leak`][Box::leak]-funksjonen på [`Box`], bortsett fra at det ikke er noen måte å gjenopprette det lekkede minnet.
    ///
    ///
    /// Denne funksjonen er hovedsakelig nyttig for data som lever resten av programmets liv.
    /// Hvis du slipper den returnerte referansen, kan det føre til minnelekkasje.
    ///
    /// # Examples
    ///
    /// Enkel bruk:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Returnerer gjenværende ledig kapasitet på vector som et stykke `MaybeUninit<T>`.
    ///
    /// Den returnerte delen kan brukes til å fylle vector med data (f.eks
    /// ved å lese fra en fil) før du merker dataene som initialisert ved hjelp av [`set_len`]-metoden.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Tildel vector stor nok til 10 elementer.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Fyll ut de tre første elementene.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Merk de tre første elementene i vector som initialisert.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Denne metoden er ikke implementert i form av `split_at_spare_mut`, for å forhindre ugyldiggjøring av pekere til bufferen.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Returnerer vector-innhold som et stykke `T`, sammen med den gjenværende ledige kapasiteten til vector som et stykke `MaybeUninit<T>`.
    ///
    /// Den returnerte ledige kapasitetsskiven kan brukes til å fylle vector med data (f.eks. Ved å lese fra en fil) før du merker dataene som initialisert ved hjelp av [`set_len`]-metoden.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Merk at dette er et API på lavt nivå, som bør brukes med forsiktighet i optimaliseringsøyemed.
    /// Hvis du trenger å legge til data til en `Vec`, kan du bruke [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] eller [`resize_with`], avhengig av dine nøyaktige behov.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Reserver ekstra plass som er stor nok til 10 elementer.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Fyll ut de neste 4 elementene.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Merk de 4 elementene i vector som initialisert.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len blir ignorert og så aldri forandret
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sikkerhet: endring av returnert .2 (&mut-størrelse) regnes som det samme som å ringe `.set_len(_)`.
    ///
    /// Denne metoden brukes til å ha unik tilgang til alle vec-deler samtidig i `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` er garantert gyldig for `len`-elementer
        // - `spare_ptr` peker ett element forbi bufferen, slik at det ikke overlapper med `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Endrer størrelsen på `Vec` på plass slik at `len` er lik `new_len`.
    ///
    /// Hvis `new_len` er større enn `len`, utvides `Vec` med differansen, med hvert ekstra spor fylt med `value`.
    ///
    /// Hvis `new_len` er mindre enn `len`, blir `Vec` ganske enkelt avkortet.
    ///
    /// Denne metoden krever at `T` implementerer [`Clone`], for å kunne klone den passerte verdien.
    /// Hvis du trenger mer fleksibilitet (eller vil stole på [`Default`] i stedet for [`Clone`]), bruk [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Kloner og legger til alle elementene i et stykke til `Vec`.
    ///
    /// Itererer over stykket `other`, kloner hvert element og legger det deretter til denne `Vec`.
    /// `other` vector krysses i rekkefølge.
    ///
    /// Merk at denne funksjonen er den samme som [`extend`], bortsett fra at den er spesialisert på å jobbe med skiver i stedet.
    ///
    /// Hvis og når Rust får spesialisering, vil denne funksjonen sannsynligvis avvikles (men fremdeles tilgjengelig).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopierer elementer fra `src`-serien til slutten av vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garanterer at det gitte området er gyldig for indeksering av selvet
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Denne koden generaliserer `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Utvid vector med `n`-verdier ved hjelp av den givne generatoren.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Bruk SetLenOnDrop til å omgå feil der kompilatoren kanskje ikke realiserer butikken gjennom `ptr` til self.set_len() ikke alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Skriv alle elementene unntatt den siste
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Øk lengden i hvert trinn i tilfelle next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Vi kan skrive det siste elementet direkte uten å klone unødvendig
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len satt av omfangsvakt
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Fjerner påfølgende gjentatte elementer i vector i henhold til [`PartialEq`] trait implementeringen.
    ///
    ///
    /// Hvis vector er sortert, fjerner dette alle duplikater.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Interne metoder og funksjoner
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` må være gyldig indeks
    /// - `self.capacity() - self.len()` må være `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len økes først etter at elementene er initialisert
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - innringeren garanterer at src er en gyldig indeks
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element ble nettopp initialisert med `MaybeUninit::write`, så det er ok å øke lenken
            // - len økes etter hvert element for å forhindre lekkasjer (se utgave #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - innringeren garanterer at `src` er en gyldig indeks
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Begge pekerne er opprettet fra unike skivereferanser (`&mut [_]`), slik at de er gyldige og ikke overlapper hverandre.
            //
            // - Elementene er: Kopier så det er OK å kopiere dem, uten å gjøre noe med de opprinnelige verdiene
            // - `count` er lik len til `source`, så kilden er gyldig for `count` leser
            // - `.reserve(count)` garanterer at `spare.len() >= count` så reserve er gyldig for `count` skriver
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elementene ble nettopp initialisert av `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vanlige trait-implementeringer for Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): med cfg(test) er den iboende `[T]::to_vec`-metoden, som kreves for denne metodedefinisjonen, ikke tilgjengelig.
    // Bruk i stedet `slice::to_vec`-funksjonen som bare er tilgjengelig med cfg(test) NB. Se slice::hack-modulen i slice.rs for mer informasjon
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // slipp alt som ikke blir overskrevet
        self.truncate(other.len());

        // self.len <= other.len på grunn av forkortelsen over, så stykkene her er alltid innenfor rammen.
        //
        let (init, tail) = other.split_at(self.len());

        // gjenbruk de inneholdte verdiene allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Skaper en forbrukende iterator, det vil si en som flytter hver verdi ut av vector (fra start til slutt).
    /// vector kan ikke brukes etter at du har ringt dette.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s har typen String, ikke &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // bladmetode som forskjellige SpecFrom/SpecExtend-implementeringer delegerer når de ikke har ytterligere optimaliseringer å bruke
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Dette er tilfelle for en generell iterator.
        //
        // Denne funksjonen skal være den moralske ekvivalenten til:
        //
        //      for vare i iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB kan ikke flyte over siden vi måtte ha tildelt adresseplassen
                self.set_len(len + 1);
            }
        }
    }

    /// Oppretter en spleiseringsiterator som erstatter det angitte området i vector med den gitte `replace_with` iteratoren og gir de fjernede elementene.
    ///
    /// `replace_with` trenger ikke være like lang som `range`.
    ///
    /// `range` blir fjernet selv om iteratoren ikke forbrukes til slutten.
    ///
    /// Det er uspesifisert hvor mange elementer som fjernes fra vector hvis `Splice`-verdien lekker.
    ///
    /// Inngående iterator `replace_with` forbrukes bare når `Splice`-verdien slippes.
    ///
    /// Dette er optimalt hvis:
    ///
    /// * Halen (elementene i vector etter `range`) er tom,
    /// * eller `replace_with` gir færre eller like elementer enn lengden på "rekkevidde"
    /// * eller den nedre grensen til `size_hint()` er nøyaktig.
    ///
    /// Ellers tildeles en midlertidig vector og halen flyttes to ganger.
    ///
    /// # Panics
    ///
    /// Panics hvis startpunktet er større enn sluttpunktet, eller hvis sluttpunktet er større enn lengden på vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Oppretter en iterator som bruker en lukking for å avgjøre om et element skal fjernes.
    ///
    /// Hvis lukkingen returnerer sant, blir elementet fjernet og gitt.
    /// Hvis lukkingen returnerer falsk, vil elementet forbli i vector og vil ikke bli gitt av iteratoren.
    ///
    /// Å bruke denne metoden tilsvarer følgende kode:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // koden din her
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Men `drain_filter` er enklere å bruke.
    /// `drain_filter` er også mer effektiv, fordi den kan tilbakeskifte elementene i matrisen i bulk.
    ///
    /// Merk at `drain_filter` også lar deg mutere hvert element i filterlukkingen, uansett om du velger å beholde eller fjerne det.
    ///
    ///
    /// # Examples
    ///
    /// Å dele en matrise i jevnheter og odds, gjenbruke den opprinnelige tildelingen:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Vakt mot at vi blir lekket (lekkasjeforsterkning)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Utvid implementeringen som kopierer elementer ut av referanser før du skyver dem på Vec.
///
/// Denne implementeringen er spesialisert for snittiteratorer, der den bruker [`copy_from_slice`] for å legge til hele skiven på en gang.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementerer sammenligning av vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementerer bestilling av vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // bruk drop for [T] bruk en rå skive for å referere til elementene i vector som den svakeste nødvendige typen;
            //
            // kunne unngå spørsmål om gyldighet i visse tilfeller
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec håndterer avtalen
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Oppretter en tom `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test trekker inn libstd, noe som forårsaker feil her
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test trekker inn libstd, noe som forårsaker feil her
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Får hele innholdet på `Vec<T>` som en matrise, hvis størrelsen nøyaktig samsvarer med den for den valgte matrisen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Hvis lengden ikke stemmer overens, kommer inngangen tilbake i `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Hvis du har det bra med bare å få et prefiks av `Vec<T>`, kan du ringe [`.truncate(N)`](Vec::truncate) først.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SIKKERHET: `.set_len(0)` er alltid lyd.
        unsafe { vec.set_len(0) };

        // SIKKERHET: En "Vec"-pekeren er alltid riktig justert, og
        // justeringen matrisen trenger er den samme som elementene.
        // Vi sjekket tidligere at vi har tilstrekkelige varer.
        // Elementene vil ikke dobbeltslippes ettersom `set_len` forteller `Vec` om ikke å slippe dem.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}