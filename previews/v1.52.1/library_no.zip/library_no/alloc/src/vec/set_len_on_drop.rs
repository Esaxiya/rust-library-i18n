// Angi lengden på vec når `SetLenOnDrop`-verdien går utenfor omfanget.
//
// Ideen er: Lengdefeltet i SetLenOnDrop er en lokal variabel som optimalisereren vil se, ikke alias med noen butikker gjennom Vecs datapeker.
// Dette er en løsning for aliasanalyseproblem #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}