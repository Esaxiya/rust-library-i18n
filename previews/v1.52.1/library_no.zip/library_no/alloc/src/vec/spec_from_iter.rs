use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Spesialisering trait brukt til Vec::from_iter
///
/// ## Delegasjonsgrafen:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Et vanlig tilfelle er å sende en vector til en funksjon som umiddelbart samles på nytt til en vector.
        // Vi kan kortslutte dette hvis IntoIter ikke har blitt avansert i det hele tatt.
        // Når den har blitt avansert, kan vi også bruke minnet på nytt og flytte dataene foran.
        // Men vi gjør det bare når den resulterende Vec ikke ville ha mer ubrukt kapasitet enn å skape den gjennom den generiske FromIterator-implementeringen.
        //
        // Denne begrensningen er ikke strengt nødvendig, ettersom Vecs allokeringsatferd med vilje er uspesifisert.
        // Men det er et konservativt valg.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // må delegere til spec_extend() siden extend() selv delegerer til spec_from for tomme Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Dette bruker `iterator.as_slice().to_vec()` siden spec_extend må ta flere skritt for å resonnere om den endelige kapasiteten + lengden og dermed gjøre mer arbeid.
// `to_vec()` fordeler direkte riktig beløp og fyller det nøyaktig.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): med cfg(test) er den iboende `[T]::to_vec`-metoden, som kreves for denne metodedefinisjonen, ikke tilgjengelig.
    // Bruk i stedet `slice::to_vec`-funksjonen som bare er tilgjengelig med cfg(test) NB. Se slice::hack-modulen i slice.rs for mer informasjon
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}