use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Spesialiseringsmarkør for å samle en iteratorrørledning inn i en Vec mens du bruker kildetildelingen på nytt, dvs.
/// utføre rørledningen på plass.
///
/// SourceIter-foreldren trait er nødvendig for at spesialiseringsfunksjonen skal få tilgang til tildelingen som skal brukes på nytt.
/// Men det er ikke tilstrekkelig at spesialiseringen er gyldig.
/// Se ytterligere grenser på impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Den std-interne SourceIter/InPlaceIterable traits er bare implementert av adapterkjeder <Adapter<Adapter<IntoIter>>> (alle eid av core/std).
// Ytterligere grenser for adapterimplementeringene (utover `impl<I: Trait> Trait for Adapter<I>`) avhenger bare av andre traits som allerede er merket som spesialisering traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. markøren avhenger ikke av levetiden til brukerleverte typer.Moduler kopihullet, som flere andre spesialiseringer allerede er avhengig av.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Tilleggskrav som ikke kan uttrykkes via trait bounds.Vi stoler på konstant i stedet:
        // a) ingen ZST-er, da det ikke vil være noen allokering til gjenbruk og pekere-aritmetikk vil panic b) størrelse samsvarer som påkrevd av Alloc-kontrakt c) justeringer samsvarer med kravene i Alloc-kontrakt
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // tilbakeslag til mer generiske implementeringer
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // bruk prøvefold siden
        // - det vektoriserer bedre for noen iteratoradaptere
        // - i motsetning til de fleste interne iterasjonsmetoder, tar det bare et &mut-selv
        // - det lar oss trekke skrivepekeren gjennom dens indre og få den tilbake til slutt
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iterasjon lyktes, ikke slipp hodet
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // sjekk om SourceIter-kontrakten ble opprettholdt: hvis de ikke var det, kan vi ikke engang gjøre det til dette punktet
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // sjekk InPlaceIterable kontrakt.Dette er bare mulig hvis iteratoren i det hele tatt avanserte kildepekeren.
        // Hvis den bruker ukontrollert tilgang via TrustedRandomAccess, vil kildepekeren forbli i utgangsposisjonen, og vi kan ikke bruke den som referanse
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // slipp eventuelle gjenværende verdier på baken av kilden, men forhindrer at selve tildelingen faller når IntoIter går utenfor omfanget hvis fallet panics, så lekker vi også alle elementene som er samlet inn i dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable-kontrakten kan ikke verifiseres nøyaktig her siden try_fold har en eksklusiv referanse til kildepekeren alt vi kan gjøre er å sjekke om den fremdeles er innen rekkevidde
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}