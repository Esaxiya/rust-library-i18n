#![stable(feature = "wake_trait", since = "1.51.0")]
//! Typer og Traits for arbeid med asynkrone oppgaver.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Implementeringen av å vekke en oppgave på en eksekutor.
///
/// Denne trait kan brukes til å lage en [`Waker`].
/// En eksekutor kan definere en implementering av denne trait, og bruke den til å konstruere en Waker til å overføre til oppgavene som utføres på den eksekutøren.
///
/// Denne trait er et minnesikkert og ergonomisk alternativ til å konstruere en [`RawWaker`].
/// Den støtter den vanlige utførelsesdesignen der dataene som brukes til å vekke en oppgave lagres i en [`Arc`].
/// Noen utførere (spesielt de for innebygde systemer) kan ikke bruke denne API-en, og det er derfor [`RawWaker`] eksisterer som et alternativ for disse systemene.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// En grunnleggende `block_on`-funksjon som tar en future og kjører den til fullføring på gjeldende tråd.
///
/// **Note:** Dette eksemplet handler om korrekthet for enkelhet.
/// For å forhindre fastlåsning, må implementeringer av produksjonsgrad også håndtere mellomanrop til `thread::unpark` samt nestede påkallinger.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// En waker som vekker den gjeldende tråden når den blir ringt.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Kjør en future til fullføring på gjeldende tråd.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Fest future slik at den kan polles.
///     let mut fut = Box::pin(fut);
///
///     // Opprett en ny kontekst som skal overføres til future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Kjør future til fullføring.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Vekk denne oppgaven.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Våkne denne oppgaven uten å konsumere våken.
    ///
    /// Hvis en eksekutor støtter en billigere måte å våkne uten å konsumere waker, bør det overstyre denne metoden.
    /// Som standard kloner den [`Arc`] og kaller [`wake`] på klonen.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SIKKERHET: Dette er trygt fordi raw_waker trygt konstruerer
        // en RawWaker fra Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Denne private funksjonen for å konstruere en RawWaker brukes i stedet for
// å trekke dette inn i `From<Arc<W>> for RawWaker`-impl., for å sikre at sikkerheten til `From<Arc<W>> for Waker` ikke avhenger av riktig trait-utsendelse, i stedet kaller begge impls denne funksjonen direkte og eksplisitt.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Øk referansetellingen til buen for å klone den.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Våkn etter verdi, flytt Arc til Wake::wake-funksjonen
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Våkn med referanse, pakk inn vakkeren i ManuallyDrop for å unngå å slippe den
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Reduser referansetellingen for Arc on drop
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}