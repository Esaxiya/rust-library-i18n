#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Innholdet i det nye minnet er ikke initialisert.
    Uninitialized,
    /// Det nye minnet nullstilles garantert.
    Zeroed,
}

/// Et verktøy på lavt nivå for mer ergonomisk tildeling, omfordeling og omplassering av en buffer med minne på dyngen uten å måtte bekymre deg for alle involverte hjørnesaker.
///
/// Denne typen er utmerket for å bygge dine egne datastrukturer som Vec og VecDeque.
/// Spesielt:
///
/// * Produserer `Unique::dangling()` på nullstørrelsestyper.
/// * Produserer `Unique::dangling()` på tildelinger uten lengde.
/// * Unngår å frigjøre `Unique::dangling()`.
/// * Fanger alle overløp i kapasitetsberegninger (markedsfører dem til "capacity overflow" panics).
/// * Beskytter mot 32-bits systemer som tildeler mer enn isize::MAX byte.
/// * Beskytter mot å overfylle lengden din.
/// * Ringer til `handle_alloc_error` for feilbare tildelinger.
/// * Inneholder en `ptr::Unique` og gir dermed brukeren alle relaterte fordeler.
/// * Bruker overskuddet som er returnert fra tildeleren for å bruke den største tilgjengelige kapasiteten.
///
/// Denne typen inspiserer uansett ikke minnet den administrerer.Når den slippes *vil den* frigjøre minnet, men det *vil ikke* prøve å slippe innholdet.
/// Det er opp til brukeren av `RawVec` å håndtere de faktiske tingene *lagret* inne i en `RawVec`.
///
/// Merk at overskuddet av nullstørrelsestyper alltid er uendelig, så `capacity()` returnerer alltid `usize::MAX`.
/// Dette betyr at du må være forsiktig når du runder denne typen med en `Box<[T]>`, siden `capacity()` ikke gir lengden.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Dette eksisterer fordi `#[unstable]` `const fn`s ikke trenger å være i samsvar med `min_const_fn`, og slik at de ikke kan kalles i`min_const_fn`s heller.
    ///
    /// Hvis du endrer `RawVec<T>::new` eller avhengigheter, må du passe på å ikke introdusere noe som virkelig bryter `min_const_fn`.
    ///
    /// NOTE: Vi kunne unngå dette hacket og sjekke samsvar med noe `#[rustc_force_min_const_fn]`-attributt som krever samsvar med `min_const_fn`, men som ikke nødvendigvis tillater å ringe det i `stable(...) const fn`/brukerkode som ikke muliggjør `foo` når `#[rustc_const_unstable(feature = "foo", issue = "01234")]` er til stede.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Oppretter den største mulige `RawVec` (på systembunken) uten å tildele.
    /// Hvis `T` har positiv størrelse, blir dette en `RawVec` med kapasitet `0`.
    /// Hvis `T` er nullstørrelse, lager den en `RawVec` med kapasitet `usize::MAX`.
    /// Nyttig for implementering av forsinket tildeling.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Oppretter en `RawVec` (på systembunken) med nøyaktig kapasitet og justeringskrav for en `[T; capacity]`.
    /// Dette tilsvarer å ringe `RawVec::new` når `capacity` er `0` eller `T` er nullstørrelse.
    /// Merk at hvis `T` er nullstørrelse, betyr det at du *ikke* får en `RawVec` med ønsket kapasitet.
    ///
    /// # Panics
    ///
    /// Panics hvis ønsket kapasitet overstiger `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Aborter på OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Som `with_capacity`, men garanterer at bufferen er nullstilt.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rekonstituerer en `RawVec` fra en peker og kapasitet.
    ///
    /// # Safety
    ///
    /// `ptr` må tildeles (på systembunken), og med den gitte `capacity`.
    /// `capacity` kan ikke overstige `isize::MAX` for størrelser.(bare en bekymring på 32-biters systemer).
    /// ZST vektorer kan ha en kapasitet på opptil `usize::MAX`.
    /// Hvis `ptr` og `capacity` kommer fra en `RawVec`, er dette garantert.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs er dumme.Gå til:
    // - 8 hvis elementstørrelsen er 1, fordi det er sannsynlig at noen haugetildlere sannsynligvis vil runde opp en forespørsel på mindre enn 8 byte til minst 8 byte.
    //
    // - 4 hvis elementene er moderat (<=1 KiB).
    // - 1 ellers, for å unngå å kaste bort for mye plass til veldig korte Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Som `new`, men parameterisert over valget av tildeler for den returnerte `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` betyr "unallocated".nullstørrelsestyper blir ignorert.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Som `with_capacity`, men parameterisert over valget av tildeler for den returnerte `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Som `with_capacity_zeroed`, men parameterisert over valget av tildeler for den returnerte `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Konverterer en `Box<[T]>` til en `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Konverterer hele bufferen til `Box<[MaybeUninit<T>]>` med den angitte `len`.
    ///
    /// Merk at dette vil rekonstruere alle `cap`-endringer som kan ha blitt utført korrekt.(Se beskrivelse av typen for detaljer.)
    ///
    /// # Safety
    ///
    /// * `len` må være større enn eller lik kapasitet sist etterspurt, og
    /// * `len` må være mindre enn eller lik `self.capacity()`.
    ///
    /// Merk at ønsket kapasitet og `self.capacity()` kan variere, ettersom en allokator kan samle og returnere en større minneblokk enn ønsket.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanitetssjekk den ene halvdelen av sikkerhetskravet (vi kan ikke sjekke den andre halvdelen).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Vi unngår `unwrap_or_else` her fordi det spruter mengden LLVM IR generert.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rekonstituerer en `RawVec` fra en peker, kapasitet og tildeler.
    ///
    /// # Safety
    ///
    /// `ptr` må tildeles (via den gitte tildeleren `alloc`), og med den gitte `capacity`.
    /// `capacity` kan ikke overstige `isize::MAX` for størrelser.
    /// (bare en bekymring på 32-biters systemer).
    /// ZST vektorer kan ha en kapasitet på opptil `usize::MAX`.
    /// Hvis `ptr` og `capacity` kommer fra en `RawVec` opprettet via `alloc`, er dette garantert.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Får en rå peker til starten av tildelingen.
    /// Merk at dette er `Unique::dangling()` hvis `capacity == 0` eller `T` er nullstørrelse.
    /// I det første tilfellet må du være forsiktig.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Får kapasiteten til tildelingen.
    ///
    /// Dette vil alltid være `usize::MAX` hvis `T` er nullstørrelse.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Returnerer en delt referanse til tildeleren som støtter denne `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Vi har en tildelt mengde minne, slik at vi kan omgå kjøretidskontroller for å få vår nåværende layout.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Sikrer at bufferen inneholder minst nok plass til å holde `len + additional`-elementer.
    /// Hvis den ikke allerede har nok kapasitet, vil den omfordele nok plass pluss komfortabel slapp plass for å bli amortisert *O*(1) oppførsel.
    ///
    /// Vil begrense denne oppførselen hvis den unødvendig vil føre til panic.
    ///
    /// Hvis `len` overstiger `self.capacity()`, kan dette mislykkes i å faktisk tildele den forespurte plassen.
    /// Dette er egentlig ikke utrygt, men den usikre koden *du* skriver som er avhengig av oppførselen til denne funksjonen, kan gå i stykker.
    ///
    /// Dette er ideelt for å implementere en bulk-push-operasjon som `extend`.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapasiteten overstiger `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Aborter på OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserve ville ha avbrutt eller fått panikk hvis lenen overskred `isize::MAX`, så dette er trygt å gjøre ukontrollert nå.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Det samme som `reserve`, men returnerer ved feil i stedet for å få panikk eller avbryte.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Sikrer at bufferen inneholder minst nok plass til å holde `len + additional`-elementer.
    /// Hvis det ikke allerede gjør det, vil den omfordele den minste mulige mengden minne som er nødvendig.
    /// Vanligvis vil dette være nøyaktig den mengden minne som er nødvendig, men i prinsippet kan allokatoren gi tilbake mer enn vi ba om.
    ///
    ///
    /// Hvis `len` overstiger `self.capacity()`, kan dette mislykkes i å faktisk tildele den forespurte plassen.
    /// Dette er egentlig ikke utrygt, men den usikre koden *du* skriver som er avhengig av oppførselen til denne funksjonen, kan gå i stykker.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapasiteten overstiger `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Aborter på OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Det samme som `reserve_exact`, men returnerer ved feil i stedet for å få panikk eller avbryte.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Krymper tildelingen ned til det angitte beløpet.
    /// Hvis det gitte beløpet er 0, deles faktisk ut fullstendig.
    ///
    /// # Panics
    ///
    /// Panics hvis det gitte beløpet er *større* enn dagens kapasitet.
    ///
    /// # Aborts
    ///
    /// Aborter på OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Returnerer hvis bufferen må vokse for å oppfylle den nødvendige ekstra kapasiteten.
    /// Brukes hovedsakelig for å gjøre innlining av reserveanrop mulig uten å legge inn `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Denne metoden blir vanligvis instansert mange ganger.Så vi vil at den skal være så liten som mulig, for å forbedre kompileringstidene.
    // Men vi vil også at så mye av innholdet skal kunne beregnes statisk som mulig, slik at den genererte koden går raskere.
    // Derfor er denne metoden nøye skrevet slik at all koden som avhenger av `T` er innenfor den, mens så mye av koden som ikke er avhengig av `T`, er i funksjoner som ikke er generiske over `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Dette sikres av kallesammenhengene.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Siden vi returnerer en kapasitet på `usize::MAX` når `elem_size` er
            // 0, å komme hit betyr nødvendigvis at `RawVec` er overfull.
            return Err(CapacityOverflow);
        }

        // Ingenting vi egentlig kan gjøre med disse kontrollene, dessverre.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Dette garanterer eksponentiell vekst.
        // Fordoblingen kan ikke flyte over fordi `cap <= isize::MAX` og typen `cap` er `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` er ikke-generisk over `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Begrensningene for denne metoden er mye de samme som på `grow_amortized`, men denne metoden blir vanligvis instansert sjeldnere, så den er mindre kritisk.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Siden vi returnerer en kapasitet på `usize::MAX` når typestørrelsen er
            // 0, å komme hit betyr nødvendigvis at `RawVec` er overfull.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` er ikke-generisk over `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Denne funksjonen er utenfor `RawVec` for å minimere kompileringstider.Se kommentaren over `RawVec::grow_amortized` for detaljer.
// (`A`-parameteren er ikke signifikant, fordi antall forskjellige `A`-typer sett i praksis er mye mindre enn antall `T`-typer.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Se etter feilen her for å minimere størrelsen på `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Tildelingen sjekker for likestilling
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Frigjør minnet som eies av `RawVec`*uten* å prøve å slippe innholdet.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Sentral funksjon for håndtering av reservefeil.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Vi må garantere følgende:
// * Vi tildeler aldri `> isize::MAX` byte-størrelse objekter.
// * Vi overløper ikke `usize::MAX` og tildeler faktisk for lite.
//
// På 64-bit trenger vi bare å sjekke for overløp siden det å prøve å tildele `> isize::MAX` byte sikkert vil mislykkes.
// På 32-bit og 16-bit trenger vi å legge til en ekstra vakt for dette i tilfelle vi kjører på en plattform som kan bruke alle 4 GB i brukerområdet, for eksempel PAE eller x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// En sentral funksjon som er ansvarlig for rapportering av kapasitet.
// Dette vil sikre at kodegenerering relatert til disse panics er minimal, da det bare er ett sted som panics i stedet for en haug i hele modulen.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}