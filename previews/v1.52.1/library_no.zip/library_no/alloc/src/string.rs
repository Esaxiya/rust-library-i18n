//! En UTF-8-kodet, dyrkbar streng.
//!
//! Denne modulen inneholder [`String`]-typen, [`ToString`] trait for konvertering til strenger, og flere feiltyper som kan oppstå ved å arbeide med [`String`].
//!
//!
//! # Examples
//!
//! Det er flere måter å lage en ny [`String`] fra en streng bokstavelig:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Du kan opprette en ny [`String`] fra en eksisterende ved å sammenkoble med
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Hvis du har en vector med gyldige UTF-8-byte, kan du lage en [`String`] ut av den.Du kan også gjøre det motsatte.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Vi vet at disse bytene er gyldige, så vi bruker `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// En UTF-8-kodet, dyrkbar streng.
///
/// `String`-typen er den vanligste strengtypen som har eierskap over strengens innhold.Den har et nært forhold til sin lånte motpart, den primitive [`str`].
///
/// # Examples
///
/// Du kan opprette en `String` fra [a literal string][`str`] med [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Du kan legge til en [`char`] til en `String` med [`push`]-metoden, og legge til en [`&str`] med [`push_str`]-metoden:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Hvis du har en vector med UTF-8 byte, kan du opprette en `String` fra den med [`from_utf8`]-metoden:
///
/// ```
/// // noen byte, i en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Vi vet at disse bytene er gyldige, så vi bruker `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s er alltid gyldige UTF-8.Dette har noen få implikasjoner, den første er at hvis du trenger en streng som ikke er UTF-8, bør du vurdere [`OsString`].Det er likt, men uten UTF-8-begrensning.Den andre implikasjonen er at du ikke kan indeksere til en `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indeksering er ment å være en konstant tidsoperasjon, men UTF-8-koding tillater ikke oss å gjøre dette.Videre er det ikke klart hva slags ting indeksen skal returnere: en byte, et kodepunkt eller en grafemklynge.
/// [`bytes`]-og [`chars`]-metodene returnerer iteratorer over henholdsvis de to første.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `Strengens redskap [` Deref`]`<Target=str>`, og arver altså alle [` str`] metodene.I tillegg betyr dette at du kan overføre en `String` til en funksjon som tar en [`&str`] ved å bruke et ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Dette vil opprette en [`&str`] fra `String` og sende den inn. Denne konverteringen er veldig billig, og generelt vil funksjoner akseptere [`&str`] som argumenter med mindre de trenger en `String` av en eller annen spesifikk grunn.
///
/// I visse tilfeller har Rust ikke nok informasjon til å gjøre denne konverteringen, kjent som [`Deref`] tvang.I det følgende eksemplet implementerer en strengskive [`&'a str`][`&str`] trait `TraitExample`, og funksjonen `example_func` tar alt som implementerer trait.
/// I dette tilfellet trenger Rust å gjøre to implisitte konverteringer, noe Rust ikke har mulighet til å gjøre.
/// Av den grunn vil ikke følgende eksempel kompilere.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Det er to alternativer som fungerer i stedet.Den første ville være å endre linjen `example_func(&example_string);` til `example_func(example_string.as_str());`, ved å bruke metoden [`as_str()`] for å eksplisitt trekke ut strengskiven som inneholder strengen.
/// Den andre måten endrer `example_func(&example_string);` til `example_func(&*example_string);`.
/// I dette tilfellet refererer vi til en `String` til en [`str`][`&str`], og refererer deretter [`str`][`&str`] tilbake til [`&str`].
/// Den andre måten er mer idiomatisk, men begge arbeider for å gjøre konverteringen eksplisitt i stedet for å stole på den implisitte konvertering.
///
/// # Representation
///
/// En `String` består av tre komponenter: en peker til noen byte, en lengde og en kapasitet.Pekeren peker på en intern buffer `String` bruker til å lagre dataene.Lengden er antall byte som for øyeblikket er lagret i bufferen, og kapasiteten er størrelsen på bufferen i byte.
///
/// Som sådan vil lengden alltid være mindre enn eller lik kapasiteten.
///
/// Denne bufferen lagres alltid på dyngen.
///
/// Du kan se på disse med [`as_ptr`], [`len`] og [`capacity`] metodene:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Oppdater dette når vec_into_raw_parts er stabilisert.
/// // Forhindre automatisk å slippe strengens data
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // historien har nitten byte
/// assert_eq!(19, len);
///
/// // Vi kan bygge en streng på nytt av ptr, len og kapasitet.
/// // Alt dette er usikkert fordi vi er ansvarlige for at komponentene er gyldige:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Hvis en `String` har nok kapasitet, tildeles ikke legg til elementer på nytt.Tenk for eksempel på dette programmet:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Dette vil gi følgende:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Først har vi ikke noe minne tildelt i det hele tatt, men når vi føyer til strengen, øker den kapasiteten riktig.Hvis vi i stedet bruker [`with_capacity`]-metoden for å tildele riktig kapasitet i utgangspunktet:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Vi ender opp med en annen produksjon:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Her er det ikke nødvendig å tildele mer minne i løkken.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// En mulig feilverdi når du konverterer en `String` fra en UTF-8-byte vector.
///
/// Denne typen er feiltypen for [`from_utf8`]-metoden på [`String`].
/// Den er utformet på en slik måte å nøye unngå omdisponering: [`into_bytes`]-metoden vil gi tilbake byten vector som ble brukt i konverteringsforsøket.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`Utf8Error`]-typen levert av [`std::str`] representerer en feil som kan oppstå når du konverterer et stykke på [`u8`] til en [`&str`].
/// I denne forstand er det en analog til `FromUtf8Error`, og du kan få en fra en `FromUtf8Error` gjennom [`utf8_error`]-metoden.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// // noen ugyldige byte, i en vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// En mulig feilverdi når du konverterer en `String` fra en UTF-16-bytebit.
///
/// Denne typen er feiltypen for [`from_utf16`]-metoden på [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Oppretter en ny tom `String`.
    ///
    /// Gitt at `String` er tom, vil dette ikke tildele noen innledende buffer.Selv om det betyr at denne første operasjonen er veldig billig, kan det føre til overdreven tildeling senere når du legger til data.
    ///
    /// Hvis du har en ide om hvor mye data `String` vil inneholde, bør du vurdere [`with_capacity`]-metoden for å forhindre overdreven omfordeling.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Oppretter en ny tom `String` med en bestemt kapasitet.
    ///
    /// Strengene har en intern buffer for å holde dataene.
    /// Kapasiteten er lengden på den bufferen, og kan spørres med [`capacity`]-metoden.
    /// Denne metoden oppretter en tom `String`, men en med en innledende buffer som kan inneholde `capacity` byte.
    /// Dette er nyttig når du legger til en haug med data til `String`, og reduserer antall omfordelinger den trenger å gjøre.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Hvis den gitte kapasiteten er `0`, vil ingen tildeling forekomme, og denne metoden er identisk med [`new`]-metoden.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Strengen inneholder ingen tegn, selv om den har kapasitet til flere
    /// assert_eq!(s.len(), 0);
    ///
    /// // Alt dette gjøres uten å omfordele ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... men dette kan gjøre at strengen omfordeles
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): med cfg(test) er den iboende `[T]::to_vec`-metoden, som kreves for denne metodedefinisjonen, ikke tilgjengelig.
    // Siden vi ikke trenger denne metoden for testformål, vil jeg bare stubbe den. NB: se slice::hack-modulen i slice.rs for mer informasjon
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Konverterer en vector med byte til en `String`.
    ///
    /// En streng ([`String`]) er laget av byte ([`u8`]), og en vector av byte ([`Vec<u8>`]) er laget av byte, så denne funksjonen konverterer mellom de to.
    /// Ikke alle byte-skiver er gyldige `String`s, men: `String` krever at det er gyldig UTF-8.
    /// `from_utf8()` sjekker for å sikre at byte er gyldige UTF-8, og gjør deretter konverteringen.
    ///
    /// Hvis du er sikker på at bytesnittet er gyldig UTF-8, og du ikke vil pådra deg overhead av gyldighetskontrollen, er det en usikker versjon av denne funksjonen, [`from_utf8_unchecked`], som har samme oppførsel, men hopper over sjekken.
    ///
    ///
    /// Denne metoden vil passe på å ikke kopiere vector, for effektivitets skyld.
    ///
    /// Hvis du trenger en [`&str`] i stedet for en `String`, bør du vurdere [`str::from_utf8`].
    ///
    /// Det omvendte av denne metoden er [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Returnerer [`Err`] hvis segmentet ikke er UTF-8 med en beskrivelse av hvorfor de gitt byte ikke er UTF-8.vector du flyttet inn er også inkludert.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // noen byte, i en vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Vi vet at disse bytene er gyldige, så vi bruker `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Feil byte:
    ///
    /// ```
    /// // noen ugyldige byte, i en vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Se dokumentene for [`FromUtf8Error`] for mer informasjon om hva du kan gjøre med denne feilen.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Konverterer en bit byte til en streng, inkludert ugyldige tegn.
    ///
    /// Strenger er laget av byte ([`u8`]), og en bit byte ([`&[u8]`][byteslice]) er laget av byte, så denne funksjonen konverterer mellom de to.Ikke alle bytesnitt er gyldige strenger, men strenger kreves for å være gyldige UTF-8.
    /// Under denne konverteringen erstatter `from_utf8_lossy()` alle ugyldige UTF-8-sekvenser med [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], som ser slik ut:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Hvis du er sikker på at bytesnittet er gyldig UTF-8, og du ikke vil pådra deg overhead for konverteringen, er det en usikker versjon av denne funksjonen, [`from_utf8_unchecked`], som har samme oppførsel, men hopper over kontrollene.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Denne funksjonen returnerer en [`Cow<'a, str>`].Hvis byte-delen vår er ugyldig UTF-8, må vi sette inn erstatningstegnene, som vil endre størrelsen på strengen og dermed kreve en `String`.
    /// Men hvis den allerede er gyldig UTF-8, trenger vi ikke en ny tildeling.
    /// Denne returtypen lar oss håndtere begge tilfeller.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // noen byte, i en vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Feil byte:
    ///
    /// ```
    /// // noen ugyldige byte
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Dekode en UTF-16-kodet vector `v` til en `String`, og returnere [`Err`] hvis `v` inneholder ugyldige data.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Dette gjøres ikke via samle: : <Result<_, _>> () av ytelsesgrunner.
        // FIXME: funksjonen kan forenkles igjen når #48994 er lukket.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Dekod et UTF-16-kodet stykke `v` i en `String`, og erstatt ugyldige data med [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// I motsetning til [`from_utf8_lossy`] som returnerer en [`Cow<'a, str>`], returnerer `from_utf16_lossy` en `String` siden UTF-16 til UTF-8-konverteringen krever en minnetildeling.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Nedbryter en `String` i sine rå komponenter.
    ///
    /// Returnerer råpekeren til de underliggende dataene, lengden på strengen (i byte) og den tildelte kapasiteten til dataene (i byte).
    /// Dette er de samme argumentene i samme rekkefølge som argumentene til [`from_raw_parts`].
    ///
    /// Etter å ha ringt denne funksjonen, er den som ringer ansvarlig for minnet som tidligere ble administrert av `String`.
    /// Den eneste måten å gjøre dette på er å konvertere råpekeren, lengden og kapasiteten tilbake til en `String` med [`from_raw_parts`]-funksjonen, slik at destruktøren kan utføre oppryddingen.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Oppretter en ny `String` fra lengde, kapasitet og peker.
    ///
    /// # Safety
    ///
    /// Dette er svært utrygt på grunn av antall invarianter som ikke er sjekket:
    ///
    /// * Minnet på `buf` må ha blitt tildelt tidligere av samme tildeler som standardbiblioteket bruker, med en nødvendig justering på nøyaktig 1.
    /// * `length` må være mindre enn eller lik `capacity`.
    /// * `capacity` må være riktig verdi.
    /// * De første `length`-bytene på `buf` må være gyldige UTF-8.
    ///
    /// Brudd på disse kan føre til problemer som å ødelegge tildelers interne datastrukturer.
    ///
    /// Eierskapet til `buf` overføres effektivt til `String`, som deretter kan omfordele, omdisponere eller endre innholdet i minnet som pekeren peker på.
    /// Forsikre deg om at ingenting annet bruker pekeren etter at du har kalt denne funksjonen.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Oppdater dette når vec_into_raw_parts er stabilisert.
    ///     // Forhindre automatisk å slippe strengens data
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Konverterer en vector med byte til en `String` uten å sjekke at strengen inneholder gyldig UTF-8.
    ///
    /// Se den sikre versjonen, [`from_utf8`], for mer informasjon.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker fordi den ikke kontrollerer at byte som sendes til den er gyldige UTF-8.
    /// Hvis denne begrensningen brytes, kan det føre til problemer med minneutrygghet hos future-brukere av `String`, da resten av standardbiblioteket antar at `String`s er gyldige UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // noen byte, i en vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Konverterer en `String` til en byte vector.
    ///
    /// Dette bruker `String`, så vi trenger ikke å kopiere innholdet.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Pakk ut en strengskive som inneholder hele `String`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Konverterer en `String` til en foranderlig strengdel.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Legger til en gitt strengskive på slutten av denne `String`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Returnerer denne "strengens" kapasitet, i byte.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Sikrer at denne "strengens" kapasitet er minst `additional` byte større enn lengden.
    ///
    /// Kapasiteten kan økes med mer enn `additional` byte hvis den velger det, for å forhindre hyppige omdisponeringer.
    ///
    ///
    /// Hvis du ikke vil ha denne "at least"-oppførselen, se [`reserve_exact`]-metoden.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapasiteten renner over [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dette øker kanskje ikke kapasiteten:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s har nå en lengde på 2 og en kapasitet på 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Siden vi allerede har ekstra 8 kapasiteter, kaller vi dette ...
    /// s.reserve(8);
    ///
    /// // ... øker faktisk ikke.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Sikrer at kapasiteten til denne strengen er `additional` byte større enn lengden.
    ///
    /// Vurder å bruke [`reserve`]-metoden med mindre du absolutt vet bedre enn tildeleren.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapasiteten renner over `usize`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dette øker kanskje ikke kapasiteten:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s har nå en lengde på 2 og en kapasitet på 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Siden vi allerede har ekstra 8 kapasiteter, kaller vi dette ...
    /// s.reserve_exact(8);
    ///
    /// // ... øker faktisk ikke.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Prøver å reservere kapasitet for at minst `additional` flere elementer skal settes inn i den gitte `String`.
    /// Samlingen kan reservere mer plass for å unngå hyppige omdisponeringer.
    /// Etter å ha ringt `reserve`, vil kapasiteten være større enn eller lik `self.len() + additional`.
    /// Gjør ingenting hvis kapasiteten allerede er tilstrekkelig.
    ///
    /// # Errors
    ///
    /// Hvis kapasiteten går over, eller allokeringen rapporterer en feil, returneres en feil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Forhåndsreserver minnet, avslutt hvis vi ikke kan
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nå vet vi at dette ikke kan OOM midt i vårt komplekse arbeid
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Forsøker å reservere minimumskapasiteten for nøyaktig `additional` flere elementer som skal settes inn i den gitte `String`.
    ///
    /// Etter å ha ringt `reserve_exact`, vil kapasiteten være større enn eller lik `self.len() + additional`.
    /// Gjør ingenting hvis kapasiteten allerede er tilstrekkelig.
    ///
    /// Merk at tildeleren kan gi samlingen mer plass enn den ber om.
    /// Derfor kan man ikke stole på at kapasiteten er nøyaktig minimal.
    /// Foretrekker `reserve` hvis det forventes innføring av future.
    ///
    /// # Errors
    ///
    /// Hvis kapasiteten går over, eller allokeringen rapporterer en feil, returneres en feil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Forhåndsreserver minnet, avslutt hvis vi ikke kan
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nå vet vi at dette ikke kan OOM midt i vårt komplekse arbeid
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Krymper kapasiteten til denne `String` for å matche lengden.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Krymper kapasiteten til denne `String` med en nedre grense.
    ///
    /// Kapasiteten vil forbli minst like stor som både lengden og den tilførte verdien.
    ///
    ///
    /// Hvis den nåværende kapasiteten er mindre enn den nedre grensen, er dette en no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Legger til den gitte [`char`] til slutten av denne `String`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Returnerer en bytebit av innholdet i denne `String`.
    ///
    /// Det omvendte av denne metoden er [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Forkorter denne `String` til den angitte lengden.
    ///
    /// Hvis `new_len` er større enn strengens nåværende lengde, har dette ingen effekt.
    ///
    ///
    /// Merk at denne metoden ikke har noen innvirkning på strengens tildelte kapasitet
    ///
    /// # Panics
    ///
    /// Panics hvis `new_len` ikke ligger på en [`char`]-grense.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Fjerner det siste tegnet fra strengbufferen og returnerer det.
    ///
    /// Returnerer [`None`] hvis denne `String` er tom.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Fjerner en [`char`] fra denne `String` i en byteposisjon og returnerer den.
    ///
    /// Dette er en *O*(*n*)-operasjon, da den krever kopiering av hvert element i bufferen.
    ///
    /// # Panics
    ///
    /// Panics hvis `idx` er større enn eller lik "Strengens" lengde, eller hvis den ikke ligger på en [`char`]-grense.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Fjern alle trekkene med mønster `pat` i `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Treff vil bli oppdaget og fjernet iterativt, så i tilfeller der mønstre overlapper, vil bare det første mønsteret bli fjernet:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SIKKERHET: start og slutt vil være på utf8 bytegrenser pr
        // Searcher dokumenterer
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Beholder bare tegnene som er angitt av predikatet.
    ///
    /// Fjern med andre ord alle tegn `c` slik at `f(c)` returnerer `false`.
    /// Denne metoden fungerer på plass, besøker hvert tegn nøyaktig en gang i den opprinnelige rekkefølgen, og bevarer rekkefølgen på de beholdte tegnene.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Den nøyaktige rekkefølgen kan være nyttig for sporing av ekstern tilstand, som en indeks.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Pek idx til neste røye
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Setter inn et tegn i denne `String` i en byteposisjon.
    ///
    /// Dette er en *O*(*n*)-operasjon, da den krever kopiering av hvert element i bufferen.
    ///
    /// # Panics
    ///
    /// Panics hvis `idx` er større enn strengens lengde, eller hvis den ikke ligger på en [`char`]-grense.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Setter inn en strengskive i denne `String` i en byteposisjon.
    ///
    /// Dette er en *O*(*n*)-operasjon, da den krever kopiering av hvert element i bufferen.
    ///
    /// # Panics
    ///
    /// Panics hvis `idx` er større enn strengens lengde, eller hvis den ikke ligger på en [`char`]-grense.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Returnerer en foranderlig referanse til innholdet i denne `String`.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker fordi den ikke kontrollerer at byte som sendes til den er gyldige UTF-8.
    /// Hvis denne begrensningen brytes, kan det føre til problemer med minneutrygghet hos future-brukere av `String`, da resten av standardbiblioteket antar at `String`s er gyldige UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Returnerer lengden på denne `String`, i byte, ikke [`char`] eller grafemer.
    /// Med andre ord, det er kanskje ikke det et menneske vurderer lengden på strengen.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Returnerer `true` hvis denne `String` har en lengde på null, og ellers `false`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Deler strengen i to ved gitt byteindeks.
    ///
    /// Returnerer en nylig tildelt `String`.
    /// `self` inneholder byte `[0, at)`, og den returnerte `String` inneholder byte `[at, len)`.
    /// `at` må være på grensen til et UTF-8-kodepunkt.
    ///
    /// Merk at kapasiteten til `self` ikke endres.
    ///
    /// # Panics
    ///
    /// Panics hvis `at` ikke er på en `UTF-8`-kodepunktsgrense, eller hvis den er utenfor strengens siste kodepunkt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Avkorter denne `String` og fjerner alt innholdet.
    ///
    /// Selv om dette betyr at `String` vil ha en lengde på null, berører den ikke kapasiteten.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Oppretter en drenerende iterator som fjerner det angitte området i `String` og gir den fjernede `chars`.
    ///
    ///
    /// Note: Elementområdet fjernes selv om iteratoren ikke forbrukes til slutten.
    ///
    /// # Panics
    ///
    /// Panics hvis startpunktet eller sluttpunktet ikke ligger på en [`char`]-grense, eller hvis de er utenfor grensene.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Fjern området opp til β fra strengen
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Et komplett utvalg tømmer strengen
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Minne sikkerhet
        //
        // String-versjonen av Drain har ikke minnesikkerhetsproblemer med vector-versjonen.
        // Dataene er bare enkle byte.
        // Fordi fjerningen av rekkevidden skjer i Drop, vil ikke fjerningen skje hvis Drain iteratoren lekker.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Ta opp to lån samtidig.
        // &mut-strengen blir ikke tilgjengelig før iterasjonen er over, i Drop.
        let self_ptr = self as *mut _;
        // SIKKERHET: `slice::range` og `is_char_boundary` gjør de riktige grensekontrollene.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Fjerner det angitte området i strengen, og erstatter det med den gitte strengen.
    /// Den gitte strengen trenger ikke å ha samme lengde som området.
    ///
    /// # Panics
    ///
    /// Panics hvis startpunktet eller sluttpunktet ikke ligger på en [`char`]-grense, eller hvis de er utenfor grensene.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Bytt ut området opp til β fra strengen
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Minne sikkerhet
        //
        // Replace_range har ikke minnesikkerhetsproblemer med en vector Splice.
        // av vector-versjonen.Dataene er bare enkle byte.

        // ADVARSEL: Innføring av denne variabelen vil være usunt (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ADVARSEL: Innføring av denne variabelen vil være usunt (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Å bruke `range` igjen ville være usunt (#81138) Vi antar at grensene rapportert av `range` er de samme, men en kontradiktorisk implementering kan endre seg mellom samtaler
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Konverterer denne `String` til en [`Box`]`<`[`str`] `>`.
    ///
    /// Dette vil redusere overflødig kapasitet.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Returnerer en bit av [`u8`] s byte som ble forsøkt å konvertere til en `String`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // noen ugyldige byte, i en vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Returnerer byte som ble prøvd å konvertere til en `String`.
    ///
    /// Denne metoden er nøye konstruert for å unngå tildeling.
    /// Det vil konsumere feilen, flytte ut byte, slik at en kopi av byte ikke trenger å lages.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // noen ugyldige byte, i en vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Hent en `Utf8Error` for å få mer informasjon om konverteringsfeilen.
    ///
    /// [`Utf8Error`]-typen levert av [`std::str`] representerer en feil som kan oppstå når du konverterer et stykke på [`u8`] til en [`&str`].
    /// I denne forstand er det en analog til `FromUtf8Error`.
    /// Se dokumentasjonen for mer informasjon om bruk av den.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // noen ugyldige byte, i en vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // den første byten er ugyldig her
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Fordi vi itererer over `String`s, kan vi unngå minst en tildeling ved å hente den første strengen fra iteratoren og legge til den påfølgende strengene.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Fordi vi itererer over CoWs, kan vi (potentially) unngå minst en tildeling ved å få det første elementet og legge til det påfølgende elementene.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// En praktisk impl. Som delegerer til impl for `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Oppretter en tom `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementerer `+`-operatøren for sammenkobling av to strenger.
///
/// Dette forbruker `String` på venstre side og bruker bufferen på nytt (dyrker den om nødvendig).
/// Dette gjøres for å unngå å tildele en ny `String` og kopiere hele innholdet på hver operasjon, noe som vil føre til *O*(*n*^ 2) kjøretid når du bygger en *n*-bytestreng ved gjentatt sammenføyning.
///
///
/// Strengen på høyre side er bare lånt;innholdet kopieres til den returnerte `String`.
///
/// # Examples
///
/// Å sammenkoble to `strenger` tar den første etter verdi og låner den andre:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` flyttes og kan ikke lenger brukes her.
/// ```
///
/// Hvis du vil fortsette å bruke den første `String`, kan du klone den og legge til klonen i stedet:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` er fortsatt gyldig her.
/// ```
///
/// Sammenkopling av `&str`-skiver kan gjøres ved å konvertere den første til en `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementerer `+=`-operatøren for å legge til en `String`.
///
/// Dette har samme oppførsel som [`push_str`][String::push_str]-metoden.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Et typealias for [`Infallible`].
///
/// Dette aliaset eksisterer for bakoverkompatibilitet, og kan til slutt avvikles.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// En trait for å konvertere en verdi til en `String`.
///
/// Denne trait implementeres automatisk for alle typer som implementerer [`Display`] trait.
/// Som sådan bør ikke `ToString` implementeres direkte:
/// [`Display`] skal implementeres i stedet, og du får `ToString`-implementeringen gratis.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Konverterer den gitte verdien til en `String`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// I denne implementeringen returnerer `to_string`-metoden panics hvis `Display`-implementeringen returnerer en feil.
/// Dette indikerer en feil `Display`-implementering siden `fmt::Write for String` aldri returnerer en feil selv.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // En vanlig retningslinje er å ikke integrere generiske funksjoner.
    // Fjernelse av `#[inline]` fra denne metoden forårsaker imidlertid ikke ubetydelige regresjoner.
    // Se <https://github.com/rust-lang/rust/pull/74852>, det siste forsøket på å prøve å fjerne den.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Konverterer en `&mut str` til en `String`.
    ///
    /// Resultatet fordeles på dyngen.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test trekker inn libstd, noe som forårsaker feil her
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Konverterer den gitte `str`-delen i boks til en `String`.
    /// Det er bemerkelsesverdig at `str`-stykket eies.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Konverterer den gitte `String` til et `str`-stykke i eske som eies.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Konverterer en strengskive til en lånt variant.
    /// Ingen haugetildeling utføres, og strengen kopieres ikke.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Konverterer en streng til en eiervariant.
    /// Ingen haugetildeling utføres, og strengen kopieres ikke.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Konverterer en strengreferanse til en lånt variant.
    /// Ingen haugetildeling utføres, og strengen kopieres ikke.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Konverterer den gitte `String` til en vector `Vec` som inneholder verdier av typen `u8`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// En drenerende iterator for `String`.
///
/// Denne strukturen er laget av [`drain`]-metoden på [`String`].
/// Se dokumentasjonen for mer.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Vil bli brukt som&'en mut streng i destruktoren
    string: *mut String,
    /// Start på del som skal fjernes
    start: usize,
    /// Slutten på delen som skal fjernes
    end: usize,
    /// Gjeldende gjenværende område som skal fjernes
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Bruk Vec::drain.
            // "Reaffirm" grensekontrollene for å unngå at panic-koden settes inn igjen.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Returnerer den gjenværende (under) strengen til denne iteratoren som et stykke.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef impls nedenfor under stabilisering.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Kommentarer når du stabiliserer `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>for Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> for Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}