//! Tildelingen Prelude
//!
//! Hensikten med denne modulen er å lindre import av ofte brukte gjenstander av `alloc` crate ved å legge til en global import til toppen av modulene:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;