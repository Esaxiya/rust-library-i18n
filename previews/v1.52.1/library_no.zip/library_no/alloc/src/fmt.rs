//! Verktøy for formatering og utskrift av `String`s.
//!
//! Denne modulen inneholder kjøretidsstøtte for [`format!`] syntaksutvidelse.
//! Denne makroen er implementert i kompilatoren for å sende anrop til denne modulen for å formatere argumenter ved kjøretid i strenger.
//!
//! # Usage
//!
//! [`format!`]-makroen er ment å være kjent for de som kommer fra Cs `printf`/`fprintf`-funksjoner eller Python s `str.format`-funksjon.
//!
//! Noen eksempler på [`format!`]-utvidelsen er:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" med ledende nuller
//! ```
//!
//! Fra disse kan du se at det første argumentet er en formatstreng.Det kreves av kompilatoren at dette er en streng bokstavelig;det kan ikke være en variabel som sendes inn (for å utføre gyldighetskontroll).
//! Kompilatoren vil deretter analysere formatstrengen og avgjøre om listen over argumenter som er gitt, er egnet til å overføres til denne formatstrengen.
//!
//! For å konvertere en enkelt verdi til en streng, bruk [`to_string`]-metoden.Dette vil bruke [`Display`]-formateringen trait.
//!
//! ## Posisjonsparametere
//!
//! Hvert formateringsargument har lov til å spesifisere hvilket verdiargument det refererer til, og hvis det utelates antas det å være "the next argument".
//! For eksempel vil formatstrengen `{} {} {}` ta tre parametere, og de vil bli formatert i samme rekkefølge som de er gitt.
//! Formatstrengen `{2} {1} {0}` vil imidlertid formatere argumenter i omvendt rekkefølge.
//!
//! Ting kan bli litt vanskelige når du begynner å blande de to typene posisjonsspesifikatorer."next argument"-spesifikatoren kan betraktes som en iterator over argumentet.
//! Hver gang en "next argument"-spesifikator blir sett, går iteratoren videre.Dette fører til atferd som dette:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Den interne iteratoren over argumentet har ikke blitt avansert da den første `{}` er sett, så den skriver ut det første argumentet.Så når den når den andre `{}`, har iteratoren gått videre til det andre argumentet.
//! I hovedsak påvirker ikke parametere som eksplisitt navngir argumentet deres, parametere som ikke navngir et argument når det gjelder posisjonsspesifikatorer.
//!
//! Det kreves en formatstreng for å bruke alle argumentene, ellers er det en kompileringstidsfeil.Du kan referere til det samme argumentet mer enn én gang i formatstrengen.
//!
//! ## Navngitte parametere
//!
//! Rust i seg selv har ikke en Python-lignende ekvivalent av navngitte parametere til en funksjon, men [`format!`]-makroen er en syntaksutvidelse som gjør det mulig å utnytte navngitte parametere.
//! Navngitte parametere er oppført på slutten av argumentlisten og har syntaksen:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Følgende [`format!`]-uttrykk bruker for eksempel alle navngitte argumenter:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Det er ikke gyldig å sette posisjonsparametere (de uten navn) etter argumenter som har navn.Som med posisjonsparametere, er det ikke gyldig å oppgi navngitte parametere som ikke brukes av formatstrengen.
//!
//! # Formateringsparametere
//!
//! Hvert argument som formateres kan transformeres av et antall formateringsparametere (tilsvarende `format_spec` i [the syntax](#syntax)). Disse parametrene påvirker strengrepresentasjonen av det som blir formatert.
//!
//! ## Width
//!
//! ```
//! // Alle disse skriver ut "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Dette er en parameter for "minimum width" som formatet skal ta opp.
//! Hvis strengens verdi ikke fyller så mange tegn, vil polstringen spesifisert av fill/alignment brukes til å ta opp ønsket plass (se nedenfor).
//!
//! Verdien for bredden kan også oppgis som en [`usize`] i listen over parametere ved å legge til en postfix `$`, noe som indikerer at det andre argumentet er en [`usize`] som spesifiserer bredden.
//!
//! Å referere til et argument med dollar-syntaksen påvirker ikke "next argument"-telleren, så det er vanligvis en god ide å referere til argumenter etter posisjon, eller bruke navngitte argumenter.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Valgfritt fyllkarakter og justering leveres normalt i forbindelse med [`width`](#width)-parameteren.Den må defineres før `width`, rett etter `:`.
//! Dette indikerer at hvis verdien som formateres er mindre enn `width`, vil noen ekstra tegn bli skrevet ut rundt den.
//! Fylling kommer i følgende varianter for forskjellige justeringer:
//!
//! * `[fill]<` - argumentet er venstrejustert i `width`-kolonner
//! * `[fill]^` - argumentet er midtstilt i `width`-kolonner
//! * `[fill]>` - argumentet er høyrejustert i `width`-kolonner
//!
//! Standard [fill/alignment](#fillalignment) for ikke-numerikk er mellomrom og venstrejustert.Standard for numeriske formater er også et mellomromstegn, men med høyrejustering.
//! Hvis `0`-flagget (se nedenfor) er spesifisert for numerikk, er det implisitte fylltegnet `0`.
//!
//! Merk at justering ikke kan implementeres av noen typer.Spesielt er det vanligvis ikke implementert for `Debug` trait.
//! En god måte å sikre at polstring blir brukt er å formatere inngangen din, og deretter putte denne resulterende strengen for å få utdataene dine:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hei Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Dette er alle flagg som endrer formatørens oppførsel.
//!
//! * `+` - Dette er ment for numeriske typer og indikerer at tegnet alltid skal skrives ut.Positive tegn skrives aldri ut som standard, og det negative tegnet skrives bare ut som standard for `Signed` trait.
//! Dette flagget indikerer at riktig tegn (`+` eller `-`) alltid skal skrives ut.
//! * `-` - For tiden ikke brukt
//! * `#` - Dette flagget indikerer at utskriftsformen "alternate" skal brukes.De alternative skjemaene er:
//!     * `#?` - skriv ut [`Debug`]-formateringen pent
//!     * `#x` - går foran argumentet med en `0x`
//!     * `#X` - går foran argumentet med en `0x`
//!     * `#b` - går foran argumentet med en `0b`
//!     * `#o` - går foran argumentet med en `0o`
//! * `0` - Dette brukes til å indikere for heltallformater at polstringen til `width` både skal gjøres med et `0`-tegn, så vel som å være tegnbevisst.
//! Et format som `{:08}` vil gi `00000001` for heltallet `1`, mens det samme formatet vil gi `-0000001` for heltallet `-1`.
//! Legg merke til at den negative versjonen har en færre null enn den positive versjonen.
//!         Merk at polstringsnuller alltid plasseres etter tegnet (hvis noen) og før sifrene.Når det brukes sammen med `#`-flagget, gjelder en lignende regel: polstringsnuller settes inn etter prefikset, men før sifrene.
//!         Prefikset er inkludert i totalbredden.
//!
//! ## Precision
//!
//! For ikke-numeriske typer kan dette betraktes som en "maximum width".
//! Hvis den resulterende strengen er lengre enn denne bredden, blir den avkortet ned til så mange tegn, og den avkortede verdien sendes ut med riktig `fill`, `alignment` og `width` hvis disse parameterne er satt.
//!
//! For integrerte typer ignoreres dette.
//!
//! For flytende punkttyper indikerer dette hvor mange sifre etter desimaltegnet som skal skrives ut.
//!
//! Det er tre mulige måter å spesifisere ønsket `precision` på:
//!
//! 1. Et heltall `.N`:
//!
//!    heltallet `N` i seg selv er presisjonen.
//!
//! 2. Et heltall eller navn etterfulgt av dollartegn `.N$`:
//!
//!    bruk format *argument*`N` (som må være en `usize`) som presisjon.
//!
//! 3. En stjerne `.*`:
//!
//!    `.*` betyr at denne `{...}` er assosiert med *to* formatinnganger i stedet for én: den første inngangen har `usize`-presisjonen, og den andre inneholder verdien som skal skrives ut.
//!    Merk at i dette tilfellet, hvis man bruker formatstrengen `{<arg>:<spec>.*}`, så refererer `<arg>`-delen til*-verdien * som skal skrives ut, og `precision` må komme i inngangen før `<arg>`.
//!
//! For eksempel skriver følgende samtaler ut det samme `Hello x is 0.01000`:
//!
//! ```
//! // Hei {arg 0 ("x")} er {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hei {arg 1 ("x")} er {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hei {arg 0 ("x")} er {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hei {next arg ("x")} er {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hei {next arg ("x")} er {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hei {next arg ("x")} er {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Mens disse:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! skrive ut tre vesentlig forskjellige ting:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! I noen programmeringsspråk avhenger oppførselen til strengformateringsfunksjoner av innstillingene for operativsystemet.
//! Formatfunksjonene som tilbys av Rust s standardbibliotek har ikke noe lokalkonsept og vil gi de samme resultatene på alle systemer uavhengig av brukerkonfigurasjon.
//!
//! For eksempel vil følgende kode alltid skrive ut `1.5` selv om systemets språk bruker en desimalseparator enn en prikk.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Bokstavtegnene `{` og `}` kan inkluderes i en streng ved å gå foran dem med samme tegn.For eksempel slippes `{`-tegnet med `{{` og `}`-tegnet slippes unna med `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! For å oppsummere, her kan du finne den fullstendige grammatikken til formatstrenger.
//! Syntaksen for formateringsspråket som er brukt er hentet fra andre språk, så det skal ikke være for fremmed.Argumenter er formatert med Python-lignende syntaks, noe som betyr at argumenter er omgitt av `{}` i stedet for C-lignende `%`.
//! Den faktiske grammatikken for formateringssyntaks er:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! I grammatikken ovenfor kan det hende at `text` ikke inneholder noen `'{'`-eller `'}'`-tegn.
//!
//! # Formatering av traits
//!
//! Når du ber om at et argument skal formateres med en bestemt type, ber du faktisk om at et argument tilskrives en bestemt trait.
//! Dette gjør at flere faktiske typer kan formateres via `{:x}` (som [`i8`] så vel som [`isize`]).Den nåværende kartleggingen av typene til traits er:
//!
//! * *ingenting* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] med små og store heksadesimale heltall
//! * `X?` ⇒ [`Debug`] med store og små heksadesimale heltall
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Hva dette betyr er at alle typer argumenter som implementerer [`fmt::Binary`][`Binary`] trait, kan deretter formateres med `{:b}`.Implementeringer er gitt for disse traits for en rekke primitive typer også av standardbiblioteket.
//!
//! Hvis ikke noe format er spesifisert (som i `{}` eller `{:6}`), er formatet trait som brukes [`Display`] trait.
//!
//! Når du implementerer et format trait for din egen type, må du implementere en metode for signaturen:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // vår tilpassede type
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Din type vil bli sendt som `self`-referanse, og deretter skal funksjonen sende utgang til `f.buf`-strømmen.Det er opp til hvert format trait-implementering å rette seg etter de valgte formateringsparametrene.
//! Verdiene til disse parametrene vil bli oppført i feltene i [`Formatter`] struct.For å hjelpe til med dette, gir [`Formatter`] struct også noen hjelpemetoder.
//!
//! I tillegg er returverdien for denne funksjonen [`fmt::Result`], som er et typealias for [`Resultat`]`<(),`[`std: : fmt::Error`] `>`.
//! Formatering av implementeringer bør sikre at de overfører feil fra [`Formatter`] (f.eks. Når du ringer til [`write!`]).
//! Imidlertid bør de aldri returnere feil falskt.
//! Det vil si at en formateringsimplementering bare må returnere en feil hvis den innleverte [`Formatter`] returnerer en feil.
//! Dette er fordi, i motsetning til hva funksjonssignaturen kan foreslå, er strengformatering en ufeilbarbar operasjon.
//! Denne funksjonen returnerer bare et resultat fordi skriving til den underliggende strømmen kan mislykkes, og den må gi en måte å formidle det faktum at det har oppstått en feil tilbake i stabelen.
//!
//! Et eksempel på implementering av formateringen traits vil se ut:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f`-verdien implementerer `Write` trait, det er det som skrives!makro venter.
//!         // Merk at denne formateringen ignorerer de forskjellige flaggene som er gitt for å formatere strenger.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Ulike traits tillater forskjellige former for utdata av en type.
//! // Betydningen av dette formatet er å skrive ut størrelsen på en vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respekter formateringsflaggene ved hjelp av hjelpemetoden `pad_integral` på Formatter-objektet.
//!         // Se metodedokumentasjonen for detaljer, og funksjonen `pad` kan brukes til å putte strenger.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` mot `fmt::Debug`
//!
//! Disse to formateringene traits har forskjellige formål:
//!
//! - [`fmt::Display`][`Display`] implementeringer hevder at typen til enhver tid kan representeres som en UTF-8-streng.Det er **ikke** forventet at alle typer implementerer [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementeringer bør implementeres for **alle** offentlige typer.
//!   Output vil typisk representere den interne tilstanden så trofast som mulig.
//!   Formålet med [`Debug`] trait er å lette feilsøking av Rust-koden.I de fleste tilfeller er bruk av `#[derive(Debug)]` tilstrekkelig og anbefalt.
//!
//! Noen eksempler på produksjonen fra begge traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Relaterte makroer
//!
//! Det er en rekke relaterte makroer i [`format!`]-familien.De som er implementert for øyeblikket er:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dette og [`writeln!`] er to makroer som brukes til å sende ut formatstrengen til en spesifisert strøm.Dette brukes til å forhindre mellomfordeling av formatstrenger og i stedet skrive utdataene direkte.
//! Under panseret påkaller denne funksjonen faktisk [`write_fmt`]-funksjonen som er definert på [`std::io::Write`] trait.
//! Eksempel på bruk er:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Dette og [`println!`] sender ut produksjonen til stdout.På samme måte som [`write!`]-makroen, er målet med disse makroene å unngå mellomtildelinger når du skriver ut utskrift.Eksempel på bruk er:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`]-og [`eprintln!`]-makroene er identiske med henholdsvis [`print!`] og [`println!`], bortsett fra at de sender ut resultatet til stderr.
//!
//! ### `format_args!`
//!
//! Dette er en merkelig makro som brukes til å trygt passere et ugjennomsiktig objekt som beskriver formatstrengen.Dette objektet krever ingen haugetildelinger for å opprette, og det refererer bare til informasjon på bunken.
//! Under panseret er alle relaterte makroer implementert i forhold til dette.
//! For det første er noen eksempler på bruk:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Resultatet av [`format_args!`]-makroen er en verdi av typen [`fmt::Arguments`].
//! Denne strukturen kan deretter sendes til [`write`]-og [`format`]-funksjonene i denne modulen for å behandle formatstrengen.
//! Målet med denne makroen er å ytterligere forhindre mellomallokeringer når du arbeider med formateringsstrenger.
//!
//! For eksempel kan et loggbibliotek bruke standard formateringssyntaks, men det vil passere internt rundt denne strukturen til det er bestemt hvor utdata skal gå til.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format`-funksjonen tar en [`Arguments`]-struktur og returnerer den resulterende formaterte strengen.
///
///
/// [`Arguments`]-forekomsten kan opprettes med [`format_args!`]-makroen.
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Vær oppmerksom på at bruk av [`format!`] kan være å foretrekke.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}