//! En dynamisk størrelse i en sammenhengende sekvens, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Skiver er et syn på en blokk av minne representert som en peker og en lengde.
//!
//! ```
//! // kutte en Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // tvinger en matrise til et stykke
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Skivene kan enten endres eller deles.
//! Den delte skivetypen er `&[T]`, mens den skiftbare skivetypen er `&mut [T]`, der `T` representerer elementtypen.
//! For eksempel kan du mutere minneblokken som en muterbar del peker på:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Her er noen av tingene denne modulen inneholder:
//!
//! ## Structs
//!
//! Det er flere strukturer som er nyttige for skiver, for eksempel [`Iter`], som representerer iterasjon over et stykke.
//!
//! ## Trait Implementasjoner
//!
//! Det er flere implementeringer av vanlige traits for skiver.Noen eksempler inkluderer:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], for skiver hvis elementtype er [`Eq`] eller [`Ord`].
//! * [`Hash`] - for skiver hvis elementtype er [`Hash`].
//!
//! ## Iteration
//!
//! Skivene implementerer `IntoIterator`.Iteratoren gir referanser til skiveelementene.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Den foranderlige delen gir foranderlige referanser til elementene:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Denne iteratoren gir muterte referanser til skivens elementer, så mens skivens elementtype er `i32`, er elementtypen til iteratoren `&mut i32`.
//!
//!
//! * [`.iter`] og [`.iter_mut`] er de eksplisitte metodene for å returnere standard iteratorene.
//! * Ytterligere metoder som returnerer iteratorer er [`.split`], [`.splitn`], [`.chunks`], [`.windows`] og mer.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Mange av bruken i denne modulen brukes bare i testkonfigurasjonen.
// Det er renere å bare slå av advarselen ubrukt_import enn å fikse dem.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Grunnleggende metoder for skiveforlengelse
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) nødvendig for implementering av `vec!`-makro under testing NB, se `hack`-modulen i denne filen for mer informasjon.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) nødvendig for implementering av `Vec::clone` under testing NB, se `hack`-modulen i denne filen for mer informasjon.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Med cfg(test) `impl [T]` ikke er tilgjengelig, disse tre funksjonene er faktisk metoder som er i `impl [T]`, men ikke i `core::slice::SliceExt`, vi må levere disse funksjonene for `test_permutations`-testen
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Vi bør ikke legge til innebygd attributt til dette siden dette hovedsakelig brukes i `vec!`-makro og forårsaker perfeksjon.
    // Se #71204 for diskusjon og perfeksjonsresultater.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // elementene ble merket initialisert i løkken nedenfor
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) er nødvendig for at LLVM skal fjerne grensekontroll og har bedre kodegen enn zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec ble tildelt og initialisert ovenfor til minst denne lengden.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // tildelt ovenfor med kapasiteten på `s`, og initialiser til `s.len()` i ptr::copy_to_non_overlapping nedenfor.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sorterer skiven.
    ///
    /// Denne typen er stabil (dvs. omorganiserer ikke like elementer) og *O*(*n*\*log(* n*)) i verste fall.
    ///
    /// Når det er aktuelt, foretrekkes ustabil sortering fordi den generelt er raskere enn stabil sortering og den ikke tildeler hjelpeminne.
    /// Se [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er en adaptiv, iterativ flettesortering inspirert av [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Den er designet for å være veldig rask i tilfeller der stykket er nesten sortert, eller består av to eller flere sorterte sekvenser sammenkoblet etter hverandre.
    ///
    ///
    /// Den tildeler også midlertidig lagring halvparten av størrelsen på `self`, men for korte stykker brukes en ikke-tildelende innsettingssort i stedet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sorterer stykket med en komparatorfunksjon.
    ///
    /// Denne typen er stabil (dvs. omorganiserer ikke like elementer) og *O*(*n*\*log(* n*)) i verste fall.
    ///
    /// Komparatorfunksjonen må definere en total rekkefølge for elementene i stykket.Hvis bestillingen ikke er total, er rekkefølgen på elementene uspesifisert.
    /// En ordre er en total ordre hvis den er (for alle `a`, `b` og `c`):
    ///
    /// * total og antisymmetrisk: nøyaktig en av `a < b`, `a == b` eller `a > b` er sant, og
    /// * transitive, `a < b` og `b < c` innebærer `a < c`.Det samme må gjelde for både `==` og `>`.
    ///
    /// For eksempel, mens [`f64`] ikke implementerer [`Ord`] fordi `NaN != NaN`, kan vi bruke `partial_cmp` som vår sorteringsfunksjon når vi vet at delen ikke inneholder en `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Når det er aktuelt, foretrekkes ustabil sortering fordi den generelt er raskere enn stabil sortering og den ikke tildeler hjelpeminne.
    /// Se [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er en adaptiv, iterativ flettesortering inspirert av [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Den er designet for å være veldig rask i tilfeller der stykket er nesten sortert, eller består av to eller flere sorterte sekvenser sammenkoblet etter hverandre.
    ///
    /// Den tildeler også midlertidig lagring halvparten av størrelsen på `self`, men for korte stykker brukes en ikke-tildelende innsettingssort i stedet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // omvendt sortering
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sorterer skiven med en nøkkelutvinningsfunksjon.
    ///
    /// Denne typen er stabil (dvs. omorganiserer ikke like elementer) og *O*(*m*\* * n *\* log(*n*)) worst-case, der nøkkelfunksjonen er *O*(*m*).
    ///
    /// For dyre nøkkelfunksjoner (f.eks
    /// funksjoner som ikke er enkel tilgang til eiendom eller grunnleggende operasjoner), vil [`sort_by_cached_key`](slice::sort_by_cached_key) sannsynligvis være betydelig raskere, da det ikke beregner elementtaster på nytt.
    ///
    ///
    /// Når det er aktuelt, foretrekkes ustabil sortering fordi den generelt er raskere enn stabil sortering og den ikke tildeler hjelpeminne.
    /// Se [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er en adaptiv, iterativ flettesortering inspirert av [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Den er designet for å være veldig rask i tilfeller der stykket er nesten sortert, eller består av to eller flere sorterte sekvenser sammenkoblet etter hverandre.
    ///
    /// Den tildeler også midlertidig lagring halvparten av størrelsen på `self`, men for korte stykker brukes en ikke-tildelende innsettingssort i stedet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sorterer skiven med en nøkkelutvinningsfunksjon.
    ///
    /// Under sortering kalles nøkkelfunksjonen bare én gang per element.
    ///
    /// Denne typen er stabil (dvs. omorganiserer ikke like elementer) og *O*(*m*\* * n *+* n *\* log(*n*)) i verste fall, der nøkkelfunksjonen er *O*(*m*) .
    ///
    /// For enkle nøkkelfunksjoner (f.eks. Funksjoner som er tilgang til eiendom eller grunnleggende operasjoner), vil [`sort_by_key`](slice::sort_by_key) sannsynligvis være raskere.
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er basert på [pattern-defeating quicksort][pdqsort] av Orson Peters, som kombinerer det raske gjennomsnittlige tilfellet av randomisert kviksort med det raskeste verste tilfellet av heapsort, mens man oppnår lineær tid på skiver med visse mønstre.
    /// Den bruker litt randomisering for å unngå degenererte tilfeller, men med en fast seed for alltid å gi deterministisk oppførsel.
    ///
    /// I verste fall tildeler algoritmen midlertidig lagring i en `Vec<(K, usize)>` lengden på stykket.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Hjelpemakro for indeksering av vår vector av minst mulig type, for å redusere tildelingen.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Elementene til `indices` er unike, ettersom de er indeksert, så alle slags vil være stabile i forhold til den originale delen.
                // Vi bruker `sort_unstable` her fordi det krever mindre minnetildeling.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopierer `self` til en ny `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Her kan `s` og `x` endres uavhengig.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopierer `self` til en ny `Vec` med en allokator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Her kan `s` og `x` endres uavhengig.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, se `hack`-modulen i denne filen for mer informasjon.
        hack::to_vec(self, alloc)
    }

    /// Konverterer `self` til en vector uten kloner eller tildeling.
    ///
    /// Den resulterende vector kan konverteres tilbake til en boks via `Vec<T>`into_boxed_slice`-metoden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` kan ikke brukes lenger fordi den er konvertert til `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, se `hack`-modulen i denne filen for mer informasjon.
        hack::into_vec(self)
    }

    /// Oppretter en vector ved å gjenta et stykke `n` ganger.
    ///
    /// # Panics
    ///
    /// Denne funksjonen vil panic hvis kapasiteten vil flyte over.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// En panic ved overløp:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Hvis `n` er større enn null, kan den deles som `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` er tallet representert av '1'-biten til venstre for `n`, og `rem` er den gjenværende delen av `n`.
        //
        //

        // Bruker `Vec` for å få tilgang til `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` repetisjon gjøres ved å doble `buf` `expn`-ganger.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Hvis `m > 0`, er det gjenværende bits opp til venstre '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` har kapasitet på `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) repetisjon gjøres ved å kopiere første `rem`-repetisjoner fra selve `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Dette er ikke-overlappende siden `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` tilsvarer `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flater et stykke `T` til en enkelt verdi `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flater et stykke `T` inn i en enkelt verdi `Self::Output`, og plasserer en gitt skilletegn mellom hver.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flater et stykke `T` inn i en enkelt verdi `Self::Output`, og plasserer en gitt skilletegn mellom hver.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Returnerer en vector som inneholder en kopi av dette stykket der hver byte er tilordnet sin ASCII-store bokstavsekvivalent.
    ///
    ///
    /// ASCII-bokstaver 'a' til 'z' tilordnes til 'A' til 'Z', men ikke-ASCII-bokstaver er uendret.
    ///
    /// Bruk [`make_ascii_uppercase`] for å versere verdien på stedet.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Returnerer en vector som inneholder en kopi av dette stykket der hver byte er kartlagt til ASCII-små bokstavsekvivalenter.
    ///
    ///
    /// ASCII-bokstaver 'A' til 'Z' tilordnes til 'a' til 'z', men ikke-ASCII-bokstaver er uendret.
    ///
    /// For å redusere verdien på plass, bruk [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Utvidelse traits for skiver over bestemte typer data
////////////////////////////////////////////////////////////////////////////////

/// Hjelper trait for [`[T]: : concat`](skive::concat).
///
/// Note: `Item`-typeparameteren brukes ikke i denne trait, men den lar impls være mer generiske.
/// Uten den får vi denne feilen:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Dette er fordi det kan eksistere `V`-typer med flere `Borrow<[_]>`-impls, slik at flere `T`-typer vil gjelde:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Den resulterende typen etter sammenkobling
    type Output;

    /// Implementering av [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Hjelper trait for [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Den resulterende typen etter sammenkobling
    type Output;

    /// Implementering av [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standard trait implementeringer for skiver
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // slipp noe i målet som ikke blir overskrevet
        target.truncate(self.len());

        // target.len <= self.len på grunn av forkortelsen over, så stykkene her er alltid innenfor rammen.
        //
        let (init, tail) = self.split_at(target.len());

        // gjenbruk de inneholdte verdiene allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Setter `v[0]` inn i forhåndssortert sekvens `v[1..]` slik at hele `v[..]` blir sortert.
///
/// Dette er den integrerte underrutinen til innsettingssorter.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Det er tre måter å implementere innsetting her:
            //
            // 1. Bytt tilstøtende elementer til den første kommer til endelig destinasjon.
            //    Imidlertid kopierer vi data rundt mer enn nødvendig.
            //    Hvis elementene er store strukturer (kostbare å kopiere), vil denne metoden være treg.
            //
            // 2. Iterer til riktig sted for det første elementet er funnet.
            // Skift deretter elementene etter det for å få plass til det og plasser det til slutt i det gjenværende hullet.
            // Dette er en god metode.
            //
            // 3. Kopier det første elementet til en midlertidig variabel.Iterer til riktig sted for det er funnet.
            // Når vi går videre, kopierer du hvert krysset element inn i sporet før det.
            // Til slutt, kopier data fra den midlertidige variabelen til det gjenværende hullet.
            // Denne metoden er veldig bra.
            // Benchmarks viste litt bedre ytelse enn med den andre metoden.
            //
            // Alle metoder ble benchmarked, og den tredje viste best resultat.Så vi valgte den.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Den mellomliggende tilstanden til innsettingsprosessen spores alltid av `hole`, som tjener to formål:
            // 1. Beskytter integriteten til `v` fra panics i `is_less`.
            // 2. Fyller gjenværende hull i `v` til slutt.
            //
            // Panic sikkerhet:
            //
            // Hvis `is_less` panics på et hvilket som helst tidspunkt i løpet av prosessen, vil `hole` bli droppet og fylle hullet i `v` med `tmp`, og dermed sikre at `v` fortsatt holder hvert objekt det opprinnelig holdt nøyaktig en gang.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` blir droppet og kopierer dermed `tmp` inn i det gjenværende hullet i `v`.
        }
    }

    // Når du slipper, kopierer du fra `src` til `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Fusjonerer ikke-avtagende kjører `v[..mid]` og `v[mid..]` ved bruk av `buf` som midlertidig lagring, og lagrer resultatet i `v[..]`.
///
/// # Safety
///
/// De to skivene må ikke være tomme, og `mid` må være innenfor grensene.
/// Buffer `buf` må være lang nok til å ha en kopi av den kortere delen.
/// `T` må heller ikke være av null størrelse.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Sammenslåingsprosessen kopierer først den kortere løpeturen til `buf`.
    // Deretter spores det nylig kopierte løpet og lengre løp fremover (eller bakover), sammenligner de neste ukonsumerte elementene og kopierer det minste (eller større) til `v`.
    //
    // Så snart den kortere løpeturen er fullstendig forbruk, er prosessen ferdig.Hvis den lengre løpet blir fortært først, må vi kopiere det som er igjen av den kortere løpet inn i gjenværende hull i `v`.
    //
    // Den mellomliggende tilstanden til prosessen spores alltid av `hole`, som tjener to formål:
    // 1. Beskytter integriteten til `v` fra panics i `is_less`.
    // 2. Fyller gjenværende hull i `v` hvis lengre løp blir fortært først.
    //
    // Panic sikkerhet:
    //
    // Hvis `is_less` panics på et hvilket som helst tidspunkt i løpet av prosessen, vil `hole` bli droppet og fylle hullet i `v` med det uforbrukte området i `buf`, og dermed sikre at `v` fortsatt holder hvert objekt det opprinnelig holdt nøyaktig en gang.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Venstre løp er kortere.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // I utgangspunktet peker disse pekepinnene på begynnelsen av arrangementene deres.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Forbruke den mindre siden.
            // Hvis det er likt, foretrekker du venstre løp for å opprettholde stabilitet.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Riktig løp er kortere.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // I utgangspunktet peker disse pekerne forbi endene på matrisen.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Konsumere den større siden.
            // Hvis du er lik, foretrekker du riktig løp for å opprettholde stabilitet.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Endelig blir `hole` droppet.
    // Hvis den kortere løpeturen ikke ble fullstendig fortært, vil det som gjenstår av det nå bli kopiert inn i hullet i `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Når du slipper den, kopierer du området `start..end` til `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` er ikke en nullstørrelse, så det er greit å dele på størrelsen.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Denne sammenslåingen sorterer noen (men ikke alle) ideer fra TimSort, som er beskrevet i detalj [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algoritmen identifiserer strengt synkende og ikke-synkende påfølgende, som kalles naturlige løp.Det er en bunke med ventende løp som ennå ikke skal slås sammen.
/// Hver nylig funnet løp skyves på bunken, og deretter slås noen par tilstøtende løp sammen til disse to invarianter er fornøyd:
///
/// 1. for hver `i` i `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. for hver `i` i `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Invarianter sørger for at den totale kjøretiden er *O*(*n*\*log(* n*)) worst-case.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Skiver opp til denne lengden blir sortert ved hjelp av innsettingssortering.
    const MAX_INSERTION: usize = 20;
    // Svært korte løp utvides ved å bruke innsettingssortering for å spenne i det minste så mange elementer.
    const MIN_RUN: usize = 10;

    // Sortering har ingen meningsfull oppførsel på nullstørrelsestyper.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Korte matriser blir sortert på plass via innsettingssortering for å unngå tildelinger.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Tildel en buffer som skal brukes som skrapeminne.Vi beholder lengden 0 slik at vi kan ha i den grunne kopier av innholdet i `v` uten å risikere at dtorene kjører på kopier hvis `is_less` panics.
    //
    // Når du slår sammen to sorterte kjøringer, har denne bufferen en kopi av den kortere kjøringen, som alltid vil ha lengden på maksimalt `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // For å identifisere naturlige løp i `v`, krysser vi den bakover.
    // Det kan virke som en merkelig beslutning, men vurder det faktum at fusjoner oftere går i motsatt retning (forwards).
    // I følge referanser er det å koble sammen fremover litt raskere enn å slå sammen bakover.
    // For å konkludere, forbedrer ytelsen ved å identifisere løp ved å krysse bakover.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Finn neste naturlige løp, og snu det hvis det er strengt synkende.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Sett inn noen flere elementer i løpet hvis det er for kort.
        // Innsettingssortering er raskere enn sammenslåing på korte sekvenser, så dette forbedrer ytelsen betydelig.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Skyv dette løpet på bunken.
        runs.push(Run { start, len: end - start });
        end = start;

        // Slå sammen noen par tilstøtende løp for å tilfredsstille invarianter.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Til slutt må nøyaktig ett løp være igjen i stakken.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Undersøker løpestabelen og identifiserer neste par løp som skal slås sammen.
    // Mer spesifikt, hvis `Some(r)` returneres, betyr det at `runs[r]` og `runs[r + 1]` må slås sammen neste.
    // Hvis algoritmen skulle fortsette å bygge et nytt løp i stedet, returneres `None`.
    //
    // TimSort er beryktet for sine buggy-implementeringer, som beskrevet her:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Kjernen i historien er: vi må håndheve invarianterne på de fire beste løpene på bunken.
    // Å håndheve dem på bare topp tre er ikke tilstrekkelig for å sikre at invarianter fortsatt vil holde i *alle* løp i stabelen.
    //
    // Denne funksjonen sjekker invarianter riktig for de fire beste løpene.
    // I tillegg, hvis toppløpet starter ved indeks 0, vil det alltid kreve en sammenslåing til stakken er fullstendig kollapset, for å fullføre sorteringen.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}