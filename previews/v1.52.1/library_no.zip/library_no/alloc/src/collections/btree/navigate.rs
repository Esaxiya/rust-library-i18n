use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Tar midlertidig ut en annen, uforanderlig ekvivalent av samme område.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Finner de forskjellige bladkantene som avgrenser et spesifisert område i et tre.
    /// Returnerer enten et par forskjellige håndtak i samme tre eller et par tomme alternativer.
    ///
    /// # Safety
    ///
    /// Med mindre `BorrowType` er `Immut`, ikke bruk dupliserte håndtak for å besøke samme KV to ganger.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Tilsvarer `(root1.first_leaf_edge(), root2.last_leaf_edge())`, men mer effektiv.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Finner paret av bladkanter som avgrenser et bestemt område i et tre.
    ///
    /// Resultatet er bare meningsfullt hvis treet er ordnet etter nøkkel, slik som treet i en `BTreeMap` er.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SIKKERHET: vår lånetype er uforanderlig.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Finner paret av bladkanter som avgrenser et helt tre.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Deler en unik referanse i et par bladkanter som avgrenser et spesifisert område.
    /// Resultatet er ikke-unike referanser som tillater (some)-mutasjon, som må brukes forsiktig.
    ///
    /// Resultatet er bare meningsfullt hvis treet er ordnet etter nøkkel, slik som treet i en `BTreeMap` er.
    ///
    ///
    /// # Safety
    /// Ikke bruk dupliserte håndtak for å besøke samme KV to ganger.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Deler en unik referanse i et par bladkanter som avgrenser hele treets utvalg.
    /// Resultatene er ikke-unike referanser som tillater mutasjon (bare av verdier), så de må brukes med forsiktighet.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Vi dupliserer roten NodeRef her-vi vil aldri besøke samme KV to ganger, og ender aldri med overlappende verdireferanser.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Deler en unik referanse i et par bladkanter som avgrenser hele treets utvalg.
    /// Resultatene er ikke-unike referanser som tillater massiv destruktiv mutasjon, så de må brukes med største forsiktighet.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Vi dupliserer roten NodeRef her-vi får aldri tilgang til den på en måte som overlapper referanser hentet fra roten.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Gitt et blad edge håndtak, returnerer [`Result::Ok`] med et håndtak til nærliggende KV på høyre side, som enten er i samme bladnode eller i en forfedernode.
    ///
    /// Hvis bladet edge er det siste i treet, returnerer [`Result::Err`] med rotnoden.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Gitt et blad edge-håndtak, returnerer [`Result::Ok`] med et håndtak til den nærliggende KV på venstre side, som enten er i samme bladnode eller i en forfedernode.
    ///
    /// Hvis bladet edge er det første i treet, returnerer [`Result::Err`] med rotnoden.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Gitt et internt edge-håndtak, returnerer [`Result::Ok`] med et håndtak til nærliggende KV på høyre side, som enten er i samme interne node eller i en forfedernode.
    ///
    /// Hvis den interne edge er den siste i treet, returnerer [`Result::Err`] med rotnoden.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Gitt et blad edge-håndtak inn i et døende tre, returnerer neste blad edge på høyre side, og nøkkelverdiparet i mellom, som enten er i samme bladnode, i en forfadernode eller ikke eksisterer.
    ///
    ///
    /// Denne metoden distribuerer også hvilken som helst node(s) den når slutten av.
    /// Dette innebærer at hvis det ikke finnes flere nøkkelverdipar, vil hele resten av treet ha blitt omplassert og det er ingenting igjen å returnere.
    ///
    /// # Safety
    /// Den gitte edge må ikke ha blitt returnert av motparten `deallocating_next_back` tidligere.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Gitt et blad edge-håndtak inn i et døende tre, returnerer neste blad edge på venstre side, og nøkkelverdiparet i mellom, som enten er i samme bladnode, i en forfedernode eller ikke eksisterer.
    ///
    ///
    /// Denne metoden distribuerer også hvilken som helst node(s) den når slutten av.
    /// Dette innebærer at hvis det ikke finnes flere nøkkelverdipar, vil hele resten av treet ha blitt omplassert og det er ingenting igjen å returnere.
    ///
    /// # Safety
    /// Den gitte edge må ikke ha blitt returnert av motparten `deallocating_next` tidligere.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Distribuerer en haug med noder fra bladet og opp til roten.
    /// Dette er den eneste måten å plassere resten av et tre etter at `deallocating_next` og `deallocating_next_back` har nappet på begge sider av treet, og har truffet samme edge.
    /// Ettersom det kun er ment å ringes når alle nøkler og verdier er returnert, blir det ikke ryddet opp på noen av nøklene eller verdiene.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Flytter bladet edge til neste blad edge og returnerer referanser til nøkkelen og verdien i mellom.
    ///
    ///
    /// # Safety
    /// Det må være nok en KV i den kjørte retningen.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Flytter bladet edge til det forrige bladet edge og returnerer referanser til nøkkelen og verdien i mellom.
    ///
    ///
    /// # Safety
    /// Det må være nok en KV i den kjørte retningen.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Flytter bladet edge til neste blad edge og returnerer referanser til nøkkelen og verdien i mellom.
    ///
    ///
    /// # Safety
    /// Det må være nok en KV i den kjørte retningen.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Å gjøre dette sist er raskere, i henhold til referanser.
        kv.into_kv_valmut()
    }

    /// Flytter bladet edge til det forrige bladet og returnerer referanser til nøkkelen og verdien i mellom.
    ///
    ///
    /// # Safety
    /// Det må være nok en KV i den kjørte retningen.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Å gjøre dette sist er raskere, i henhold til referanser.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Flytter bladet edge-håndtaket til neste blad edge og returnerer nøkkelen og verdien i mellom, og fordeler hvilken som helst node som er igjen mens den tilsvarende edge blir igjen i sin overordnede node.
    ///
    /// # Safety
    /// - Det må være nok en KV i den kjørte retningen.
    /// - At KV ikke tidligere ble returnert av motstykke `next_back_unchecked` på noen kopier av håndtakene som ble brukt til å krysse treet.
    ///
    /// Den eneste trygge måten å fortsette med det oppdaterte håndtaket er å sammenligne det, slippe det, ringe denne metoden igjen med forbehold om sikkerhetsforholdene, eller ringe motparten `next_back_unchecked` med forbehold om sikkerhetsforholdene.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Flytter bladet edge-håndtaket til det forrige bladet edge og returnerer nøkkelen og verdien i mellom, og fordeler en hvilken som helst node som er igjen mens den tilsvarende edge blir igjen i sin overordnede node.
    ///
    /// # Safety
    /// - Det må være nok en KV i den kjørte retningen.
    /// - Det bladet edge ble ikke tidligere returnert av motstykke `next_unchecked` på noen kopier av håndtakene som ble brukt til å krysse treet.
    ///
    /// Den eneste trygge måten å fortsette med det oppdaterte håndtaket er å sammenligne det, slippe det, ringe denne metoden igjen med forbehold om sikkerhetsforholdene, eller ringe motparten `next_unchecked` med forbehold om sikkerhetsforholdene.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Returnerer bladet edge til venstre i eller under en node, med andre ord edge du trenger først når du navigerer fremover (eller sist når du navigerer bakover).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Returnerer bladet edge til høyre i eller under en node, med andre ord edge du trenger sist når du navigerer fremover (eller først når du navigerer bakover).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Besøker bladnoder og interne KV-er i rekkefølge av stigende nøkler, og besøker også interne noder som en helhet i en dybde første orden, noe som betyr at interne noder går foran deres individuelle KV-er og deres barns noder.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Beregner antall elementer i et (under) tre.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Returnerer bladet edge nærmest en KV for fremovernavigasjon.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Returnerer bladet edge nærmest en KV for bakover navigering.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}