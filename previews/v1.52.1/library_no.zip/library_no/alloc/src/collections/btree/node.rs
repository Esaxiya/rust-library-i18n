// Dette er et forsøk på en implementering som følger idealet
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Siden Rust ikke har avhengige typer og polymorf rekursjon, nøyer vi oss med mye usikkerhet.
//

// Et hovedmål med denne modulen er å unngå kompleksitet ved å behandle treet som en generisk (hvis merkelig formet) beholder og unngå å håndtere de fleste av B-Tree-invarianter.
//
// Som sådan bryr denne modulen seg ikke om oppføringene er sortert, hvilke noder som kan være for full eller til og med hva underfull betyr.Imidlertid stoler vi på noen få invarianter:
//
// - Trær må ha uniform depth/height.Dette betyr at hver vei ned til et blad fra en gitt node har nøyaktig samme lengde.
// - En node med lengden `n` har `n`-nøkler, `n`-verdier og `n + 1`-kanter.
//   Dette innebærer at selv en tom node har minst en edge.
//   For en bladnode betyr "having an edge" bare at vi kan identifisere en posisjon i noden, siden bladkanter er tomme og ikke trenger datarepresentasjon.
// I en intern node identifiserer en edge både en posisjon og inneholder en peker til en undernode.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Den underliggende representasjonen av bladnoder og en del av representasjonen av interne noder.
struct LeafNode<K, V> {
    /// Vi ønsker å være samvariante i `K` og `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Denne nodens indeks i foreldrenodens `edges`-array.
    /// `*node.parent.edges[node.parent_idx]` skal være det samme som `node`.
    /// Dette initialiseres garantert bare når `parent` ikke er null.
    parent_idx: MaybeUninit<u16>,

    /// Antall nøkler og verdier denne noden lagrer.
    len: u16,

    /// Arrangementene som lagrer de faktiske dataene til noden.
    /// Bare de første `len`-elementene i hver matrise er initialisert og gyldige.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Initialiserer en ny `LeafNode` på plass.
    unsafe fn init(this: *mut Self) {
        // Som en generell policy, lar vi felt ikke-initialiseres hvis de kan være, da dette skal være både litt raskere og lettere å spore i Valgrind.
        //
        unsafe {
            // parent_idx, nøkler og vals er alle MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Oppretter en ny boks `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Den underliggende representasjonen av interne noder.Som med `LeafNode`s, bør disse være skjult bak`BoxedNode`s for å forhindre at uninitialiserte nøkler og verdier faller.
/// Enhver peker til en `InternalNode` kan kastes direkte til en peker til den underliggende `LeafNode`-delen av noden, slik at koden kan virke på blad og interne noder generelt uten å måtte sjekke hvilken av de to en peker peker på.
///
/// Denne egenskapen er aktivert ved bruk av `repr(C)`.
///
#[repr(C)]
// gdb_providers.py bruker dette typenavnet til introspeksjon.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Pekepinnene til barna i denne noden.
    /// `len + 1` av disse anses som initialisert og gyldig, bortsett fra at nær slutten, mens treet holdes gjennom lånetype `Dying`, dingler noen av disse pekerne.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Oppretter en ny boks `InternalNode`.
    ///
    /// # Safety
    /// En invariant av interne noder er at de har minst en initialisert og gyldig edge.
    /// Denne funksjonen setter ikke opp en slik edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Vi trenger bare å initialisere dataene;kantene er MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// En administrert, ikke-null peker til en node.Dette er enten en eid peker til `LeafNode<K, V>` eller en eid peker til `InternalNode<K, V>`.
///
/// Imidlertid inneholder `BoxedNode` ingen informasjon om hvilken av de to typer noder den faktisk inneholder, og delvis på grunn av denne mangelen på informasjon, er den ikke en egen type og har ingen ødelegger.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Rotknuten til et eid tre.
///
/// Merk at dette ikke har en destruktor, og må ryddes opp manuelt.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Returnerer et nytt eid tre, med sin egen rotnode som i utgangspunktet er tom.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` må ikke være null.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Låner mutabelt den eide rotnoden.
    /// I motsetning til `reborrow_mut` er dette trygt fordi returverdien ikke kan brukes til å ødelegge roten, og det ikke kan være andre referanser til treet.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Låner den eide rotnoden litt mutabelt.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Overgås irreversibelt til en referanse som tillater gjennomkjørsel og tilbyr destruktive metoder og lite annet.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Legger til en ny intern node med en enkelt edge som peker til forrige rotnode, gjør den nye noden til rotnoden og returner den.
    /// Dette øker høyden med 1 og er motsatt av `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, bortsett fra at vi bare glemte at vi er interne nå:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Fjerner den interne rotnoden, og bruker det første barnet som den nye rotnoden.
    /// Ettersom det bare er ment å kalles når rotnoden bare har ett barn, gjøres det ikke opprydding på noen av nøklene, verdiene og andre barn.
    ///
    /// Dette reduserer høyden med 1 og er motsatt av `push_internal_level`.
    ///
    /// Krever eksklusiv tilgang til `Root`-objektet, men ikke til rotnoden;
    /// det vil ikke ugyldiggjøre andre håndtak eller referanser til rotnoden.
    ///
    /// Panics hvis det ikke er noe internt nivå, dvs. hvis rotnoden er et blad.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SIKKERHET: vi hevdet å være interne.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SIKKERHET: vi lånte `self` eksklusivt, og lånetypen er eksklusiv.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SIKKERHET: den første edge initialiseres alltid.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` er alltid kovariant i `K` og `V`, selv når `BorrowType` er `Mut`.
// Dette er teknisk feil, men kan ikke føre til usikkerhet på grunn av intern bruk av `NodeRef` fordi vi holder oss helt generiske over `K` og `V`.
//
// Men når en offentlig type innpakker `NodeRef`, må du sørge for at den har riktig varians.
//
/// En referanse til en node.
///
/// Denne typen har en rekke parametere som styrer hvordan den fungerer:
/// - `BorrowType`: En dummy-type som beskriver lånetypen og bærer livet ut.
///    - Når dette er `Immut<'a>`, fungerer `NodeRef` omtrent som `&'a Node`.
///    - Når dette er `ValMut<'a>`, fungerer `NodeRef` omtrent som `&'a Node` med hensyn til nøkler og trestruktur, men tillater også at mange foranderlige referanser til verdier i hele treet kan eksistere.
///    - Når dette er `Mut<'a>`, fungerer `NodeRef` omtrent som `&'a mut Node`, selv om innsettingsmetoder tillater en foranderlig peker til en verdi å eksistere sammen.
///    - Når dette er `Owned`, fungerer `NodeRef` omtrent som `Box<Node>`, men har ingen ødelegger, og må ryddes opp manuelt.
///    - Når dette er `Dying`, fungerer `NodeRef` fortsatt omtrent som `Box<Node>`, men har metoder for å ødelegge treet bit for bit, og vanlige metoder, selv om de ikke er merket som usikre å ringe, kan påkalle UB hvis de blir kalt feil.
///
///   Siden enhver `NodeRef` tillater navigering gjennom treet, gjelder `BorrowType` effektivt hele treet, ikke bare selve noden.
/// - `K` og `V`: Dette er typene nøkler og verdier som er lagret i nodene.
/// - `Type`: Dette kan være `Leaf`, `Internal` eller `LeafOrInternal`.
/// Når dette er `Leaf`, peker `NodeRef` til en bladnode, når dette er `Internal`, peker `NodeRef` mot en intern node, og når dette er `LeafOrInternal`, kan `NodeRef` peke på begge typer noder.
///   `Type` heter `NodeType` når den brukes utenfor `NodeRef`.
///
/// Både `BorrowType` og `NodeType` begrenser hvilke metoder vi implementerer for å utnytte sikkerhet for statisk type.Det er begrensninger i måten vi kan anvende slike begrensninger på:
/// - For hver type parameter kan vi bare definere en metode enten generisk eller for en bestemt type.
/// For eksempel kan vi ikke definere en metode som `into_kv` generisk for alle `BorrowType`, eller en gang for alle typer som har en levetid, fordi vi vil at den skal returnere `&'a`-referanser.
///   Derfor definerer vi det bare for den minst kraftige typen `Immut<'a>`.
/// - Vi kan ikke få implisitt tvang fra si `Mut<'a>` til `Immut<'a>`.
///   Derfor må vi eksplisitt kalle `reborrow` på en kraftigere `NodeRef` for å nå en metode som `into_kv`.
///
/// Alle metoder på `NodeRef` som returnerer en slags referanse, enten:
/// - Ta `self` etter verdi, og returner levetiden som bæres av `BorrowType`.
///   Noen ganger må vi ringe `reborrow_mut` for å påkalle en slik metode.
/// - Ta `self` som referanse, og (implicitly) returnerer referansens levetid, i stedet for levetiden som bæres av `BorrowType`.
/// På den måten garanterer lånekontrollen at `NodeRef` forblir lånt så lenge den returnerte referansen brukes.
///   Metodene som støtter innlegg bøyer denne regelen ved å returnere en rå peker, dvs. en referanse uten noen levetid.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Antall nivåer som noden og bladnivået er fra hverandre, en konstant av noden som ikke kan beskrives helt av `Type`, og som noden i seg selv ikke lagrer.
    /// Vi trenger bare å lagre høyden på rotnoden, og utlede høyden på alle andre noder.
    /// Må være null hvis `Type` er `Leaf` og ikke-null hvis `Type` er `Internal`.
    ///
    ///
    height: usize,
    /// Pekeren til bladet eller den interne noden.
    /// Definisjonen av `InternalNode` sikrer at pekeren er gyldig på begge måter.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Pakk ut en nodereferanse som var pakket som `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Eksponerer dataene til en intern node.
    ///
    /// Returnerer en rå ptr for å unngå å ugyldiggjøre andre referanser til denne noden.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SIKKERHET: den statiske nodetypen er `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Låner eksklusiv tilgang til dataene til en intern node.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Finner lengden på noden.Dette er antall nøkler eller verdier.
    /// Antall kanter er `len() + 1`.
    /// Merk at til tross for at det er trygt, kan det å ringe til denne funksjonen ha den bivirkningen at ugyldige referanser som usikker kode har opprettet, ugyldiggjøres.
    ///
    pub fn len(&self) -> usize {
        // Avgjørende er at vi bare får tilgang til `len`-feltet her.
        // Hvis BorrowType er marker::ValMut, kan det være utestående mutable referanser til verdier som vi ikke må ugyldiggjøre.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Returnerer antall nivåer som noden og bladene er fra hverandre.
    /// Null høyde betyr at noden er et blad i seg selv.
    /// Hvis du ser på trær med roten på toppen, sier tallet i hvilken høyde noden vises.
    /// Hvis du ser på trær med blader på toppen, sier tallet hvor høyt treet strekker seg over noden.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Tar midlertidig ut en annen, uforanderlig referanse til samme node.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Eksponerer bladdelen av et hvilket som helst blad eller intern node.
    ///
    /// Returnerer en rå ptr for å unngå å ugyldiggjøre andre referanser til denne noden.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Noden må være gyldig i minst LeafNode-delen.
        // Dette er ikke en referanse i NodeRef-typen fordi vi ikke vet om den skal være unik eller delt.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Finner foreldrene til den nåværende noden.
    /// Returnerer `Ok(handle)` hvis den nåværende noden faktisk har en overordnet, der `handle` peker mot edge til den overordnede som peker til den nåværende noden.
    ///
    /// Returnerer `Err(self)` hvis den nåværende noden ikke har noen foreldre, og gir tilbake den originale `NodeRef`.
    ///
    /// Metodenavnet forutsetter at du ser på trær med rotnoden på toppen.
    ///
    /// `edge.descend().ascend().unwrap()` og `node.ascend().unwrap().descend()` skal begge, etter suksess, ikke gjøre noe.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Vi må bruke rå pekere til noder, fordi hvis BorrowType er marker::ValMut, kan det være utestående foranderlige referanser til verdier som vi ikke må ugyldiggjøre.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Vær oppmerksom på at `self` må være ikke-fritt.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Vær oppmerksom på at `self` må være ikke-fritt.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Eksponerer bladdelen av et hvilket som helst blad eller intern knute i et uforanderlig tre.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SIKKERHET: det kan ikke finnes noen foranderlige referanser til dette treet lånt som `Immut`.
        unsafe { &*ptr }
    }

    /// Låner en visning til tastene som er lagret i noden.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// I likhet med `ascend`, får en referanse til en nodes overordnede node, men avtaler også den aktuelle noden i prosessen.
    /// Dette er usikkert fordi den nåværende noden fremdeles vil være tilgjengelig til tross for at den er distribuert.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Hevder usikker til kompilatoren den statiske informasjonen om at denne noden er en `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hevder usikker til kompilatoren den statiske informasjonen om at denne noden er en `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Tar midlertidig ut en annen, foranderlig referanse til samme node.Vær oppmerksom, siden denne metoden er veldig farlig, dobbelt så siden den kanskje ikke umiddelbart virker farlig.
    ///
    /// Fordi foranderlige pekere kan streife rundt hvor som helst rundt treet, kan den returnerte pekeren enkelt brukes til å gjøre den opprinnelige pekeren dinglende, utenfor grensene eller ugyldig under stablede låneregler.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) vurdere å legge til enda en type parameter til `NodeRef` som begrenser bruken av navigasjonsmetoder på punktere som er gjenlånt, og forhindrer denne usikkerheten.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Låner eksklusiv tilgang til bladdelen av et hvilket som helst blad eller intern node.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SIKKERHET: vi har eksklusiv tilgang til hele noden.
        unsafe { &mut *ptr }
    }

    /// Tilbyr eksklusiv tilgang til bladdelen av et hvilket som helst blad eller intern node.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SIKKERHET: vi har eksklusiv tilgang til hele noden.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Låner eksklusiv tilgang til et element i nøkkeloppbevaringsområdet.
    ///
    /// # Safety
    /// `index` er i grensene til 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SIKKERHET: innringeren vil ikke kunne ringe videre metoder på egenhånd
        // helt til referansen til nøkkelstykket slippes, ettersom vi har unik tilgang i løpet av lånet.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Låner eksklusiv tilgang til et element eller et stykke av nodens verdilagringsområde.
    ///
    /// # Safety
    /// `index` er i grensene til 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SIKKERHET: innringeren vil ikke kunne ringe videre metoder på egenhånd
        // inntil referansen til verdiskiven faller, ettersom vi har unik tilgang for lånets levetid.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Låner eksklusiv tilgang til et element eller et stykke av nodens lagringsområde for edge-innhold.
    ///
    /// # Safety
    /// `index` er i grensene til 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SIKKERHET: innringeren vil ikke kunne ringe videre metoder på egenhånd
        // til edge-skivereferansen blir droppet, ettersom vi har unik tilgang for lånets levetid.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Noden har mer enn `idx` initialiserte elementer.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Vi oppretter bare en referanse til det ene elementet vi er interessert i, for å unngå å kalle enestående referanser til andre elementer, spesielt de som returneres til innringeren i tidligere iterasjoner.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Vi må tvinge til usorterte matrisepekere på grunn av Rust-utgaven #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Låner eksklusiv tilgang til lengden på noden.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Angir koblingen til noden til den overordnede edge, uten å ugyldiggjøre andre referanser til noden.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Fjerner koblingen til roten til foreldrene edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Legger til et nøkkelverdipar til slutten av noden.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Hvert element som returneres av `range` er en gyldig edge-indeks for noden.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Legger til et nøkkelverdipar og en edge for å gå til høyre for det paret, til slutten av noden.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Sjekker om en node er en `Internal`-node eller en `Leaf`-node.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// En referanse til et spesifikt nøkkelverdipar eller edge i en node.
/// `Node`-parameteren må være en `NodeRef`, mens `Type` enten kan være `KV` (som betyr et håndtak på et nøkkelverdipar) eller `Edge` (som betyr et håndtak på en edge).
///
/// Merk at til og med `Leaf`-noder kan ha `Edge`-håndtak.
/// I stedet for å representere en peker til en undernode, representerer disse mellomrommene der barnepekere vil gå mellom nøkkelverdiparene.
/// For eksempel, i en node med lengde 2, ville det være 3 mulige edge-steder, en til venstre for noden, en mellom de to parene og en til høyre for noden.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Vi trenger ikke den fulle generalen av `#[derive(Clone)]`, da den eneste gangen `Node` vil være "klonbar" er når det er en uforanderlig referanse og derfor `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Henter noden som inneholder edge eller nøkkelverdiparet dette håndtaket peker på.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Returnerer posisjonen til dette håndtaket i noden.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Oppretter et nytt håndtak til et nøkkelverdipar i `node`.
    /// Usikre fordi innringeren må sørge for at `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Kan være en offentlig implementering av PartialEq, men bare brukt i denne modulen.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tar midlertidig ut et annet, uforanderlig håndtak på samme sted.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Vi kan ikke bruke Handle::new_kv eller Handle::new_edge fordi vi ikke kjenner typen vår
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Hevder usikkert til kompilatoren den statiske informasjonen om at håndtakets node er en `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Tar midlertidig ut et annet, foranderlig håndtak på samme sted.
    /// Vær oppmerksom, siden denne metoden er veldig farlig, dobbelt så siden den kanskje ikke umiddelbart virker farlig.
    ///
    ///
    /// For detaljer, se `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Vi kan ikke bruke Handle::new_kv eller Handle::new_edge fordi vi ikke kjenner typen vår
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Oppretter et nytt håndtak til en edge i `node`.
    /// Usikre fordi innringeren må sørge for at `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Gitt en edge-indeks der vi ønsker å sette inn i en node fylt til kapasitet, beregner en fornuftig KV-indeks av et splittepunkt og hvor vi skal utføre innsettingen.
///
/// Målet med delingspunktet er at nøkkelen og verdien havner i en foreldrenode.
/// nøklene, verdiene og kantene til venstre for splittpunktet blir det venstre barnet;
/// nøklene, verdiene og kantene til høyre for splittpunktet blir det rette barnet.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust utgave #74834 prøver å forklare disse symmetriske reglene.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Setter inn et nytt nøkkelverdipar mellom nøkkelverdiparene til høyre og venstre for denne edge.
    /// Denne metoden forutsetter at det er nok plass i noden til at det nye paret kan passe.
    ///
    /// Den returnerte pekeren peker på den innsatte verdien.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Setter inn et nytt nøkkelverdipar mellom nøkkelverdiparene til høyre og venstre for denne edge.
    /// Denne metoden deler noden hvis det ikke er nok plass.
    ///
    /// Den returnerte pekeren peker på den innsatte verdien.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fikser foreldrepekeren og indeksen i den underordnede noden som denne edge lenker til.
    /// Dette er nyttig når rekkefølgen på kanter er endret,
    fn correct_parent_link(self) {
        // Opprett backpointer uten å ugyldiggjøre andre referanser til noden.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Setter inn et nytt nøkkelverdipar og et edge som vil gå til høyre for det nye paret mellom dette edge og nøkkelverdiparet til høyre for denne edge.
    /// Denne metoden forutsetter at det er nok plass i noden til at det nye paret kan passe.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Setter inn et nytt nøkkelverdipar og et edge som vil gå til høyre for det nye paret mellom dette edge og nøkkelverdiparet til høyre for denne edge.
    /// Denne metoden deler noden hvis det ikke er nok plass.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Setter inn et nytt nøkkelverdipar mellom nøkkelverdiparene til høyre og venstre for denne edge.
    /// Denne metoden deler noden hvis det ikke er nok plass, og prøver å sette den delte delen inn i foreldrenoden rekursivt, til roten er nådd.
    ///
    ///
    /// Hvis det returnerte resultatet er en `Fit`, kan håndtakets node være denne edge-noden eller en forfader.
    /// Hvis det returnerte resultatet er en `Split`, vil `left`-feltet være rotnoden.
    /// Den returnerte pekeren peker på den innsatte verdien.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Finner noden som denne edge peker på.
    ///
    /// Metodenavnet forutsetter at du ser på trær med rotnoden på toppen.
    ///
    /// `edge.descend().ascend().unwrap()` og `node.ascend().unwrap().descend()` skal begge, etter suksess, ikke gjøre noe.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Vi må bruke rå pekere til noder, fordi hvis BorrowType er marker::ValMut, kan det være utestående foranderlige referanser til verdier som vi ikke må ugyldiggjøre.
        // Det er ingen grunn til å få tilgang til høydefeltet fordi verdien blir kopiert.
        // Vær oppmerksom på at når nodepekeren er referert til, får vi tilgang til kanter matrisen med en referanse (Rust utgave #73987) og ugyldiggjør andre referanser til eller inne i matrisen, hvis det skulle være noen.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Vi kan ikke ringe separate nøkkel-og verdimetoder, fordi anrop til den andre ugyldiggjør referansen som returneres av den første.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Bytt ut nøkkelen og verdien som KV-håndtaket refererer til.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Hjelper implementeringer av `split` for en bestemt `NodeType`, ved å ta vare på bladdata.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Deler den underliggende noden i tre deler:
    ///
    /// - Noden er avkortet slik at den bare inneholder nøkkelverdiparene til venstre for dette håndtaket.
    /// - Nøkkelen og verdien som dette håndtaket peker på blir hentet ut.
    /// - Alle nøkkelverdiparene til høyre for dette håndtaket blir satt i en nylig tildelt node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Fjerner nøkkelverdiparet som dette håndtaket peker på, og returnerer det sammen med edge som nøkkelverdiparet falt sammen.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Deler den underliggende noden i tre deler:
    ///
    /// - Noden er avkortet slik at den bare inneholder kantene og nøkkelverdiparene til venstre for dette håndtaket.
    /// - Nøkkelen og verdien som dette håndtaket peker på blir hentet ut.
    /// - Alle kantene og nøkkelverdiparene til høyre for dette håndtaket blir satt i en nylig tildelt node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Representerer en økt for evaluering og utføring av en balanseringsoperasjon rundt et internt nøkkelverdipar.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Velger en balanserende kontekst som involverer noden som barn, og dermed mellom KV umiddelbart til venstre eller til høyre i foreldrenoden.
    /// Returnerer en `Err` hvis det ikke er noen forelder.
    /// Panics hvis foreldrene er tomme.
    ///
    /// Foretrekker venstre side for å være optimal hvis den gitte noden på en eller annen måte er underfull, noe som bare betyr her at den har færre elementer enn sitt venstre søsken og enn det høyre søskenbarnet, hvis de eksisterer.
    /// I så fall går det raskere å slå seg sammen med venstre søsken, siden vi bare trenger å flytte nodens N-elementer, i stedet for å forskyve dem til høyre og bevege mer enn N-elementer foran.
    /// Å stjele fra det venstre søsken er også vanligvis raskere, siden vi bare trenger å forskyve nodens N-elementer til høyre, i stedet for å forskyve minst N av søskenens elementer til venstre.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Returnerer om sammenslåing er mulig, dvs. om det er nok plass i en node til å kombinere den sentrale KV med begge tilstøtende underordnede noder.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Utfører en sammenslåing og lar en avslutning bestemme hva som skal returneres.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SIKKERHET: høyden på nodene som slås sammen er under høyden
                // av noden til denne edge, altså over null, så de er interne.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Slår sammen foreldrenes nøkkelverdipar og begge tilstøtende underordnede noder i venstre undernode og returnerer den krympet overordnede noden.
    ///
    ///
    /// Panics med mindre vi `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Slår sammen foreldrenes nøkkelverdipar og begge tilstøtende underordnede noder i venstre undernode og returnerer den underordnede noden.
    ///
    ///
    /// Panics med mindre vi `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Slår sammen foreldrenes nøkkelverdipar og begge tilstøtende underordnede noder i venstre barneknute og returnerer edge-håndtaket i den underordnede noden der sporet barn edge havnet,
    ///
    ///
    /// Panics med mindre vi `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Fjerner et nøkkelverdipar fra venstre barn og plasserer det i nøkkelverdilagringen til foreldrene, mens du skyver det gamle foreldrenøkkelverdiparet inn i det rette barnet.
    ///
    /// Returnerer et håndtak til edge i høyre barn som tilsvarer der originalen edge spesifisert av `track_right_edge_idx` havnet.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Fjerner et nøkkelverdipar fra høyre barn og plasserer det i nøkkelverdilagringen til foreldrene, mens du skyver det gamle foreldrenøkkelverdiparet på det venstre barnet.
    ///
    /// Returnerer et håndtak til edge i det venstre barnet spesifisert av `track_left_edge_idx`, som ikke beveget seg.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Dette stjeler lik `steal_left`, men stjeler flere elementer på en gang.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Forsikre deg om at vi kan stjele trygt.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Flytt bladdata.
            {
                // Gi plass til stjålne elementer i riktig barn.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Flytt elementer fra venstre barn til høyre.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Flytt paret som er stjålet til venstre mest til foreldrene.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Flytt foreldrenes nøkkelverdipar til riktig barn.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Gi plass til stjålne kanter.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Stjær kanter.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Den symmetriske klonen til `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Forsikre deg om at vi kan stjele trygt.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Flytt bladdata.
            {
                // Flytt det mest stjålne paret til foreldrene.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Flytt foreldrenes nøkkelverdipar til venstre barn.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Flytt elementer fra høyre barn til venstre.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Fyll hullet der stjålne elementer pleide å være.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Stjær kanter.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Fyll hullet der stjålne kanter pleide å være.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Fjerner statisk informasjon som hevder at denne noden er en `Leaf`-node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Fjerner all statisk informasjon som hevder at denne noden er en `Internal`-node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Sjekker om den underliggende noden er en `Internal`-node eller en `Leaf`-node.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Flytt suffikset etter `self` fra en node til en annen.`right` må være tom.
    /// Den første edge av `right` forblir uendret.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultat av innsetting, når en node trengte å utvide seg utover kapasiteten.
pub struct SplitResult<'a, K, V, NodeType> {
    // Endret node i eksisterende tre med elementer og kanter som hører til venstre for `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Noen nøkkel og verdi splittes av for å settes inn andre steder.
    pub kv: (K, V),
    // Eid, uvedlagt, ny node med elementer og kanter som hører til høyre for `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Om nodhenvisninger av denne låntypen tillater kryssing til andre noder i treet.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Gjennomgang er ikke nødvendig, det skjer ved å bruke resultatet av `borrow_mut`.
        // Ved å deaktivere traversal, og bare opprette nye referanser til røtter, vet vi at hver referanse av `Owned`-typen er til en rotnode.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Setter inn en verdi i et stykke initialiserte elementer etterfulgt av ett ikke-initialisert element.
///
/// # Safety
/// Skiven har mer enn `idx`-elementer.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Fjerner og returnerer en verdi fra en del av alle initialiserte elementer, og etterlater ett etterfølgende ikke-initialisert element.
///
///
/// # Safety
/// Skiven har mer enn `idx`-elementer.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Flytter elementene i et stykke `distance`-posisjoner til venstre.
///
/// # Safety
/// Stykket har minst `distance`-elementer.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Flytter elementene i et stykke `distance`-posisjoner til høyre.
///
/// # Safety
/// Stykket har minst `distance`-elementer.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Flytter alle verdier fra et stykke initialiserte elementer til et stykke ikke-initialiserte elementer, og etterlater `src` som alle ikke-initialiserte.
///
/// Fungerer som `dst.copy_from_slice(src)`, men krever ikke at `T` er `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;