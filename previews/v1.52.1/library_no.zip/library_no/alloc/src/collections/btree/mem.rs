use core::intrinsics;
use core::mem;
use core::ptr;

/// Dette erstatter verdien bak den unike `v`-referansen ved å ringe til den aktuelle funksjonen.
///
///
/// Hvis en panic oppstår i `change`-nedleggelsen, avbrytes hele prosessen.
#[allow(dead_code)] // oppbevares som illustrasjon og for bruk av future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Dette erstatter verdien bak den unike `v`-referansen ved å ringe til den aktuelle funksjonen, og returnerer et resultat oppnådd underveis.
///
///
/// Hvis en panic oppstår i `change`-nedleggelsen, avbrytes hele prosessen.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}