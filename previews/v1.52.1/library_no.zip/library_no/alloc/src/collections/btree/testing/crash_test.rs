use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// En plan for kollisjonstestdummy-forekomster som overvåker bestemte hendelser.
/// Noen forekomster kan konfigureres til panic på et eller annet tidspunkt.
/// Hendelser er `clone`, `drop` eller en anonym `query`.
///
/// Crash test dummies identifiseres og ordnes av en id, slik at de kan brukes som nøkler i et BTreeMap.
/// Implementeringen bruker bevisst ikke på noe som er definert i crate, bortsett fra `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Skaper en kollisjonstestdummy-design.`id` bestemmer rekkefølge og likhet mellom forekomster.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Oppretter en forekomst av en kollisjonstestdummy som registrerer hvilke hendelser den opplever og eventuelt panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Returnerer hvor mange ganger forekomster av dummy har blitt klonet.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Returnerer hvor mange ganger forekomster av dummy har blitt droppet.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Returnerer hvor mange ganger forekomster av dummy har fått sitt `query`-medlem påkalt.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Noen anonyme spørsmål, hvis resultat allerede er gitt.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}