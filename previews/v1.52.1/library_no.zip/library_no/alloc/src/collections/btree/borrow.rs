use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modellerer en gjenoppliving av en unik referanse når du vet at gjenopplivningen og alle dens etterkommere (dvs. alle pekere og referanser avledet fra den) ikke vil bli brukt lenger på et tidspunkt, hvorpå du vil bruke den originale unike referansen igjen .
///
///
/// Lånekontrollen håndterer vanligvis denne stablingen av lån for deg, men noen kontrollflyter som oppnår denne stablingen er for kompliserte til at kompilatoren kan følge.
/// En `DormantMutRef` lar deg sjekke utlån selv, mens du fremdeles uttrykker sin stablede natur, og innkapsler råpekekoden som trengs for å gjøre dette uten udefinert oppførsel.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Ta et unikt lån, og lån det umiddelbart igjen.
    /// For kompilatoren er levetiden til den nye referansen den samme som levetiden til den opprinnelige referansen, men du promise for å bruke den i en kortere periode.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SIKKERHET: vi holder lånet gjennom 'a via `_marker`, og vi avslører
        // bare denne referansen, så den er unik.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Gå tilbake til det unike lånet som ble tatt i utgangspunktet.
    ///
    /// # Safety
    ///
    /// Gjenopplæringen må ha avsluttet, dvs. referansen returnert av `new` og alle pekere og referanser fra den, kan ikke brukes lenger.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SIKKERHET: Våre egne sikkerhetsforhold innebærer at denne referansen igjen er unik.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;