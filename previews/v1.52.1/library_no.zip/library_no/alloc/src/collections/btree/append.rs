use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Legger til alle nøkkelverdipar fra foreningen av to stigende iteratorer, og øker en `length`-variabel underveis.Sistnevnte gjør det lettere for den som ringer å unngå en lekkasje når en fallhåndterer får panikk.
    ///
    /// Hvis begge iteratorene produserer samme nøkkel, slipper denne metoden paret fra venstre iterator og legger paret fra høyre iterator.
    ///
    /// Hvis du vil at treet skal havne i en streng stigende rekkefølge, som for en `BTreeMap`, bør begge iteratorene produsere nøkler i strengt stigende rekkefølge, hver større enn alle nøklene i treet, inkludert eventuelle nøkler som allerede er i treet ved oppføring.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Vi forbereder oss på å slå sammen `left` og `right` til en sortert sekvens i lineær tid.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // I mellomtiden bygger vi et tre fra den sorterte sekvensen i lineær tid.
        self.bulk_push(iter, length)
    }

    /// Skyver alle nøkkelverdipar til enden av treet, og øker en `length`-variabel underveis.
    /// Sistnevnte gjør det lettere for den som ringer å unngå lekkasje når iteratoren får panikk.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterer gjennom alle nøkkelverdipar og skyver dem inn i noder på riktig nivå.
        for (key, value) in iter {
            // Prøv å skyve nøkkelverdipar inn i gjeldende bladnode.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ingen plass igjen, gå opp og skyv dit.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Fant en node med plass igjen, trykk her.
                                open_node = parent;
                                break;
                            } else {
                                // Gå opp igjen.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Vi er på toppen, lager en ny rotnode og skyver dit.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Trykk nøkkelverdipar og nytt høyre undertre.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Gå ned til høyre blad igjen.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Øk lengden for hver iterasjon for å sikre at kartet slipper de vedlagte elementene, selv om iteratoren rykker ut.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// En iterator for å slå sammen to sorterte sekvenser til en
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Hvis to taster er like, returnerer nøkkelverdiparet fra riktig kilde.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}