//! Referanser som teller enkelt tråder.'Rc' står for 'Reference
//! Counted'.
//!
//! Typen [`Rc<T>`][`Rc`] gir delt eierskap av en verdi av typen `T`, tildelt i bunken.
//! Å påkalle [`clone`][clone] på [`Rc`] produserer en ny peker til samme tildeling i bunken.
//! Når den siste [`Rc`]-pekeren til en gitt tildeling blir ødelagt, faller også verdien som er lagret i den tildelingen (ofte referert til som "inner value").
//!
//! Delte referanser i Rust tillater ikke mutasjon som standard, og [`Rc`] er ikke noe unntak: du kan vanligvis ikke få en mutbar referanse til noe i en [`Rc`].
//! Hvis du trenger mutabilitet, setter du en [`Cell`] eller [`RefCell`] i [`Rc`];se [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] bruker ikke-atomreferansetelling.
//! Dette betyr at overhead er veldig lavt, men en [`Rc`] kan ikke sendes mellom tråder, og følgelig implementerer [`Rc`] ikke [`Send`][send].
//! Som et resultat vil Rust-kompilatoren sjekke *ved kompileringstid* at du ikke sender [`Rc`] mellom tråder.
//! Hvis du trenger teller med flere tråder, atomreferanser, bruk [`sync::Arc`][arc].
//!
//! [`downgrade`][downgrade]-metoden kan brukes til å lage en ikke-eier [`Weak`]-peker.
//! En [`Weak`]-peker kan være ["oppgradering"][oppgradering] d til en [`Rc`], men denne vil returnere [`None`] hvis verdien som er lagret i tildelingen allerede er falt.
//! Med andre ord holder ikke `Weak`-pekere levende i tildelingen;imidlertid *holder de* tildelingen (backingbutikken for den indre verdien) levende.
//!
//! En syklus mellom [`Rc`]-pekere vil aldri bli fordelt.
//! Av denne grunn brukes [`Weak`] til å bryte sykluser.
//! For eksempel kan et tre ha sterke [`Rc`]-pekere fra foreldrenoder til barn, og [`Weak`]-pekere fra barn tilbake til foreldrene.
//!
//! `Rc<T>` automatisk referanser til `T` (via [`Deref`] trait), slik at du kan ringe `T`s metoder på en verdi av typen [`Rc<T>`][`Rc`].
//! For å unngå navnekollisjon med `T`-metodene, er metodene til [`Rc<T>`][`Rc`] i seg selv tilknyttede funksjoner, kalt ved bruk av [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>implementeringer av traits som `Clone` kan også kalles ved bruk av fullstendig syntaks.
//! Noen foretrekker å bruke fullt kvalifisert syntaks, mens andre foretrekker å bruke metodesamtalsyntaks.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Metodesamtalsyntaks
//! let rc2 = rc.clone();
//! // Fullt kvalifisert syntaks
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] gjør ikke autodereferanse til `T`, fordi den indre verdien allerede kan ha blitt tapt.
//!
//! # Kloningsreferanser
//!
//! Å lage en ny referanse til den samme tildelingen som en eksisterende referanseteltet peker gjøres ved hjelp av `Clone` trait implementert for [`Rc<T>`][`Rc`] og [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // De to syntaksen nedenfor er ekvivalente.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a og b peker begge på samme minneplassering som foo.
//! ```
//!
//! `Rc::clone(&from)`-syntaksen er den mest idiomatiske fordi den gir mer eksplisitt betydningen av koden.
//! I eksemplet ovenfor gjør denne syntaksen det lettere å se at denne koden skaper en ny referanse i stedet for å kopiere hele innholdet i foo.
//!
//! # Examples
//!
//! Tenk på et scenario der et sett med gadgets eies av en gitt `Owner`.
//! Vi ønsker å ha vår "Gadget" til `Owner`.Vi kan ikke gjøre dette med unikt eierskap, fordi mer enn en enhet kan tilhøre samme `Owner`.
//! [`Rc`] tillater oss å dele en `Owner` mellom flere `Gadget`er, og få `Owner` forbli tildelt så lenge noen `Gadget`-poeng på den.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... andre felt
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... andre felt
//! }
//!
//! fn main() {
//!     // Lag en referansetelling `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Lag "Gadget" som tilhører `gadget_owner`.
//!     // Kloning av `Rc<Owner>` gir oss en ny peker til samme `Owner`-tildeling, og øker referansetellingen i prosessen.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Kast vår lokale variabel `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Til tross for at vi slipper `gadget_owner`, kan vi fremdeles skrive ut navnet på `Owner` på gadgeten.
//!     // Dette er fordi vi bare har droppet en enkelt `Rc<Owner>`, ikke `Owner` den peker på.
//!     // Så lenge det er andre `Rc<Owner>` som peker på samme `Owner`-tildeling, vil den forbli live.
//!     // Feltprojeksjonen `gadget1.owner.name` fungerer fordi `Rc<Owner>` automatisk henviser til `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // På slutten av funksjonen blir `gadget1` og `gadget2` ødelagt, og med dem de siste tellede referansene til vår `Owner`.
//!     // Gadget Man blir nå også ødelagt.
//!     //
//! }
//! ```
//!
//! Hvis kravene våre endres, og vi også trenger å være i stand til å krysse fra `Owner` til `Gadget`, vil vi støte på problemer.
//! En [`Rc`]-peker fra `Owner` til `Gadget` introduserer en syklus.
//! Dette betyr at referansetallene deres aldri kan nå 0, og tildelingen vil aldri bli ødelagt:
//! en minnelekkasje.For å komme oss rundt dette kan vi bruke [`Weak`]-pekere.
//!
//! Rust gjør det faktisk vanskelig å produsere denne løkken i utgangspunktet.For å ende opp med to verdier som peker mot hverandre, må en av dem være foranderlig.
//! Dette er vanskelig fordi [`Rc`] håndhever minnesikkerheten ved bare å gi ut delte referanser til verdien den pakker inn, og disse tillater ikke direkte mutasjon.
//! Vi må pakke inn den delen av verdien vi ønsker å mutere i en [`RefCell`], som gir *indre mutabilitet*: en metode for å oppnå mutabilitet gjennom en delt referanse.
//! [`RefCell`] håndhever Rust s låneregler ved kjøretid.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... andre felt
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... andre felt
//! }
//!
//! fn main() {
//!     // Lag en referansetelling `Owner`.
//!     // Merk at vi har plassert `Eierens vector av` Gadget`s inne i en `RefCell` slik at vi kan mutere den gjennom en delt referanse.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Lag "Gadget" som tilhører `gadget_owner`, som før.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Legg til gadgetene til `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dynamisk lån slutter her.
//!     }
//!
//!     // Iterer over "Gadget"-ene våre, og skriver ut detaljene deres.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` er en `Weak<Gadget>`.
//!         // Siden `Weak`-pekere ikke kan garantere at tildelingen fortsatt eksisterer, må vi ringe `upgrade`, som returnerer en `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // I dette tilfellet vet vi at tildelingen fortsatt eksisterer, så vi `unwrap` `Option`.
//!         // I et mer komplisert program trenger du kanskje grasiøs feilbehandling for et `None`-resultat.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // På slutten av funksjonen blir `gadget_owner`, `gadget1` og `gadget2` ødelagt.
//!     // Det er nå ingen sterke (`Rc`)-pekere til gadgetene, så de blir ødelagt.
//!     // Dette nullstiller referansetellingen på Gadget Man, så han blir også ødelagt.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Dette er repr(C) til future-bevis mot mulig feltbestilling, noe som vil forstyrre ellers sikker [into|from]_raw() av transmuterbare indre typer.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// En referansetellingspeker med en tråd.'Rc' står for 'Reference
/// Counted'.
///
/// Se [module-level documentation](./index.html) for mer informasjon.
///
/// De iboende metodene til `Rc` er alle tilknyttede funksjoner, noe som betyr at du må kalle dem som f.eks. [`Rc::get_mut(&mut value)`][get_mut] i stedet for `value.get_mut()`.
/// Dette unngår konflikter med metoder av den indre typen `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Denne usikkerheten er ok, for mens denne Rc er i live er vi garantert at den indre pekeren er gyldig.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konstruerer en ny `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Det er en implisitt svak peker som eies av alle de sterke pekerne, noe som sikrer at den svake destruktøren aldri frigjør tildelingen mens den sterke destruktøren kjører, selv om den svake pekeren er lagret inne i den sterke.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konstruerer en ny `Rc<T>` ved å bruke en svak referanse til seg selv.
    /// Forsøk på å oppgradere den svake referansen før denne funksjonen returnerer, vil resultere i en `None`-verdi.
    ///
    /// Imidlertid kan den svake referansen klones fritt og lagres for bruk på et senere tidspunkt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... flere felt
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Konstruer det indre i "uninitialized"-tilstand med en enkelt svak referanse.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Det er viktig at vi ikke gir opp eierskapet til den svake pekeren, ellers kan minnet bli frigjort når `data_fn` kommer tilbake.
        // Hvis vi virkelig ønsket å passere eierskap, kunne vi lage en ekstra svak peker for oss selv, men dette vil resultere i ytterligere oppdateringer av det svake referansetallet som ellers ikke er nødvendig.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Sterke referanser bør samlet ha en delt svak referanse, så ikke kjør ødeleggeren for vår gamle svake referanse.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruerer en ny `Rc` med ikke-initialisert innhold.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Utsatt initialisering:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerer en ny `Rc` med ikke-initialisert innhold, hvor minnet fylles med `0` byte.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] for eksempler på riktig og feil bruk av denne metoden.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerer en ny `Rc<T>` og returnerer en feil hvis tildelingen mislykkes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Det er en implisitt svak peker som eies av alle de sterke pekerne, noe som sikrer at den svake destruktøren aldri frigjør tildelingen mens den sterke destruktøren kjører, selv om den svake pekeren er lagret inne i den sterke.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Konstruerer en ny `Rc` med ikke-initialisert innhold, og returnerer en feil hvis tildelingen mislykkes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Utsatt initialisering:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruerer en ny `Rc` med ikke-initialisert innhold, hvor minnet fylles med `0` byte, og returnerer en feil hvis tildelingen mislykkes
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] for eksempler på riktig og feil bruk av denne metoden.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konstruerer en ny `Pin<Rc<T>>`.
    /// Hvis `T` ikke implementerer `Unpin`, blir `value` festet i minnet og kan ikke flyttes.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Returnerer den indre verdien hvis `Rc` har nøyaktig en sterk referanse.
    ///
    /// Ellers returneres en [`Err`] med samme `Rc` som ble sendt inn.
    ///
    ///
    /// Dette vil lykkes selv om det er fremragende svake referanser.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopier det inneholdte objektet

                // Angi for Weaks at de ikke kan fremmes ved å redusere den sterke tellingen, og fjern deretter den implisitte "strong weak"-pekeren mens du også håndterer droplogikk ved å lage en falsk svak.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Konstruerer et nytt referansetelt stykke med ikke-initialisert innhold.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Utsatt initialisering:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Konstruerer et nytt referansetelt stykke med ikke-initialisert innhold, med minnet fylt med `0` byte.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] for eksempler på riktig og feil bruk av denne metoden.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Konverterer til `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`], er det opp til innringeren å garantere at den indre verdien virkelig er i en initialisert tilstand.
    ///
    /// Å kalle dette når innholdet ennå ikke er fullstendig initialisert, forårsaker umiddelbar udefinert oppførsel.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Utsatt initialisering:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Konverterer til `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`], er det opp til innringeren å garantere at den indre verdien virkelig er i en initialisert tilstand.
    ///
    /// Å kalle dette når innholdet ennå ikke er fullstendig initialisert, forårsaker umiddelbar udefinert oppførsel.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Utsatt initialisering:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Forbruker `Rc` og returnerer den innpakkede pekeren.
    ///
    /// For å unngå minnelekkasje må pekeren konverteres tilbake til en `Rc` ved hjelp av [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Gir en rå peker til dataene.
    ///
    /// Tellerne påvirkes ikke på noen måte, og `Rc` forbrukes ikke.
    /// Pekeren er gyldig så lenge det er sterke tellinger i `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SIKKERHET: Dette kan ikke gå gjennom Deref::deref eller Rc::inner fordi
        // dette kreves for å beholde raw/mut herkomst slik at f.eks
        // `get_mut` kan skrive gjennom pekeren etter at Rc er gjenopprettet gjennom `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Konstruerer en `Rc<T>` fra en rå peker.
    ///
    /// Råpekeren må ha blitt returnert tidligere av en samtale til [`Rc<U>::into_raw`][into_raw] der `U` må ha samme størrelse og justering som `T`.
    /// Dette er trivielt sant hvis `U` er `T`.
    /// Merk at hvis `U` ikke er `T`, men har samme størrelse og justering, er dette i utgangspunktet som å transmittere referanser av forskjellige typer.
    /// Se [`mem::transmute`][transmute] for mer informasjon om hvilke begrensninger som gjelder i dette tilfellet.
    ///
    /// Brukeren av `from_raw` må sørge for at en spesifikk verdi på `T` bare slippes en gang.
    ///
    /// Denne funksjonen er usikker fordi feil bruk kan føre til usikkerhet i minnet, selv om den returnerte `Rc<T>` aldri er tilgjengelig.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konverter tilbake til en `Rc` for å forhindre lekkasje.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ytterligere anrop til `Rc::from_raw(x_ptr)` vil være minne-utrygt.
    /// }
    ///
    /// // Minnet ble frigjort da `x` gikk utenfor omfanget ovenfor, så `x_ptr` dingler nå!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Snu forskyvningen for å finne den originale RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Oppretter en ny [`Weak`]-peker til denne tildelingen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Forsikre deg om at vi ikke lager en dinglende svak
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Får antall [`Weak`]-pekere til denne tildelingen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Får antall sterke (`Rc`)-pekere til denne tildelingen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Returnerer `true` hvis det ikke er noen andre `Rc`-eller [`Weak`]-pekere til denne tildelingen.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Returnerer en mutbar referanse til den gitte `Rc`, hvis det ikke er noen andre `Rc`-eller [`Weak`]-pekere til den samme tildelingen.
    ///
    ///
    /// Returnerer [`None`] ellers, fordi det ikke er trygt å mutere en delt verdi.
    ///
    /// Se også [`make_mut`][make_mut], som vil [`clone`][clone] den indre verdien når det er andre pekere.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Returnerer en foranderlig referanse til den gitte `Rc`, uten noen kontroll.
    ///
    /// Se også [`get_mut`], som er trygt og foretar passende kontroller.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Andre `Rc`-eller [`Weak`]-pekere til den samme tildelingen må ikke refereres så lenge lånet returneres.
    ///
    /// Dette er trivielt tilfelle hvis det ikke finnes noen slike pekere, for eksempel umiddelbart etter `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Vi er forsiktige med å *ikke* lage en referanse som dekker "count"-feltene, da dette vil være i konflikt med tilgang til referansetellene (f.eks.
        // av `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Returnerer `true` hvis de to `Rc`ene peker på samme tildeling (i en vene som ligner på [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Gjør en foranderlig referanse til den gitte `Rc`.
    ///
    /// Hvis det er andre `Rc`-pekere til samme tildeling, vil `make_mut` [`clone`] den indre verdien til en ny tildeling for å sikre unikt eierskap.
    /// Dette blir også referert til som klon-på-skriv.
    ///
    /// Hvis det ikke er noen andre `Rc`-pekere til denne tildelingen, vil [`Weak`]-pekere til denne tildelingen skilles fra.
    ///
    /// Se også [`get_mut`], som vil mislykkes i stedet for kloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Vil ikke klone noe
    /// let mut other_data = Rc::clone(&data);    // Vil ikke klone indre data
    /// *Rc::make_mut(&mut data) += 1;        // Kloner indre data
    /// *Rc::make_mut(&mut data) += 1;        // Vil ikke klone noe
    /// *Rc::make_mut(&mut other_data) *= 2;  // Vil ikke klone noe
    ///
    /// // Nå peker `data` og `other_data` på forskjellige tildelinger.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] pekere blir frakoblet:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Må klone dataene, det er andre RC-er.
            // Forhåndsallokere minne slik at du kan skrive den klonede verdien direkte.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Kan bare stjele dataene, alt som er igjen er Svake
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Fjern implisitt sterk-svak ref (ingen grunn til å lage en falsk svak her-vi vet at andre svakheter kan rydde opp for oss)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Denne usikkerheten er ok fordi vi er garantert at pekeren som returneres er den *eneste* pekeren som noen gang vil bli returnert til T.
        // Referansetallet vårt er garantert 1 på dette tidspunktet, og vi krevde at selve `Rc<T>` var `mut`, så vi returnerer den eneste mulige referansen til tildelingen.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Forsøk å nedstøte `Rc<dyn Any>` til en konkret type.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Tildeler en `RcBox<T>` med tilstrekkelig plass til en mulig ikke-størrelse indre verdi der verdien har oppsettet.
    ///
    /// Funksjonen `mem_to_rcbox` kalles med datapekeren og må returnere en (potensielt fett)-peker for `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Beregn layout med den gitte verdilayouten.
        // Tidligere ble layout beregnet på uttrykket `&*(ptr as* const RcBox<T>)`, men dette skapte en feiljustert referanse (se #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Tildel en `RcBox<T>` med tilstrekkelig plass til en muligens ikke-størrelse indre verdi der verdien har oppsettet, og returnerer en feil hvis tildelingen mislykkes.
    ///
    ///
    /// Funksjonen `mem_to_rcbox` kalles med datapekeren og må returnere en (potensielt fett)-peker for `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Beregn layout med den gitte verdilayouten.
        // Tidligere ble layout beregnet på uttrykket `&*(ptr as* const RcBox<T>)`, men dette skapte en feiljustert referanse (se #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Tildel til oppsettet.
        let ptr = allocate(layout)?;

        // Initialiser RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Tildeler en `RcBox<T>` med tilstrekkelig plass til en ikke-størrelse indre verdi
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Tildel til `RcBox<T>` med den gitte verdien.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopier verdien som byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Gratis tildelingen uten å slippe innholdet
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Tildeler en `RcBox<[T]>` med gitt lengde.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopier elementer fra stykket til nylig tildelt Rc <\[T\]>
    ///
    /// Usikkert fordi den som ringer må enten ta eierskap eller binde `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Konstruerer en `Rc<[T]>` fra en iterator som er kjent for å være av en viss størrelse.
    ///
    /// Atferd er udefinert hvis størrelsen skulle være feil.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic vakt mens du kloner T-elementer.
        // I tilfelle panic vil elementer som er skrevet inn i den nye RcBox bli droppet, så frigjør minnet.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Peker til første element
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alt klart.Glem vakten slik at den ikke frigjør den nye RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spesialisering trait brukt til `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Dropper `Rc`.
    ///
    /// Dette vil redusere den sterke referansetellingen.
    /// Hvis det sterke referansetallet når null, er de eneste andre referansene (hvis noen) [`Weak`], så vi `drop` den indre verdien.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Skriver ikke ut noe
    /// drop(foo2);   // Skriver ut "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ødelegge gjenstanden som finnes
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // fjern den implisitte "strong weak"-pekeren nå som vi har ødelagt innholdet.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Gjør en klon av `Rc`-pekeren.
    ///
    /// Dette skaper en annen peker til samme tildeling, og øker den sterke referansen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Oppretter en ny `Rc<T>`, med `Default`-verdien for `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack for å tillate spesialisering på `Eq` selv om `Eq` har en metode.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Vi gjør denne spesialiseringen her, og ikke som en mer generell optimalisering på `&T`, fordi det ellers ville lagt til en kostnad for alle likhetskontroller på ref.
/// Vi antar at `Rc`s brukes til å lagre store verdier, som er sakte å klone, men som også er tunge å sjekke for likeverd, noe som får denne kostnaden til å betale seg lettere.
///
/// Det er også mer sannsynlig å ha to `Rc`-kloner, som peker på samme verdi, enn to `&T`er.
///
/// Vi kan bare gjøre dette når `T: Eq` som `PartialEq` kan være bevisst irrefleksiv.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Likhet for to `Rc`er.
    ///
    /// To `Rc`er er like hvis deres indre verdier er like, selv om de er lagret i annen tildeling.
    ///
    /// Hvis `T` også implementerer `Eq` (antyder refleksivitet av likhet), er to `Rc`er som peker på samme tildeling alltid like.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ulikhet for to `Rc`er.
    ///
    /// To `Rc`er er ulik hvis deres indre verdier er ulik.
    ///
    /// Hvis `T` også implementerer `Eq` (antyder refleksivitet av likhet), er to `Rc`er som peker på samme tildeling aldri ulik.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Delvis sammenligning for to `Rc`er.
    ///
    /// De to sammenlignes ved å kalle `partial_cmp()` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mindre enn sammenligning for to `Rc`er.
    ///
    /// De to sammenlignes ved å kalle `<` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Mindre enn eller lik' sammenligning for to `Rc`er.
    ///
    /// De to sammenlignes ved å kalle `<=` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Større enn sammenligning for to `Rc`er.
    ///
    /// De to sammenlignes ved å kalle `>` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Større enn eller lik' sammenligning for to `Rc`er.
    ///
    /// De to sammenlignes ved å kalle `>=` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Sammenligning for to `Rc`er.
    ///
    /// De to sammenlignes ved å kalle `cmp()` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Tildel et referansetelt stykke og fyll det ved å klone ``v`s elementer.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Tildel en referansetelt strengskive og kopier `v` inn i den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Tildel en referansetelt strengskive og kopier `v` inn i den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Flytt et emne i boks til en ny, referansetelling, tildeling.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Tildel et referansetelt stykke og flytt `v`-elementene inn i det.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // La Vec frigjøre hukommelsen, men ikke ødelegge innholdet
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Tar hvert element i `Iterator` og samler det inn i en `Rc<[T]>`.
    ///
    /// # Ytelsesegenskaper
    ///
    /// ## Den generelle saken
    ///
    /// Generelt sett samles det i `Rc<[T]>` ved først å samle inn i en `Vec<T>`.Det vil si når du skriver følgende:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dette oppfører seg som om vi skrev:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Det første settet med tildelinger skjer her.
    ///     .into(); // En annen tildeling for `Rc<[T]>` skjer her.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dette tildeles så mange ganger som nødvendig for å konstruere `Vec<T>`, og deretter vil det tildeles en gang for å gjøre `Vec<T>` til `Rc<[T]>`.
    ///
    ///
    /// ## Iteratorer av kjent lengde
    ///
    /// Når `Iterator` implementerer `TrustedLen` og har en nøyaktig størrelse, vil det bli gitt en enkelt tildeling for `Rc<[T]>`.For eksempel:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Bare en enkelt tildeling skjer her.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spesialisering trait brukt til å samle inn i `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Dette er tilfelle for en `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SIKKERHET: Vi må sørge for at iteratoren har en nøyaktig lengde, og det har vi.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Fall tilbake til normal implementering.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` er en versjon av [`Rc`] som inneholder en ikke-eier referanse til den administrerte tildelingen.Du får tilgang til tildelingen ved å ringe [`upgrade`] på `Weak`-pekeren, som returnerer en [`Option`]`<`[`Rc`] `<T>>`.
///
/// Siden en `Weak`-referanse ikke teller med på eierskap, vil den ikke forhindre at verdien som er lagret i tildelingen blir droppet, og `Weak` i seg selv gir ingen garantier for at verdien fortsatt er til stede.
/// Dermed kan den returnere [`None`] når [`upgrade`] d.
/// Merk imidlertid at en `Weak`-referanse *forhindrer* allokering av selve tildelingen (backing-butikken).
///
/// En `Weak`-peker er nyttig for å holde en midlertidig referanse til tildelingen administrert av [`Rc`] uten å forhindre at den indre verdien faller.
/// Den brukes også til å forhindre sirkulære referanser mellom [`Rc`]-pekere, siden gjensidige eierreferanser aldri vil tillate at noen av [`Rc`] slippes.
/// For eksempel kan et tre ha sterke [`Rc`]-pekere fra foreldrenoder til barn, og `Weak`-pekere fra barn tilbake til foreldrene.
///
/// Den typiske måten å få tak i en `Weak`-peker er å ringe [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dette er en `NonNull` som muliggjør optimalisering av størrelsen på denne typen i enums, men det er ikke nødvendigvis en gyldig peker.
    //
    // `Weak::new` setter dette til `usize::MAX` slik at det ikke trenger å tildele plass på dyngen.
    // Det er ikke en verdi en ekte peker noen gang vil ha fordi RcBox har justering minst 2.
    // Dette er bare mulig når `T: Sized`;unsized `T` dingler aldri.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Konstruerer en ny `Weak<T>` uten å tildele noe minne.
    /// Å ringe [`upgrade`] på returverdien gir alltid [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Hjelpertype for å tillate tilgang til referansetellene uten å gjøre noen påstander om datafeltet.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Returnerer en rå peker til objektet `T` pekt på av denne `Weak<T>`.
    ///
    /// Pekeren er bare gyldig hvis det er noen sterke referanser.
    /// Pekeren kan være dinglende, ujustert eller til og med [`null`] ellers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Begge peker på det samme objektet
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Den sterke her holder den i live, slik at vi fremdeles kan få tilgang til objektet.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Men ikke nå lenger.
    /// // Vi kan gjøre weak.as_ptr(), men tilgang til pekeren vil føre til udefinert oppførsel.
    /// // assert_eq! ("hei", usikre {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Hvis pekeren henger, returnerer vi sentinellen direkte.
            // Dette kan ikke være en gyldig nyttelastadresse, siden nyttelasten er minst like justert som RcBox (usize).
            ptr as *const T
        } else {
            // SIKKERHET: Hvis is_dangling returnerer false, kan pekeren avvises.
            // Nyttelasten kan bli droppet på dette punktet, og vi må opprettholde herkomst, så bruk rå pekermanipulasjon.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Forbruker `Weak<T>` og gjør den til en rå peker.
    ///
    /// Dette konverterer den svake pekeren til en rå peker, mens du fremdeles bevarer eierskapet til en svak referanse (det svake antallet endres ikke av denne operasjonen).
    /// Den kan gjøres om til `Weak<T>` med [`from_raw`].
    ///
    /// De samme begrensningene for tilgang til pekermålet som med [`as_ptr`] gjelder.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konverterer en rå peker som tidligere ble opprettet av [`into_raw`] tilbake til `Weak<T>`.
    ///
    /// Dette kan brukes til å trygt få en sterk referanse (ved å ringe [`upgrade`] senere) eller for å plassere det svake antallet ved å slippe `Weak<T>`.
    ///
    /// Det tar eierskap til en svak referanse (med unntak av pekere opprettet av [`new`], da disse ikke eier noe; metoden fungerer fortsatt på dem).
    ///
    /// # Safety
    ///
    /// Pekeren må ha sitt utspring fra [`into_raw`] og må fremdeles eie sin potensielle svake referanse.
    ///
    /// Det er tillatt for den sterke tellingen å være 0 når du kaller dette.
    /// Likevel tar dette eierskap til en svak referanse som for øyeblikket er representert som en rå peker (det svake antallet er ikke modifisert av denne operasjonen), og derfor må den sammenkobles med en tidligere samtale til [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Reduser den siste svake tellingen.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Se Weak::as_ptr for kontekst om hvordan inngangspekeren blir avledet.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dette er en dinglende svak.
            ptr as *mut RcBox<T>
        } else {
            // Ellers er vi garantert at pekeren kom fra en svak svindel.
            // SIKKERHET: data_offset er trygt å ringe, da ptr refererer til en ekte (potensielt droppet) T.
            let offset = unsafe { data_offset(ptr) };
            // Dermed reverserer vi forskyvningen for å få hele RcBox.
            // SIKKERHET: pekeren stammer fra en svak, så denne forskyvningen er trygg.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIKKERHET: vi har nå gjenopprettet den opprinnelige svake pekeren, slik at vi kan opprette den svake.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Forsøker å oppgradere `Weak`-pekeren til en [`Rc`], og forsinker å slippe den indre verdien hvis den lykkes.
    ///
    ///
    /// Returnerer [`None`] hvis den indre verdien siden har blitt sluppet.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ødelegg alle sterke pekere.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Får antall sterke (`Rc`)-pekere som peker på denne tildelingen.
    ///
    /// Hvis `self` ble opprettet ved hjelp av [`Weak::new`], vil dette returnere 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Får antall `Weak`-pekere som peker på denne tildelingen.
    ///
    /// Hvis det ikke er noen sterke pekere igjen, vil dette gi null.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // trekk den implisitte svake ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Returnerer `None` når pekeren henger og det ikke er tildelt `RcBox`, (dvs. når denne `Weak` ble opprettet av `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Vi er forsiktige med å *ikke* opprette en referanse som dekker "data"-feltet, da feltet kan bli mutert samtidig (for eksempel hvis den siste `Rc` blir droppet, vil datafeltet bli droppet på plass).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Returnerer `true` hvis de to svake peker på samme tildeling (ligner på [`ptr::eq`]), eller hvis begge ikke peker på noen tildeling (fordi de ble opprettet med `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Siden dette sammenligner pekere, betyr det at `Weak::new()` vil like hverandre, selv om de ikke peker på noen tildeling.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Sammenligning av `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Dropper `Weak`-pekeren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Skriver ikke ut noe
    /// drop(foo);        // Skriver ut "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // den svake tellingen starter ved 1, og vil bare gå til null hvis alle de sterke pekerne har forsvunnet.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Gjør en klon av `Weak`-pekeren som peker på samme tildeling.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruerer en ny `Weak<T>` og tildeler minne til `T` uten å initialisere den.
    /// Å ringe [`upgrade`] på returverdien gir alltid [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Vi sjekket_add her for å håndtere mem::forget trygt.Spesielt
// hvis du mem::forget Rcs (eller Weaks), kan ref-count overløpe, og så kan du frigjøre tildelingen mens det finnes utestående Rcs (eller Weaks).
//
// Vi avbryter fordi dette er et så degenerert scenario at vi ikke bryr oss om hva som skjer-ingen reelle programmer burde noen gang oppleve dette.
//
// Dette burde ha ubetydelig overhead siden du faktisk ikke trenger å klone disse mye i Rust takket være eierskap og flyttesemantikk.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Vi vil avbryte ved overløp i stedet for å slippe verdien.
        // Referansetellingen vil aldri være null når dette kalles;
        // likevel setter vi inn et avbrudd her for å antyde LLVM til en ellers savnet optimalisering.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Vi vil avbryte ved overløp i stedet for å slippe verdien.
        // Referansetellingen vil aldri være null når dette kalles;
        // likevel setter vi inn et avbrudd her for å antyde LLVM til en ellers savnet optimalisering.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Få forskyvningen innen en `RcBox` for nyttelasten bak en peker.
///
/// # Safety
///
/// Pekeren må peke på (og ha gyldige metadata for) en tidligere gyldig forekomst av T, men T er tillatt å slippe.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Juster den ustørrede verdien til slutten av RcBox.
    // Fordi RcBox er repr(C), vil det alltid være det siste feltet i minnet.
    // SIKKERHET: siden de eneste mulige typene er skiver, trait-objekter,
    // og eksterne typer, er sikkerhetskravet for inngang for tiden nok til å tilfredsstille kravene til align_of_val_raw;dette er en implementeringsdetalj av språket som ikke kan stole på utenfor std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}