// rsbegin.o og rsend.o er den såkalte "compiler runtime startup objects".
// De inneholder koden som trengs for å korrekt initialisere kompilatorens kjøretid.
//
// Når et kjørbart eller dylib-bilde er koblet, er all brukerkode og bibliotek "sandwiched" mellom disse to objektfilene, så kode eller data fra rsbegin.o blir først i de respektive delene av bildet, mens kode og data fra rsend.o blir de siste.
// Denne effekten kan brukes til å plassere symboler i begynnelsen eller slutten av en seksjon, så vel som å sette inn alle påkrevde topp-eller bunntekster.
//
// Vær oppmerksom på at det faktiske modulinngangspunktet er plassert i C-runtime-oppstartsobjektet (vanligvis kalt `crtX.o`), som deretter påkaller tilbakeringing til initialisering av andre kjøretidskomponenter (registrert via enda en spesiell bildeseksjon).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Merker begynnelsen på stabelrammen for å koble av info-delen
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Skrap plass for avviklerens interne bokføring.
    // Dette er definert som `struct object` i $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Slapp av info registration/deregistration-rutiner.
    // Se dokumentene til libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registrer avkoblingsinfo ved oppstart av modulen
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // avregistrere ved avstenging
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-spesifikk init/uninit rutinemessig registrering
    pub mod mingw_init {
        // MinGWs oppstartsobjekter (crt0.o/dllcrt0.o) vil påkalle globale konstruktører i .ctors-og .dtors-seksjonene ved oppstart og utgang.
        // Når det gjelder DLLer, gjøres dette når DLL lastes og lastes ut.
        //
        // Linkeren vil sortere seksjonene, noe som sikrer at tilbakeringingene våre ligger på slutten av listen.
        // Siden konstruktører kjøres i omvendt rekkefølge, sikrer dette at tilbakeringingene våre er de første og siste som blir utført.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C initialisering tilbakeringinger
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C-tilbakeringing ved avslutning
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}