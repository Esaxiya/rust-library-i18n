//! Implementering av Rust panics via prosessavbrudd
//!
//! Sammenlignet med implementeringen via avkobling er denne crate *mye* enklere!Når det er sagt, er det ikke fullt så allsidig, men her går!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" nyttelasten og mellomlegget til den aktuelle avbruddet på den aktuelle plattformen.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ring std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // På Windows bruker du den prosessorspesifikke __fastfail-mekanismen.I Windows 8 og senere vil dette avslutte prosessen umiddelbart uten å kjøre noen unntakshåndterere i prosessen.
            // I tidligere versjoner av Windows blir denne sekvensen av instruksjoner behandlet som et brudd på tilgangen, og avslutter prosessen, men uten nødvendigvis å omgå alle unntakshåndterere.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: dette er den samme implementeringen som i libstds `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Dette ... er litt rart.Den tl; dr;er at dette er nødvendig for å koble riktig, den lengre forklaringen er nedenfor.
//
// Akkurat nå er binærfiler fra libcore/libstd som vi leverer, samlet med `-C panic=unwind`.Dette gjøres for å sikre at binærfiler er maksimalt kompatible med så mange situasjoner som mulig.
// Kompilatoren krever imidlertid en "personality function" for alle funksjoner som er kompilert med `-C panic=unwind`.Denne personlighetsfunksjonen er hardkodet til symbolet `rust_eh_personality` og er definert av `eh_personality` lang-elementet.
//
// So...
// hvorfor ikke bare definere det lang elementet her?Godt spørsmål!Måten panic kjøretider er koblet på er faktisk litt subtil fordi de er "sort of" i kompilatorens crate-butikk, men bare faktisk koblet hvis en annen ikke er koblet til.
//
// Dette ender med at både denne crate og panic_unwind crate kan vises i kompilatorens crate-butikk, og hvis begge definerer `eh_personality` lang-elementet, vil det treffe en feil.
//
// For å håndtere dette krever kompilatoren bare at `eh_personality` er definert hvis panic-kjøretiden som er koblet til, er avviklingstiden, og ellers er det ikke nødvendig å definere det (med rette).
// I dette tilfellet definerer imidlertid dette biblioteket bare dette symbolet, så det er i det minste en eller annen personlighet et sted.
//
// I hovedsak er dette symbolet bare definert for å bli koblet til libcore/libstd-binærfiler, men det skal aldri kalles ettersom vi ikke kobler sammen i en avkoblingstid.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // På x86_64-pc-windows-gnu bruker vi vår egen personlighetsfunksjon som trenger å returnere `ExceptionContinueSearch` når vi videreformidler alle rammene våre.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // I likhet med ovenfor tilsvarer dette `eh_catch_typeinfo` lang-elementet som bare brukes på Emscripten for øyeblikket.
    //
    // Siden panics ikke genererer unntak, og utenlandske unntak for øyeblikket er UB med -C panic=avbrutt (selv om dette kan endres), vil noen catch_unwind-samtaler aldri bruke denne typen informasjon.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Disse to kalles av oppstartsobjektene våre på i686-pc-windows-gnu, men de trenger ikke gjøre noe så kroppene er nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}