use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Brukes til å fortelle `#[assert_instr]`-merknadene våre om at all simd-egenart er tilgjengelig for å teste kodegen, siden noen er gated bak en ekstra `-Ctarget-feature=+unimplemented-simd128` som ikke har noe tilsvarende i `#[target_feature]` akkurat nå.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}