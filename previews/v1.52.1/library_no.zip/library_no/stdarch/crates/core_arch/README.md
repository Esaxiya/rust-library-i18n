`core::arch` - Rust s kjernebiblioteksarkitektur-spesifikke egenart
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch`-modulen implementerer arkitekturavhengig egenutvikling (f.eks. SIMD).

# Usage 

`core::arch` er tilgjengelig som en del av `libcore`, og den eksporteres på nytt av `libstd`.Foretrekker å bruke den via `core::arch` eller `std::arch` enn via denne crate.
Ustabile funksjoner er ofte tilgjengelige i Rust om natten via `feature(stdsimd)`.

Å bruke `core::arch` via denne crate krever Rust om natten, og det kan (og gjør det) ofte.De eneste tilfellene der du bør vurdere å bruke det via denne crate er:

* hvis du trenger å re-kompilere `core::arch` selv, for eksempel med spesifikke målfunksjoner aktivert som ikke er aktivert for `libcore`/`libstd`.
Note: Hvis du trenger å kompilere det på nytt for et ikke-standardmål, kan du foretrekke å bruke `xargo` og kompilere `libcore`/`libstd` etter behov i stedet for å bruke denne crate.
  
* bruker noen funksjoner som kanskje ikke er tilgjengelige selv bak ustabile Rust-funksjoner.Vi prøver å holde disse til et minimum.
Hvis du trenger å bruke noen av disse funksjonene, kan du åpne et problem slik at vi kan avsløre dem i Rust om natten, og du kan bruke dem derfra.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` distribueres primært under vilkårene for både MIT-lisensen og Apache-lisensen (versjon 2.0), med deler dekket av forskjellige BSD-lignende lisenser.

Se LISENS-APACHE og LISENS-MIT for detaljer.

# Contribution

Med mindre du uttrykkelig oppgir noe annet, skal ethvert bidrag med vilje levert for inkludering i `core_arch` av deg, som definert i Apache-2.0-lisensen, være dobbelt lisensiert som ovenfor, uten ytterligere vilkår eller betingelser.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












