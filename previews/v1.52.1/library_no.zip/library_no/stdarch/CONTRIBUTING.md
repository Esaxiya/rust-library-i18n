# Bidrar til stdarch

`stdarch` crate er mer enn villig til å ta imot bidrag!Først vil du sannsynligvis sjekke ut depotet og sørge for at testene passerer for deg:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Der `<your-target-arch>` er mål-trippelen som brukt av `rustup`, f.eks. `x86_x64-unknown-linux-gnu` (uten noen tidligere `nightly-` eller lignende).
Husk også at dette depotet krever nattkanalen til Rust!
Ovennevnte tester krever faktisk at nattlig rust er standard på systemet ditt, for å angi at bruk `rustup default nightly` (og `rustup default stable` for å tilbakestille).

Hvis noen av trinnene ovenfor ikke fungerer, [please let us know][new]!

Deretter kan du [find an issue][issues] for å hjelpe deg, vi har valgt noen få med [`help wanted`][help]-og [`impl-period`][impl]-kodene som spesielt kan bruke litt hjelp. 
Du er kanskje mest interessert i [#40][vendor], og implementerer all leverandørens egenart på x86.Det problemet har noen gode tips om hvor du kan komme i gang!

Hvis du har generelle spørsmål, er du velkommen til [join us on gitter][gitter] og spør deg rundt!Ping gjerne@BurntSushi eller@alexcrichton med spørsmål.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Hvordan skrive eksempler for stdarch-egenart

Det er noen få funksjoner som må være aktivert for at den gitte egenskapen skal fungere skikkelig, og eksemplet må bare kjøres av `cargo test --doc` når funksjonen støttes av CPUen.

Som et resultat vil standard `fn main` som genereres av `rustdoc` ikke fungere (i de fleste tilfeller).
Vurder å bruke følgende som en veiledning for å sikre at eksemplet ditt fungerer som forventet.

```rust
/// # // Vi trenger cfg_target_feature for å sikre at eksemplet bare er
/// # // drives av `cargo test --doc` når CPU støtter funksjonen
/// # #![feature(cfg_target_feature)]
/// # // Vi trenger target_feature for at den iboende skal fungere
/// # #![feature(target_feature)]
/// #
/// # // rustdoc bruker som standard `extern crate stdarch`, men vi trenger
/// # // `#[macro_use]`
/// # # [makrobruk] ekstern crate stdarch;
/// #
/// # // Den virkelige hovedfunksjonen
/// # fn main() {
/// #     // Kjør dette bare hvis `<target feature>` støttes
/// #     hvis cfg_feature_enabled! ("<target feature>"){
/// #         // Opprett en `worker`-funksjon som bare kjøres hvis målfunksjonen
/// #         // støttes og sørg for at `target_feature` er aktivert for arbeidstakeren din
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         usikre fn worker() {
/// // Skriv eksemplet ditt her.Funksjonsspesifikke egener vil fungere her!Bli gal!
///
/// #         }
///
/// #         usikre { worker(); }
/// #     }
/// # }
```

Hvis noen av de ovennevnte syntakene ikke ser kjent ut, beskriver [Documentation as tests]-delen av [Rust Book] `rustdoc`-syntaksen ganske bra.
Som alltid, føl deg fri til [join us on gitter][gitter] og spør oss om du treffer noen hakk, og takk for at du hjelper med å forbedre dokumentasjonen til `stdarch`!

# Alternative testinstruksjoner

Det anbefales generelt at du bruker `ci/run.sh` til å kjøre testene.
Dette kan imidlertid ikke fungere for deg, for eksempel hvis du er på Windows.

I så fall kan du gå tilbake til å kjøre `cargo +nightly test` og `cargo +nightly test --release -p core_arch` for å teste kodegenerering.
Vær oppmerksom på at disse krever at den nattlige verktøykjeden installeres og at `rustc` vet om din trippelmål og CPU-en.
Spesielt må du stille inn miljøvariabelen `TARGET` slik du ville gjort for `ci/run.sh`.
I tillegg må du stille `RUSTCFLAGS` (trenger `C`) for å indikere målfunksjoner, f.eks `RUSTCFLAGS="-C -target-features=+avx2"`.
Du kan også stille `-C -target-cpu=native` hvis du utvikler "just" mot din nåværende CPU.

Vær advart om at når du bruker disse alternative instruksjonene, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], f.eks
instruksjoner for generering av instruksjoner kan mislykkes fordi demontereren navngir dem annerledes, f.eks
det kan generere `vaesenc` i stedet for `aesenc`-instruksjoner til tross for at de oppfører seg likt.
Disse instruksjonene utfører også færre tester enn normalt, så vær ikke overrasket over at når du til slutt trekker forespørsel, kan det oppstå noen feil for tester som ikke er dekket her.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






