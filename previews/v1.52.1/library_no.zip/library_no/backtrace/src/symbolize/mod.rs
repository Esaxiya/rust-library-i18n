use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Løs en adresse til et symbol, og før symbolet til den angitte lukkingen.
///
/// Denne funksjonen vil slå opp den gitte adressen i områder som den lokale symboltabellen, den dynamiske symboltabellen eller DWARF-feilsøkingsinformasjonen (avhengig av aktivert implementering) for å finne symboler å gi.
///
///
/// Avslutningen kan ikke kalles hvis oppløsningen ikke kunne utføres, og det kan også kalles mer enn en gang i tilfelle av innebygde funksjoner.
///
/// Symboler som vises representerer kjøringen ved den angitte `addr`, og returnerer file/line-par for den adressen (hvis tilgjengelig).
///
/// Merk at hvis du har en `Frame`, anbefales det å bruke `resolve_frame`-funksjonen i stedet for denne.
///
/// # Nødvendige funksjoner
///
/// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
///
/// # Panics
///
/// Denne funksjonen prøver å aldri panic, men hvis `cb` ga panics, vil noen plattformer tvinge en dobbel panic til å avbryte prosessen.
/// Noen plattformer bruker et C-bibliotek som internt bruker tilbakeringinger som ikke kan spoles gjennom, så panikk fra `cb` kan utløse en prosessavbrudd.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // bare se på topprammen
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Løs en tidligere fanget ramme til et symbol, og før symbolet til den angitte lukkingen.
///
/// Denne funksjonen utfører den samme funksjonen som `resolve` bortsett fra at den tar en `Frame` som argument i stedet for en adresse.
/// Dette kan tillate noen plattformimplementeringer av tilbakesporing for å gi mer nøyaktig symbolinformasjon eller informasjon om innebygde rammer for eksempel.
///
/// Det anbefales å bruke dette hvis du kan.
///
/// # Nødvendige funksjoner
///
/// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
///
/// # Panics
///
/// Denne funksjonen prøver å aldri panic, men hvis `cb` ga panics, vil noen plattformer tvinge en dobbel panic til å avbryte prosessen.
/// Noen plattformer bruker et C-bibliotek som internt bruker tilbakeringinger som ikke kan spoles gjennom, så panikk fra `cb` kan utløse en prosessavbrudd.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // bare se på topprammen
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP-verdier fra stabelrammer er vanligvis (always?) instruksjonen *etter* samtalen som er den faktiske stakksporingen.
// Symbolisering av dette på fører til at filename/line-tallet er ett foran og kanskje inn i tomrommet hvis det er nær slutten av funksjonen.
//
// Dette ser ut til å alltid være tilfelle på alle plattformer, så vi trekker alltid en fra en løst ip for å løse den til forrige samtaleinstruksjon i stedet for at instruksjonen blir returnert til.
//
//
// Ideelt sett ville vi ikke gjøre dette.
// Ideelt sett vil vi kreve at innringere av `resolve` APIene her må gjøre -1 manuelt og gjøre rede for at de vil ha stedsinformasjon for *forrige* instruksjon, ikke den nåværende.
// Ideelt sett vil vi også eksponere på `Frame` hvis vi virkelig er adressen til neste instruksjon eller den nåværende.
//
// For nå, selv om dette er en ganske nisje bekymring, så vi bare internt trekker en.
// Forbrukere bør fortsette å jobbe og få ganske gode resultater, så vi skal være gode nok.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Samme som `resolve`, bare usikkert da det er usynkronisert.
///
/// Denne funksjonen har ikke synkroniseringsgarantier, men er tilgjengelig når `std`-funksjonen til denne crate ikke er kompilert i.
/// Se `resolve`-funksjonen for mer dokumentasjon og eksempler.
///
/// # Panics
///
/// Se informasjon på `resolve` for advarsler om `cb`-panikk.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Samme som `resolve_frame`, bare usikkert da det er usynkronisert.
///
/// Denne funksjonen har ikke synkroniseringsgarantier, men er tilgjengelig når `std`-funksjonen til denne crate ikke er kompilert i.
/// Se `resolve_frame`-funksjonen for mer dokumentasjon og eksempler.
///
/// # Panics
///
/// Se informasjon på `resolve_frame` for advarsler om `cb`-panikk.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// En trait som representerer oppløsningen til et symbol i en fil.
///
/// Denne trait er gitt som et trait-objekt mot lukkingen gitt til `backtrace::resolve`-funksjonen, og den sendes praktisk talt ettersom det er ukjent hvilken implementering som ligger bak.
///
///
/// Et symbol kan gi kontekstuell informasjon om en funksjon, for eksempel navn, filnavn, linjenummer, presis adresse, etc.
/// Ikke all informasjon er alltid tilgjengelig i et symbol, så alle metoder returnerer en `Option`.
///
///
pub struct Symbol {
    // TODO: dette levetidsbundet må vedvares til slutt til `Symbol`,
    // men det er for øyeblikket en bruddendring.
    // Foreløpig er dette trygt siden `Symbol` bare blir utlevert med referanse og ikke kan klones.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Returnerer navnet på denne funksjonen.
    ///
    /// Den returnerte strukturen kan brukes til å spørre forskjellige egenskaper om symbolnavnet:
    ///
    ///
    /// * `Display`-implementeringen vil skrive ut det avviklede symbolet.
    /// * Den rå `str`-verdien til symbolet er tilgjengelig (hvis den er gyldig utf-8).
    /// * De rå bytene for symbolnavnet er tilgjengelige.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Returnerer startadressen til denne funksjonen.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Returnerer det rå filnavnet som et stykke.
    /// Dette er hovedsakelig nyttig i `no_std`-miljøer.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Returnerer kolonnenummeret for hvor dette symbolet for tiden kjøres.
    ///
    /// Bare gimli gir for øyeblikket en verdi her og til og med da bare hvis `filename` returnerer `Some`, og det er følgelig underlagt lignende forbehold.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Returnerer linjenummeret for hvor dette symbolet for tiden kjøres.
    ///
    /// Denne returverdien er vanligvis `Some` hvis `filename` returnerer `Some`, og er følgelig utsatt for lignende forbehold.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Returnerer filnavnet der denne funksjonen ble definert.
    ///
    /// Dette er for øyeblikket bare tilgjengelig når libbacktrace eller gimli brukes (f.eks
    /// unix andre plattformer) og når en binær er kompilert med debuginfo.
    /// Hvis ingen av disse vilkårene er oppfylt, vil dette sannsynligvis returnere `None`.
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Kanskje et analysert C++ -symbol, hvis analysering av det manglede symbolet som Rust mislyktes.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Sørg for å ha denne nullstørrelsen, slik at `cpp_demangle`-funksjonen ikke koster når den er deaktivert.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// En omvikling rundt et symbolnavn for å gi ergonomiske aksessorer til det demanglede navnet, råbyte, råstreng osv.
///
// Tillat død kode når `cpp_demangle`-funksjonen ikke er aktivert.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Oppretter et nytt symbolnavn fra de rå underliggende byte.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Returnerer det rå (mangled)-symbolnavnet som en `str` hvis symbolet er gyldig utf-8.
    ///
    /// Bruk `Display`-implementeringen hvis du vil ha en demanglet versjon.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Returnerer det rå symbolnavnet som en liste over byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Dette kan skrives ut hvis det demangulerte symbolet ikke er gyldig, så håndter feilen her elegant ved ikke å spre den utover.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Forsøk å gjenvinne det bufrede minnet som brukes til å symbolisere adresser.
///
/// Denne metoden vil forsøke å frigjøre globale datastrukturer som ellers er lagret globalt eller i tråden som vanligvis representerer analysert DWARF-informasjon eller lignende.
///
///
/// # Caveats
///
/// Selv om denne funksjonen alltid er tilgjengelig, gjør den faktisk ingenting på de fleste implementeringer.
/// Biblioteker som dbghelp eller libbacktrace gir ikke fasiliteter for å distribuere tilstand og administrere det tildelte minnet.
/// For nå er `gimli-symbolize`-funksjonen til denne crate den eneste funksjonen der denne funksjonen har noen effekt.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}