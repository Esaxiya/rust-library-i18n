//! Symboliseringsstrategi ved bruk av DWARF-parsing-koden i libbacktrace.
//!
//! Libbacktrace C-biblioteket, vanligvis distribuert med gcc, støtter ikke bare å generere en backtrace (som vi faktisk ikke bruker), men også symbolisere backtrace og håndtere dvergfeilsøkingsinformasjon om ting som inline-rammer og hva som helst.
//!
//!
//! Dette er relativt komplisert på grunn av mange forskjellige bekymringer her, men grunntanken er:
//!
//! * Først kaller vi `backtrace_syminfo`.Dette får symbolinformasjon fra den dynamiske symboltabellen hvis vi kan.
//! * Neste kaller vi `backtrace_pcinfo`.Dette vil analysere feilsøkingstabeller hvis de er tilgjengelige og tillate oss å gjenopprette informasjon om innebygde rammer, filnavn, linjenumre, etc.
//!
//! Det er mye lureri med å få dvergbordene inn i libbacktrace, men forhåpentligvis er det ikke verdens ende og er tydelig nok når du leser nedenfor.
//!
//! Dette er standard symboliseringsstrategi for ikke-MSVC-og ikke-OSX-plattformer.I libstd er dette standardstrategien for OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Hvis mulig foretrekker `function`-navnet som kommer fra debuginfo og kan vanligvis være mer nøyaktig for for eksempel innebygde rammer.
                // Hvis det ikke er til stede, fall tilbake til symboltabellnavnet spesifisert i `symname`.
                //
                // Vær oppmerksom på at `function` noen ganger kan føles noe mindre nøyaktig, for eksempel å være oppført som `try<i32,closure>` ikke er i stedet for `std::panicking::try::do_call`.
                //
                // Det er ikke helt klart hvorfor, men generelt virker `function`-navnet mer nøyaktig.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // gjør ingenting for nå
}

/// Type `data`-pekeren sendt til `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Når denne tilbakeringingen er påkalt fra `backtrace_syminfo` når vi begynner å løse, går vi lenger for å ringe `backtrace_pcinfo`.
    // `backtrace_pcinfo`-funksjonen vil konsultere feilsøkingsinformasjon og forsøke å gjøre ting som å gjenopprette file/line-informasjon så vel som inline-rammer.
    // Vær oppmerksom på at `backtrace_pcinfo` kan mislykkes eller ikke gjøre mye hvis det ikke er informasjon om feilsøking, så hvis det skjer, vil vi sikkert ringe tilbakeringingen med minst ett symbol fra `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Type `data`-pekeren sendt til `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API støtter opprettelse av en tilstand, men den støtter ikke ødeleggelse av en stat.
// Jeg personlig tar dette til å bety at en stat er ment å bli opprettet og deretter leve for alltid.
//
// Jeg vil gjerne registrere en at_exit()-handler som rydder opp i denne tilstanden, men libbacktrace gir ingen måte å gjøre det.
//
// Med disse begrensningene har denne funksjonen en statisk hurtigbufret tilstand som beregnes første gang dette blir bedt om.
//
// Husk at backtracing alt skjer serielt (en global lås).
//
// Merk at mangelen på synkronisering her skyldes kravet om at `resolve` er eksternt synkronisert.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ikke bruk threadsafe-funksjonene til libbacktrace siden vi alltid kaller det på en synkronisert måte.
        //
        0,
        error_cb,
        ptr::null_mut(), // ingen ekstra data
    );

    return STATE;

    // Merk at for at libbacktrace skal fungere i det hele tatt, trenger den å finne DWARF-feilsøkingsinformasjonen for den gjeldende kjørbare filen.Det gjør det vanligvis via en rekke mekanismer, inkludert, men ikke begrenset til:
    //
    // * /proc/self/exe på støttede plattformer
    // * Filnavnet ble gitt eksplisitt når staten opprettet
    //
    // Libbacktrace-biblioteket er en stor mengde C-kode.Dette betyr naturlig at det har minnesikkerhetsproblemer, spesielt når du håndterer misdannet feilsøkingsinformasjon.
    // Libstd har møtt mange av disse historisk.
    //
    // Hvis /proc/self/exe brukes, kan vi vanligvis ignorere disse, ettersom vi antar at libbacktrace er "mostly correct" og ellers ikke gjør rare ting med "attempted to be correct" dvergfeilsøkingsinformasjon.
    //
    //
    // Hvis vi sender inn et filnavn, er det imidlertid mulig på noen plattformer (som BSDer) der en ondsinnet aktør kan føre til at en vilkårlig fil blir plassert på det stedet.
    // Dette betyr at hvis vi forteller libbacktrace om et filnavn, kan det være at det bruker en vilkårlig fil, og muligens forårsaker segfeil.
    // Hvis vi ikke forteller libbacktrace noe skjønt, vil det ikke gjøre noe på plattformer som ikke støtter stier som /proc/self/exe!
    //
    // Gitt alt det vi prøver så hardt som mulig å *ikke* sende inn et filnavn, men vi må på plattformer som ikke støtter /proc/self/exe i det hele tatt.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Merk at ideelt sett vil vi bruke `std::env::current_exe`, men vi kan ikke kreve `std` her.
            //
            // Bruk `_NSGetExecutablePath` for å laste den nåværende kjørbare banen inn i et statisk område (som bare er å gi opp hvis det er for lite).
            //
            //
            // Merk at vi seriøst stoler på libbacktrace her for ikke å dø av korrupte kjørbare filer, men det gjør det sikkert ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows har en modus for å åpne filer der den ikke kan slettes etter at den er åpnet.
            // Det er generelt det vi vil ha her fordi vi vil sikre at den kjørbare filen vår ikke endrer seg under oss etter at vi har overlevert den til libbacktrace, forhåpentligvis reduserer muligheten til å overføre vilkårlige data til libbacktrace (som kan bli feilhåndtert).
            //
            //
            // Gitt at vi danser litt her for å prøve å få en slags lås på vårt eget bilde:
            //
            // * Få tak i den nåværende prosessen, last inn filnavnet.
            // * Åpne en fil til det filnavnet med høyre flagg.
            // * Last inn den nåværende prosessens filnavn, og pass på at den er den samme
            //
            // Hvis alt går, har vi i teorien faktisk åpnet prosessfilen vår, og vi er garantert at den ikke vil endres.FWIW en haug med dette er kopiert fra libstd historisk, så dette er min beste tolkning av hva som skjedde.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Dette lever i statisk minne slik at vi kan returnere det ..
                static mut BUF: [i8; N] = [0; N];
                // ... og dette lever på bunken siden det er midlertidig
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // med vilje lekke `handle` her fordi det å ha det åpent burde bevare låsingen vår på dette filnavnet.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Vi ønsker å returnere et stykke som er null-avsluttet, så hvis alt ble fylt ut og det tilsvarer den totale lengden, tilsvarer du det til feil.
                //
                //
                // Ellers må du forsikre deg om at nulbyte er inkludert i stykket når du returnerer suksess.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // tilbakesporingsfeil feies for tiden under teppet
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Ring `backtrace_syminfo` API som (fra å lese koden) skal ringe `syminfo_cb` nøyaktig en gang (eller mislykkes med en feil antagelig).
    // Vi håndterer mer innenfor `syminfo_cb`.
    //
    // Merk at vi gjør dette siden `syminfo` vil konsultere symboltabellen og finne symbolnavn selv om det ikke er noen feilsøkingsinformasjon i binærfilen.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}