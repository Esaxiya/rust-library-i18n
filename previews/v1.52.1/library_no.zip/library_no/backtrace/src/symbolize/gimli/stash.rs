// bare brukt på Linux akkurat nå, så tillat død kode andre steder
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// En enkel arenaallokering for bytebuffere.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Tildeler en buffer med den spesifiserte størrelsen og returnerer en foranderlig referanse til den.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SIKKERHET: dette er den eneste funksjonen som noensinne konstruerer en muterbar
        // referanse til `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SIKKERHET: vi fjerner aldri elementer fra `self.buffers`, så en referanse
        // til dataene i enhver buffer vil leve så lenge `self` gjør.
        &mut buffers[i]
    }
}