//! Støtte for symbolisering ved bruk av `gimli` crate på crates.io
//!
//! Dette er standard implementering av symbolisering for Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'statisk levetid er en løgn å hacke rundt mangel på støtte for selvhenvisende strukturer.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Konverter til 'statiske levetider siden symbolene bare skal låne `map` og `stash`, og vi bevarer dem nedenfor.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // For å laste innfødte biblioteker på Windows, se litt diskusjon på rust-lang/rust#71060 for de forskjellige strategiene her.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW-biblioteker støtter foreløpig ikke ASLR (rust-lang/rust#16514), men DLL-filer kan fortsatt flyttes rundt i adresserommet.
            // Det ser ut til at adresser i feilsøkingsinfo alle er som om dette biblioteket ble lastet på "image base", som er et felt i COFF-filoverskriftene.
            // Siden dette er hva debuginfo ser ut til å liste, analyserer vi symboltabellen og lagrer adresser som om biblioteket også var lastet inn på "image base".
            //
            // Biblioteket kan imidlertid ikke lastes inn på "image base".
            // (antagelig kan noe annet lastes der?) Det er her `bias`-feltet kommer til spill, og vi må finne ut verdien av `bias` her.Dessverre er det ikke klart hvordan du skaffer deg dette fra en lastet modul.
            // Det vi har, er imidlertid den faktiske lastadressen (`modBaseAddr`).
            //
            // Som litt av en cop-out for nå, mmap vi filen, les filinformasjon og slipp deretter mmap.Dette er bortkastet fordi vi sannsynligvis åpner mmap senere, men dette skal fungere bra nok for nå.
            //
            // Når vi har `image_base` (ønsket lasteplassering) og `base_addr` (faktisk lasteplassering), kan vi fylle ut `bias` (forskjell mellom faktisk og ønsket), og deretter er den oppgitte adressen til hvert segment `image_base`, siden det er det filen sier.
            //
            //
            // For nå ser det ut til at i motsetning til ELF/MachO kan vi klare oss med ett segment per bibliotek ved å bruke `modBaseSize` som hele størrelsen.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS bruker Mach-O-filformatet og bruker DYLD-spesifikke APIer for å laste inn en liste over innfødte biblioteker som er en del av applikasjonen.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Hent navnet på dette biblioteket som tilsvarer banen hvor du også skal laste det inn.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Last inn bildeoverskriften til dette biblioteket og deleger til `object` for å analysere alle lastekommandoer, slik at vi kan finne ut alle segmentene som er involvert her.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterer over segmentene og registrer kjente regioner for segmenter som vi finner.
            // I tillegg registrerer du informasjon om tekstsegmenter for senere behandling, se kommentarene nedenfor.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Bestem "slide" for dette biblioteket, som ender med å være forspenningen vi bruker for å finne ut hvor i minnet objekter er lastet.
            // Dette er litt av en merkelig beregning skjønt, og er resultatet av å prøve et par ting i naturen og se hva som stikker.
            //
            // Den generelle ideen er at `bias` pluss et segment `stated_virtual_memory_address` kommer til å være der i det faktiske adresseområdet segmentet ligger.
            // Den andre tingen vi stoler på er at en ekte adresse minus `bias` er indeksen for å slå opp i symboltabellen og feilsøkingsinformasjonen.
            //
            // Det viser seg imidlertid at disse beregningene for systembelastede biblioteker er feil.For innfødte kjørbare filer ser det imidlertid ut til å være riktig.
            // Løfter litt logikk fra LLDBs kilde, har den noen spesiell foringsrør for den første `__TEXT`-seksjonen lastet fra filforskyvning 0 med en ikke-null størrelse.
            // Uansett av hvilken grunn når dette er til stede ser det ut til å bety at symboltabellen er i forhold til bare vmaddr-lysbildet for biblioteket.
            // Hvis den *ikke* er til stede, er symboltabellen i forhold til vmaddr-lysbildet pluss segmentets oppgitte adresse.
            //
            // For å håndtere denne situasjonen hvis vi *ikke* finner en tekstseksjon ved filforskyvning null, øker vi forspenningen med de første tekstseksjonenes oppgitte adresse og reduserer også alle oppgitte adresser med det beløpet.
            //
            // På den måten vises alltid symboltabellen i forhold til bibliotekets forspenningsbeløp.
            // Dette ser ut til å ha de riktige resultatene for symbolisering via symboltabellen.
            //
            // Ærlig talt er jeg ikke helt sikker på om dette er riktig, eller om det er noe annet som skal indikere hvordan du gjør dette.
            // Foreløpig synes dette å fungere godt nok (?), og vi bør alltid kunne justere dette over tid om nødvendig.
            //
            // For mer informasjon, se #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Annet Unix (f.eks
        // Linux) plattformer bruker ELF som et objektfilformat og implementerer vanligvis en API kalt `dl_iterate_phdr` for å laste innfødte biblioteker.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` bør være en gyldig pekepinn.
        // `vec` skal være en gyldig peker til en `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 støtter ikke naturlig feilsøkingsinformasjon, men byggesystemet vil plassere feilsøkingsinformasjon på banen `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Alt annet skal bruke ELF, men vet ikke hvordan man skal laste innfødte biblioteker.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Alle kjente delte biblioteker som er lastet inn.
    libraries: Vec<Library>,

    /// Kartlegginger cache der vi lagrer informasjon om analysert dverg.
    ///
    /// Denne listen har en fast kapasitet for hele kjøretiden som aldri øker.
    /// `usize`-elementet i hvert par er en indeks i `libraries` over der `usize::max_value()` representerer den gjeldende kjørbare filen.
    ///
    /// `Mapping` er tilsvarende analysert dverginformasjon.
    ///
    /// Merk at dette i utgangspunktet er en LRU-hurtigbuffer, og vi flytter ting rundt her når vi symboliserer adresser.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Deler av dette biblioteket lastet inn i minnet, og hvor de er lastet.
    segments: Vec<LibrarySegment>,
    /// "bias" i dette biblioteket, vanligvis der det er lastet inn i minnet.
    /// Denne verdien legges til hvert segments oppgitte adresse for å få den faktiske virtuelle minneadressen som segmentet er lastet inn i.
    /// I tillegg trekkes denne skjevheten fra ekte virtuelle minneadresser for å indeksere til debuginfo og symboltabellen.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Den oppgitte adressen til dette segmentet i objektfilen.
    /// Dette er faktisk ikke hvor segmentet er lastet, men heller denne adressen pluss det inneholder bibliotekets `bias` er hvor du finner den.
    ///
    stated_virtual_memory_address: usize,
    /// Størrelsen på dette segmentet i minnet.
    len: usize,
}

// usikre fordi dette kreves for å være synkronisert eksternt
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // usikre fordi dette kreves for å være synkronisert eksternt
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // En veldig liten, veldig enkel LRU-cache for feilsøking av informasjonskartlegginger.
        //
        // Treffraten bør være veldig høy, siden den typiske stakken ikke krysser mellom mange delte biblioteker.
        //
        // `addr2line::Context`-strukturene er ganske dyre å lage.
        // Kostnadene forventes å bli amortisert av påfølgende `locate`-spørsmål, som utnytter strukturene som ble bygget når du konstruerer `addr2line: : Context`s for å få fine hastigheter.
        //
        // Hvis vi ikke hadde denne hurtigbufferen, ville amortiseringen aldri skje, og det å symbolisere tilbakesporinger ville være ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Test først om denne `lib` har noe segment som inneholder `addr` (håndtering av flytting).Hvis denne kontrollen går, kan vi fortsette nedenfor og faktisk oversette adressen.
                //
                // Merk at vi bruker `wrapping_add` her for å unngå overløpskontroller.Det har blitt sett i naturen at SVMA + biasberegning renner over.
                // Det virker litt rart at det ville skje, men det er ikke så mye vi kan gjøre med det annet enn å sannsynligvis bare ignorere disse segmentene, siden de sannsynligvis peker ut i verdensrommet.
                //
                // Dette kom opprinnelig opp i rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Nå som vi vet at `lib` inneholder `addr`, kan vi kompensere med skjevheten for å finne den oppgitte virutale minneadressen.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: etter denne betingede fullføringen uten tidlig retur
        // fra en feil er hurtigbufferoppføringen for denne banen i indeks 0.

        if let Some(idx) = idx {
            // Når kartleggingen allerede er i hurtigbufferen, flytt den til fronten.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Når kartleggingen ikke er i hurtigbufferen, oppretter du en ny kartlegging, setter den inn foran på hurtigbufferen og kaster den eldste hurtigbufferoppføringen om nødvendig.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ikke lek `'static`-levetiden, sørg for at den er tilpasset bare oss selv
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Forleng levetiden til `sym` til `'static`, siden vi dessverre er pålagt å komme hit, men det går alltid ut som en referanse, så ingen henvisning til den skal uansett fortsette utover denne rammen.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Til slutt, få en hurtigbufret kartlegging eller opprett en ny kartlegging for denne filen, og evaluer DWARF-informasjonen for å finne file/line/name for denne adressen.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Vi var i stand til å finne rammeinformasjon for dette symbolet, og `addr2line`s ramme har internt alle de smarte detaljene.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Fant ikke feilsøkingsinformasjon, men vi fant den i symboltabellen til den kjørbare alven.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}