use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Representasjon av et eid og selvstendig bakspor.
///
/// Denne strukturen kan brukes til å fange en backtrace på forskjellige punkter i et program og senere brukes til å inspisere hva backtrace var på den tiden.
///
///
/// `Backtrace` støtter pen utskrift av backtraces gjennom `Debug`-implementeringen.
///
/// # Nødvendige funksjoner
///
/// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Rammer her er oppført fra topp til bunn av bunken
    frames: Vec<BacktraceFrame>,
    // Indeksen vi tror er den faktiske starten på tilbakesporingen, og utelater rammer som `Backtrace::new` og `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Hentet versjon av en ramme i et bakspor.
///
/// Denne typen returneres som en liste fra `Backtrace::frames` og representerer en stabelramme i et fanget bakspor.
///
/// # Nødvendige funksjoner
///
/// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Hentet versjon av et symbol i et bakspor.
///
/// Denne typen returneres som en liste fra `BacktraceFrame::symbols` og representerer metadataene for et symbol i et bakspor.
///
/// # Nødvendige funksjoner
///
/// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Fanger et tilbakespor på samtalen til denne funksjonen, og returnerer en eid representasjon.
    ///
    /// Denne funksjonen er nyttig for å representere et bakspor som et objekt i Rust.Denne returnerte verdien kan sendes over tråder og skrives ut andre steder, og formålet med denne verdien er å være helt selvforsynt.
    ///
    /// Vær oppmerksom på at på noen plattformer kan det være ekstremt dyrt å anskaffe en full backtrace og løse det.
    /// Hvis kostnadene er for høye for applikasjonen din, anbefales det å bruke `Backtrace::new_unresolved()` i stedet for å unngå trinn for symboloppløsning (som vanligvis tar lengst tid) og tillate utsettelse til en senere dato.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // vil sørge for at det er en ramme her å fjerne
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// I likhet med `new`, bortsett fra at dette ikke løser noen symboler, fanger dette ganske enkelt baksporet som en liste over adresser.
    ///
    /// På et senere tidspunkt kan `resolve`-funksjonen kalles for å løse symbolene for dette baksporet til lesbare navn.
    /// Denne funksjonen eksisterer fordi oppløsningsprosessen noen ganger kan ta lang tid, mens en hvilken som helst backtrace bare sjelden kan skrives ut.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ingen symbolnavn
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // symbolnavn nå til stede
    /// ```
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    ///
    ///
    #[inline(never)] // vil sørge for at det er en ramme her å fjerne
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Returnerer rammene fra da denne baksporet ble fanget.
    ///
    /// Den første oppføringen av denne delen er sannsynligvis funksjonen `Backtrace::new`, og den siste rammen er sannsynligvis noe om hvordan denne tråden eller hovedfunksjonen startet.
    ///
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Hvis denne backtrace ble opprettet fra `new_unresolved`, vil denne funksjonen løse alle adressene i backtrace til deres symbolske navn.
    ///
    ///
    /// Hvis denne tilbakesporingen tidligere er løst eller ble opprettet gjennom `new`, gjør denne funksjonen ingenting.
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Samme som `Frame::ip`
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Samme som `Frame::symbol_address`
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Samme som `Frame::module_base_address`
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Returnerer listen over symboler som denne rammen tilsvarer.
    ///
    /// Normalt er det bare ett symbol per ramme, men noen ganger vil flere symboler returneres hvis et antall funksjoner er inline i en ramme.
    /// Det første oppførte symbolet er "innermost function", mens det siste symbolet er det ytterste (siste innringeren).
    ///
    /// Merk at hvis denne rammen kommer fra et uløst tilbakespor, vil dette returnere en tom liste.
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Samme som `Symbol::name`
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Samme som `Symbol::addr`
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Samme som `Symbol::filename`
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Samme som `Symbol::lineno`
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Samme som `Symbol::colno`
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Når du skriver ut stier prøver vi å strippe cwd hvis den finnes, ellers skriver vi bare ut stien som den er.
        // Merk at vi også bare gjør dette for kortformatet, for hvis det er fullt, vil vi antagelig skrive ut alt.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}