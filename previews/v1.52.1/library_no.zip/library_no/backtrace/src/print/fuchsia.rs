use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr tar en tilbakeringing som vil motta en dl_phdr_info-peker for hver DSO som er koblet til prosessen.
    // dl_iterate_phdr sørger også for at den dynamiske linkeren er låst fra begynnelse til slutt av iterasjonen.
    // Hvis tilbakeringingen returnerer en verdi som ikke er null, avsluttes iterasjonen tidlig.
    // 'data' vil bli sendt som det tredje argumentet for tilbakeringingen ved hver samtale.
    // 'size' gir størrelsen på dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Vi må analysere bygge-ID og noen grunnleggende programoverskriftsdata, noe som betyr at vi også trenger litt ting fra ELF-spesifikasjonen.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nå må vi replikere, litt for bit, strukturen til typen dl_phdr_info som brukes av fuchsias nåværende dynamiske linker.
// Chromium har også denne ABI-grensen, samt crashpad.
// Til slutt vil vi flytte disse sakene for å bruke alvesøk, men vi må oppgi det i SDK og det er ennå ikke gjort.
//
// Dermed sitter vi (og de) fast med å måtte bruke denne metoden som medfører en tett kobling med fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Vi har ingen måte å vite om e_phoff og e_phnum er gyldige.
    // libc bør sikre dette for oss, men så det er trygt å danne et stykke her.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr representerer en 64-bit ELF-programhode i slutten av målarkitekturen.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr representerer et gyldig ELF-programoverskrift og innholdet.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Vi har ingen måte å sjekke om p_addr eller p_memsz er gyldige.
    // Fuchsia's libc analyserer først notatene, så i kraft av å være her må disse overskriftene være gyldige.
    //
    // NoteIter krever ikke at de underliggende dataene er gyldige, men det krever at grensene er gyldige.
    // Vi stoler på at libc har sørget for at dette er tilfelle for oss her.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Merknadstypen for bygge-ID-er.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr representerer en ELF-notatoverskrift i målets slutt.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Notatet representerer et ELF-notat (overskrift + innhold).
// Navnet er igjen som et u8-stykke fordi det ikke alltid er null avsluttet, og rust gjør det enkelt å sjekke at byte samsvarer med en eller annen måte.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter lar deg trygt itere over et notatsegment.
// Den avsluttes så snart en feil oppstår eller det ikke er flere notater.
// Hvis du gjentar over ugyldige data, vil den fungere som om det ikke ble funnet noen notater.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Det er en uforanderlig funksjon at pekeren og størrelsen som er gitt, betegner et gyldig utvalg av byte som alle kan leses.
    // Innholdet i disse bytene kan være alt annet enn området må være gyldig for at dette skal være trygt.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to justerer 'x' til 'to'-byte-justering forutsatt at 'to' er en styrke på 2.
// Dette følger et standard mønster i C/C ++ ELF-parsingskode der (x + til, 1) og -to brukes.
// Rust lar deg ikke benekte bruk, så jeg bruker
// 2-komplement konvertering for å gjenskape det.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 forbruker antall byte fra stykket (hvis det er tilstede) og sørger i tillegg for at den endelige delen er riktig justert.
// Hvis enten antall byte som er forespurt er for stort, eller hvis stykket ikke kan justeres etterpå på grunn av at det ikke er nok gjenværende byte, returneres ingen, og segmentet blir ikke endret.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Denne funksjonen har ingen reelle invarianter som innringeren må opprettholde, bortsett fra at 'bytes' skal justeres for ytelse (og på noen arkitektoniske korrektheter).
// Verdiene i Elf_Nhdr-feltene kan være tull, men denne funksjonen sikrer ikke noe slikt.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Dette er trygt så lenge det er nok plass, og vi bekreftet at i uttalelsen ovenfor, slik at dette ikke skal være utrygt.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Merk at sice_of: :<Elf_Nhdr>() er alltid 4-byte-justert.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Sjekk om vi har nådd slutten.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Vi overfører en nhdr, men vi vurderer nøye den resulterende strukturen.
        // Vi stoler ikke på namesz eller descsz, og vi tar ingen usikre beslutninger basert på typen.
        //
        // Så selv om vi får ut fullstendig søppel, bør vi fortsatt være trygge.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indikerer at et segment er kjørbart.
const PERM_X: u32 = 0b00000001;
/// Indikerer at et segment er skrivbart.
const PERM_W: u32 = 0b00000010;
/// Indikerer at et segment er lesbart.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Representerer et ELF-segment ved kjøretid.
struct Segment {
    /// Gir den virtuelle kjøretidsadressen til innholdet i dette segmentet.
    addr: usize,
    /// Gir minnestørrelsen på dette segmentets innhold.
    size: usize,
    /// Gir modulens virtuelle adresse til dette segmentet med ELF-filen.
    mod_rel_addr: usize,
    /// Gir tillatelsene som finnes i ELF-filen.
    /// Disse tillatelsene er ikke nødvendigvis tillatelsene som er tilstede under kjøretid.
    flags: Perm,
}

/// Lar en iterere over segmenter fra en DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Representerer en ELF DSO (Dynamic Shared Object).
/// Denne typen refererer til dataene som er lagret i selve DSO i stedet for å lage en egen kopi.
struct Dso<'a> {
    /// Den dynamiske linkeren gir oss alltid et navn, selv om navnet er tomt.
    /// Når det gjelder den viktigste kjørbare filen, vil dette navnet være tomt.
    /// Når det gjelder et delt objekt, vil det være sonamnet (se DT_SONAME).
    name: &'a str,
    /// På Fuchsia har nesten alle binærfiler ID-er, men dette er ikke en streng forespørsel.
    /// Det er ingen måte å matche DSO-informasjon med en ekte ELF-fil etterpå hvis det ikke er build_id, så vi krever at hver DSO har en her.
    ///
    /// DSO uten build_id ignoreres.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Returnerer en iterator over segmenter i denne DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Disse feilene koder for problemer som oppstår under informasjonen om hver DSO.
///
enum Error {
    /// NameError betyr at det oppstod en feil under konvertering av en C-stilstreng til en rust-streng.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError betyr at vi ikke fant en bygge-ID.
    /// Dette kan enten være fordi DSO ikke hadde noen build-ID, eller fordi segmentet som inneholder build-ID var feil.
    ///
    BuildIDError,
}

/// Ringer enten 'dso' eller 'error' for hver DSO som er koblet til prosessen av den dynamiske linkeren.
///
///
/// # Arguments
///
/// * `visitor` - En DsoPrinter som vil ha en av spisemetodene som kalles for hver DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr sørger for at info.name vil peke på et gyldig sted.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Denne funksjonen skriver ut Fuchsia-symboliseringsmarkeringen for all informasjon i en DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}