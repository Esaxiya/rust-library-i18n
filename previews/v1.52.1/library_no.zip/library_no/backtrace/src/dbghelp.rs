//! En modul som hjelper deg med å administrere dbghelp-bindinger på Windows
//!
//! Backtraces på Windows (i det minste for MSVC) drives i stor grad gjennom `dbghelp.dll` og de forskjellige funksjonene den inneholder.
//! Disse funksjonene er for øyeblikket lastet *dynamisk* i stedet for å lenke til `dbghelp.dll` statisk.
//! Dette gjøres for øyeblikket av standardbiblioteket (og er i teorien nødvendig der), men er et forsøk på å redusere de statiske dll-avhengighetene til et bibliotek, siden tilbakesporinger vanligvis er ganske valgfrie.
//!
//! Når det er sagt, lastes `dbghelp.dll` nesten alltid vellykket på Windows.
//!
//! Vær oppmerksom på at siden vi laster inn all denne støtten dynamisk, kan vi faktisk ikke bruke rådefinisjonene i `winapi`, men vi må heller definere funksjonstypene selv og bruke den.
//! Vi vil egentlig ikke være i gang med å duplisere winapi, så vi har en Cargo-funksjon `verify-winapi` som hevder at alle bindinger samsvarer med de i winapi, og denne funksjonen er aktivert på CI.
//!
//! Til slutt vil du merke deg at dll for `dbghelp.dll` aldri blir lastet ut, og det er foreløpig forsettlig.
//! Tanken er at vi globalt kan cache den og bruke den mellom samtaler til API, og unngå dyre loads/unloads.
//! Hvis dette er et problem for lekkasjedetektorer eller noe sånt, kan vi krysse broen når vi kommer dit.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Arbeid rundt `SymGetOptions` og `SymSetOptions` som ikke er tilstede i selve winapi.
// Ellers brukes dette bare når vi dobbeltsjekker typer mot winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ikke definert i winapi ennå
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Dette er definert i winapi, men det er feil (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ikke definert i winapi ennå
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Denne makroen brukes til å definere en `Dbghelp`-struktur som internt inneholder alle funksjonspekerne vi kan laste inn.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Den lastede DLL-en for `dbghelp.dll`
            dll: HMODULE,

            // Hver funksjonspeker for hver funksjon vi kan bruke
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Opprinnelig har vi ikke lastet inn DLL
            dll: 0 as *mut _,
            // Start alle funksjonene er satt til null for å si at de må lastes dynamisk.
            //
            $($name: 0,)*
        };

        // Komfort typedef for hver funksjonstype.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Forsøk på å åpne `dbghelp.dll`.
            /// Returnerer suksess hvis det fungerer eller feil hvis `LoadLibraryW` mislykkes.
            ///
            /// Panics hvis biblioteket allerede er lastet.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funksjon for hver metode vi vil bruke.
            // Når den kalles, vil den enten lese hurtigbufrede funksjonspekere eller laste den inn og returnere den lastede verdien.
            // Belastninger hevdes å lykkes.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Bekvem proxy for å bruke oppryddingslåsene for å referere til dbghelp-funksjoner.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialiser all støtte som er nødvendig for å få tilgang til `dbghelp` API-funksjoner fra denne crate.
///
///
/// Merk at denne funksjonen er **trygg**, den har sin egen synkronisering internt.
/// Vær også oppmerksom på at det er trygt å ringe denne funksjonen flere ganger rekursivt.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Det første vi må gjøre er å synkronisere denne funksjonen.Dette kan kalles samtidig fra andre tråder eller rekursivt innenfor en tråd.
        // Merk at det er vanskeligere enn det, fordi det vi bruker her, `dbghelp`,*også* må synkroniseres med alle andre innringere til `dbghelp` i denne prosessen.
        //
        // Vanligvis er det egentlig ikke så mange anrop til `dbghelp` i samme prosess, og vi kan sannsynligvis trygt anta at vi er de eneste som får tilgang til det.
        // Det er imidlertid en primær annen bruker vi trenger å bekymre oss for som ironisk nok er oss selv, men i standardbiblioteket.
        // Rust-standardbiblioteket er avhengig av denne crate for støtte for tilbakesporing, og denne crate finnes også på crates.io.
        // Dette betyr at hvis standardbiblioteket skriver ut en panic backtrace, kan det kjøre med denne crate som kommer fra crates.io, og forårsake segfeil.
        //
        // For å løse dette synkroniseringsproblemet bruker vi et Windows-spesifikt triks her (det er tross alt en Windows-spesifikk begrensning om synkronisering).
        // Vi oppretter en *økt-lokal* med navnet mutex for å beskytte denne samtalen.
        // Intensjonen her er at standardbiblioteket og denne crate ikke trenger å dele Rust-nivå APIer for å synkronisere her, men i stedet kan jobbe bak kulissene for å sikre at de synkroniserer med hverandre.
        //
        // På den måten når denne funksjonen kalles gjennom standardbiblioteket eller gjennom crates.io, kan vi være sikre på at den samme mutex blir anskaffet.
        //
        // Så alt dette er å si at det første vi gjør her er at vi atomisk oppretter en `HANDLE` som er en kalt mutex på Windows.
        // Vi synkroniserer litt med andre tråder som deler denne funksjonen spesifikt, og sørger for at bare ett håndtak blir opprettet per forekomst av denne funksjonen.
        // Merk at håndtaket aldri lukkes når det er lagret i det globale.
        //
        // Etter at vi faktisk har gått i låsen, skaffer vi oss den, og `Init`-håndtaket vi deler ut, er ansvarlig for å slippe den til slutt.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, pøss!Nå som vi alle er trygt synkronisert, la oss faktisk begynne å behandle alt.
        // Først må vi sørge for at `dbghelp.dll` faktisk lastes inn i denne prosessen.
        // Vi gjør dette dynamisk for å unngå statisk avhengighet.
        // Dette har historisk blitt gjort for å omgå rare koblingsproblemer, og er ment å gjøre binærfiler litt mer bærbare, siden dette stort sett bare er et feilsøkingsverktøy.
        //
        //
        // Når vi har åpnet `dbghelp.dll`, må vi kalle noen initialiseringsfunksjoner i den, og det er detaljert mer nedenfor.
        // Vi gjør dette bare en gang, skjønt, så vi har en global boolean som indikerer om vi er ferdige ennå eller ikke.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Forsikre deg om at `SYMOPT_DEFERRED_LOADS`-flagget er satt, for ifølge MSVCs egne dokumenter om dette: "This is the fastest, most efficient way to use the symbol handler.", så la oss gjøre det!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Initialiser faktisk symboler med MSVC.Merk at dette kan mislykkes, men vi ignorerer det.
        // Det er ikke massevis av kjent teknikk for dette i seg selv, men LLVM ser ut til å ignorere returverdien her, og et av desinfiseringsbibliotekene i LLVM skriver ut en skummel advarsel hvis dette mislykkes, men i utgangspunktet ignorerer det i det lange løp.
        //
        //
        // Et tilfelle dette kommer opp for Rust er at standardbiblioteket og denne crate på crates.io begge vil konkurrere om `SymInitializeW`.
        // Standardbiblioteket ønsket historisk å initialisere deretter opprydding mesteparten av tiden, men nå som det bruker denne crate, betyr det at noen først kommer til initialisering og den andre vil plukke opp den initialiseringen.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}