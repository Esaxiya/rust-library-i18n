#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// En formatering for tilbakesporinger.
///
/// Denne typen kan brukes til å skrive ut en backtrace uavhengig av hvor selve backtrace kommer fra.
/// Hvis du har en `Backtrace`-type, bruker `Debug`-implementeringen allerede dette utskriftsformatet.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Utskriftsstilene vi kan skrive ut
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Skriver ut en terser backtrace som ideelt sett bare inneholder relevant informasjon
    Short,
    /// Skriver ut en backtrace som inneholder all mulig informasjon
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Opprett en ny `BacktraceFmt` som vil skrive utdata til den medfølgende `fmt`.
    ///
    /// `format`-argumentet vil kontrollere stilen der baksporet skrives ut, og `print_path`-argumentet vil bli brukt til å skrive ut `BytesOrWideString`-forekomster av filnavn.
    /// Denne typen i seg selv gjør ikke utskrift av filnavn, men denne tilbakeringingen er nødvendig for å gjøre det.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Skriver ut en innledning for baksporet som skal skrives ut.
    ///
    /// Dette er nødvendig på enkelte plattformer for at backtraces skal være fullt symbolisert senere, og ellers bør dette bare være den første metoden du ringer etter å ha opprettet en `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Legger til en ramme i backtrace-utgangen.
    ///
    /// Denne forpliktelsen returnerer en RAII-forekomst av en `BacktraceFrameFmt` som kan brukes til å faktisk skrive ut en ramme, og ved ødeleggelse øker den rammetelleren.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Fullfører backtrace-utgangen.
    ///
    /// Dette er for øyeblikket en no-op, men er lagt til for future-kompatibilitet med backtrace-formater.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Foreløpig en no-op-- inkludert denne hook for å tillate future tillegg.
        Ok(())
    }
}

/// En formatering for bare en ramme av et bakspor.
///
/// Denne typen er opprettet av `BacktraceFmt::frame`-funksjonen.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Skriver ut en `BacktraceFrame` med denne rammeformatøren.
    ///
    /// Dette vil rekursivt skrive ut alle `BacktraceSymbol`-forekomster i `BacktraceFrame`.
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Skriver ut en `BacktraceSymbol` i en `BacktraceFrame`.
    ///
    /// # Nødvendige funksjoner
    ///
    /// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: dette er ikke bra at vi ikke ender med å skrive ut noe
            // med ikke-utf8 filnavn.
            // Heldigvis er nesten alt utf8, så dette skal ikke være så ille.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Skriver ut en rå sporet `Frame` og `Symbol`, vanligvis fra de rå tilbakeringingene til denne crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Legger til en rå ramme i backtrace-utgangen.
    ///
    /// Denne metoden tar, i motsetning til den forrige, råargumentene i tilfelle de kommer fra forskjellige steder.
    /// Merk at dette kan kalles flere ganger for en ramme.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Legger til en rå ramme i backtrace-utgangen, inkludert kolonneinformasjon.
    ///
    /// Denne metoden, som den forrige, tar de rå argumentene i tilfelle de kommer fra forskjellige steder.
    /// Merk at dette kan kalles flere ganger for en ramme.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia kan ikke symbolisere i en prosess, så det har et spesielt format som kan brukes til å symbolisere senere.
        // Skriv ut det i stedet for å skrive ut adresser i vårt eget format her.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Ingen grunn til å skrive ut "null"-rammer, det betyr i utgangspunktet bare at systemets tilbakesporing var litt ivrig etter å spore super langt tilbake.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // For å redusere TCB-størrelse i Sgx-enklave, ønsker vi ikke å implementere symboloppløsningsfunksjonalitet.
        // Snarere kan vi skrive ut forskyvningen av adressen her, som senere kan kartlegges for å fungere korrekt.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Skriv ut indeksen på rammen samt den valgfrie instruksjonspekeren på rammen.
        // Hvis vi er utenfor det første symbolet på denne rammen, skriver vi bare ut passende mellomrom.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Deretter skriver du ut symbolnavnet ved hjelp av alternativ formatering for mer informasjon hvis vi er en full backtrace.
        // Her håndterer vi også symboler som ikke har navn,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Og sist, skriv ut filename/line-nummeret hvis det er tilgjengelig.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line er skrevet ut på linjer under symbolnavnet, så skriv ut et passende mellomrom for å rette oss opp.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegere til vår interne tilbakeringing for å skrive ut filnavnet og deretter skrive ut linjenummeret.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Legg til kolonnenummer, hvis tilgjengelig.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Vi bryr oss bare om det første symbolet på en ramme
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}