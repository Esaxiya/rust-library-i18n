use core::ffi::c_void;
use core::fmt;

/// Inspiserer den gjeldende samtalestakken, og sender alle aktive rammer inn i lukkingen som er gitt for å beregne en stakksporing.
///
/// Denne funksjonen er arbeidshesten til dette biblioteket ved beregning av stablespor for et program.Den gitte lukkingen `cb` er eksempler på en `Frame` som representerer informasjon om den samtalerammen på bunken.
/// Lukkingen gir rammer på en top-down måte (sist kalt funksjoner først).
///
/// Nedleggelsens returverdi er en indikasjon på om tilbakesporingen skal fortsette.En returverdi på `false` vil avslutte tilbakesporingen og returnere umiddelbart.
///
/// Når en `Frame` er anskaffet, vil du sannsynligvis ringe `backtrace::resolve` for å konvertere `ip` (instruksjonspeker) eller symboladresse til en `Symbol` som navnet og/eller filnavnet/linjenummeret kan læres gjennom.
///
///
/// Merk at dette er en relativt lavt nivå-funksjon, og hvis du for eksempel vil fange et tilbakesporingsbilde som skal inspiseres senere, kan `Backtrace`-typen være mer passende.
///
/// # Nødvendige funksjoner
///
/// Denne funksjonen krever at `std`-funksjonen til `backtrace` crate er aktivert, og `std`-funksjonen er aktivert som standard.
///
/// # Panics
///
/// Denne funksjonen prøver å aldri panic, men hvis `cb` ga panics, vil noen plattformer tvinge en dobbel panic til å avbryte prosessen.
/// Noen plattformer bruker et C-bibliotek som internt bruker tilbakeringinger som ikke kan spoles gjennom, så panikk fra `cb` kan utløse en prosessavbrudd.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // fortsett tilbakesporingen
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Samme som `trace`, bare usikkert da det er usynkronisert.
///
/// Denne funksjonen har ikke synkroniseringsgarantier, men er tilgjengelig når `std`-funksjonen til denne crate ikke er kompilert i.
/// Se `trace`-funksjonen for mer dokumentasjon og eksempler.
///
/// # Panics
///
/// Se informasjon på `trace` for advarsler om `cb`-panikk.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// En trait som representerer en ramme av en backtrace, ga `trace`-funksjonen til denne crate.
///
/// Sporingsfunksjonens lukking vil gi rammer, og rammen blir praktisk talt sendt, ettersom den underliggende implementeringen ikke alltid er kjent før kjøretiden.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Returnerer gjeldende instruksjonspeker for denne rammen.
    ///
    /// Dette er normalt neste instruksjon som skal utføres i rammen, men ikke alle implementeringer viser dette med 100% nøyaktighet (men det er generelt ganske nært).
    ///
    ///
    /// Det anbefales å overføre denne verdien til `backtrace::resolve` for å gjøre den om til et symbolnavn.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Returnerer gjeldende stakkpeker for denne rammen.
    ///
    /// I tilfelle at en backend ikke kan gjenopprette stackepekeren for denne rammen, returneres en nullpeker.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Returnerer startsymboladressen til rammen til denne funksjonen.
    ///
    /// Dette vil prøve å spole tilbake instruksjonspekeren som returneres av `ip` til starten av funksjonen, og returnere den verdien.
    ///
    /// I noen tilfeller vil imidlertid backender bare returnere `ip` fra denne funksjonen.
    ///
    /// Den returnerte verdien kan noen ganger brukes hvis `backtrace::resolve` mislyktes på `ip` gitt ovenfor.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Returnerer baseadressen til modulen som rammen tilhører.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Dette må komme først, for å sikre at Miri prioriterer vertsplattformen
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // bare brukt i dbghelp symboliserer
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}