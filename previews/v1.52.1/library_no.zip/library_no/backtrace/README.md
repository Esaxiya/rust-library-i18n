# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Et bibliotek for anskaffelse av tilbakesporinger ved kjøretid for Rust.
Dette biblioteket tar sikte på å forbedre støtten til standardbiblioteket ved å tilby et programmatisk grensesnitt å jobbe med, men det støtter også ganske enkelt å skrive ut den nåværende tilbakesporingen, som libstds panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

For å bare fange et tilbakespor og utsette å håndtere det til et senere tidspunkt, kan du bruke `Backtrace`-typen på toppnivå.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Hvis du imidlertid ønsker mer rå tilgang til den faktiske sporingsfunksjonaliteten, kan du bruke funksjonene `trace` og `resolve` direkte.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Løs denne instruksjonspekeren til et symbolnavn
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // fortsett til neste ramme
    });
}
```

# License

Dette prosjektet er lisensiert under en av

 * Apache Lisens, versjon 2.0, ([LICENSE-APACHE](LICENSE-APACHE) eller http://www.apache.org/licenses/LICENSE-2.0)
 * MIT-lisens ([LICENSE-MIT](LICENSE-MIT) eller http://opensource.org/licenses/MIT)

etter eget valg.

### Contribution

Med mindre du uttrykkelig oppgir noe annet, skal ethvert bidrag med vilje sendt inn for inkludering i backtrace-r av deg, som definert i Apache-2.0-lisensen, være dobbel lisensiert som ovenfor, uten ytterligere vilkår eller betingelser.







