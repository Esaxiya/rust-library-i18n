//! Windows SEH
//!
//! På Windows (foreløpig bare på MSVC) er standard unntakshåndteringsmekanisme Structured Exception Handling (SEH).
//! Dette er ganske annerledes enn dvergbasert unntakshåndtering (f.eks. Hva andre unix-plattformer bruker) når det gjelder kompilatorinterne, så det kreves at LLVM har mye ekstra støtte for SEH.
//!
//! I et nøtteskall er det som skjer her:
//!
//! 1. `panic`-funksjonen kaller standard Windows-funksjonen `_CxxThrowException` for å kaste et C++ -som unntak, som utløser avviklingsprosessen.
//! 2.
//! Alle landingsplater generert av kompilatoren bruker personlighetsfunksjonen `__CxxFrameHandler3`, en funksjon i CRT, og avkoblingskoden i Windows vil bruke denne personlighetsfunksjonen til å utføre all oppryddingskode på bunken.
//!
//! 3. Alle kompilergenererte samtaler til `invoke` har en landingsplass satt som en `cleanuppad` LLVM-instruksjon, som indikerer starten på oppryddingsrutinen.
//! Personligheten (i trinn 2, definert i CRT) er ansvarlig for å kjøre oppryddingsrutinene.
//! 4. Til slutt blir "catch"-koden i `try` iboende (generert av kompilatoren) utført og indikerer at kontrollen skal komme tilbake til Rust.
//! Dette gjøres via en `catchswitch` pluss en `catchpad`-instruksjon i LLVM IR-termer, og til slutt returnerer normal kontroll til programmet med en `catchret`-instruksjon.
//!
//! Noen spesifikke forskjeller fra den gcc-baserte unntakshåndteringen er:
//!
//! * Rust har ingen tilpasset personlighetsfunksjon, det er i stedet *alltid*`__CxxFrameHandler3`.I tillegg utføres ingen ekstra filtrering, så vi ender opp med C++ unntak som tilfeldigvis ser ut som den typen vi kaster.
//! Merk at å kaste et unntak i Rust er udefinert oppførsel uansett, så dette skal være greit.
//! * Vi har noen data å overføre over avviklingsgrensen, spesielt en `Box<dyn Any + Send>`.Som med unntak av dverg lagres disse to pekerne som en nyttelast i unntaket selv.
//! På MSVC er det imidlertid ikke behov for en ekstra haugetildeling fordi samtalestakken bevares mens filterfunksjonene blir utført.
//! Dette betyr at pekerne blir sendt direkte til `_CxxThrowException` som deretter gjenopprettes i filterfunksjonen som skal skrives til stabelrammen til `try` iboende.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Dette må være et alternativ fordi vi fanger unntaket ved referanse og destruktoren utføres av C++ kjøretid.
    // Når vi tar boksen ut av unntaket, må vi la unntaket være i en gyldig tilstand for at destruktoren skal kjøre uten å dobbeltkaste boksen.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Først opp, en hel haug med typedefinisjoner.Det er noen plattformspesifikke rariteter her, og mye som bare er åpenbart kopiert fra LLVM.Hensikten med alt dette er å implementere `panic`-funksjonen nedenfor gjennom en samtale til `_CxxThrowException`.
//
// Denne funksjonen tar to argumenter.Den første er en peker til dataene vi sender inn, som i dette tilfellet er vårt trait-objekt.Ganske enkelt å finne!Den neste er imidlertid mer komplisert.
// Dette er en peker til en `_ThrowInfo`-struktur, og den er generelt bare ment å bare beskrive unntaket som kastes.
//
// For tiden er definisjonen av denne typen [1] litt hårete, og den viktigste rare (og forskjellen fra den elektroniske artikkelen) er at på 32-bit er pekerne pekere, men på 64-bit er pekerne uttrykt som 32-bit forskyvninger fra `__ImageBase` symbol.
//
// `ptr_t`-og `ptr!`-makroen i modulene nedenfor brukes til å uttrykke dette.
//
// Labyrinten av typedefinisjoner følger også nøye med på hva LLVM avgir for denne typen operasjoner.Hvis du for eksempel kompilerer denne C++ -koden på MSVC og sender ut LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ugyldig foo() { rust_panic a = {0, 1};
//          kaste en;}
//
// Det er egentlig det vi prøver å etterligne.De fleste av de konstante verdiene nedenfor ble nettopp kopiert fra LLVM,
//
// I alle fall er disse konstruksjonene konstruert på en lignende måte, og det er bare noe ordentlig for oss.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Merk at vi med vilje ignorerer regler for navnemangling her: vi vil ikke at C++ skal kunne fange Rust panics ved ganske enkelt å erklære en `struct rust_panic`.
//
//
// Når du endrer, må du sørge for at typenavnstrengen stemmer overens med den som ble brukt i `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Den ledende `\x01`-byten her er faktisk et magisk signal til LLVM om å *ikke* bruke noe annet manglende som prefiks med et `_`-tegn.
    //
    //
    // Dette symbolet er tabellen som brukes av C++ `std::type_info`.
    // Objekter av typen `std::type_info`, typebeskrivere, har en peker til denne tabellen.
    // Typebeskrivere er referert av C++ EH-strukturene som er definert ovenfor, og som vi konstruerer nedenfor.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Denne type beskrivelsen brukes bare når du kaster et unntak.
// Fangsdelen håndteres av try intrinsic, som genererer sin egen TypeDescriptor.
//
// Dette er greit siden MSVC-kjøretiden bruker strengesammenligning på typenavnet for å matche TypeDescriptors i stedet for pekerlikhet.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor brukt hvis C++ -koden bestemmer seg for å fange unntaket og slippe det uten å forplante det.
// Fangsten av prøven iboende vil sette det første ordet i unntaksobjektet til 0 slik at det hoppes over av destruktoren.
//
// Merk at x86 Windows bruker "thiscall"-anropskonvensjonen for C++ -medlemfunksjoner i stedet for standard "C"-anropskonvensjon.
//
// Exception_copy-funksjonen er litt spesiell her: den påkalles av MSVC-kjøretiden under en try/catch-blokk, og panic som vi genererer her, vil bli brukt som resultat av unntakskopien.
//
// Dette brukes av C++ kjøretid for å støtte fange unntak med std::exception_ptr, som vi ikke kan støtte fordi Box<dyn Any>er ikke klonbar.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException kjøres helt på denne stablerammen, så det er ikke nødvendig å overføre `data` til haugen.
    // Vi sender bare en pekepeker til denne funksjonen.
    //
    // ManuallyDrop er nødvendig her, siden vi ikke vil at unntak skal slippes når du slapper av.
    // I stedet vil den bli droppet av exception_cleanup som påkalles av C++ kjøretid.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Dette ... kan virke overraskende, og med rette.På 32-biters MSVC er pekerne mellom disse strukturene bare det, pekere.
    // På 64-bit MSVC blir imidlertid pekerne mellom strukturer ganske uttrykt som 32-bits forskyvninger fra `__ImageBase`.
    //
    // Derfor kan vi på 32-bit MSVC erklære alle disse pekerne i `statisk` ovenfor.
    // På 64-bit MSVC må vi uttrykke subtraksjon av pekere i statikk, som Rust for øyeblikket ikke tillater, så vi kan faktisk ikke gjøre det.
    //
    // Det nest beste er å fylle ut disse strukturene ved kjøretid (panikk er allerede "slow path" uansett).
    // Så her tolker vi alle disse pekerfeltene på nytt som 32-biters heltall og lagrer deretter den relevante verdien i den (atomisk, siden samtidig panics kan skje).
    //
    // Teknisk sett vil kjøretiden sannsynligvis gjøre en ikke-atomisk lesing av disse feltene, men i teorien leser de aldri *feil* verdi, så det skal ikke være så ille ...
    //
    // I alle fall trenger vi i utgangspunktet å gjøre noe slikt til vi kan uttrykke flere operasjoner i statikk (og det kan vi kanskje aldri gjøre).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // En NULL nyttelast her betyr at vi kom hit fra fangsten (...) på __rust_try.
    // Dette skjer når et utenlandsk unntak som ikke er Rust blir fanget.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Dette kreves av kompilatoren for å eksistere (f.eks. Det er et lang element), men det kalles faktisk aldri av kompilatoren fordi __C_specific_handler eller_except_handler3 er personlighetsfunksjonen som alltid brukes.
//
// Derfor er dette bare en avbrutt stubbe.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}