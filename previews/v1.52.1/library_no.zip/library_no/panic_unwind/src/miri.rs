//! Avvikler panics for Miri.
use alloc::boxed::Box;
use core::any::Any;

// Type nyttelast som Miri-motoren forplanter seg ved å koble av for oss.
// Må være pekerstørrelse.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-gitt ekstern funksjon for å begynne å slappe av.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Nyttelasten vi overfører til `miri_start_panic` vil være nøyaktig argumentet vi får i `cleanup` nedenfor.
    // Så vi bokser det bare opp en gang for å få noe pekestørrelse.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Gjenopprett den underliggende `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}