//! Implementering av panics via stablingavvikling
//!
//! Denne crate er en implementering av panics i Rust ved hjelp av "most native" stakkavviklingsmekanisme for plattformen dette blir kompilert for.
//! Dette blir i hovedsak kategorisert i tre bøtter for tiden:
//!
//! 1. MSVC-mål bruker SEH i `seh.rs`-filen.
//! 2. Emscripten bruker C++ unntak i `emcc.rs`-filen.
//! 3. Alle andre mål bruker libunwind/libgcc i `gcc.rs`-filen.
//!
//! Mer dokumentasjon om hver implementering finner du i den respektive modulen.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` er ubrukt med Miri, så still advarsler.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust kjøretids oppstartsobjekter er avhengige av disse symbolene, så gjør dem offentlige.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Mål som ikke støtter avkobling.
        // - arch=wasm32
        // - os=ingen ("bare metal"-mål)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Bruk Miri-kjøretiden.
        // Vi må fortsatt også laste inn normal kjøretid ovenfor, da rustc forventer at visse langelementer derfra skal defineres.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Bruk den virkelige kjøretiden.
        use real_imp as imp;
    }
}

extern "C" {
    /// Behandler i libstd ringte når et panic-objekt slippes utenfor `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler i libstd ringte når et utenlandsk unntak blir fanget.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Inngangspunkt for å heve et unntak, bare delegerer til plattformspesifikk implementering.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}