use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Selv om denne funksjonen brukes på ett sted og implementeringen av den kunne være inline, gjorde de tidligere forsøkene på dette rustc langsommere:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Oppsett av en minneblokk.
///
/// En forekomst av `Layout` beskriver et bestemt minneoppsett.
/// Du bygger en `Layout` opp som en inngang for å gi til en tildeler.
///
/// Alle oppsett har en tilhørende størrelse og en power-of-two-justering.
///
/// (Merk at oppsett *ikke* kreves for å ha størrelse uten null, selv om `GlobalAlloc` krever at alle minneforespørsler ikke er null.
/// En innringer må enten sørge for at vilkår som dette er oppfylt, bruke spesifikke tildelere med løsere krav, eller bruke det mildere `Allocator`-grensesnittet.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // størrelsen på den forespurte minneblokken, målt i byte.
    size_: usize,

    // justering av den forespurte minneblokken, målt i byte.
    // vi sørger for at dette alltid er en power-of-two, fordi API-er som `posix_memalign` krever det, og det er en rimelig begrensning å pålegge Layout-konstruktører.
    //
    //
    // (Imidlertid krever vi ikke analogt `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Konstruerer en `Layout` fra en gitt `size` og `align`, eller returnerer `LayoutError` hvis noen av følgende betingelser ikke er oppfylt:
    ///
    /// * `align` må ikke være null,
    ///
    /// * `align` må være en kraft på to,
    ///
    /// * `size`, når den avrundes til nærmeste multiplum av `align`, må den ikke flyte over (dvs. den avrundede verdien må være mindre enn eller lik `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-two innebærer justering!=0.)

        // Avrundet størrelse er:
        //   size_rounded_up=(størrelse + juster, 1)&! (juster, 1);
        //
        // Vi vet ovenfra at justering!=0.
        // Hvis tilsetning (justering, 1) ikke flyter over, vil avrunding være greit.
        //
        // Omvendt vil&-maskering med! (Align, 1) trekke av bare småordensbiter.
        // Dermed hvis overløp oppstår med summen, kan ikke&-masken trekke nok til å angre overløpet.
        //
        //
        // Ovenfor antyder at det er nødvendig og tilstrekkelig å sjekke for summeringsoverløp.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SIKKERHET: forholdene for `from_size_align_unchecked` har vært
        // sjekket over.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Oppretter et oppsett, utenom alle kontroller.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker, da den ikke bekrefter forutsetningene fra [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SIKKERHET: innringeren må sørge for at `align` er større enn null.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Minimumsstørrelsen i byte for en minneblokk av dette oppsettet.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Minimum bytejustering for en minneblokk av dette oppsettet.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Konstruerer en `Layout` som er egnet for å holde en verdi av typen `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SIKKERHET: justeringen garanteres av Rust å være en kraft på to og
        // kombinasjonen størrelse + justering passer garantert i adresserommet vårt.
        // Som et resultat, bruk den ukontrollerte konstruktøren her for å unngå å sette inn kode som panics hvis den ikke er optimalisert godt nok.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produserer layout som beskriver en plate som kan brukes til å tildele backingstruktur for `T` (som kan være en trait eller annen ikke-størrelse type som et stykke).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIKKERHET: se begrunnelsen i `new` for hvorfor dette bruker den usikre varianten
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produserer layout som beskriver en plate som kan brukes til å tildele backingstruktur for `T` (som kan være en trait eller annen ikke-størrelse type som et stykke).
    ///
    /// # Safety
    ///
    /// Denne funksjonen er bare trygt å ringe hvis følgende forhold gjelder:
    ///
    /// - Hvis `T` er `Sized`, er det alltid trygt å ringe denne funksjonen.
    /// - Hvis den usikre halen på `T` er:
    ///     - en [slice], så må skivens hales lengde være et intialisert heltall, og størrelsen på *hele verdien*(dynamisk halelengde + statisk størrelse prefiks) må passe inn i `isize`.
    ///     - en [trait object], så må vtabeldelen av pekeren peke på en gyldig vtabell for typen `T` som er anskaffet av en ikke-størrende tvang, og størrelsen på *hele verdien*(dynamisk halelengde + statisk størrelse prefiks) må passe inn i `isize`.
    ///
    ///     - en (unstable) [extern type], så er denne funksjonen alltid trygg å ringe, men kan panic eller på annen måte returnere feil verdi, da den eksterne typen ikke er kjent.
    ///     Dette er den samme oppførselen som [`Layout::for_value`] på en referanse til en ekstern type hale.
    ///     - ellers er det konservativt ikke tillatt å kalle denne funksjonen.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SIKKERHET: vi overfører forutsetningene for disse funksjonene til innringeren
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIKKERHET: se begrunnelsen i `new` for hvorfor dette bruker den usikre varianten
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Oppretter en `NonNull` som er dinglende, men godt justert for dette oppsettet.
    ///
    /// Merk at pekerverdien potensielt kan representere en gyldig peker, noe som betyr at denne ikke må brukes som en "not yet initialized" sentinelverdi.
    /// Typer som lat tildeles, må spore initialisering på annen måte.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SIKKERHET: justering er garantert ikke null
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Oppretter et oppsett som beskriver posten som kan inneholde en verdi av samme layout som `self`, men som også er justert til justering `align` (målt i byte).
    ///
    ///
    /// Hvis `self` allerede oppfyller den foreskrevne justeringen, returnerer du `self`.
    ///
    /// Merk at denne metoden ikke legger til noe polstring i den totale størrelsen, uavhengig av om det returnerte oppsettet har en annen justering.
    /// Med andre ord, hvis `K` har størrelse 16, vil `K.align_to(32)`*fortsatt* ha størrelse 16.
    ///
    /// Returnerer en feil hvis kombinasjonen av `self.size()` og den gitte `align` bryter med vilkårene som er oppført i [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Returnerer mengden polstring vi må sette inn etter `self` for å sikre at følgende adresse vil tilfredsstille `align` (målt i byte).
    ///
    /// for eksempel, hvis `self.size()` er 9, returnerer `self.padding_needed_for(4)` 3, fordi det er det minste antallet byte av polstring som kreves for å få en 4-justert adresse (forutsatt at den tilsvarende minneblokken starter på en 4-justert adresse).
    ///
    ///
    /// Returverdien til denne funksjonen har ingen betydning hvis `align` ikke er en power-of-two.
    ///
    /// Merk at nytteverdien til den returnerte verdien krever at `align` er mindre enn eller lik justeringen av startadressen for hele den tildelte minneblokken.En måte å tilfredsstille denne begrensningen på er å sikre `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Avrundet verdi er:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // og så returnerer vi polstringsforskjellen: `len_rounded_up - len`.
        //
        // Vi bruker modulær aritmetikk hele tiden:
        //
        // 1. align er garantert> 0, så align, 1 er alltid gyldig.
        //
        // 2.
        // `len + align - 1` kan overløpe med maksimalt `align - 1`, så&-masken med `!(align - 1)` vil sikre at i tilfelle overløp, vil `len_rounded_up` i seg selv være 0.
        //
        //    Dermed gir den returnerte polstringen, når den er lagt til `len`, 0, som trivielt tilfredsstiller justeringen `align`.
        //
        // (Selvfølgelig skal forsøk på å tildele minneblokker hvis størrelse og polstring overløper på ovennevnte måte føre til at tildeleren allikevel gir en feil.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Oppretter et oppsett ved å avrunde størrelsen på dette oppsettet opp til et multiplum av oppsettet.
    ///
    ///
    /// Dette tilsvarer å legge til resultatet av `padding_needed_for` til oppsettets nåværende størrelse.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Dette kan ikke renne over.Sitat fra invarianten av Layout:
        // > `size`, når avrundet til nærmeste multiplum av `align`,
        // > må ikke flyte over (dvs. den avrundede verdien må være mindre enn
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Oppretter et oppsett som beskriver posten for `n`-forekomster av `self`, med en passende mengde polstring mellom hver for å sikre at hver forekomst får ønsket størrelse og justering.
    /// Ved suksess returnerer `(k, offs)` der `k` er oppsettet til matrisen og `offs` er avstanden mellom starten på hvert element i matrisen.
    ///
    /// Ved aritmetisk overløp, returnerer `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Dette kan ikke renne over.Sitat fra invarianten av Layout:
        // > `size`, når avrundet til nærmeste multiplum av `align`,
        // > må ikke flyte over (dvs. den avrundede verdien må være mindre enn
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SIKKERHET: self.align er allerede kjent for å være gyldig og alloc_size har vært
        // polstret allerede.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Oppretter et oppsett som beskriver posten for `self` etterfulgt av `next`, inkludert nødvendig polstring for å sikre at `next` blir riktig justert, men *ingen etterfølgende polstring*.
    ///
    /// For å matche C-representasjonslayout `repr(C)`, bør du ringe `pad_to_align` etter å ha utvidet layouten med alle felt.
    /// (Det er ingen måte å matche standard Rust representasjonsoppsett `repr(Rust)`, as it is unspecified.)
    ///
    /// Vær oppmerksom på at justeringen av det resulterende oppsettet vil være maksimalt for `self` og `next`, for å sikre justering av begge deler.
    ///
    /// Returnerer `Ok((k, offset))`, der `k` er oppsettet til den sammenkoblede posten og `offset` er den relative plasseringen i byte til starten på `next` innebygd i den sammenkoblede posten (forutsatt at selve posten starter ved forskyvning 0).
    ///
    ///
    /// Ved aritmetisk overløp, returnerer `LayoutError`.
    ///
    /// # Examples
    ///
    /// Slik beregner du oppsettet til en `#[repr(C)]`-struktur og forskyvning av feltene fra feltoppsettene:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Husk å fullføre med `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // test at det fungerer
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Oppretter et oppsett som beskriver posten for `n`-forekomster av `self`, uten polstring mellom hver forekomst.
    ///
    /// Merk at, i motsetning til `repeat`, garanterer ikke `repeat_packed` at gjentatte forekomster av `self` vil være riktig justert, selv om en gitt forekomst av `self` er riktig justert.
    /// Med andre ord, hvis layouten som returneres av `repeat_packed` brukes til å tildele en matrise, er det ikke garantert at alle elementene i matrisen vil bli riktig justert.
    ///
    /// Ved aritmetisk overløp, returnerer `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Oppretter et oppsett som beskriver posten for `self` etterfulgt av `next` uten ekstra polstring mellom de to.
    /// Siden ingen polstring er satt inn, er justeringen av `next` irrelevant, og er ikke integrert *i det hele tatt* i den resulterende layouten.
    ///
    ///
    /// Ved aritmetisk overløp, returnerer `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Oppretter et oppsett som beskriver posten for en `[T; n]`.
    ///
    /// Ved aritmetisk overløp, returnerer `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametrene gitt til `Layout::from_size_align` eller en annen `Layout`-konstruktør tilfredsstiller ikke de dokumenterte begrensningene.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (vi trenger dette for nedstrøms impl. av trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}