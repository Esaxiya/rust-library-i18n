//! APIer for tildeling av minne

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError`-feilen indikerer en allokeringsfeil som kan være på grunn av ressursutmattelse eller noe galt når du kombinerer de gitte inngangsargumentene med denne tildeleren.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (vi trenger dette for nedstrøms impl. av trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// En implementering av `Allocator` kan tildele, vokse, krympe og distribuere vilkårlige datablokker beskrevet via [`Layout`][].
///
/// `Allocator` er designet for å implementeres på ZST, referanser eller smarte pekere fordi det å ha en allokator som `MyAlloc([u8; N])` ikke kan flyttes uten å oppdatere pekerne til det tildelte minnet.
///
/// I motsetning til [`GlobalAlloc`][] er tildelinger i nullstørrelse tillatt i `Allocator`.
/// Hvis en underliggende tildeler ikke støtter dette (som jemalloc) eller returnerer en nullpeker (for eksempel `libc::malloc`), må dette fanges opp av implementeringen.
///
/// ### For tiden tildelt minne
///
/// Noen av metodene krever at en minneblokk *for tiden tildeles* via en allokator.Dette betyr at:
///
/// * startadressen for den minneblokken ble tidligere returnert av [`allocate`], [`grow`] eller [`shrink`], og
///
/// * minneblokken har ikke senere blitt omlokalisert, der blokker enten blir omlokalisert direkte ved å bli sendt til [`deallocate`] eller ble endret ved å bli sendt til [`grow`] eller [`shrink`] som returnerer `Ok`.
///
/// Hvis `grow` eller `shrink` har returnert `Err`, forblir den passerte pekeren gyldig.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Minnetilpasning
///
/// Noen av metodene krever at et oppsett *passer* til en minneblokk.
/// Hva det betyr for et oppsett til "fit", betyr en minneblokk (eller tilsvarende for en minneblokk til "fit" et oppsett) at følgende forhold må være:
///
/// * Blokken må tildeles med samme justering som [`layout.align()`], og
///
/// * Den medfølgende [`layout.size()`] må falle i området `min ..= max`, der:
///   - `min` er størrelsen på oppsettet som nylig ble brukt til å tildele blokken, og
///   - `max` er den siste faktiske størrelsen som er returnert fra [`allocate`], [`grow`] eller [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Minneblokker som returneres fra en tildeler, må peke på gyldig minne og beholde gyldigheten til forekomsten og alle dens kloner slippes,
///
/// * kloning eller flytting av tildeleren må ikke ugyldiggjøre minneblokker som returneres fra denne tildeleren.En klonet tildeler må oppføre seg som samme tildeler, og
///
/// * hvilken som helst peker til en minneblokk som er [*currently allocated*] kan sendes til en hvilken som helst annen metode for tildeleren.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Forsøk på å tildele en blokk med minne.
    ///
    /// Ved suksess returnerer en [`NonNull<[u8]>`][NonNull] som oppfyller størrelsen og justeringsgarantiene til `layout`.
    ///
    /// Den returnerte blokken kan ha en større størrelse enn spesifisert av `layout.size()`, og innholdet kan initialiseres eller ikke.
    ///
    /// # Errors
    ///
    /// Å returnere `Err` indikerer at enten minnet er oppbrukt, eller at `layout` ikke oppfyller tildelers størrelse eller justeringsbegrensninger.
    ///
    /// Implementeringer oppfordres til å returnere `Err` på minneutmattelse i stedet for å få panikk eller avbryte, men dette er ikke et strengt krav.
    /// (Spesielt: det er *lovlig* å implementere denne trait på toppen av et underliggende naturlig tildelingsbibliotek som avbryter minneutmattelse.)
    ///
    /// Kunder som ønsker å avbryte beregning som svar på en allokeringsfeil, oppfordres til å ringe [`handle_alloc_error`]-funksjonen, i stedet for å direkte påkalle `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Oppfører seg som `allocate`, men sørger også for at det returnerte minnet nullstartes.
    ///
    /// # Errors
    ///
    /// Å returnere `Err` indikerer at enten minnet er oppbrukt, eller at `layout` ikke oppfyller tildelers størrelse eller justeringsbegrensninger.
    ///
    /// Implementeringer oppfordres til å returnere `Err` på minneutmattelse i stedet for å få panikk eller avbryte, men dette er ikke et strengt krav.
    /// (Spesielt: det er *lovlig* å implementere denne trait på toppen av et underliggende naturlig tildelingsbibliotek som avbryter minneutmattelse.)
    ///
    /// Kunder som ønsker å avbryte beregning som svar på en allokeringsfeil, oppfordres til å ringe [`handle_alloc_error`]-funksjonen, i stedet for å direkte påkalle `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SIKKERHET: `alloc` returnerer en gyldig minneblokk
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Distribuerer minnet som `ptr` refererer til.
    ///
    /// # Safety
    ///
    /// * `ptr` må betegne en blokk med minne [*currently allocated*] via denne tildeleren, og
    /// * `layout` må [*fit*] den minneblokken.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Forsøk på å utvide minneblokken.
    ///
    /// Returnerer en ny [`NonNull<[u8]>`][NonNull] som inneholder en peker og den faktiske størrelsen på det tildelte minnet.Pekeren er egnet for å lagre data beskrevet av `new_layout`.
    /// For å oppnå dette kan tildeleren utvide tildelingen som `ptr` refererer til for å passe til det nye oppsettet.
    ///
    /// Hvis dette returnerer `Ok`, er eierskapet til minneblokken referert til av `ptr` overført til denne tildeleren.
    /// Minnet kan eller ikke har blitt frigjort, og bør betraktes som ubrukelig med mindre det ble overført tilbake til innringeren igjen via returverdien til denne metoden.
    ///
    /// Hvis denne metoden returnerer `Err`, har eierskap til minneblokken ikke blitt overført til denne tildeleren, og innholdet i minneblokken er uendret.
    ///
    /// # Safety
    ///
    /// * `ptr` må betegne en blokk med minne [*currently allocated*] via denne tildeleren.
    /// * `old_layout` må [*fit*] den blokken med minne (`new_layout`-argumentet trenger ikke å passe den.).
    /// * `new_layout.size()` må være større enn eller lik `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnerer `Err` hvis det nye oppsettet ikke oppfyller tildelers størrelse og justeringsbegrensninger for tildeleren, eller hvis vekst ellers mislykkes.
    ///
    /// Implementeringer oppfordres til å returnere `Err` på minneutmattelse i stedet for å få panikk eller avbryte, men dette er ikke et strengt krav.
    /// (Spesielt: det er *lovlig* å implementere denne trait på toppen av et underliggende naturlig tildelingsbibliotek som avbryter minneutmattelse.)
    ///
    /// Kunder som ønsker å avbryte beregning som svar på en allokeringsfeil, oppfordres til å ringe [`handle_alloc_error`]-funksjonen, i stedet for å direkte påkalle `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIKKERHET: fordi `new_layout.size()` må være større enn eller lik
        // `old_layout.size()`, både den gamle og den nye minnetildelingen er gyldig for lesing og skriving for `old_layout.size()` byte.
        // Også fordi den gamle tildelingen ennå ikke var fordelt, kan den ikke overlappe `new_ptr`.
        // Dermed er samtalen til `copy_nonoverlapping` trygg.
        // Sikkerhetskontrakten for `dealloc` må opprettholdes av den som ringer.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Oppfører seg som `grow`, men sørger også for at det nye innholdet blir satt til null før det returneres.
    ///
    /// Minneblokken vil inneholde følgende innhold etter en vellykket samtale til
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` er bevart fra den opprinnelige tildelingen.
    ///   * Bytes `old_layout.size()..old_size` blir enten bevart eller nullstilt, avhengig av implementeringen av tildeleren.
    ///   `old_size` refererer til størrelsen på minneblokken før `grow_zeroed`-samtalen, som kan være større enn størrelsen som opprinnelig ble bedt om da den ble tildelt.
    ///   * Byte `old_size..new_size` nullstilles.`new_size` refererer til størrelsen på minneblokken som returneres av `grow_zeroed`-samtalen.
    ///
    /// # Safety
    ///
    /// * `ptr` må betegne en blokk med minne [*currently allocated*] via denne tildeleren.
    /// * `old_layout` må [*fit*] den blokken med minne (`new_layout`-argumentet trenger ikke å passe den.).
    /// * `new_layout.size()` må være større enn eller lik `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnerer `Err` hvis det nye oppsettet ikke oppfyller tildelers størrelse og justeringsbegrensninger for tildeleren, eller hvis vekst ellers mislykkes.
    ///
    /// Implementeringer oppfordres til å returnere `Err` på minneutmattelse i stedet for å få panikk eller avbryte, men dette er ikke et strengt krav.
    /// (Spesielt: det er *lovlig* å implementere denne trait på toppen av et underliggende naturlig tildelingsbibliotek som avbryter minneutmattelse.)
    ///
    /// Kunder som ønsker å avbryte beregning som svar på en allokeringsfeil, oppfordres til å ringe [`handle_alloc_error`]-funksjonen, i stedet for å direkte påkalle `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SIKKERHET: fordi `new_layout.size()` må være større enn eller lik
        // `old_layout.size()`, både den gamle og den nye minnetildelingen er gyldig for lesing og skriving for `old_layout.size()` byte.
        // Også fordi den gamle tildelingen ennå ikke var fordelt, kan den ikke overlappe `new_ptr`.
        // Dermed er samtalen til `copy_nonoverlapping` trygg.
        // Sikkerhetskontrakten for `dealloc` må opprettholdes av den som ringer.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Forsøk på å krympe minneblokken.
    ///
    /// Returnerer en ny [`NonNull<[u8]>`][NonNull] som inneholder en peker og den faktiske størrelsen på det tildelte minnet.Pekeren er egnet for å lagre data beskrevet av `new_layout`.
    /// For å oppnå dette kan tildeleren krympe tildelingen som det refereres av `ptr` for å passe til det nye oppsettet.
    ///
    /// Hvis dette returnerer `Ok`, er eierskapet til minneblokken referert til av `ptr` overført til denne tildeleren.
    /// Minnet kan eller ikke har blitt frigjort, og bør betraktes som ubrukelig med mindre det ble overført tilbake til innringeren igjen via returverdien til denne metoden.
    ///
    /// Hvis denne metoden returnerer `Err`, har eierskap til minneblokken ikke blitt overført til denne tildeleren, og innholdet i minneblokken er uendret.
    ///
    /// # Safety
    ///
    /// * `ptr` må betegne en blokk med minne [*currently allocated*] via denne tildeleren.
    /// * `old_layout` må [*fit*] den blokken med minne (`new_layout`-argumentet trenger ikke å passe den.).
    /// * `new_layout.size()` må være mindre enn eller lik `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnerer `Err` hvis det nye oppsettet ikke oppfyller tildelerens størrelse og justeringsbegrensninger for tildeleren, eller hvis krymping ellers mislykkes.
    ///
    /// Implementeringer oppfordres til å returnere `Err` på minneutmattelse i stedet for å få panikk eller avbryte, men dette er ikke et strengt krav.
    /// (Spesielt: det er *lovlig* å implementere denne trait på toppen av et underliggende naturlig tildelingsbibliotek som avbryter minneutmattelse.)
    ///
    /// Kunder som ønsker å avbryte beregning som svar på en allokeringsfeil, oppfordres til å ringe [`handle_alloc_error`]-funksjonen, i stedet for å direkte påkalle `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIKKERHET: fordi `new_layout.size()` må være lavere enn eller lik
        // `old_layout.size()`, både den gamle og den nye minnetildelingen er gyldig for lesing og skriving for `new_layout.size()` byte.
        // Også fordi den gamle tildelingen ennå ikke var fordelt, kan den ikke overlappe `new_ptr`.
        // Dermed er samtalen til `copy_nonoverlapping` trygg.
        // Sikkerhetskontrakten for `dealloc` må opprettholdes av den som ringer.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Oppretter en "by reference"-adapter for denne forekomsten av `Allocator`.
    ///
    /// Den returnerte adapteren implementerer også `Allocator` og vil bare låne denne.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SIKKERHET: sikkerhetskontrakten må opprettholdes av den som ringer
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIKKERHET: sikkerhetskontrakten må opprettholdes av den som ringer
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIKKERHET: sikkerhetskontrakten må opprettholdes av den som ringer
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIKKERHET: sikkerhetskontrakten må opprettholdes av den som ringer
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}