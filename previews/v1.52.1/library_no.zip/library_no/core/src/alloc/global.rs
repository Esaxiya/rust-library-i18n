use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// En minnetildeler som kan registreres som standardbibliotekets standard gjennom `#[global_allocator]`-attributtet.
///
/// Noen av metodene krever at en minneblokk *for tiden tildeles* via en allokator.Dette betyr at:
///
/// * startadressen for den minneblokken ble tidligere returnert av en tidligere samtale til en tildelingsmetode som `alloc`, og
///
/// * minneblokken har ikke blitt omlokalisert senere, der blokker blir omlokalisert enten ved å bli sendt til en deallocation-metode som `dealloc` eller ved å bli sendt til en reallocation-metode som returnerer en ikke-null-peker.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait er en `unsafe` trait av flere årsaker, og implementører må sørge for at de overholder disse kontraktene:
///
/// * Det er udefinert oppførsel hvis globale tildelere slapper av.Denne begrensningen kan løftes i future, men for tiden kan en panic fra noen av disse funksjonene føre til minneusikkerhet.
///
/// * `Layout` spørsmål og beregninger generelt må være korrekte.Innringere av denne trait har tillatelse til å stole på kontraktene som er definert for hver metode, og implementører må sørge for at slike kontrakter forblir sanne.
///
/// * Du kan ikke stole på at tildelinger faktisk skjer, selv om det er eksplisitte dyngetildelinger i kilden.
/// Optimalisereren kan oppdage ubrukte tildelinger som den enten kan eliminere helt eller flytte til stabelen og dermed aldri påkalle tildeleren.
/// Optimizer kan videre anta at allokering er ufeilbarlig, så kode som pleide å mislykkes på grunn av allokeringsfeil, kan nå plutselig fungere fordi optimizer jobbet rundt behovet for en allokering.
/// Mer konkret er følgende kodeeksempel usunt, uavhengig av om din egendefinerte tildeler tillater å telle hvor mange tildelinger som har skjedd.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Merk at optimaliseringene nevnt ovenfor ikke er den eneste optimaliseringen som kan brukes.Du kan vanligvis ikke stole på at haugetildeling skjer hvis de kan fjernes uten å endre programatferd.
///   Om tildelinger skjer eller ikke er ikke en del av programoppførselen, selv om den kunne oppdages via en allokator som sporer tildelinger ved å skrive ut eller på annen måte ha bivirkninger.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Tildel minne som beskrevet av den gitte `layout`.
    ///
    /// Returnerer en peker til nylig tildelt minne, eller null for å indikere tildelingsfeil.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er utrygg fordi udefinert oppførsel kan oppstå hvis den som ringer ikke sørger for at `layout` har en størrelse som ikke er null.
    ///
    /// (Extras-underruter kan gi mer spesifikke grenser for atferd, for eksempel garantere en vaktadresse eller en nullpeker som svar på en forespørsel om tildeling av nullstørrelse.)
    ///
    /// Den tildelte minneblokken kan eller ikke initialiseres.
    ///
    /// # Errors
    ///
    /// Å returnere en nullpeker indikerer at enten minnet er oppbrukt, eller at `layout` ikke oppfyller denne tildelers størrelse eller justeringsbegrensninger.
    ///
    /// Implementeringer oppfordres til å returnere null ved minneutmattelse i stedet for å avbryte, men dette er ikke et strengt krav.
    /// (Spesielt: det er *lovlig* å implementere denne trait på toppen av et underliggende naturlig tildelingsbibliotek som avbryter minneutmattelse.)
    ///
    /// Kunder som ønsker å avbryte beregning som svar på en allokeringsfeil, oppfordres til å ringe [`handle_alloc_error`]-funksjonen, i stedet for å direkte påkalle `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Fordel minneblokken ved den gitte `ptr`-pekeren med den gitte `layout`.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker fordi udefinert oppførsel kan oppstå hvis den som ringer ikke sørger for alt av følgende:
    ///
    ///
    /// * `ptr` må betegne en minneblokk som for tiden er tildelt via denne tildeleren,
    ///
    /// * `layout` må være det samme oppsettet som ble brukt til å tildele den minneblokken.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Oppfører seg som `alloc`, men sørger også for at innholdet er satt til null før det returneres.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker av samme årsaker som `alloc`.
    /// Imidlertid er den tildelte minneblokken garantert initialisert.
    ///
    /// # Errors
    ///
    /// Å returnere en nullpeker indikerer at enten minnet er oppbrukt, eller at `layout` ikke oppfyller tildelers størrelse eller justeringsbegrensninger, akkurat som i `alloc`.
    ///
    /// Kunder som ønsker å avbryte beregning som svar på en allokeringsfeil, oppfordres til å ringe [`handle_alloc_error`]-funksjonen, i stedet for å direkte påkalle `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SIKKERHET: sikkerhetskontrakten for `alloc` må opprettholdes av den som ringer.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SIKKERHET: da tildelingen lyktes, ble regionen fra `ptr`
            // av størrelse `size` er garantert gyldig for skriv.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Krymp eller øk en minneblokk til den gitte `new_size`.
    /// Blokken er beskrevet av den gitte `ptr`-pekeren og `layout`.
    ///
    /// Hvis dette returnerer en ikke-null peker, har eierskap til minneblokken som det refereres til av `ptr` blitt overført til denne tildeleren.
    /// Minnet kan eller ikke har blitt omplassert, og bør betraktes som ubrukelig (med mindre det selvfølgelig ble overført tilbake til innringeren igjen via returverdien til denne metoden).
    /// Den nye minneblokken er tildelt `layout`, men med `size` oppdatert til `new_size`.
    /// Dette nye oppsettet skal brukes når du plasserer den nye minneblokken med `dealloc`.
    /// Området `0..min(layout.size(), new_size) `av den nye minneblokken har garantert de samme verdiene som den opprinnelige blokken.
    ///
    /// Hvis denne metoden returnerer null, har eierskap til minneblokken ikke blitt overført til denne tildeleren, og innholdet i minneblokken er uendret.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker fordi udefinert oppførsel kan oppstå hvis den som ringer ikke sørger for alt av følgende:
    ///
    /// * `ptr` må for tiden tildeles via denne tildeleren,
    ///
    /// * `layout` må være det samme oppsettet som ble brukt til å tildele den minneblokken,
    ///
    /// * `new_size` må være større enn null.
    ///
    /// * `new_size`, når den er avrundet til nærmeste multiplum av `layout.align()`, må den ikke flyte over (dvs. den avrundede verdien må være mindre enn `usize::MAX`).
    ///
    /// (Extras-underruter kan gi mer spesifikke grenser for atferd, for eksempel garantere en vaktadresse eller en nullpeker som svar på en forespørsel om tildeling av nullstørrelse.)
    ///
    /// # Errors
    ///
    /// Returnerer null hvis det nye oppsettet ikke oppfyller størrelses-og justeringsbegrensningene til tildeleren, eller hvis omdisponering ellers mislykkes.
    ///
    /// Implementeringer oppfordres til å returnere null ved minneutmattelse i stedet for å få panikk eller avbryte, men dette er ikke et strengt krav.
    /// (Spesielt: det er *lovlig* å implementere denne trait på toppen av et underliggende naturlig tildelingsbibliotek som avbryter minneutmattelse.)
    ///
    /// Kunder som ønsker å avbryte beregning som svar på en omdisponeringsfeil, oppfordres til å ringe [`handle_alloc_error`]-funksjonen, i stedet for å direkte påkalle `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SIKKERHET: innringeren må sørge for at `new_size` ikke renner over.
        // `layout.align()` kommer fra en `Layout` og er dermed garantert gyldig.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SIKKERHET: innringeren må sørge for at `new_layout` er større enn null.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SIKKERHET: den tidligere tildelte blokken kan ikke overlappe den nylig tildelte blokken.
            // Sikkerhetskontrakten for `dealloc` må opprettholdes av den som ringer.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}