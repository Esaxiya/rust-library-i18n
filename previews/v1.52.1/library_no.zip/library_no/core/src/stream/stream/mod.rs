use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Et grensesnitt for håndtering av asynkrone iteratorer.
///
/// Dette er hovedstrømmen trait.
/// For mer informasjon om konseptet med strømmer, se [module-level documentation].
/// Spesielt vil du kanskje vite hvordan du skal [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Typen varer som strømmen gir.
    type Item;

    /// Forsøk å trekke ut den neste verdien av denne strømmen, registrer den gjeldende oppgaven for oppvåkning hvis verdien ennå ikke er tilgjengelig, og returner `None` hvis strømmen er oppbrukt.
    ///
    /// # Returverdi
    ///
    /// Det er flere mulige returverdier, som hver indikerer en distinkt strømtilstand:
    ///
    /// - `Poll::Pending` betyr at denne streamens neste verdi ikke er klar ennå.Implementeringer vil sikre at den gjeldende oppgaven blir varslet når neste verdi kan være klar.
    ///
    /// - `Poll::Ready(Some(val))` betyr at strømmen har produsert en verdi, `val`, og kan produsere ytterligere verdier ved påfølgende `poll_next`-samtaler.
    ///
    /// - `Poll::Ready(None)` betyr at strømmen har avsluttet, og `poll_next` skal ikke påberopes igjen.
    ///
    /// # Panics
    ///
    /// Når en strøm er ferdig (returnerte `Ready(None)` from `poll_next`), å ringe til `poll_next`-metoden igjen, kan panic, blokkere for alltid eller forårsake andre typer problemer; `Stream` trait stiller ingen krav til effekten av en slik samtale.
    ///
    /// Imidlertid, siden `poll_next`-metoden ikke er merket `unsafe`, gjelder Rust s vanlige regler: samtaler må aldri forårsake udefinert oppførsel (minnekorrupsjon, feil bruk av `unsafe`-funksjoner eller lignende), uavhengig av strømens tilstand.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Returnerer grensene for gjenværende lengde på strømmen.
    ///
    /// Spesielt returnerer `size_hint()` en tuple der det første elementet er den nedre grensen, og det andre elementet er den øvre grensen.
    ///
    /// Den andre halvdelen av tupelen som returneres er en [`Option`]`<`[`usize`] `>`.
    /// En [`None`] her betyr at enten det ikke er noen kjent øvre grense, eller at den øvre grensen er større enn [`usize`].
    ///
    /// # Implementeringsnotater
    ///
    /// Det håndheves ikke at en strømimplementering gir det deklarerte antall elementer.En buggy stream kan gi mindre enn den nedre grensen eller mer enn den øvre grensen for elementer.
    ///
    /// `size_hint()` er primært ment å brukes til optimaliseringer som for eksempel å reservere plass til elementene i strømmen, men må ikke stole på å for eksempel utelate grensekontroller i usikker kode.
    /// Feil implementering av `size_hint()` bør ikke føre til minnesikkerhetsbrudd.
    ///
    /// Når det er sagt, skal implementeringen gi et riktig estimat, fordi det ellers ville være et brudd på trait s protokoll.
    ///
    /// Standardimplementeringen returnerer `(0,` [`None`]`)`som er riktig for enhver strøm.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}