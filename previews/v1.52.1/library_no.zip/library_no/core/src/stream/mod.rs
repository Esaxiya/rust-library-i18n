//! Komponerbar asynkron iterasjon.
//!
//! Hvis futures er asynkrone verdier, er strømmer asynkrone iteratorer.
//! Hvis du har funnet deg selv med en asynkron samling av noe slag, og trenger å utføre en operasjon på elementene i samlingen, vil du raskt løpe inn i 'streams'.
//! Strømmer brukes mye i idiomatisk asynkron Rust-kode, så det er verdt å bli kjent med dem.
//!
//! Før vi forklarer mer, la oss snakke om hvordan denne modulen er strukturert:
//!
//! # Organization
//!
//! Denne modulen er i stor grad organisert etter type:
//!
//! * [Traits] er kjernepartiet: disse traits definerer hva slags strømmer som finnes og hva du kan gjøre med dem.Metodene til disse traits er verdt å bruke litt ekstra studietid på.
//! * Funksjoner gir noen nyttige måter å lage noen grunnleggende strømmer på.
//! * Structs er ofte returtypene til de forskjellige metodene på denne modulens traits.Du vil vanligvis se på metoden som oppretter `struct`, i stedet for selve `struct`.
//! For mer detalj om hvorfor, se '[Implementing Stream](#implementeringsstrøm)'.
//!
//! [Traits]: #traits
//!
//! Det er det!La oss grave i bekker.
//!
//! # Stream
//!
//! Hjertet og sjelen til denne modulen er [`Stream`] trait.Kjernen til [`Stream`] ser slik ut:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! I motsetning til `Iterator` skiller `Stream` mellom [`poll_next`]-metoden som brukes når du implementerer en `Stream`, og en (to-be-implemented) `next`-metode som brukes når du bruker en strøm.
//!
//! Forbrukere av `Stream` trenger bare å vurdere `next`, som når den kalles, returnerer en future som gir `Option<Stream::Item>`.
//!
//! future returnert av `next` vil gi `Some(Item)` så lenge det er elementer, og når de alle er oppbrukt, vil de gi `None` for å indikere at iterasjonen er ferdig.
//! Hvis vi venter på noe asynkront å løse, vil future vente til strømmen er klar til å gi igjen.
//!
//! Enkeltstrømmer kan velge å gjenoppta iterasjon, og det å ringe `next` igjen kan kanskje gi `Some(Item)` igjen på et eller annet tidspunkt.
//!
//! [``Stream``s fullstendige definisjon inkluderer også en rekke andre metoder, men de er standardmetoder, bygget på toppen av [`poll_next`], og så får du dem gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementering av strøm
//!
//! Å lage en egen strøm innebærer to trinn: lage en `struct` for å holde strømmen, og deretter implementere [`Stream`] for den `struct`.
//!
//! La oss lage en strøm med navnet `Counter` som teller fra `1` til `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Først strukturen:
//!
//! /// En strøm som teller fra en til fem
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vi vil at tellingen vår skal starte på en, så la oss legge til en new()-metode for å hjelpe.
//! // Dette er ikke strengt nødvendig, men er praktisk.
//! // Merk at vi starter `count` på null, vi får se hvorfor i `poll_next()`'s implementering nedenfor.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Deretter implementerer vi `Stream` for `Counter`:
//!
//! impl Stream for Counter {
//!     // vi vil telle med størrelsen
//!     type Item = usize;
//!
//!     // poll_next() er den eneste nødvendige metoden
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Øk antallet våre.Dette er grunnen til at vi startet på null.
//!         self.count += 1;
//!
//!         // Sjekk om vi er ferdig med å telle eller ikke.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Bekker er *late*.Dette betyr at bare å lage en strøm ikke _do_ veldig mye.Ingenting skjer egentlig før du ringer til `next`.
//! Noen ganger er dette en kilde til forvirring når du oppretter en strøm utelukkende for bivirkningene.
//! Kompilatoren vil advare oss om denne typen oppførsel:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;