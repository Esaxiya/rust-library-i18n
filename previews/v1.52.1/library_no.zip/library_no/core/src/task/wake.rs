#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// En `RawWaker` lar implementatoren til en oppgaveutfører lage en [`Waker`] som gir tilpasset oppvåkning.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Den består av en datapeker og en [virtual function pointer table (vtable)][vtable] som tilpasser oppførselen til `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// En datapeker, som kan brukes til å lagre vilkårlige data som kreves av utføreren.
    /// Dette kan f.eks
    /// en typeslettet peker til en `Arc` som er tilknyttet oppgaven.
    /// Verdien av dette feltet blir overført til alle funksjoner som er en del av vtabellen som den første parameteren.
    ///
    data: *const (),
    /// Pekertabell for virtuell funksjon som tilpasser oppførselen til denne waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Oppretter en ny `RawWaker` fra den medfølgende `data`-pekeren og `vtable`.
    ///
    /// `data`-pekeren kan brukes til å lagre vilkårlige data som kreves av utføreren.Dette kan f.eks
    /// en typeslettet peker til en `Arc` som er tilknyttet oppgaven.
    /// Verdien på denne pekeren vil bli sendt til alle funksjoner som er en del av `vtable` som den første parameteren.
    ///
    /// `vtable` tilpasser oppførselen til en `Waker` som blir opprettet fra en `RawWaker`.
    /// For hver operasjon på `Waker` vil den tilknyttede funksjonen i `vtable` til den underliggende `RawWaker` kalles.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// En peketabell (vtable) for virtuell funksjon som spesifiserer oppførselen til en [`RawWaker`].
///
/// Pekeren som sendes til alle funksjonene i vtabellen, er `data`-pekeren fra det vedlagte [`RawWaker`]-objektet.
///
/// Funksjonene i denne strukturen er bare ment å kalles på `data`-pekeren til et riktig konstruert [`RawWaker`]-objekt fra innsiden av [`RawWaker`]-implementeringen.
/// Å ringe til en av funksjonene som finnes ved å bruke en hvilken som helst annen `data`-peker, vil føre til udefinert oppførsel.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Denne funksjonen vil bli kalt når [`RawWaker`] blir klonet, for eksempel når [`Waker`] der [`RawWaker`] er lagret blir klonet.
    ///
    /// Implementeringen av denne funksjonen må beholde alle ressursene som kreves for denne ekstra forekomsten av en [`RawWaker`] og tilhørende oppgave.
    /// Å ringe `wake` på den resulterende [`RawWaker`] bør resultere i en vekking av den samme oppgaven som ville blitt vekket av den opprinnelige [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Denne funksjonen vil bli kalt når `wake` kalles på [`Waker`].
    /// Den må vekke oppgaven knyttet til denne [`RawWaker`].
    ///
    /// Implementeringen av denne funksjonen må sørge for å frigjøre ressurser som er knyttet til denne forekomsten av en [`RawWaker`] og tilhørende oppgave.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Denne funksjonen vil bli kalt når `wake_by_ref` kalles på [`Waker`].
    /// Den må vekke oppgaven knyttet til denne [`RawWaker`].
    ///
    /// Denne funksjonen ligner på `wake`, men må ikke forbruke den angitte datapekeren.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Denne funksjonen blir kalt når en [`RawWaker`] blir droppet.
    ///
    /// Implementeringen av denne funksjonen må sørge for å frigjøre ressurser som er knyttet til denne forekomsten av en [`RawWaker`] og tilhørende oppgave.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Oppretter en ny `RawWakerVTable` fra de medfølgende funksjonene `clone`, `wake`, `wake_by_ref` og `drop`.
    ///
    /// # `clone`
    ///
    /// Denne funksjonen vil bli kalt når [`RawWaker`] blir klonet, for eksempel når [`Waker`] der [`RawWaker`] er lagret blir klonet.
    ///
    /// Implementeringen av denne funksjonen må beholde alle ressursene som kreves for denne ekstra forekomsten av en [`RawWaker`] og tilhørende oppgave.
    /// Å ringe `wake` på den resulterende [`RawWaker`] bør resultere i en vekking av den samme oppgaven som ville blitt vekket av den opprinnelige [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Denne funksjonen vil bli kalt når `wake` kalles på [`Waker`].
    /// Den må vekke oppgaven knyttet til denne [`RawWaker`].
    ///
    /// Implementeringen av denne funksjonen må sørge for å frigjøre ressurser som er knyttet til denne forekomsten av en [`RawWaker`] og tilhørende oppgave.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Denne funksjonen vil bli kalt når `wake_by_ref` kalles på [`Waker`].
    /// Den må vekke oppgaven knyttet til denne [`RawWaker`].
    ///
    /// Denne funksjonen ligner på `wake`, men må ikke forbruke den angitte datapekeren.
    ///
    /// # `drop`
    ///
    /// Denne funksjonen blir kalt når en [`RawWaker`] blir droppet.
    ///
    /// Implementeringen av denne funksjonen må sørge for å frigjøre ressurser som er knyttet til denne forekomsten av en [`RawWaker`] og tilhørende oppgave.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` til en asynkron oppgave.
///
/// For øyeblikket tjener `Context` bare for å gi tilgang til en `&Waker` som kan brukes til å vekke den gjeldende oppgaven.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Sørg for at vi er future-sikre mot variansendringer ved å tvinge levetiden til å være invariant (argumentposisjonens levetid er kontravariant mens returposisjonens levetid er kovariant).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Opprett en ny `Context` fra en `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Returnerer en referanse til `Waker` for gjeldende oppgave.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// En `Waker` er et håndtak for å vekke en oppgave ved å varsle eksekutøren om at den er klar til å kjøres.
///
/// Dette håndtaket innkapsler en [`RawWaker`]-forekomst, som definerer den eksekutorspesifikke oppvåkningsatferden.
///
///
/// Implementerer [`Clone`], [`Send`] og [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Våkn opp oppgaven knyttet til denne `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Den faktiske oppvåkningssamtalen delegeres gjennom en virtuell funksjonsanrop til implementeringen som er definert av utføreren.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ikke ring `drop`-waker vil bli fortært av `wake`.
        crate::mem::forget(self);

        // SIKKERHET: Dette er trygt fordi `Waker::from_raw` er den eneste måten
        // å initialisere `wake` og `data` som krever at brukeren anerkjenner at kontrakten til `RawWaker` er opprettholdt.
        //
        unsafe { (wake)(data) };
    }

    /// Våkn opp oppgaven knyttet til denne `Waker` uten å forbruke `Waker`.
    ///
    /// Dette ligner på `wake`, men kan være litt mindre effektivt i tilfeller der en eid `Waker` er tilgjengelig.
    /// Denne metoden bør foretrekkes fremfor å ringe `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Den faktiske oppvåkningssamtalen delegeres gjennom en virtuell funksjonsanrop til implementeringen som er definert av utføreren.
        //

        // SIKKERHET: se `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Returnerer `true` hvis denne `Waker` og en annen `Waker` har vekket den samme oppgaven.
    ///
    /// Denne funksjonen fungerer best mulig, og kan returnere falsk, selv når Waker ville vekke den samme oppgaven.
    /// Imidlertid, hvis denne funksjonen returnerer `true`, er det garantert at `Waker`s vil vekke den samme oppgaven.
    ///
    /// Denne funksjonen brukes primært til optimaliseringsformål.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Oppretter en ny `Waker` fra [`RawWaker`].
    ///
    /// Oppførselen til den returnerte `Waker` er udefinert hvis kontrakten som er definert i ['RawWaker'] og ['RawWakerVTable'] 's dokumentasjon ikke blir opprettholdt.
    ///
    /// Derfor er denne metoden usikker.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SIKKERHET: Dette er trygt fordi `Waker::from_raw` er den eneste måten
            // å initialisere `clone` og `data` som krever at brukeren anerkjenner at kontrakten til [`RawWaker`] er opprettholdt.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SIKKERHET: Dette er trygt fordi `Waker::from_raw` er den eneste måten
        // å initialisere `drop` og `data` som krever at brukeren anerkjenner at kontrakten til `RawWaker` er opprettholdt.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}