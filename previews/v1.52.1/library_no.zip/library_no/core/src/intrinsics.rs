//! Kompilatorens egenart.
//!
//! De tilsvarende definisjonene er i `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! De tilsvarende const-implementeringene er i `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const iboende
//!
//! Note: eventuelle endringer i egenskapen til egenskapene bør diskuteres med språklaget.
//! Dette inkluderer endringer i konstansen.
//!
//! For å gjøre en egen brukbar ved kompileringstid, må man kopiere implementeringen fra <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> til `compiler/rustc_mir/src/interpret/intrinsics.rs` og legge til en `#[rustc_const_unstable(feature = "foo", issue = "01234")]` til den indre.
//!
//!
//! Hvis en egenart skal brukes fra en `const fn` med en `rustc_const_stable`-attributt, må egenskapens attributt også være `rustc_const_stable`.
//! En slik endring bør ikke gjøres uten T-lang-konsultasjon, fordi den baker en funksjon inn i språket som ikke kan replikeres i brukerkode uten kompilatorstøtte.
//!
//! # Volatiles
//!
//! De flyktige egenskapene gir operasjoner som er ment å fungere på I/O-minne, som garantert ikke blir omorganisert av kompilatoren på tvers av andre flyktige innbyggere.Se LLVM-dokumentasjonen på [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atomens egenart gir vanlige atomoperasjoner på maskinord, med flere mulige minnebestillinger.De adlyder samme semantikk som C++ 11.Se LLVM-dokumentasjonen på [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! En rask oppdatering på minnebestilling:
//!
//! * Erverve, en barriere for å anskaffe en lås.Etterfølgende lesing og skriving finner sted etter barrieren.
//! * Slipp, en barriere for å frigjøre en lås.Forrige lesing og skriving foregår før barrieren.
//! * Sekvensielt konsistente, sekvensielt konsistente operasjoner er garantert å skje i orden.Dette er standardmodus for arbeid med atomtyper og tilsvarer Java s `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Denne importen brukes for å forenkle intra-doc lenker
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SIKKERHET: se `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, disse egenskapene tar rå pekepinner fordi de muterer aliasminne, noe som ikke er gyldig for verken `&` eller `&mut`.
    //

    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange`-metoden ved å sende [`Ordering::SeqCst`] som både `success`-og `failure`-parametere.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange`-metoden ved å sende [`Ordering::Acquire`] som både `success`-og `failure`-parametere.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange`-metoden ved å sende [`Ordering::Release`] som `success` og [`Ordering::Relaxed`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange`-metoden ved å sende [`Ordering::AcqRel`] som `success` og [`Ordering::Acquire`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange`-metoden ved å sende [`Ordering::Relaxed`] som både `success`-og `failure`-parametere.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange`-metoden ved å sende [`Ordering::SeqCst`] som `success` og [`Ordering::Relaxed`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange`-metoden ved å sende [`Ordering::SeqCst`] som `success` og [`Ordering::Acquire`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange`-metoden ved å sende [`Ordering::Acquire`] som `success` og [`Ordering::Relaxed`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange`-metoden ved å sende [`Ordering::AcqRel`] som `success` og [`Ordering::Relaxed`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange_weak`-metoden ved å sende [`Ordering::SeqCst`] som både `success`-og `failure`-parametere.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange_weak`-metoden ved å sende [`Ordering::Acquire`] som både `success`-og `failure`-parametere.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange_weak`-metoden ved å sende [`Ordering::Release`] som `success` og [`Ordering::Relaxed`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange_weak`-metoden ved å sende [`Ordering::AcqRel`] som `success` og [`Ordering::Acquire`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange_weak`-metoden ved å sende [`Ordering::Relaxed`] som både `success`-og `failure`-parametere.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange_weak`-metoden ved å sende [`Ordering::SeqCst`] som `success` og [`Ordering::Relaxed`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange_weak`-metoden ved å sende [`Ordering::SeqCst`] som `success` og [`Ordering::Acquire`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange_weak`-metoden ved å sende [`Ordering::Acquire`] som `success` og [`Ordering::Relaxed`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrer en verdi hvis den nåværende verdien er den samme som `old`-verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `compare_exchange_weak`-metoden ved å sende [`Ordering::AcqRel`] som `success` og [`Ordering::Relaxed`] som `failure`-parametere.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Laster inn nåværende verdi av pekeren.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `load`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Laster inn nåværende verdi av pekeren.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `load`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Laster inn nåværende verdi av pekeren.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `load`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Lagrer verdien på den angitte minneplasseringen.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `store`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Lagrer verdien på den angitte minneplasseringen.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `store`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Lagrer verdien på den angitte minneplasseringen.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `store`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Lagrer verdien på den angitte minneplasseringen, og returnerer den gamle verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `swap`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lagrer verdien på den angitte minneplasseringen, og returnerer den gamle verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `swap`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lagrer verdien på den angitte minneplasseringen, og returnerer den gamle verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `swap`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lagrer verdien på den angitte minneplasseringen, og returnerer den gamle verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `swap`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lagrer verdien på den angitte minneplasseringen, og returnerer den gamle verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `swap`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Legger til den nåværende verdien og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_add`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Legger til den nåværende verdien og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_add`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Legger til den nåværende verdien og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_add`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Legger til den nåværende verdien og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_add`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Legger til den nåværende verdien og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_add`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Trekk fra gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_sub`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trekk fra gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_sub`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trekk fra gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_sub`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trekk fra gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_sub`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Trekk fra gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_sub`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis og med gjeldende verdi, returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_and`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og med gjeldende verdi, returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_and`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og med gjeldende verdi, returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_and`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og med gjeldende verdi, returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_and`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og med gjeldende verdi, returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_and`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis nand med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis eller med gjeldende verdi, og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_or`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med gjeldende verdi, og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_or`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med gjeldende verdi, og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_or`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med gjeldende verdi, og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_or`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med gjeldende verdi, og returnerer den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_or`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis x eller med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_xor`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_xor`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_xor`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_xor`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med gjeldende verdi, og returner den forrige verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-typene via `fetch_xor`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum med gjeldende verdi ved hjelp av en signert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med gjeldende verdi ved hjelp av en signert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med gjeldende verdi ved hjelp av en signert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med gjeldende verdi ved hjelp av en signert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med gjeldende verdi.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum med gjeldende verdi ved bruk av en signert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med gjeldende verdi ved bruk av en signert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med gjeldende verdi ved bruk av en signert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med gjeldende verdi ved bruk av en signert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med gjeldende verdi ved bruk av en signert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`]-signerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum med gjeldende verdi ved bruk av usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med gjeldende verdi ved bruk av usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med gjeldende verdi ved bruk av usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med gjeldende verdi ved bruk av usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med gjeldende verdi ved bruk av usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_min`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum med gjeldende verdi ved bruk av en usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med gjeldende verdi ved bruk av en usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med gjeldende verdi ved bruk av en usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med gjeldende verdi ved bruk av en usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med gjeldende verdi ved bruk av en usignert sammenligning.
    ///
    /// Den stabiliserte versjonen av denne egenskapen er tilgjengelig på [`atomic`] usignerte heltallstyper via `fetch_max`-metoden ved å sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` iboende er et hint til kodegeneratoren for å sette inn en forhånds hentingsinstruksjon hvis den støttes;ellers er det en no-op.
    /// Forhentinger har ingen innvirkning på oppførselen til programmet, men kan endre ytelsesegenskapene.
    ///
    /// `locality`-argumentet må være et konstant heltall og er en tidsmessig lokalitetsspesifikator som spenner fra (0), ingen lokalitet, til (3), ekstremt lokalt i cache.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` iboende er et hint til kodegeneratoren for å sette inn en forhånds hentingsinstruksjon hvis den støttes;ellers er det en no-op.
    /// Forhentinger har ingen innvirkning på oppførselen til programmet, men kan endre ytelsesegenskapene.
    ///
    /// `locality`-argumentet må være et konstant heltall og er en tidsmessig lokalitetsspesifikator som spenner fra (0), ingen lokalitet, til (3), ekstremt lokalt i cache.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` iboende er et hint til kodegeneratoren for å sette inn en forhånds hentingsinstruksjon hvis den støttes;ellers er det en no-op.
    /// Forhentinger har ingen innvirkning på oppførselen til programmet, men kan endre ytelsesegenskapene.
    ///
    /// `locality`-argumentet må være et konstant heltall og er en tidsmessig lokalitetsspesifikator som spenner fra (0), ingen lokalitet, til (3), ekstremt lokalt i cache.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` iboende er et hint til kodegeneratoren for å sette inn en forhånds hentingsinstruksjon hvis den støttes;ellers er det en no-op.
    /// Forhentinger har ingen innvirkning på oppførselen til programmet, men kan endre ytelsesegenskapene.
    ///
    /// `locality`-argumentet må være et konstant heltall og er en tidsmessig lokalitetsspesifikator som spenner fra (0), ingen lokalitet, til (3), ekstremt lokalt i cache.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Et atomgjerde.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig i [`atomic::fence`] ved å sende [`Ordering::SeqCst`] som `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Et atomgjerde.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig i [`atomic::fence`] ved å sende [`Ordering::Acquire`] som `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Et atomgjerde.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig i [`atomic::fence`] ved å sende [`Ordering::Release`] som `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Et atomgjerde.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig i [`atomic::fence`] ved å sende [`Ordering::AcqRel`] som `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// En minnesperre bare for kompilator.
    ///
    /// Minnetilgang blir aldri omorganisert over denne barrieren av kompilatoren, men ingen instruksjoner vil bli sendt ut for den.
    /// Dette er hensiktsmessig for operasjoner på samme tråd som kan være forhindret, for eksempel når du kommuniserer med signalbehandlere.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig i [`atomic::compiler_fence`] ved å sende [`Ordering::SeqCst`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// En minnesperre bare for kompilator.
    ///
    /// Minnetilgang blir aldri omorganisert over denne barrieren av kompilatoren, men ingen instruksjoner vil bli sendt ut for den.
    /// Dette er hensiktsmessig for operasjoner på samme tråd som kan være forhindret, for eksempel når du kommuniserer med signalbehandlere.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig i [`atomic::compiler_fence`] ved å sende [`Ordering::Acquire`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// En minnesperre bare for kompilator.
    ///
    /// Minnetilgang blir aldri omorganisert over denne barrieren av kompilatoren, men ingen instruksjoner vil bli sendt ut for den.
    /// Dette er hensiktsmessig for operasjoner på samme tråd som kan være forhindret, for eksempel når du kommuniserer med signalbehandlere.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig i [`atomic::compiler_fence`] ved å sende [`Ordering::Release`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// En minnesperre bare for kompilator.
    ///
    /// Minnetilgang blir aldri omorganisert over denne barrieren av kompilatoren, men ingen instruksjoner vil bli sendt ut for den.
    /// Dette er hensiktsmessig for operasjoner på samme tråd som kan være forhindret, for eksempel når du kommuniserer med signalbehandlere.
    ///
    /// Den stabiliserte versjonen av dette iboende er tilgjengelig i [`atomic::compiler_fence`] ved å sende [`Ordering::AcqRel`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magisk iboende som henter sin betydning fra attributter knyttet til funksjonen.
    ///
    /// For eksempel bruker dataflyt dette til å injisere statiske påstander slik at `rustc_peek(potentially_uninitialized)` faktisk vil dobbeltsjekke at dataflyten faktisk beregnet at den ikke er initialisert på det tidspunktet i kontrollflyten.
    ///
    ///
    /// Denne egenskapen skal ikke brukes utenfor kompilatoren.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Avbryter gjennomføringen av prosessen.
    ///
    /// En mer brukervennlig og stabil versjon av denne operasjonen er [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informerer optimalisereren om at dette punktet i koden ikke kan nås, noe som muliggjør ytterligere optimaliseringer.
    ///
    /// NB, dette er veldig forskjellig fra `unreachable!()`-makroen: I motsetning til makroen, som panics når den kjøres, er det *udefinert oppførsel* å nå kode merket med denne funksjonen.
    ///
    ///
    /// Den stabiliserte versjonen av dette iboende er [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informerer optimalisereren om at en tilstand alltid er oppfylt.
    /// Hvis tilstanden er falsk, er oppførselen udefinert.
    ///
    /// Det genereres ingen kode for dette iboende, men optimalisereren vil prøve å bevare den (og dens tilstand) mellom passeringene, noe som kan forstyrre optimaliseringen av koden rundt og redusere ytelsen.
    /// Det bør ikke brukes hvis invarianten kan oppdages av optimalisereren alene, eller hvis den ikke muliggjør noen vesentlige optimaliseringer.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Tips til kompilatoren at branch-tilstanden sannsynligvis vil være sant.
    /// Returnerer verdien som er sendt til den.
    ///
    /// Enhver annen bruk enn med `if`-utsagn vil sannsynligvis ikke ha noen effekt.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Tips til kompilatoren at tilstanden branch sannsynligvis er falsk.
    /// Returnerer verdien som er sendt til den.
    ///
    /// Enhver annen bruk enn med `if`-utsagn vil sannsynligvis ikke ha noen effekt.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Utfører en knekkpunktfelle for inspeksjon av en feilsøkingsprogram.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn breakpoint();

    /// Størrelsen på en type i byte.
    ///
    /// Mer spesifikt er dette forskyvningen i byte mellom påfølgende elementer av samme type, inkludert justeringspolstring.
    ///
    ///
    /// Den stabiliserte versjonen av dette iboende er [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Minimumstilpasning av en type.
    ///
    /// Den stabiliserte versjonen av dette iboende er [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Den foretrukne justeringen av en type.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Størrelsen på den refererte verdien i byte.
    ///
    /// Den stabiliserte versjonen av dette iboende er [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Den nødvendige justeringen av den refererte verdien.
    ///
    /// Den stabiliserte versjonen av dette iboende er [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Får en statisk strengdel som inneholder navnet på en type.
    ///
    /// Den stabiliserte versjonen av dette iboende er [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Får en identifikator som er global unik for den angitte typen.
    /// Denne funksjonen vil returnere den samme verdien for en type uavhengig av hvilken crate den blir påkalt.
    ///
    ///
    /// Den stabiliserte versjonen av dette iboende er [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// En vakt for usikre funksjoner som aldri kan utføres hvis `T` er ubebodd:
    /// Dette vil statisk enten panic, eller gjøre ingenting.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// En vakt for usikre funksjoner som aldri kan utføres hvis `T` ikke tillater null initialisering: Dette vil statisk enten panic, eller gjøre ingenting.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn assert_zero_valid<T>();

    /// En vakt for usikre funksjoner som aldri kan utføres hvis `T` har ugyldige bitmønstre: Dette vil statisk enten panic, eller gjøre ingenting.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn assert_uninit_valid<T>();

    /// Får en referanse til en statisk `Location` som indikerer hvor den ble kalt.
    ///
    /// Vurder å bruke [`core::panic::Location::caller`](crate::panic::Location::caller) i stedet.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Flytter en verdi utenfor omfanget uten å kjøre drop lim.
    ///
    /// Dette eksisterer bare for [`mem::forget_unsized`];normal `forget` bruker `ManuallyDrop` i stedet.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Gjentolker bitene av en verdi av en type som en annen type.
    ///
    /// Begge typene må ha samme størrelse.
    /// Verken originalen eller resultatet kan være en [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` tilsvarer semantisk en bitvis flytting av en type til en annen.Den kopierer bitene fra kildeverdien til destinasjonsverdien, og glemmer deretter originalen.
    /// Det tilsvarer Cs `memcpy` under panseret, akkurat som `transmute_copy`.
    ///
    /// Fordi `transmute` er en byverdioperasjon, er ikke justering av de *transmuterte verdiene* en bekymring.
    /// Som med alle andre funksjoner, sørger kompilatoren allerede for at både `T` og `U` er riktig justert.
    /// Imidlertid, når du overfører verdier som *peker et annet sted*(som pekere, referanser, ruter ...), må den som ringer sørge for riktig justering av de pekede verdiene.
    ///
    /// `transmute` er **utrolig** utrygt.Det er mange måter å forårsake [undefined behavior][ub] med denne funksjonen.`transmute` bør være den absolutt siste utvei.
    ///
    /// [nomicon](../../nomicon/transmutes.html) har tilleggsdokumentasjon.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Det er noen få ting som `transmute` er veldig nyttig for.
    ///
    /// Gjør en peker til en funksjonspeker.Dette er *ikke* bærbart til maskiner der funksjonspekere og datapekere har forskjellige størrelser.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Forlenge en levetid, eller forkorte en uendelig levetid.Dette er avansert, veldig usikkert Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Fortvil ikke: mange bruksområder av `transmute` kan oppnås på andre måter.
    /// Nedenfor er vanlige applikasjoner av `transmute` som kan erstattes med sikrere konstruksjoner.
    ///
    /// Slå rå bytes(`&[u8]`) til `u32`, `f64`, osv .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // bruk `u32::from_ne_bytes` i stedet
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // eller bruk `u32::from_le_bytes` eller `u32::from_be_bytes` for å spesifisere endigheten
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Gjør en peker til en `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Bruk en `as`-rollebesetning i stedet
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Gjør en `*mut T` til en `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Bruk en gjenopplasting i stedet
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Gjør en `&mut T` til en `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Sett sammen `as` og gjenlån, merk at kjetting av `as` `as` ikke er i overgang
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Gjør en `&str` til en `&[u8]`:
    ///
    /// ```
    /// // dette er ikke en god måte å gjøre dette på.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Du kan bruke `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Eller bruk bare en byte-streng hvis du har kontroll over strengen bokstavelig
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Gjør en `Vec<&T>` til en `Vec<Option<&T>>`.
    ///
    /// For å overføre den indre typen av innholdet i en container, må du sørge for å ikke bryte med noen av containerens invarianter.
    /// For `Vec` betyr dette at både størrelsen *og justeringen* av de indre typene må matche.
    /// Andre containere kan stole på størrelsen på typen, justeringen eller til og med `TypeId`, i hvilket tilfelle transmuting ikke ville være mulig i det hele tatt uten å bryte container invarianter.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klone vector da vi vil bruke dem senere
    /// let v_clone = v_orig.clone();
    ///
    /// // Ved hjelp av transmute: dette er avhengig av den uspesifiserte datalayouten til `Vec`, noe som er en dårlig ide og kan forårsake udefinert oppførsel.
    /////
    /// // Imidlertid er det ingen kopi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dette er den foreslåtte, trygge måten.
    /// // Det kopierer imidlertid hele vector til en ny matrise.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dette er den riktige, ikke-kopierte, usikre måten å "transmuting" og `Vec` på, uten å stole på datalayouten.
    /// // I stedet for å bokstavelig talt ringe `transmute`, utfører vi en pekestøping, men når det gjelder å konvertere den opprinnelige indre typen (`&i32`) til den nye (`Option<&i32>`), har dette de samme advarslene.
    /////
    /// // I tillegg til informasjonen ovenfor, se også [`from_raw_parts`]-dokumentasjonen.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Oppdater dette når vec_into_raw_parts er stabilisert.
    ///     // Forsikre deg om at den originale vector ikke tappes.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementering av `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Det er flere måter å gjøre dette på, og det er flere problemer med følgende (transmute)-måte.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // først: transmute er ikke typesikker;alt det sjekker er at T og
    ///         // Du er av samme størrelse.
    ///         // For det andre, akkurat her, har du to foranderlige referanser som peker på samme minne.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dette blir kvitt typen sikkerhetsproblemer;`&mut *` vil* bare *gi deg en `&mut T` fra en `&mut T` eller `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // imidlertid har du fremdeles to foranderlige referanser som peker på samme minne.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Slik gjør standardbiblioteket det.
    /// // Dette er den beste metoden, hvis du trenger å gjøre noe slikt
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Dette har nå tre foranderlige referanser som peker på samme minne.`slice`, rverdien ret.0 og rverdien ret.1.
    ///         // `slice` brukes aldri etter `let ptr = ...`, og man kan behandle det som "dead", og derfor har du bare to virkelige foranderlige skiver.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Selv om dette gjør den indre const stabil, har vi litt tilpasset kode i const fn
    // sjekker som forhindrer bruk innen `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Returnerer `true` hvis den faktiske typen gitt som `T` krever drop lim;returnerer `false` hvis den faktiske typen som er gitt for `T` implementerer `Copy`.
    ///
    ///
    /// Hvis den faktiske typen verken krever droplim eller implementerer `Copy`, er returverdien til denne funksjonen uspesifisert.
    ///
    /// Den stabiliserte versjonen av dette iboende er [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Beregner forskyvningen fra en peker.
    ///
    /// Dette er implementert som et iboende for å unngå konvertering til og fra et helt tall, siden konverteringen vil kaste bort aliaseringsinformasjon.
    ///
    /// # Safety
    ///
    /// Både startpekeren og den resulterende pekeren må være enten i rammer eller en byte forbi slutten av et tildelt objekt.
    /// Hvis enten pekeren er utenfor grensene eller aritmetisk overløp oppstår, vil enhver videre bruk av den returnerte verdien resultere i udefinert oppførsel.
    ///
    ///
    /// Den stabiliserte versjonen av dette iboende er [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Beregner forskyvningen fra en peker, eventuelt innpakning.
    ///
    /// Dette er implementert som et iboende for å unngå konvertering til og fra et helt tall, siden konverteringen hemmer visse optimaliseringer.
    ///
    /// # Safety
    ///
    /// I motsetning til `offset` iboende, begrenser ikke denne egenskapen den resulterende pekeren til å peke inn i eller en byte forbi enden av et tildelt objekt, og den brytes med tos komplementaritmetikk.
    /// Den resulterende verdien er ikke nødvendigvis gyldig for å brukes til å faktisk få tilgang til minne.
    ///
    /// Den stabiliserte versjonen av dette iboende er [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Tilsvarer riktig `llvm.memcpy.p0i8.0i8.*` iboende, med en størrelse på `count`*`size_of::<T>()` og en justering av
    ///
    /// `min_align_of::<T>()`
    ///
    /// Den flyktige parameteren er satt til `true`, så den blir ikke optimalisert med mindre størrelsen er lik null.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Tilsvarer riktig `llvm.memmove.p0i8.0i8.*` iboende, med en størrelse på `count* size_of::<T>()` og en justering av
    ///
    /// `min_align_of::<T>()`
    ///
    /// Den flyktige parameteren er satt til `true`, så den blir ikke optimalisert med mindre størrelsen er lik null.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Tilsvarer riktig `llvm.memset.p0i8.*` iboende, med en størrelse på `count* size_of::<T>()` og en justering av `min_align_of::<T>()`.
    ///
    ///
    /// Den flyktige parameteren er satt til `true`, så den blir ikke optimalisert med mindre størrelsen er lik null.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Utfører en flyktig belastning fra `src`-pekeren.
    ///
    /// Den stabiliserte versjonen av dette iboende er [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Utfører en ustabil butikk til `dst`-pekeren.
    ///
    /// Den stabiliserte versjonen av dette iboende er [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Utfører en flyktig belastning fra `src`-pekeren. Det er ikke nødvendig at pekeren er justert.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Utfører en ustabil butikk til `dst`-pekeren.
    /// Det kreves ikke at pekeren er justert.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Returnerer kvadratroten til en `f32`
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Returnerer kvadratroten til en `f64`
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Løfter en `f32` til et heltall.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Hever en `f64` til et heltall.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Returnerer sinus til en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Returnerer sinus til en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Returnerer cosinus til en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Returnerer cosinus til en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Løfter en `f32` til en `f32`-effekt.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Løfter en `f64` til en `f64`-effekt.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Returnerer eksponentiell for en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Returnerer eksponentiell for en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Returnerer 2 hevet til kraften til en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Returnerer 2 hevet til kraften til en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Returnerer den naturlige logaritmen til en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Returnerer den naturlige logaritmen til en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Returnerer 10 basalogaritmen til en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Returnerer 10 basalogaritmen til en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Returnerer base 2-logaritmen til en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Returnerer base 2-logaritmen til en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Returnerer `a * b + c` for `f32`-verdier.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Returnerer `a * b + c` for `f64`-verdier.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Returnerer absoluttverdien til en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Returnerer absoluttverdien til en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Returnerer minimum to `f32`-verdier.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Returnerer minimum to `f64`-verdier.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Returnerer maksimalt to `f32`-verdier.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Returnerer maksimalt to `f64`-verdier.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopierer tegnet fra `y` til `x` for `f32`-verdier.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopierer tegnet fra `y` til `x` for `f64`-verdier.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Returnerer det største heltallet mindre enn eller lik en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Returnerer det største heltallet mindre enn eller lik en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Returnerer det minste heltallet større enn eller lik en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Returnerer det minste heltallet større enn eller lik en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Returnerer heltall av en `f32`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Returnerer heltall av en `f64`.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Returnerer nærmeste heltall til en `f32`.
    /// Kan heve et unøyaktig unntak for flytende punkt hvis argumentet ikke er et helt tall.
    pub fn rintf32(x: f32) -> f32;
    /// Returnerer nærmeste heltall til en `f64`.
    /// Kan heve et unøyaktig unntak for flytende punkt hvis argumentet ikke er et helt tall.
    pub fn rintf64(x: f64) -> f64;

    /// Returnerer nærmeste heltall til en `f32`.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Returnerer nærmeste heltall til en `f64`.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Returnerer nærmeste heltall til en `f32`.Avrunder halvveis tilfeller vekk fra null.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Returnerer nærmeste heltall til en `f64`.Avrunder halvveis tilfeller vekk fra null.
    ///
    /// Den stabiliserte versjonen av dette iboende er
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Flyttilsetning som tillater optimaliseringer basert på algebraiske regler.
    /// Kan anta at innspillene er endelige.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Flyt subtraksjon som tillater optimaliseringer basert på algebraiske regler.
    /// Kan anta at innspillene er endelige.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Flytmultiplikasjon som tillater optimaliseringer basert på algebraiske regler.
    /// Kan anta at innspillene er endelige.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Flytdeling som tillater optimaliseringer basert på algebraiske regler.
    /// Kan anta at innspillene er endelige.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Flyterest som tillater optimaliseringer basert på algebraiske regler.
    /// Kan anta at innspillene er endelige.
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konverter med LLVMs fptoui/fptosi, som kan returnere undef for verdier utenfor området
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilisert som [`f32::to_int_unchecked`] og [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Returnerer antall bits som er satt i et heltallstype `T`
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `count_ones`-metoden.
    /// For eksempel,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Returnerer antall ledende usettbiter (zeroes) i et heltall `T`.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `leading_zeros`-metoden.
    /// For eksempel,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// En `x` med verdien `0` vil returnere bitbredden til `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Som `ctlz`, men ekstra utrygt da den returnerer `undef` når den får en `x` med verdien `0`.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Returnerer antall etterfølgende usettbiter (zeroes) i et heltall `T`.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `trailing_zeros`-metoden.
    /// For eksempel,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// En `x` med verdien `0` vil returnere bitbredden til `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Som `cttz`, men ekstra utrygt da den returnerer `undef` når den får en `x` med verdien `0`.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Omvendt byte i et heltall `T`.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `swap_bytes`-metoden.
    /// For eksempel,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Vender bitene i et helt tall `T`.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `reverse_bits`-metoden.
    /// For eksempel,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Utfører merket heltallstilsetning.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `overflowing_add`-metoden.
    /// For eksempel,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Utfører sjekket heltall subtraksjon
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `overflowing_sub`-metoden.
    /// For eksempel,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Utfører sjekket heltallsmultiplikasjon
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `overflowing_mul`-metoden.
    /// For eksempel,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Utfører en nøyaktig inndeling, noe som resulterer i udefinert oppførsel der `x % y != 0` eller `y == 0` eller `x == T::MIN && y == -1`
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Utfører en ukontrollert inndeling, noe som resulterer i udefinert oppførsel der `y == 0` eller `x == T::MIN && y == -1`
    ///
    ///
    /// Sikre innpakninger for dette iboende er tilgjengelig på heltallets primitiver via `checked_div`-metoden.
    /// For eksempel,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Returnerer resten av en ukontrollert inndeling, noe som resulterer i udefinert oppførsel når `y == 0` eller `x == T::MIN && y == -1`
    ///
    ///
    /// Sikre innpakninger for dette iboende er tilgjengelig på heltallets primitiver via `checked_rem`-metoden.
    /// For eksempel,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Utfører et ukontrollert venstre skift, noe som resulterer i udefinert oppførsel når `y < 0` eller `y >= N`, hvor N er bredden på T i bits.
    ///
    ///
    /// Sikre innpakninger for dette iboende er tilgjengelig på heltallets primitiver via `checked_shl`-metoden.
    /// For eksempel,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Utfører et ukontrollert høyre skift, noe som resulterer i udefinert oppførsel når `y < 0` eller `y >= N`, hvor N er bredden på T i bits.
    ///
    ///
    /// Sikre innpakninger for dette iboende er tilgjengelig på heltallets primitiver via `checked_shr`-metoden.
    /// For eksempel,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Returnerer resultatet av et ukontrollert tillegg, noe som resulterer i udefinert oppførsel når `x + y > T::MAX` eller `x + y < T::MIN`.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Returnerer resultatet av en ukontrollert subtraksjon, noe som resulterer i udefinert oppførsel når `x - y > T::MAX` eller `x - y < T::MIN`.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Returnerer resultatet av en ukontrollert multiplikasjon, noe som resulterer i udefinert oppførsel når `x *y > T::MAX` eller `x* y < T::MIN`.
    ///
    ///
    /// Denne egenskapen har ikke en stabil motstykke.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Utfører roter til venstre.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `rotate_left`-metoden.
    /// For eksempel,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Utfører roter til høyre.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `rotate_right`-metoden.
    /// For eksempel,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returnerer (a + b) mod 2 <sup>N</sup>, hvor N er bredden på T i bits.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `wrapping_add`-metoden.
    /// For eksempel,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returnerer (a, b) mod 2 <sup>N</sup>, hvor N er bredden på T i bits.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `wrapping_sub`-metoden.
    /// For eksempel,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returnerer (a * b) mod 2 <sup>N</sup>, hvor N er bredden på T i bits.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `wrapping_mul`-metoden.
    /// For eksempel,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Beregner `a + b`, metter ved numeriske grenser.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `saturating_add`-metoden.
    /// For eksempel,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Beregner `a - b`, metter ved numeriske grenser.
    ///
    /// De stabiliserte versjonene av dette iboende er tilgjengelig på heltallets primitiver via `saturating_sub`-metoden.
    /// For eksempel,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Returnerer verdien av diskriminanten for varianten i 'v';
    /// hvis `T` ikke har noen diskriminant, returnerer `0`.
    ///
    /// Den stabiliserte versjonen av dette iboende er [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Returnerer antall varianter av typen `T` støpt til en `usize`;
    /// hvis `T` ikke har varianter, returnerer `0`.Ubebodde varianter vil telles.
    ///
    /// Den å være stabiliserte versjonen av dette iboende er [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust s "try catch"-konstruksjon som påkaller funksjonspekeren `try_fn` med datapekeren `data`.
    ///
    /// Det tredje argumentet er en funksjon som kalles hvis en panic oppstår.
    /// Denne funksjonen tar datapekeren og en peker til det målspesifikke unntaksobjektet som ble fanget.
    ///
    /// For mer informasjon, se kompilatorens kilde samt std s fangstimplementering.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Avgir en `!nontemporal`-butikk i henhold til LLVM (se dokumentene deres).
    /// Sannsynligvis vil aldri bli stabil.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Se dokumentasjonen til `<*const T>::offset_from` for detaljer.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Se dokumentasjonen til `<*const T>::guaranteed_eq` for detaljer.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Se dokumentasjonen til `<*const T>::guaranteed_ne` for detaljer.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Tildel på kompileringstidspunktet.Bør ikke kalles ved kjøretid.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Noen funksjoner er definert her fordi de ved et uhell ble gjort tilgjengelig i denne modulen på stabil.
// Se <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` faller også inn i denne kategorien, men det kan ikke pakkes inn på grunn av kontrollen av at `T` og `U` har samme størrelse.)
//

/// Sjekker om `ptr` er riktig justert i forhold til `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopierer `count *size_of::<T>()` byte fra `src` til `dst`.Kilden og destinasjonen må* ikke * overlappe hverandre.
///
/// For områder med minne som kan overlappe hverandre, bruk [`copy`] i stedet.
///
/// `copy_nonoverlapping` er semantisk ekvivalent med Cs [`memcpy`], men med argumentordren byttet.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `src` må være [valid] for lesing av `count * size_of::<T>()` byte.
///
/// * `dst` må være [valid] for skriving av `count * size_of::<T>()` byte.
///
/// * Både `src` og `dst` må være riktig justert.
///
/// * Regionen til minnet som begynner på `src` med størrelsen på `count *
///   størrelsen av: :<T>() `byte må *ikke* overlappe med minneområdet som begynner på `dst` med samme størrelse.
///
/// I likhet med [`read`] lager `copy_nonoverlapping` en bitvis kopi av `T`, uavhengig av om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan *begge* verdiene i regionen som begynner på `*src` og regionen som begynner på `* dst` være [violate memory safety][read-ownership].
///
///
/// Merk at selv om den effektivt kopierte størrelsen (`count * size_of: :<T>()`) er `0`, må pekerne være ikke NULL og riktig justert.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manuelt implementere [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Flytter alle elementene i `src` til `dst`, slik at `src` er tom.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Forsikre deg om at `dst` har nok kapasitet til å holde hele `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Anropet om å kompensere er alltid trygt fordi `Vec` aldri vil tildele mer enn `isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Avkort `src` uten å slippe innholdet.
///         // Vi gjør dette først, for å unngå problemer i tilfelle noe lenger nede i panics.
///         src.set_len(0);
///
///         // De to regionene kan ikke overlappe hverandre fordi mutable referanser ikke har et alias, og to forskjellige vektorer kan ikke eie det samme minnet.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Gi `dst` beskjed om at den nå inneholder innholdet i `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Utfør disse kontrollene bare på kjøretid
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ikke få panikk for å holde kodegenes innvirkning mindre.
        abort();
    }*/

    // SIKKERHET: sikkerhetskontrakten for `copy_nonoverlapping` må være
    // opprettholdes av den som ringer.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopierer `count * size_of::<T>()` byte fra `src` til `dst`.Kilden og destinasjonen kan overlappe hverandre.
///
/// Hvis kilden og destinasjonen *aldri* overlapper hverandre, kan [`copy_nonoverlapping`] brukes i stedet.
///
/// `copy` er semantisk ekvivalent med Cs [`memmove`], men med argumentordren byttet.
/// Kopiering foregår som om byte ble kopiert fra `src` til en midlertidig matrise og deretter kopiert fra matrisen til `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `src` må være [valid] for lesing av `count * size_of::<T>()` byte.
///
/// * `dst` må være [valid] for skriving av `count * size_of::<T>()` byte.
///
/// * Både `src` og `dst` må være riktig justert.
///
/// I likhet med [`read`] lager `copy` en bitvis kopi av `T`, uavhengig av om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan både verdiene i regionen som begynner på `*src` og regionen som begynner på `* dst` [violate memory safety][read-ownership].
///
///
/// Merk at selv om den effektivt kopierte størrelsen (`count * size_of: :<T>()`) er `0`, må pekerne være ikke NULL og riktig justert.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Lag en Rust vector effektivt fra en usikker buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` må være riktig justert for sin type og ikke-null.
/// /// * `ptr` må være gyldig for lesing av `elts` sammenhengende elementer av typen `T`.
/// /// * Disse elementene må ikke brukes etter at du har kalt denne funksjonen med mindre `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SIKKERHET: Forutsetningen vår sørger for at kilden er justert og gyldig,
///     // og `Vec::with_capacity` sørger for at vi har brukbar plass til å skrive dem.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SIKKERHET: Vi skapte den med denne kapasiteten tidligere,
///     // og den forrige `copy` har initialisert disse elementene.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Utfør disse kontrollene bare på kjøretid
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ikke få panikk for å holde kodegenes innvirkning mindre.
        abort();
    }*/

    // SIKKERHET: sikkerhetskontrakten for `copy` må opprettholdes av den som ringer.
    unsafe { copy(src, dst, count) }
}

/// Stiller inn `count * size_of::<T>()` byte minne som starter ved `dst` til `val`.
///
/// `write_bytes` ligner Cs [`memset`], men setter `count * size_of::<T>()` byte til `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `dst` må være [valid] for skriving av `count * size_of::<T>()` byte.
///
/// * `dst` må være riktig justert.
///
/// I tillegg må den som ringer sørge for at skriving av `count * size_of::<T>()`-byte til den gitte minnesregionen resulterer i en gyldig verdi på `T`.
/// Å bruke et minneområde som er skrevet som en `T` som inneholder en ugyldig verdi på `T`, er udefinert oppførsel.
///
/// Merk at selv om den effektivt kopierte størrelsen (`count * size_of: :<T>()`) er `0`, må pekeren være ikke NULL og riktig justert.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Opprette en ugyldig verdi:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Lekker den tidligere holdt verdien ved å overskrive `Box<T>` med en nullpeker.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // På dette punktet fører bruk eller slipp av `v` til udefinert oppførsel.
/// // drop(v); // ERROR
///
/// // Selv lekker `v` "uses" det, og dermed er udefinert oppførsel.
/// // mem::forget(v); // ERROR
///
/// // Faktisk er `v` ugyldig i henhold til grunnleggende type invarianter, så *enhver* operasjon som berører den er udefinert oppførsel.
/////
/// // la v2 =v;//FEIL
///
/// unsafe {
///     // La oss i stedet sette inn en gyldig verdi
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nå er boksen i orden
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SIKKERHET: sikkerhetskontrakten for `write_bytes` må opprettholdes av den som ringer.
    unsafe { write_bytes(dst, val, count) }
}