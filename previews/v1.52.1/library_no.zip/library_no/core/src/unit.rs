use crate::iter::FromIterator;

/// Samler alle enhetselementene fra en iterator i en.
///
/// Dette er mer nyttig når det kombineres med abstraksjoner på høyere nivå, som å samle til en `Result<(), E>` der du bare bryr deg om feil:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}