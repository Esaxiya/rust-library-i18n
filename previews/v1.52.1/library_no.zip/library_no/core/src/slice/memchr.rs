// Original implementering hentet fra rust-memchr.
// Copyright 2015 Andrew Gallant, bluss og Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Bruk avkutt.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Returnerer `true` hvis `x` inneholder null byte.
///
/// Fra *Matters Computational*, J. Arndt:
///
/// "Ideen er å trekke en fra hver av byte og deretter se etter byte der lånet forplantet seg helt til det viktigste
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Returnerer den første indeksen som samsvarer med byten `x` i `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Rask sti for små skiver
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Skann etter en enkelt byteverdi ved å lese to `usize`-ord om gangen.
    //
    // Del `text` i tre deler
    // - ujustert første del, før den første ordjusterte adressen i teksten
    // - kropp, skann med to ord om gangen
    // - den siste gjenværende delen, <2 ordstørrelse

    // søke opp til en justert grense
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // søk i teksten
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SIKKERHET: tidenes predikat garanterer en avstand på minst 2 * usize_bytes
        // mellom forskyvningen og enden av stykket.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // pause hvis det er en matchende byte
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Finn byte etter det punktet kroppssløyfen stoppet.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Returnerer den siste indeksen som samsvarer med byten `x` i `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Skann etter en enkelt byteverdi ved å lese to `usize`-ord om gangen.
    //
    // Del `text` i tre deler:
    // - ujustert hale, etter siste ordjusterte adresse i tekst,
    // - body, skannet med to ord om gangen,
    // - de første gjenværende byte, <2 ordstørrelse.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Vi kaller dette bare for å få lengden på prefikset og suffikset.
        // I midten behandler vi alltid to biter på en gang.
        // SIKKERHET: Overføring av `[u8]` til `[usize]` er trygt bortsett fra størrelsesforskjeller som håndteres av `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Søk i teksten, pass på at vi ikke krysser min_justert_offset.
    // offset er alltid justert, så bare å teste `>` er tilstrekkelig og unngår mulig overløp.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SIKKERHET: forskyvning starter ved len, suffix.len(), så lenge den er større enn
        // min_aligned_offset (prefix.len()) den gjenværende avstanden er minst 2 * klump_byte.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Bryt hvis det er en matchende byte.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Finn byte før punktet kroppssløyfen stoppet.
    text[..offset].iter().rposition(|elt| *elt == x)
}