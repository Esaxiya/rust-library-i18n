//! Gratis funksjoner for å lage `&[T]` og `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Danner et stykke fra en peker og en lengde.
///
/// `len`-argumentet er antall **elementer**, ikke antall byte.
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `data` må være [valid] for lesing for `len * mem::size_of::<T>()` mange byte, og den må være riktig justert.Dette betyr spesielt:
///
///     * Hele minneområdet for denne delen må være inneholdt i et enkelt tildelt objekt!
///       Skiver kan aldri spenne over flere tildelte objekter.Se [below](#incorrect-usage) for et eksempel som ikke tar dette i betraktning.
///     * `data` må være ikke-null og justert selv for null-lengdesnitt.
///     En grunn til dette er at optimalisering av enum-layout kan stole på at referanser (inkludert skiver av hvilken som helst lengde) blir justert og ikke-null for å skille dem fra andre data.
///     Du kan skaffe deg en peker som kan brukes som `data` for skiver uten lengde ved hjelp av [`NonNull::dangling()`].
///
/// * `data` må peke på `len` påfølgende riktig initialiserte verdier av typen `T`.
///
/// * Minneet som det returnerte stykket refererer til, må ikke muteres så lenge `'a` varer, unntatt inne i en `UnsafeCell`.
///
/// * Den totale størrelsen `len * mem::size_of::<T>()` på stykket må ikke være større enn `isize::MAX`.
///   Se sikkerhetsdokumentasjonen til [`pointer::offset`].
///
/// # Caveat
///
/// Levetiden for den returnerte delen er utledet fra bruken.
/// For å forhindre utilsiktet misbruk, anbefales det å knytte levetiden til hvilken kilde levetiden som er trygg i sammenhengen, for eksempel ved å tilby en hjelperfunksjon som tar levetiden til en vertsverdi for stykket, eller ved eksplisitt kommentar.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifest et stykke for et enkelt element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Feil bruk
///
/// Følgende `join_slices`-funksjon er **usunt** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Påstanden ovenfor sikrer at `fst` og `snd` er sammenhengende, men de kan fremdeles være inneholdt i _different allocated objects_, i så fall å opprette denne delen er udefinert oppførsel.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` og `b` er forskjellige tildelte objekter ...
///     let a = 42;
///     let b = 27;
///     // ... som likevel kan legges sammen i minnet: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Utfører den samme funksjonaliteten som [`from_raw_parts`], bortsett fra at en muterbar del returneres.
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `data` må være [valid] for både leser og skriver for `len * mem::size_of::<T>()` mange byte, og den må være riktig justert.Dette betyr spesielt:
///
///     * Hele minneområdet for denne delen må være inneholdt i et enkelt tildelt objekt!
///       Skiver kan aldri spenne over flere tildelte objekter.
///     * `data` må være ikke-null og justert selv for null-lengdesnitt.
///     En grunn til dette er at optimalisering av enum-layout kan stole på at referanser (inkludert skiver av hvilken som helst lengde) blir justert og ikke-null for å skille dem fra andre data.
///
///     Du kan skaffe deg en peker som kan brukes som `data` for skiver uten lengde ved hjelp av [`NonNull::dangling()`].
///
/// * `data` må peke på `len` påfølgende riktig initialiserte verdier av typen `T`.
///
/// * Minneet som det returnerte stykket refererer til, må ikke nås gjennom noen annen peker (ikke hentet fra returverdien) i løpet av levetiden `'a`.
///   Både lese-og skrivetilgang er forbudt.
///
/// * Den totale størrelsen `len * mem::size_of::<T>()` på stykket må ikke være større enn `isize::MAX`.
///   Se sikkerhetsdokumentasjonen til [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Konverterer en referanse til T til et stykke lengde 1 (uten kopiering).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Konverterer en referanse til T til et stykke lengde 1 (uten kopiering).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}