//! Skivesortering
//!
//! Denne modulen inneholder en sorteringsalgoritme basert på Orson Peters 'mønsterbekjempende kviksort, publisert på: <https://github.com/orlp/pdqsort>
//!
//!
//! Ustabil sortering er kompatibel med libcore fordi den ikke tildeler minne, i motsetning til vår stabile sorteringsimplementering.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Når du slipper, kopierer du fra `src` til `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SIKKERHET: Dette er en hjelperklasse.
        //          Se bruken for korrekthet.
        //          Man må nemlig være sikker på at `src` og `dst` ikke overlapper slik `ptr::copy_nonoverlapping` krever.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Flytter det første elementet til høyre til det møter et større eller like element.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIKKERHET: De usikre operasjonene nedenfor innebærer indeksering uten innbundet sjekk (`get_unchecked` og `get_unchecked_mut`)
    // og kopieringsminne (`ptr::copy_nonoverlapping`).
    //
    // en.Indeksering:
    //  1. Vi sjekket størrelsen på matrisen til>=2.
    //  2. All indeksering som vi vil gjøre er alltid maksimalt mellom {0 <= index < len}.
    //
    // b.Minnekopiering
    //  1. Vi får tips til referanser som garantert er gyldige.
    //  2. De kan ikke overlappe hverandre fordi vi får pekere til forskjellsindeksene for stykket.
    //     Nemlig `i` og `i-1`.
    //  3. Hvis skiven er riktig justert, er elementene riktig justert.
    //     Det er den som ringer å sørge for at skiven er riktig justert.
    //
    // Se kommentarene nedenfor for ytterligere detaljer.
    unsafe {
        // Hvis de to første elementene ikke er i orden ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Les det første elementet i en stabelallokert variabel.
            // Hvis en følgende sammenligningsoperasjon panics, vil `hole` bli droppet og automatisk skrive elementet tilbake i stykket.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Flytt i-elementet ett sted til venstre, og skyv hullet til høyre.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` blir droppet og kopierer dermed `tmp` inn i det gjenværende hullet i `v`.
        }
    }
}

/// Flytter det siste elementet til venstre til det møter et mindre eller like element.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIKKERHET: De usikre operasjonene nedenfor innebærer indeksering uten innbundet sjekk (`get_unchecked` og `get_unchecked_mut`)
    // og kopieringsminne (`ptr::copy_nonoverlapping`).
    //
    // en.Indeksering:
    //  1. Vi sjekket størrelsen på matrisen til>=2.
    //  2. All indeksering som vi vil gjøre er alltid maksimalt mellom `0 <= index < len-1`.
    //
    // b.Minnekopiering
    //  1. Vi får tips til referanser som garantert er gyldige.
    //  2. De kan ikke overlappe hverandre fordi vi får pekere til forskjellsindeksene for stykket.
    //     Nemlig `i` og `i+1`.
    //  3. Hvis skiven er riktig justert, er elementene riktig justert.
    //     Det er den som ringer å sørge for at skiven er riktig justert.
    //
    // Se kommentarene nedenfor for ytterligere detaljer.
    unsafe {
        // Hvis de to siste elementene ikke er i orden ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Les det siste elementet i en stabelallokert variabel.
            // Hvis en følgende sammenligningsoperasjon panics, vil `hole` bli droppet og automatisk skrive elementet tilbake i stykket.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Flytt i-elementet ett sted til høyre, og skyv hullet til venstre.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` blir droppet og kopierer dermed `tmp` inn i det gjenværende hullet i `v`.
        }
    }
}

/// Sorterer delvis et stykke ved å flytte flere elementer utenfor ordren.
///
/// Returnerer `true` hvis delen er sortert på slutten.Denne funksjonen er *O*(*n*) i verste fall.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maksimalt antall tilstøtende par uten ordre som vil skiftes.
    const MAX_STEPS: usize = 5;
    // Hvis stykket er kortere enn dette, må du ikke flytte noen elementer.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SIKKERHET: Vi gjorde allerede eksplisitt kontrollen med `i < len`.
        // All vår påfølgende indeksering er bare i området `0 <= index < len`
        unsafe {
            // Finn neste par tilstøtende ordreelementer.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Er vi ferdige?
        if i == len {
            return true;
        }

        // Ikke skift elementer på korte matriser, det har en ytelseskostnad.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Bytt det funnet elementet.Dette setter dem i riktig rekkefølge.
        v.swap(i - 1, i);

        // Skyv det mindre elementet til venstre.
        shift_tail(&mut v[..i], is_less);
        // Skyv det større elementet til høyre.
        shift_head(&mut v[i..], is_less);
    }

    // Klarte ikke å sortere stykket i det begrensede antall trinn.
    false
}

/// Sorterer et stykke ved hjelp av innsettingssortering, som er *O*(*n*^ 2) i verste fall.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sorterer `v` ved hjelp av heapsort, noe som garanterer *O*(*n*\*log(* n*)) i verste fall.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Denne binære bunken respekterer den uforanderlige `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Barn av `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Velg det større barnet.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stopp hvis invarianten holder på `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Bytt `node` med det større barnet, flytt ett trinn ned og fortsett siktingen.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Bygg haugen på lineær tid.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maksimale elementer fra dyngen.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partisjoner `v` i elementer mindre enn `pivot`, etterfulgt av elementer som er større enn eller lik `pivot`.
///
///
/// Returnerer antall elementer mindre enn `pivot`.
///
/// Partisjonering utføres blokk-for-blokk for å minimere kostnadene ved forgrening.
/// Denne ideen presenteres i [BlockQuicksort][pdf]-papiret.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Antall elementer i en typisk blokk.
    const BLOCK: usize = 128;

    // Partisjoneringsalgoritmen gjentar følgende trinn til fullføring:
    //
    // 1. Spore en blokk fra venstre side for å identifisere elementer som er større enn eller lik dreietappen.
    // 2. Spor en blokk fra høyre side for å identifisere elementer som er mindre enn pivoten.
    // 3. Bytt ut de identifiserte elementene mellom venstre og høyre side.
    //
    // Vi har følgende variabler for en blokk med elementer:
    //
    // 1. `block` - Antall elementer i blokken.
    // 2. `start` - Start pekeren i `offsets`-arrayet.
    // 3. `end` - Sluttpekeren i `offsets`-arrayet.
    // 4. `forskyvninger, indekser av ordrer utenfor ordren i blokken.

    // Gjeldende blokk på venstre side (fra `l` til `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Gjeldende blokk på høyre side (fra `r.sub(block_r)` to `r`).
    // SIKKERHET: Dokumentasjonen for .add() nevner spesielt at `vec.as_ptr().add(vec.len())` alltid er trygt
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Når vi får VLA, prøv å lage en rekke lengder `min(v.len(), 2 * BLOCK) `heller
    // enn to faste størrelser med lengde `BLOCK`.VLA-er kan være mer cacheeffektive.

    // Returnerer antall elementer mellom pekerne `l` (inclusive) og `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Vi er ferdige med partisjonering blokk-for-blokk når `l` og `r` kommer veldig nært.
        // Deretter gjør vi litt oppdateringsarbeid for å partisjonere de gjenværende elementene i mellom.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Antall gjenværende elementer (fremdeles ikke sammenlignet med pivoten).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Juster blokkstørrelser slik at venstre og høyre blokk ikke overlapper hverandre, men blir perfekt justert for å dekke hele gjenværende gap.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Spor `block_l`-elementer fra venstre side.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SIKKERHET: Usikkerhetsoperasjonene nedenfor innebærer bruk av `offset`.
                //         I henhold til vilkårene som kreves av funksjonen, tilfredsstiller vi dem fordi:
                //         1. `offsets_l` er stack-allokert, og anses derfor som separat tildelt objekt.
                //         2. Funksjonen `is_less` returnerer en `bool`.
                //            Å kaste en `bool` vil aldri flyte over `isize`.
                //         3. Vi har garantert at `block_l` blir `<= BLOCK`.
                //            I tillegg ble `end_l` opprinnelig satt til startpekeren til `offsets_` som ble erklært på bunken.
                //            Dermed vet vi at selv i verste fall (alle påkallelser av `is_less` returnerer falske) vil vi bare maksimalt være 1 byte som passerer slutten.
                //        En annen usikkerhetsoperasjon her er dereferencing `elem`.
                //        Imidlertid var `elem` i utgangspunktet startpekeren til stykket som alltid er gyldig.
                unsafe {
                    // Grenløs sammenligning.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Spor `block_r`-elementer fra høyre side.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SIKKERHET: Usikkerhetsoperasjonene nedenfor innebærer bruk av `offset`.
                //         I henhold til vilkårene som kreves av funksjonen, tilfredsstiller vi dem fordi:
                //         1. `offsets_r` er stack-allokert, og anses derfor som separat tildelt objekt.
                //         2. Funksjonen `is_less` returnerer en `bool`.
                //            Å kaste en `bool` vil aldri flyte over `isize`.
                //         3. Vi har garantert at `block_r` blir `<= BLOCK`.
                //            I tillegg ble `end_r` opprinnelig satt til startpekeren til `offsets_` som ble erklært på bunken.
                //            Dermed vet vi at selv i verste fall (alle påkallinger av `is_less` returnerer sanne) vil vi bare maksimalt være 1 byte som passerer slutten.
                //        En annen usikkerhetsoperasjon her er dereferencing `elem`.
                //        Imidlertid var `elem` opprinnelig `1 *sizeof(T)` etter slutten, og vi reduserer den med `1* sizeof(T)` før vi får tilgang til den.
                //        I tillegg ble `block_r` hevdet å være mindre enn `BLOCK`, og `elem` vil derfor på det meste peke på begynnelsen av stykket.
                unsafe {
                    // Grenløs sammenligning.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Antall elementer som ikke er i ordre som skal byttes mellom venstre og høyre side.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // I stedet for å bytte ett par om gangen, er det mer effektivt å utføre en syklisk permutasjon.
            // Dette tilsvarer ikke strengt tatt bytte, men gir et lignende resultat ved å bruke færre minneoperasjoner.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Alle ordreelementer i venstre blokk ble flyttet.Gå til neste blokk.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Alle ut-bestillingselementer i høyre blokk ble flyttet.Gå til forrige blokk.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Alt som gjenstår nå er maksimalt ett kvartal (enten til venstre eller høyre) med elementer som ikke er i ordre som må flyttes.
    // Slike gjenværende elementer kan rett og slett flyttes til slutten i blokken.
    //

    if start_l < end_l {
        // Den venstre blokken forblir.
        // Flytt de gjenværende elementene som ikke er i ordre helt til høyre.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Den høyre blokken gjenstår.
        // Flytt de gjenværende elementene som ikke er i ordre helt til venstre.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ingenting annet å gjøre, vi er ferdige.
        width(v.as_mut_ptr(), l)
    }
}

/// Partisjoner `v` i elementer mindre enn `v[pivot]`, etterfulgt av elementer som er større enn eller lik `v[pivot]`.
///
///
/// Returnerer en tuple av:
///
/// 1. Antall elementer mindre enn `v[pivot]`.
/// 2. Sant hvis `v` allerede var partisjonert.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Plasser pivoten i begynnelsen av skiven.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Les pivoten i en stabiltildelt variabel for effektivitet.
        // Hvis en følgende sammenligningsoperasjon panics, blir pivoten automatisk skrevet tilbake i stykket.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Finn det første paret som ikke er i ordre.
        let mut l = 0;
        let mut r = v.len();

        // SIKKERHET: Usikkerheten nedenfor innebærer indeksering av en matrise.
        // For det første: Vi gjør allerede grensene for å sjekke her med `l < r`.
        // For den andre: Vi har i utgangspunktet `l == 0` og `r == v.len()`, og vi sjekket at `l < r` ved hver indekseringsoperasjon.
        //                     Herfra vet vi at `r` må være minst `r == l`, noe som ble vist å være gyldig fra den første.
        unsafe {
            // Finn det første elementet som er større enn eller lik pivoten.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Finn det siste elementet som er mindre enn pivoten.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` går utenfor omfanget og skriver pivoten (som er en stabelallokert variabel) tilbake i stykket der den opprinnelig var.
        // Dette trinnet er avgjørende for å sikre sikkerhet!
        //
    };

    // Plasser pivoten mellom de to partisjonene.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partisjoner `v` i elementer lik `v[pivot]` etterfulgt av elementer større enn `v[pivot]`.
///
/// Returnerer antall elementer som er lik pivot.
/// Det antas at `v` ikke inneholder elementer som er mindre enn pivoten.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Plasser pivoten i begynnelsen av skiven.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Les pivoten i en stabiltildelt variabel for effektivitet.
    // Hvis en følgende sammenligningsoperasjon panics, blir pivoten automatisk skrevet tilbake i stykket.
    // SIKKERHET: Pekeren her er gyldig fordi den er hentet fra en referanse til et stykke.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Del nå stykket.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SIKKERHET: Usikkerheten nedenfor innebærer indeksering av en matrise.
        // For det første: Vi gjør allerede grensene for å sjekke her med `l < r`.
        // For den andre: Vi har i utgangspunktet `l == 0` og `r == v.len()`, og vi sjekket at `l < r` ved hver indekseringsoperasjon.
        //                     Herfra vet vi at `r` må være minst `r == l`, noe som ble vist å være gyldig fra den første.
        unsafe {
            // Finn det første elementet som er større enn pivoten.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Finn det siste elementet som er lik pivoten.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Er vi ferdige?
            if l >= r {
                break;
            }

            // Bytt det funnet paret som ikke er i ordre.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Vi fant `l`-elementer som var lik svingpunktet.Legg til 1 på kontoen for selve pivoten.
    l + 1

    // `_pivot_guard` går utenfor omfanget og skriver pivoten (som er en stabelallokert variabel) tilbake i stykket der den opprinnelig var.
    // Dette trinnet er avgjørende for å sikre sikkerhet!
}

/// Spred noen elementer rundt i et forsøk på å bryte mønstre som kan forårsake ubalanserte partisjoner i kviksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom nummergenerator fra "Xorshift RNGs"-papiret av George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ta tilfeldige tall modulo dette tallet.
        // Antallet passer inn i `usize` fordi `len` ikke er større enn `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Noen pivotkandidater vil være i nærheten av denne indeksen.La oss randomisere dem.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generer et tilfeldig tall modulo `len`.
            // For å unngå kostbare operasjoner tar vi imidlertid først modulo en kraft på to, og senker deretter med `len` til den passer inn i området `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` er garantert mindre enn `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Velger en pivot i `v` og returnerer indeksen og `true` hvis delen sannsynligvis allerede er sortert.
///
/// Elementer i `v` kan bestilles på nytt.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimumslengde for å velge metian-of-medians-metoden.
    // Kortere skiver bruker den enkle median-av-tre-metoden.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maksimalt antall bytter som kan utføres i denne funksjonen.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tre indekser i nærheten som vi skal velge en pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Teller det totale antallet bytter vi skal utføre mens vi sorterer indekser.
    let mut swaps = 0;

    if len >= 8 {
        // Bytter indekser slik at `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Bytter indekser slik at `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Finner medianen til `v[a - 1], v[a], v[a + 1]` og lagrer indeksen i `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Finn medianer i nabolagene `a`, `b` og `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Finn medianen mellom `a`, `b` og `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Maksimalt antall bytter ble utført.
        // Sjansen er stor for at stykket er synkende eller for det meste synkende, så reversering vil sannsynligvis bidra til å sortere det raskere.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sorterer `v` rekursivt.
///
/// Hvis segmentet hadde en forgjenger i den opprinnelige matrisen, er den spesifisert som `pred`.
///
/// `limit` er antall tillatte ubalanserte partisjoner før du bytter til `heapsort`.
/// Hvis null, vil denne funksjonen umiddelbart bytte til heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Skiver opp til denne lengden blir sortert ved hjelp av innsettingssortering.
    const MAX_INSERTION: usize = 20;

    // Sant hvis den siste partisjonen var rimelig balansert.
    let mut was_balanced = true;
    // Sant hvis den siste partisjonen ikke blandet elementene (stykket var allerede delt).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Svært korte skiver blir sortert ved bruk av innsettingssortering.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Hvis det ble gjort for mange dårlige dreievalg, kan du bare falle tilbake til stort utvalg for å garantere `O(n * log(n))` i verste fall.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Hvis den siste partisjonen var i ubalanse, kan du prøve å bryte mønstre i stykket ved å blande noen elementer rundt.
        // Forhåpentligvis velger vi en bedre pivot denne gangen.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Velg en pivot og prøv å gjette om stykket allerede er sortert.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Hvis den siste partisjonen var anstendig balansert og ikke blandet elementene, og hvis pivotvalget forutsier at delen sannsynligvis allerede er sortert ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Prøv å identifisere flere ordrer og flytt dem til riktige posisjoner.
            // Hvis stykket ender med å bli helt sortert, er vi ferdige.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Hvis den valgte pivoten er lik forgjengeren, er den det minste elementet i stykket.
        // Del skiven i elementer som er like og elementer som er større enn pivoten.
        // Denne saken treffes vanligvis når segmentet inneholder mange dupliserte elementer.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Fortsett å sortere elementer som er større enn pivoten.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Del skiven.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Del stykket i `left`, `pivot` og `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Fortsett på kortsiden bare for å minimere det totale antallet rekursive samtaler og konsumere mindre stabelplass.
        // Så er det bare å fortsette med den lengre siden (dette ligner på halenrekursjon).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sorterer `v` ved hjelp av mønsterbeseirende quicksort, som er *O*(*n*\*log(* n*)) worst-case.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortering har ingen meningsfull oppførsel på nullstørrelsestyper.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Begrens antall ubalanserte partisjoner til `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // For stykker opp til denne lengden er det sannsynligvis raskere å bare sortere dem.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Velg en pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Hvis den valgte pivoten er lik forgjengeren, er den det minste elementet i stykket.
        // Del skiven i elementer som er like og elementer som er større enn pivoten.
        // Denne saken treffes vanligvis når segmentet inneholder mange dupliserte elementer.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Hvis vi har bestått indeksen vår, er vi gode.
                if mid > index {
                    return;
                }

                // Ellers fortsett å sortere elementer som er større enn pivoten.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Del stykket i `left`, `pivot` og `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Hvis midt==indeks, så er vi ferdige, siden partition() garanterte at alle elementene etter midten er større enn eller lik midten.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortering har ingen meningsfull oppførsel på nullstørrelsestyper.Gjør ingenting.
    } else if index == v.len() - 1 {
        // Finn maks-elementet og plasser det i den siste posisjonen til matrisen.
        // Vi kan bruke `unwrap()` her fordi vi vet at v ikke må være tom.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Finn min-element og plasser det i den første posisjonen til matrisen.
        // Vi kan bruke `unwrap()` her fordi vi vet at v ikke må være tom.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}