//! Makroer som brukes av iteratorer av skive.

// Inlining is_empty og len utgjør en enorm ytelsesforskjell
macro_rules! is_empty {
    // Slik vi koder lengden på en ZST iterator, fungerer dette både for ZST og ikke-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// For å bli kvitt noen grensekontroller (se `position`), beregner vi lengden på en noe uventet måte.
// (Testet av `codegen/slice-position-bounds-check '.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // vi blir noen ganger brukt i en usikker blokk

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Denne _cannot_ bruker `unchecked_sub` fordi vi er avhengige av innpakning for å representere lengden på lange ZST-snitt-iteratorer.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Vi vet at `start <= end`, så kan gjøre det bedre enn `offset_from`, som trenger å håndtere signert.
            // Ved å sette passende flagg her kan vi fortelle LLVM dette, noe som hjelper det med å fjerne grensekontroll.
            // SIKKERHET: Av typen invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ved å også fortelle LLVM at pekerne er fra hverandre med et nøyaktig multiplum av typestørrelsen, kan det optimalisere `len() == 0` ned til `start == end` i stedet for `(end - start) < size`.
            //
            // SIKKERHET: Etter typen invariant, er pekerne justert slik at
            //         avstanden mellom dem må være et multiplum av poengstørrelsen
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Den delte definisjonen av itoratorene `Iter` og `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Returnerer det første elementet og flytter starten på iteratoren fremover med 1.
        // Forbedrer ytelsen sterkt sammenlignet med en innebygd funksjon.
        // Iteratoren må ikke være tom.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Returnerer det siste elementet og beveger enden av iteratoren bakover med 1.
        // Forbedrer ytelsen sterkt sammenlignet med en innebygd funksjon.
        // Iteratoren må ikke være tom.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Krymper iteratoren når T er en ZST, ved å flytte enden av iteratoren bakover med `n`.
        // `n` må ikke overstige `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Hjelpefunksjon for å lage et stykke fra iteratoren.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SIKKERHET: iteratoren ble opprettet fra et stykke med pekeren
                // `self.ptr` og lengde `len!(self)`.
                // Dette garanterer at alle forutsetningene for `from_raw_parts` er oppfylt.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Hjelpefunksjon for å flytte starten av iteratoren fremover av `offset`-elementer, og returnere den gamle starten.
            //
            // Usikre fordi forskyvningen ikke må overstige `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SIKKERHET: innringeren garanterer at `offset` ikke overstiger `self.len()`,
                    // så denne nye pekeren er inne i `self` og er garantert ikke null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Hjelpefunksjon for å flytte enden av iteratoren bakover av `offset`-elementer, og returnere den nye enden.
            //
            // Usikre fordi forskyvningen ikke må overstige `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SIKKERHET: innringeren garanterer at `offset` ikke overstiger `self.len()`,
                    // som garantert ikke overløper en `isize`.
                    // Den resulterende pekeren er også innenfor grensene til `slice`, som oppfyller de andre kravene til `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // kunne implementeres med skiver, men dette unngår grensekontroller

                // SIKKERHET: `assume`-samtaler er trygge siden startpekeren til et stykke
                // må være ikke-null, og skiver over ikke-ZST-er må også ha en ikke-null sluttpeker.
                // Samtalet til `next_unchecked!` er trygt siden vi sjekker om iteratoren først er tom.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Denne iteratoren er nå tom.
                    if mem::size_of::<T>() == 0 {
                        // Vi må gjøre det på denne måten, da `ptr` kanskje aldri er 0, men `end` kan være det (på grunn av innpakning).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SIKKERHET: slutten kan ikke være 0 hvis T ikke er ZST fordi ptr ikke er 0 og slutt>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SIKKERHET: Vi er i grensene.`post_inc_start` gjør det riktige selv for ZST-er.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Vi overstyrer standardimplementeringen, som bruker `try_fold`, fordi denne enkle implementeringen genererer mindre LLVM IR og er raskere å kompilere.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Vi overstyrer standardimplementeringen, som bruker `try_fold`, fordi denne enkle implementeringen genererer mindre LLVM IR og er raskere å kompilere.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Vi overstyrer standardimplementeringen, som bruker `try_fold`, fordi denne enkle implementeringen genererer mindre LLVM IR og er raskere å kompilere.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Vi overstyrer standardimplementeringen, som bruker `try_fold`, fordi denne enkle implementeringen genererer mindre LLVM IR og er raskere å kompilere.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Vi overstyrer standardimplementeringen, som bruker `try_fold`, fordi denne enkle implementeringen genererer mindre LLVM IR og er raskere å kompilere.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Vi overstyrer standardimplementeringen, som bruker `try_fold`, fordi denne enkle implementeringen genererer mindre LLVM IR og er raskere å kompilere.
            // `assume` unngår også en grensekontroll.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SIKKERHET: Vi er garantert i grensene av løkke-invarianten:
                        // når `i >= n`, returnerer `self.next()` `None` og sløyfen går i stykker.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Vi overstyrer standardimplementeringen, som bruker `try_fold`, fordi denne enkle implementeringen genererer mindre LLVM IR og er raskere å kompilere.
            // `assume` unngår også en grensekontroll.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SIKKERHET: `i` må være lavere enn `n` siden den starter på `n`
                        // og avtar bare.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SIKKERHET: innringeren må garantere at `i` er innenfor grensene for
                // den underliggende delen, slik at `i` ikke kan overløpe en `isize`, og de returnerte referansene refererer garantert til et element i segmentet og er dermed garantert gyldige.
                //
                // Vær også oppmerksom på at den som ringer også garanterer at vi aldri blir ringt med den samme indeksen igjen, og at ingen andre metoder som får tilgang til denne delseksjonen, blir kalt, så det er gyldig at den returnerte referansen kan bli mutert i tilfelle
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // kunne implementeres med skiver, men dette unngår grensekontroller

                // SIKKERHET: `assume`-samtaler er trygge siden startpekeren til et stykke må være ikke-null,
                // og skiver over ikke-ZST-er må også ha en ikke-null sluttpeker.
                // Samtalet til `next_back_unchecked!` er trygt siden vi sjekker om iteratoren først er tom.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Denne iteratoren er nå tom.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SIKKERHET: Vi er i grensene.`pre_dec_end` gjør det riktige selv for ZST-er.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}