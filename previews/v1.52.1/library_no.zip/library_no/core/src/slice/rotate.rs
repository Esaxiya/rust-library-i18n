// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Roterer området `[mid-left, mid+right)` slik at elementet ved `mid` blir det første elementet.Tilsvarende roterer området `left`-elementene til venstre eller `right`-elementene til høyre.
///
/// # Safety
///
/// Det angitte området må være gyldig for lesing og skriving.
///
/// # Algorithm
///
/// Algoritme 1 brukes til små verdier av `left + right` eller for store `T`.
/// Elementene blir flyttet inn i sine endelige posisjoner en om gangen, og starter ved `mid - left` og går videre med `right` trinn modulo `left + right`, slik at bare en midlertidig er nødvendig.
/// Til slutt kommer vi tilbake til `mid - left`.
/// Imidlertid, hvis `gcd(left + right, right)` ikke er 1, hoppet trinnene ovenfor over elementene.
/// For eksempel:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Heldigvis er antallet hoppede over elementer mellom de endelige elementene alltid likt, så vi kan bare kompensere for startposisjonen vår og gjøre flere runder (totalt antall runder er `gcd(left + right, right)` value).
///
/// Sluttresultatet er at alle elementene er ferdig en gang og bare en gang.
///
/// Algoritme 2 brukes hvis `left + right` er stor, men `min(left, right)` er liten nok til å passe på en stabelbuffer.
/// `min(left, right)`-elementene kopieres på bufferen, `memmove` påføres de andre, og de på bufferen flyttes tilbake i hullet på motsatt side av der de oppsto.
///
/// Algoritmer som kan vektoriseres, overgår ovennevnte når `left + right` blir stor nok.
/// Algoritme 1 kan vektoriseres ved å klumpe ut og utføre mange runder på en gang, men det er for få runder i gjennomsnitt til `left + right` er enorm, og det verste tilfellet med en enkelt runde er alltid der.
/// I stedet bruker algoritme 3 gjentatt bytte av `min(left, right)`-elementer til et mindre rotasjonsproblem er igjen.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// når `left < right` skjer byttingen fra venstre i stedet.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algoritmene nedenfor kan mislykkes hvis disse sakene ikke blir sjekket
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritme 1 Microbenchmarks indikerer at den gjennomsnittlige ytelsen for tilfeldige skift er bedre helt til omtrent `left + right == 32`, men i verste fall går ytelsen til og med rundt 16.
            // 24 ble valgt som midtvei.
            // Hvis størrelsen på `T` er større enn 4 usize, overgår denne algoritmen også andre algoritmer.
            //
            //
            let x = unsafe { mid.sub(left) };
            // begynnelsen av første runde
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` kan bli funnet før hånd ved å beregne `gcd(left + right, right)`, men det er raskere å gjøre en sløyfe som beregner gcd som en bivirkning, og deretter gjør resten av klumpen
            //
            //
            let mut gcd = right;
            // referanser viser at det er raskere å bytte midlertidig hele veien gjennom i stedet for å lese en midlertidig en gang, kopiere bakover, og deretter skrive den midlertidige helt på slutten.
            // Dette skyldes muligens det faktum at bytte eller erstatte midlertidige bare bruker en minneadresse i sløyfen i stedet for å trenge å administrere to.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // i stedet for å øke `i` og deretter sjekke om det er utenfor grensene, sjekker vi om `i` vil gå utenfor grensene ved neste trinn.
                // Dette forhindrer innpakning av pekere eller `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // slutten av første runde
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // denne betingede må være her hvis `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // avslutt klumpen med flere runder
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` er ikke en nullstørrelse, så det er greit å dele på størrelsen.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritme 2 `[T; 0]` her er for å sikre at dette er riktig justert for T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritme 3 Det er en alternativ måte å bytte som innebærer å finne ut hvor den siste utvekslingen av denne algoritmen ville være, og bytte ved hjelp av den siste delen i stedet for å bytte tilstøtende biter som denne algoritmen gjør, men denne måten er fortsatt raskere.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritme 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}