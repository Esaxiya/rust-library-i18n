// ignore-tidy-filelength

//! Slice management og manipulasjon.
//!
//! For mer informasjon, se [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Ren implementering av rust memchr, hentet fra rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Denne funksjonen er kun offentlig fordi det ikke er noen annen måte å teste høysort på.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Returnerer antall elementer i delen.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SIKKERHET: const-lyd fordi vi transmitterer lengdefeltet som en størrelse (som det må være)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIKKERHET: dette er trygt fordi `&[T]` og `FatPtr<T>` har samme oppsett.
            // Bare `std` kan gi denne garantien.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Bytt ut med `crate::ptr::metadata(self)` når det er konststabilt.
            // I skrivende stund forårsaker dette en "Const-stable functions can only call other const-stable functions"-feil.
            //

            // SIKKERHET: Å få tilgang til verdien fra `PtrRepr`-foreningen er trygt siden * konst T
            // og PtrComponents<T>har samme minneoppsett.
            // Bare std kan stille denne garantien.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Returnerer `true` hvis delen har en lengde på 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Returnerer det første elementet i stykket, eller `None` hvis det er tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Returnerer en foranderlig peker til det første elementet i stykket, eller `None` hvis den er tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Returnerer den første og alle resten av elementene i stykket, eller `None` hvis den er tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Returnerer den første og alle resten av elementene i stykket, eller `None` hvis den er tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Returnerer den siste og resten av elementene i stykket, eller `None` hvis den er tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Returnerer den siste og resten av elementene i stykket, eller `None` hvis den er tom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Returnerer det siste elementet i stykket, eller `None` hvis det er tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Returnerer en muterbar peker til det siste elementet i stykket.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Returnerer en referanse til et element eller underdel, avhengig av type indeks.
    ///
    /// - Hvis du får en posisjon, returnerer du en referanse til elementet i den posisjonen eller `None` hvis den er utenfor grensene.
    ///
    /// - Hvis det gis et område, returnerer underdelen som tilsvarer det området, eller `None` hvis den er utenfor grensene.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Returnerer en foranderlig referanse til et element eller underdel avhengig av type indeks (se [`get`]) eller `None` hvis indeksen er utenfor grensene.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Returnerer en referanse til et element eller underdel, uten å gjøre grensekontroll.
    ///
    /// For et trygt alternativ, se [`get`].
    ///
    /// # Safety
    ///
    /// Å kalle denne metoden med en indeks utenfor grensene er *[udefinert oppførsel]* selv om den resulterende referansen ikke brukes.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SIKKERHET: innringeren må opprettholde de fleste av sikkerhetskravene til `get_unchecked`;
        // segmentet kan avleses fordi `self` er en trygg referanse.
        // Den returnerte pekeren er trygg fordi implantater fra `SliceIndex` må garantere at den er det.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Returnerer en foranderlig referanse til et element eller underdel, uten å gjøre grensekontroll.
    ///
    /// For et trygt alternativ, se [`get_mut`].
    ///
    /// # Safety
    ///
    /// Å kalle denne metoden med en indeks utenfor grensene er *[udefinert oppførsel]* selv om den resulterende referansen ikke brukes.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskravene til `get_unchecked_mut`;
        // segmentet kan avleses fordi `self` er en trygg referanse.
        // Den returnerte pekeren er trygg fordi implantater fra `SliceIndex` må garantere at den er det.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Returnerer en rå peker til stykkets buffer.
    ///
    /// Innringeren må sørge for at stykket overlever pekeren som denne funksjonen returnerer, ellers vil den ende opp med søppel.
    ///
    /// Innringeren må også sørge for at minnet pekeren (non-transitively) peker på aldri blir skrevet til (unntatt inne i en `UnsafeCell`) ved hjelp av denne pekeren eller en hvilken som helst peker som er hentet fra den.
    /// Hvis du trenger å mutere innholdet i stykket, bruk [`as_mut_ptr`].
    ///
    /// Hvis du endrer beholderen som dette stykket refererer til, kan bufferen omdisponeres, noe som også vil gjøre eventuelle pekere til den ugyldige.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Returnerer en usikker, muterbar peker til stykkets buffer.
    ///
    /// Innringeren må sørge for at stykket overlever pekeren som denne funksjonen returnerer, ellers vil den ende opp med søppel.
    ///
    /// Hvis du endrer beholderen som dette stykket refererer til, kan bufferen omdisponeres, noe som også vil gjøre eventuelle pekere til den ugyldige.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Returnerer de to rå pekerne som spenner over stykket.
    ///
    /// Det returnerte området er halvåpent, noe som betyr at sluttpekeren peker *ett forbi* det siste elementet i stykket.
    /// På denne måten representeres et tomt stykke av to like pekere, og forskjellen mellom de to pekerne representerer størrelsen på skiven.
    ///
    /// Se [`as_ptr`] for advarsler om bruk av disse pekerne.Endepekeren krever ekstra forsiktighet, da den ikke peker på et gyldig element i stykket.
    ///
    /// Denne funksjonen er nyttig for å samhandle med utenlandske grensesnitt som bruker to pekere for å referere til en rekke elementer i minnet, slik det er vanlig i C++ .
    ///
    ///
    /// Det kan også være nyttig å sjekke om en peker til et element refererer til et element i denne delen:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SIKKERHET: `add` her er trygg, fordi:
        //
        //   - Begge pekerne er en del av det samme objektet, ettersom det også teller å peke direkte forbi objektet.
        //
        //   - Størrelsen på stykket er aldri større enn isize::MAX byte, som nevnt her:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Det er ingen innpakning involvert, da skiver ikke vikles forbi enden av adresseplassen.
        //
        // Se dokumentasjonen til pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Returnerer de to usikre, muterbare pekerne som spenner over stykket.
    ///
    /// Det returnerte området er halvåpent, noe som betyr at sluttpekeren peker *ett forbi* det siste elementet i stykket.
    /// På denne måten representeres et tomt stykke av to like pekere, og forskjellen mellom de to pekerne representerer størrelsen på skiven.
    ///
    /// Se [`as_mut_ptr`] for advarsler om bruk av disse pekerne.
    /// Sluttpekeren krever ekstra forsiktighet, da den ikke peker på et gyldig element i stykket.
    ///
    /// Denne funksjonen er nyttig for å samhandle med utenlandske grensesnitt som bruker to pekere for å referere til en rekke elementer i minnet, slik det er vanlig i C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SIKKERHET: Se as_ptr_range() ovenfor for hvorfor `add` her er trygt.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Bytter to elementer i stykket.
    ///
    /// # Arguments
    ///
    /// * a, Indeksen for det første elementet
    /// * b, indeksen til det andre elementet
    ///
    /// # Panics
    ///
    /// Panics hvis `a` eller `b` er utenfor grensene.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Kan ikke ta to mutable lån fra en vector, så bruk i stedet rå pekere.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SIKKERHET: `pa` og `pb` er opprettet fra sikre, mutable referanser og refererer
        // til elementene i stykket og er derfor garantert å være gyldige og justert.
        // Merk at tilgang til elementene bak `a` og `b` er merket av og vil panic når det er utenfor grensene.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Vender rekkefølgen på elementene i stykket, på plass.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // For veldig små typer fungerer alle individene i normal vei dårlig.
        // Vi kan gjøre det bedre, gitt effektiv ujustert load/store, ved å laste inn en større del og reversere et register.
        //

        // Ideelt sett ville LLVM gjøre dette for oss, ettersom det vet bedre enn vi gjør om ujusterte avlesninger er effektive (siden for eksempel endringer mellom forskjellige ARM-versjoner) og hva den beste klumpstørrelsen ville være.
        // Dessverre, fra og med LLVM 4.0 (2017-05), ruller den bare løkken, så vi må gjøre dette selv.
        // (Hypotese: omvendt er plagsomt fordi sidene kan justeres annerledes-vil være når lengden er merkelig-så det er ingen måte å sende ut pre-og postludes for å bruke fulljustert SIMD i midten.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Bruk llvm.bswap iboende for å reversere u8s i en størrelse
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SIKKERHET: Det er flere ting å sjekke her:
                //
                // - Merk at `chunk` enten er 4 eller 8 på grunn av cfg-sjekken ovenfor.Så `chunk - 1` er positiv.
                // - Indeksering med indeks `i` er greit som løkkekontrollen garanterer
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indeksering med indeks `ln - i - chunk = ln - (i + chunk)` er greit:
                //   - `i + chunk > 0` er trivielt sant.
                //   - Sløyfekontrollen garanterer:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, og subtraksjon strømmer dermed ikke.
                // - `read_unaligned`-og `write_unaligned`-samtalene er fine:
                //   - `pa` peker på indeks `i` hvor `i < ln / 2 - (chunk - 1)` (se ovenfor) og `pb` peker på indeks `ln - i - chunk`, så begge er minst `chunk` mange byte unna slutten av `self`.
                //
                //   - Ethvert initialisert minne er gyldig `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Bruk rotate-by-16 for å reversere u16s i en u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SIKKERHET: En ujustert u32 kan leses fra `i` hvis `i + 1 < ln`
                // (og åpenbart `i < ln`), fordi hvert element er 2 byte og vi leser 4.
                //
                // `i + chunk - 1 < ln / 2` # mens tilstand
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Siden det er mindre enn lengden delt på 2, må den være i grensene.
                //
                // Dette betyr også at tilstanden `0 < i + chunk <= ln` alltid respekteres, slik at `pb`-pekeren kan brukes trygt.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SIKKERHET: `i` er dårligere enn halvparten av stykket
            // tilgang til `i` og `ln - i - 1` er trygt (`i` starter ved 0 og kommer ikke lenger enn `ln / 2 - 1`).
            // De resulterende pekerne `pa` og `pb` er derfor gyldige og justert, og kan leses fra og skrives til.
            //
            //
            unsafe {
                // Usikker bytte for å unngå grensesjekk i sikker bytte.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Returnerer en iterator over stykket.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Returnerer en iterator som tillater endring av hver verdi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Returnerer en iterator over alle sammenhengende windows av lengde `size`.
    /// windows overlapper hverandre.
    /// Hvis stykket er kortere enn `size`, returnerer iteratoren ingen verdier.
    ///
    /// # Panics
    ///
    /// Panics hvis `size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Hvis stykket er kortere enn `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer av skiven om gangen, og begynner på begynnelsen av skiven.
    ///
    /// Biter er skiver og overlapper ikke hverandre.Hvis `chunk_size` ikke deler lengden på stykket, vil den siste delen ikke ha lengden `chunk_size`.
    ///
    /// Se [`chunks_exact`] for en variant av denne iteratoren som returnerer biter av alltid nøyaktig `chunk_size`-elementer, og [`rchunks`] for samme iterator, men starter på slutten av stykket.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer av skiven om gangen, og begynner på begynnelsen av skiven.
    ///
    /// Biter er mutable skiver, og overlapper ikke hverandre.Hvis `chunk_size` ikke deler lengden på stykket, vil den siste delen ikke ha lengden `chunk_size`.
    ///
    /// Se [`chunks_exact_mut`] for en variant av denne iteratoren som returnerer biter av alltid nøyaktig `chunk_size`-elementer, og [`rchunks_mut`] for samme iterator, men starter på slutten av stykket.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer av skiven om gangen, og begynner på begynnelsen av skiven.
    ///
    /// Biter er skiver og overlapper ikke hverandre.
    /// Hvis `chunk_size` ikke deler lengden på snittet, vil de siste opptil `chunk_size-1`-elementene bli utelatt og kan hentes fra iteratorens `remainder`-funksjon.
    ///
    ///
    /// På grunn av at hver del har nøyaktig `chunk_size`-elementer, kan kompilatoren ofte optimalisere den resulterende koden bedre enn i tilfelle [`chunks`].
    ///
    /// Se [`chunks`] for en variant av denne iteratoren som også returnerer resten som en mindre del, og [`rchunks_exact`] for den samme iteratoren, men starter på slutten av stykket.
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer av skiven om gangen, og begynner på begynnelsen av skiven.
    ///
    /// Biter er mutable skiver, og overlapper ikke hverandre.
    /// Hvis `chunk_size` ikke deler lengden på snittet, vil de siste opptil `chunk_size-1`-elementene bli utelatt og kan hentes fra iteratorens `into_remainder`-funksjon.
    ///
    ///
    /// På grunn av at hver del har nøyaktig `chunk_size`-elementer, kan kompilatoren ofte optimalisere den resulterende koden bedre enn i tilfelle [`chunks_mut`].
    ///
    /// Se [`chunks_mut`] for en variant av denne iteratoren som også returnerer resten som en mindre del, og [`rchunks_exact_mut`] for den samme iteratoren, men starter på slutten av stykket.
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Deler skiven i et stykke `N`-element matriser, forutsatt at det ikke er noen rest.
    ///
    ///
    /// # Safety
    ///
    /// Dette kan bare kalles når
    /// - Skiven deler seg nøyaktig i `N`-elementbiter (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SIKKERHET: 1-element biter har aldri resten
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SIKKERHET: Skivelengden (6) er et multiplum av 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Disse ville være usunde:
    /// // la biter: &[[_;5]]= slice.as_chunks_unchecked()//Skivelengden er ikke et multiplum av 5 la biter:&[[_;0]]= slice.as_chunks_unchecked()//Nulllengde biter er aldri tillatt
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SIKKERHET: Forutsetningen vår er akkurat det som trengs for å kalle dette
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SIKKERHET: Vi kaster et stykke `new_len * N`-elementer i
        // et stykke `new_len` mange `N`-elementbiter.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Deler skiven i et stykke `N`-element-matriser, som begynner på begynnelsen av skiven, og en restskive med lengde som er strengt mindre enn `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne sjekken vil sannsynligvis bli endret til en kompilasjonsfel før denne metoden blir stabilisert.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SIKKERHET: Vi hadde allerede panikk for null, og sørget for bygging
        // at underdelens lengde er et multiplum av N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Deler skiven i et stykke `N`-element-matriser, som begynner på slutten av skiven, og en gjenværende skive med lengde som er strengt mindre enn `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne sjekken vil sannsynligvis bli endret til en kompilasjonsfel før denne metoden blir stabilisert.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SIKKERHET: Vi hadde allerede panikk for null, og sørget for bygging
        // at underdelens lengde er et multiplum av N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Returnerer en iterator over `N`-elementer av skiven om gangen, og begynner på begynnelsen av skiven.
    ///
    /// Biter er matrisehenvisninger og overlapper ikke hverandre.
    /// Hvis `N` ikke deler lengden på snittet, vil de siste opptil `N-1`-elementene bli utelatt og kan hentes fra iteratorens `remainder`-funksjon.
    ///
    ///
    /// Denne metoden er den generiske ekvivalenten til [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne sjekken vil sannsynligvis bli endret til en kompilasjonsfel før denne metoden blir stabilisert.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Deler skiven i et stykke `N`-element matriser, forutsatt at det ikke er noen rest.
    ///
    ///
    /// # Safety
    ///
    /// Dette kan bare kalles når
    /// - Skiven deler seg nøyaktig i `N`-elementbiter (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SIKKERHET: 1-element biter har aldri resten
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SIKKERHET: Skivelengden (6) er et multiplum av 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Disse ville være usunde:
    /// // la biter: &[[_;5]]= slice.as_chunks_unchecked_mut()//Skivelengden er ikke et multiplum av 5 la biter:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nulllengde biter er aldri tillatt
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SIKKERHET: Forutsetningen vår er akkurat det som trengs for å kalle dette
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SIKKERHET: Vi kaster et stykke `new_len * N`-elementer i
        // et stykke `new_len` mange `N`-elementbiter.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Deler skiven i et stykke `N`-element-matriser, som begynner på begynnelsen av skiven, og en restskive med lengde som er strengt mindre enn `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne sjekken vil sannsynligvis bli endret til en kompilasjonsfel før denne metoden blir stabilisert.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SIKKERHET: Vi hadde allerede panikk for null, og sørget for bygging
        // at underdelens lengde er et multiplum av N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Deler skiven i et stykke `N`-element-matriser, som begynner på slutten av skiven, og en gjenværende skive med lengde som er strengt mindre enn `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne sjekken vil sannsynligvis bli endret til en kompilasjonsfel før denne metoden blir stabilisert.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SIKKERHET: Vi hadde allerede panikk for null, og sørget for bygging
        // at underdelens lengde er et multiplum av N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Returnerer en iterator over `N`-elementer av skiven om gangen, og begynner på begynnelsen av skiven.
    ///
    /// Biter er mutable matrisehenvisninger og overlapper ikke hverandre.
    /// Hvis `N` ikke deler lengden på snittet, vil de siste opptil `N-1`-elementene bli utelatt og kan hentes fra iteratorens `into_remainder`-funksjon.
    ///
    ///
    /// Denne metoden er den generiske ekvivalenten til [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne sjekken vil sannsynligvis bli endret til en kompilasjonsfel før denne metoden blir stabilisert.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Returnerer en iterator som overlapper windows av `N`-elementer i et stykke, og begynner ved begynnelsen av segmentet.
    ///
    ///
    /// Dette er den generiske ekvivalenten til [`windows`].
    ///
    /// Hvis `N` er større enn størrelsen på stykket, returnerer den ingen windows.
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0.
    /// Denne sjekken vil sannsynligvis bli endret til en kompileringsfeil før denne metoden blir stabilisert.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Returnerer en iterator over `chunk_size`-elementer av skiven om gangen, og begynner på slutten av skiven.
    ///
    /// Biter er skiver og overlapper ikke hverandre.Hvis `chunk_size` ikke deler lengden på stykket, vil den siste delen ikke ha lengden `chunk_size`.
    ///
    /// Se [`rchunks_exact`] for en variant av denne iteratoren som returnerer biter av alltid nøyaktig `chunk_size`-elementer, og [`chunks`] for samme iterator, men som begynner på begynnelsen av stykket.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer av skiven om gangen, og begynner på slutten av skiven.
    ///
    /// Biter er mutable skiver, og overlapper ikke hverandre.Hvis `chunk_size` ikke deler lengden på stykket, vil den siste delen ikke ha lengden `chunk_size`.
    ///
    /// Se [`rchunks_exact_mut`] for en variant av denne iteratoren som returnerer biter av alltid nøyaktig `chunk_size`-elementer, og [`chunks_mut`] for samme iterator, men som begynner på begynnelsen av stykket.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer av skiven om gangen, og begynner på slutten av skiven.
    ///
    /// Biter er skiver og overlapper ikke hverandre.
    /// Hvis `chunk_size` ikke deler lengden på snittet, vil de siste opptil `chunk_size-1`-elementene bli utelatt og kan hentes fra iteratorens `remainder`-funksjon.
    ///
    /// På grunn av at hver del har nøyaktig `chunk_size`-elementer, kan kompilatoren ofte optimalisere den resulterende koden bedre enn i tilfelle [`chunks`].
    ///
    /// Se [`rchunks`] for en variant av denne iteratoren som også returnerer resten som en mindre del, og [`chunks_exact`] for den samme iteratoren, men starter i begynnelsen av stykket.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer av skiven om gangen, og begynner på slutten av skiven.
    ///
    /// Biter er mutable skiver, og overlapper ikke hverandre.
    /// Hvis `chunk_size` ikke deler lengden på snittet, vil de siste opptil `chunk_size-1`-elementene bli utelatt og kan hentes fra iteratorens `into_remainder`-funksjon.
    ///
    /// På grunn av at hver del har nøyaktig `chunk_size`-elementer, kan kompilatoren ofte optimalisere den resulterende koden bedre enn i tilfelle [`chunks_mut`].
    ///
    /// Se [`rchunks_mut`] for en variant av denne iteratoren som også returnerer resten som en mindre del, og [`chunks_exact_mut`] for den samme iteratoren, men starter i begynnelsen av stykket.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Returnerer en iterator over skiven som produserer ikke-overlappende kjør av elementer ved hjelp av predikatet for å skille dem.
    ///
    /// Predikatet kalles på to elementer som følger seg selv, det betyr at predikatet kalles på `slice[0]` og `slice[1]`, deretter på `slice[1]` og `slice[2]` og så videre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Denne metoden kan brukes til å trekke ut de sorterte underrubrikene:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Returnerer en iterator over skiven og produserer ikke-overlappende, mutable kjøringer av elementer ved hjelp av predikatet for å skille dem.
    ///
    /// Predikatet kalles på to elementer som følger seg selv, det betyr at predikatet kalles på `slice[0]` og `slice[1]`, deretter på `slice[1]` og `slice[2]` og så videre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Denne metoden kan brukes til å trekke ut de sorterte underrubrikene:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Deler en skive i to ved en indeks.
    ///
    /// Den første vil inneholde alle indekser fra `[0, mid)` (unntatt indeksen `mid` i seg selv) og den andre vil inneholde alle indekser fra `[mid, len)` (unntatt indeksen `len` selv).
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SIKKERHET: `[ptr; mid]` og `[mid; len]` er inne i `self`, som
        // oppfyller kravene til `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Deler en muterbar skive i to ved en indeks.
    ///
    /// Den første vil inneholde alle indekser fra `[0, mid)` (unntatt indeksen `mid` i seg selv) og den andre vil inneholde alle indekser fra `[mid, len)` (unntatt indeksen `len` selv).
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SIKKERHET: `[ptr; mid]` og `[mid; len]` er inne i `self`, som
        // oppfyller kravene til `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Deler en skive i to ved en indeks, uten å gjøre grensekontroll.
    ///
    /// Den første vil inneholde alle indekser fra `[0, mid)` (unntatt indeksen `mid` i seg selv) og den andre vil inneholde alle indekser fra `[mid, len)` (unntatt indeksen `len` selv).
    ///
    ///
    /// For et trygt alternativ, se [`split_at`].
    ///
    /// # Safety
    ///
    /// Å kalle denne metoden med en indeks utenfor grensene er *[udefinert oppførsel]* selv om den resulterende referansen ikke brukes.Innringeren må sørge for at `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SIKKERHET: Oppringeren må sjekke at `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Deler en muterbar skive i to ved en indeks, uten å gjøre grensekontroll.
    ///
    /// Den første vil inneholde alle indekser fra `[0, mid)` (unntatt indeksen `mid` i seg selv) og den andre vil inneholde alle indekser fra `[mid, len)` (unntatt indeksen `len` selv).
    ///
    ///
    /// For et trygt alternativ, se [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Å kalle denne metoden med en indeks utenfor grensene er *[udefinert oppførsel]* selv om den resulterende referansen ikke brukes.Innringeren må sørge for at `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SIKKERHET: Oppringeren må sjekke at `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` og `[mid; len]` overlapper ikke, så det er greit å returnere en foranderlig referanse.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Returnerer en iterator over underdeler atskilt med elementer som samsvarer med `pred`.
    /// Det samsvarende elementet er ikke inkludert i underlisene.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Hvis det første elementet matches, vil en tom del være det første elementet som returneres av iteratoren.
    /// På samme måte, hvis det siste elementet i stykket matches, vil en tom del være det siste elementet som returneres av iteratoren:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Hvis to samsvarende elementer ligger rett ved siden av, vil det være et tomt stykke mellom dem:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Returnerer en iterator over foranderlige underdeler atskilt med elementer som samsvarer med `pred`.
    /// Det samsvarende elementet er ikke inkludert i underlisene.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Returnerer en iterator over underdeler atskilt med elementer som samsvarer med `pred`.
    /// Det samsvarende elementet er inneholdt på slutten av forrige delsnitt som en terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Hvis det siste elementet i stykket samsvarer, vil dette elementet bli betraktet som terminatoren for forrige stykke.
    ///
    /// Denne delen vil være det siste elementet som returneres av iteratoren.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Returnerer en iterator over foranderlige underdeler atskilt med elementer som samsvarer med `pred`.
    /// Det samsvarende elementet er inneholdt i forrige delsnitt som en terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Returnerer en iterator over underdeler atskilt med elementer som samsvarer med `pred`, og begynner på slutten av stykket og jobber bakover.
    /// Det samsvarende elementet er ikke inkludert i underlisene.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Som med `split()`, hvis det første eller siste elementet samsvarer, vil en tom bit være det første (eller siste) elementet som returneres av iteratoren.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Returnerer en iterator over muterbare underdeler atskilt med elementer som samsvarer med `pred`, og begynner på slutten av stykket og jobber bakover.
    /// Det samsvarende elementet er ikke inkludert i underlisene.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Returnerer en iterator over sublices atskilt av elementer som samsvarer med `pred`, begrenset til å returnere maksimalt `n`-elementer.
    /// Det samsvarende elementet er ikke inkludert i underlisene.
    ///
    /// Det siste elementet som returneres, hvis noe, vil inneholde resten av stykket.
    ///
    /// # Examples
    ///
    /// Skriv ut delingen en gang delt med tall som kan deles med 3 (dvs. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Returnerer en iterator over sublices atskilt av elementer som samsvarer med `pred`, begrenset til å returnere maksimalt `n`-elementer.
    /// Det samsvarende elementet er ikke inkludert i underlisene.
    ///
    /// Det siste elementet som returneres, hvis noe, vil inneholde resten av stykket.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Returnerer en iterator over sublices atskilt av elementer som samsvarer med `pred`, begrenset til å returnere maksimalt `n`-elementer.
    /// Dette starter på slutten av stykket og fungerer bakover.
    /// Det samsvarende elementet er ikke inkludert i underlisene.
    ///
    /// Det siste elementet som returneres, hvis noe, vil inneholde resten av stykket.
    ///
    /// # Examples
    ///
    /// Skriv ut delingen en gang, fra slutten, med tall som kan deles med 3 (dvs. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Returnerer en iterator over sublices atskilt av elementer som samsvarer med `pred`, begrenset til å returnere maksimalt `n`-elementer.
    /// Dette starter på slutten av stykket og fungerer bakover.
    /// Det samsvarende elementet er ikke inkludert i underlisene.
    ///
    /// Det siste elementet som returneres, hvis noe, vil inneholde resten av stykket.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Returnerer `true` hvis delen inneholder et element med den gitte verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Hvis du ikke har en `&T`, men bare en `&U` slik at `T: Borrow<U>` (f.eks
    /// `String: Lån<str>`), kan du bruke `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // stykke `String`
    /// assert!(v.iter().any(|e| e == "hello")); // søk med `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Returnerer `true` hvis `needle` er et prefiks for stykket.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Returnerer alltid `true` hvis `needle` er et tomt stykke:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Returnerer `true` hvis `needle` er et suffiks av stykket.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Returnerer alltid `true` hvis `needle` er et tomt stykke:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Returnerer en underdel med prefikset fjernet.
    ///
    /// Hvis snittet begynner med `prefix`, returnerer delsnittet etter prefikset, pakket inn i `Some`.
    /// Hvis `prefix` er tom, returnerer du bare den originale delen.
    ///
    /// Hvis stykket ikke starter med `prefix`, returnerer `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Denne funksjonen trenger omskriving hvis og når SlicePattern blir mer sofistikert.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Returnerer en underdel med suffikset fjernet.
    ///
    /// Hvis delen slutter med `suffix`, returnerer du underdelen før suffikset, pakket inn i `Some`.
    /// Hvis `suffix` er tom, returnerer du bare den originale delen.
    ///
    /// Hvis delen ikke slutter med `suffix`, returnerer `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Denne funksjonen trenger omskriving hvis og når SlicePattern blir mer sofistikert.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary søker i dette sorterte stykket etter et gitt element.
    ///
    /// Hvis verdien blir funnet, returneres [`Result::Ok`], som inneholder indeksen for det samsvarende elementet.
    /// Hvis det er flere kamper, kan en av kampene returneres.
    /// Hvis verdien ikke blir funnet, returneres [`Result::Err`], som inneholder indeksen der et samsvarende element kan settes inn mens den sorterte rekkefølgen opprettholdes.
    ///
    ///
    /// Se også [`binary_search_by`], [`binary_search_by_key`] og [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Slår opp en serie med fire elementer.
    /// Den første er funnet, med en unik bestemt posisjon;den andre og den tredje blir ikke funnet;den fjerde kunne matche hvilken som helst posisjon i `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Hvis du vil sette inn et element i en sortert vector, mens du opprettholder sorteringsrekkefølgen:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binær søker i dette sorterte stykket med en komparatorfunksjon.
    ///
    /// Komparatorfunksjonen skal implementere en ordre som samsvarer med sorteringsrekkefølgen til den underliggende delen, og returnere en ordrekode som indikerer om argumentet er `Less`, `Equal` eller `Greater` det ønskede målet.
    ///
    ///
    /// Hvis verdien blir funnet, returneres [`Result::Ok`], som inneholder indeksen for det samsvarende elementet.Hvis det er flere kamper, kan en av kampene returneres.
    /// Hvis verdien ikke blir funnet, returneres [`Result::Err`], som inneholder indeksen der et samsvarende element kan settes inn mens den sorterte rekkefølgen opprettholdes.
    ///
    /// Se også [`binary_search`], [`binary_search_by_key`] og [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Slår opp en serie med fire elementer.Den første er funnet, med en unik bestemt posisjon;den andre og den tredje blir ikke funnet;den fjerde kunne matche hvilken som helst posisjon i `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SIKKERHET: samtalen gjøres trygg av følgende invarianter:
            // - `mid >= 0`
            // - `mid < size`: `mid` er begrenset av `[left; right)` bundet.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Årsaken til at vi bruker if/else-kontrollflyt i stedet for å matche, er fordi kamp omorganiserer sammenligningsoperasjoner, som er perfekt følsom.
            //
            // Dette er x86 asm for u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary søker i dette sorterte stykket med en nøkkelutvinningsfunksjon.
    ///
    /// Forutsetter at delen er sortert etter nøkkelen, for eksempel med [`sort_by_key`] ved hjelp av den samme nøkkelutvinningsfunksjonen.
    ///
    /// Hvis verdien blir funnet, returneres [`Result::Ok`], som inneholder indeksen for det samsvarende elementet.
    /// Hvis det er flere kamper, kan en av kampene returneres.
    /// Hvis verdien ikke blir funnet, returneres [`Result::Err`], som inneholder indeksen der et samsvarende element kan settes inn mens den sorterte rekkefølgen opprettholdes.
    ///
    ///
    /// Se også [`binary_search`], [`binary_search_by`] og [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Slår opp en serie med fire elementer i et par par sortert etter de andre elementene.
    /// Den første er funnet, med en unik bestemt posisjon;den andre og den tredje blir ikke funnet;den fjerde kunne matche hvilken som helst posisjon i `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links er tillatt da `slice::sort_by_key` er i crate `alloc`, og som sådan ikke eksisterer ennå når du bygger `core`.
    //
    // lenker til nedstrøms crate: #74481.Siden primitiver bare er dokumentert i libstd (#73423), fører dette aldri til ødelagte lenker i praksis.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sorterer stykket, men beholder kanskje ikke rekkefølgen på like elementer.
    ///
    /// Denne typen er ustabil (dvs. kan endre rekkefølge på like elementer), på plass (dvs. tildeler ikke) og *O*(*n*\*log(* n*)) i verste fall.
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er basert på [pattern-defeating quicksort][pdqsort] av Orson Peters, som kombinerer det raske gjennomsnittlige tilfellet av randomisert kviksort med det raskeste verste tilfellet av heapsort, mens man oppnår lineær tid på skiver med visse mønstre.
    /// Den bruker litt randomisering for å unngå degenererte tilfeller, men med en fast seed for alltid å gi deterministisk oppførsel.
    ///
    /// Det er vanligvis raskere enn stabil sortering, bortsett fra i noen spesielle tilfeller, for eksempel når skiven består av flere sammenkoblede sorterte sekvenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sorterer skiven med en komparatorfunksjon, men beholder kanskje ikke rekkefølgen på like elementer.
    ///
    /// Denne typen er ustabil (dvs. kan endre rekkefølge på like elementer), på plass (dvs. tildeler ikke) og *O*(*n*\*log(* n*)) i verste fall.
    ///
    /// Komparatorfunksjonen må definere en total rekkefølge for elementene i stykket.Hvis bestillingen ikke er total, er rekkefølgen på elementene uspesifisert.En ordre er en total ordre hvis den er (for alle `a`, `b` og `c`):
    ///
    /// * total og antisymmetrisk: nøyaktig en av `a < b`, `a == b` eller `a > b` er sant, og
    /// * transitive, `a < b` og `b < c` innebærer `a < c`.Det samme må gjelde for både `==` og `>`.
    ///
    /// For eksempel, mens [`f64`] ikke implementerer [`Ord`] fordi `NaN != NaN`, kan vi bruke `partial_cmp` som vår sorteringsfunksjon når vi vet at delen ikke inneholder en `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er basert på [pattern-defeating quicksort][pdqsort] av Orson Peters, som kombinerer det raske gjennomsnittlige tilfellet av randomisert kviksort med det raskeste verste tilfellet av heapsort, mens man oppnår lineær tid på skiver med visse mønstre.
    /// Den bruker litt randomisering for å unngå degenererte tilfeller, men med en fast seed for alltid å gi deterministisk oppførsel.
    ///
    /// Det er vanligvis raskere enn stabil sortering, bortsett fra i noen spesielle tilfeller, for eksempel når skiven består av flere sammenkoblede sorterte sekvenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // omvendt sortering
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sorterer skiven med en nøkkelutvinningsfunksjon, men beholder kanskje ikke rekkefølgen på like elementer.
    ///
    /// Denne typen er ustabil (dvs. kan endre rekkefølge på like elementer), på plass (dvs. tildeler ikke) og *O*(m\* * n *\* log(*n*)) i verste fall, der nøkkelfunksjonen er *O*(*m*).
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er basert på [pattern-defeating quicksort][pdqsort] av Orson Peters, som kombinerer det raske gjennomsnittlige tilfellet av randomisert kviksort med det raskeste verste tilfellet av heapsort, mens man oppnår lineær tid på skiver med visse mønstre.
    /// Den bruker litt randomisering for å unngå degenererte tilfeller, men med en fast seed for alltid å gi deterministisk oppførsel.
    ///
    /// På grunn av strategien for viktige anrop, er det sannsynlig at [`sort_unstable_by_key`](#method.sort_unstable_by_key) vil være tregere enn [`sort_by_cached_key`](#method.sort_by_cached_key) i tilfeller der nøkkelfunksjonen er dyr.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Omorganiser skiven slik at elementet på `index` er i sin endelige sorterte posisjon.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Omorganiser skiven med en komparatorfunksjon slik at elementet på `index` er i sin endelige sorterte posisjon.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Omorganiser skiven med en nøkkelutvinningsfunksjon slik at elementet på `index` er i sin endelige sorterte posisjon.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Omorganiser skiven slik at elementet på `index` er i sin endelige sorterte posisjon.
    ///
    /// Denne omorganiseringen har den ekstra egenskapen at en hvilken som helst verdi på posisjon `i < index` vil være mindre enn eller lik en verdi på en posisjon `j > index`.
    /// I tillegg er denne omorganiseringen ustabil (dvs.
    /// et hvilket som helst antall like elementer kan havne på posisjon `index`), på plass (dvs.
    /// fordeler ikke), og *O*(*n*) i verste fall.
    /// Denne funksjonen er også kjent som "kth element" i andre biblioteker.
    /// Den returnerer en triplett av følgende verdier: alle elementene mindre enn den ved den gitte indeksen, verdien ved den gitte indeksen, og alle elementene større enn den ved den gitte indeksen.
    ///
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er basert på hurtigvalgdelen av den samme kvikksortalgoritmen som brukes til [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics når `index >= len()`, noe som betyr at det alltid panics på tomme skiver.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Finn medianen
    /// v.select_nth_unstable(2);
    ///
    /// // Vi er bare garantert at delen vil være en av følgende, basert på måten vi sorterer om den spesifiserte indeksen.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Omorganiser skiven med en komparatorfunksjon slik at elementet på `index` er i sin endelige sorterte posisjon.
    ///
    /// Denne omorganiseringen har den ekstra egenskapen at en hvilken som helst verdi i posisjon `i < index` vil være mindre enn eller lik en verdi på en posisjon `j > index` ved hjelp av komparatorfunksjonen.
    /// I tillegg er denne omorganiseringen ustabil (dvs. et hvilket som helst antall like elementer kan havne på posisjon `index`), på plass (dvs. tildeler ikke) og *O*(*n*) i verste fall.
    /// Denne funksjonen er også kjent som "kth element" i andre biblioteker.
    /// Den returnerer en triplett av følgende verdier: alle elementer mindre enn den ved den gitte indeksen, verdien ved den gitte indeksen, og alle elementene større enn den ved den gitte indeksen, ved hjelp av den medfølgende komparatorfunksjonen.
    ///
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er basert på hurtigvalgdelen av den samme kvikksortalgoritmen som brukes til [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics når `index >= len()`, noe som betyr at det alltid panics på tomme skiver.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Finn medianen som om stykket ble sortert i synkende rekkefølge.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Vi er bare garantert at delen vil være en av følgende, basert på måten vi sorterer om den spesifiserte indeksen.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Omorganiser skiven med en nøkkelutvinningsfunksjon slik at elementet på `index` er i sin endelige sorterte posisjon.
    ///
    /// Denne omorganiseringen har den tilleggsegenskapen at en hvilken som helst verdi på posisjon `i < index` vil være mindre enn eller lik en verdi på en posisjon `j > index` ved bruk av nøkkelutvinningsfunksjonen.
    /// I tillegg er denne omorganiseringen ustabil (dvs. et hvilket som helst antall like elementer kan havne på posisjon `index`), på plass (dvs. tildeler ikke) og *O*(*n*) i verste fall.
    /// Denne funksjonen er også kjent som "kth element" i andre biblioteker.
    /// Den returnerer en triplett av følgende verdier: alle elementer mindre enn den ved den gitte indeksen, verdien ved den gitte indeksen, og alle elementene som er større enn den ved den gitte indeksen, ved å bruke den medfølgende nøkkelutvinningsfunksjonen.
    ///
    ///
    /// # Gjeldende implementering
    ///
    /// Den nåværende algoritmen er basert på hurtigvalgdelen av den samme kvikksortalgoritmen som brukes til [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics når `index >= len()`, noe som betyr at det alltid panics på tomme skiver.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Returner medianen som om matrisen ble sortert etter absolutt verdi.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Vi er bare garantert at delen vil være en av følgende, basert på måten vi sorterer om den spesifiserte indeksen.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Flytter alle påfølgende gjentatte elementer til slutten av stykket i henhold til implementeringen av [`PartialEq`] trait.
    ///
    ///
    /// Returnerer to skiver.Den første inneholder ingen påfølgende gjentatte elementer.
    /// Den andre inneholder alle duplikatene i ingen spesifisert rekkefølge.
    ///
    /// Hvis segmentet er sortert, inneholder den første returnerte delen ingen duplikater.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Flytter alle unntatt de første påfølgende elementene til slutten av stykket som tilfredsstiller en gitt likhetsforhold.
    ///
    /// Returnerer to skiver.Den første inneholder ingen påfølgende gjentatte elementer.
    /// Den andre inneholder alle duplikatene i ingen spesifisert rekkefølge.
    ///
    /// `same_bucket`-funksjonen sendes referanser til to elementer fra stykket og må avgjøre om elementene er like.
    /// Elementene sendes i motsatt rekkefølge fra deres rekkefølge i stykket, så hvis `same_bucket(a, b)` returnerer `true`, flyttes `a` på slutten av stykket.
    ///
    ///
    /// Hvis segmentet er sortert, inneholder den første returnerte delen ingen duplikater.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Selv om vi har en foranderlig referanse til `self`, kan vi ikke gjøre *vilkårlige* endringer.`same_bucket`-samtalene kan være panic, så vi må sørge for at delen til enhver tid er i gyldig tilstand.
        //
        // Måten vi håndterer dette på er å bruke bytter;vi itererer over alle elementene, bytter når vi går slik at til slutt elementene vi ønsker å beholde er foran, og de vi ønsker å avvise er på baksiden.
        // Vi kan da dele skiven.
        // Denne operasjonen er fortsatt `O(n)`.
        //
        // Eksempel: Vi starter i denne tilstanden, der `r` representerer "neste
        // les "og `w` representerer" neste_skriv ".
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Sammenligning av self[r] mot selv [w-1], dette er ikke et duplikat, så vi bytter self[r] og self[w] (ingen effekt som r==w) og øker deretter både r og w, og etterlater oss med:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Sammenligning av self[r] mot selv [w-1], er denne verdien en duplikat, så vi øker `r`, men lar alt annet være uendret:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Sammenligning av self[r] mot selv [w-1], dette er ikke et duplikat, så bytt self[r] og self[w] og avansere r og w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ikke et duplikat, gjenta:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplikat, advance r. End stykke.Del på m.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SIKKERHET: `while`-tilstanden garanterer `next_read` og `next_write`
        // er mindre enn `len`, og er dermed inne i `self`.
        // `prev_ptr_write` peker på ett element før `ptr_write`, men `next_write` starter på 1, så `prev_ptr_write` er aldri mindre enn 0 og er inne i skiven.
        // Dette oppfyller kravene for dereferanse `ptr_read`, `prev_ptr_write` og `ptr_write`, og for bruk av `ptr.add(next_read)`, `ptr.add(next_write - 1)` og `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` økes også maksimalt en gang per sløyfe på det meste, noe som betyr at ingen elementer hoppes over når det kan være behov for å bytte.
        //
        // `ptr_read` og `prev_ptr_write` peker aldri på det samme elementet.Dette kreves for at `&mut *ptr_read`, `&mut* prev_ptr_write` skal være trygge.
        // Forklaringen er ganske enkelt at `next_read >= next_write` alltid er sant, og dermed er `next_read > next_write - 1` også.
        //
        //
        //
        //
        //
        unsafe {
            // Unngå grensekontroll ved å bruke rå pekere.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Flytter alle bortsett fra det første av påfølgende elementer til slutten av stykket som løser til samme nøkkel.
    ///
    ///
    /// Returnerer to skiver.Den første inneholder ingen påfølgende gjentatte elementer.
    /// Den andre inneholder alle duplikatene i ingen spesifisert rekkefølge.
    ///
    /// Hvis segmentet er sortert, inneholder den første returnerte delen ingen duplikater.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Roterer skiven på plass slik at de første `mid`-elementene i skiven beveger seg til enden mens de siste `self.len() - mid`-elementene beveger seg fremover.
    /// Etter å ha ringt `rotate_left`, blir elementet tidligere ved indeks `mid` det første elementet i stykket.
    ///
    /// # Panics
    ///
    /// Denne funksjonen vil panic hvis `mid` er større enn skivelengden.Merk at `mid == self.len()` gjør _not_ panic og er en no-op-rotasjon.
    ///
    /// # Complexity
    ///
    /// Tar lineær (i `self.len()`) tid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rotere en delsnitt:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SIKKERHET: Området `[p.add(mid) - mid, p.add(mid) + k)` er trivielt
        // gyldig for lesing og skriving, slik `ptr_rotate` krever.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Roterer skiven på plass slik at de første `self.len() - k`-elementene i skiven beveger seg til enden mens de siste `k`-elementene beveger seg fremover.
    /// Etter å ha ringt `rotate_right`, blir elementet tidligere ved indeks `self.len() - k` det første elementet i stykket.
    ///
    /// # Panics
    ///
    /// Denne funksjonen vil panic hvis `k` er større enn skivelengden.Merk at `k == self.len()` gjør _not_ panic og er en no-op-rotasjon.
    ///
    /// # Complexity
    ///
    /// Tar lineær (i `self.len()`) tid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Roter en underdel:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SIKKERHET: Området `[p.add(mid) - mid, p.add(mid) + k)` er trivielt
        // gyldig for lesing og skriving, slik `ptr_rotate` krever.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Fyller `self` med elementer ved å klone `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Fyller `self` med elementer som returneres ved å ringe en nedleggelse flere ganger.
    ///
    /// Denne metoden bruker en lukking for å skape nye verdier.Hvis du heller vil [`Clone`] en gitt verdi, bruk [`fill`].
    /// Hvis du vil bruke [`Default`] trait til å generere verdier, kan du sende [`Default::default`] som argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopierer elementene fra `src` til `self`.
    ///
    /// Lengden på `src` må være den samme som `self`.
    ///
    /// Hvis `T` implementerer `Copy`, kan det være mer effektiv å bruke [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Denne funksjonen vil panic hvis de to skivene har forskjellige lengder.
    ///
    /// # Examples
    ///
    /// Kloning av to elementer fra et stykke i et annet:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Fordi skivene må være like lange, skiver vi kildeskiven fra fire elementer til to.
    /// // Det vil panic hvis vi ikke gjør dette.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust håndhever at det bare kan være en foranderlig referanse uten uforanderlige referanser til et bestemt stykke data i et bestemt omfang.
    /// På grunn av dette vil forsøk på å bruke `clone_from_slice` på ett stykke resultere i kompileringsfeil:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// For å omgå dette kan vi bruke [`split_at_mut`] til å lage to forskjellige underskiver fra et stykke:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopierer alle elementene fra `src` til `self`, ved hjelp av en memcpy.
    ///
    /// Lengden på `src` må være den samme som `self`.
    ///
    /// Hvis `T` ikke implementerer `Copy`, bruk [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Denne funksjonen vil panic hvis de to skivene har forskjellige lengder.
    ///
    /// # Examples
    ///
    /// Kopiering av to elementer fra et stykke til et annet:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Fordi skivene må være like lange, skiver vi kildeskiven fra fire elementer til to.
    /// // Det vil panic hvis vi ikke gjør dette.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust håndhever at det bare kan være en foranderlig referanse uten uforanderlige referanser til et bestemt stykke data i et bestemt omfang.
    /// På grunn av dette vil forsøk på å bruke `copy_from_slice` på ett stykke resultere i kompileringsfeil:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// For å omgå dette kan vi bruke [`split_at_mut`] til å lage to forskjellige underskiver fra et stykke:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic-kodebanen ble satt inn i en kald funksjon for ikke å oppblåse anropssiden.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SIKKERHET: `self` er gyldig for `self.len()`-elementer per definisjon, og `src` var
        // sjekket for å ha samme lengde.
        // Skivene kan ikke overlappe hverandre fordi mutable referanser er eksklusive.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopierer elementer fra en del av skiven til en annen del av seg selv ved hjelp av en memmove.
    ///
    /// `src` er området innen `self` å kopiere fra.
    /// `dest` er startindeksen for området innen `self` å kopiere til, som vil ha samme lengde som `src`.
    /// De to områdene kan overlappe hverandre.
    /// Endene på de to områdene må være mindre enn eller lik `self.len()`.
    ///
    /// # Panics
    ///
    /// Denne funksjonen vil panic hvis et område overstiger slutten av stykket, eller hvis slutten på `src` er før start.
    ///
    ///
    /// # Examples
    ///
    /// Kopiere fire byte i et stykke:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SIKKERHET: Betingelsene for `ptr::copy` har blitt sjekket ovenfor,
        // det samme har de for `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Bytter alle elementene i `self` med de i `other`.
    ///
    /// Lengden på `other` må være den samme som `self`.
    ///
    /// # Panics
    ///
    /// Denne funksjonen vil panic hvis de to skivene har forskjellige lengder.
    ///
    /// # Example
    ///
    /// Bytte to elementer over skiver:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust håndhever at det bare kan være en mutbar referanse til et bestemt stykke data i et bestemt omfang.
    ///
    /// På grunn av dette vil forsøk på å bruke `swap_with_slice` på ett stykke resultere i kompileringsfeil:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// For å omgå dette, kan vi bruke [`split_at_mut`] til å lage to distribuerbare underdeler fra et stykke:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SIKKERHET: `self` er gyldig for `self.len()`-elementer per definisjon, og `src` var
        // sjekket for å ha samme lengde.
        // Skivene kan ikke overlappe hverandre fordi mutable referanser er eksklusive.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funksjon for å beregne lengdene på den midterste og etterfølgende delen for `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Det vi skal gjøre med `rest`, er å finne ut hvilket multiplum av U-er vi kan legge inn med et laveste antall T-er.
        //
        // Og hvor mange `T`er vi trenger for hver slik "multiple".
        //
        // Tenk for eksempel på T=u8 U=u16.Så kan vi sette 1 U i 2 Ts.Enkel.
        // Tenk for eksempel på et tilfelle der size_of: :<T>=16, størrelse_av::<U>=24.</u>
        // Vi kan sette 2 Us i stedet for hver tredje Ts i `rest`-stykket.
        // Litt mer komplisert.
        //
        // Formelen for å beregne dette er:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Utvidet og forenklet:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Heldigvis siden alt dette er konstant evaluert ... ytelse her betyr ikke noe!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterativ steins algoritme. Vi bør fortsatt lage denne `const fn` (og gå tilbake til rekursiv algoritme hvis vi gjør det) fordi det å stole på at llvm skal utgjøre alt dette ... vel, det gjør meg ukomfortabel.
            //
            //

            // SIKKERHET: `a` og `b` er sjekket for å være ikke-nullverdier.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // fjern alle faktorene på 2 fra b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SIKKERHET: `b` er krysset av for å være null.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Bevæpnet med denne kunnskapen kan vi finne hvor mange U-er vi kan passe!
        let us_len = self.len() / ts * us;
        // Og hvor mange `T` vil være i den bakre delen!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmuter skiven til en skive av en annen type, og sørg for at justeringen av typene opprettholdes.
    ///
    /// Denne metoden deler skiven i tre forskjellige skiver: prefiks, riktig justert mellomskive av en ny type, og suffiksskiven.
    /// Metoden kan gjøre midtstykket størst mulig lengde for en gitt type og inndelingsskive, men bare algoritmens ytelse skal avhenge av det, ikke dens korrekthet.
    ///
    /// Det er tillatt at alle inngangsdata returneres som prefiks eller suffiks.
    ///
    /// Denne metoden har ikke noe formål når verken inngangselement `T` eller utgangselement `U` er nullstørrelse og vil returnere den originale delen uten å splitte noe.
    ///
    /// # Safety
    ///
    /// Denne metoden er egentlig en `transmute` med hensyn til elementene i den returnerte midtstykket, så alle vanlige advarsler som gjelder `transmute::<T, U>` gjelder også her.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Merk at det meste av denne funksjonen vil bli evaluert konstant,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // håndter ZST spesielt, som er-ikke håndter dem i det hele tatt.
            return (self, &[], &[]);
        }

        // Finn først på hvilket punkt vi deler mellom første og andre stykke.
        // Enkelt med ptr.align_offset.
        let ptr = self.as_ptr();
        // SIKKERHET: Se `align_to_mut`-metoden for detaljert sikkerhetskommentar.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SIKKERHET: Nå er `rest` definitivt justert, så `from_raw_parts` nedenfor er ok,
            // siden innringeren garanterer at vi kan overføre `T` til `U` trygt.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmuter skiven til en skive av en annen type, og sørg for at justeringen av typene opprettholdes.
    ///
    /// Denne metoden deler skiven i tre forskjellige skiver: prefiks, riktig justert mellomskive av en ny type, og suffiksskiven.
    /// Metoden kan gjøre midtstykket størst mulig lengde for en gitt type og inndelingsskive, men bare algoritmens ytelse skal avhenge av det, ikke dens korrekthet.
    ///
    /// Det er tillatt at alle inngangsdata returneres som prefiks eller suffiks.
    ///
    /// Denne metoden har ikke noe formål når verken inngangselement `T` eller utgangselement `U` er nullstørrelse og vil returnere den originale delen uten å splitte noe.
    ///
    /// # Safety
    ///
    /// Denne metoden er egentlig en `transmute` med hensyn til elementene i den returnerte midtstykket, så alle vanlige advarsler som gjelder `transmute::<T, U>` gjelder også her.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Merk at det meste av denne funksjonen vil bli evaluert konstant,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // håndter ZST spesielt, som er-ikke håndter dem i det hele tatt.
            return (self, &mut [], &mut []);
        }

        // Finn først på hvilket punkt vi deler mellom første og andre stykke.
        // Enkelt med ptr.align_offset.
        let ptr = self.as_ptr();
        // SIKKERHET: Her sørger vi for at vi vil bruke justerte pekere for U for
        // resten av metoden.Dette gjøres ved å sende en peker til&[T] med en justering rettet mot U.
        // `crate::ptr::align_offset` kalles med en riktig justert og gyldig peker `ptr` (den kommer fra en referanse til `self`) og med en størrelse som er en styrke på to (siden den kommer fra justeringen for U), og tilfredsstiller dens sikkerhetsbegrensninger.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Vi kan ikke bruke `rest` igjen etter dette, som vil ugyldiggjøre aliaset `mut_ptr`!SIKKERHET: se kommentarer til `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Sjekker om elementene i denne delen er sortert.
    ///
    /// Det vil si at for hvert element `a` og dets følgende element `b`, må `a <= b` holde.Hvis delen gir nøyaktig null eller ett element, returneres `true`.
    ///
    /// Merk at hvis `Self::Item` bare er `PartialOrd`, men ikke `Ord`, innebærer definisjonen ovenfor at denne funksjonen returnerer `false` hvis to påfølgende elementer ikke er sammenlignbare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Sjekker om elementene i denne delen er sortert ved hjelp av den gitte komparatorfunksjonen.
    ///
    /// I stedet for å bruke `PartialOrd::partial_cmp`, bruker denne funksjonen den gitte `compare`-funksjonen til å bestemme rekkefølgen av to elementer.
    /// Bortsett fra det tilsvarer det [`is_sorted`];se dokumentasjonen for mer informasjon.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Sjekker om elementene i denne delen er sortert ved hjelp av den gitte nøkkelutvinningsfunksjonen.
    ///
    /// I stedet for å sammenligne skiveelementene direkte, sammenligner denne funksjonen nøklene til elementene, som bestemt av `f`.
    /// Bortsett fra det tilsvarer det [`is_sorted`];se dokumentasjonen for mer informasjon.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Returnerer indeksen til partisjonspunktet i henhold til det gitte predikatet (indeksen til det første elementet i den andre partisjonen).
    ///
    /// Skiven antas å være partisjonert i henhold til gitt predikat.
    /// Dette betyr at alle elementene som predikatet returnerer sant for, er i begynnelsen av stykket, og alle elementene som predikatet returnerer falsk for, er på slutten.
    ///
    /// For eksempel er [7, 15, 3, 5, 4, 12, 6] en partisjonert under predikatet x% 2!=0 (alle oddetall er i starten, alt til og med på slutten).
    ///
    /// Hvis denne delen ikke er partisjonert, er det returnerte resultatet uspesifisert og meningsløst, siden denne metoden utfører et slags binært søk.
    ///
    /// Se også [`binary_search`], [`binary_search_by`] og [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SIKKERHET: Når `left < right`, `left <= mid < right`.
            // Derfor øker alltid `left` og `right` avtar alltid, og en av dem blir valgt.I begge tilfeller er `left <= right` fornøyd.Derfor, hvis `left < right` i et trinn, er `left <= right` fornøyd i neste trinn.
            //
            // Derfor så lenge `left != right`, `0 <= left < right <= len` er fornøyd, og hvis denne saken `0 <= mid < len` også er fornøyd.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Vi må eksplisitt skjære dem i samme lengde
        // for å gjøre det lettere for optimalisereren å fjerne grensekontroll.
        // Men siden det ikke kan stole på, har vi også en eksplisitt spesialisering for T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Skaper et tomt stykke.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Oppretter en muterbar tom skive.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Mønstre i skiver, for tiden, bare brukt av `strip_prefix` og `strip_suffix`.
/// På et future-punkt håper vi å generalisere `core::str::Pattern` (som i skrivende stund er begrenset til `str`) til skiver, og så blir denne trait erstattet eller avskaffet.
///
pub trait SlicePattern {
    /// Elementtypen til stykket som matches.
    type Item;

    /// For tiden trenger forbrukerne av `SlicePattern` et stykke.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}