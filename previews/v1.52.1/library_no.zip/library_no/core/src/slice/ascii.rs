//! Operasjoner på ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Sjekker om alle byte i denne delen er innenfor ASCII-området.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontrollerer at to skiver er en ASCII-saklig følsomhet.
    ///
    /// Samme som `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, men uten å tildele og kopiere midlertidige.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konverterer dette stykket til dets ASCII-store bokstaver tilsvarende på stedet.
    ///
    /// ASCII-bokstaver 'a' til 'z' tilordnes til 'A' til 'Z', men ikke-ASCII-bokstaver er uendret.
    ///
    /// For å returnere en ny versjon uten å endre den eksisterende, bruk [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konverterer denne delen til ASCII-småbokstavsekvivalenten på stedet.
    ///
    /// ASCII-bokstaver 'A' til 'Z' tilordnes til 'a' til 'z', men ikke-ASCII-bokstaver er uendret.
    ///
    /// For å returnere en ny verdi med lavere verdi uten å endre den eksisterende, bruk [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Returnerer `true` hvis noen byte i ordet `v` er nonascii (>=128).
/// Snarfed fra `../str/mod.rs`, som gjør noe lignende for utf8-validering.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimalisert ASCII-test som bruker usize-at-a-time operasjoner i stedet for byte-at-a-time operasjoner (når det er mulig).
///
/// Algoritmen vi bruker her er ganske enkel.Hvis `s` er for kort, sjekker vi bare hver byte og er ferdig med den.Ellers:
///
/// - Les det første ordet med en ujustert belastning.
/// - Juster pekeren, les påfølgende ord til slutten med justerte belastninger.
/// - Les den siste `usize` fra `s` med en ujustert belastning.
///
/// Hvis noen av disse lastene produserer noe som `contains_nonascii` (above) returnerer sant for, vet vi at svaret er usant.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Hvis vi ikke ville få noe ut av ord-på-en-gang-implementeringen, kan du falle tilbake til en skalær sløyfe.
    //
    // Vi gjør dette også for arkitekturer der `size_of::<usize>()` ikke er tilstrekkelig justering for `usize`, fordi det er en rar edge-sak.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Vi leser alltid det første ordet ujustert, noe som betyr at `align_offset` er det
    // 0, vil vi lese den samme verdien igjen for den justerte avlesningen.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SIKKERHET: Vi bekrefter `len < USIZE_SIZE` ovenfor.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Vi sjekket dette ovenfor, noe implisitt.
    // Merk at `offset_to_aligned` er enten `align_offset` eller `USIZE_SIZE`, begge er eksplisitt sjekket ovenfor.
    //
    debug_assert!(offset_to_aligned <= len);

    // SIKKERHET: word_ptr er (riktig justert) størrelsen ptr vi bruker for å lese
    // midtbiter av stykket.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` er byteindeksen til `word_ptr`, brukt til endekontroll av sløyfe.
    let mut byte_pos = offset_to_aligned;

    // Paranoia sjekker om justering, siden vi er i ferd med å gjøre en haug med ujusterte belastninger.
    // I praksis bør dette være umulig å utelukke en feil i `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Les påfølgende ord til det siste justerte ordet, unntatt det siste justerte ordet i seg selv som skal gjøres i halekontroll senere, for å sikre at halen alltid er en `usize` på det meste til ekstra branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity sjekk at avlesningen er innenfor grensene
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Og at våre antagelser om `byte_pos` holder.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SIKKERHET: Vi vet at `word_ptr` er riktig justert (pga
        // `align_offset`), og vi vet at vi har nok byte mellom `word_ptr` og slutten
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SIKKERHET: Vi vet at `byte_pos <= len - USIZE_SIZE`, som betyr det
        // etter denne `add` vil `word_ptr` være maksimalt en-the-end.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanitetssjekk for å sikre at det virkelig bare er en `usize` igjen.
    // Dette bør garanteres av vår sløyfetilstand.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SIKKERHET: Dette er avhengig av `len >= USIZE_SIZE`, som vi sjekker i starten.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}