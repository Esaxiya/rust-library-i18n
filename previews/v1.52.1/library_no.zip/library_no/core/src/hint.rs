#![stable(feature = "core_hint", since = "1.27.0")]

//! Tips til kompilatoren som påvirker hvordan koden skal sendes ut eller optimaliseres.
//! Tips kan være kompileringstid eller kjøretid.

use crate::intrinsics;

/// Informerer kompilatoren om at dette punktet i koden ikke er tilgjengelig, noe som muliggjør ytterligere optimaliseringer.
///
/// # Safety
///
/// Å nå denne funksjonen er helt *udefinert oppførsel*(UB).Spesielt antar kompilatoren at all UB aldri må skje, og vil derfor eliminere alle grener som når en samtale til `unreachable_unchecked()`.
///
/// Som denne forutsetningen av UB, hvis denne antagelsen viser seg å være feil, dvs. at `unreachable_unchecked()`-anropet faktisk er tilgjengelig blant alle mulige kontrollflyter, vil kompilatoren bruke feil optimaliseringsstrategi, og kan til og med til og med ødelegge tilsynelatende urelatert kode og forårsake vanskelig å feilsøke problemer.
///
///
/// Bruk denne funksjonen bare når du kan bevise at koden aldri vil ringe den.
/// Ellers bør du vurdere å bruke [`unreachable!`]-makroen, som ikke tillater optimalisering, men som vil panic når den kjøres.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` er alltid positiv (ikke null), derfor vil `checked_div` aldri returnere `None`.
/////
///     // Derfor er den andre branch ikke tilgjengelig.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SIKKERHET: sikkerhetskontrakten for `intrinsics::unreachable` må
    // bli opprettholdt av den som ringer.
    unsafe { intrinsics::unreachable() }
}

/// Avgir en maskininstruksjon for å signalisere prosessoren om at den kjører i en travel-vinne-sløyfe ("spinnlås").
///
/// Ved mottak av spin-loop-signalet kan prosessoren optimalisere sin oppførsel ved for eksempel å spare strøm eller bytte hyper-tråder.
///
/// Denne funksjonen er forskjellig fra [`thread::yield_now`] som gir direkte til systemets planlegger, mens `spin_loop` ikke samhandler med operativsystemet.
///
/// En vanlig brukssak for `spin_loop` er å implementere avgrenset optimistisk spinning i en CAS-sløyfe i synkroniseringsprimitiver.
/// For å unngå problemer som prioritert inversjon, anbefales det sterkt at spinnsløyfen avsluttes etter en endelig mengde iterasjoner og en passende blokkeringssignal er laget.
///
///
/// **Merk**: På plattformer som ikke støtter mottak av spin-loop-tips, gjør denne funksjonen ikke noe i det hele tatt.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // En delt atomverdi som tråder vil bruke til å koordinere
/// let live = Arc::new(AtomicBool::new(false));
///
/// // I en bakgrunnstråd setter vi til slutt verdien
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Gjør noe arbeid, så gjør verdien levende
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Tilbake på vår nåværende tråd, venter vi på at verdien skal settes
/// while !live.load(Ordering::Acquire) {
///     // Spinnsløyfen er et hint til CPUen at vi venter, men sannsynligvis ikke veldig lenge
/////
///     hint::spin_loop();
/// }
///
/// // Verdien er nå satt
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SIKKERHET: `cfg` attr sørger for at vi bare utfører dette på x86-mål.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SIKKERHET: `cfg` attr sørger for at vi bare utfører dette på x86_64-mål.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SIKKERHET: `cfg` attr sørger for at vi bare utfører dette på aarch64-mål.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SIKKERHET: `cfg` attr sørger for at vi bare utfører dette på armmål
            // med støtte for v6-funksjonen.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// En identitetsfunksjon som *__ antyder __* til kompilatoren for å være maksimalt pessimistisk om hva `black_box` kan gjøre.
///
/// I motsetning til [`std::convert::identity`] oppfordres en Rust-kompilator til å anta at `black_box` kan bruke `dummy` på en mulig gyldig måte som Rust-koden er tillatt til uten å innføre udefinert oppførsel i ringekoden.
///
/// Denne egenskapen gjør `black_box` nyttig for å skrive kode der visse optimaliseringer ikke er ønsket, for eksempel referanseverdier.
///
/// Vær imidlertid oppmerksom på at `black_box` bare (og kan bare leveres) på "best-effort"-basis.I hvilken grad det kan blokkere optimaliseringer kan variere avhengig av hvilken plattform og kodegenerasjon som brukes.
/// Programmer kan ikke stole på `black_box` for *korrekthet* på noen måte.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Vi må "use" argumentet på en eller annen måte LLVM ikke kan introspektere, og på mål som støtter det, kan vi vanligvis utnytte innebygd montering for å gjøre dette.
    // LLVMs tolkning av innebygd montering er at det er en svart boks.
    // Dette er ikke den største implementeringen siden den sannsynligvis deoptimerer mer enn vi vil, men den er så langt god nok.
    //
    //

    #[cfg(not(miri))] // Dette er bare et hint, så det er greit å hoppe over i Miri.
    // SIKKERHET: innebygd montering er en no-op.
    unsafe {
        // FIXME: Kan ikke bruke `asm!` fordi den ikke støtter MIPS og andre arkitekturer.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}