//! Delbare, foranderlige beholdere.
//!
//! Rust minnesikkerhet er basert på denne regelen: Gitt et objekt `T`, er det bare mulig å ha ett av følgende:
//!
//! - Har flere uforanderlige referanser (`&T`) til objektet (også kjent som **aliasing**).
//! - Å ha en mutbar referanse (`&mut T`) til objektet (også kjent som **mutabilitet**).
//!
//! Dette håndheves av Rust kompilatoren.Imidlertid er det situasjoner der denne regelen ikke er fleksibel nok.Noen ganger er det nødvendig å ha flere referanser til et objekt og likevel mutere det.
//!
//! Delbare mutable beholdere eksisterer for å tillate mutabilitet på en kontrollert måte, selv i nærvær av aliasing.Både [`Cell<T>`] og [`RefCell<T>`] tillater å gjøre dette på en enkelt tråd.
//! Imidlertid er verken `Cell<T>` eller `RefCell<T>` trådsikre (de implementerer ikke [`Sync`]).
//! Hvis du trenger å gjøre aliasing og mutasjon mellom flere tråder, er det mulig å bruke [`Mutex<T>`], [`RwLock<T>`] eller [`atomic`] typer.
//!
//! Verdiene av typene `Cell<T>` og `RefCell<T>` kan muteres gjennom delte referanser (dvs.
//! den vanlige `&T`-typen), mens de fleste Rust-typer bare kan muteres gjennom unike (`&mut T`) referanser.
//! Vi sier at `Cell<T>` og `RefCell<T>` gir 'indre mutabilitet', i motsetning til typiske Rust-typer som viser 'arvet mutabilitet'.
//!
//! Celletyper kommer i to smaker: `Cell<T>` og `RefCell<T>`.`Cell<T>` implementerer interiørmutabilitet ved å flytte verdier inn og ut av `Cell<T>`.
//! For å bruke referanser i stedet for verdier, må man bruke typen `RefCell<T>` og anskaffe en skrivelås før man muterer.`Cell<T>` gir metoder for å hente og endre gjeldende indre verdi:
//!
//!  - For typer som implementerer [`Copy`], henter [`get`](Cell::get)-metoden gjeldende indre verdi.
//!  - For typer som implementerer [`Default`], erstatter [`take`](Cell::take)-metoden gjeldende indre verdi med [`Default::default()`] og returnerer den erstattede verdien.
//!  - For alle typer erstatter [`replace`](Cell::replace)-metoden gjeldende indre verdi og returnerer den erstattede verdien, og [`into_inner`](Cell::into_inner)-metoden forbruker `Cell<T>` og returnerer den indre verdien.
//!  I tillegg erstatter [`set`](Cell::set)-metoden den indre verdien og slipper den erstattede verdien.
//!
//! `RefCell<T>` bruker Rust s levetid for å implementere 'dynamisk lån', en prosess der man kan kreve midlertidig, eksklusiv, muterbar tilgang til den indre verdien.
//! Låner til `RefCell<T>`s blir sporet 'ved kjøretid', i motsetning til Rust s opprinnelige referansetyper som er helt sporet statisk, på kompileringstidspunktet.
//! Fordi `RefCell<T>`-lån er dynamiske, er det mulig å prøve å låne en verdi som allerede er lånt.når dette skjer, resulterer det i tråden panic.
//!
//! # Når skal du velge interiørmutabilitet
//!
//! Den mer vanlige arvelige mutabiliteten, der man må ha unik tilgang til å mutere en verdi, er et av nøkkelspråkelementene som gjør det mulig for Rust å resonnere sterkt om aliasering av peker, og statisk forhindre krasjfeil.
//! På grunn av det er arvelig mutabilitet å foretrekke, og indre mutabilitet er noe av en siste utvei.
//! Siden celletyper muliggjør mutasjon der det ellers ikke ville være tillatt, er det tilfeller der indre mutabilitet kan være aktuelt, eller til og med *må* brukes, f.eks.
//!
//! * Vi introduserer mutabilitet 'inside' av noe uforanderlig
//! * Implementeringsdetaljer for logisk uforanderlige metoder.
//! * Muterende implementeringer av [`Clone`].
//!
//! ## Vi introduserer mutabilitet 'inside' av noe uforanderlig
//!
//! Mange delte smarte pekertyper, inkludert [`Rc<T>`] og [`Arc<T>`], gir containere som kan klones og deles mellom flere parter.
//! Fordi de innholdsverdiene kan være multiplisert, kan de bare lånes med `&`, ikke `&mut`.
//! Uten celler ville det i det hele tatt være umulig å mutere data inne i disse smarte pekerne.
//!
//! Det er veldig vanlig å sette en `RefCell<T>` i delte pekertyper for å gjeninnføre mutabilitet:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Opprett en ny blokk for å begrense omfanget av det dynamiske lånet
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Merk at hvis vi ikke hadde latt forrige lån av hurtigbufferen falle utenfor omfanget, ville den etterfølgende låningen forårsake en dynamisk tråd panic.
//!     //
//!     // Dette er den største faren ved å bruke `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Merk at dette eksemplet bruker `Rc<T>` og ikke `Arc<T>`.`RefCell<T>`s er for scenarier med en tråd.Vurder å bruke [`RwLock<T>`] eller [`Mutex<T>`] hvis du trenger delt mutabilitet i en situasjon med flere tråder.
//!
//! ## Implementeringsdetaljer for logisk uforanderlige metoder
//!
//! Noen ganger kan det være ønskelig å ikke avsløre i et API at det skjer en mutasjon "under the hood".
//! Dette kan være fordi logisk er operasjonen uforanderlig, men f.eks. Tvinger caching implementeringen til å utføre mutasjon;eller fordi du må bruke mutasjon for å implementere en trait-metode som opprinnelig ble definert til å ta `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Dyrt beregning går her
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Muterende implementeringer av `Clone`
//!
//! Dette er rett og slett et spesielt, men vanlig tilfelle av det forrige: å skjule mutabilitet for operasjoner som ser ut til å være uforanderlige.
//! [`clone`](Clone::clone)-metoden forventes ikke å endre kildeverdien, og erklæres å ta `&self`, ikke `&mut self`.
//! Derfor må enhver mutasjon som skjer i `clone`-metoden bruke celletyper.
//! For eksempel opprettholder [`Rc<T>`] referansetallene i en `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// En foranderlig minneplassering.
///
/// # Examples
///
/// I dette eksemplet kan du se at `Cell<T>` muliggjør mutasjon i en uforanderlig struktur.
/// Med andre ord, det muliggjør "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // FEIL: `my_struct` er uforanderlig
/// // my_struct.regular_field =ny_verdi;
///
/// // FUNKSJONER: Selv om `my_struct` er uforanderlig, er `special_field` en `Cell`,
/// // som alltid kan muteres
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Se [module-level documentation](self) for mer informasjon.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Oppretter en `Cell<T>`, med `Default`-verdien for T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Oppretter en ny `Cell` som inneholder den gitte verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Angir den innesluttede verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Bytter verdiene til to celler.
    /// Forskjellen med `std::mem::swap` er at denne funksjonen ikke krever `&mut`-referanse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SIKKERHET: Dette kan være risikabelt hvis det kalles fra separate tråder, men `Cell`
        // er `!Sync`, så dette vil ikke skje.
        // Dette vil heller ikke ugyldiggjøre noen pekere siden `Cell` sørger for at ingenting annet peker på noen av disse `Cellene '.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Erstatter den inneholdte verdien med `val`, og returnerer den gamle inneholdte verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SIKKERHET: Dette kan føre til dataløp hvis det ringes fra en egen tråd,
        // men `Cell` er `!Sync`, så dette vil ikke skje.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Pakk ut verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Returnerer en kopi av den innholdte verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SIKKERHET: Dette kan føre til dataløp hvis det ringes fra en egen tråd,
        // men `Cell` er `!Sync`, så dette vil ikke skje.
        unsafe { *self.value.get() }
    }

    /// Oppdaterer den inneholdte verdien ved hjelp av en funksjon og returnerer den nye verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Returnerer en rå peker til de underliggende dataene i denne cellen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Returnerer en foranderlig referanse til de underliggende dataene.
    ///
    /// Denne samtalen låner `Cell` mutabelt (ved kompileringstid) som garanterer at vi har den eneste referansen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Returnerer en `&Cell<T>` fra en `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SIKKERHET: `&mut` sørger for unik tilgang.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Tar verdien av cellen og lar `Default::default()` være på plass.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Returnerer en `&[Cell<T>]` fra en `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SIKKERHET: `Cell<T>` har samme minneoppsett som `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// En foranderlig minneplassering med dynamisk kontrollerte låneregler
///
/// Se [module-level documentation](self) for mer informasjon.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// En feil returnert av [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// En feil returnert av [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positive verdier representerer antall `Ref` aktive.Negative verdier representerer antall `RefMut` aktive.
// Flere `RefMut`s kan bare være aktive om gangen hvis de refererer til forskjellige, ikke-overlappende komponenter i en `RefCell` (f.eks. Forskjellige områder av et stykke).
//
// `Ref` og `RefMut` er begge to ord i størrelse, og så vil det sannsynligvis aldri være nok `Ref` eller`RefMut` til å overfylle halvparten av `usize`-serien.
// Dermed vil en `BorrowFlag` sannsynligvis aldri strømme over eller understrømme.
// Dette er imidlertid ikke en garanti, et patologisk program kan gjentatte ganger opprette og deretter mem::forget `Ref`s eller`RefMut`s.
// Dermed må all kode eksplisitt sjekke for overflow og underflow for å unngå usikkerhet, eller i det minste oppføre seg riktig i tilfelle overflow eller underflow skjer (f.eks. Se BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Oppretter en ny `RefCell` som inneholder `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Forbruker `RefCell` og returnerer den innpakkede verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Siden denne funksjonen tar `self` (`RefCell`) etter verdi, verifiserer kompilatoren statisk at den ikke er lånt for øyeblikket.
        //
        self.value.into_inner()
    }

    /// Erstatter den innpakkede verdien med en ny, og returnerer den gamle verdien uten å avinitialisere noen av dem.
    ///
    ///
    /// Denne funksjonen tilsvarer [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics hvis verdien for øyeblikket er lånt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Erstatter den innpakkede verdien med en ny beregnet fra `f`, og returnerer den gamle verdien uten å deaktivere noen av dem.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis verdien for øyeblikket er lånt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Bytter innpakket verdi av `self` med innpakket verdi `other`, uten å deaktivere noen av dem.
    ///
    ///
    /// Denne funksjonen tilsvarer [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics hvis verdien i en av `RefCell` for øyeblikket er lånt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Låner uformelt innpakket verdi.
    ///
    /// Lånet varer til den returnerte `Ref` går ut av omfanget.
    /// Flere uforanderlige lån kan tas ut samtidig.
    ///
    /// # Panics
    ///
    /// Panics hvis verdien for øyeblikket lånes mutabelt.
    /// For en variant uten panikk, bruk [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Et eksempel på panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Låner uformelt innpakket verdi og returnerer en feil hvis verdien for øyeblikket er lånt.
    ///
    ///
    /// Lånet varer til den returnerte `Ref` går ut av omfanget.
    /// Flere uforanderlige lån kan tas ut samtidig.
    ///
    /// Dette er den ikke-panikk-varianten av [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SIKKERHET: `BorrowRef` sørger for at det bare er uforanderlig tilgang
            // til verdien mens den er lånt.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Låner mutabelt den innpakkede verdien.
    ///
    /// Lånet varer til det returnerte `RefMut` eller alle `RefMut`er som er avledet fra det exit-omfanget.
    ///
    /// Verdien kan ikke lånes mens denne lånen er aktiv.
    ///
    /// # Panics
    ///
    /// Panics hvis verdien for øyeblikket er lånt.
    /// For en variant uten panikk, bruk [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Et eksempel på panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Låner mutatisk den innpakkede verdien, og returnerer en feil hvis verdien for øyeblikket er lånt.
    ///
    ///
    /// Lånet varer til det returnerte `RefMut` eller alle `RefMut`er som er avledet fra det exit-omfanget.
    /// Verdien kan ikke lånes mens denne lånen er aktiv.
    ///
    /// Dette er den ikke-panikk-varianten av [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SIKKERHET: `BorrowRef` garanterer unik tilgang.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Returnerer en rå peker til de underliggende dataene i denne cellen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Returnerer en foranderlig referanse til de underliggende dataene.
    ///
    /// Denne samtalen låner `RefCell` mutabelt (ved kompileringstid), slik at det ikke er behov for dynamiske kontroller.
    ///
    /// Vær imidlertid forsiktig: denne metoden forventer at `self` kan forandres, noe som vanligvis ikke er tilfelle når du bruker en `RefCell`.
    ///
    /// Ta en titt på [`borrow_mut`]-metoden i stedet hvis `self` ikke kan endres.
    ///
    /// Vær også oppmerksom på at denne metoden bare er for spesielle omstendigheter og vanligvis ikke er det du vil ha.
    /// I tilfelle tvil, bruk [`borrow_mut`] i stedet.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Angre effekten av lekket vakt på lånetilstanden til `RefCell`.
    ///
    /// Denne samtalen ligner på [`get_mut`], men mer spesialisert.
    /// Den låner `RefCell` mutabelt for å sikre at det ikke finnes noen lån, og tilbakestiller deretter staten som sporer delte lån.
    /// Dette er relevant hvis noen `Ref`-eller `RefMut`-lån har blitt lekket.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Låner uformelt innpakket verdi og returnerer en feil hvis verdien for øyeblikket er lånt.
    ///
    /// # Safety
    ///
    /// I motsetning til `RefCell::borrow` er denne metoden usikker fordi den ikke returnerer en `Ref`, og dermed blir låneflagget uberørt.
    /// Gjensidig lån av `RefCell` mens referansen som returneres med denne metoden er i live, er udefinert oppførsel.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SIKKERHET: Vi sjekker at ingen skriver aktivt nå, men det er det
            // innringers ansvar for å sikre at ingen skriver før den returnerte referansen ikke lenger er i bruk.
            // `self.value.get()` refererer også til verdien som eies av `self` og er dermed garantert å være gyldig i løpet av `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Tar den innpakket verdien og lar `Default::default()` være på plass.
    ///
    /// # Panics
    ///
    /// Panics hvis verdien for øyeblikket er lånt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics hvis verdien for øyeblikket lånes mutabelt.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Oppretter en `RefCell<T>`, med `Default`-verdien for T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics hvis verdien i en av `RefCell` for øyeblikket er lånt.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics hvis verdien i en av `RefCell` for øyeblikket er lånt.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics hvis verdien i en av `RefCell` for øyeblikket er lånt.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics hvis verdien i en av `RefCell` for øyeblikket er lånt.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics hvis verdien i en av `RefCell` for øyeblikket er lånt.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics hvis verdien i en av `RefCell` for øyeblikket er lånt.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics hvis verdien i en av `RefCell` for øyeblikket er lånt.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Økende lån kan resultere i en ikke-lesende verdi (<=0) i disse tilfellene:
            // 1. Det var <0, dvs. at det er skrivelån, så vi kan ikke tillate et lest lån på grunn av Rust s referansealiaseringsregler
            // 2.
            // Det var isize::MAX (maksimalt antall lån som ble lest), og det rant over i isize::MIN (maksimalt antall lån som er skrevet), slik at vi ikke kan tillate et ekstra lese-lån fordi isize ikke kan representere så mange lese-lån (dette kan bare skje hvis du mem::forget mer enn en liten konstant mengde `Ref`s, noe som ikke er god praksis)
            //
            //
            //
            //
            None
        } else {
            // Økende lån kan resultere i en leseverdi (> 0) i disse tilfellene:
            // 1. Det var=0, det vil si at det ikke var lånt, og vi tar førsteleset lån
            // 2. Det var> 0 og <isize::MAX, dvs.
            // det ble lest lån, og isize er stort nok til å representere det å ha en mer lest lån
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Siden denne ref eksisterer, vet vi at låneflagget er et leselån.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Forhindre at lånetelleren renner over i en skriftlig lån.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Pakk inn en lånt referanse til en verdi i en `RefCell`-boks.
/// En innpakningstype for en uforlignelig lånt verdi fra en `RefCell<T>`.
///
/// Se [module-level documentation](self) for mer informasjon.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopierer en `Ref`.
    ///
    /// `RefCell` er allerede umåtelig lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funksjon som må brukes som `Ref::clone(...)`.
    /// En `Clone`-implementering eller en metode vil forstyrre den utbredte bruken av `r.borrow().clone()` for å klone innholdet i en `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Lager en ny `Ref` for en del av de lånte dataene.
    ///
    /// `RefCell` er allerede umåtelig lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funksjon som må brukes som `Ref::map(...)`.
    /// En metode vil forstyrre metoder med samme navn på innholdet i en `RefCell` som brukes gjennom `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Lager en ny `Ref` for en valgfri komponent av de lånte dataene.
    /// Den originale vernet returneres som en `Err(..)` hvis lukkingen returnerer `None`.
    ///
    /// `RefCell` er allerede umåtelig lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funksjon som må brukes som `Ref::filter_map(...)`.
    /// En metode vil forstyrre metoder med samme navn på innholdet i en `RefCell` som brukes gjennom `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Deler en `Ref` i flere `Ref`er for forskjellige komponenter i de lånte dataene.
    ///
    /// `RefCell` er allerede umåtelig lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funksjon som må brukes som `Ref::map_split(...)`.
    /// En metode vil forstyrre metoder med samme navn på innholdet i en `RefCell` som brukes gjennom `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Konverter til en referanse til de underliggende dataene.
    ///
    /// Den underliggende `RefCell` kan aldri lånes fra igjen og vil alltid fremstå som uforanderlig lånt.
    ///
    /// Det er ikke en god ide å lekke mer enn et konstant antall referanser.
    /// `RefCell` kan immutabelt lånes igjen hvis bare et mindre antall lekkasjer har skjedd totalt.
    ///
    /// Dette er en tilknyttet funksjon som må brukes som `Ref::leak(...)`.
    /// En metode vil forstyrre metoder med samme navn på innholdet i en `RefCell` som brukes gjennom `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Ved å glemme denne refen, sørger vi for at lånetelleren i RefCell ikke kan gå tilbake til ubrukt i løpet av `'b` levetid.
        // Tilbakestilling av referansesporingsstatusen vil kreve en unik referanse til den lånte RefCell.
        // Ingen ytterligere foranderlige referanser kan opprettes fra den opprinnelige cellen.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Lager en ny `RefMut` for en komponent av de lånte dataene, for eksempel en enum-variant.
    ///
    /// `RefCell` er allerede mutet lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funksjon som må brukes som `RefMut::map(...)`.
    /// En metode vil forstyrre metoder med samme navn på innholdet i en `RefCell` som brukes gjennom `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): fikse lånesjekk
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Lager en ny `RefMut` for en valgfri komponent av de lånte dataene.
    /// Den originale vernet returneres som en `Err(..)` hvis lukkingen returnerer `None`.
    ///
    /// `RefCell` er allerede mutet lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funksjon som må brukes som `RefMut::filter_map(...)`.
    /// En metode vil forstyrre metoder med samme navn på innholdet i en `RefCell` som brukes gjennom `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): fikse lånesjekk
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SIKKERHET: funksjonen holder på en eksklusiv referanse for varigheten
        // av sin samtale gjennom `orig`, og pekeren er bare referert inne i funksjonsanropet, slik at den eksklusive referansen ikke kan unnslippe.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SIKKERHET: samme som ovenfor.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Deler en `RefMut` i flere `RefMut`s for forskjellige komponenter i de lånte dataene.
    ///
    /// Den underliggende `RefCell` vil fortsatt være lånt ut til begge returnerte `RefMut`ene kommer utenfor omfanget.
    ///
    /// `RefCell` er allerede mutet lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funksjon som må brukes som `RefMut::map_split(...)`.
    /// En metode vil forstyrre metoder med samme navn på innholdet i en `RefCell` som brukes gjennom `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Konverter til en mutbar referanse til de underliggende dataene.
    ///
    /// Den underliggende `RefCell` kan ikke lånes fra igjen og vil alltid fremstå som allerede mutert lånt, noe som gjør den returnerte referansen den eneste til interiøret.
    ///
    ///
    /// Dette er en tilknyttet funksjon som må brukes som `RefMut::leak(...)`.
    /// En metode vil forstyrre metoder med samme navn på innholdet i en `RefCell` som brukes gjennom `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ved å glemme denne BorrowRefMut, sørger vi for at lånetelleren i RefCell ikke kan gå tilbake til UNUSED i løpet av `'b` levetid.
        // Tilbakestilling av referansesporingsstatusen vil kreve en unik referanse til den lånte RefCell.
        // Ingen ytterligere referanser kan opprettes fra den opprinnelige cellen i løpet av den levetiden, noe som gjør gjeldende lån til den eneste referansen for den gjenværende levetiden.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: I motsetning til BorrowRefMut::clone kalles nytt for å lage initialen
        // muterbar referanse, og det må for øyeblikket ikke være noen eksisterende referanser.
        // Således, mens klon øker den muterbare reftellingen, tillater vi her eksplisitt bare å gå fra UNUSED til UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Kloner en `BorrowRefMut`.
    //
    // Dette er bare gyldig hvis hver `BorrowRefMut` brukes til å spore en mutbar referanse til et distinkt, ikke-overlappende område for det opprinnelige objektet.
    //
    // Dette er ikke i en klonimpl, slik at koden ikke kaller dette implisitt.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Forhindre at lånetelleren strømmer under.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// En innpakningstype for en mutert lånt verdi fra en `RefCell<T>`.
///
/// Se [module-level documentation](self) for mer informasjon.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Kjernen primitiv for interiørmutabilitet i Rust.
///
/// Hvis du har en referanse `&T`, utfører kompilatoren normalt i Rust optimaliseringer basert på kunnskapen om at `&T` peker på uforanderlige data.Å mutere disse dataene, for eksempel gjennom et alias eller ved å overføre en `&T` til en `&mut T`, betraktes som udefinert oppførsel.
/// `UnsafeCell<T>` velger bort garantien for uforanderlighet for `&T`: en delt referanse `&UnsafeCell<T>` kan peke på data som blir mutert.Dette kalles "interior mutability".
///
/// Alle andre typer som tillater intern mutabilitet, for eksempel `Cell<T>` og `RefCell<T>`, bruker `UnsafeCell` internt til å pakke inn dataene sine.
///
/// Vær oppmerksom på at bare garantien for uforanderlighet for delte referanser påvirkes av `UnsafeCell`.Unikitetsgarantien for foranderlige referanser påvirkes ikke.Det er *ingen* lovlig måte å få aliasing `&mut`, ikke engang med `UnsafeCell<T>`.
///
/// `UnsafeCell` API i seg selv er teknisk veldig enkelt: [`.get()`] gir deg en rå peker `*mut T` til innholdet.Det er opp til _you_ som abstraksjonsdesigner å bruke den rå pekeren riktig.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// De nøyaktige Rust-aliaseringsreglene er noe i bevegelse, men hovedpoengene er ikke omstridt:
///
/// - Hvis du oppretter en sikker referanse med levetiden `'a` (enten en `&T`-eller `&mut T`-referanse) som er tilgjengelig med sikker kode (for eksempel fordi du returnerte den), må du ikke få tilgang til dataene på noen måte som strider mot referansen for resten av `'a`.
/// For eksempel betyr dette at hvis du tar `*mut T` fra en `UnsafeCell<T>` og kaster den til en `&T`, så må dataene i `T` forbli uforanderlige (modulo alle `UnsafeCell`-data som finnes i `T`, selvfølgelig) til referansens levetid utløper.
/// På samme måte, hvis du oppretter en `&mut T`-referanse som frigjøres til sikker kode, må du ikke få tilgang til dataene i `UnsafeCell` før den referansen utløper.
///
/// - Du må til enhver tid unngå dataløp.Hvis flere tråder har tilgang til den samme `UnsafeCell`, må alle skrivinger ha en skikkelig hendelse-før-forhold til alle andre tilganger (eller bruk atomics).
///
/// For å hjelpe til med riktig design er følgende scenarier eksplisitt erklært lovlige for kode med en tråd:
///
/// 1. En `&T`-referanse kan frigis til sikker kode, og der kan den eksistere sammen med andre `&T`-referanser, men ikke med en `&mut T`
///
/// 2. En `&mut T`-referanse kan frigis til sikker kode forutsatt at verken annen `&mut T` eller `&T` eksisterer sammen med den.En `&mut T` må alltid være unik.
///
/// Merk at mens mutering av innholdet i en `&UnsafeCell<T>` (selv om andre `&UnsafeCell<T>` refererer til alias cellen) er ok (forutsatt at du håndhever ovennevnte invarianter på en annen måte), er det fremdeles udefinert oppførsel å ha flere `&mut UnsafeCell<T>`-aliaser.
/// Det vil si at `UnsafeCell` er en innpakning designet for å ha en spesiell interaksjon med _shared_ accesses (_i.e._, gjennom en `&UnsafeCell<_>`-referanse);det er ingen magi overhodet når du arbeider med _exclusive_ accesses (_e.g._, gjennom en `&mut UnsafeCell<_>`): verken cellen eller den innpakkede verdien kan være alias for varigheten av den `&mut` lånet.
///
/// Dette vises av [`.get_mut()`] accessor, som er en _safe_ getter som gir en `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Her er et eksempel som viser hvordan du kan mutere innholdet på en `UnsafeCell<_>`, til tross for at det er flere referanser som aliaserer cellen:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Få flere/delte referanser til samme `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SIKKERHET: innenfor dette omfanget er det ingen andre referanser til innholdet i `x`,
///     // så vårt er effektivt unikt.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- låne-+
///     *p1_exclusive += 27; // |
/// } // <---------- kan ikke gå utover dette punktet -------------------+
///
/// unsafe {
///     // SIKKERHET: innenfor dette omfanget forventer ingen å ha eksklusiv tilgang til innholdet til "x",
///     // slik at vi kan ha flere delte tilganger samtidig.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Følgende eksempel viser at eksklusiv tilgang til en `UnsafeCell<T>` innebærer eksklusiv tilgang til `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // med eksklusive tilganger,
///                         // `UnsafeCell` er en gjennomsiktig no-op-innpakning, så du trenger ikke `unsafe` her.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Få en kompileringstidskontrollert unik referanse til `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Med en eksklusiv referanse kan vi mutere innholdet gratis.
/// *p_unique.get_mut() = 0;
/// // Eller tilsvarende:
/// x = UnsafeCell::new(0);
///
/// // Når vi eier verdien, kan vi trekke ut innholdet gratis.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Konstruerer en ny forekomst av `UnsafeCell` som vil pakke den angitte verdien.
    ///
    ///
    /// All tilgang til den indre verdien gjennom metoder er `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Pakk ut verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Får en muterbar peker til den innpakkede verdien.
    ///
    /// Dette kan kastes til en peker av noe slag.
    /// Forsikre deg om at tilgangen er unik (ingen aktive referanser, muterbar eller ikke) når du kaster til `&mut T`, og sørg for at det ikke skjer mutasjoner eller mutable alias når du kaster til `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Vi kan bare kaste pekeren fra `UnsafeCell<T>` til `T` på grunn av #[repr(transparent)].
        // Dette utnytter libstds spesielle status, det er ingen garanti for brukerkode at dette vil fungere i future-versjoner av kompilatoren!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Returnerer en foranderlig referanse til de underliggende dataene.
    ///
    /// Denne samtalen låner `UnsafeCell` mutabelt (ved kompileringstid), noe som garanterer at vi har den eneste referansen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Får en muterbar peker til den innpakkede verdien.
    /// Forskjellen til [`get`] er at denne funksjonen godtar en rå peker, noe som er nyttig for å unngå oppretting av midlertidige referanser.
    ///
    /// Resultatet kan kastes til en peker av noe slag.
    /// Forsikre deg om at tilgangen er unik (ingen aktive referanser, muterbar eller ikke) når du kaster til `&mut T`, og sørg for at det ikke foregår mutasjoner eller mutable alias når du kaster til `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Gradvis initialisering av en `UnsafeCell` krever `raw_get`, ettersom å ringe `get` vil kreve å opprette en referanse til ikke-initialiserte data:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Vi kan bare kaste pekeren fra `UnsafeCell<T>` til `T` på grunn av #[repr(transparent)].
        // Dette utnytter libstds spesielle status, det er ingen garanti for brukerkode at dette vil fungere i future-versjoner av kompilatoren!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Oppretter en `UnsafeCell`, med `Default`-verdien for T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}