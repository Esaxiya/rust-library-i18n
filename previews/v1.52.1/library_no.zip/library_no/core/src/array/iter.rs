//! Definerer den `IntoIter`-eide iteratoren for arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// En verdi [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Dette er matrisen vi itererer over.
    ///
    /// Elementer med indeks `i` der `alive.start <= i < alive.end` ikke har blitt gitt ennå og er gyldige matriseposter.
    /// Elementer med indeksene `i < alive.start` eller `i >= alive.end` er allerede gitt og må ikke nås lenger!Disse døde elementene kan til og med være i en helt uinitialisert tilstand!
    ///
    ///
    /// Så invarianter er:
    /// - `data[alive]` er i live (dvs. inneholder gyldige elementer)
    /// - `data[..alive.start]` og `data[alive.end..]` er døde (dvs. elementene var allerede lest og må ikke berøres lenger!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Elementene i `data` som ikke har blitt gitt ennå.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Oppretter en ny iterator over den gitte `array`.
    ///
    /// *Merk*: denne metoden kan bli avviklet i future, etter [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Typen `value` er en `i32` her, i stedet for `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SIKKERHET: Transmitteringen her er faktisk trygg.Dokumentene til `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` er garantert å ha samme størrelse og justering
        // > som `T`.
        //
        // Dokumentene viser til og med en transmute fra en matrise på `MaybeUninit<T>` til en matrise på `T`.
        //
        //
        // Med det tilfredsstiller denne initialiseringen invarianter.

        // FIXME(LukasKalbertodt): faktisk bruker `mem::transmute` her, når det fungerer med const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Inntil da kan vi bruke `mem::transmute_copy` til å lage en bitvis kopi som en annen type, og deretter glemme `array` slik at den ikke blir droppet.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Returnerer en uforanderlig del av alle elementene som ikke har blitt gitt ennå.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SIKKERHET: Vi vet at alle elementene i `alive` er riktig initialisert.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Returnerer en foranderlig del av alle elementene som ikke har blitt gitt ennå.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SIKKERHET: Vi vet at alle elementene i `alive` er riktig initialisert.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Få neste indeks fra forsiden.
        //
        // Å øke `alive.start` med 1 opprettholder invarianten angående `alive`.
        // Imidlertid, på grunn av denne endringen, i kort tid, er den levende sonen ikke `data[alive]` lenger, men `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Les elementet fra matrisen.
            // SIKKERHET: `idx` er en indeks i den tidligere "alive"-regionen i
            // array.Å lese dette elementet betyr at `data[idx]` blir ansett som død nå (dvs. ikke berør).
            // Da `idx` var starten på den levende sonen, er den levende sonen nå `data[alive]` igjen, og gjenoppretter alle invarianter.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Få neste indeks bakfra.
        //
        // Å redusere `alive.end` med 1 opprettholder invarianten angående `alive`.
        // Imidlertid, på grunn av denne endringen, i kort tid, er den levende sonen ikke `data[alive]` lenger, men `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Les elementet fra matrisen.
            // SIKKERHET: `idx` er en indeks i den tidligere "alive"-regionen i
            // array.Å lese dette elementet betyr at `data[idx]` blir ansett som død nå (dvs. ikke berør).
            // Da `idx` var slutten på den levende sonen, er den levende sonen nå `data[alive]` igjen, og gjenoppretter alle invarianter.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SIKKERHET: Dette er trygt: `as_mut_slice` returnerer nøyaktig underdel
        // av elementer som ikke er flyttet ut ennå, og som gjenstår å slippe.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Vil aldri strømme på grunn av den uforanderlige `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iteratoren rapporterer faktisk riktig lengde.
// Antallet "alive"-elementer (som fremdeles vil bli gitt) er lengden på området `alive`.
// Dette området er redusert i lengde i enten `next` eller `next_back`.
// Det blir alltid redusert med 1 i disse metodene, men bare hvis `Some(_)` returneres.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Merk at vi egentlig ikke trenger å matche nøyaktig samme levende område, så vi kan bare klone til forskyvning 0 uansett hvor `self` er.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klone alle levende elementer.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Skriv en klon i den nye matrisen, og oppdater deretter sitt levende område.
            // Hvis vi kloner panics, slipper vi de forrige elementene riktig.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Skriv bare ut elementene som ikke ble gitt ennå: vi har ikke tilgang til de oppnådde elementene lenger.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}