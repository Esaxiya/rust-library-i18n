use crate::iter::{FusedIterator, TrustedLen};

/// Oppretter en iterator som lat genererer en verdi nøyaktig en gang ved å påkalle den medfølgende lukningen.
///
/// Dette brukes ofte til å tilpasse en enkeltverdienerator til en [`chain()`] av andre typer iterasjon.
/// Kanskje du har en iterator som dekker nesten alt, men du trenger en ekstra spesiell sak.
/// Kanskje du har en funksjon som fungerer på iteratorer, men du trenger bare å behandle en verdi.
///
/// I motsetning til [`once()`], genererer denne funksjonen verdien på forespørsel.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::iter;
///
/// // en er det ensomste tallet
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // bare en, det er alt vi får
/// assert_eq!(None, one.next());
/// ```
///
/// Kjetting sammen med en annen iterator.
/// La oss si at vi vil gjenta hver fil i `.foo`-katalogen, men også en konfigurasjonsfil,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // vi må konvertere fra en iterator av DirEntry-s til en iterator av PathBufs, så vi bruker kart
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nå, vår iterator bare for konfigurasjonsfilen vår
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // lenke de to iteratorene sammen til en stor iterator
/// let files = dirs.chain(config);
///
/// // Dette vil gi oss alle filene i .foo så vel som .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// En iterator som gir et enkelt element av typen `A` ved å bruke den medfølgende lukningen `F: FnOnce() -> A`.
///
///
/// Denne `struct` er opprettet av [`once_with()`]-funksjonen.
/// Se dokumentasjonen for mer.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}