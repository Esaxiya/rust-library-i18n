use crate::iter::{FusedIterator, TrustedLen};

/// Oppretter en iterator som gir et element nøyaktig en gang.
///
/// Dette brukes ofte til å tilpasse en enkelt verdi til en [`chain()`] av andre typer iterasjon.
/// Kanskje du har en iterator som dekker nesten alt, men du trenger en ekstra spesiell sak.
/// Kanskje du har en funksjon som fungerer på iteratorer, men du trenger bare å behandle en verdi.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::iter;
///
/// // en er det ensomste tallet
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // bare en, det er alt vi får
/// assert_eq!(None, one.next());
/// ```
///
/// Kjetting sammen med en annen iterator.
/// La oss si at vi vil gjenta hver fil i `.foo`-katalogen, men også en konfigurasjonsfil,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // vi må konvertere fra en iterator av DirEntry-s til en iterator av PathBufs, så vi bruker kart
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nå, vår iterator bare for konfigurasjonsfilen vår
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // lenke de to iteratorene sammen til en stor iterator
/// let files = dirs.chain(config);
///
/// // Dette vil gi oss alle filene i .foo så vel som .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// En iterator som gir et element nøyaktig en gang.
///
/// Denne `struct` er opprettet av [`once()`]-funksjonen.Se dokumentasjonen for mer.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}