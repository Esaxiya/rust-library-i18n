use crate::iter::{FusedIterator, TrustedLen};

/// Oppretter en ny iterator som endeløst gjentar et enkelt element.
///
/// `repeat()`-funksjonen gjentar en enkelt verdi igjen og igjen.
///
/// Uendelige iteratorer som `repeat()` brukes ofte med adaptere som [`Iterator::take()`], for å gjøre dem endelige.
///
/// Hvis elementtypen til iteratoren du trenger ikke implementerer `Clone`, eller hvis du ikke vil beholde det gjentatte elementet i minnet, kan du i stedet bruke [`repeat_with()`]-funksjonen.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::iter;
///
/// // nummer fire 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, fortsatt fire
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Går endelig med [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // det siste eksemplet var for mange firere.La oss bare ha fire firere.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... og nå er vi ferdige
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// En iterator som gjentar et element uendelig.
///
/// Denne `struct` er opprettet av [`repeat()`]-funksjonen.Se dokumentasjonen for mer.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}