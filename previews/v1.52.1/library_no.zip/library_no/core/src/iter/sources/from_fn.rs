use crate::fmt;

/// Oppretter en ny iterator der hver iterasjon kaller den medfølgende lukningen `F: FnMut() -> Option<T>`.
///
/// Dette gjør det mulig å lage en tilpasset iterator med hvilken som helst oppførsel uten å bruke den mer detaljerte syntaksen for å lage en dedikert type og implementere [`Iterator`] trait for den.
///
/// Merk at `FromFn` iteratoren ikke legger til grunn antagelser om oppførselen til nedleggelsen, og derfor ikke implementerer [`FusedIterator`] konservativt, eller overstyrer [`Iterator::size_hint()`] fra standard `(0, None)`.
///
///
/// Avslutningen kan bruke opptak og omgivelsene for å spore tilstand på tvers av iterasjoner.Avhengig av hvordan iteratoren brukes, kan dette kreve at du angir [`move`]-nøkkelordet på nedleggelsen.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// La oss implementere counter iteratoren fra [module-level documentation] på nytt:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Øk antallet våre.Dette er grunnen til at vi startet på null.
///     count += 1;
///
///     // Sjekk om vi er ferdig med å telle eller ikke.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// En iterator der hver iterasjon kaller den medfølgende lukningen `F: FnMut() -> Option<T>`.
///
/// Denne `struct` er opprettet av [`iter::from_fn()`]-funksjonen.
/// Se dokumentasjonen for mer.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}