use crate::iter::{FusedIterator, TrustedLen};

/// Oppretter en ny iterator som gjentar elementer av typen `A` uendelig ved å bruke den medfølgende lukkingen, repeateren, `F: FnMut() -> A`.
///
/// `repeat_with()`-funksjonen kaller repeateren om og om igjen.
///
/// Uendelige iteratorer som `repeat_with()` brukes ofte med adaptere som [`Iterator::take()`], for å gjøre dem endelige.
///
/// Hvis elementtypen til iteratoren du trenger implementerer [`Clone`], og det er OK å holde kildeelementet i minnet, bør du i stedet bruke [`repeat()`]-funksjonen.
///
///
/// En iterator produsert av `repeat_with()` er ikke en [`DoubleEndedIterator`].
/// Hvis du trenger `repeat_with()` for å returnere en [`DoubleEndedIterator`], kan du åpne et GitHub-problem som forklarer brukssaken din.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::iter;
///
/// // la oss anta at vi har noen verdi av en type som ikke er `Clone` eller som ikke vil ha i minnet ennå fordi den er dyr:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // en bestemt verdi for alltid:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Ved hjelp av mutasjon og blir endelig:
///
/// ```rust
/// use std::iter;
///
/// // Fra null til tredje kraft av to:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... og nå er vi ferdige
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// En iterator som gjentar elementer av typen `A` uendelig ved å bruke den medfølgende lukningen `F: FnMut() -> A`.
///
///
/// Denne `struct` er opprettet av [`repeat_with()`]-funksjonen.
/// Se dokumentasjonen for mer.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}