use crate::{fmt, iter::FusedIterator};

/// Oppretter en ny iterator der hver påfølgende vare beregnes basert på den forrige.
///
/// Iteratoren starter med den gitte første varen (hvis noen) og kaller den gitte `FnMut(&T) -> Option<T>`-lukningen for å beregne etterfølgeren til hvert element.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Hvis denne funksjonen returnerte `impl Iterator<Item=T>`, kan den være basert på `unfold` og ikke trenger en dedikert type.
    //
    // Å ha en navngitt `Successors<T, F>`-type gjør det imidlertid mulig å være `Clone` når `T` og `F` er.
    Successors { next: first, succ }
}

/// En ny iterator der hver påfølgende vare blir beregnet basert på den forrige.
///
/// Denne `struct` er opprettet av [`iter::successors()`]-funksjonen.
/// Se dokumentasjonen for mer.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}