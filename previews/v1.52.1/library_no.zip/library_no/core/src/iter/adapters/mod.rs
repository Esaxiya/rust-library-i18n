use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Denne trait gir transitiv tilgang til kildestadiet i en interator-adapterrørledning under de forhold som
/// * iteratorkilden `S` implementerer selv `SourceIter<Source = S>`
/// * det er en delegerende implementering av denne trait for hver adapter i rørledningen mellom kilden og rørledningsforbrukeren.
///
/// Når kilden er en eier iterator-struktur (ofte kalt `IntoIter`), kan dette være nyttig for å spesialisere [`FromIterator`]-implementeringer eller gjenopprette de gjenværende elementene etter at en iterator er delvis oppbrukt.
///
///
/// Merk at implementeringer ikke nødvendigvis trenger å gi tilgang til den innerste kilden til en rørledning.En statelig mellomliggende adapter kan ivrig evaluere en del av rørledningen og avsløre den interne lagringen som kilde.
///
/// trait er usikre fordi implementatorer må opprettholde ytterligere sikkerhetsegenskaper.
/// Se [`as_inner`] for detaljer.
///
/// # Examples
///
/// Henter en delvis forbrukt kilde:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Et kildetrinn i en iteratorrørledning.
    type Source: Iterator;

    /// Hent kilden til en iteratorrørledning.
    ///
    /// # Safety
    ///
    /// Implementeringer av må returnere samme mutable referanse for hele livet, med mindre de erstattes av en innringer.
    /// Innringere kan bare erstatte referansen når de stoppet iterasjon og slipper iterator-rørledningen etter å ha hentet kilden.
    ///
    /// Dette betyr at iteratoradaptere kan stole på at kilden ikke endres under iterasjonen, men de kan ikke stole på den i Drop-implementeringene.
    ///
    /// Implementering av denne metoden betyr at adaptere gir avkall på privat tilgang til kilden og kan bare stole på garantier som er laget basert på metodene for mottaker.
    /// Mangelen på begrenset tilgang krever også at adaptere må opprettholde kildens offentlige API selv når de har tilgang til internt.
    ///
    /// Innringere må i sin tur forvente at kilden skal være i en hvilken som helst tilstand som er i samsvar med sin offentlige API, siden adaptere som sitter mellom den og kilden har samme tilgang.
    /// Spesielt kan en adapter ha brukt flere elementer enn strengt nødvendig.
    ///
    /// Det overordnede målet med disse kravene er å la forbrukeren av en rørledning bruke
    /// * hva som helst som er igjen i kilden etter at iterasjonen har stoppet
    /// * minnet som har blitt ubrukt ved å fremme en konsumerende iterator
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// En iteratoradapter som produserer utdata så lenge den underliggende iteratoren produserer `Result::Ok`-verdier.
///
///
/// Hvis det oppstår en feil, stopper iteratoren og feilen lagres.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Behandle den gitte iteratoren som om den ga en `T` i stedet for en `Result<T, _>`.
/// Eventuelle feil vil stoppe den indre iteratoren, og det totale resultatet vil være en feil.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}