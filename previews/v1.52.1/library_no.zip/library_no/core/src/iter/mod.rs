//! Komponerbar ekstern iterasjon.
//!
//! Hvis du har funnet deg selv med en samling av noe slag, og trenger å utføre en operasjon på elementene i samlingen, vil du raskt løpe inn i 'iterators'.
//! Iteratorer brukes mye i idiomatisk Rust-kode, så det er verdt å bli kjent med dem.
//!
//! Før vi forklarer mer, la oss snakke om hvordan denne modulen er strukturert:
//!
//! # Organization
//!
//! Denne modulen er i stor grad organisert etter type:
//!
//! * [Traits] er kjernepartiet: disse traits definerer hva slags iteratorer som finnes og hva du kan gjøre med dem.Metodene til disse traits er verdt å bruke litt ekstra studietid på.
//! * [Functions] gi noen nyttige måter å lage noen grunnleggende iteratorer på.
//! * [Structs] er ofte returtypene til de forskjellige metodene på denne modulens traits.Du vil vanligvis se på metoden som oppretter `struct`, i stedet for selve `struct`.
//! For mer detalj om hvorfor, se '[Implementing Iterator](#implementerings-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Det er det!La oss grave i iteratorer.
//!
//! # Iterator
//!
//! Hjertet og sjelen til denne modulen er [`Iterator`] trait.Kjernen til [`Iterator`] ser slik ut:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! En iterator har en metode, [`next`], som når den kalles, returnerer en [`Option`]`<Item>`.
//! [`next`] vil returnere [`Some(Item)`] så lenge det er elementer, og når de alle er oppbrukt, returnerer `None` for å indikere at iterasjonen er ferdig.
//! Individuelle iteratorer kan velge å gjenoppta iterasjon, og det kan hende at det å ringe [`next`] igjen kan begynne å returnere [`Some(Item)`] igjen på et eller annet tidspunkt (for eksempel se [`TryIter`]).
//!
//!
//! [Iterator`s full definisjon inneholder også en rekke andre metoder, men de er standardmetoder, bygget på toppen av [`next`], og så får du dem gratis.
//!
//! Iteratorer er også sammensettbare, og det er vanlig å kjede dem sammen for å gjøre mer komplekse former for prosessering.Se [Adapters](#adapters)-delen nedenfor for mer informasjon.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # De tre former for iterasjon
//!
//! Det er tre vanlige metoder som kan lage iteratorer fra en samling:
//!
//! * `iter()`, som gjentas over `&T`.
//! * `iter_mut()`, som gjentas over `&mut T`.
//! * `into_iter()`, som gjentas over `T`.
//!
//! Forskjellige ting i standardbiblioteket kan implementere en eller flere av de tre, der det er hensiktsmessig.
//!
//! # Implementering av Iterator
//!
//! Å lage en egen iterator innebærer to trinn: å lage en `struct` for å holde iteratorens tilstand, og deretter implementere [`Iterator`] for den `struct`.
//! Det er derfor det er så mange strukturer i denne modulen: det er en for hver iterator og iteratoradapter.
//!
//! La oss lage en iterator kalt `Counter` som teller fra `1` til `5`:
//!
//! ```
//! // Først strukturen:
//!
//! /// En iterator som teller fra en til fem
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vi vil at tellingen vår skal starte på en, så la oss legge til en new()-metode for å hjelpe.
//! // Dette er ikke strengt nødvendig, men er praktisk.
//! // Merk at vi starter `count` på null, vi får se hvorfor i `next()`'s implementering nedenfor.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Deretter implementerer vi `Iterator` for `Counter`:
//!
//! impl Iterator for Counter {
//!     // vi vil telle med størrelsen
//!     type Item = usize;
//!
//!     // next() er den eneste nødvendige metoden
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Øk antallet våre.Dette er grunnen til at vi startet på null.
//!         self.count += 1;
//!
//!         // Sjekk om vi er ferdig med å telle eller ikke.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Og nå kan vi bruke det!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Å ringe [`next`] på denne måten blir repeterende.Rust har en konstruksjon som kan ringe [`next`] på iteratoren din, til den når `None`.La oss gå over det neste.
//!
//! Vær også oppmerksom på at `Iterator` gir en standardimplementering av metoder som `nth` og `fold` som kaller `next` internt.
//! Det er imidlertid også mulig å skrive en tilpasset implementering av metoder som `nth` og `fold` hvis en iterator kan beregne dem mer effektivt uten å ringe `next`.
//!
//! # `for` sløyfer og `IntoIterator`
//!
//! Rust s syntaks `for`-loop er faktisk sukker for iteratorer.Her er et grunnleggende eksempel på `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Dette vil skrive ut tallene ett til fem, hver på sin egen linje.Men du vil legge merke til noe her: vi ringte aldri noe på vector for å produsere en iterator.Hva gir?
//!
//! Det er en trait i standardbiblioteket for å konvertere noe til en iterator: [`IntoIterator`].
//! Denne trait har en metode, [`into_iter`], som konverterer tingen som implementerer [`IntoIterator`] til en iterator.
//! La oss se på den `for`-sløyfen igjen, og hva kompilatoren konverterer den til:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sukker dette til:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Først kaller vi `into_iter()` for verdien.Deretter matcher vi på iteratoren som returnerer, og kaller [`next`] om og om igjen til vi ser en `None`.
//! På det tidspunktet `break` vi ut av løkken, og vi er ferdige iterating.
//!
//! Det er en mer subtil bit her: Standardbiblioteket inneholder en interessant implementering av [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Med andre ord, alle [`Iterator`] implementerer [`IntoIterator`], ved å bare returnere seg selv.Dette betyr to ting:
//!
//! 1. Hvis du skriver en [`Iterator`], kan du bruke den med en `for`-løkke.
//! 2. Hvis du oppretter en samling, vil implementeringen av [`IntoIterator`] for den tillate at samlingen din brukes med `for`-løkken.
//!
//! # Iterere ved referanse
//!
//! Siden [`into_iter()`] tar `self` etter verdi, forbruker den samlingen ved å bruke en `for`-løkke for å iterere over en samling.Ofte kan det være lurt å gjenta over en samling uten å konsumere den.
//! Mange samlinger tilbyr metoder som gir iteratorer over referanser, kalt henholdsvis `iter()` og `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` eies fortsatt av denne funksjonen.
//! ```
//!
//! Hvis en samlingstype `C` gir `iter()`, implementerer den vanligvis også `IntoIterator` for `&C`, med en implementering som bare kaller `iter()`.
//! På samme måte implementerer en samling `C` som gir `iter_mut()` generelt `IntoIterator` for `&mut C` ved å delegere til `iter_mut()`.Dette muliggjør en praktisk stenografi:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // samme som `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // samme som `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Mens mange samlinger tilbyr `iter()`, tilbyr ikke alle `iter_mut()`.
//! For eksempel kan mutering av nøklene til en [`HashSet<T>`] eller [`HashMap<K, V>`] sette samlingen i en inkonsekvent tilstand hvis nøkkelhashingen endres, så disse samlingene tilbyr bare `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funksjoner som tar en [`Iterator`] og returnerer en annen [`Iterator`] kalles ofte 'iterator-adaptere', da de er en form for 'adapteren
//! pattern'.
//!
//! Vanlige iteratoradaptere inkluderer [`map`], [`take`] og [`filter`].
//! For mer, se dokumentasjonen deres.
//!
//! Hvis en iteratoradapter panics, vil iteratoren være i en uspesifisert (men minnesikker) tilstand.
//! Denne tilstanden er heller ikke garantert å være den samme på tvers av versjoner av Rust, så du bør unngå å stole på de nøyaktige verdiene som returneres av en iterator som fikk panikk.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratorer (og iterator [adapters](#adapters)) er *late*. Dette betyr at bare å lage en iterator ikke _do_ veldig mye. Ingenting skjer egentlig før du ringer til [`next`].
//! Dette er noen ganger en kilde til forvirring når du oppretter en iterator kun for bivirkningene.
//! For eksempel kaller [`map`]-metoden en lukking for hvert element den gjentas over:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Dette vil ikke skrive ut noen verdier, ettersom vi bare opprettet en iterator, i stedet for å bruke den.Kompilatoren vil advare oss om denne typen oppførsel:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Den idiomatiske måten å skrive en [`map`] på for bivirkningene er å bruke en `for`-løkke eller ringe [`for_each`]-metoden:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! En annen vanlig måte å evaluere en iterator på er å bruke [`collect`]-metoden til å produsere en ny samling.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratorer trenger ikke å være endelige.Som et eksempel er et åpent område en uendelig iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Det er vanlig å bruke [`take`] iteratoradapteren for å gjøre en uendelig iterator til en endelig:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Dette vil skrive ut tallene `0` til `4`, hver på sin egen linje.
//!
//! Husk at metoder på uendelige iteratorer, selv de som et resultat kan bestemmes matematisk for på endelig tid, kanskje ikke avsluttes.
//! Spesielt vil metoder som [`min`], som generelt krever å krysse hvert element i iteratoren, sannsynligvis ikke returnere vellykket for noen uendelige iteratorer.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Å nei!En uendelig løkke!
//! // `ones.min()` forårsaker en uendelig løkke, så vi når ikke dette punktet!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;