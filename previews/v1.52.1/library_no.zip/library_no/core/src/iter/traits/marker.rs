/// En iterator som alltid fortsetter å gi `None` når den er utmattet.
///
/// Å ringe neste gang på en smeltet iterator som har returnert `None` en gang, er garantert å returnere [`None`] igjen.
/// Denne trait bør implementeres av alle iteratorer som oppfører seg på denne måten fordi den tillater optimalisering av [`Iterator::fuse()`].
///
///
/// Note: Generelt sett bør du ikke bruke `FusedIterator` i generiske grenser hvis du trenger en smeltet iterator.
/// I stedet bør du bare ringe [`Iterator::fuse()`] på iteratoren.
/// Hvis iteratoren allerede er smeltet, vil den ekstra [`Fuse`]-innpakningen være en no-op uten ytelsesstraff.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// En iterator som rapporterer en nøyaktig lengde ved hjelp av size_hint.
///
/// Iteratoren rapporterer et størrelseshint der det enten er nøyaktig (nedre grense er lik øvre grense), eller øvre grense er [`None`].
///
/// Den øvre grensen må bare være [`None`] hvis den faktiske iteratorlengden er større enn [`usize::MAX`].
/// I så fall må den nedre grensen være [`usize::MAX`], noe som resulterer i en [`Iterator::size_hint()`] på `(usize::MAX, None)`.
///
/// Iteratoren må produsere nøyaktig antall elementer den rapporterte eller avviker før den når slutten.
///
/// # Safety
///
/// Denne trait må bare implementeres når kontrakten opprettholdes.
/// Forbrukere av denne trait må inspisere [`Iterator::size_hint()`]’s øvre grense.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// En iterator som når du gir en vare vil ha tatt minst ett element fra den underliggende [`SourceIter`].
///
/// Kaller en hvilken som helst metode som fremmer iteratoren, f.eks
/// [`next()`] eller [`try_fold()`], garanterer at for hvert trinn er minst en verdi av iteratorens underliggende kilde flyttet ut, og resultatet av iteratorkjeden kan settes inn i stedet, forutsatt at strukturelle begrensninger for kilden tillater en slik innsetting.
///
/// Med andre ord indikerer denne trait at en iteratorrørledning kan samles på plass.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}