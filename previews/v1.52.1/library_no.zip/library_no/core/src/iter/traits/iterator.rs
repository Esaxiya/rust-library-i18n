// ignore-tidy-filelength Denne filen består nesten utelukkende av definisjonen av `Iterator`.
// Vi kan ikke dele det i flere filer.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Et grensesnitt for å håndtere iteratorer.
///
/// Dette er hovedteratoren trait.
/// For mer informasjon om konseptet med iteratorer generelt, se [module-level documentation].
/// Spesielt vil du kanskje vite hvordan du skal [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Typen av elementene som gjentas over.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Avanserer iteratoren og returnerer neste verdi.
    ///
    /// Returnerer [`None`] når iterasjonen er ferdig.
    /// Individuelle iteratorimplementeringer kan velge å gjenoppta iterasjon, og det å ringe `next()` igjen kan eller ikke kan begynne å returnere [`Some(Item)`] igjen på et tidspunkt.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Et anrop til next() returnerer neste verdi ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... og så ingen når det er over.
    /// assert_eq!(None, iter.next());
    ///
    /// // Flere anrop returnerer `None` eller ikke.Her vil de alltid gjøre det.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Returnerer grensene for gjenværende lengde på iteratoren.
    ///
    /// Spesielt returnerer `size_hint()` en tuple der det første elementet er den nedre grensen, og det andre elementet er den øvre grensen.
    ///
    /// Den andre halvdelen av tupelen som returneres er en [`Option`]`<`[`usize`] `>`.
    /// En [`None`] her betyr at enten det ikke er noen kjent øvre grense, eller at den øvre grensen er større enn [`usize`].
    ///
    /// # Implementeringsnotater
    ///
    /// Det håndheves ikke at en iteratorimplementering gir det deklarerte antall elementer.En buggy iterator kan gi mindre enn den nedre grensen eller mer enn den øvre grensen for elementer.
    ///
    /// `size_hint()` er primært ment å brukes til optimaliseringer som for eksempel å reservere plass til elementene i iteratoren, men må ikke stole på å for eksempel utelate grensekontroller i usikker kode.
    /// Feil implementering av `size_hint()` bør ikke føre til minnesikkerhetsbrudd.
    ///
    /// Når det er sagt, skal implementeringen gi et riktig estimat, fordi det ellers ville være et brudd på trait s protokoll.
    ///
    /// Standardimplementeringen returnerer `(0,` [`Ingen`]`)`som er riktig for enhver iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Et mer komplekst eksempel:
    ///
    /// ```
    /// // Partallene fra null til ti.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Vi kan komme til å gå fra null til ti ganger.
    /// // Å vite at det er fem er ikke mulig uten å utføre filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // La oss legge til fem tall til med chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // nå økes begge grensene med fem
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Returnerer `None` for en øvre grense:
    ///
    /// ```
    /// // en uendelig iterator har ingen øvre grenser og maksimalt mulig nedre grense
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Forbruker iteratoren, teller antall iterasjoner og returnerer den.
    ///
    /// Denne metoden vil kalle [`next`] gjentatte ganger til [`None`] oppstår, og returnerer antall ganger den så [`Some`].
    /// Merk at [`next`] må ringes minst en gang, selv om iteratoren ikke har noen elementer.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Overflow Atferd
    ///
    /// Metoden beskytter ikke mot overløp, så det å telle elementer i en iterator med mer enn [`usize::MAX`]-elementer gir enten feil resultat eller panics.
    ///
    /// Hvis feilsøking påstander er aktivert, er en panic garantert.
    ///
    /// # Panics
    ///
    /// Denne funksjonen kan panic hvis iteratoren har mer enn [`usize::MAX`]-elementer.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Forbruker iteratoren og returnerer det siste elementet.
    ///
    /// Denne metoden vil evaluere iteratoren til den returnerer [`None`].
    /// Mens du gjør det, holder den oversikt over gjeldende element.
    /// Etter at [`None`] er returnert, returnerer `last()` det siste elementet den så.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Fremmer iteratoren med `n`-elementer.
    ///
    /// Denne metoden vil ivrig hoppe over `n`-elementer ved å ringe [`next`] opptil `n` ganger til [`None`] oppstår.
    ///
    /// `advance_by(n)` vil returnere [`Ok(())`][Ok] hvis iteratoren lykkes med å avansere med `n`-elementer, eller [`Err(k)`][Err] hvis [`None`] oppstår, der `k` er antall elementer iteratoren avanseres før den går tom for elementer (dvs.
    /// lengden på iteratoren).
    /// Merk at `k` alltid er mindre enn `n`.
    ///
    /// Å ringe til `advance_by(0)` bruker ikke noen elementer og returnerer alltid [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // bare `&4` ble hoppet over
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Returnerer `n` elementet i iteratoren.
    ///
    /// Som de fleste indekseringsoperasjoner starter tellingen fra null, så `nth(0)` returnerer den første verdien, `nth(1)` den andre og så videre.
    ///
    /// Merk at alle de foregående elementene, så vel som det returnerte elementet, vil bli konsumert fra iteratoren.
    /// Det betyr at de foregående elementene vil bli forkastet, og at det å ringe `nth(0)` flere ganger på samme iterator vil returnere forskjellige elementer.
    ///
    ///
    /// `nth()` returnerer [`None`] hvis `n` er større enn eller lik lengden på iteratoren.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Å ringe `nth()` flere ganger spoler ikke iteratoren tilbake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Returnerer `None` hvis det er mindre enn `n + 1`-elementer:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Oppretter en iterator som starter på samme punkt, men går etter det gitte beløpet ved hver iterasjon.
    ///
    /// Merk 1: Det første elementet i iteratoren vil alltid bli returnert, uavhengig av trinn som er gitt.
    ///
    /// Merknad 2: Tidspunktet der ignorerte elementer trekkes er ikke fast.
    /// `StepBy` oppfører seg som sekvensen `next(), nth(step-1), nth(step-1),…`, men er også fri til å oppføre seg som sekvensen
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Hvilken måte som brukes kan endres for noen iteratorer av ytelsesgrunner.
    /// Den andre måten vil fremme iteratoren tidligere og kan konsumere flere gjenstander.
    ///
    /// `advance_n_and_return_first` tilsvarer:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metoden vil panic hvis det gitte trinnet er `0`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Tar to iteratorer og lager en ny iterator over begge i rekkefølge.
    ///
    /// `chain()` vil returnere en ny iterator som først itererer over verdier fra første iterator og deretter over verdier fra andre iterator.
    ///
    /// Med andre ord kobler den to iteratorer sammen, i en kjede.🔗
    ///
    /// [`once`] brukes ofte til å tilpasse en enkelt verdi til en kjede av andre typer iterasjon.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Siden argumentet til `chain()` bruker [`IntoIterator`], kan vi overføre alt som kan konverteres til en [`Iterator`], ikke bare en [`Iterator`] i seg selv.
    /// For eksempel kan skiver (`&[T]`) implementere [`IntoIterator`], og så kan de overføres til `chain()` direkte:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hvis du jobber med Windows API, kan det være lurt å konvertere [`OsStr`] til `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zipper opp' to iteratorer til en enkelt iterator av par.
    ///
    /// `zip()` returnerer en ny iterator som vil iterere over to andre iteratorer, og returnere en tuple der det første elementet kommer fra den første iteratoren, og det andre elementet kommer fra den andre iteratoren.
    ///
    ///
    /// Med andre ord glider den to iteratorer sammen, til en enkelt.
    ///
    /// Hvis en av iteratorene returnerer [`None`], returnerer [`next`] fra den zippede iteratoren [`None`].
    /// Hvis den første iteratoren returnerer [`None`], vil `zip` kortslutte og `next` vil ikke bli kalt på den andre iteratoren.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Siden argumentet til `zip()` bruker [`IntoIterator`], kan vi overføre alt som kan konverteres til en [`Iterator`], ikke bare en [`Iterator`] i seg selv.
    /// For eksempel kan skiver (`&[T]`) implementere [`IntoIterator`], og så kan de overføres til `zip()` direkte:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` brukes ofte til å zip en uendelig iterator til en endelig.
    /// Dette fungerer fordi den endelige iteratoren til slutt vil returnere [`None`] og avslutte glidelåsen.Zipping med `(0..)` kan se ut som [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Oppretter en ny iterator som plasserer en kopi av `separator` mellom tilstøtende gjenstander til den originale iteratoren.
    ///
    /// Hvis `separator` ikke implementerer [`Clone`] eller må beregnes hver gang, bruk [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Det første elementet fra `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separatoren.
    /// assert_eq!(a.next(), Some(&1));   // Det neste elementet fra `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separatoren.
    /// assert_eq!(a.next(), Some(&2));   // Det siste elementet fra `a`.
    /// assert_eq!(a.next(), None);       // Iteratoren er ferdig.
    /// ```
    ///
    /// `intersperse` kan være veldig nyttig å bli med i en iterators gjenstander ved hjelp av et vanlig element:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Oppretter en ny iterator som plasserer et element generert av `separator` mellom tilstøtende elementer i den opprinnelige iteratoren.
    ///
    /// Lukkingen vil bli kalt nøyaktig en gang hver gang en vare plasseres mellom to tilstøtende gjenstander fra den underliggende iteratoren;
    /// spesifikt kalles ikke nedleggelsen hvis den underliggende iteratoren gir mindre enn to varer og etter at den siste varen er gitt.
    ///
    ///
    /// Hvis iteratorens gjenstand implementerer [`Clone`], kan det være enklere å bruke [`intersperse`].
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Det første elementet fra `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separatoren.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Det neste elementet fra `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separatoren.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Det siste elementet fra `v`.
    /// assert_eq!(it.next(), None);               // Iteratoren er ferdig.
    /// ```
    ///
    /// `intersperse_with` kan brukes i situasjoner der separatoren må beregnes:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Avslutningen låner mutabelt konteksten for å generere en vare.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Tar en lukking og oppretter en iterator som kaller den lukkingen på hvert element.
    ///
    /// `map()` forvandler en iterator til en annen, ved hjelp av argumentet:
    /// noe som implementerer [`FnMut`].Den produserer en ny iterator som kaller denne lukkingen på hvert element i den opprinnelige iteratoren.
    ///
    /// Hvis du er god til å tenke i typer, kan du tenke på `map()` slik:
    /// Hvis du har en iterator som gir deg elementer av en eller annen type `A`, og du vil ha en iterator av en annen type `B`, kan du bruke `map()`, passere en lukking som tar en `A` og returnerer en `B`.
    ///
    ///
    /// `map()` er konseptuelt lik en [`for`]-løkke.Men da `map()` er lat, brukes den best når du allerede jobber med andre iteratorer.
    /// Hvis du gjør en slags looping for en bivirkning, anses det å være mer idiomatisk å bruke [`for`] enn `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hvis du gjør en slags bivirkning, foretrekker du [`for`] fremfor `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ikke gjør dette:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // det vil ikke engang kjøres, da det er lat.Rust vil advare deg om dette.
    ///
    /// // Bruk i stedet for:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Kaller en lukking på hvert element i en iterator.
    ///
    /// Dette tilsvarer å bruke en [`for`]-løkke på iteratoren, selv om `break` og `continue` ikke er mulig fra en lukking.
    /// Det er generelt mer idiomatisk å bruke en `for`-løkke, men `for_each` kan være mer leselig når man behandler varer på slutten av lengre iteratorkjeder.
    ///
    /// I noen tilfeller kan `for_each` også være raskere enn en sløyfe, fordi den vil bruke intern iterasjon på adaptere som `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// For et så lite eksempel kan en `for`-løkke være renere, men `for_each` kan være å foretrekke for å beholde en funksjonell stil med lengre iteratorer:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Oppretter en iterator som bruker en lukking for å avgjøre om et element skal gis.
    ///
    /// Gitt et element må lukkingen returnere `true` eller `false`.Den returnerte iteratoren gir bare elementene som lukkingen returnerer sant for.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Fordi nedleggelsen som sendes til `filter()` tar en referanse, og mange iteratorer gjentas over referanser, fører dette til en mulig forvirrende situasjon, der lukketypen er en dobbel referanse:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // trenger to * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Det er vanlig å i stedet bruke destrukturer på argumentet for å fjerne en:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // både&og *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// eller begge:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // to &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// av disse lagene.
    ///
    /// Merk at `iter.filter(f).next()` tilsvarer `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Oppretter en iterator som både filtrerer og kartlegger.
    ///
    /// Den returnerte iteratoren gir bare `` verdien '' som den medfølgende lukkingen returnerer `Some(value)` for.
    ///
    /// `filter_map` kan brukes til å gjøre kjeder av [`filter`] og [`map`] mer konsise.
    /// Eksemplet nedenfor viser hvordan en `map().filter().map()` kan forkortes til en enkelt samtale til `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Her er det samme eksemplet, men med [`filter`] og [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Oppretter en iterator som gir gjeldende iterasjonstall og neste verdi.
    ///
    /// Den returnerte iteratoren gir par `(i, val)`, der `i` er gjeldende indeks for iterasjon og `val` er verdien som returneres av iteratoren.
    ///
    ///
    /// `enumerate()` holder sin telling som en [`usize`].
    /// Hvis du vil telle med et helt tall i annen størrelse, gir [`zip`]-funksjonen lignende funksjonalitet.
    ///
    /// # Overflow Atferd
    ///
    /// Metoden beskytter ikke mot overløp, så å oppregne mer enn [`usize::MAX`]-elementer gir enten feil resultat eller panics.
    /// Hvis feilsøking påstander er aktivert, er en panic garantert.
    ///
    /// # Panics
    ///
    /// Den returnerte iteratoren kan panic hvis den som skal returneres indeksen vil flyte over en [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Oppretter en iterator som kan bruke [`peek`] til å se på neste element i iteratoren uten å konsumere den.
    ///
    /// Legger til en [`peek`]-metode til en iterator.Se dokumentasjonen for mer informasjon.
    ///
    /// Merk at den underliggende iteratoren fremdeles er avansert når [`peek`] kalles for første gang: For å hente neste element kalles [`next`] på den underliggende iteratoren, derav eventuelle bivirkninger (dvs.
    ///
    /// noe annet enn å hente neste verdi) av [`next`]-metoden vil forekomme.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() lar oss se inn i future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // vi kan peek() flere ganger, iteratoren vil ikke gå videre
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // etter at iteratoren er ferdig, er det også peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Oppretter en iterator som [`hopper over '] elementer basert på et predikat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` tar en nedleggelse som argument.Det vil kalle denne lukkingen på hvert element i iteratoren, og ignorere elementene til den returnerer `false`.
    ///
    /// Etter at `false` er returnert, er `skip_while()`'s-jobben over, og resten av elementene blir gitt.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Fordi nedleggelsen overført til `skip_while()` tar en referanse, og mange iteratorer gjentas over referanser, fører dette til en mulig forvirrende situasjon, der typen lukkingsargument er en dobbel referanse:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // trenger to * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopper etter en første `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // mens dette ville ha vært falskt, siden vi allerede har fått en falsk, brukes ikke skip_while() lenger
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Oppretter en iterator som gir elementer basert på et predikat.
    ///
    /// `take_while()` tar en nedleggelse som argument.Det vil kalle denne lukkingen på hvert element i iteratoren, og gi elementer mens den returnerer `true`.
    ///
    /// Etter at `false` er returnert, er `take_while()`'s-jobben over, og resten av elementene blir ignorert.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Fordi nedleggelsen som sendes til `take_while()` tar en referanse, og mange iteratorer gjentas over referanser, fører dette til en mulig forvirrende situasjon, der lukketypen er en dobbel referanse:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // trenger to * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopper etter en første `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Vi har flere elementer som er mindre enn null, men siden vi allerede har en falsk, brukes ikke take_while() mer
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Fordi `take_while()` må se på verdien for å se om den skal være inkludert eller ikke, vil forbrukende iteratorer se at den er fjernet:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` er ikke lenger der, fordi den ble fortært for å se om iterasjonen skulle stoppe, men ikke ble plassert tilbake i iteratoren.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Oppretter en iterator som både gir elementer basert på et predikat og kart.
    ///
    /// `map_while()` tar en nedleggelse som argument.
    /// Det vil kalle denne lukkingen på hvert element i iteratoren, og gi elementer mens den returnerer [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Her er det samme eksemplet, men med [`take_while`] og [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopper etter en første [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Vi har flere elementer som kan passe inn i u32 (4, 5), men `map_while` returnerte `None` for `-3` (når `predicate` returnerte `None`) og `collect` stopper ved den første `None` som ble oppdaget.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Fordi `map_while()` må se på verdien for å se om den skal være inkludert eller ikke, vil forbrukende iteratorer se at den er fjernet:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` er ikke lenger der, fordi den ble fortært for å se om iterasjonen skulle stoppe, men ikke ble plassert tilbake i iteratoren.
    ///
    /// Merk at i motsetning til [`take_while`] er denne iteratoren **ikke** smeltet sammen.
    /// Det er heller ikke spesifisert hva denne iteratoren returnerer etter at den første [`None`] er returnert.
    /// Hvis du trenger smeltet iterator, bruk [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Oppretter en iterator som hopper over de første `n`-elementene.
    ///
    /// Etter at de er fortært, blir resten av elementene gitt.
    /// I stedet for å overstyre denne metoden direkte, i stedet overstyr `nth`-metoden.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Oppretter en iterator som gir sine første `n`-elementer.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` brukes ofte med en uendelig iterator for å gjøre den endelig:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hvis mindre enn `n`-elementer er tilgjengelige, vil `take` begrense seg til størrelsen på den underliggende iteratoren:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// En iteratoradapter som ligner på [`fold`] som holder intern tilstand og produserer en ny iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` tar to argumenter: en startverdi som frøer den interne tilstanden, og en lukking med to argumenter, den første er en foranderlig referanse til den interne tilstanden og den andre et iteratorelement.
    ///
    /// Avslutningen kan tilordnes den interne tilstanden for å dele tilstanden mellom iterasjonene.
    ///
    /// Ved iterasjon vil lukkingen påføres hvert element i iteratoren, og returverdien fra lukkingen, en [`Option`], blir gitt av iteratoren.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // hver iterasjon multipliserer vi tilstanden med elementet
    ///     *state = *state * x;
    ///
    ///     // da vil vi gi negasjonen av staten
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Oppretter en iterator som fungerer som kart, men flater nestet struktur.
    ///
    /// [`map`]-adapteren er veldig nyttig, men bare når lukkingsargumentet gir verdier.
    /// Hvis det i stedet produserer en iterator, er det et ekstra lag med indireksjon.
    /// `flat_map()` fjerner dette ekstra laget på egenhånd.
    ///
    /// Du kan tenke på `flat_map(f)` som den semantiske ekvivalenten til [`map`] ping, og deretter [`flate`] ing som i `map(f).flatten()`.
    ///
    /// En annen måte å tenke på `flat_map()`: [`map`] lukking returnerer ett element for hvert element, og `flat_map()`'s lukking returnerer en iterator for hvert element.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnerer en iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Oppretter en iterator som flater nestet struktur.
    ///
    /// Dette er nyttig når du har en iterator av iteratorer eller en iterator av ting som kan gjøres om til iteratorer, og du vil fjerne ett nivå av indireksjon.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kartlegging og deretter utflating:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnerer en iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Du kan også omskrive dette i form av [`flat_map()`], som er å foretrekke i dette tilfellet, siden det formidler klarere hensikter:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnerer en iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flating fjerner bare ett nivå av hekking om gangen:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Her ser vi at `flatten()` ikke utfører en "deep"-flatning.
    /// I stedet fjernes bare ett nivå av hekking.Det vil si at hvis du `flatten()` en tredimensjonal matrise, blir resultatet todimensjonalt og ikke endimensjonalt.
    /// For å få en endimensjonal struktur, må du `flatten()` igjen.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Oppretter en iterator som slutter etter den første [`None`].
    ///
    /// Etter at en iterator har returnert [`None`], kan future-samtaler gi [`Some(T)`] eller ikke.
    /// `fuse()` tilpasser en iterator, og sørger for at etter at en [`None`] er gitt, vil den alltid returnere [`None`] for alltid.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // en iterator som veksler mellom noen og ingen
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // hvis det er jevnt, Some(i32), ellers Ingen
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // vi kan se iteratoren vår gå frem og tilbake
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // når vi først smelter sammen ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // den vil alltid returnere `None` etter første gang.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Gjør noe med hvert element i en iterator, og sender verdien videre.
    ///
    /// Når du bruker iteratorer, vil du ofte koble flere av dem sammen.
    /// Mens du jobber med en slik kode, vil du kanskje sjekke ut hva som skjer på forskjellige deler i rørledningen.For å gjøre det, legg inn et anrop til `inspect()`.
    ///
    /// Det er mer vanlig at `inspect()` brukes som feilsøkingsverktøy enn i den endelige koden, men applikasjoner kan finne det nyttig i visse situasjoner når feil må logges før de kastes.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // denne iteratorsekvensen er kompleks.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // la oss legge til noen inspect()-samtaler for å undersøke hva som skjer
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Dette vil skrive ut:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Loggfeil før du forkaster dem:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Dette vil skrive ut:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Låner en iterator, i stedet for å konsumere den.
    ///
    /// Dette er nyttig for å tillate bruk av iteratoradaptere mens du fortsatt beholder eierskapet til den originale iteratoren.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // hvis vi prøver å bruke iter igjen, vil det ikke fungere.
    /// // Følgende linje gir "feil: bruk av flyttet verdi: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // la oss prøve det igjen
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // i stedet legger vi til en .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // nå er dette bare bra:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Forvandler en iterator til en samling.
    ///
    /// `collect()` kan ta hva som helst iterable, og gjøre det til en relevant samling.
    /// Dette er en av de kraftigere metodene i standardbiblioteket, brukt i en rekke sammenhenger.
    ///
    /// Det mest grunnleggende mønsteret der `collect()` brukes er å gjøre en samling om til en annen.
    /// Du tar en samling, kaller [`iter`] på den, gjør en haug med transformasjoner, og deretter `collect()` på slutten.
    ///
    /// `collect()` kan også opprette forekomster av typer som ikke er typiske samlinger.
    /// For eksempel kan en [`String`] bygges fra [`char`] s, og en iterator av [`Result<T, E>`][`Result`]-elementer kan samles inn i `Result<Collection<T>, E>`.
    ///
    /// Se eksemplene nedenfor for mer.
    ///
    /// Fordi `collect()` er så generell, kan det føre til problemer med typeinferanse.
    /// Som sådan er `collect()` en av de få gangene du ser syntaksen kjærlig kjent som 'turbofish': `::<>`.
    /// Dette hjelper slutningsalgoritmen med å forstå spesifikt hvilken samling du prøver å samle inn i.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Merk at vi trengte `: Vec<i32>` på venstre side.Dette er fordi vi kunne samle inn for eksempel en [`VecDeque<T>`] i stedet:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Bruke 'turbofish' i stedet for å kommentere `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Fordi `collect()` bare bryr seg om det du samler inn i, kan du fremdeles bruke et delvis hint, `_`, med turbofisken:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Bruke `collect()` til å lage en [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Hvis du har en liste over [`Resultat<T, E>`][`Resultat`] s, du kan bruke `collect()` for å se om noen av dem mislyktes:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gir oss den første feilen
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gir oss listen over svar
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Konsumerer en iterator og lager to samlinger fra den.
    ///
    /// Predikatet som sendes til `partition()` kan returnere `true` eller `false`.
    /// `partition()` returnerer et par, alle elementene det returnerte `true` for, og alle elementene som det returnerte `false` for.
    ///
    ///
    /// Se også [`is_partitioned()`] og [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Omorganiserer elementene i denne iteratoren *på plass* i henhold til gitt predikat, slik at alle de som returnerer `true` går foran alle de som returnerer `false`.
    ///
    /// Returnerer antall funnet `true`-elementer.
    ///
    /// Den relative rekkefølgen på partisjonerte gjenstander opprettholdes ikke.
    ///
    /// Se også [`is_partitioned()`] og [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partisjon på plass mellom jevnheter og odds
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: skal vi bekymre oss for at tellingen renner over?Den eneste måten å ha mer enn
        // `usize::MAX` mutable referanser er med ZST-er, som ikke er nyttige for partisjonering ...

        // Disse "factory"-funksjonene lukkes for å unngå generisitet i `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Finn den første `false` gjentatte ganger og bytt den med den siste `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Sjekker om elementene i denne iteratoren er partisjonert i henhold til det gitte predikatet, slik at alle de som returnerer `true` går foran alle de som returnerer `false`.
    ///
    ///
    /// Se også [`partition()`] og [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Enten tester alle elementene `true`, eller den første paragrafen stopper ved `false`, og vi sjekker at det ikke er flere `true`-poster etter det.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// En iteratormetode som bruker en funksjon så lenge den returnerer, og produserer en enkelt, endelig verdi.
    ///
    /// `try_fold()` tar to argumenter: en startverdi og en lukking med to argumenter: en 'accumulator' og et element.
    /// Avslutningen returnerer enten vellykket, med verdien som akkumulatoren skal ha for neste iterasjon, eller den returnerer feil, med en feilverdi som forplantes tilbake til den som ringer umiddelbart (short-circuiting).
    ///
    ///
    /// Den opprinnelige verdien er verdien akkumulatoren vil ha ved første samtale.Hvis påføring av lukkingen lykkes mot hvert element i iteratoren, returnerer `try_fold()` den endelige akkumulatoren som suksess.
    ///
    /// Bretting er nyttig når du har en samling av noe, og ønsker å produsere en enkelt verdi av det.
    ///
    /// # Merknad til implementatorer
    ///
    /// Flere av de andre (forward)-metodene har standardimplementeringer når det gjelder denne, så prøv å implementere dette eksplisitt hvis det kan gjøre noe bedre enn standard `for`-loopimplementering.
    ///
    /// Spesielt prøv å ha denne samtalen `try_fold()` på de interne delene som denne iteratoren er sammensatt av.
    /// Hvis det er behov for flere samtaler, kan `?`-operatøren være praktisk for å koble akkumulatorverdien sammen, men vær oppmerksom på eventuelle invarianter som må opprettholdes før de kommer tilbake.
    /// Dette er en `&mut self`-metode, så iterasjonen må kunne gjenopptas etter at du har truffet en feil her.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // den sjekkede summen av alle elementene i matrisen
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Denne summen flyter over når du legger til 100-elementet
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Fordi den kortsluttet, er de gjenværende elementene fremdeles tilgjengelige gjennom iteratoren.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// En iteratormetode som bruker en feilbar funksjon for hvert element i iteratoren, stopper ved den første feilen og returnerer den feilen.
    ///
    ///
    /// Dette kan også betraktes som feilbar form av [`for_each()`] eller som den statsløse versjonen av [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Det kortsluttet, så gjenværende gjenstander er fortsatt i iteratoren:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Bretter hvert element i en akkumulator ved å utføre en operasjon, og returnere det endelige resultatet.
    ///
    /// `fold()` tar to argumenter: en startverdi og en lukking med to argumenter: en 'accumulator' og et element.
    /// Avslutningen returnerer verdien som akkumulatoren skal ha for neste iterasjon.
    ///
    /// Den opprinnelige verdien er verdien akkumulatoren vil ha ved første samtale.
    ///
    /// Etter at denne lukkingen er brukt på hvert element i iteratoren, returnerer `fold()` akkumulatoren.
    ///
    /// Denne operasjonen kalles noen ganger 'reduce' eller 'inject'.
    ///
    /// Bretting er nyttig når du har en samling av noe, og ønsker å produsere en enkelt verdi av det.
    ///
    /// Note: `fold()`, og lignende metoder som krysser hele iteratoren, slutter kanskje ikke for uendelige iteratorer, selv ikke på traits som resultatet kan bestemmes på endelig tid.
    ///
    /// Note: [`reduce()`] kan brukes til å bruke det første elementet som startverdi, hvis akkumulatortypen og varetypen er den samme.
    ///
    /// # Merknad til implementatorer
    ///
    /// Flere av de andre (forward)-metodene har standardimplementeringer når det gjelder denne, så prøv å implementere dette eksplisitt hvis det kan gjøre noe bedre enn standard `for`-loopimplementering.
    ///
    ///
    /// Spesielt prøv å ha denne samtalen `fold()` på de interne delene som denne iteratoren er sammensatt av.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // summen av alle elementene i matrisen
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// La oss gå gjennom hvert trinn i iterasjonen her:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Og så, vårt endelige resultat, `6`.
    ///
    /// Det er vanlig at folk som ikke har brukt iteratorer mye, bruker en `for`-løkke med en liste over ting for å bygge opp et resultat.Disse kan gjøres om til `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // for løkke:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // de er de samme
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reduserer elementene til en enkelt, ved å bruke gjentatte ganger en reduserende operasjon.
    ///
    /// Hvis iteratoren er tom, returnerer [`None`];Ellers returnerer resultatet av reduksjonen.
    ///
    /// For iteratorer med minst ett element er dette det samme som [`fold()`] med det første elementet i iteratoren som den opprinnelige verdien, og bretter hvert påfølgende element inn i det.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Finn maksimumsverdien:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Tester om hvert element i iteratoren samsvarer med et predikat.
    ///
    /// `all()` tar en nedleggelse som returnerer `true` eller `false`.Den bruker denne lukkingen på hvert element i iteratoren, og hvis de alle returnerer `true`, så gjør `all()` det også.
    /// Hvis noen av dem returnerer `false`, returnerer den `false`.
    ///
    /// `all()` er kortslutning;med andre ord, den vil slutte å behandle så snart den finner en `false`, gitt at uansett hva annet som skjer, blir resultatet også `false`.
    ///
    ///
    /// En tom iterator returnerer `true`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Stopper ved første `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // vi kan fortsatt bruke `iter`, ettersom det er flere elementer.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tester om noe element i iteratoren samsvarer med et predikat.
    ///
    /// `any()` tar en nedleggelse som returnerer `true` eller `false`.Den bruker denne lukkingen på hvert element i iteratoren, og hvis noen av dem returnerer `true`, så gjør `any()` det også.
    /// Hvis de alle returnerer `false`, returnerer den `false`.
    ///
    /// `any()` er kortslutning;med andre ord, den vil slutte å behandle så snart den finner en `true`, gitt at uansett hva annet som skjer, blir resultatet også `true`.
    ///
    ///
    /// En tom iterator returnerer `false`.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Stopper ved første `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // vi kan fortsatt bruke `iter`, ettersom det er flere elementer.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Søker etter et element i en iterator som tilfredsstiller et predikat.
    ///
    /// `find()` tar en nedleggelse som returnerer `true` eller `false`.
    /// Den bruker denne lukkingen på hvert element i iteratoren, og hvis noen av dem returnerer `true`, returnerer `find()` [`Some(element)`].
    /// Hvis de alle returnerer `false`, returnerer den [`None`].
    ///
    /// `find()` er kortslutning;det vil med andre ord slutte å behandle så snart nedleggelsen returnerer `true`.
    ///
    /// Fordi `find()` tar en referanse, og mange iteratorer itererer over referanser, fører dette til en mulig forvirrende situasjon der argumentet er en dobbel referanse.
    ///
    /// Du kan se denne effekten i eksemplene nedenfor, med `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Stopper ved første `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // vi kan fortsatt bruke `iter`, ettersom det er flere elementer.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Merk at `iter.find(f)` tilsvarer `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Gjelder funksjon på elementene i iterator og returnerer det første ikke-ingen-resultatet.
    ///
    ///
    /// `iter.find_map(f)` tilsvarer `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Gjelder funksjon på elementene i iterator og returnerer det første sanne resultatet eller den første feilen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Søker etter et element i en iterator og returnerer indeksen.
    ///
    /// `position()` tar en nedleggelse som returnerer `true` eller `false`.
    /// Den bruker denne lukkingen på hvert element i iteratoren, og hvis en av dem returnerer `true`, returnerer `position()` [`Some(index)`].
    /// Hvis alle returnerer `false`, returnerer den [`None`].
    ///
    /// `position()` er kortslutning;med andre ord, den vil stoppe behandlingen så snart den finner en `true`.
    ///
    /// # Overflow Atferd
    ///
    /// Metoden beskytter ikke mot overløp, så hvis det er mer enn [`usize::MAX`] ikke-samsvarende elementer, gir den enten feil resultat eller panics.
    ///
    /// Hvis feilsøking påstander er aktivert, er en panic garantert.
    ///
    /// # Panics
    ///
    /// Denne funksjonen kan panic hvis iteratoren har mer enn `usize::MAX` elementer som ikke samsvarer.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Stopper ved første `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // vi kan fortsatt bruke `iter`, ettersom det er flere elementer.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Den returnerte indeksen avhenger av iteratorstatus
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Søker etter et element i en iterator fra høyre, og returnerer indeksen.
    ///
    /// `rposition()` tar en nedleggelse som returnerer `true` eller `false`.
    /// Den bruker denne lukkingen på hvert element i iteratoren, fra slutten, og hvis en av dem returnerer `true`, returnerer `rposition()` [`Some(index)`].
    ///
    /// Hvis alle returnerer `false`, returnerer den [`None`].
    ///
    /// `rposition()` er kortslutning;med andre ord, den vil stoppe behandlingen så snart den finner en `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Stopper ved første `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // vi kan fortsatt bruke `iter`, ettersom det er flere elementer.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Ingen behov for en overløpssjekk her, fordi `ExactSizeIterator` innebærer at antall elementer passer inn i en `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Returnerer det maksimale elementet til en iterator.
    ///
    /// Hvis flere elementer er like maksimale, returneres det siste elementet.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Returnerer minimumselementet til en iterator.
    ///
    /// Hvis flere elementer er like minimale, returneres det første elementet.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Returnerer elementet som gir maksimumsverdien fra den angitte funksjonen.
    ///
    ///
    /// Hvis flere elementer er like maksimale, returneres det siste elementet.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Returnerer elementet som gir maksimal verdi med hensyn til den spesifiserte sammenligningsfunksjonen.
    ///
    ///
    /// Hvis flere elementer er like maksimale, returneres det siste elementet.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Returnerer elementet som gir minimumsverdien fra den angitte funksjonen.
    ///
    ///
    /// Hvis flere elementer er like minimale, returneres det første elementet.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Returnerer elementet som gir minimumsverdien med hensyn til den spesifiserte sammenligningsfunksjonen.
    ///
    ///
    /// Hvis flere elementer er like minimale, returneres det første elementet.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Vender en iterators retning.
    ///
    /// Vanligvis gjentar iteratorer fra venstre til høyre.
    /// Etter bruk av `rev()`, vil en iterator i stedet itere fra høyre til venstre.
    ///
    /// Dette er bare mulig hvis iteratoren har en slutt, så `rev()` fungerer bare på [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Konverterer en iterator av par til et par containere.
    ///
    /// `unzip()` bruker en hel iterator av par, og produserer to samlinger: en fra venstre element av parene, og en fra de rette elementene.
    ///
    ///
    /// Denne funksjonen er på en eller annen måte motsatt av [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Oppretter en iterator som kopierer alle elementene.
    ///
    /// Dette er nyttig når du har en iterator over `&T`, men du trenger en iterator over `T`.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopiert er det samme som .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Oppretter en iterator som ["kloner"] alle elementene.
    ///
    /// Dette er nyttig når du har en iterator over `&T`, men du trenger en iterator over `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonet er det samme som .map(|&x| x), for heltall
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Gjentar en iterator uendelig.
    ///
    /// I stedet for å stoppe ved [`None`], vil iteratoren i stedet starte på nytt, fra begynnelsen.Etter å ha iterert igjen, vil den starte i begynnelsen igjen.Og igjen.
    /// Og igjen.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Oppsummerer elementene til en iterator.
    ///
    /// Tar hvert element, legger dem sammen og returnerer resultatet.
    ///
    /// En tom iterator returnerer nullverdien av typen.
    ///
    /// # Panics
    ///
    /// Når du ringer til `sum()` og en primitiv heltallstype returneres, vil denne metoden panic hvis beregningen renner over og feilsøking påstander er aktivert.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Itererer over hele iteratoren og multipliserer alle elementene
    ///
    /// En tom iterator returnerer den ene verdien av typen.
    ///
    /// # Panics
    ///
    /// Når du ringer til `product()` og en primitiv heltalstype blir returnert, vil metoden panic hvis beregningen flyter over og feilsøking påstander er aktivert.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) sammenligner elementene i denne [`Iterator`] med elementene i en annen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) sammenligner elementene i denne [`Iterator`] med elementene til en annen med hensyn til den spesifiserte sammenligningsfunksjonen.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) sammenligner elementene i denne [`Iterator`] med elementene i en annen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) sammenligner elementene i denne [`Iterator`] med elementene til en annen med hensyn til den spesifiserte sammenligningsfunksjonen.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Bestemmer om elementene i denne [`Iterator`] er lik de andre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Bestemmer om elementene i denne [`Iterator`] er lik de andres med hensyn til den spesifiserte likhetsfunksjonen.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Bestemmer om elementene i denne [`Iterator`] er ulik de andre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Bestemmer om elementene til denne [`Iterator`] er [lexicographically](Ord#lexicographical-comparison) mindre enn for en annen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Bestemmer om elementene i denne [`Iterator`] er [lexicographically](Ord#lexicographical-comparison) mindre eller lik dem til en annen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Bestemmer om elementene til denne [`Iterator`] er [lexicographically](Ord#lexicographical-comparison) større enn for en annen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Bestemmer om elementene i denne [`Iterator`] er [lexicographically](Ord#lexicographical-comparison) større enn eller lik dem til en annen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Sjekker om elementene i denne iteratoren er sortert.
    ///
    /// Det vil si at for hvert element `a` og dets følgende element `b`, må `a <= b` holde.Hvis iteratoren gir nøyaktig null eller ett element, returneres `true`.
    ///
    /// Merk at hvis `Self::Item` bare er `PartialOrd`, men ikke `Ord`, innebærer definisjonen ovenfor at denne funksjonen returnerer `false` hvis to påfølgende elementer ikke er sammenlignbare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Sjekker om elementene i denne iteratoren er sortert ved hjelp av den gitte komparatorfunksjonen.
    ///
    /// I stedet for å bruke `PartialOrd::partial_cmp`, bruker denne funksjonen den gitte `compare`-funksjonen til å bestemme rekkefølgen av to elementer.
    /// Bortsett fra det tilsvarer det [`is_sorted`];se dokumentasjonen for mer informasjon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Sjekker om elementene i denne iteratoren er sortert ved hjelp av den gitte nøkkelutvinningsfunksjonen.
    ///
    /// I stedet for å sammenligne iteratorelementene direkte, sammenligner denne funksjonen nøklene til elementene, som bestemt av `f`.
    /// Bortsett fra det tilsvarer det [`is_sorted`];se dokumentasjonen for mer informasjon.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Se [TrustedRandomAccess]
    // Det uvanlige navnet er å unngå navnekollisjoner i metodeoppløsningen, se #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}