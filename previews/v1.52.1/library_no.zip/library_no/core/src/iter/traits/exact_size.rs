/// En iterator som vet nøyaktig lengde.
///
/// Mange [`Iterator`] vet ikke hvor mange ganger de vil gjenta, men noen gjør det.
/// Hvis en iterator vet hvor mange ganger den kan iterere, kan det være nyttig å gi tilgang til den informasjonen.
/// Hvis du for eksempel vil gjenta bakover, er en god start å vite hvor slutten er.
///
/// Når du implementerer en `ExactSizeIterator`, må du også implementere [`Iterator`].
/// Når du gjør det, må implementeringen av [`Iterator::size_hint`] * returnere den eksakte størrelsen på iteratoren.
///
/// [`len`]-metoden har en standardimplementering, så du bør vanligvis ikke implementere den.
/// Imidlertid kan det hende du kan gi en mer performant implementering enn standard, så det er fornuftig å overstyre det i dette tilfellet.
///
///
/// Merk at denne trait er en sikker trait og som sådan *ikke* og *ikke* kan garantere at den returnerte lengden er riktig.
/// Dette betyr at `unsafe`-koden **ikke må** stole på riktigheten av [`Iterator::size_hint`].
/// Den ustabile og usikre [`TrustedLen`](super::marker::TrustedLen) trait gir denne tilleggsgarantien.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// // et begrenset utvalg vet nøyaktig hvor mange ganger det vil gjenta
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// I [module-level docs] implementerte vi en [`Iterator`], `Counter`.
/// La oss implementere `ExactSizeIterator` for det også:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Vi kan enkelt beregne det gjenværende antall iterasjoner.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Og nå kan vi bruke det!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Returnerer den eksakte lengden på iteratoren.
    ///
    /// Implementeringen sikrer at iteratoren vil returnere nøyaktig `len()` flere ganger en [`Some(T)`]-verdi før den returnerer [`None`].
    ///
    /// Denne metoden har en standardimplementering, så du bør vanligvis ikke implementere den direkte.
    /// Men hvis du kan tilby en mer effektiv implementering, kan du gjøre det.
    /// Se [trait-level]-dokumentene for et eksempel.
    ///
    /// Denne funksjonen har de samme sikkerhetsgarantiene som [`Iterator::size_hint`]-funksjonen.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // et begrenset utvalg vet nøyaktig hvor mange ganger det vil gjenta
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Denne påstanden er altfor defensiv, men den sjekker invarianten
        // garantert av trait.
        // Hvis denne trait var rust-intern, kunne vi bruke debug_assert !;assert_eq!vil sjekke alle Rust brukerimplementeringer også.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Returnerer `true` hvis iteratoren er tom.
    ///
    /// Denne metoden har en standardimplementering ved bruk av [`ExactSizeIterator::len()`], så du trenger ikke å implementere den selv.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}