use crate::ops::{ControlFlow, Try};

/// En iterator som kan gi elementer fra begge ender.
///
/// Noe som implementerer `DoubleEndedIterator` har en ekstra evne i forhold til noe som implementerer [`Iterator`]: muligheten til å også ta `Item`s fra baksiden, så vel som fra fronten.
///
///
/// Det er viktig å merke seg at både frem og tilbake fungerer på samme område, og ikke krysser: iterasjon er over når de møtes i midten.
///
/// På en lignende måte som [`Iterator`]-protokollen, når en `DoubleEndedIterator` returnerer [`None`] fra en [`next_back()`], kan du ringe den til [`Some`] igjen.
/// [`next()`] og [`next_back()`] er utskiftbare for dette formålet.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Fjerner og returnerer et element fra slutten av iteratoren.
    ///
    /// Returnerer `None` når det ikke er flere elementer.
    ///
    /// [trait-level]-dokumentene inneholder flere detaljer.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Elementene gitt av `DoubleEndedIterator`s metoder kan avvike fra de som er gitt av [`Iterator`] metoder:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Fremfører iteratoren fra baksiden med `n`-elementer.
    ///
    /// `advance_back_by` er den omvendte versjonen av [`advance_by`].Denne metoden vil ivrig hoppe over `n`-elementer som starter fra baksiden ved å ringe [`next_back`] opp til `n` ganger til [`None`] oppstår.
    ///
    /// `advance_back_by(n)` vil returnere [`Ok(())`] hvis iteratoren lykkes med å avansere med `n`-elementer, eller [`Err(k)`] hvis [`None`] oppstår, der `k` er antall elementer iteratoren avanseres før den går tom for elementer (dvs.
    /// lengden på iteratoren).
    /// Merk at `k` alltid er mindre enn `n`.
    ///
    /// Å ringe til `advance_back_by(0)` bruker ikke noen elementer og returnerer alltid [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // bare `&3` ble hoppet over
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Returnerer `n` element fra slutten av iteratoren.
    ///
    /// Dette er egentlig den omvendte versjonen av [`Iterator::nth()`].
    /// Selv om antallet, som de fleste indekseringsoperasjoner, starter fra null, returnerer `nth_back(0)` den første verdien fra slutten, `nth_back(1)` den andre og så videre.
    ///
    ///
    /// Merk at alle elementene mellom slutten og det returnerte elementet vil bli fortært, inkludert det returnerte elementet.
    /// Dette betyr også at å ringe `nth_back(0)` flere ganger på samme iterator, vil returnere forskjellige elementer.
    ///
    /// `nth_back()` returnerer [`None`] hvis `n` er større enn eller lik lengden på iteratoren.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Å ringe `nth_back()` flere ganger spoler ikke iteratoren tilbake:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Returnerer `None` hvis det er mindre enn `n + 1`-elementer:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Dette er den omvendte versjonen av [`Iterator::try_fold()`]: det tar elementer som starter fra baksiden av iteratoren.
    ///
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Fordi den kortsluttet, er de gjenværende elementene fremdeles tilgjengelige gjennom iteratoren.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// En iteratormetode som reduserer iteratorens elementer til en enkelt, endelig verdi, fra baksiden.
    ///
    /// Dette er den omvendte versjonen av [`Iterator::fold()`]: det tar elementer som starter fra baksiden av iteratoren.
    ///
    /// `rfold()` tar to argumenter: en startverdi og en lukking med to argumenter: en 'accumulator' og et element.
    /// Avslutningen returnerer verdien som akkumulatoren skal ha for neste iterasjon.
    ///
    /// Den opprinnelige verdien er verdien akkumulatoren vil ha ved første samtale.
    ///
    /// Etter at denne lukkingen er brukt på hvert element i iteratoren, returnerer `rfold()` akkumulatoren.
    ///
    /// Denne operasjonen kalles noen ganger 'reduce' eller 'inject'.
    ///
    /// Bretting er nyttig når du har en samling av noe, og ønsker å produsere en enkelt verdi av det.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // summen av alle elementene i a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Dette eksemplet bygger en streng som begynner med en innledende verdi og fortsetter med hvert element fra baksiden til forsiden:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Søker etter et element av en iterator bakfra som tilfredsstiller et predikat.
    ///
    /// `rfind()` tar en nedleggelse som returnerer `true` eller `false`.
    /// Den bruker denne lukkingen på hvert element i iteratoren, fra slutten, og hvis noen av dem returnerer `true`, returnerer `rfind()` [`Some(element)`].
    /// Hvis de alle returnerer `false`, returnerer den [`None`].
    ///
    /// `rfind()` er kortslutning;det vil med andre ord slutte å behandle så snart nedleggelsen returnerer `true`.
    ///
    /// Fordi `rfind()` tar en referanse, og mange iteratorer itererer over referanser, fører dette til en mulig forvirrende situasjon der argumentet er en dobbel referanse.
    ///
    /// Du kan se denne effekten i eksemplene nedenfor, med `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Stopper ved første `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // vi kan fortsatt bruke `iter`, ettersom det er flere elementer.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}