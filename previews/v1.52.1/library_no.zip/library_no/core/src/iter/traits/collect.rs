/// Konvertering fra en [`Iterator`].
///
/// Ved å implementere `FromIterator` for en type, definerer du hvordan den skal opprettes fra en iterator.
/// Dette er vanlig for typer som beskriver en samling av noe slag.
///
/// [`FromIterator::from_iter()`] kalles sjelden eksplisitt, og brukes i stedet gjennom [`Iterator::collect()`]-metoden.
///
/// Se [`Iterator::collect()`]'s-dokumentasjon for flere eksempler.
///
/// Se også: [`IntoIterator`].
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Bruke [`Iterator::collect()`] til implisitt å bruke `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementering av `FromIterator` for din type:
///
/// ```
/// use std::iter::FromIterator;
///
/// // En prøvesamling, det er bare en innpakning over Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // La oss gi det noen metoder slik at vi kan lage en og legge ting til den.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // og vi implementerer FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nå kan vi lage en ny iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... og lag en MyCollection av den
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // samle verk også!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Skaper en verdi fra en iterator.
    ///
    /// Se [module-level documentation] for mer informasjon.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konvertering til en [`Iterator`].
///
/// Ved å implementere `IntoIterator` for en type, definerer du hvordan den skal konverteres til en iterator.
/// Dette er vanlig for typer som beskriver en samling av noe slag.
///
/// En fordel med å implementere `IntoIterator` er at typen din vil [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Se også: [`FromIterator`].
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementering av `IntoIterator` for din type:
///
/// ```
/// // En prøvesamling, det er bare en innpakning over Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // La oss gi det noen metoder slik at vi kan lage en og legge ting til den.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // og vi implementerer IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nå kan vi lage en ny samling ...
/// let mut c = MyCollection::new();
///
/// // ... legg til noen ting i den ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... og gjør det deretter til en Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Det er vanlig å bruke `IntoIterator` som en trait bound.Dette gjør at innsamlingstypen kan endres, så lenge den fremdeles er en iterator.
/// Ytterligere grenser kan spesifiseres ved å begrense
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Typen av elementene som gjentas over.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Hvilken type iterator gjør vi om til dette?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Oppretter en iterator fra en verdi.
    ///
    /// Se [module-level documentation] for mer informasjon.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Utvid en samling med innholdet i en iterator.
///
/// Iteratorer produserer en rekke verdier, og samlinger kan også betraktes som en serie verdier.
/// `Extend` trait bygger bro over dette gapet, slik at du kan utvide en samling ved å inkludere innholdet i den iteratoren.
/// Når du utvider en samling med en allerede eksisterende nøkkel, oppdateres den oppføringen, eller i tilfelle samlinger som tillater flere oppføringer med like nøkler, blir den oppføringen satt inn.
///
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// // Du kan utvide en streng med noen tegn:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementering av `Extend`:
///
/// ```
/// // En prøvesamling, det er bare en innpakning over Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // La oss gi det noen metoder slik at vi kan lage en og legge ting til den.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // siden MyCollection har en liste over i32, implementerer vi Extend for i32
/// impl Extend<i32> for MyCollection {
///
///     // Dette er litt enklere med betongtypesignaturen: vi kan ringe utvide alt som kan gjøres om til en Iterator som gir oss i32-er.
///     // Fordi vi trenger i32-er for å sette inn i MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Implementeringen er veldig grei: gå gjennom iteratoren, og add() hvert element for oss selv.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // la oss utvide samlingen vår med tre nummer til
/// c.extend(vec![1, 2, 3]);
///
/// // vi har lagt til disse elementene på slutten
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Utvider en samling med innholdet i en iterator.
    ///
    /// Siden dette er den eneste nødvendige metoden for denne trait, inneholder [trait-level]-dokumentene flere detaljer.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // Du kan utvide en streng med noen tegn:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Utvider en samling med nøyaktig ett element.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserverer kapasitet i en samling for det gitte antallet tilleggselementer.
    ///
    /// Standardimplementeringen gjør ingenting.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}