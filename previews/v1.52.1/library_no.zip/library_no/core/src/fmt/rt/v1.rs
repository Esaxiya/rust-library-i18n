//! Dette er en intern modul som brukes av ifmt!kjøretid.Disse strukturene sendes ut til statiske matriser for å forhåndskompilere strenger på forhånd.
//!
//! Disse definisjonene ligner på `ct`-ekvivalenter, men skiller seg ut ved at disse kan tildeles statisk og er litt optimalisert for kjøretiden
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Mulige justeringer som kan bestilles som en del av et formateringsdirektiv.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indikasjon om at innholdet skal være venstrejustert.
    Left,
    /// Indikasjon om at innholdet skal være rettjustert.
    Right,
    /// Indikasjon om at innholdet skal være midtjustert.
    Center,
    /// Ingen justering ble bedt om.
    Unknown,
}

/// Brukt av [width](https://doc.rust-lang.org/std/fmt/#width)-og [precision](https://doc.rust-lang.org/std/fmt/#precision)-spesifikatorer.
#[derive(Copy, Clone)]
pub enum Count {
    /// Spesifisert med et bokstavelig tall, lagrer verdien
    Is(usize),
    /// Spesifisert ved bruk av `$` og `*` syntakser, lagrer indeksen i `args`
    Param(usize),
    /// Ikke spesifisert
    Implied,
}