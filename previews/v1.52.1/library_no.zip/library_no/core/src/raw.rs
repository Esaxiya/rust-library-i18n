#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Inneholder strukturdefinisjoner for utformingen av kompilatorens innebygde typer.
//!
//! De kan brukes som mål for transmuterer i usikker kode for å manipulere de rå representasjonene direkte.
//!
//!
//! Definisjonen deres skal alltid stemme overens med ABI definert i `rustc_middle::ty::layout`.
//!

/// Representasjonen av et trait-objekt som `&dyn SomeTrait`.
///
/// Denne strukturen har samme oppsett som typer som `&dyn SomeTrait` og `Box<dyn AnotherTrait>`.
///
/// `TraitObject` er garantert å matche oppsett, men det er ikke typen trait-objekter (f.eks. er feltene ikke direkte tilgjengelige på en `&dyn SomeTrait`) og styrer heller ikke det oppsettet (endring av definisjonen vil ikke endre oppsettet til en `&dyn SomeTrait`).
///
/// Den er bare designet for å brukes av usikker kode som trenger å manipulere detaljer på lavt nivå.
///
/// Det er ingen måte å referere til alle trait-objekter generelt, så den eneste måten å skape verdier av denne typen er med funksjoner som [`std::mem::transmute`][transmute].
/// På samme måte er den eneste måten å lage et ekte trait-objekt fra en `TraitObject`-verdi med `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Syntese av et trait-objekt med uoverensstemmende typer-en der vtabellen ikke tilsvarer verdien av verdien som datapekeren peker på-vil sannsynligvis føre til udefinert oppførsel.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // et eksempel trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // la kompilatoren lage et trait-objekt
/// let object: &dyn Foo = &value;
///
/// // se på den rå representasjonen
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // datapekeren er adressen til `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // konstruer et nytt objekt, pek på en annen `i32`, vær forsiktig med å bruke `i32`-tabellen fra `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // det skulle fungere akkurat som om vi hadde konstruert et trait-objekt direkte fra `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}