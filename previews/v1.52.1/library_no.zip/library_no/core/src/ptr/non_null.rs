use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` men ikke-null og kovariant.
///
/// Dette er ofte den riktige tingen å bruke når man bygger datastrukturer ved hjelp av rå pekere, men er til slutt farligere å bruke på grunn av tilleggsegenskapene.Hvis du ikke er sikker på om du skal bruke `NonNull<T>`, er det bare å bruke `*mut T`!
///
/// I motsetning til `*mut T`, må pekeren alltid være null, selv om pekeren aldri blir referert til.Dette er slik at enums kan bruke denne forbudte verdien som en diskriminant-`Option<NonNull<T>>` har samme størrelse som `* mut T`.
/// Men pekeren kan fortsatt dingle hvis den ikke blir referert til.
///
/// I motsetning til `*mut T` ble `NonNull<T>` valgt til å være kovariant fremfor `T`.Dette gjør det mulig å bruke `NonNull<T>` når du bygger kovariant-typer, men introduserer risikoen for usunnhet hvis den brukes i en type som egentlig ikke burde være kovariant.
/// (Det motsatte valget ble tatt for `*mut T`, selv om teknisk ulyd bare kunne kalles usikre funksjoner.)
///
/// Kovarians er riktig for de fleste sikre abstraksjoner, for eksempel `Box`, `Rc`, `Arc`, `Vec` og `LinkedList`.Dette er tilfelle fordi de tilbyr en offentlig API som følger de vanlige delte XOR-mutable reglene til Rust.
///
/// Hvis typen ikke trygt kan være kovariant, må du sørge for at den inneholder et ekstra felt for å gi variasjon.Ofte vil dette feltet være en [`PhantomData`]-type som `PhantomData<Cell<T>>` eller `PhantomData<&'a mut T>`.
///
/// Legg merke til at `NonNull<T>` har en `From`-forekomst for `&T`.Dette endrer imidlertid ikke det faktum at mutering gjennom en (peker avledet fra en) delt referanse er udefinert oppførsel med mindre mutasjonen skjer inne i en [`UnsafeCell<T>`].Det samme gjelder for å lage en foranderlig referanse fra en delt referanse.
///
/// Når du bruker denne `From`-forekomsten uten en `UnsafeCell<T>`, er det ditt ansvar å sikre at `as_mut` aldri blir ringt, og `as_ptr` blir aldri brukt til mutasjon.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pekere er ikke `Send` fordi dataene de refererer til, kan være alias.
// NB, dette impl. Er unødvendig, men burde gi bedre feilmeldinger.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pekere er ikke `Sync` fordi dataene de refererer til, kan være alias.
// NB, dette impl. Er unødvendig, men burde gi bedre feilmeldinger.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Oppretter en ny `NonNull` som er dinglende, men godt justert.
    ///
    /// Dette er nyttig for initialisering av typer som lat tildeles, slik `Vec::new` gjør.
    ///
    /// Merk at pekerverdien potensielt kan representere en gyldig peker til en `T`, noe som betyr at denne ikke må brukes som en "not yet initialized" sentinelverdi.
    /// Typer som lat tildeles, må spore initialisering på annen måte.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SIKKERHET: mem::align_of() returnerer en størrelse som ikke er null, som deretter kastes
        // til en * mut T.
        // Derfor er `ptr` ikke null, og vilkårene for å ringe new_unchecked() blir respektert.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Returnerer en delt referanse til verdien.I motsetning til [`as_ref`] krever dette ikke at verdien må initialiseres.
    ///
    /// For den mutable motparten, se [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Når du kaller denne metoden, må du forsikre deg om at alt av dette stemmer:
    ///
    /// * Pekeren må være riktig justert.
    ///
    /// * Det må være "dereferencable" i den forstand som er definert i [the module documentation].
    ///
    /// * Du må håndheve Rust s aliaseringsregler, siden den returnerte levetiden `'a` er vilkårlig valgt og ikke nødvendigvis gjenspeiler den faktiske levetiden til dataene.
    ///
    ///   Spesielt, i løpet av denne levetiden, må ikke minnet pekeren peker på bli mutert (unntatt inne i `UnsafeCell`).
    ///
    /// Dette gjelder selv om resultatet av denne metoden er ubrukt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SIKKERHET: innringeren må garantere at `self` oppfyller alle
        // krav til referanse.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Returnerer unike referanser til verdien.I motsetning til [`as_mut`] krever dette ikke at verdien må initialiseres.
    ///
    /// For den delte motparten, se [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Når du kaller denne metoden, må du forsikre deg om at alt av dette stemmer:
    ///
    /// * Pekeren må være riktig justert.
    ///
    /// * Det må være "dereferencable" i den forstand som er definert i [the module documentation].
    ///
    /// * Du må håndheve Rust s aliaseringsregler, siden den returnerte levetiden `'a` er vilkårlig valgt og ikke nødvendigvis gjenspeiler den faktiske levetiden til dataene.
    ///
    ///   Spesielt i løpet av denne levetiden, må ikke minnet pekeren peker på få tilgang til (lest eller skrevet) gjennom noen annen peker.
    ///
    /// Dette gjelder selv om resultatet av denne metoden er ubrukt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SIKKERHET: innringeren må garantere at `self` oppfyller alle
        // krav til referanse.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Oppretter en ny `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` må være ikke-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIKKERHET: innringeren må garantere at `ptr` ikke er null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Oppretter en ny `NonNull` hvis `ptr` ikke er null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIKKERHET: Pekeren er allerede sjekket og er ikke null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Utfører samme funksjonalitet som [`std::ptr::from_raw_parts`], bortsett fra at en `NonNull`-peker returneres, i motsetning til en rå `*const`-peker.
    ///
    ///
    /// Se dokumentasjonen til [`std::ptr::from_raw_parts`] for mer informasjon.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SIKKERHET: Resultatet av `ptr::from::raw_parts_mut` er ikke null fordi `data_address` er.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Nedbryt en (muligens bred) peker til er adresse-og metadatakomponenter.
    ///
    /// Pekeren kan senere rekonstrueres med [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Anskaffer den underliggende `*mut`-pekeren.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Returnerer en delt referanse til verdien.Hvis verdien kan være ikke-initialisert, må [`as_uninit_ref`] brukes i stedet.
    ///
    /// For den mutable motparten, se [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Når du kaller denne metoden, må du forsikre deg om at alt av dette stemmer:
    ///
    /// * Pekeren må være riktig justert.
    ///
    /// * Det må være "dereferencable" i den forstand som er definert i [the module documentation].
    ///
    /// * Pekeren må peke på en initialisert forekomst av `T`.
    ///
    /// * Du må håndheve Rust s aliaseringsregler, siden den returnerte levetiden `'a` er vilkårlig valgt og ikke nødvendigvis gjenspeiler den faktiske levetiden til dataene.
    ///
    ///   Spesielt, i løpet av denne levetiden, må ikke minnet pekeren peker på bli mutert (unntatt inne i `UnsafeCell`).
    ///
    /// Dette gjelder selv om resultatet av denne metoden er ubrukt!
    /// (Delen om å bli initialisert er ennå ikke helt bestemt, men inntil det er den eneste sikre tilnærmingen er å sikre at de virkelig blir initialisert.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIKKERHET: innringeren må garantere at `self` oppfyller alle
        // krav til referanse.
        unsafe { &*self.as_ptr() }
    }

    /// Returnerer en unik referanse til verdien.Hvis verdien kan være ikke-initialisert, må [`as_uninit_mut`] brukes i stedet.
    ///
    /// For den delte motparten, se [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Når du kaller denne metoden, må du forsikre deg om at alt av dette stemmer:
    ///
    /// * Pekeren må være riktig justert.
    ///
    /// * Det må være "dereferencable" i den forstand som er definert i [the module documentation].
    ///
    /// * Pekeren må peke på en initialisert forekomst av `T`.
    ///
    /// * Du må håndheve Rust s aliaseringsregler, siden den returnerte levetiden `'a` er vilkårlig valgt og ikke nødvendigvis gjenspeiler den faktiske levetiden til dataene.
    ///
    ///   Spesielt i løpet av denne levetiden, må ikke minnet pekeren peker på få tilgang til (lest eller skrevet) gjennom noen annen peker.
    ///
    /// Dette gjelder selv om resultatet av denne metoden er ubrukt!
    /// (Delen om å bli initialisert er ennå ikke helt bestemt, men inntil det er den eneste sikre tilnærmingen er å sikre at de virkelig blir initialisert.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIKKERHET: innringeren må garantere at `self` oppfyller alle
        // krav til en mutbar referanse.
        unsafe { &mut *self.as_ptr() }
    }

    /// Kaster til en peker av en annen type.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SIKKERHET: `self` er en `NonNull`-peker som nødvendigvis ikke er null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Oppretter et ikke-null råskive fra en tynn peker og en lengde.
    ///
    /// `len`-argumentet er antall **elementer**, ikke antall byte.
    ///
    /// Denne funksjonen er trygg, men å referere returverdien er usikker.
    /// Se dokumentasjonen til [`slice::from_raw_parts`] for sikkerhetskrav til skiver.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // lag en snittpeker når du starter med en peker til det første elementet
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Merk at dette eksemplet kunstig demonstrerer bruken av denne metoden, men `la skive= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SIKKERHET: `data` er en `NonNull`-peker som nødvendigvis ikke er null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Returnerer lengden på et ikke-null råskive.
    ///
    /// Den returnerte verdien er antall **elementer**, ikke antall byte.
    ///
    /// Denne funksjonen er trygg, selv når ikke-null råstykket ikke kan henvises til et stykke fordi pekeren ikke har en gyldig adresse.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Returnerer en ikke-null peker til stykkets buffer.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SIKKERHET: Vi vet at `self` ikke er null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Returnerer en rå peker til stykkets buffer.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Returnerer en delt referanse til et stykke muligens ikke-initialiserte verdier.I motsetning til [`as_ref`] krever dette ikke at verdien må initialiseres.
    ///
    /// For den mutable motparten, se [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Når du kaller denne metoden, må du forsikre deg om at alt av dette stemmer:
    ///
    /// * Pekeren må være [valid] for å lese for `ptr.len() * mem::size_of::<T>()` mange byte, og den må være riktig justert.Dette betyr spesielt:
    ///
    ///     * Hele minneområdet for denne delen må være inneholdt i et enkelt tildelt objekt!
    ///       Skiver kan aldri spenne over flere tildelte objekter.
    ///
    ///     * Pekeren må være justert selv for skiver uten lengde.
    ///     En grunn til dette er at optimalisering av enum-layout kan stole på at referanser (inkludert skiver av hvilken som helst lengde) blir justert og ikke-null for å skille dem fra andre data.
    ///
    ///     Du kan skaffe deg en peker som kan brukes som `data` for skiver uten lengde ved hjelp av [`NonNull::dangling()`].
    ///
    /// * Den totale størrelsen `ptr.len() * mem::size_of::<T>()` på stykket må ikke være større enn `isize::MAX`.
    ///   Se sikkerhetsdokumentasjonen til [`pointer::offset`].
    ///
    /// * Du må håndheve Rust s aliaseringsregler, siden den returnerte levetiden `'a` er vilkårlig valgt og ikke nødvendigvis gjenspeiler den faktiske levetiden til dataene.
    ///   Spesielt, i løpet av denne levetiden, må ikke minnet pekeren peker på bli mutert (unntatt inne i `UnsafeCell`).
    ///
    /// Dette gjelder selv om resultatet av denne metoden er ubrukt!
    ///
    /// Se også [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Returnerer en unik referanse til et stykke muligens ikke-initialiserte verdier.I motsetning til [`as_mut`] krever dette ikke at verdien må initialiseres.
    ///
    /// For den delte motparten, se [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Når du kaller denne metoden, må du forsikre deg om at alt av dette stemmer:
    ///
    /// * Pekeren må være [valid] for å lese og skrive for `ptr.len() * mem::size_of::<T>()` mange byte, og den må være riktig justert.Dette betyr spesielt:
    ///
    ///     * Hele minneområdet for denne delen må være inneholdt i et enkelt tildelt objekt!
    ///       Skiver kan aldri spenne over flere tildelte objekter.
    ///
    ///     * Pekeren må være justert selv for skiver uten lengde.
    ///     En grunn til dette er at optimalisering av enum-layout kan stole på at referanser (inkludert skiver av hvilken som helst lengde) blir justert og ikke-null for å skille dem fra andre data.
    ///
    ///     Du kan skaffe deg en peker som kan brukes som `data` for skiver uten lengde ved hjelp av [`NonNull::dangling()`].
    ///
    /// * Den totale størrelsen `ptr.len() * mem::size_of::<T>()` på stykket må ikke være større enn `isize::MAX`.
    ///   Se sikkerhetsdokumentasjonen til [`pointer::offset`].
    ///
    /// * Du må håndheve Rust s aliaseringsregler, siden den returnerte levetiden `'a` er vilkårlig valgt og ikke nødvendigvis gjenspeiler den faktiske levetiden til dataene.
    ///   Spesielt i løpet av denne levetiden, må ikke minnet pekeren peker på få tilgang til (lest eller skrevet) gjennom noen annen peker.
    ///
    /// Dette gjelder selv om resultatet av denne metoden er ubrukt!
    ///
    /// Se også [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Dette er trygt da `memory` er gyldig for lesing og skriving for `memory.len()` mange byte.
    /// // Vær oppmerksom på at det ikke er tillatt å ringe `memory.as_mut()` her, da innholdet kan være uinitialisert.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Returnerer en rå peker til et element eller underdel, uten å gjøre grensekontroll.
    ///
    /// Å kalle denne metoden med en indeks utenfor grensene eller når `self` ikke kan avvises, er *[udefinert oppførsel]* selv om den resulterende pekeren ikke brukes.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SIKKERHET: innringeren sørger for at `self` kan avleses og `index` er innenfor rammen.
        // Som en konsekvens kan ikke den resulterende pekeren være NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SIKKERHET: En unik peker kan ikke være null, så betingelsene for
        // new_unchecked() blir respektert.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIKKERHET: En foranderlig referanse kan ikke være null.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SIKKERHET: En referanse kan ikke være null, så vilkårene for
        // new_unchecked() blir respektert.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}