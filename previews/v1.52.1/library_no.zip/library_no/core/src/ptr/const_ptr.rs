use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Returnerer `true` hvis pekeren er null.
    ///
    /// Merk at usorterte typer har mange mulige nullpekere, da bare rådatapekeren blir vurdert, ikke lengden, vtabelen osv.
    /// Derfor kan to pekere som er null, fremdeles ikke sammenlignes like med hverandre.
    ///
    /// ## Atferd under const evaluering
    ///
    /// Når denne funksjonen brukes under const-evaluering, kan den returnere `false` for pekere som viser seg å være null ved kjøretid.
    /// Spesielt når en peker til noe minne blir forskjøvet utenfor grensene på en slik måte at den resulterende pekeren er null, vil funksjonen fremdeles returnere `false`.
    ///
    /// Det er ingen måte for CTFE å vite den absolutte posisjonen til det minnet, så vi kan ikke fortelle om pekeren er null eller ikke.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Sammenlign via en rollebesetning med en tynn peker, så fettpekere vurderer bare deres "data"-del for nullhet.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Kaster til en peker av en annen type.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Nedbryt en (muligens bred) peker til er adresse-og metadatakomponenter.
    ///
    /// Pekeren kan senere rekonstrueres med [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Returnerer `None` hvis pekeren er null, eller ellers returnerer en delt referanse til verdien pakket inn i `Some`.Hvis verdien kan være ikke-initialisert, må [`as_uninit_ref`] brukes i stedet.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Når du kaller denne metoden, må du sørge for at *enten* pekeren er NULL *eller* at alt av dette stemmer:
    ///
    /// * Pekeren må være riktig justert.
    ///
    /// * Det må være "dereferencable" i den forstand som er definert i [the module documentation].
    ///
    /// * Pekeren må peke på en initialisert forekomst av `T`.
    ///
    /// * Du må håndheve Rust s aliaseringsregler, siden den returnerte levetiden `'a` er vilkårlig valgt og ikke nødvendigvis gjenspeiler den faktiske levetiden til dataene.
    ///   Spesielt, i løpet av denne levetiden, må ikke minnet pekeren peker på bli mutert (unntatt inne i `UnsafeCell`).
    ///
    /// Dette gjelder selv om resultatet av denne metoden er ubrukt!
    /// (Delen om å bli initialisert er ennå ikke helt bestemt, men inntil det er den eneste sikre tilnærmingen er å sikre at de virkelig blir initialisert.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null-ukontrollert versjon
    ///
    /// Hvis du er sikker på at pekeren aldri kan være null og leter etter en slags `as_ref_unchecked` som returnerer `&T` i stedet for `Option<&T>`, vet du at du kan henvise pekeren direkte.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SIKKERHET: innringeren må garantere at `self` er gyldig
        // for en referanse hvis den ikke er null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Returnerer `None` hvis pekeren er null, eller ellers returnerer en delt referanse til verdien pakket inn i `Some`.
    /// I motsetning til [`as_ref`] krever dette ikke at verdien må initialiseres.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Når du kaller denne metoden, må du sørge for at *enten* pekeren er NULL *eller* at alt av dette stemmer:
    ///
    /// * Pekeren må være riktig justert.
    ///
    /// * Det må være "dereferencable" i den forstand som er definert i [the module documentation].
    ///
    /// * Du må håndheve Rust s aliaseringsregler, siden den returnerte levetiden `'a` er vilkårlig valgt og ikke nødvendigvis gjenspeiler den faktiske levetiden til dataene.
    ///
    ///   Spesielt, i løpet av denne levetiden, må ikke minnet pekeren peker på bli mutert (unntatt inne i `UnsafeCell`).
    ///
    /// Dette gjelder selv om resultatet av denne metoden er ubrukt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SIKKERHET: innringeren må garantere at `self` oppfyller alle
        // krav til referanse.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Beregner forskyvningen fra en peker.
    ///
    /// `count` er i enheter av T;for eksempel representerer en `count` på 3 en pekerforskyvning av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Hvis noen av følgende betingelser er brutt, er resultatet udefinert oppførsel:
    ///
    /// * Både startpekeren og den resulterende pekeren må være enten i rammer eller en byte forbi slutten av det samme tildelte objektet.
    /// Merk at i Rust blir hver (stack-allocated)-variabel ansett som et separat tildelt objekt.
    ///
    /// * Den beregnede forskyvningen,**i byte**, kan ikke flyte over en `isize`.
    ///
    /// * Forskyvningen som er innenfor grensene kan ikke stole på at "wrapping around" adresseområdet.Det vil si at den uendelige presisjonssummen,**i byte**, må passe i en størrelse.
    ///
    /// Kompilatoren og standardbiblioteket prøver vanligvis å sikre at tildelinger aldri når en størrelse der en forskyvning er en bekymring.
    /// For eksempel sørger `Vec` og `Box` for at de aldri tildeler mer enn `isize::MAX` byte, så `vec.as_ptr().add(vec.len())` er alltid trygt.
    ///
    /// De fleste plattformer kan ikke engang konstruere en slik tildeling.
    /// For eksempel kan ingen kjent 64-biters plattform noensinne tjene en forespørsel om 2 <sup>63</sup> byte på grunn av sidetabellbegrensninger eller splitting av adresseplassen.
    /// Imidlertid kan noen 32-biters og 16-biters plattformer vellykket servere en forespørsel om mer enn `isize::MAX`-byte med ting som fysisk adresseutvidelse.
    ///
    /// Som sådan kan minne hentet direkte fra tildelere eller minnekartede filer * være for stort til å håndtere denne funksjonen.
    ///
    /// Vurder å bruke [`wrapping_offset`] i stedet hvis disse begrensningene er vanskelige å oppfylle.
    /// Den eneste fordelen med denne metoden er at den muliggjør mer aggressive kompilatoroptimaliseringer.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Beregner forskyvningen fra en peker ved hjelp av innpakningsaritmetikk.
    ///
    /// `count` er i enheter av T;for eksempel representerer en `count` på 3 en pekerforskyvning av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Selve denne operasjonen er alltid trygg, men det er ikke bruk av den resulterende pekeren.
    ///
    /// Den resulterende pekeren forblir festet til det samme tildelte objektet som `self` peker på.
    /// Det kan *ikke* brukes til å få tilgang til et annet tildelt objekt.Merk at i Rust blir hver (stack-allocated)-variabel ansett som et separat tildelt objekt.
    ///
    /// Med andre ord gjør `let z = x.wrapping_offset((y as isize) - (x as isize))`*ikke*`z` det samme som `y`, selv om vi antar at `T` har størrelse `1` og det ikke er noe overløp: `z` er fortsatt festet til objektet `x` er festet til, og dereferanse det er udefinert oppførsel med mindre `x` og `y` peker inn i det samme tildelte objektet.
    ///
    /// Sammenlignet med [`offset`] forsinker denne metoden i utgangspunktet kravet om å holde seg innenfor det samme tildelte objektet: [`offset`] er umiddelbar udefinert oppførsel når du krysser objektgrenser;`wrapping_offset` produserer en peker, men fører fremdeles til udefinert atferd hvis en peker blir referert når den er utenfor grensene for objektet den er festet til.
    /// [`offset`] kan optimaliseres bedre og er dermed å foretrekke i ytelsessensitiv kode.
    ///
    /// Den forsinkede kontrollen tar bare hensyn til verdien til pekeren som ble henvist til, ikke de mellomverdiene som ble brukt under beregningen av det endelige resultatet.
    /// For eksempel er `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` alltid det samme som `x`.Det er med andre ord tillatt å forlate det tildelte objektet og deretter gå inn på nytt senere.
    ///
    /// Hvis du trenger å krysse objektgrenser, kan du kaste pekeren til et heltall og gjøre regningen der.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // Iterer ved å bruke en rå peker i trinn på to elementer
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Denne sløyfen skriver ut "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIKKERHET: `arith_offset` har ingen forutsetninger for å kunne kalles.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Beregner avstanden mellom to pekere.Den returnerte verdien er i enheter av T: avstanden i byte er delt med `mem::size_of::<T>()`.
    ///
    /// Denne funksjonen er den omvendte av [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Hvis noen av følgende betingelser er brutt, er resultatet udefinert oppførsel:
    ///
    /// * Både startpekeren og den andre pekeren må være enten i rammer eller en byte forbi slutten av det samme tildelte objektet.
    /// Merk at i Rust blir hver (stack-allocated)-variabel ansett som et separat tildelt objekt.
    ///
    /// * Begge pekerne må være *avledet fra* en peker til det samme objektet.
    ///   (Se nedenfor for et eksempel.)
    ///
    /// * Avstanden mellom pekerne, i byte, må være et nøyaktig multiplum av størrelsen på `T`.
    ///
    /// * Avstanden mellom pekerne,**i byte**, kan ikke overløpe en `isize`.
    ///
    /// * Avstanden i grensene kan ikke stole på "wrapping around" adresseområdet.
    ///
    /// Rust-typene er aldri større enn `isize::MAX` og Rust-tildelinger brytes aldri rundt adresseplassen, så to pekere innenfor en verdi av en hvilken som helst Rust-type `T` vil alltid tilfredsstille de to siste betingelsene.
    ///
    /// Standardbiblioteket sørger også generelt for at tildelinger aldri når en størrelse der en forskyvning er en bekymring.
    /// For eksempel sørger `Vec` og `Box` for at de aldri tildeler mer enn `isize::MAX` byte, så `ptr_into_vec.offset_from(vec.as_ptr())` tilfredsstiller alltid de to siste betingelsene.
    ///
    /// De fleste plattformer kan ikke engang konstruere en så stor tildeling.
    /// For eksempel kan ingen kjent 64-biters plattform noensinne tjene en forespørsel om 2 <sup>63</sup> byte på grunn av sidetabellbegrensninger eller splitting av adresseplassen.
    /// Imidlertid kan noen 32-biters og 16-biters plattformer vellykket servere en forespørsel om mer enn `isize::MAX`-byte med ting som fysisk adresseutvidelse.
    /// Som sådan kan minne hentet direkte fra tildelere eller minnekartede filer * være for stort til å håndtere denne funksjonen.
    /// (Merk at [`offset`] og [`add`] også har en lignende begrensning og derfor ikke kan brukes på så store tildelinger heller.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Denne funksjonen panics hvis `T` er en nullstørrelse type ("ZST").
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Feil* bruk:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Gjør ptr2_other til en "alias" av ptr2, men avledet av ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Siden ptr2_other og ptr2 er avledet fra pekere til forskjellige objekter, er beregning av deres forskyvning udefinert oppførsel, selv om de peker på samme adresse!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Udefinert oppførsel
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Returnerer om to pekere garantert er like.
    ///
    /// Ved kjøretid oppfører denne funksjonen seg som `self == other`.
    /// I noen sammenhenger (f.eks. Kompileringstidevaluering) er det imidlertid ikke alltid mulig å bestemme likhet mellom to pekere, så denne funksjonen kan falskt returnere `false` for pekere som senere faktisk viser seg å være like.
    ///
    /// Men når den returnerer `true`, er pekepinnene garantert like.
    ///
    /// Denne funksjonen er speilet til [`guaranteed_ne`], men ikke dens inverse.Det er sammenligninger som begge funksjonene returnerer `false` for.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Returverdien kan endres avhengig av kompilatorversjonen, og usikker kode er kanskje ikke avhengig av resultatet av denne funksjonen for lyd.
    /// Det anbefales at du bare bruker denne funksjonen for ytelsesoptimaliseringer der falske `false`-returverdier av denne funksjonen ikke påvirker resultatet, men bare ytelsen.
    /// Konsekvensene av å bruke denne metoden for å få kjøretid og kompileringskode til å oppføre seg annerledes er ikke utforsket.
    /// Denne metoden skal ikke brukes til å innføre slike forskjeller, og den bør heller ikke stabiliseres før vi har en bedre forståelse av dette problemet.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Returnerer om to pekere garantert er ulik.
    ///
    /// Ved kjøretid oppfører denne funksjonen seg som `self != other`.
    /// I noen sammenhenger (for eksempel evaluering av kompileringstid) er det imidlertid ikke alltid mulig å bestemme ulikheten til to pekere, så denne funksjonen kan falskt returnere `false` for pekere som senere faktisk viser seg å være ulik.
    ///
    /// Men når den returnerer `true`, er pekepinnene garantert ulik.
    ///
    /// Denne funksjonen er speilet til [`guaranteed_eq`], men ikke dens inverse.Det er sammenligninger som begge funksjonene returnerer `false` for.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Returverdien kan endres avhengig av kompilatorversjonen, og usikker kode er kanskje ikke avhengig av resultatet av denne funksjonen for lyd.
    /// Det anbefales at du bare bruker denne funksjonen for ytelsesoptimaliseringer der falske `false`-returverdier av denne funksjonen ikke påvirker resultatet, men bare ytelsen.
    /// Konsekvensene av å bruke denne metoden for å få kjøretid og kompileringskode til å oppføre seg annerledes er ikke utforsket.
    /// Denne metoden skal ikke brukes til å innføre slike forskjeller, og den bør heller ikke stabiliseres før vi har en bedre forståelse av dette problemet.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Beregner forskyvningen fra en peker (praktisk for `.offset(count as isize)`).
    ///
    /// `count` er i enheter av T;for eksempel representerer en `count` på 3 en pekerforskyvning av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Hvis noen av følgende betingelser er brutt, er resultatet udefinert oppførsel:
    ///
    /// * Både startpekeren og den resulterende pekeren må være enten i rammer eller en byte forbi slutten av det samme tildelte objektet.
    /// Merk at i Rust blir hver (stack-allocated)-variabel ansett som et separat tildelt objekt.
    ///
    /// * Den beregnede forskyvningen,**i byte**, kan ikke flyte over en `isize`.
    ///
    /// * Forskyvningen som er innenfor grensene kan ikke stole på at "wrapping around" adresseområdet.Det vil si at den uendelige presisjonssummen må passe inn i en `usize`.
    ///
    /// Kompilatoren og standardbiblioteket prøver vanligvis å sikre at tildelinger aldri når en størrelse der en forskyvning er en bekymring.
    /// For eksempel sørger `Vec` og `Box` for at de aldri tildeler mer enn `isize::MAX` byte, så `vec.as_ptr().add(vec.len())` er alltid trygt.
    ///
    /// De fleste plattformer kan ikke engang konstruere en slik tildeling.
    /// For eksempel kan ingen kjent 64-biters plattform noensinne tjene en forespørsel om 2 <sup>63</sup> byte på grunn av sidetabellbegrensninger eller splitting av adresseplassen.
    /// Imidlertid kan noen 32-biters og 16-biters plattformer vellykket servere en forespørsel om mer enn `isize::MAX`-byte med ting som fysisk adresseutvidelse.
    ///
    /// Som sådan kan minne hentet direkte fra tildelere eller minnekartede filer * være for stort til å håndtere denne funksjonen.
    ///
    /// Vurder å bruke [`wrapping_add`] i stedet hvis disse begrensningene er vanskelige å oppfylle.
    /// Den eneste fordelen med denne metoden er at den muliggjør mer aggressive kompilatoroptimaliseringer.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Beregner forskyvningen fra en peker (bekvemmelighet for `.offset ((regnes som isize).wrapping_neg())`).
    ///
    /// `count` er i enheter av T;for eksempel representerer en `count` på 3 en pekerforskyvning av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Hvis noen av følgende betingelser er brutt, er resultatet udefinert oppførsel:
    ///
    /// * Både startpekeren og den resulterende pekeren må være enten i rammer eller en byte forbi slutten av det samme tildelte objektet.
    /// Merk at i Rust blir hver (stack-allocated)-variabel ansett som et separat tildelt objekt.
    ///
    /// * Den beregnede forskyvningen kan ikke overstige `isize::MAX`**byte**.
    ///
    /// * Forskyvningen som er innenfor grensene kan ikke stole på at "wrapping around" adresseområdet.Det vil si at den uendelige presisjonssummen må passe inn i en størrelse.
    ///
    /// Kompilatoren og standardbiblioteket prøver vanligvis å sikre at tildelinger aldri når en størrelse der en forskyvning er en bekymring.
    /// For eksempel sørger `Vec` og `Box` for at de aldri tildeler mer enn `isize::MAX` byte, så `vec.as_ptr().add(vec.len()).sub(vec.len())` er alltid trygt.
    ///
    /// De fleste plattformer kan ikke engang konstruere en slik tildeling.
    /// For eksempel kan ingen kjent 64-biters plattform noensinne tjene en forespørsel om 2 <sup>63</sup> byte på grunn av sidetabellbegrensninger eller splitting av adresseplassen.
    /// Imidlertid kan noen 32-biters og 16-biters plattformer vellykket servere en forespørsel om mer enn `isize::MAX`-byte med ting som fysisk adresseutvidelse.
    ///
    /// Som sådan kan minne hentet direkte fra tildelere eller minnekartede filer * være for stort til å håndtere denne funksjonen.
    ///
    /// Vurder å bruke [`wrapping_sub`] i stedet hvis disse begrensningene er vanskelige å oppfylle.
    /// Den eneste fordelen med denne metoden er at den muliggjør mer aggressive kompilatoroptimaliseringer.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Beregner forskyvningen fra en peker ved hjelp av innpakningsaritmetikk.
    /// (bekvemmelighet for `.wrapping_offset(count as isize)`)
    ///
    /// `count` er i enheter av T;for eksempel representerer en `count` på 3 en pekerforskyvning av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Selve denne operasjonen er alltid trygg, men det er ikke bruk av den resulterende pekeren.
    ///
    /// Den resulterende pekeren forblir festet til det samme tildelte objektet som `self` peker på.
    /// Det kan *ikke* brukes til å få tilgang til et annet tildelt objekt.Merk at i Rust blir hver (stack-allocated)-variabel ansett som et separat tildelt objekt.
    ///
    /// Med andre ord gjør `let z = x.wrapping_add((y as usize) - (x as usize))`*ikke*`z` det samme som `y`, selv om vi antar at `T` har størrelse `1` og det ikke er noe overløp: `z` er fortsatt festet til objektet `x` er festet til, og dereferanse det er udefinert oppførsel med mindre `x` og `y` peker inn i det samme tildelte objektet.
    ///
    /// Sammenlignet med [`add`] forsinker denne metoden i utgangspunktet kravet om å holde seg innenfor det samme tildelte objektet: [`add`] er umiddelbar udefinert oppførsel når du krysser objektgrenser;`wrapping_add` produserer en peker, men fører fremdeles til udefinert atferd hvis en peker blir referert når den er utenfor grensene for objektet den er festet til.
    /// [`add`] kan optimaliseres bedre og er dermed å foretrekke i ytelsessensitiv kode.
    ///
    /// Den forsinkede kontrollen tar bare hensyn til verdien til pekeren som ble henvist til, ikke de mellomverdiene som ble brukt under beregningen av det endelige resultatet.
    /// For eksempel er `x.wrapping_add(o).wrapping_sub(o)` alltid det samme som `x`.Det er med andre ord tillatt å forlate det tildelte objektet og deretter gå inn på nytt senere.
    ///
    /// Hvis du trenger å krysse objektgrenser, kan du kaste pekeren til et heltall og gjøre regningen der.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // Iterer ved å bruke en rå peker i trinn på to elementer
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Denne sløyfen skriver ut "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Beregner forskyvningen fra en peker ved hjelp av innpakningsaritmetikk.
    /// (bekvemmelighet for `.wrapping_offset ((tell som isize).wrapping_neg())`)
    ///
    /// `count` er i enheter av T;for eksempel representerer en `count` på 3 en pekerforskyvning av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Selve denne operasjonen er alltid trygg, men det er ikke bruk av den resulterende pekeren.
    ///
    /// Den resulterende pekeren forblir festet til det samme tildelte objektet som `self` peker på.
    /// Det kan *ikke* brukes til å få tilgang til et annet tildelt objekt.Merk at i Rust blir hver (stack-allocated)-variabel ansett som et separat tildelt objekt.
    ///
    /// Med andre ord gjør `let z = x.wrapping_sub((x as usize) - (y as usize))`*ikke*`z` det samme som `y`, selv om vi antar at `T` har størrelse `1` og det ikke er noe overløp: `z` er fortsatt festet til objektet `x` er festet til, og dereferanse det er udefinert oppførsel med mindre `x` og `y` peker inn i det samme tildelte objektet.
    ///
    /// Sammenlignet med [`sub`] forsinker denne metoden i utgangspunktet kravet om å holde seg innenfor det samme tildelte objektet: [`sub`] er umiddelbar udefinert oppførsel når du krysser objektgrenser;`wrapping_sub` produserer en peker, men fører fremdeles til udefinert atferd hvis en peker blir referert når den er utenfor grensene for objektet den er festet til.
    /// [`sub`] kan optimaliseres bedre og er dermed å foretrekke i ytelsessensitiv kode.
    ///
    /// Den forsinkede kontrollen tar bare hensyn til verdien til pekeren som ble henvist til, ikke de mellomverdiene som ble brukt under beregningen av det endelige resultatet.
    /// For eksempel er `x.wrapping_add(o).wrapping_sub(o)` alltid det samme som `x`.Det er med andre ord tillatt å forlate det tildelte objektet og deretter gå inn på nytt senere.
    ///
    /// Hvis du trenger å krysse objektgrenser, kan du kaste pekeren til et heltall og gjøre regningen der.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk:
    ///
    /// ```
    /// // Iterer ved å bruke en rå peker i trinn på to elementer (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Denne sløyfen skriver ut "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Setter pekerverdien til `ptr`.
    ///
    /// I tilfelle `self` er en (fat)-peker til en ikke-størrelse type, vil denne operasjonen bare påvirke pekerdelen, mens dette for (thin)-pekere til størrelsestyper har samme effekt som en enkel oppgave.
    ///
    /// Den resulterende pekeren vil ha herkomst fra `val`, dvs. for en fettpeker er denne operasjonen semantisk den samme som å opprette en ny fettpeker med datapekeren på `val`, men metadataene til `self`.
    ///
    ///
    /// # Examples
    ///
    /// Denne funksjonen er først og fremst nyttig for å tillate bytevis pekere aritmetikk på potensielt fettpekere:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // vil skrive ut "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SIKKERHET: I tilfelle en tynn peker er denne operasjonen identisk
        // til en enkel oppgave.
        // I tilfelle en fettpeker, med den nåværende implementeringen av fettpekeroppsett, er det første feltet i en slik peker alltid datapekeren, som også er tildelt.
        //
        unsafe { *thin = val };
        self
    }

    /// Leser verdien fra `self` uten å flytte den.
    /// Dette etterlater minnet i `self` uendret.
    ///
    /// Se [`ptr::read`] for sikkerhetshensyn og eksempler.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `read`.
        unsafe { read(self) }
    }

    /// Gjør en flyktig avlesning av verdien fra `self` uten å flytte den.Dette etterlater minnet i `self` uendret.
    ///
    /// Flyktige operasjoner er ment å virke på I/O-minne, og garanteres at de ikke blir utvidet eller omorganisert av kompilatoren over andre flyktige operasjoner.
    ///
    ///
    /// Se [`ptr::read_volatile`] for sikkerhetshensyn og eksempler.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Leser verdien fra `self` uten å flytte den.
    /// Dette etterlater minnet i `self` uendret.
    ///
    /// I motsetning til `read`, kan pekeren være ujustert.
    ///
    /// Se [`ptr::read_unaligned`] for sikkerhetshensyn og eksempler.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopierer `count * size_of<T>` byte fra `self` til `dest`.
    /// Kilden og destinasjonen kan overlappe hverandre.
    ///
    /// NOTE: dette har *samme* argumentrekkefølge som [`ptr::copy`].
    ///
    /// Se [`ptr::copy`] for sikkerhetshensyn og eksempler.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopierer `count * size_of<T>` byte fra `self` til `dest`.
    /// Kilden og destinasjonen kan *ikke* overlappe hverandre.
    ///
    /// NOTE: dette har *samme* argumentrekkefølge som [`ptr::copy_nonoverlapping`].
    ///
    /// Se [`ptr::copy_nonoverlapping`] for sikkerhetshensyn og eksempler.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Beregner forskyvningen som må brukes på pekeren for å gjøre den justert til `align`.
    ///
    /// Hvis det ikke er mulig å justere pekeren, returnerer implementeringen `usize::MAX`.
    /// Det er tillatt for implementeringen å *alltid* returnere `usize::MAX`.
    /// Bare algoritmens ytelse kan avhenge av å få en brukbar forskyvning her, ikke dens korrekthet.
    ///
    /// Offset uttrykkes i antall `T`-elementer, og ikke byte.Verdien som returneres kan brukes med `wrapping_add`-metoden.
    ///
    /// Det er ingen garantier overhode for at motregning av pekeren ikke vil flyte over eller gå utover tildelingen som pekeren peker på.
    ///
    /// Det er opp til innringeren å sikre at den returnerte forskyvningen er korrekt i alle andre ord enn justering.
    ///
    /// # Panics
    ///
    /// Funksjonen panics hvis `align` ikke er en power-of-two.
    ///
    /// # Examples
    ///
    /// Tilgang til tilstøtende `u8` som `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // mens pekeren kan justeres via `offset`, peker den utenfor tildelingen
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SIKKERHET: `align` er sjekket for å være en effekt på 2 ovenfor
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Returnerer lengden på en rå skive.
    ///
    /// Den returnerte verdien er antall **elementer**, ikke antall byte.
    ///
    /// Denne funksjonen er trygg, selv når rå skive ikke kan kastes til en skivereferanse fordi pekeren er null eller ikke justert.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIKKERHET: dette er trygt fordi `*const [T]` og `FatPtr<T>` har samme oppsett.
            // Bare `std` kan gi denne garantien.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Returnerer en rå peker til stykkets buffer.
    ///
    /// Dette tilsvarer å støpe `self` til `*const T`, men mer typesikkert.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Returnerer en rå peker til et element eller underdel, uten å gjøre grensekontroll.
    ///
    /// Å kalle denne metoden med en indeks utenfor grensene eller når `self` ikke kan avvises, er *[udefinert oppførsel]* selv om den resulterende pekeren ikke brukes.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SIKKERHET: innringeren sørger for at `self` kan avleses og `index` er innenfor rammen.
        unsafe { index.get_unchecked(self) }
    }

    /// Returnerer `None` hvis pekeren er null, ellers returnerer et delt stykke til verdien pakket inn i `Some`.
    /// I motsetning til [`as_ref`] krever dette ikke at verdien må initialiseres.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Når du kaller denne metoden, må du sørge for at *enten* pekeren er NULL *eller* at alt av dette stemmer:
    ///
    /// * Pekeren må være [valid] for å lese for `ptr.len() * mem::size_of::<T>()` mange byte, og den må være riktig justert.Dette betyr spesielt:
    ///
    ///     * Hele minneområdet for denne delen må være inneholdt i et enkelt tildelt objekt!
    ///       Skiver kan aldri spenne over flere tildelte objekter.
    ///
    ///     * Pekeren må være justert selv for skiver uten lengde.
    ///     En grunn til dette er at optimalisering av enum-layout kan stole på at referanser (inkludert skiver av hvilken som helst lengde) blir justert og ikke-null for å skille dem fra andre data.
    ///
    ///     Du kan skaffe deg en peker som kan brukes som `data` for skiver uten lengde ved hjelp av [`NonNull::dangling()`].
    ///
    /// * Den totale størrelsen `ptr.len() * mem::size_of::<T>()` på stykket må ikke være større enn `isize::MAX`.
    ///   Se sikkerhetsdokumentasjonen til [`pointer::offset`].
    ///
    /// * Du må håndheve Rust s aliaseringsregler, siden den returnerte levetiden `'a` er vilkårlig valgt og ikke nødvendigvis gjenspeiler den faktiske levetiden til dataene.
    ///   Spesielt, i løpet av denne levetiden, må ikke minnet pekeren peker på bli mutert (unntatt inne i `UnsafeCell`).
    ///
    /// Dette gjelder selv om resultatet av denne metoden er ubrukt!
    ///
    /// Se også [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Likestilling for pekere
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Sammenligning for pekere
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}