//! Administrer minne manuelt gjennom rå pekere.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Mange funksjoner i denne modulen tar råpekere som argumenter og leser fra eller skriver til dem.For at dette skal være trygt, må disse pekerne være *gyldige*.
//! Hvorvidt en peker er gyldig, avhenger av operasjonen den brukes til (lese eller skrive), og omfanget av minnet du får tilgang til (dvs. hvor mange byte som er read/written).
//! De fleste funksjoner bruker `*mut T` og `* const T` for kun å få tilgang til en enkelt verdi, i hvilket tilfelle dokumentasjonen utelater størrelsen og antar implisitt at den er `size_of::<T>()` byte.
//!
//! De nøyaktige reglene for gyldighet er ikke bestemt ennå.Garantiene som er gitt på dette punktet er veldig minimale:
//!
//! * En [null]-peker er *aldri* gyldig, ikke engang for tilgang til [size zero][zst].
//! * For at en peker skal være gyldig, er det nødvendig, men ikke alltid tilstrekkelig, at pekeren kan være *dereferenserbar*: minneområdet til den gitte størrelsen som starter ved pekeren, må alle være innenfor grensene til et enkelt tildelt objekt.
//!
//! Merk at i Rust blir hver (stack-allocated)-variabel ansett som et separat tildelt objekt.
//! * Selv for [size zero][zst]-operasjoner, må ikke pekeren peke på et distribuert minne, dvs. at deallocation gjør pekere ugyldige selv for nullstore operasjoner.
//! Å kaste et helt tall *bokstavelig* som ikke er null til en peker er imidlertid gyldig for tilgang i nullstørrelse, selv om noe tilfeldigvis eksisterer på den adressen og blir fordelt.
//! Dette tilsvarer å skrive din egen tildeler: tildeling av objekter i null størrelse er ikke veldig vanskelig.
//! Den kanoniske måten å skaffe en peker som er gyldig for tilgang i nullstørrelse, er [`NonNull::dangling`].
//! * All tilgang utført av funksjoner i denne modulen er *ikke-atomisk* i betydningen [atomic operations] som brukes til å synkronisere mellom tråder.
//! Dette betyr at det er udefinert oppførsel å utføre to samtidige tilganger til samme sted fra forskjellige tråder, med mindre begge tilgangene bare leses fra minnet.
//! Legg merke til at dette eksplisitt inkluderer [`read_volatile`] og [`write_volatile`]: Flyktige tilganger kan ikke brukes til synkronisering mellom tråder.
//! * Resultatet av å kaste en referanse til en peker er gyldig så lenge det underliggende objektet er live og ingen referanse (bare rå pekere) brukes for å få tilgang til samme minne.
//!
//! Disse aksiomene, sammen med forsiktig bruk av [`offset`] for pekere aritmetikk, er nok til å implementere mange nyttige ting i usikker kode riktig.
//! Sterkere garantier vil til slutt bli gitt, ettersom [aliasing]-reglene blir bestemt.
//! For mer informasjon, se [book] samt delen i referansen viet til [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Gyldige råpekere som definert ovenfor er ikke nødvendigvis riktig innrettet (der "proper"-justering er definert av pointetypen, dvs. at `*const T` må justeres til `mem::align_of::<T>()`).
//! Imidlertid krever de fleste funksjoner at argumentene deres er riktig justert, og vil eksplisitt oppgi dette kravet i dokumentasjonen.
//! Merkbare unntak fra dette er [`read_unaligned`] og [`write_unaligned`].
//!
//! Når en funksjon krever riktig justering, gjør den det selv om tilgangen har størrelse 0, dvs. selv om minnet faktisk ikke berøres.Vurder å bruke [`NonNull::dangling`] i slike tilfeller.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Utfører destruktoren (hvis noen) av den pekte verdien.
///
/// Dette tilsvarer semantisk å ringe [`ptr::read`] og forkaste resultatet, men har følgende fordeler:
///
/// * Det er *påkrevd* å bruke `drop_in_place` til å slippe usorterte typer som trait-objekter, fordi de ikke kan leses ut på bunken og slippes normalt.
///
/// * Det er vennligere for optimalisereren å gjøre dette over [`ptr::read`] når man slipper manuelt tildelt minne (f.eks. I implementeringene av `Box`/`Rc`/`Vec`), ettersom kompilatoren ikke trenger å bevise at det er lyd å kopiere kopien.
///
///
/// * Den kan brukes til å slippe [pinned]-data når `T` ikke er `repr(packed)` (festede data må ikke flyttes før de slippes).
///
/// Ikke-justerte verdier kan ikke slippes på plass, de må kopieres til et justert sted først ved hjelp av [`ptr::read_unaligned`].For pakkede konstruksjoner blir dette trekket gjort automatisk av kompilatoren.
/// Dette betyr at feltene med pakkede strukturer ikke blir droppet på plass.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `to_drop` må være [valid] for både lesing og skriving.
///
/// * `to_drop` må være riktig justert.
///
/// * Verdien `to_drop` peker på må være gyldig for å slippe, noe som kan bety at den må opprettholde flere invarianter, dette er typeavhengig.
///
/// I tillegg, hvis `T` ikke er [`Copy`], kan bruk av den påpekte verdien etter å ha ringt `drop_in_place` forårsake udefinert oppførsel.Merk at `*to_drop = foo` teller som en bruk fordi det vil føre til at verdien slippes igjen.
/// [`write()`] kan brukes til å overskrive data uten at de blir droppet.
///
/// Merk at selv om `T` har størrelse `0`, må pekeren være ikke NULL og riktig justert.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Fjern det siste elementet manuelt fra en vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Få en rå peker til det siste elementet i `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Forkort `v` for å forhindre at det siste elementet blir droppet.
///     // Vi gjør det først for å forhindre problemer hvis `drop_in_place` under panics.
///     v.set_len(1);
///     // Uten en samtale `drop_in_place`, ville det siste elementet aldri bli droppet, og minnet det administrerer ville bli lekket.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Forsikre deg om at det siste elementet ble droppet.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Legg merke til at kompilatoren utfører denne kopien automatisk når du slipper pakket pakker, dvs. at du vanligvis ikke trenger å bekymre deg for slike problemer med mindre du ringer `drop_in_place` manuelt.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kode her spiller ingen rolle, dette erstattes av ekte dråpelim av kompilatoren.
    //

    // SIKKERHET: se kommentar ovenfor
    unsafe { drop_in_place(to_drop) }
}

/// Oppretter en null rå peker.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Oppretter en null-mutabel rå peker.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manuell impl. Nødvendig for å unngå `T: Clone` bundet.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manuell impl. Nødvendig for å unngå `T: Copy` bundet.
impl<T> Copy for FatPtr<T> {}

/// Danner en rå skive fra en peker og en lengde.
///
/// `len`-argumentet er antall **elementer**, ikke antall byte.
///
/// Denne funksjonen er trygg, men det er ikke sikkert å bruke returverdien.
/// Se dokumentasjonen til [`slice::from_raw_parts`] for sikkerhetskrav til skiver.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // lag en snittpeker når du starter med en peker til det første elementet
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SIKKERHET: Å få tilgang til verdien fra `Repr`-unionen er trygg siden * const [T]
        //
        // og FatPtr har samme minneoppsett.Bare std kan gi denne garantien.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Utfører samme funksjonalitet som [`slice_from_raw_parts`], bortsett fra at en rå, muterbar skive returneres, i motsetning til en rå uforanderlig skive.
///
///
/// Se dokumentasjonen til [`slice_from_raw_parts`] for mer informasjon.
///
/// Denne funksjonen er trygg, men det er ikke sikkert å bruke returverdien.
/// Se dokumentasjonen til [`slice::from_raw_parts_mut`] for sikkerhetskrav til skiver.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // tilordne en verdi til en indeks i delen
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SIKKERHET: Å få tilgang til verdien fra `Repr`-unionen er trygg siden * mut [T]
        // og FatPtr har samme minneoppsett
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Bytter verdiene på to mutable steder av samme type, uten å deinitialisere heller.
///
/// Men for de følgende to unntakene tilsvarer denne funksjonen semantisk [`mem::swap`]:
///
///
/// * Den opererer på rå pekere i stedet for referanser.
/// Når referanser er tilgjengelige, bør [`mem::swap`] foretrekkes.
///
/// * De to påpekte verdiene kan overlappe hverandre.
/// Hvis verdiene overlapper hverandre, vil den overlappende regionen til minnet fra `x` bli brukt.
/// Dette demonstreres i det andre eksemplet nedenfor.
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * Både `x` og `y` må være [valid] for både lesing og skriving.
///
/// * Både `x` og `y` må være riktig justert.
///
/// Merk at selv om `T` har størrelse `0`, må pekerne være ikke NULL og riktig justert.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Bytte av to ikke-overlappende regioner:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // dette er `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // dette er `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Bytter to overlappende regioner:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // dette er `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // dette er `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indeksene `1..3` i stykket overlapper mellom `x` og `y`.
///     // Rimelige resultater ville være for dem å være `[2, 3]`, slik at indeksene `0..3` er `[1, 2, 3]` (matchende `y` før `swap`);eller for at de skal være `[0, 1]` slik at indeksene `1..4` er `[0, 1, 2]` (matchende `x` før `swap`).
/////
///     // Denne implementeringen er definert for å ta sistnevnte valg.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Gi oss litt riperom å jobbe med.
    // Vi trenger ikke å bekymre oss for dråper: `MaybeUninit` gjør ingenting når det slippes.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Utfør bytte SIKKERHET: innringeren må garantere at `x` og `y` er gyldige for skriving og riktig justert.
    // `tmp` kan ikke overlappe hverken `x` eller `y` fordi `tmp` nettopp ble tildelt på stakken som et separat tildelt objekt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` og `y` kan overlappe hverandre
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Bytter `count * size_of::<T>()` byte mellom de to regionene i minnet som begynner på `x` og `y`.
/// De to regionene må *ikke* overlappe hverandre.
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * Både `x` og `y` må være [valid] for både å lese og skrive om `count *
///   størrelsen av: :<T>() `byte.
///
/// * Både `x` og `y` må være riktig justert.
///
/// * Regionen til minnet som begynner på `x` med størrelsen på `count *
///   størrelsen av: :<T>() `byte må *ikke* overlappe med minneområdet som begynner på `y` med samme størrelse.
///
/// Merk at selv om den effektivt kopierte størrelsen (`count * size_of: :<T>()`) er `0`, må pekerne være ikke NULL og riktig justert.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SIKKERHET: innringeren må garantere at `x` og `y` er
    // gyldig for skriv og riktig justert.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // For typer som er mindre enn blokkoptimaliseringen nedenfor, er det bare å bytte direkte for å unngå pessimisering av kodegen.
    //
    if mem::size_of::<T>() < 32 {
        // SIKKERHET: innringeren må garantere at `x` og `y` er gyldige
        // for skriver, riktig justert og ikke-overlappende.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Tilnærmingen her er å bruke simd til å bytte x&y effektivt.
    // Testing viser at bytte av enten 32 byte eller 64 byte av gangen er mest effektivt for Intel Haswell E-prosessorer.
    // LLVM er mer i stand til å optimalisere hvis vi gir en struktur en #[repr(simd)], selv om vi ikke faktisk bruker denne strukturen direkte.
    //
    //
    // FIXME repr(simd) ødelagt på emscripten og redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Sløyfe gjennom x&y, kopiere dem `Block` om gangen. Optimizer bør rulle sløyfen fullstendig for de fleste typer NB
    // Vi kan ikke bruke en for loop da `range` impl kaller `mem::swap` rekursivt
    //
    let mut i = 0;
    while i + block_size <= len {
        // Lag litt uinitialisert minne som skrapeplass Ved å erklære `t` her unngås å justere stakken når denne sløyfen er ubrukt
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SIKKERHET: Som `i < len`, og som den som ringer må garantere at `x` og `y` er gyldige
        // for `len` byte må `x + i` og `y + i` være gyldige adresser, som oppfyller sikkerhetskontrakten for `add`.
        //
        // Innringeren må også garantere at `x` og `y` er gyldige for skriving, riktig justert og ikke-overlappende, som oppfyller sikkerhetskontrakten for `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Bytt en blokk med byte av x&y, bruk t som en midlertidig buffer. Dette bør optimaliseres til effektive SIMD-operasjoner der det er tilgjengelig
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Bytt eventuelle gjenværende byte
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SIKKERHET: se forrige sikkerhetskommentar.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Flytter `src` inn i den spisse `dst`, og returnerer den forrige `dst`-verdien.
///
/// Ingen av verdiene faller.
///
/// Denne funksjonen er semantisk ekvivalent med [`mem::replace`], bortsett fra at den fungerer på rå pekere i stedet for referanser.
/// Når referanser er tilgjengelige, bør [`mem::replace`] foretrekkes.
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `dst` må være [valid] for både lesing og skriving.
///
/// * `dst` må være riktig justert.
///
/// * `dst` må peke på en riktig initialisert verdi av typen `T`.
///
/// Merk at selv om `T` har størrelse `0`, må pekeren være ikke NULL og riktig justert.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ville ha samme effekt uten å kreve den usikre blokkeringen.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SIKKERHET: innringeren må garantere at `dst` er gyldig
    // kastet til en mutbar referanse (gyldig for skriving, justert, initialisert), og kan ikke overlappe `src` siden `dst` må peke på et distinkt tildelt objekt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // kan ikke overlappe hverandre
    }
    src
}

/// Leser verdien fra `src` uten å flytte den.Dette etterlater minnet i `src` uendret.
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `src` må være [valid] for lesing.
///
/// * `src` må være riktig justert.Bruk [`read_unaligned`] hvis dette ikke er tilfelle.
///
/// * `src` må peke på en riktig initialisert verdi av typen `T`.
///
/// Merk at selv om `T` har størrelse `0`, må pekeren være ikke NULL og riktig justert.
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuelt implementere [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Lag en bitvis kopi av verdien på `a` i `tmp`.
///         let tmp = ptr::read(a);
///
///         // Å avslutte på dette punktet (enten ved eksplisitt å returnere eller ved å ringe en funksjon som panics) vil føre til at verdien i `tmp` slippes mens den samme verdien fremdeles refereres til av `a`.
///         // Dette kan utløse udefinert oppførsel hvis `T` ikke er `Copy`.
/////
/////
///
///         // Lag en bitvis kopi av verdien på `b` i `a`.
///         // Dette er trygt fordi foranderlige referanser ikke kan alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Som ovenfor kan avslutning her utløse udefinert oppførsel fordi den samme verdien er referert til av `a` og `b`.
/////
///
///         // Flytt `tmp` til `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` har blitt flyttet (`write` tar eierskap til sitt andre argument), så ingenting blir mistet implisitt her.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Eierskap av den returnerte verdien
///
/// `read` oppretter en bitvis kopi av `T`, uavhengig av om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan bruk av både den returnerte verdien og verdien på `*src` bryte minnesikkerheten.
/// Merk at tildeling til `*src` teller som en bruk fordi den vil prøve å slippe verdien på `* src`.
///
/// [`write()`] kan brukes til å overskrive data uten at de blir droppet.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` peker nå på det samme underliggende minnet som `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Når du tilordner til `s2`, faller den opprinnelige verdien.
///     // Utover dette punktet, må `s` ikke lenger brukes, siden det underliggende minnet er frigjort.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Å tilordne til `s` vil føre til at den gamle verdien faller igjen, og føre til udefinert oppførsel.
/////
///     // s= String::from("bar");//FEIL
///
///     // `ptr::write` kan brukes til å overskrive en verdi uten å slippe den.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIKKERHET: innringeren må garantere at `src` er gyldig for lesing.
    // `src` kan ikke overlappe `tmp` fordi `tmp` nettopp ble tildelt på stakken som et separat tildelt objekt.
    //
    //
    // Siden vi nettopp skrev en gyldig verdi i `tmp`, vil den garantert bli riktig initialisert.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Leser verdien fra `src` uten å flytte den.Dette etterlater minnet i `src` uendret.
///
/// I motsetning til [`read`] fungerer `read_unaligned` med ikke-justerte pekere.
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `src` må være [valid] for lesing.
///
/// * `src` må peke på en riktig initialisert verdi av typen `T`.
///
/// I likhet med [`read`] lager `read_unaligned` en bitvis kopi av `T`, uavhengig av om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan både den returnerte verdien og verdien på `*src` bruke [violate memory safety][read-ownership].
///
/// Merk at selv om `T` har størrelse `0`, må pekeren ikke være NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## På `packed`-strukturer
///
/// Det er foreløpig umulig å lage rå pekere til ujusterte felt i en fullpakket struktur.
///
/// Forsøk på å lage en rå peker til et `unaligned`-strukturfelt med et uttrykk som `&packed.unaligned as *const FieldType`, skaper en mellomliggende ikke-justert referanse før den konverteres til en rå peker.
///
/// At denne referansen er midlertidig og umiddelbart kastet, er uvesentlig da kompilatoren alltid forventer at referanser skal være riktig justert.
/// Som et resultat forårsaker bruk av `&packed.unaligned as *const FieldType` øyeblikkelig* udefinert oppførsel * i programmet ditt.
///
/// Et eksempel på hva du ikke skal gjøre og hvordan dette forholder seg til `read_unaligned` er:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Her prøver vi å ta adressen til et 32-biters heltall som ikke er justert.
///     let unaligned =
///         // Her opprettes en midlertidig ujustert referanse som resulterer i udefinert oppførsel uansett om referansen brukes eller ikke.
/////
///         &packed.unaligned
///         // Det hjelper ikke å kaste til en rå peker;feilen skjedde allerede.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Å få tilgang til ujusterte felt direkte med f.eks. `packed.unaligned` er imidlertid trygt.
///
///
///
///
///
///
// FIXME: Oppdater dokumenter basert på utfallet av RFC #2582 og venner.
/// # Examples
///
/// Les en bruksverdi fra en bytebuffer:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIKKERHET: innringeren må garantere at `src` er gyldig for lesing.
    // `src` kan ikke overlappe `tmp` fordi `tmp` nettopp ble tildelt på stakken som et separat tildelt objekt.
    //
    //
    // Siden vi nettopp skrev en gyldig verdi i `tmp`, vil den garantert bli riktig initialisert.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Overskriver en minneplassering med den gitte verdien uten å lese eller slippe den gamle verdien.
///
/// `write` slipper ikke innholdet i `dst`.
/// Dette er trygt, men det kan lekke allokeringer eller ressurser, så du må være forsiktig så du ikke overskriver et objekt som skal slippes.
///
///
/// I tillegg slipper den ikke `src`.Semantisk flyttes `src` til stedet som `dst` peker på.
///
/// Dette er passende for initialisering av ikke-initialisert minne, eller overskriving av minne som tidligere har vært [`read`] fra.
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `dst` må være [valid] for skriver.
///
/// * `dst` må være riktig justert.Bruk [`write_unaligned`] hvis dette ikke er tilfelle.
///
/// Merk at selv om `T` har størrelse `0`, må pekeren være ikke NULL og riktig justert.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuelt implementere [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Lag en bitvis kopi av verdien på `a` i `tmp`.
///         let tmp = ptr::read(a);
///
///         // Å avslutte på dette punktet (enten ved eksplisitt å returnere eller ved å ringe en funksjon som panics) vil føre til at verdien i `tmp` slippes mens den samme verdien fremdeles refereres til av `a`.
///         // Dette kan utløse udefinert oppførsel hvis `T` ikke er `Copy`.
/////
/////
///
///         // Lag en bitvis kopi av verdien på `b` i `a`.
///         // Dette er trygt fordi foranderlige referanser ikke kan alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Som ovenfor kan avslutning her utløse udefinert oppførsel fordi den samme verdien er referert til av `a` og `b`.
/////
///
///         // Flytt `tmp` til `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` har blitt flyttet (`write` tar eierskap til sitt andre argument), så ingenting blir mistet implisitt her.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Vi kaller det indre for å unngå funksjonsanrop i den genererte koden, da `intrinsics::copy_nonoverlapping` er en innpakningsfunksjon.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SIKKERHET: innringeren må garantere at `dst` er gyldig for skriving.
    // `dst` kan ikke overlappe `src` fordi innringer har mutbar tilgang til `dst` mens `src` eies av denne funksjonen.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Overskriver en minneplassering med den gitte verdien uten å lese eller slippe den gamle verdien.
///
/// I motsetning til [`write()`], kan pekeren være ujustert.
///
/// `write_unaligned` slipper ikke innholdet i `dst`.Dette er trygt, men det kan lekke allokeringer eller ressurser, så du bør være forsiktig så du ikke overskriver et objekt som skal slippes.
///
/// I tillegg slipper den ikke `src`.Semantisk flyttes `src` til stedet som `dst` peker på.
///
/// Dette er passende for initialisering av ikke-initialisert minne, eller overskriving av minne som tidligere har blitt lest med [`read_unaligned`].
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `dst` må være [valid] for skriver.
///
/// Merk at selv om `T` har størrelse `0`, må pekeren ikke være NULL.
///
/// [valid]: self#safety
///
/// ## På `packed`-strukturer
///
/// Det er foreløpig umulig å lage rå pekere til ujusterte felt i en fullpakket struktur.
///
/// Forsøk på å lage en rå peker til et `unaligned`-strukturfelt med et uttrykk som `&packed.unaligned as *const FieldType`, skaper en mellomliggende ikke-justert referanse før den konverteres til en rå peker.
///
/// At denne referansen er midlertidig og umiddelbart kastet, er uvesentlig da kompilatoren alltid forventer at referanser skal være riktig justert.
/// Som et resultat forårsaker bruk av `&packed.unaligned as *const FieldType` øyeblikkelig* udefinert oppførsel * i programmet ditt.
///
/// Et eksempel på hva du ikke skal gjøre og hvordan dette forholder seg til `write_unaligned` er:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Her prøver vi å ta adressen til et 32-biters heltall som ikke er justert.
///     let unaligned =
///         // Her opprettes en midlertidig ujustert referanse som resulterer i udefinert oppførsel uansett om referansen brukes eller ikke.
/////
///         &mut packed.unaligned
///         // Det hjelper ikke å kaste til en rå peker;feilen skjedde allerede.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Å få tilgang til ujusterte felt direkte med f.eks. `packed.unaligned` er imidlertid trygt.
///
///
///
///
///
///
///
///
///
// FIXME: Oppdater dokumenter basert på utfallet av RFC #2582 og venner.
/// # Examples
///
/// Skriv en bruksverdi til en bytebuffer:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SIKKERHET: innringeren må garantere at `dst` er gyldig for skriving.
    // `dst` kan ikke overlappe `src` fordi innringer har mutbar tilgang til `dst` mens `src` eies av denne funksjonen.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Vi kaller det indre direkte for å unngå funksjonsanrop i den genererte koden.
        intrinsics::forget(src);
    }
}

/// Gjør en flyktig avlesning av verdien fra `src` uten å flytte den.Dette etterlater minnet i `src` uendret.
///
/// Flyktige operasjoner er ment å virke på I/O-minne, og garanteres at de ikke blir utvidet eller omorganisert av kompilatoren over andre flyktige operasjoner.
///
/// # Notes
///
/// Rust har for øyeblikket ikke en nøye og formelt definert minnemodell, så den presise semantikken til hva "volatile" betyr her kan endres over tid.
/// Når det er sagt, vil semantikken nesten alltid ende opp ganske lik [C11's definition of volatile][c11].
///
/// Kompilatoren bør ikke endre den relative rekkefølgen eller antallet av flyktige minneoperasjoner.
/// Imidlertid er ustabile minneoperasjoner på nullstørrelsestyper (f.eks. Hvis en nullstørrelsestype sendes til `read_volatile`) noops og kan ignoreres.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `src` må være [valid] for lesing.
///
/// * `src` må være riktig justert.
///
/// * `src` må peke på en riktig initialisert verdi av typen `T`.
///
/// I likhet med [`read`] lager `read_volatile` en bitvis kopi av `T`, uavhengig av om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan både den returnerte verdien og verdien på `*src` bruke [violate memory safety][read-ownership].
/// Det er nesten helt sikkert feil å lagre typer som ikke er [`Copy`] i flyktig minne.
///
/// Merk at selv om `T` har størrelse `0`, må pekeren være ikke NULL og riktig justert.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Akkurat som i C, har en operasjon er ustabil, ingen betydning for spørsmål som involverer samtidig tilgang fra flere tråder.Flyktige tilganger oppfører seg akkurat som ikke-atomiske tilganger i den forbindelse.
///
/// Spesielt er et løp mellom en `read_volatile` og en hvilken som helst skriveoperasjon til samme sted udefinert oppførsel.
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ikke få panikk for å holde kodegenes innvirkning mindre.
        abort();
    }
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Utfører en flyktig skriving av en minneplassering med den gitte verdien uten å lese eller slippe den gamle verdien.
///
/// Flyktige operasjoner er ment å virke på I/O-minne, og garanteres at de ikke blir utvidet eller omorganisert av kompilatoren over andre flyktige operasjoner.
///
/// `write_volatile` slipper ikke innholdet i `dst`.Dette er trygt, men det kan lekke allokeringer eller ressurser, så du bør være forsiktig så du ikke overskriver et objekt som skal slippes.
///
/// I tillegg slipper den ikke `src`.Semantisk flyttes `src` til stedet som `dst` peker på.
///
/// # Notes
///
/// Rust har for øyeblikket ikke en nøye og formelt definert minnemodell, så den presise semantikken til hva "volatile" betyr her kan endres over tid.
/// Når det er sagt, vil semantikken nesten alltid ende opp ganske lik [C11's definition of volatile][c11].
///
/// Kompilatoren bør ikke endre den relative rekkefølgen eller antallet av flyktige minneoperasjoner.
/// Imidlertid er ustabile minneoperasjoner på nullstørrelsestyper (f.eks. Hvis en nullstørrelsestype sendes til `write_volatile`) noops og kan ignoreres.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Atferd er udefinert hvis noen av følgende betingelser er brutt:
///
/// * `dst` må være [valid] for skriver.
///
/// * `dst` må være riktig justert.
///
/// Merk at selv om `T` har størrelse `0`, må pekeren være ikke NULL og riktig justert.
///
/// [valid]: self#safety
///
/// Akkurat som i C, har en operasjon er ustabil, ingen betydning for spørsmål som involverer samtidig tilgang fra flere tråder.Flyktige tilganger oppfører seg akkurat som ikke-atomiske tilganger i den forbindelse.
///
/// Spesielt er et løp mellom en `write_volatile` og annen operasjon (lesing eller skriving) på samme sted udefinert oppførsel.
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ikke få panikk for å holde kodegenes innvirkning mindre.
        abort();
    }
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Juster pekeren `p`.
///
/// Beregn forskyvning (når det gjelder elementer i `stride`-skritt) som må brukes på pekeren `p`, slik at pekeren `p` blir justert til `a`.
///
/// Note: Denne implementeringen er nøye skreddersydd for ikke panic.Det er UB for dette å panic.
/// Den eneste reelle endringen som kan gjøres her er endring av `INV_TABLE_MOD_16` og tilhørende konstanter.
///
/// Hvis vi noen gang bestemmer oss for å gjøre det mulig å ringe det indre med `a` som ikke er en kraft-av-to, vil det sannsynligvis være mer forsiktig å bare endre til en naiv implementering i stedet for å prøve å tilpasse dette for å imøtekomme den endringen.
///
///
/// Eventuelle spørsmål går til@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Direkte bruk av disse egenskapene forbedrer kodegen betydelig på opt-level <=
    // 1, der metodeversjonene av disse operasjonene ikke er angitt.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Beregn multiplikativ modulær invers av `x` modulo `m`.
    ///
    /// Denne implementeringen er skreddersydd for `align_offset` og har følgende forutsetninger:
    ///
    /// * `m` er en power-of-two;
    /// * `x < m`; (hvis `x ≥ m`, send inn `x % m` i stedet)
    ///
    /// Implementering av denne funksjonen skal ikke panic.Noen gang.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikativ modulær invers tabell modulo 2⁴=16.
        ///
        /// Merk at denne tabellen ikke inneholder verdier der invers ikke eksisterer (dvs. for `0⁻¹ mod 16`, `2⁻¹ mod 16`, etc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo som `INV_TABLE_MOD_16` er beregnet på.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SIKKERHET: `m` kreves for å være en power-of-two, derav ikke-null.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Vi gjentar "up" ved hjelp av følgende formel:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // inntil 2²ⁿ ≥ m.Da kan vi redusere til ønsket `m` ved å ta resultatet `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Merk at vi bruker innpakningsoperasjoner her med vilje-den originale formelen bruker f.eks. Subtraksjon `mod n`.
                // Det er helt greit å gjøre dem `mod usize::MAX` i stedet, for vi tar uansett resultatet `mod n` på slutten.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SIKKERHET: `a` er en power-of-two, derfor ikke-null.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` saken kan beregnes enklere gjennom `-p (mod a)`, men det hindrer LLVMs evne til å velge instruksjoner som `lea`.I stedet beregner vi
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // som distribuerer operasjoner rundt den bærende, men pessimerer `and` tilstrekkelig for at LLVM skal kunne utnytte de forskjellige optimaliseringene den vet om.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Allerede justert.Jippi!
        return 0;
    } else if stride == 0 {
        // Hvis pekeren ikke er justert, og elementet er nullstørrelse, vil ingen mengde elementer noen gang justere pekeren.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SIKKERHET: a er power-of-two og derfor ikke-null.stride==0 saken behandles ovenfor.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SIKKERHET: gcdpow har en øvre grense som maksimalt er antall biter i en størrelse.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SIKKERHET: gcd er alltid større eller lik 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Denne branch løser følgende lineære kongruensligning:
        //
        // ` p + so = 0 mod a `
        //
        // `p` her er pekerverdien, `s`, stride av `T`, `o` offset i `T`s, og `a`, den forespurte justeringen.
        //
        // Med `g = gcd(a, s)`, og ovennevnte tilstand som hevder at `p` også er delelig med `g`, kan vi betegne `a' = a/g`, `s' = s/g`, `p' = p/g`, da blir dette ekvivalent med:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Den første termen er "the relative alignment of `p` to `a`" (delt på `g`), den andre termen er "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (igjen delt på `g`).
        //
        // Deling av `g` er nødvendig for å gjøre det inverse godt dannet hvis `a` og `s` ikke er samprimert.
        //
        // Videre er resultatet produsert av denne løsningen ikke "minimal", så det er nødvendig å ta resultatet `o mod lcm(s, a)`.Vi kan erstatte `lcm(s, a)` med bare en `a'`.
        //
        //
        //
        //
        //

        // SIKKERHET: `gcdpow` har en øvre grense som ikke er større enn antall etterfølgende 0-bits i `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SIKKERHET: `a2` er ikke-null.Skifting av `a` med `gcdpow` kan ikke skifte ut noen av settbittene
        // i `a` (hvorav den har nøyaktig en).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SIKKERHET: `gcdpow` har en øvre grense som ikke er større enn antall etterfølgende 0-bits i `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SIKKERHET: `gcdpow` har en øvre grense som ikke er større enn antall etterfølgende 0-bits
        // `a`.
        // Videre kan ikke subtraksjonen løpe over, fordi `a2 = a >> gcdpow` alltid vil være strengt større enn `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SIKKERHET: `a2` er en kraft av to, som vist ovenfor.`s2` er strengt tatt mindre enn `a2`
        // fordi `(s % a) >> gcdpow` er strengt mindre enn `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Kan ikke justeres i det hele tatt.
    usize::MAX
}

/// Sammenligner rå pekere for likeverd.
///
/// Dette er det samme som å bruke `==`-operatøren, men mindre generisk:
/// argumentene må være `*const T` rå pekere, ikke noe som implementerer `PartialEq`.
///
/// Dette kan brukes til å sammenligne `&T`-referanser (som tvinges til `*const T` implisitt) etter adressen i stedet for å sammenligne verdiene de peker på (det er det `PartialEq for &T`-implementeringen gjør).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Skiver sammenlignes også etter lengde (fettpekere):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits sammenlignes også med implementeringen:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Pekere har like adresser.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objekter har like adresser, men `Trait` har forskjellige implementeringer.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Konvertering av referansen til en `*const u8` sammenlignes etter adresse.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash en rå peker.
///
/// Dette kan brukes til å hash en `&T`-referanse (som impliseres til `*const T` implisitt) etter adressen i stedet for verdien den peker på (det er hva `Hash for &T`-implementeringen gjør).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls for funksjonspekere
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Mellomstøpet som størrelse er påkrevd for AVR
                // slik at adresseområdet til kildefunksjonspekeren er bevart i den endelige funksjonspekeren.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Mellomstøpet som størrelse er påkrevd for AVR
                // slik at adresseområdet til kildefunksjonspekeren er bevart i den endelige funksjonspekeren.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Ingen variadiske funksjoner med 0 parametere
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Lag en `const` rå peker til et sted uten å opprette en mellomreferanse.
///
/// Å lage en referanse med `&`/`&mut` er bare tillatt hvis pekeren er riktig justert og peker på initialiserte data.
/// I tilfeller der kravene ikke holder, bør råpekere brukes i stedet.
/// `&expr as *const _` oppretter imidlertid en referanse før den kastes til en rå peker, og den referansen er underlagt de samme reglene som alle andre referanser.
///
/// Denne makroen kan opprette en rå peker *uten* å opprette en referanse først.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` ville skape en ujustert referanse, og dermed være udefinert oppførsel!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Lag en `mut` rå peker til et sted uten å opprette en mellomreferanse.
///
/// Å lage en referanse med `&`/`&mut` er bare tillatt hvis pekeren er riktig justert og peker på initialiserte data.
/// I tilfeller der kravene ikke holder, bør råpekere brukes i stedet.
/// `&mut expr as *mut _` oppretter imidlertid en referanse før den kastes til en rå peker, og den referansen er underlagt de samme reglene som alle andre referanser.
///
/// Denne makroen kan opprette en rå peker *uten* å opprette en referanse først.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` ville skape en ujustert referanse, og dermed være udefinert oppførsel!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` tvinger kopiering av feltet i stedet for å lage en referanse.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}