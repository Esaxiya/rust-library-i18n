#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Gir pekeren metadatatypen til hvilken som helst peketype.
///
/// # Pekermetadata
///
/// Rå pekertyper og referansetyper i Rust kan betraktes som laget av to deler:
/// en datapeker som inneholder minneadressen til verdien, og noen metadata.
///
/// For typer med statisk størrelse (som implementerer `Sized` traits) så vel som for `extern`-typer, sies det at pekere er "tynne": metadata er nullstørrelse og typen er `()`.
///
///
/// Pekere til [dynamically-sized types][dst] sies å være `brede` eller `fete`, de har metadata som ikke er av størrelse:
///
/// * For strukturer hvis siste felt er en sommertid, er metadata metadata for det siste feltet
/// * For `str`-typen er metadata lengden i byte som `usize`
/// * For segmenttyper som `[T]` er metadata lengden på elementene som `usize`
/// * For trait-objekter som `dyn SomeTrait` er metadata [`DynMetadata<Self>`][DynMetadata] (f.eks. `DynMetadata<dyn SomeTrait>`)
///
/// I future kan Rust-språket få nye typer typer som har forskjellige pekermetadata.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Poenget med denne trait er dens `Metadata`-tilknyttede type, som er `()` eller `usize` eller `DynMetadata<_>` som beskrevet ovenfor.
/// Den implementeres automatisk for alle typer.
/// Det kan antas å være implementert i en generisk sammenheng, selv uten en tilsvarende grense.
///
/// # Usage
///
/// Rå pekere kan dekomponeres i dataadressen og metadatakomponentene med [`to_raw_parts`]-metoden.
///
/// Alternativt kan metadata alene ekstraheres med [`metadata`]-funksjonen.
/// En referanse kan sendes til [`metadata`] og implisitt tvinges.
///
/// En (possibly-wide)-peker kan settes sammen fra sin adresse og metadata med [`from_raw_parts`] eller [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Typen for metadata i pekere og referanser til `Self`.
    #[lang = "metadata_type"]
    // NOTE: Hold trait bounds i `static_assert_expected_bounds_for_metadata`
    //
    // i `library/core/src/ptr/metadata.rs` synkronisert med de her:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Pekere til typer som implementerer dette trait-aliaset er `tynne`.
///
/// Dette inkluderer statisk-størrelse størrelse og `extern` typer.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: stabiliser ikke dette før trait-aliaser er stabile på språket?
pub trait Thin = Pointee<Metadata = ()>;

/// Pakk ut metadata-komponenten til en peker.
///
/// Verdier av typen `*mut T`, `&T` eller `&mut T` kan overføres direkte til denne funksjonen ettersom de implisitt tvinges til `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SIKKERHET: Å få tilgang til verdien fra `PtrRepr`-foreningen er trygt siden * konst T
    // og PtrComponents<T>har samme minneoppsett.
    // Bare std kan stille denne garantien.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Danner en (possibly-wide) rå peker fra en datadresse og metadata.
///
/// Denne funksjonen er trygg, men den returnerte pekeren er ikke nødvendigvis trygge for forskjeller.
/// For skiver, se dokumentasjonen til [`slice::from_raw_parts`] for sikkerhetskrav.
/// For trait-objekter må metadataene komme fra en peker til samme underliggende slettede type.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SIKKERHET: Å få tilgang til verdien fra `PtrRepr`-foreningen er trygt siden * konst T
    // og PtrComponents<T>har samme minneoppsett.
    // Bare std kan stille denne garantien.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Utfører samme funksjonalitet som [`from_raw_parts`], bortsett fra at en rå `*mut`-peker returneres, i motsetning til en rå `* const`-peker.
///
///
/// Se dokumentasjonen til [`from_raw_parts`] for mer informasjon.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SIKKERHET: Å få tilgang til verdien fra `PtrRepr`-foreningen er trygt siden * konst T
    // og PtrComponents<T>har samme minneoppsett.
    // Bare std kan stille denne garantien.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manuell impl. Nødvendig for å unngå `T: Copy` bundet.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manuell impl. Nødvendig for å unngå `T: Clone` bundet.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadataene for en `Dyn = dyn SomeTrait` trait-objekttype.
///
/// Det er en peker til en vtabell (virtuell samtaletabell) som representerer all nødvendig informasjon for å manipulere betongtypen som er lagret i et trait-objekt.
/// Tabellen inneholder spesielt:
///
/// * type størrelse
/// * typejustering
/// * en peker til typens `drop_in_place` impl (kan være en no-op for vanlig gamle data)
/// * pekepinner til alle metodene for typens implementering av trait
///
/// Merk at de tre første er spesielle fordi de er nødvendige for å tildele, slippe og distribuere et hvilket som helst trait-objekt.
///
/// Det er mulig å navngi denne strukturen med en typeparameter som ikke er et `dyn` trait-objekt (for eksempel `DynMetadata<u64>`), men ikke for å oppnå en meningsfull verdi av den strukturen.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Det vanlige prefikset til alle vtabeller.Det blir fulgt av funksjonspekere for trait-metoder.
///
/// Privat implementeringsdetalj av `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Returnerer størrelsen på typen som er tilknyttet denne vtabellen.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Returnerer justeringen av typen som er knyttet til denne vtabellen.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Returnerer størrelsen og justeringen sammen som en `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SIKKERHET: kompilatoren sendte ut denne vtabellen for en konkret Rust-type som
        // er kjent for å ha en gyldig layout.Samme begrunnelse som i `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manuelle installasjoner er nødvendige for å unngå `Dyn: $Trait`-grenser.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}