use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// En innpakning rundt en rå ikke-null `*mut T` som indikerer at innehaveren av denne innpakningen eier referenten.
/// Nyttig for å bygge abstraksjoner som `Box<T>`, `Vec<T>`, `String` og `HashMap<K, V>`.
///
/// I motsetning til `*mut T`, oppfører `Unique<T>` seg "as if", det var en forekomst av `T`.
/// Den implementerer `Send`/`Sync` hvis `T` er `Send`/`Sync`.
/// Det innebærer også den typen sterk aliasing som garanterer at en forekomst av `T` kan forvente:
/// referenten til pekeren skal ikke endres uten en unik bane til den som eier Unique.
///
/// Hvis du er usikker på om det er riktig å bruke `Unique` til dine formål, bør du vurdere å bruke `NonNull`, som har svakere semantikk.
///
///
/// I motsetning til `*mut T`, må pekeren alltid være ikke-null, selv om pekeren aldri blir referert til.
/// Dette er slik at enums kan bruke denne forbudte verdien som en diskriminant-`Option<Unique<T>>` har samme størrelse som `Unique<T>`.
/// Men pekeren kan fortsatt dingle hvis den ikke blir referert til.
///
/// I motsetning til `*mut T` er `Unique<T>` mervariøs enn `T`.
/// Dette bør alltid være riktig for alle typer som opprettholder Uniques aliasingskrav.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: denne markøren har ingen konsekvenser for avvik, men er nødvendig
    // for dropck å forstå at vi logisk eier en `T`.
    //
    // For detaljer, se:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pekere er `Send` hvis `T` er `Send` fordi dataene de refererer til, ikke er tilpasset.
/// Legg merke til at denne aliasingvarianten ikke styrkes av typesystemet;abstraksjonen ved bruk av `Unique` må håndheve den.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pekere er `Sync` hvis `T` er `Sync` fordi dataene de refererer til, ikke er tilpasset.
/// Legg merke til at denne aliasingvarianten ikke styrkes av typesystemet;abstraksjonen ved bruk av `Unique` må håndheve den.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Oppretter en ny `Unique` som er dinglende, men godt justert.
    ///
    /// Dette er nyttig for initialisering av typer som lat tildeles, slik `Vec::new` gjør.
    ///
    /// Merk at pekerverdien potensielt kan representere en gyldig peker til en `T`, noe som betyr at denne ikke må brukes som en "not yet initialized" sentinelverdi.
    /// Typer som lat tildeles, må spore initialisering på annen måte.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SIKKERHET: mem::align_of() returnerer en gyldig, ikke-null peker.De
        // vilkårene for å ringe new_unchecked() blir dermed respektert.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Oppretter en ny `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` må være ikke-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIKKERHET: innringeren må garantere at `ptr` ikke er null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Oppretter en ny `Unique` hvis `ptr` ikke er null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIKKERHET: Pekeren er allerede sjekket og er ikke null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Anskaffer den underliggende `*mut`-pekeren.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Derefererer innholdet.
    ///
    /// Den resulterende levetiden er bundet til seg selv, så dette oppfører seg "as if", det var faktisk en forekomst av T som blir lånt.
    /// Hvis du trenger en lengre levetid på (unbound), bruk `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIKKERHET: innringeren må garantere at `self` oppfyller alle
        // krav til referanse.
        unsafe { &*self.as_ptr() }
    }

    /// Gjennomsnittlig refererer innholdet.
    ///
    /// Den resulterende levetiden er bundet til seg selv, så dette oppfører seg "as if", det var faktisk en forekomst av T som blir lånt.
    /// Hvis du trenger en lengre levetid på (unbound), bruk `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIKKERHET: innringeren må garantere at `self` oppfyller alle
        // krav til en mutbar referanse.
        unsafe { &mut *self.as_ptr() }
    }

    /// Kaster til en peker av en annen type.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SIKKERHET: Unique::new_unchecked() skaper et nytt unikt og behov
        // den gitte pekeren ikke skal være null.
        // Siden vi passerer oss selv som en peker, kan det ikke være null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIKKERHET: En foranderlig referanse kan ikke være null
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}