//! Grunnleggende funksjoner for å håndtere minne.
//!
//! Denne modulen inneholder funksjoner for å stille spørsmål om størrelsen og justeringen av typene, initialisere og manipulere minne.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Tar eierskap og "forgets" om verdien **uten å kjøre ødeleggeren**.
///
/// Eventuelle ressurser som verdien forvalter, for eksempel heapminne eller et filhåndtak, vil ligge i evigheter i uoppnåelig tilstand.Det garanterer imidlertid ikke at pekere til dette minnet forblir gyldige.
///
/// * Hvis du vil lekke minne, se [`Box::leak`].
/// * Hvis du vil skaffe deg en rå peker til minnet, se [`Box::into_raw`].
/// * Hvis du vil avhende en verdi på riktig måte og kjøre destruktoren, se [`mem::drop`].
///
/// # Safety
///
/// `forget` er ikke merket som `unsafe`, fordi Rust s sikkerhetsgarantier ikke inkluderer en garanti for at destruktører alltid vil kjøre.
/// For eksempel kan et program opprette en referansesyklus ved hjelp av [`Rc`][rc], eller ringe [`process::exit`][exit] for å avslutte uten å kjøre destruktorer.
/// Dermed endrer ikke `mem::forget` fra sikker kode fundamentalt ikke Rust s sikkerhetsgarantier.
///
/// Når det er sagt, er det ofte uønsket å lekke ressurser som minne eller I/O-objekter.
/// Behovet kommer opp i noen spesialiserte brukstilfeller for FFI eller usikker kode, men selv da er [`ManuallyDrop`] vanligvis foretrukket.
///
/// Fordi det er tillatt å glemme en verdi, må enhver `unsafe`-kode du skriver tillate denne muligheten.Du kan ikke returnere en verdi og forvente at innringeren nødvendigvis vil kjøre verdienes destruktør.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Den kanoniske sikre bruken av `mem::forget` er å omgå en verdis ødelegger implementert av `Drop` trait.For eksempel vil dette lekke en `File`, dvs.
/// gjenvinne plassen som er tatt av variabelen, men lukk aldri den underliggende systemressursen:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Dette er nyttig når eierskapet til den underliggende ressursen tidligere ble overført til kode utenfor Rust, for eksempel ved å overføre råfilbeskriveren til C-kode.
///
/// # Forholdet til `ManuallyDrop`
///
/// Mens `mem::forget` også kan brukes til å overføre *minne* eierskap, er det feilutsatt.
/// [`ManuallyDrop`] skal brukes i stedet.Tenk for eksempel på denne koden:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Bygg en `String` ved hjelp av innholdet i `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // lekkasje `v` fordi minnet nå administreres av `s`
/// mem::forget(v);  // FEIL, v er ugyldig og må ikke overføres til en funksjon
/// assert_eq!(s, "Az");
/// // `s` blir implisitt droppet og hukommelsen omplassert.
/// ```
///
/// Det er to problemer med eksemplet ovenfor:
///
/// * Hvis det ble lagt til mer kode mellom konstruksjonen av `String` og påkallingen av `mem::forget()`, ville en panic i den forårsake en dobbel ledig fordi det samme minnet håndteres av både `v` og `s`.
/// * Etter å ha ringt `v.as_mut_ptr()` og overført eierskapet til dataene til `s`, er `v`-verdien ugyldig.
/// Selv når en verdi bare er flyttet til `mem::forget` (som ikke vil inspisere den), har noen typer strenge krav til verdiene som gjør dem ugyldige når de dingler eller ikke eies lenger.
/// Å bruke ugyldige verdier på noen måte, inkludert å overføre dem til eller returnere dem fra funksjoner, utgjør udefinert oppførsel og kan bryte antagelsene fra kompilatoren.
///
/// Å bytte til `ManuallyDrop` unngår begge problemene:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Før vi demonterer `v` i de rå delene, må du sørge for at den ikke faller av!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Demonter nå `v`.Disse operasjonene kan ikke panic, så det kan ikke være lekkasje.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Til slutt, bygg en `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` blir implisitt droppet og hukommelsen omplassert.
/// ```
///
/// `ManuallyDrop` forhindrer robust dobbeltfri fordi vi deaktiverer `v`s destruktør før vi gjør noe annet.
/// `mem::forget()` tillater ikke dette fordi det bruker argumentet sitt, og tvinger oss til å ringe det først etter å ha hentet ut alt vi trenger fra `v`.
/// Selv om en panic ble introdusert mellom konstruksjonen av `ManuallyDrop` og bygningen av strengen (som ikke kan skje i koden som vist), vil det resultere i en lekkasje og ikke en dobbeltfri.
/// Med andre ord, feil `ManuallyDrop` på siden av lekkasje i stedet for å feile på siden av (dobbelt-) å slippe.
///
/// `ManuallyDrop` hindrer oss også i å måtte "touch" `v` etter å ha overført eierskapet til `s`-det siste trinnet i å samhandle med `v` for å avhende det uten å kjøre ødeleggeren, unngås helt.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Som [`forget`], men godtar også ikke-store verdier.
///
/// Denne funksjonen er bare et mellomlag ment som skal fjernes når `unsized_locals`-funksjonen blir stabilisert.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Returnerer størrelsen på en type i byte.
///
/// Mer spesifikt er dette forskyvningen i byte mellom påfølgende elementer i en matrise med den elementtypen inkludert justeringspolstring.
///
/// Således, for alle typer `T` og lengde `n`, har `[T; n]` en størrelse på `n * size_of::<T>()`.
///
/// Generelt er størrelsen på en type ikke stabil på tvers av kompileringer, men spesifikke typer som primitiver er.
///
/// Tabellen nedenfor gir størrelsen på primitiver.
///
/// Type |størrelsen av: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 røyer |4
///
/// Videre har `usize` og `isize` samme størrelse.
///
/// Typene `*const T`, `&T`, `Box<T>`, `Option<&T>` og `Option<Box<T>>` har alle samme størrelse.
/// Hvis `T` er størrelse, har alle disse typene samme størrelse som `usize`.
///
/// En pekers mutabilitet endrer ikke størrelsen.Som sådan har `&T` og `&mut T` samme størrelse.
/// Likeledes for `*const T` og `* mut T`.
///
/// # Størrelse på `#[repr(C)]`-artikler
///
/// `C`-representasjonen for varer har et definert oppsett.
/// Med denne utformingen er størrelsen på varene også stabil så lenge alle felt har en stabil størrelse.
///
/// ## Structts størrelse
///
/// For `structs` bestemmes størrelsen av følgende algoritme.
///
/// For hvert felt i strukturen bestilt etter erklæringsordre:
///
/// 1. Legg til størrelsen på feltet.
/// 2. Rund opp gjeldende størrelse til nærmeste multiplum av neste felt [alignment].
///
/// Til slutt rund størrelsen på strukturen til nærmeste multiplum av [alignment].
/// Justeringen av strukturen er vanligvis den største justeringen av alle dens felt;dette kan endres ved bruk av `repr(align(N))`.
///
/// I motsetning til `C` er ikke størrelser i null størrelse avrundet opp til en byte i størrelse.
///
/// ## Størrelse på Enums
///
/// Enums som ikke har andre data enn den diskriminerende, har samme størrelse som C enums på plattformen de er kompilert for.
///
/// ## Størrelse på fagforeninger
///
/// Størrelsen på en fagforening er størrelsen på dens største felt.
///
/// I motsetning til `C` avrundes fagforeninger med null størrelse ikke opp til en byte i størrelse.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Noen primitiver
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Noen matriser
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pekerstørrelseslikhet
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Bruker `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Størrelsen på det første feltet er 1, så legg 1 til størrelsen.Størrelse er 1.
/// // Justeringen av det andre feltet er 2, så legg 1 til størrelsen for polstring.Størrelse er 2.
/// // Størrelsen på det andre feltet er 2, så legg 2 til størrelsen.Størrelse er 4.
/// // Justeringen av det tredje feltet er 1, så legg 0 til størrelsen for polstring.Størrelse er 4.
/// // Størrelsen på det tredje feltet er 1, så legg 1 til størrelsen.Størrelse er 5.
/// // Til slutt er justeringen av strukturen 2 (fordi den største justeringen blant feltene er 2), så legg 1 til størrelsen for polstring.
/// // Størrelse er 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple strukturer følger de samme reglene.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Merk at omorganisering av feltene kan redusere størrelsen.
/// // Vi kan fjerne begge polstringsbyte ved å sette `third` før `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union størrelse er størrelsen på det største feltet.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Returnerer størrelsen på den påpekte verdien i byte.
///
/// Dette er vanligvis det samme som `size_of::<T>()`.
/// Imidlertid, når `T`*ikke har* noen statisk kjent størrelse, f.eks. En skive [`[T]`][slice] eller en [trait object], kan `size_of_val` brukes til å få den dynamisk kjente størrelsen.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SIKKERHET: `val` er en referanse, så det er en gyldig rå peker
    unsafe { intrinsics::size_of_val(val) }
}

/// Returnerer størrelsen på den påpekte verdien i byte.
///
/// Dette er vanligvis det samme som `size_of::<T>()`.Imidlertid, når `T`*har* ingen statisk kjent størrelse, f.eks. En skive [`[T]`][slice] eller en [trait object], kan `size_of_val_raw` brukes til å få den dynamisk kjente størrelsen.
///
/// # Safety
///
/// Denne funksjonen er bare trygt å ringe hvis følgende forhold gjelder:
///
/// - Hvis `T` er `Sized`, er det alltid trygt å ringe denne funksjonen.
/// - Hvis den usikre halen på `T` er:
///     - en [slice], må lengden på skivehalen være et initialisert heltall, og størrelsen på *hele verdien*(dynamisk halelengde + statisk størrelse prefiks) må passe inn i `isize`.
///     - en [trait object], så må vtabeldelen av pekeren peke på en gyldig vtabell som er anskaffet av en ikke-størrelse tvang, og størrelsen på *hele verdien*(dynamisk halelengde + statisk størrelse prefiks) må passe inn i `isize`.
///
///     - en (unstable) [extern type], så er denne funksjonen alltid trygg å ringe, men kan panic eller på annen måte returnere feil verdi, da den eksterne typen ikke er kjent.
///     Dette er den samme oppførselen som [`size_of_val`] på en referanse til en type med en ekstern type hale.
///     - ellers er det konservativt ikke tillatt å kalle denne funksjonen.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIKKERHET: innringeren må oppgi en gyldig rå peker
    unsafe { intrinsics::size_of_val(val) }
}

/// Returnerer den [ABI]-krevde minimumsjusteringen av en type.
///
/// Hver referanse til en verdi av typen `T` må være et multiplum av dette tallet.
///
/// Dette er justeringen som brukes for strukturfelt.Det kan være mindre enn den foretrukne justeringen.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returnerer den [ABI]-påkrevde minimumsjusteringen av verdien av verdien `val` peker på.
///
/// Hver referanse til en verdi av typen `T` må være et multiplum av dette tallet.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIKKERHET: val er en referanse, så det er en gyldig rå peker
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnerer den [ABI]-krevde minimumsjusteringen av en type.
///
/// Hver referanse til en verdi av typen `T` må være et multiplum av dette tallet.
///
/// Dette er justeringen som brukes for strukturfelt.Det kan være mindre enn den foretrukne justeringen.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returnerer den [ABI]-påkrevde minimumsjusteringen av verdien av verdien `val` peker på.
///
/// Hver referanse til en verdi av typen `T` må være et multiplum av dette tallet.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIKKERHET: val er en referanse, så det er en gyldig rå peker
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnerer den [ABI]-påkrevde minimumsjusteringen av verdien av verdien `val` peker på.
///
/// Hver referanse til en verdi av typen `T` må være et multiplum av dette tallet.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Denne funksjonen er bare trygt å ringe hvis følgende forhold gjelder:
///
/// - Hvis `T` er `Sized`, er det alltid trygt å ringe denne funksjonen.
/// - Hvis den usikre halen på `T` er:
///     - en [slice], må lengden på skivehalen være et initialisert heltall, og størrelsen på *hele verdien*(dynamisk halelengde + statisk størrelse prefiks) må passe inn i `isize`.
///     - en [trait object], så må vtabeldelen av pekeren peke på en gyldig vtabell som er anskaffet av en ikke-størrelse tvang, og størrelsen på *hele verdien*(dynamisk halelengde + statisk størrelse prefiks) må passe inn i `isize`.
///
///     - en (unstable) [extern type], så er denne funksjonen alltid trygg å ringe, men kan panic eller på annen måte returnere feil verdi, da den eksterne typen ikke er kjent.
///     Dette er den samme oppførselen som [`align_of_val`] på en referanse til en type med en ekstern type hale.
///     - ellers er det konservativt ikke tillatt å kalle denne funksjonen.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIKKERHET: innringeren må oppgi en gyldig rå peker
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnerer `true` hvis fallverdier av typen `T` betyr noe.
///
/// Dette er bare et optimeringshint, og kan implementeres konservativt:
/// det kan returnere `true` for typer som faktisk ikke trenger å bli droppet.
/// Som sådan vil alltid returnering av `true` være en gyldig implementering av denne funksjonen.Men hvis denne funksjonen faktisk returnerer `false`, kan du være sikker på at å slippe `T` ikke har noen bivirkning.
///
/// Implementeringer på lavt nivå av ting som samlinger, som må slippe dataene manuelt, bør bruke denne funksjonen for å unngå å unødvendig prøve å slippe alt innholdet når de blir ødelagt.
///
/// Dette kan ikke utgjøre en forskjell i utgivelsesbygninger (der en sløyfe uten bivirkninger lett blir oppdaget og eliminert), men er ofte en stor gevinst for feilsøking.
///
/// Merk at [`drop_in_place`] allerede utfører denne kontrollen, så hvis arbeidsbelastningen din kan reduseres til et lite antall [`drop_in_place`]-samtaler, er det unødvendig å bruke dette.
/// Vær spesielt oppmerksom på at du kan [`drop_in_place`] et stykke, og det vil gjøre en enkelt behovsdråpesjekk for alle verdiene.
///
/// Typer som Vec er derfor bare `drop_in_place(&mut self[..])` uten å bruke `needs_drop` eksplisitt.
/// Typer som [`HashMap`], derimot, må slippe verdiene en om gangen og bør bruke denne APIen.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Her er et eksempel på hvordan en samling kan bruke `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // slipp dataene
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Returnerer verdien av typen `T` representert med byte-mønsteret helt null.
///
/// Dette betyr at for eksempel polstringsbyte i `(u8, u16)` ikke nødvendigvis nullstilles.
///
/// Det er ingen garanti for at et byte-mønster helt null representerer en gyldig verdi av en eller annen type `T`.
/// For eksempel er ikke alt-byte-mønsteret en gyldig verdi for referansetyper (`&T`, `&mut T`) og funksjonspekere.
/// Bruk av `zeroed` på slike typer fører til umiddelbar [undefined behavior][ub] fordi [the Rust compiler assumes][inv] at det alltid er en gyldig verdi i en variabel den anser som initialisert.
///
///
/// Dette har samme effekt som [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Det er nyttig for FFI noen ganger, men bør generelt unngås.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Riktig bruk av denne funksjonen: initialisering av et heltall med null.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Feil* bruk av denne funksjonen: initialisering av en referanse med null.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Udefinert oppførsel!
/// let _y: fn() = unsafe { mem::zeroed() }; // Og igjen!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SIKKERHET: innringeren må garantere at en null-verdi er gyldig for `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Omgår Rust s normale minneinitialiseringskontroller ved å late som å produsere en verdi av typen `T`, mens du ikke gjør noe i det hele tatt.
///
/// **Denne funksjonen er avviklet.** Bruk [`MaybeUninit<T>`] i stedet.
///
/// Årsaken til avskrivning er at funksjonen i utgangspunktet ikke kan brukes riktig: den har samme effekt som [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Som [`assume_init` documentation][assume_init] forklarer, [the Rust compiler assumes][inv] at verdiene er riktig initialisert.
/// Som en konsekvens av å ringe f.eks
/// `mem::uninitialized::<bool>()` forårsaker umiddelbar udefinert oppførsel for å returnere en `bool` som ikke definitivt er hverken `true` eller `false`.
/// Verre, virkelig uinitialisert minne som det som blir returnert her, er spesielt ved at kompilatoren vet at den ikke har en fast verdi.
/// Dette gjør det udefinerte oppførselen å ha ikke-initialiserte data i en variabel selv om variabelen har en heltallstype.
/// (Legg merke til at reglene rundt uinitialiserte heltall ikke er ferdig ennå, men inntil de er det, anbefales det å unngå dem.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SIKKERHET: innringeren må garantere at en enhetlig verdi er gyldig for `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Bytter verdiene på to mutable steder, uten å avinitialisere noen av dem.
///
/// * Hvis du vil bytte med en standard-eller dummyverdi, se [`take`].
/// * Hvis du vil bytte med en godkjent verdi, og returnere den gamle verdien, se [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SIKKERHET: råpekerne er opprettet fra trygge, mutable referanser som tilfredsstiller alle
    // begrensninger på `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Erstatter `dest` med standardverdien `T`, og returnerer den forrige `dest`-verdien.
///
/// * Hvis du vil erstatte verdiene til to variabler, se [`swap`].
/// * Hvis du vil erstatte med en bestått verdi i stedet for standardverdien, se [`replace`].
///
/// # Examples
///
/// Et enkelt eksempel:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` tillater å ta eierskap til et strukturfelt ved å erstatte det med en "empty"-verdi.
/// Uten `take` kan du støte på problemer som disse:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Merk at `T` ikke nødvendigvis implementerer [`Clone`], så det kan ikke engang klone og tilbakestille `self.buf`.
/// Men `take` kan brukes til å koble den opprinnelige verdien av `self.buf` fra `self`, slik at den kan returneres:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Flytter `src` til den refererte `dest`, og returnerer den forrige `dest`-verdien.
///
/// Ingen av verdiene faller.
///
/// * Hvis du vil erstatte verdiene til to variabler, se [`swap`].
/// * Hvis du vil erstatte med en standardverdi, se [`take`].
///
/// # Examples
///
/// Et enkelt eksempel:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` tillater forbruk av et strukturfelt ved å erstatte det med en annen verdi.
/// Uten `replace` kan du støte på problemer som disse:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Merk at `T` ikke nødvendigvis implementerer [`Clone`], så vi kan ikke engang klone `self.buf[i]` for å unngå flyttingen.
/// Men `replace` kan brukes til å koble fra den opprinnelige verdien ved den indeksen fra `self`, slik at den kan returneres:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SIKKERHET: Vi leser fra `dest`, men skriver `src` direkte inn i den etterpå,
    // slik at den gamle verdien ikke dupliseres.
    // Ingenting blir droppet, og ingenting her kan panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Avhender en verdi.
///
/// Dette gjøres ved å kalle argumentets implementering av [`Drop`][drop].
///
/// Dette gjør effektivt ingenting for typer som implementerer `Copy`, f.eks
/// integers.
/// Slike verdier kopieres og _then_ flyttes inn i funksjonen, så verdien vedvarer etter denne funksjonssamtalen.
///
///
/// Denne funksjonen er ikke magisk;det er bokstavelig talt definert som
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Fordi `_x` flyttes inn i funksjonen, slippes den automatisk før funksjonen returnerer.
///
/// [drop]: Drop
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // slipp vector eksplisitt
/// ```
///
/// Siden [`RefCell`] håndhever lånereglene ved kjøretid, kan `drop` frigjøre et [`RefCell`]-lån:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // gi avkall på det mutable lånet på dette sporet
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Heltall og andre typer som implementerer [`Copy`] påvirkes ikke av `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // en kopi av `x` flyttes og slippes
/// drop(y); // en kopi av `y` flyttes og slippes
///
/// println!("x: {}, y: {}", x, y.0); // fortsatt tilgjengelig
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Tolker `src` som å ha typen `&U`, og leser deretter `src` uten å flytte den inneholdte verdien.
///
/// Denne funksjonen antar usikkert at pekeren `src` er gyldig for [`size_of::<U>`][size_of] byte ved å overføre `&T` til `&U` og deretter lese `&U` (bortsett fra at dette gjøres på en måte som er riktig selv når `&U` stiller strengere justeringskrav enn `&T`).
/// Det vil også usikkert lage en kopi av den innholdte verdien i stedet for å flytte ut av `src`.
///
/// Det er ikke en kompilasjonsfeil hvis `T` og `U` har forskjellige størrelser, men det oppfordres sterkt til bare å påkalle denne funksjonen der `T` og `U` har samme størrelse.Denne funksjonen utløser [undefined behavior][ub] hvis `U` er større enn `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopier dataene fra 'foo_array' og behandle dem som en 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Endre de kopierte dataene
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Innholdet i 'foo_array' burde ikke ha endret seg
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Hvis U har et høyere justeringskrav, kan det hende at src ikke er riktig justert.
    if align_of::<U>() > align_of::<T>() {
        // SIKKERHET: `src` er en referanse som garantert er gyldig for lesing.
        // Innringeren må garantere at selve transmutasjonen er trygg.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SIKKERHET: `src` er en referanse som garantert er gyldig for lesing.
        // Vi sjekket nettopp at `src as *const U` var riktig justert.
        // Innringeren må garantere at selve transmutasjonen er trygg.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Ugjennomsiktig type som representerer enumets diskriminant.
///
/// Se [`discriminant`]-funksjonen i denne modulen for mer informasjon.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Disse trait-implementeringene kan ikke utledes fordi vi ikke vil ha noen grenser på T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Returnerer en verdi som unikt identifiserer enum-varianten i `v`.
///
/// Hvis `T` ikke er enum, vil ikke ringing av denne funksjonen resultere i udefinert oppførsel, men returverdien er uspesifisert.
///
///
/// # Stability
///
/// Diskriminanten av enum-varianten kan endres hvis definisjonen av enum endres.
/// En diskriminant av en eller annen variant vil ikke skifte mellom kompileringer med samme kompilator.
///
/// # Examples
///
/// Dette kan brukes til å sammenligne enums som bærer data, mens man ser bort fra de faktiske dataene:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Returnerer antall varianter i enumtypen `T`.
///
/// Hvis `T` ikke er enum, vil ikke ringing av denne funksjonen resultere i udefinert oppførsel, men returverdien er uspesifisert.
/// Tilsvarende, hvis `T` er et enum med flere varianter enn `usize::MAX`, er returverdien uspesifisert.
/// Ubebodde varianter vil telles.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}