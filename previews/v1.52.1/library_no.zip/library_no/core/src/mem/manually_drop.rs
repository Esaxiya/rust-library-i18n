use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// En innpakning som hindrer kompilatoren i å automatisk ringe `T`s destruktør.
/// Denne innpakningen koster 0.
///
/// `ManuallyDrop<T>` er underlagt samme layoutoptimaliseringer som `T`.
/// Som en konsekvens har det *ingen effekt* på forutsetningene som kompilatoren gjør om innholdet.
/// Initialisering av en `ManuallyDrop<&mut T>` med [`mem::zeroed`] er for eksempel udefinert oppførsel.
/// Hvis du trenger å håndtere uinitialiserte data, bruk [`MaybeUninit<T>`] i stedet.
///
/// Merk at tilgang til verdien i en `ManuallyDrop<T>` er trygg.
/// Dette betyr at en `ManuallyDrop<T>` hvis innhold er sluppet ikke må eksponeres gjennom et offentlig trygt API.
/// Tilsvarende er `ManuallyDrop::drop` usikre.
///
/// # `ManuallyDrop` og slipp ordren.
///
/// Rust har en veldefinert [drop order] av verdier.
/// For å sikre at felt eller lokalbefolkningen blir droppet i en bestemt rekkefølge, må du omorganisere erklæringen slik at den implisitte slippordren er riktig.
///
/// Det er mulig å bruke `ManuallyDrop` for å kontrollere slippordren, men dette krever usikker kode og det er vanskelig å gjøre riktig i nærvær av avvikling.
///
///
/// Hvis du for eksempel vil sørge for at et bestemt felt blir droppet etter de andre, må du gjøre det til det siste feltet i en struktur:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` vil bli droppet etter `children`.
///     // Rust garanterer at felt blir droppet i erklæringsrekkefølgen.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Pakk inn en verdi som skal slippes manuelt.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Du kan fortsatt trygt betjene verdien
    /// assert_eq!(*x, "Hello");
    /// // Men `Drop` vil ikke kjøres her
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Henter ut verdien fra `ManuallyDrop`-beholderen.
    ///
    /// Dette gjør at verdien kan slippes igjen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Dette dropper `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Tar ut verdien fra `ManuallyDrop<T>`-beholderen.
    ///
    /// Denne metoden er primært ment for å flytte ut verdier i fall.
    /// I stedet for å bruke [`ManuallyDrop::drop`] til å slippe verdien manuelt, kan du bruke denne metoden til å ta verdien og bruke den uansett hvor ønsket.
    ///
    /// Når det er mulig, er det å foretrekke å bruke [`into_inner`][`ManuallyDrop::into_inner`] i stedet, noe som forhindrer duplisering av innholdet i `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Denne funksjonen flytter semantisk den innholdsverdien uten å forhindre videre bruk, og etterlater tilstanden til denne beholderen uendret.
    /// Det er ditt ansvar å sørge for at denne `ManuallyDrop` ikke brukes igjen.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SIKKERHET: vi leser fra en referanse, som er garantert
        // å være gyldig for lesinger.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Slipper den inneholdte verdien manuelt.Dette tilsvarer nøyaktig å ringe [`ptr::drop_in_place`] med en peker til den innholdsverdien.
    /// Med mindre den innholdte verdien er en pakket struktur, vil destruktøren kalles på plass uten å flytte verdien, og kan dermed brukes til å trygt slippe [pinned]-data.
    ///
    /// Hvis du har eierskap til verdien, kan du bruke [`ManuallyDrop::into_inner`] i stedet.
    ///
    /// # Safety
    ///
    /// Denne funksjonen kjører destruktoren for den innholdte verdien.
    /// Annet enn endringer gjort av destruktoren selv, blir minnet uendret, og så langt som kompilatoren gjelder, har det fortsatt et bitmønster som er gyldig for typen `T`.
    ///
    ///
    /// Denne "zombie"-verdien skal imidlertid ikke utsettes for sikker kode, og denne funksjonen skal ikke kalles mer enn en gang.
    /// Å bruke en verdi etter at den er falt, eller slippe en verdi flere ganger, kan forårsake udefinert oppførsel (avhengig av hva `drop` gjør).
    /// Dette forhindres normalt av typesystemet, men brukere av `ManuallyDrop` må opprettholde disse garantiene uten hjelp fra kompilatoren.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SIKKERHET: vi slipper verdien som er pekt på med en foranderlig referanse
        // som garantert er gyldig for skriv.
        // Det er opp til den som ringer å sørge for at `slot` ikke slippes igjen.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}