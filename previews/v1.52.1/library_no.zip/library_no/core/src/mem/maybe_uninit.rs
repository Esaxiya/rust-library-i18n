use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// En innpakningstype for å konstruere uinitialiserte forekomster av `T`.
///
/// # Initialisering invariant
///
/// Kompilatoren antar generelt at en variabel er riktig initialisert i henhold til kravene til variabelens type.For eksempel må en variabel av referansetypen være justert og ikke-NULL.
/// Dette er en invariant som *alltid* må opprettholdes, selv i usikker kode.
/// Som en konsekvens forårsaker nullinitialisering av en variabel av referansetype øyeblikkelig [undefined behavior][ub], uansett om referansen noen gang blir vant til å få tilgang til minne:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // udefinert oppførsel!⚠️
/// // Tilsvarende kode med `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // udefinert oppførsel!⚠️
/// ```
///
/// Dette utnyttes av kompilatoren til forskjellige optimaliseringer, for eksempel å fjerne kjøretidskontroller og optimalisere `enum`-layout.
///
/// På samme måte kan helt uinitialisert minne ha noe innhold, mens en `bool` alltid må være `true` eller `false`.Derfor er å opprette en ikke-initialisert `bool` udefinert oppførsel:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // udefinert oppførsel!⚠️
/// // Tilsvarende kode med `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // udefinert oppførsel!⚠️
/// ```
///
/// Videre er ikke-initialisert minne spesielt fordi det ikke har en fast verdi ("fixed" som betyr "it won't change without being written to").Å lese den samme ikke-initialiserte byten flere ganger kan gi forskjellige resultater.
/// Dette gjør det udefinerte oppførselen å ha ikke-initialiserte data i en variabel selv om variabelen har en heltallstype, som ellers kan ha et hvilket som helst *fast* bitmønster:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // udefinert oppførsel!⚠️
/// // Tilsvarende kode med `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // udefinert oppførsel!⚠️
/// ```
/// (Legg merke til at reglene rundt uinitialiserte heltall ikke er ferdig ennå, men inntil de er det, anbefales det å unngå dem.)
///
/// På toppen av det, husk at de fleste typer har flere invarianter utover bare å bli ansett som initialisert på typenivå.
/// For eksempel anses en `1`-initialisert [`Vec<T>`] som initialisert (under den nåværende implementeringen; dette utgjør ikke en stabil garanti) fordi det eneste kravet kompilatoren vet om det er at datapekeren må være ikke-null.
/// Å lage en slik `Vec<T>` forårsaker ikke *umiddelbar* udefinert oppførsel, men vil føre til udefinert oppførsel med de mest sikre operasjonene (inkludert å slippe den).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` tjener til å gjøre det mulig for usikker kode å håndtere uinitialiserte data.
/// Det er et signal til kompilatoren som indikerer at dataene her kanskje ikke * initialiseres:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Lag en eksplisitt ikke-initialisert referanse.
/// // Kompilatoren vet at data i en `MaybeUninit<T>` kan være ugyldige, og derfor er dette ikke UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Sett den til en gyldig verdi.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Pakk ut de initialiserte dataene-dette er kun tillatt *etter* riktig initialisering av `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Kompilatoren vet da å ikke gjøre noen feil forutsetninger eller optimaliseringer på denne koden.
///
/// Du kan tenke på `MaybeUninit<T>` som å være litt som `Option<T>`, men uten sporing av kjøretiden og uten sikkerhetskontroller.
///
/// ## out-pointers
///
/// Du kan bruke `MaybeUninit<T>` til å implementere "out-pointers": i stedet for å returnere data fra en funksjon, send den en peker til noe (uninitialized)-minne for å legge resultatet inn.
/// Dette kan være nyttig når det er viktig for innringeren å kontrollere hvordan minnet resultatet blir lagret i, og du vil unngå unødvendige trekk.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` slipper ikke det gamle innholdet, noe som er viktig.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nå vet vi at `v` er initialisert!Dette sørger også for at vector blir skikkelig droppet.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initialisere en matrise element for element
///
/// `MaybeUninit<T>` kan brukes til å initialisere et stort utvalg element for element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Lag et ikke-initialisert utvalg av `MaybeUninit`.
///     // `assume_init` er trygt fordi den typen vi hevder å ha initialisert her er en haug med 'MaybeUninit`s, som ikke krever initialisering.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Å slippe en `MaybeUninit` gjør ingenting.
///     // Dermed fører ikke bruk av rå pekertilordning i stedet for `ptr::write` til at den gamle ikke-initialiserte verdien blir droppet.
/////
///     // Også hvis det er en panic i løpet av denne sløyfen, har vi en minnelekkasje, men det er ikke noe minnesikkerhetsproblem.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Alt er initialisert.
///     // Overfør matrisen til den initialiserte typen.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Du kan også arbeide med delvis initialiserte matriser, som kan bli funnet i datastrukturer på lavt nivå.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Lag et ikke-initialisert utvalg av `MaybeUninit`.
/// // `assume_init` er trygt fordi den typen vi hevder å ha initialisert her er en haug med 'MaybeUninit`s, som ikke krever initialisering.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Tell antall elementer vi har tildelt.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // For hvert element i matrisen, slipp hvis vi tildelte den.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initialisere en struktur felt for felt
///
/// Du kan bruke `MaybeUninit<T>` og [`std::ptr::addr_of_mut`]-makroen til å initialisere strukturer felt for felt:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initialiserer `name`-feltet
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initialisere `list`-feltet Hvis det er en panic her, lekker `String` i `name`-feltet.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Alle feltene er initialisert, så vi kaller `assume_init` for å få en initialisert Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` er garantert å ha samme størrelse, justering og ABI som `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Husk imidlertid at en type *som inneholder* en `MaybeUninit<T>` ikke nødvendigvis er den samme utformingen;Rust garanterer generelt ikke at feltene til en `Foo<T>` har samme rekkefølge som en `Foo<U>`, selv om `T` og `U` har samme størrelse og justering.
///
/// Videre fordi en hvilken som helst bitverdi er gyldig for en `MaybeUninit<T>`, kan ikke kompilatoren bruke non-zero/niche-filling-optimaliseringer, noe som potensielt kan resultere i en større størrelse:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Hvis `T` er FFI-trygt, er det også `MaybeUninit<T>`.
///
/// Mens `MaybeUninit` er `#[repr(transparent)]` (noe som indikerer at den garanterer samme størrelse, justering og ABI som `T`), endrer dette ikke * noen av de tidligere advarslene.
/// `Option<T>` og `Option<MaybeUninit<T>>` kan fremdeles ha forskjellige størrelser, og typer som inneholder et felt av typen `T` kan legges ut (og dimensjoneres) annerledes enn om dette feltet var `MaybeUninit<T>`.
/// `MaybeUninit` er en unionstype, og `#[repr(transparent)]` på fagforeninger er ustabil (se [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Over tid kan de nøyaktige garantiene for `#[repr(transparent)]` på fagforeninger utvikle seg, og `MaybeUninit` kan eller ikke forbli `#[repr(transparent)]`.
/// Når det er sagt, vil `MaybeUninit<T>`*alltid* garantere at den har samme størrelse, justering og ABI som `T`;det er bare slik `MaybeUninit` implementerer den garantien kan utvikle seg.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang element slik at vi kan pakke inn andre typer i det.Dette er nyttig for generatorer.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Vi ringer ikke `T::clone()`, vi kan ikke vite om vi er initialisert nok til det.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Oppretter en ny `MaybeUninit<T>` initialisert med den gitte verdien.
    /// Det er trygt å ringe [`assume_init`] på returverdien til denne funksjonen.
    ///
    /// Merk at å slippe en `MaybeUninit<T>` aldri vil kalle `T`s slippkode.
    /// Det er ditt ansvar å sørge for at `T` blir droppet hvis den blir initialisert.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Oppretter en ny `MaybeUninit<T>` i uinitialisert tilstand.
    ///
    /// Merk at å slippe en `MaybeUninit<T>` aldri vil kalle `T`s slippkode.
    /// Det er ditt ansvar å sørge for at `T` blir droppet hvis den blir initialisert.
    ///
    /// Se [type-level documentation][MaybeUninit] for noen eksempler.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Opprett et nytt utvalg av `MaybeUninit<T>`-elementer i uinitialisert tilstand.
    ///
    /// Note: i en future Rust-versjon kan denne metoden bli unødvendig når ordbokstavelig syntaks tillater [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Eksemplet nedenfor kan da bruke `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Returnerer et (muligens mindre) stykke data som faktisk ble lest
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SIKKERHET: En ikke-initialisert `[MaybeUninit<_>; LEN]` er gyldig.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Oppretter en ny `MaybeUninit<T>` i uinitialisert tilstand, med minnet fylt med `0` byte.Det avhenger av `T` om det allerede gir riktig initialisering.
    ///
    /// For eksempel initialiseres `MaybeUninit<usize>::zeroed()`, men `MaybeUninit<&'static i32>::zeroed()` er ikke fordi referanser ikke må være null.
    ///
    /// Merk at å slippe en `MaybeUninit<T>` aldri vil kalle `T`s slippkode.
    /// Det er ditt ansvar å sørge for at `T` blir droppet hvis den blir initialisert.
    ///
    /// # Example
    ///
    /// Riktig bruk av denne funksjonen: initialisering av en struktur med null, der alle felt i strukturen kan holde bitmønsteret 0 som en gyldig verdi.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Feil* bruk av denne funksjonen: ringe til `x.zeroed().assume_init()` når `0` ikke er et gyldig bitmønster for typen:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Inne i et par lager vi en `NotZero` som ikke har en gyldig diskriminant.
    /// // Dette er udefinert oppførsel.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SIKKERHET: `u.as_mut_ptr()` peker på tildelt minne.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Angir verdien på `MaybeUninit<T>`.
    /// Dette overskriver tidligere verdier uten å slippe det, så vær forsiktig så du ikke bruker dette to ganger med mindre du vil hoppe over å kjøre destruktoren.
    ///
    /// For din bekvemmelighet returnerer dette også en foranderlig referanse til (nå trygt initialisert) innhold i `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SIKKERHET: Vi initialiserte nettopp denne verdien.
        unsafe { self.assume_init_mut() }
    }

    /// Får en peker til den inneholdte verdien.
    /// Å lese fra denne pekeren eller gjøre den om til en referanse er udefinert oppførsel med mindre `MaybeUninit<T>` initialiseres.
    /// Å skrive til minnet som denne pekeren (non-transitively) peker på, er udefinert oppførsel (unntatt inne i en `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Riktig bruk av denne metoden:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Lag en referanse til `MaybeUninit<T>`.Dette er greit fordi vi initialiserte det.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Feil* bruk av denne metoden:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Vi har opprettet en referanse til en ikke-initialisert vector!Dette er udefinert oppførsel.⚠️
    /// ```
    ///
    /// (Legg merke til at reglene rundt referanser til ikke-initialiserte data ikke er endelige ennå, men inntil de er det, anbefales det å unngå dem.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` og `ManuallyDrop` er begge `repr(transparent)` slik at vi kan kaste pekeren.
        self as *const _ as *const T
    }

    /// Får en muterbar peker til den inneholdte verdien.
    /// Å lese fra denne pekeren eller gjøre den om til en referanse er udefinert oppførsel med mindre `MaybeUninit<T>` initialiseres.
    ///
    /// # Examples
    ///
    /// Riktig bruk av denne metoden:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Lag en referanse til `MaybeUninit<Vec<u32>>`.
    /// // Dette er greit fordi vi initialiserte det.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Feil* bruk av denne metoden:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Vi har opprettet en referanse til en ikke-initialisert vector!Dette er udefinert oppførsel.⚠️
    /// ```
    ///
    /// (Legg merke til at reglene rundt referanser til ikke-initialiserte data ikke er endelige ennå, men inntil de er det, anbefales det å unngå dem.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` og `ManuallyDrop` er begge `repr(transparent)` slik at vi kan kaste pekeren.
        self as *mut _ as *mut T
    }

    /// Henter ut verdien fra `MaybeUninit<T>`-beholderen.Dette er en fin måte å sikre at dataene slippes, fordi den resulterende `T` er underlagt den vanlige fallhåndteringen.
    ///
    /// # Safety
    ///
    /// Det er opp til den som ringer å garantere at `MaybeUninit<T>` virkelig er i en initialisert tilstand.Å kalle dette når innholdet ennå ikke er fullstendig initialisert, forårsaker umiddelbar udefinert oppførsel.
    /// [type-level documentation][inv] inneholder mer informasjon om denne initialiseringsvarianten.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// På toppen av det, husk at de fleste typer har flere invarianter utover bare å bli ansett som initialisert på typenivå.
    /// For eksempel anses en `1`-initialisert [`Vec<T>`] som initialisert (under den nåværende implementeringen; dette utgjør ikke en stabil garanti) fordi det eneste kravet kompilatoren vet om det er at datapekeren må være ikke-null.
    ///
    /// Å lage en slik `Vec<T>` forårsaker ikke *umiddelbar* udefinert oppførsel, men vil føre til udefinert oppførsel med de mest sikre operasjonene (inkludert å slippe den).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Riktig bruk av denne metoden:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Feil* bruk av denne metoden:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` hadde ikke blitt initialisert ennå, så denne siste linjen forårsaket udefinert oppførsel.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SIKKERHET: innringeren må garantere at `self` er initialisert.
        // Dette betyr også at `self` må være en `value`-variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Leser verdien fra `MaybeUninit<T>`-beholderen.Den resulterende `T` er underlagt den vanlige fallhåndteringen.
    ///
    /// Når det er mulig, er det å foretrekke å bruke [`assume_init`] i stedet, noe som forhindrer duplisering av innholdet i `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Det er opp til den som ringer å garantere at `MaybeUninit<T>` virkelig er i en initialisert tilstand.Å kalle dette når innholdet ennå ikke er fullstendig initialisert, forårsaker udefinert oppførsel.
    /// [type-level documentation][inv] inneholder mer informasjon om denne initialiseringsvarianten.
    ///
    /// Videre etterlater dette en kopi av de samme dataene i `MaybeUninit<T>`.
    /// Når du bruker flere kopier av dataene (ved å ringe `assume_init_read` flere ganger, eller først ringe `assume_init_read` og deretter [`assume_init`]), er det ditt ansvar å sørge for at disse dataene faktisk kan dupliseres.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Riktig bruk av denne metoden:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` er `Copy`, så vi kan lese flere ganger.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Det er greit å duplisere en `None`-verdi, så vi kan lese flere ganger.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Feil* bruk av denne metoden:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Vi opprettet nå to eksemplarer av den samme vector, noe som fører til en dobbeltfri ⚠️ når de begge blir droppet!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SIKKERHET: innringeren må garantere at `self` er initialisert.
        // Det er trygt å lese fra `self.as_ptr()` siden `self` bør initialiseres.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Dropper den inneholdte verdien på plass.
    ///
    /// Hvis du har eierskap til `MaybeUninit`, kan du bruke [`assume_init`] i stedet.
    ///
    /// # Safety
    ///
    /// Det er opp til den som ringer å garantere at `MaybeUninit<T>` virkelig er i en initialisert tilstand.Å kalle dette når innholdet ennå ikke er fullstendig initialisert, forårsaker udefinert oppførsel.
    ///
    /// På toppen av det må alle ekstra invarianter av typen `T` være fornøyd, da `Drop`-implementeringen av `T` (eller dets medlemmer) kan stole på dette.
    /// For eksempel anses en `1`-initialisert [`Vec<T>`] som initialisert (under den nåværende implementeringen; dette utgjør ikke en stabil garanti) fordi det eneste kravet kompilatoren vet om det er at datapekeren må være ikke-null.
    ///
    /// Å slippe en slik `Vec<T>` vil imidlertid føre til udefinert oppførsel.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SIKKERHET: innringeren må garantere at `self` er initialisert og
        // tilfredsstiller alle invarianter av `T`.
        // Å slippe verdien på plass er trygt hvis det er tilfelle.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Får en delt referanse til den inneholdte verdien.
    ///
    /// Dette kan være nyttig når vi vil ha tilgang til en `MaybeUninit` som er initialisert, men ikke har eierskap til `MaybeUninit` (som forhindrer bruk av `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Å ringe dette når innholdet ennå ikke er fullstendig initialisert, forårsaker udefinert oppførsel: det er opp til den som ringer å garantere at `MaybeUninit<T>` virkelig er i en initialisert tilstand.
    ///
    ///
    /// # Examples
    ///
    /// ### Riktig bruk av denne metoden:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialiser `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nå som `MaybeUninit<_>` er kjent for å være initialisert, er det greit å lage en delt referanse til den:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SIKKERHET: `x` er initialisert.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Feil* bruk av denne metoden:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Vi har opprettet en referanse til en ikke-initialisert vector!Dette er udefinert oppførsel.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialiser `MaybeUninit` ved hjelp av `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Henvisning til en ikke-initialisert `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SIKKERHET: innringeren må garantere at `self` er initialisert.
        // Dette betyr også at `self` må være en `value`-variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Får en muterbar (unique)-referanse til den innholdte verdien.
    ///
    /// Dette kan være nyttig når vi vil ha tilgang til en `MaybeUninit` som er initialisert, men ikke har eierskap til `MaybeUninit` (som forhindrer bruk av `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Å ringe dette når innholdet ennå ikke er fullstendig initialisert, forårsaker udefinert oppførsel: det er opp til den som ringer å garantere at `MaybeUninit<T>` virkelig er i en initialisert tilstand.
    /// For eksempel kan ikke `.assume_init_mut()` brukes til å initialisere en `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Riktig bruk av denne metoden:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initialiserer *alle* byte i inndatabufferen.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialiser `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nå vet vi at `buf` er initialisert, så vi kunne `.assume_init()` det.
    /// // Imidlertid kan bruk av `.assume_init()` utløse en `memcpy` av 2048 byte.
    /// // For å hevde at bufferen vår er initialisert uten å kopiere den, oppgraderer vi `&mut MaybeUninit<[u8; 2048]>` til en `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SIKKERHET: `buf` er initialisert.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nå kan vi bruke `buf` som et vanlig stykke:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Feil* bruk av denne metoden:
    ///
    /// Du kan ikke bruke `.assume_init_mut()` til å initialisere en verdi:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Vi har opprettet en (mutable)-referanse til en ikke-initialisert `bool`!
    ///     // Dette er udefinert oppførsel.⚠️
    /// }
    /// ```
    ///
    /// For eksempel kan du ikke [`Read`] til en ikke-initialisert buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referanse til uinitialisert minne!
    ///                             // Dette er udefinert oppførsel.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Du kan heller ikke bruke direkte feltadgang for å utføre gradvis initialisering felt for felt:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referanse til uinitialisert minne!
    ///                  // Dette er udefinert oppførsel.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referanse til uinitialisert minne!
    ///                  // Dette er udefinert oppførsel.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Vi stoler for tiden på at ovenstående er feil, dvs. at vi har referanser til ikke-initialiserte data (f.eks. I `libcore/fmt/float.rs`).
    // Vi bør ta en endelig beslutning om reglene før stabilisering.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SIKKERHET: innringeren må garantere at `self` er initialisert.
        // Dette betyr også at `self` må være en `value`-variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Henter ut verdiene fra en rekke `MaybeUninit`-containere.
    ///
    /// # Safety
    ///
    /// Det er opp til innringeren å garantere at alle elementene i matrisen er i en initialisert tilstand.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SIKKERHET: Nå trygt da vi initialiserte alle elementene
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Innringeren garanterer at alle elementene i matrisen initialiseres
        // * `MaybeUninit<T>` og T har garantert samme oppsett
        // * MaybeUnint faller ikke, så det er ingen dobbeltfriheter og dermed er konverteringen trygg
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Forutsatt at alle elementene er initialisert, få et stykke til dem.
    ///
    /// # Safety
    ///
    /// Det er opp til innringeren å garantere at `MaybeUninit<T>`-elementene virkelig er i en initialisert tilstand.
    ///
    /// Å kalle dette når innholdet ennå ikke er fullstendig initialisert, forårsaker udefinert oppførsel.
    ///
    /// Se [`assume_init_ref`] for mer informasjon og eksempler.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SIKKERHET: å kaste skiver til en `*const [T]` er trygt siden innringeren garanterer det
        // `slice` er initialisert, og `MaybeUninit` har garantert samme oppsett som `T`.
        // Den oppnådde pekeren er gyldig siden den refererer til minne som eies av `slice`, som er en referanse og dermed garantert å være gyldig for lesing.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Forutsatt at alle elementene er initialisert, få et foranderlig stykke til dem.
    ///
    /// # Safety
    ///
    /// Det er opp til innringeren å garantere at `MaybeUninit<T>`-elementene virkelig er i en initialisert tilstand.
    ///
    /// Å kalle dette når innholdet ennå ikke er fullstendig initialisert, forårsaker udefinert oppførsel.
    ///
    /// Se [`assume_init_mut`] for mer informasjon og eksempler.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SIKKERHET: ligner sikkerhetsmerknader for `slice_get_ref`, men vi har en
        // foranderlig referanse som garantert også er gyldig for skrivinger.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Får en peker til det første elementet i matrisen.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Får en muterbar peker til det første elementet i matrisen.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopierer elementene fra `src` til `this`, og returnerer en foranderlig referanse til det nå initaliserte innholdet i `this`.
    ///
    /// Hvis `T` ikke implementerer `Copy`, bruk [`write_slice_cloned`]
    ///
    /// Dette ligner på [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Denne funksjonen vil panic hvis de to skivene har forskjellige lengder.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIKKERHET: vi har nettopp kopiert alle elementene i len til ledig kapasitet
    /// // de første src.len()-elementene i vec er gyldige nå.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SIKKERHET: &[T] og&[MaybeUninit<T>] har samme layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SIKKERHET: Gyldige elementer er nettopp kopiert til `this`, så det er initalisert
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Kloner elementene fra `src` til `this`, og returnerer en foranderlig referanse til det nå initaliserte innholdet i `this`.
    /// Eventuelle allerede initaliserte elementer vil ikke bli droppet.
    ///
    /// Hvis `T` implementerer `Copy`, bruk [`write_slice`]
    ///
    /// Dette ligner på [`slice::clone_from_slice`], men slipper ikke eksisterende elementer.
    ///
    /// # Panics
    ///
    /// Denne funksjonen vil panic hvis de to skivene har forskjellige lengder, eller hvis implementeringen av `Clone` panics.
    ///
    /// Hvis det er en panic, vil de allerede klonede elementene bli droppet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIKKERHET: vi har nettopp klonet alle elementene i len i ledig kapasitet
    /// // de første src.len()-elementene i vec er gyldige nå.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // i motsetning til copy_from_slice kaller dette ikke clone_from_slice på segmentet, dette er fordi `MaybeUninit<T: Clone>` ikke implementerer Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SIKKERHET: dette rå stykket inneholder bare initialiserte objekter
                // det er derfor det er lov å slippe det.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Vi må eksplisitt skjære dem i samme lengde
        // for at grensekontroll skal elides, og optimalisereren vil generere memcpy for enkle saker (for eksempel T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // vakt er nødvendig b/c panic kan skje under en klone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SIKKERHET: Gyldige elementer er nettopp skrevet inn i `this`, så det er initalisert
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}