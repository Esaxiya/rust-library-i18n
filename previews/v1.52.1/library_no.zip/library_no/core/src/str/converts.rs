//! Måter å lage en `str` fra byte-skive.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konverterer en bit byte til en strengdel.
///
/// En strengskive ([`&str`]) er laget av byte ([`u8`]), og en bitskive ([`&[u8]`][byteslice]) er laget av byte, så denne funksjonen konverterer mellom de to.
/// Ikke alle byte-skiver er gyldige strengskiver, men: [`&str`] krever at den er gyldig UTF-8.
/// `from_utf8()` sjekker for å sikre at byte er gyldige UTF-8, og gjør deretter konverteringen.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Hvis du er sikker på at bytesnittet er gyldig UTF-8, og du ikke vil pådra deg overhead av gyldighetskontrollen, er det en usikker versjon av denne funksjonen, [`from_utf8_unchecked`], som har samme oppførsel, men hopper over sjekken.
///
///
/// Hvis du trenger en `String` i stedet for en `&str`, bør du vurdere [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Fordi du kan stable-tildele en `[u8; N]`, og du kan ta en [`&[u8]`][byteslice] av den, er denne funksjonen en måte å ha en stack-allokert streng på.Det er et eksempel på dette i eksemplene nedenfor.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Returnerer `Err` hvis segmentet ikke er UTF-8 med en beskrivelse av hvorfor den medfølgende delen ikke er UTF-8.
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::str;
///
/// // noen byte, i en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Vi vet at disse byte er gyldige, så det er bare å bruke `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Feil byte:
///
/// ```
/// use std::str;
///
/// // noen ugyldige byte, i en vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Se dokumentene for [`Utf8Error`] for mer informasjon om hva slags feil som kan returneres.
///
/// En "stack allocated string":
///
/// ```
/// use std::str;
///
/// // noen byte, i en stabelallokert matrise
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Vi vet at disse byte er gyldige, så det er bare å bruke `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIKKERHET: Kjørte nettopp validering.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konverterer en foranderlig bitbit til en mutabel strengdel.
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" som en muterbar vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Som vi vet disse byte er gyldige, kan vi bruke `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Feil byte:
///
/// ```
/// use std::str;
///
/// // Noen ugyldige byte i en muterbar vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Se dokumentene for [`Utf8Error`] for mer informasjon om hva slags feil som kan returneres.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIKKERHET: Kjørte nettopp validering.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konverterer en bit byte til en strengbit uten å sjekke at strengen inneholder gyldig UTF-8.
///
/// Se den trygge versjonen, [`from_utf8`], for mer informasjon.
///
/// # Safety
///
/// Denne funksjonen er usikker fordi den ikke kontrollerer at byte som sendes til den er gyldige UTF-8.
/// Hvis denne begrensningen brytes, resulterer udefinert oppførsel, da resten av Rust antar at [`&str`] er gyldige UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::str;
///
/// // noen byte, i en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SIKKERHET: innringeren må garantere at bytene `v` er gyldige UTF-8.
    // Stoler også på at `&str` og `&[u8]` har samme layout.
    unsafe { mem::transmute(v) }
}

/// Konverterer en bit byte til en strengdel uten å sjekke at strengen inneholder gyldig UTF-8;muterbar versjon.
///
///
/// Se den uforanderlige versjonen, [`from_utf8_unchecked()`] for mer informasjon.
///
/// # Examples
///
/// Grunnleggende bruk:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SIKKERHET: innringeren må garantere at byte `v`
    // er gyldige UTF-8, og dermed er rollebesetningen til `*mut str` trygg.
    // Pekeren er ikke sikker fordi pekeren kommer fra en referanse som garantert er gyldig for skriving.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}