//! Trait-implementeringer for `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementerer bestilling av strenger.
///
/// Strenger ordnes [lexicographically](Ord#lexicographical-comparison) etter byteverdiene.
/// Dette bestiller Unicode-kodepunkter basert på deres posisjoner i kodekartene.
/// Dette er ikke nødvendigvis det samme som "alphabetical"-rekkefølgen, som varierer etter språk og sted.
/// Sortering av strenger i henhold til kulturelt aksepterte standarder krever stedsspesifikke data som er utenfor omfanget av `str`-typen.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementerer sammenligningsoperasjoner på strenger.
///
/// Strenger sammenlignes [lexicographically](Ord#lexicographical-comparison) med byteverdiene.
/// Dette sammenligner Unicode-kodepunkter basert på deres posisjoner i kodetabellene.
/// Dette er ikke nødvendigvis det samme som "alphabetical"-rekkefølgen, som varierer etter språk og sted.
/// Å sammenligne strenger i henhold til kulturelt aksepterte standarder krever stedsspesifikke data som er utenfor omfanget av `str`-typen.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementerer deling med syntaks `&self[..]` eller `&mut self[..]`.
///
/// Returnerer et stykke av hele strengen, dvs. returnerer `&self` eller `&mut self`.Tilsvarer `&selv [0 ..
/// len] `eller`&mut selv [0 ..
/// len]`.
/// I motsetning til andre indekseringsoperasjoner, kan dette aldri panic.
///
/// Denne operasjonen er *O*(1).
///
/// Før 1.20.0 ble disse indekseringsoperasjonene fortsatt støttet av direkte implementering av `Index` og `IndexMut`.
///
/// Tilsvarer `&self[0 .. len]` eller `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementerer deling med syntaks `&self[begin .. end]` eller `&mut self[begin .. end]`.
///
/// Returnerer et stykke av den gitte strengen fra byteområdet [`start", `end`).
///
/// Denne operasjonen er *O*(1).
///
/// Før 1.20.0 ble disse indekseringsoperasjonene fortsatt støttet av direkte implementering av `Index` og `IndexMut`.
///
/// # Panics
///
/// Panics hvis `begin` eller `end` ikke peker på startbyteforskyvning av et tegn (som definert av `is_char_boundary`), hvis `begin > end`, eller hvis `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // disse vil panic:
/// // byte 2 ligger innenfor `ö`:
/// // &s [2 ..3];
///
/// // byte 8 ligger innenfor `老`&s [1 ..
/// // 8];
///
/// // byte 100 er utenfor strengen&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIKKERHET: akkurat sjekket at `start` og `end` er på en røyegrense,
            // og vi sender i en sikker referanse, så returverdien vil også være en.
            // Vi sjekket også røyegrenser, så dette er gyldig UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIKKERHET: bare sjekket at `start` og `end` er på en røyegrense.
            // Vi vet at pekeren er unik fordi vi fikk den fra `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIKKERHET: innringeren garanterer at `self` er innenfor grensene til `slice`
        // som oppfyller alle betingelsene for `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIKKERHET: se kommentarer til `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary sjekker at indeksen er i [0, .len()] kan ikke gjenbruke `get` som ovenfor, på grunn av NLL-problemer
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIKKERHET: akkurat sjekket at `start` og `end` er på en røyegrense,
            // og vi sender i en sikker referanse, så returverdien vil også være en.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementerer deling med syntaks `&self[.. end]` eller `&mut self[.. end]`.
///
/// Returnerer et stykke av den gitte strengen fra byteområdet [`0`, `end`).
/// Tilsvarer `&self[0 .. end]` eller `&mut self[0 .. end]`.
///
/// Denne operasjonen er *O*(1).
///
/// Før 1.20.0 ble disse indekseringsoperasjonene fortsatt støttet av direkte implementering av `Index` og `IndexMut`.
///
/// # Panics
///
/// Panics hvis `end` ikke peker på startbyteforskyvning av et tegn (som definert av `is_char_boundary`), eller hvis `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIKKERHET: bare sjekket at `end` er på en røyegrense,
            // og vi sender i en sikker referanse, så returverdien vil også være en.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIKKERHET: bare sjekket at `end` er på en røyegrense,
            // og vi sender i en sikker referanse, så returverdien vil også være en.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SIKKERHET: bare sjekket at `end` er på en røyegrense,
            // og vi sender i en sikker referanse, så returverdien vil også være en.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementerer deling med syntaks `&self[begin ..]` eller `&mut self[begin ..]`.
///
/// Returnerer et stykke av den gitte strengen fra byteområdet [`start`, `len`).Tilsvarer `&selv [begynn ..
/// len] `eller`&mut selv [begynn ..
/// len]`.
///
/// Denne operasjonen er *O*(1).
///
/// Før 1.20.0 ble disse indekseringsoperasjonene fortsatt støttet av direkte implementering av `Index` og `IndexMut`.
///
/// # Panics
///
/// Panics hvis `begin` ikke peker på startbyteforskyvning av et tegn (som definert av `is_char_boundary`), eller hvis `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIKKERHET: bare sjekket at `start` er på en røyegrense,
            // og vi sender i en sikker referanse, så returverdien vil også være en.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIKKERHET: bare sjekket at `start` er på en røyegrense,
            // og vi sender i en sikker referanse, så returverdien vil også være en.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIKKERHET: innringeren garanterer at `self` er innenfor grensene til `slice`
        // som oppfyller alle betingelsene for `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIKKERHET: identisk med `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SIKKERHET: bare sjekket at `start` er på en røyegrense,
            // og vi sender i en sikker referanse, så returverdien vil også være en.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementerer deling med syntaks `&self[begin ..= end]` eller `&mut self[begin ..= end]`.
///
/// Returnerer et stykke av den gitte strengen fra byteområdet [`begin`, `end`].Tilsvarer `&self [begin .. end + 1]` eller `&mut self[begin .. end + 1]`, bortsett fra hvis `end` har maksimumsverdien for `usize`.
///
/// Denne operasjonen er *O*(1).
///
/// # Panics
///
/// Panics hvis `begin` ikke peker på startbyteforskyvning av et tegn (som definert av `is_char_boundary`), hvis `end` ikke peker på sluttbyteforskyvning av et tegn (`end + 1` er enten startbyteforskyvning eller lik `len`), hvis `begin > end`, eller hvis `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementerer deling med syntaks `&self[..= end]` eller `&mut self[..= end]`.
///
/// Returnerer et stykke av den gitte strengen fra byteområdet [0, `end`].
/// Tilsvarer `&self [0 .. end + 1]`, bortsett fra hvis `end` har maksimumsverdien for `usize`.
///
/// Denne operasjonen er *O*(1).
///
/// # Panics
///
/// Panics hvis `end` ikke peker på slutten av byteforskyvningen til et tegn (`end + 1` er enten en startbyteforskyvning som definert av `is_char_boundary`, eller lik `len`), eller hvis `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Parse en verdi fra en streng
///
/// `FromStr`s [`from_str`]-metode brukes ofte implisitt, gjennom [`str`] s [`parse`]-metode.
/// Se [``parse``s dokumentasjon for eksempler.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` har ikke en livstidsparameter, og så kan du bare analysere typer som ikke inneholder en levetidsparameter selv.
///
/// Med andre ord kan du analysere en `i32` med `FromStr`, men ikke en `&i32`.
/// Du kan analysere en struktur som inneholder en `i32`, men ikke en som inneholder en `&i32`.
///
/// # Examples
///
/// Grunnleggende implementering av `FromStr` på et eksempel på `Point`-typen:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Den tilhørende feilen som kan returneres fra analyse.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Deler en streng `s` for å returnere en verdi av denne typen.
    ///
    /// Hvis parsing lykkes, returnerer du verdien i [`Ok`], ellers returnerer en feil som er spesifikk for innsiden av [`Err`] når strengen er dårlig formatert.
    /// Feiltypen er spesifikk for implementering av trait.
    ///
    /// # Examples
    ///
    /// Grunnleggende bruk med [`i32`], en type som implementerer `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analyser en `bool` fra en streng.
    ///
    /// Gir en `Result<bool, ParseBoolError>`, fordi `s` faktisk kan eller ikke kan tolkes.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Merk, i mange tilfeller er `.parse()`-metoden på `str` mer riktig.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}