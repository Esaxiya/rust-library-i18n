//! En modul for arbeid med lånte data.

#![stable(feature = "rust1", since = "1.0.0")]

/// En trait for å låne data.
///
/// I Rust er det vanlig å gi forskjellige representasjoner av en type for forskjellige brukssaker.
/// For eksempel kan lagringssted og styring for en verdi spesifikt velges som passende for en bestemt bruk via pekertyper som [`Box<T>`] eller [`Rc<T>`].
/// Utover disse generiske innpakningene som kan brukes med alle typer, gir noen typer valgfrie fasetter som gir potensielt kostbar funksjonalitet.
/// Et eksempel på en slik type er [`String`] som gir muligheten til å utvide en streng til den grunnleggende [`str`].
/// Dette krever at tilleggsinformasjon holdes unødvendig for en enkel, uforanderlig streng.
///
/// Disse typene gir tilgang til de underliggende dataene gjennom referanser til typen av dataene.De sies å være "lånt som" den typen.
/// For eksempel kan en [`Box<T>`] lånes som `T` mens en [`String`] kan lånes som `str`.
///
/// Typer uttrykker at de kan lånes som en type `T` ved å implementere `Borrow<T>`, og gir en referanse til en `T` i trait s [`borrow`]-metode.En type er gratis å låne som flere forskjellige typer.
/// Hvis den ønsker å mutere lån som typen-slik at de underliggende dataene kan endres, kan den i tillegg implementere [`BorrowMut<T>`].
///
/// Videre, når det leveres implementeringer for ytterligere traits, må det vurderes om de skal oppføre seg identiske med de av den underliggende typen som en konsekvens av å fungere som en representasjon av den underliggende typen.
/// Generisk kode bruker vanligvis `Borrow<T>` når den er avhengig av den samme oppførselen til disse ekstra trait-implementeringene.
/// Disse traits vil trolig vises som ekstra trait bounds.
///
/// Spesielt må `Eq`, `Ord` og `Hash` være ekvivalente for lånte og eide verdier: `x.borrow() == y.borrow()` skal gi samme resultat som `x == y`.
///
/// Hvis generisk kode bare trenger å fungere for alle typer som kan gi en referanse til relatert type `T`, er det ofte bedre å bruke [`AsRef<T>`] ettersom flere typer trygt kan implementere den.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Som datainnsamling eier [`HashMap<K, V>`] både nøkler og verdier.Hvis nøkkelens faktiske data er pakket inn i en administrasjonstype av noe slag, bør det likevel være mulig å søke etter en verdi ved hjelp av en referanse til nøkkeldataene.
/// For eksempel, hvis nøkkelen er en streng, blir den sannsynligvis lagret med hash-kartet som en [`String`], mens det skal være mulig å søke ved hjelp av en [`&str`][`str`].
/// Dermed må `insert` operere på en `String` mens `get` trenger å kunne bruke en `&str`.
///
/// Litt forenklet ser de relevante delene av `HashMap<K, V>` slik ut:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // felt utelatt
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Hele hash-kartet er generisk over en nøkkeltype `K`.Fordi disse nøklene er lagret med hash-kartet, må denne typen eie nøkkelens data.
/// Når du setter inn et nøkkelverdipar, får kartet en slik `K` og må finne riktig hashbøtte og sjekke om nøkkelen allerede er tilstede basert på den `K`.Det krever derfor `K: Hash + Eq`.
///
/// Når du søker etter en verdi på kartet, må du imidlertid oppgi en referanse til en `K` som nøkkelen for å søke etter, å opprette en slik verdi.
/// For strengnøkler vil dette bety at en `String`-verdi må opprettes bare for å søke etter tilfeller der bare en `str` er tilgjengelig.
///
/// I stedet er `get`-metoden generisk over typen underliggende nøkkeldata, kalt `Q` i metodesignaturen ovenfor.Den sier at `K` låner som en `Q` ved å kreve at `K: Borrow<Q>`.
/// Ved å i tillegg kreve `Q: Hash + Eq`, signaliserer det kravet om at `K` og `Q` har implementeringer av `Hash` og `Eq` traits som gir identiske resultater.
///
/// Implementeringen av `get` er spesielt avhengig av identiske implementeringer av `Hash` ved å bestemme nøkkelens hashbøtte ved å ringe `Hash::hash` på `Q`-verdien, selv om den satte inn nøkkelen basert på hashverdien beregnet fra `K`-verdien.
///
///
/// Som en konsekvens brytes hash-kartet hvis en `K` som pakker inn en `Q`-verdi, gir en annen hash enn `Q`.Tenk deg for eksempel at du har en type som bryter en streng, men sammenligner ASCII-bokstaver som ignorerer saken:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Fordi to like verdier må produsere den samme hashverdien, må implementeringen av `Hash` også ignorere ASCII-saken:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kan `CaseInsensitiveString` implementere `Borrow<str>`?Det kan absolutt gi en referanse til en strengskive via den inneholdte eide strengen.
/// Men fordi `Hash`-implementeringen er forskjellig, oppfører den seg annerledes enn `str` og må derfor faktisk ikke implementere `Borrow<str>`.
/// Hvis den vil gi andre tilgang til den underliggende `str`, kan den gjøre det via `AsRef<str>` som ikke har noen ekstra krav.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Uformelt låner fra en eid verdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// En trait for data som kan muteres.
///
/// Som følgesvenn til [`Borrow<T>`] tillater denne trait en type å låne som en underliggende type ved å gi en foranderlig referanse.
/// Se [`Borrow<T>`] for mer informasjon om lån som en annen type.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Låner mutabelt fra en eid verdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}