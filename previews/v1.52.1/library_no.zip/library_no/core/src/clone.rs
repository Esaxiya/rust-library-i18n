//! `Clone` trait for typer som ikke kan 'implisitt kopieres'.
//!
//! I Rust er noen enkle typer "implicitly copyable", og når du tilordner dem eller sender dem som argumenter, vil mottakeren få en kopi og la den opprinnelige verdien være på plass.
//! Disse typene krever ikke tildeling for å kopiere og har ikke sluttbehandlere (dvs. de inneholder ikke eide bokser eller implementerer [`Drop`]), så kompilatoren anser dem som billige og trygge å kopiere.
//!
//! For andre typer må kopier lages eksplisitt, ved konvensjon å implementere [`Clone`] trait og ringe [`clone`]-metoden.
//!
//! [`clone`]: Clone::clone
//!
//! Grunnleggende brukseksempel:
//!
//! ```
//! let s = String::new(); // Strenger av typen implementerer Clone
//! let copy = s.clone(); // slik at vi kan klone det
//! ```
//!
//! For å enkelt implementere Clone trait, kan du også bruke `#[derive(Clone)]`.Eksempel:
//!
//! ```
//! #[derive(Clone)] // vi legger til klonen trait til Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // og nå kan vi klone det!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// En vanlig trait for muligheten til å eksplisitt duplisere et objekt.
///
/// Skiller seg fra [`Copy`] ved at [`Copy`] er implisitt og ekstremt billig, mens `Clone` alltid er eksplisitt og kanskje eller ikke kan være dyrt.
/// For å håndheve disse egenskapene tillater ikke Rust å implementere [`Copy`] på nytt, men du kan implementere `Clone` på nytt og kjøre vilkårlig kode.
///
/// Siden `Clone` er mer generelt enn [`Copy`], kan du automatisk gjøre alt [`Copy`] også til `Clone`.
///
/// ## Derivable
///
/// Denne trait kan brukes med `#[derive]` hvis alle feltene er `Clone`.`Derive`d implementering av [`Clone`] kaller [`clone`] på hvert felt.
///
/// [`clone`]: Clone::clone
///
/// For en generisk struktur implementerer `#[derive]` `Clone` betinget ved å legge til bundet `Clone` på generiske parametere.
///
/// ```
/// // `derive` implementerer Clone for Reading<T>når T er klon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Hvordan kan jeg implementere `Clone`?
///
/// Typer som er [`Copy`], bør ha en triviell implementering av `Clone`.Mer formelt:
/// hvis `T: Copy`, `x: T` og `y: &T`, tilsvarer `let x = y.clone();` `let x = *y;`.
/// Manuelle implementeringer bør være forsiktige med å opprettholde denne uvarianten;usikker kode må imidlertid ikke stole på den for å sikre minnesikkerhet.
///
/// Et eksempel er en generisk struktur som inneholder en funksjonspeker.I dette tilfellet kan ikke implementeringen av `Clone` `utledes`d, men kan implementeres som:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Flere implementatorer
///
/// I tillegg til [implementors listed below][impls] implementerer følgende typer også `Clone`:
///
/// * Funksjonstyper (dvs. de forskjellige typene som er definert for hver funksjon)
/// * Funksjonstypetyper (f.eks. `fn() -> i32`)
/// * Array-typer, for alle størrelser, hvis varetypen også implementerer `Clone` (f.eks. `[i32; 123456]`)
/// * Tupeltyper, hvis hver komponent også implementerer `Clone` (f.eks. `()`, `(i32, bool)`)
/// * Lukkingstyper, hvis de ikke fanger noen verdi fra miljøet, eller hvis alle slike fangede verdier implementerer `Clone` selv.
///   Vær oppmerksom på at variabler fanget av delt referanse alltid implementerer `Clone` (selv om referenten ikke gjør det), mens variabler fanget av mutabel referanse aldri implementerer `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Returnerer en kopi av verdien.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementerer Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Utfører kopiering fra `source`.
    ///
    /// `a.clone_from(&b)` tilsvarer `a = b.clone()` i funksjonalitet, men kan overstyres for å gjenbruke ressursene til `a` for å unngå unødvendige tildelinger.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Hent makro som genererer en impl. Av trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): disse strukturene brukes utelukkende av#[derive] for å hevde at hver komponent av en type implementerer klon eller kopi.
//
//
// Disse strengene skal aldri vises i brukerkoden.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementeringer av `Clone` for primitive typer.
///
/// Implementeringer som ikke kan beskrives i Rust implementeres i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Delte referanser kan klones, men mutable referanser *kan ikke*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Delte referanser kan klones, men mutable referanser *kan ikke*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}