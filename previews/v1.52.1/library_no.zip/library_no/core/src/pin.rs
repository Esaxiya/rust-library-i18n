//! Typer som fester data til plasseringen i minnet.
//!
//! Noen ganger er det nyttig å ha gjenstander som garantert ikke beveger seg, i den forstand at deres plassering i minnet ikke endres, og dermed kan stole på.
//! Et godt eksempel på et slikt scenario vil være å bygge selvhenvisende strukturer, ettersom å flytte et objekt med pekere til seg selv vil ugyldiggjøre dem, noe som kan forårsake udefinert oppførsel.
//!
//! På et høyt nivå sørger en [`Pin<P>`] for at pekeren til en hvilken som helst pekertype `P` har en stabil plassering i minnet, noe som betyr at den ikke kan flyttes andre steder, og at minnet ikke kan distribueres før den blir droppet.Vi sier at pointeen er "pinned".Ting blir mer subtile når man diskuterer typer som kombinerer festet med ikke-festede data;[see below](#projections-and-structural-pinning) for mer informasjon.
//!
//! Som standard er alle typer Rust bevegelige.
//! Rust tillater overføring av alle typer byverdier, og vanlige smartpekertyper som [`Box<T>`] og `&mut T` tillater å erstatte og flytte verdiene de inneholder: du kan flytte ut av en [`Box<T>`], eller du kan bruke [`mem::swap`].
//! [`Pin<P>`] bryter en peker type `P`, så [`Pin`]`<`[`Box`] `<T>> fungerer som en vanlig
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`` blir droppet, så gjør innholdet, og minnet blir
//!
//! avdelt.Tilsvarende er [`Pin`]`<&mut T>`mye som `&mut T`.Imidlertid lar [`Pin<P>`] ikke klienter faktisk skaffe seg en [`Box<T>`] eller `&mut T` til festede data, noe som betyr at du ikke kan bruke operasjoner som [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` trenger `&mut T`, men vi kan ikke få det.
//!     // Vi sitter fast, vi kan ikke bytte innholdet i disse referansene.
//!     // Vi kan bruke `Pin::get_unchecked_mut`, men det er usikkert av en grunn:
//!     // vi har ikke lov til å bruke den til å flytte ting ut av `Pin`.
//! }
//! ```
//!
//! Det er verdt å gjenta at [`Pin<P>`]*ikke* endrer det faktum at en Rust-kompilator anser alle typer bevegelige.[`mem::swap`] kan fortsatt kalles for alle `T`.I stedet forhindrer [`Pin<P>`] at visse *verdier*(pekt på pekere pakket inn i [`Pin<P>`]) blir flyttet ved å gjøre det umulig å ringe metoder som krever `&mut T` på dem (som [`mem::swap`]).
//!
//! [`Pin<P>`] kan brukes til å pakke inn hvilken som helst pekertype `P`, og som sådan interagerer den med [`Deref`] og [`DerefMut`].En [`Pin<P>`] der `P: Deref` skal betraktes som en "`P`-style pointer" til en festet `P::Target`-altså en [`Pin`]`<`[Box`]`<T>> `er en eid peker til en festet `T`, og en [` Pin`]`<`[`Rc`]`<T>> er en referanseteltet peker til en festet `T`.
//! For korrekthet er [`Pin<P>`] avhengig av implementeringene av [`Deref`] og [`DerefMut`] for ikke å bevege seg ut av `self`-parameteren, og bare å returnere en peker til festede data når de blir kalt på en festet peker.
//!
//! # `Unpin`
//!
//! Mange typer er alltid bevegelige, selv når de er festet, fordi de ikke stoler på å ha en stabil adresse.Dette inkluderer alle basistypene (som [`bool`], [`i32`] og referanser) samt typer som bare består av disse typene.Typer som ikke bryr seg om å feste, implementerer [`Unpin`] auto-trait, som avbryter effekten av [`Pin<P>`].
//! For `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`og [`Box<T>`] fungerer identisk, det samme gjør [`Pin`] `<&mut T>` og `&mut T`.
//!
//! Merk at pinning og [`Unpin`] bare påvirker den pekende typen `P::Target`, ikke pekeren `P` i seg selv som ble pakket inn i [`Pin<P>`].For eksempel om [`Box<T>`] er [`Unpin`] eller ikke har ingen innvirkning på oppførselen til [`Pin`]`<`[`Box`] `<T>>`(her er `T` den pekede typen).
//!
//! # Eksempel: selvhenvisende struktur
//!
//! Før vi går inn i flere detaljer for å forklare garantiene og valgene knyttet til `Pin<T>`, diskuterer vi noen eksempler på hvordan den kan brukes.
//! Ta gjerne [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Dette er en selvhenvisende struktur fordi skivefeltet peker på datafeltet.
//! // Vi kan ikke informere kompilatoren om det med en normal referanse, da dette mønsteret ikke kan beskrives med de vanlige lånereglene.
//! //
//! // I stedet bruker vi en rå peker, men en som er kjent for ikke å være null, som vi vet at den peker på strengen.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // For å sikre at dataene ikke beveger seg når funksjonen kommer tilbake, plasserer vi den i haugen der den vil forbli i objektets levetid, og den eneste måten å få tilgang til den ville være gjennom en peker til den.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // vi oppretter bare pekeren når dataene er på plass ellers vil de allerede ha flyttet før vi til og med startet
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // vi vet at dette er trygt fordi endring av et felt ikke beveger hele strukturen
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Pekeren skal peke på riktig plassering, så lenge strukturen ikke har flyttet seg.
//! //
//! // I mellomtiden står vi fritt til å flytte pekeren rundt.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Siden typen ikke implementerer Unpin, vil dette ikke kompilere:
//! // la mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Eksempel: påtrengende dobbeltkoblet liste
//!
//! I en påtrengende dobbeltkoblet liste tildeler ikke samlingen faktisk minnet til selve elementene.
//! Tildeling kontrolleres av klientene, og elementer kan leve på en stabelramme som lever kortere enn samlingen gjør.
//!
//! For å få dette til å fungere, har hvert element pekepinner til sin forgjenger og etterfølger i listen.Elementer kan bare legges til når de er festet, fordi flytting av elementene rundt vil ugyldiggjøre pekerne.Videre vil [`Drop`]-implementeringen av et koblet listeelement lappe pekepinnene til forgjengeren og etterfølgeren for å fjerne seg selv fra listen.
//!
//! Avgjørende er at vi må kunne stole på at [`drop`] blir kalt.Hvis et element kunne distribueres eller på annen måte ugyldiggjøres uten å ringe [`drop`], ville pekerne inn i det fra dets nærliggende elementer bli ugyldige, noe som ville ødelegge datastrukturen.
//!
//! Derfor kommer pinning også med en [`drop`]-relatert garanti.
//!
//! # `Drop` guarantee
//!
//! Hensikten med pinning er å kunne stole på plassering av noen data i minnet.
//! For å få dette til å fungere er ikke bare flytting av data begrenset;det er også begrenset med å omplassere, gjenbruke eller på annen måte ugyldiggjøre minnet som brukes til å lagre dataene.
//! Konkret, for fastgjorte data, må du opprettholde den uforanderlige at *hukommelsen ikke blir ugyldiggjort eller repurposed fra det øyeblikket den blir festet til når [`drop`] kalles*.Bare når [`drop`] returnerer eller panics, kan minnet brukes på nytt.
//!
//! Minne kan være "invalidated" ved deallocation, men også ved å erstatte en [`Some(v)`] med [`None`], eller ringe [`Vec::set_len`] til "kill" noen elementer av en vector.Den kan brukes på nytt ved å bruke [`ptr::write`] til å overskrive den uten å ringe destruktoren først.Ingenting av dette er tillatt for festede data uten å ringe [`drop`].
//!
//! Dette er nøyaktig den slags garanti for at den påtrengende koblede listen fra forrige avsnitt må fungere riktig.
//!
//! Legg merke til at denne garantien ikke *betyr* at minnet ikke lekker!Det er fremdeles helt ok å ikke ringe [`drop`] på et festet element (f.eks. Du kan fortsatt ringe [`mem::forget`] på en [`Pin`]`<`[`Box`] `<T>>`).I eksemplet på den dobbeltkoblede listen, vil elementet bare forbli på listen.Du kan imidlertid ikke frigjøre eller bruke lagringsplassen *uten å ringe [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Hvis typen bruker pinning (for eksempel de to eksemplene ovenfor), må du være forsiktig når du implementerer [`Drop`].[`drop`]-funksjonen tar `&mut self`, men dette kalles *selv om typen din tidligere var festet*!Det er som om kompilatoren automatisk heter [`Pin::get_unchecked_mut`].
//!
//! Dette kan aldri forårsake et problem i sikker kode fordi implementering av en type som er avhengig av pinning krever usikker kode, men vær oppmerksom på at du bestemmer deg for å bruke pinning i din type (for eksempel ved å implementere noen operasjoner på [`Pin`]`<&Self>`eller [`Pin`] `<&mut Self>`) har også konsekvenser for [`Drop`]-implementeringen din: Hvis et element av din type kunne ha blitt festet, må du behandle [`Drop`] som implisitt å ta [`Pin`]`<&mut Selv>`.
//!
//!
//! For eksempel kan du implementere `Drop` på følgende måte:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` er greit fordi vi vet at denne verdien aldri blir brukt igjen etter at den ble falt.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Faktisk slippkode går her.
//!         }
//!     }
//! }
//! ```
//!
//! Funksjonen `inner_drop` har den typen [`drop`]*skal* ha, så dette sørger for at du ikke ved et uhell bruker `self`/`this` på en måte som er i konflikt med pinning.
//!
//! Videre, hvis typen din er `#[repr(packed)]`, vil kompilatoren automatisk flytte felt rundt for å kunne slippe dem.Det kan til og med gjøre det for felt som tilfeldigvis er tilstrekkelig justert.Som en konsekvens kan du ikke bruke feste med en `#[repr(packed)]`-type.
//!
//! # Projeksjoner og strukturell pinning
//!
//! Når du arbeider med festede strukturer, oppstår spørsmålet hvordan man kan få tilgang til feltene til den strukturen i en metode som tar bare [`Pin`]`<&mut Struct>`.
//! Den vanlige tilnærmingen er å skrive hjelpemetoder (såkalte *projeksjoner*) som gjør [`Pin`]`<&mut Struct>`til en referanse til feltet, men hvilken type skal referansen ha?Er det [`Pin`]`<&mut Field>`eller `&mut Field`?
//! Det samme spørsmålet oppstår med feltene til en `enum`, og også når man vurderer container/wrapper-typer som [`Vec<T>`], [`Box<T>`] eller [`RefCell<T>`].
//! (Dette spørsmålet gjelder både mutable og delte referanser, vi bruker bare det mer vanlige tilfellet med mutable referanser her for illustrasjon.)
//!
//! Det viser seg at det faktisk er opp til forfatteren av datastrukturen å bestemme om den festede projeksjonen for et bestemt felt gjør [`Pin`]`<&mut Struct>`til [`Pin`] `<&mut Field>` eller `&mut Field`.Det er imidlertid noen begrensninger, og den viktigste begrensningen er *konsistens*:
//! hvert felt kan *enten* projiseres til en festet referanse,*eller* har pinning fjernet som en del av projeksjonen.
//! Hvis begge gjøres for samme felt, vil det sannsynligvis være dårlig!
//!
//! Som forfatter av en datastruktur får du bestemme for hvert felt om du fester "propagates" til dette feltet eller ikke.
//! Pinning som forplantes kalles også "structural", fordi den følger strukturen til typen.
//! I de følgende underavsnittene beskriver vi hensynene som må tas for begge valg.
//!
//! ## Feste *er ikke* strukturelt for `field`
//!
//! Det kan virke kontraintuitivt at feltet til en festet struktur kanskje ikke er festet, men det er faktisk det enkleste valget: Hvis en [`Pin`]`<&mut Field>`aldri blir opprettet, kan ingenting gå galt!Så hvis du bestemmer deg for at noen felt ikke har strukturell festing, er alt du trenger å sikre at du aldri oppretter en fastgjort referanse til det feltet.
//!
//! Felt uten strukturell festing kan ha en projeksjonsmetode som gjør [`Pin`]`<&mut Struct>`til `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Dette er greit fordi `field` aldri blir ansett som festet.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Du kan også `impl Unpin for Struct`*selv om* typen `field` ikke er [`Unpin`].Hva den typen tenker om å feste, er ikke relevant når det aldri er opprettet [`Pin`]`<&mut Field>`.
//!
//! ## Pinning *er* strukturell for `field`
//!
//! Det andre alternativet er å bestemme at pinning er "structural" for `field`, noe som betyr at hvis strukturen er festet, er det også feltet.
//!
//! Dette gjør det mulig å skrive en projeksjon som skaper et [`Pin`]`<&mut-felt>`, og dermed være vitne til at feltet er festet:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Dette er greit fordi `field` er festet når `self` er.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Imidlertid kommer strukturell pinning med noen ekstra krav:
//!
//! 1. Strukturen må bare være [`Unpin`] hvis alle strukturfeltene er [`Unpin`].Dette er standard, men [`Unpin`] er en sikker trait, så som forfatter av strukturen er det ditt ansvar *ikke* å legge til noe som `impl<T> Unpin for Struct<T>`.
//! (Legg merke til at å legge til en projeksjonsoperasjon krever usikker kode, så det faktum at [`Unpin`] er en trygg trait bryter ikke prinsippet om at du bare trenger å bekymre deg for noe av dette hvis du bruker `usikker`.)
//! 2. Destruktoren til strukturen må ikke flytte strukturelle felt ut av argumentet.Dette er det nøyaktige punktet som ble reist i [previous section][drop-impl]: `drop` tar `&mut self`, men strukturen (og dermed dens felt) kan ha blitt festet før.
//!     Du må garantere at du ikke flytter et felt inne i [`Drop`]-implementeringen.
//!     Spesielt, som forklart tidligere, betyr dette at din struktur må *ikke* være `#[repr(packed)]`.
//!     Se den delen for hvordan du skriver [`drop`] på en måte som kompilatoren kan hjelpe deg med å ikke ved et uhell bryte pinning.
//! 3. Du må sørge for at du opprettholder [`Drop` guarantee][drop-guarantee]:
//!     Når strukturen din er festet, blir ikke minnet som inneholder innholdet overskrevet eller distribuert uten å ringe innholdets destruktører.
//!     Dette kan være vanskelig, som bevist av [`VecDeque<T>`]: Destruktoren til [`VecDeque<T>`] kan ikke ringe [`drop`] på alle elementene hvis en av destruktørene panics.Dette bryter med [`Drop`]-garantien, fordi det kan føre til at elementer blir fordelt uten at deres destruktør blir kalt.([`VecDeque<T>`] har ingen festeprojeksjoner, så dette forårsaker ikke uro.)
//! 4. Du må ikke tilby andre operasjoner som kan føre til at data blir flyttet ut av strukturfeltene når typen er festet.For eksempel, hvis strukturen inneholder en [`Option<T>`] og det er en "take"-lignende operasjon med typen `fn(Pin<&mut Struct<T>>) -> Option<T>`, kan den operasjonen brukes til å flytte en `T` ut av en festet `Struct<T>`-noe som betyr at pinning ikke kan være strukturell for feltet som holder dette data.
//!
//!     For et mer komplekst eksempel på å flytte data ut av en festet type, forestill deg om [`RefCell<T>`] hadde en metode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Så kunne vi gjøre følgende:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Dette er katastrofalt, det betyr at vi først kan feste innholdet i [`RefCell<T>`] (ved hjelp av `RefCell::get_pin_mut`) og deretter flytte det innholdet ved hjelp av den mutable referansen vi fikk senere.
//!
//! ## Examples
//!
//! For en type som [`Vec<T>`] gir begge mulighetene (strukturell pinning eller ikke) mening.
//! En [`Vec<T>`] med strukturell festing kan ha `get_pin`/`get_pin_mut`-metoder for å få festede referanser til elementer.Imidlertid kunne det *ikke* tillate å ringe [`pop`][Vec::pop] på en festet [`Vec<T>`] fordi det ville flytte innholdet (strukturelt festet)!Det kunne heller ikke tillate [`push`][Vec::push], som kan omfordele og dermed også flytte innholdet.
//!
//! En [`Vec<T>`] uten strukturell feste kan `impl<T> Unpin for Vec<T>`, fordi innholdet aldri festes, og selve [`Vec<T>`] er greit med å bli flyttet også.
//! På det tidspunktet har pinning bare ingen effekt på vector i det hele tatt.
//!
//! I standardbiblioteket har pekertyper generelt ikke strukturell pinning, og dermed tilbyr de ikke pinningprojeksjoner.Dette er grunnen til at `Box<T>: Unpin` holder for alle `T`.
//! Det er fornuftig å gjøre dette for pekertyper, fordi flytting av `Box<T>` faktisk ikke beveger `T`: [`Box<T>`] kan være fritt bevegelig (også kalt `Unpin`) selv om `T` ikke er det.Faktisk, til og med [`Pin`]`<`[`Box`] `<T>>`og [`Pin`] `<&mut T>` er alltid [`Unpin`] selv, av samme grunn: innholdet (`T`) er festet, men pekerne selv kan flyttes uten å flytte de festede dataene.
//! For både [`Box<T>`] og [`Pin`]`<`[`Box`] `<T>>`, om innholdet er festet er helt uavhengig av om pekeren er festet, noe som betyr at festing er *ikke* strukturell.
//!
//! Når du implementerer en [`Future`]-kombinator, trenger du vanligvis strukturell festing for de nestede futures, da du trenger å få festede referanser til dem for å ringe [`poll`].
//! Men hvis kombinatoren din inneholder andre data som ikke trenger å festes, kan du gjøre disse feltene ikke strukturelle og dermed fritt få tilgang til dem med en mutbar referanse selv når du bare har [`Pin`]`<&mut Self>`(slik som i din egen [`poll`]-implementering).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// En festet peker.
///
/// Dette er en omvikling rundt en slags peker som gjør at pekeren "pin" er på plass, og forhindrer at verdien som pekeren refererer til flyttes, med mindre den implementerer [`Unpin`].
///
///
/// *Se [`pin` module]-dokumentasjonen for en forklaring på festing.*
///
/// [`pin` module]: self
///
// Note: `Clone`-utledningen nedenfor forårsaker usunnhet da det er mulig å implementere
// `Clone` for foranderlige referanser.
// Se <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> for mer informasjon.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Følgende implementeringer er ikke avledet for å unngå lydproblemer.
// `&self.pointer` skal ikke være tilgjengelig for upålitelige trait-implementeringer.
//
// Se <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> for mer informasjon.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Konstruer en ny `Pin<P>` rundt en peker til noen data av en type som implementerer [`Unpin`].
    ///
    /// I motsetning til `Pin::new_unchecked`, er denne metoden trygg fordi pekeren `P` henviser til en [`Unpin`]-type, som avbryter pinnegarantiene.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SIKKERHET: verdien som pekes på er `Unpin`, og har derfor ingen krav
        // rundt feste.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Pakk ut denne `Pin<P>` som returnerer den underliggende pekeren.
    ///
    /// Dette krever at dataene i denne `Pin` er [`Unpin`], slik at vi kan ignorere de festende invarianter når vi pakker den ut.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstruer en ny `Pin<P>` rundt en referanse til noen data av en type som kanskje implementerer `Unpin` eller ikke.
    ///
    /// Hvis `pointer` refererer til en `Unpin`-type, bør `Pin::new` brukes i stedet.
    ///
    /// # Safety
    ///
    /// Denne konstruktøren er usikker fordi vi ikke kan garantere at dataene som `pointer` peker på, er festet, noe som betyr at dataene ikke blir flyttet eller at lagring av dem blir ugyldig før de blir droppet.
    /// Hvis den konstruerte `Pin<P>` ikke garanterer at dataene `P` peker på, er festet, er det et brudd på API-kontrakten og kan føre til udefinert oppførsel i senere (safe)-operasjoner.
    ///
    /// Ved å bruke denne metoden lager du en promise om `P::Deref`-og `P::DerefMut`-implementeringene, hvis de eksisterer.
    /// Viktigst av alt, de må ikke flytte ut av `self`-argumentene sine: `Pin::as_mut` og `Pin::as_ref` vil ringe `DerefMut::deref_mut` og `Deref::deref`*på den festede pekeren* og forventer at disse metodene vil opprettholde de festende invarianter.
    /// Videre, ved å kalle denne metoden, promise at referansen `P` dereferanser til ikke blir flyttet ut av igjen;spesielt må det ikke være mulig å få tak i en `&mut P::Target` og deretter bevege seg ut av den referansen (ved å bruke for eksempel [`mem::swap`]).
    ///
    ///
    /// For eksempel er det ikke trygt å ringe `Pin::new_unchecked` på en `&'a mut T` fordi mens du klarer å feste den i den gitte levetiden `'a`, har du ingen kontroll over om den holdes festet når `'a` slutter:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Dette bør bety at pointee `a` aldri kan bevege seg igjen.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adressen til `a` endret til `b`s stakkspor, så `a` ble flyttet selv om vi tidligere har festet den!Vi har brutt den feste API-kontrakten.
    /////
    /// }
    /// ```
    ///
    /// En verdi, når den er festet, må forbli festet for alltid (med mindre typen implementerer `Unpin`).
    ///
    /// På samme måte er det usikkert å ringe `Pin::new_unchecked` på en `Rc<T>` fordi det kan være aliaser til de samme dataene som ikke er underlagt pinningbegrensningene:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Dette burde bety at pointeen aldri kan bevege seg igjen.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Nå, hvis `x` var den eneste referansen, har vi en foranderlig referanse til data som vi festet ovenfor, som vi kunne bruke til å flytte den slik vi har sett i forrige eksempel.
    ///     // Vi har brutt den feste API-kontrakten.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Får en festet delt referanse fra denne festede pekeren.
    ///
    /// Dette er en generisk metode for å gå fra `&Pin<Pointer<T>>` til `Pin<&T>`.
    /// Det er trygt fordi, som en del av kontrakten til `Pin::new_unchecked`, kan ikke pointeen bevege seg etter at `Pin<Pointer<T>>` ble opprettet.
    ///
    /// "Malicious" implementeringer av `Pointer::Deref` er også utelukket av kontrakten til `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SIKKERHET: se dokumentasjon om denne funksjonen
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Pakk ut denne `Pin<P>` som returnerer den underliggende pekeren.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker.Du må garantere at du vil fortsette å behandle pekeren `P` som festet etter at du har kalt denne funksjonen, slik at invarianter på `Pin`-typen kan opprettholdes.
    /// Hvis koden ved bruk av den resulterende `P` ikke fortsetter å opprettholde de festende invarianter som er et brudd på API-kontrakten og kan føre til udefinert oppførsel i senere (safe)-operasjoner.
    ///
    ///
    /// Hvis de underliggende dataene er [`Unpin`], bør [`Pin::into_inner`] brukes i stedet.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Får en fastgjort muterbar referanse fra denne festede pekeren.
    ///
    /// Dette er en generisk metode for å gå fra `&mut Pin<Pointer<T>>` til `Pin<&mut T>`.
    /// Det er trygt fordi, som en del av kontrakten til `Pin::new_unchecked`, kan ikke pointeen bevege seg etter at `Pin<Pointer<T>>` ble opprettet.
    ///
    /// "Malicious" implementeringer av `Pointer::DerefMut` er også utelukket av kontrakten til `Pin::new_unchecked`.
    ///
    /// Denne metoden er nyttig når du ringer til funksjoner som bruker den festede typen.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // gjør noe
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` bruker `self`, så gjenlån `Pin<&mut Self>` via `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SIKKERHET: se dokumentasjon om denne funksjonen
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Tilordner en ny verdi til minnet bak den festede referansen.
    ///
    /// Dette overskriver festede data, men det er greit: ødeleggeren kjøres før den blir overskrevet, så ingen festegaranti brytes.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstruerer en ny pin ved å kartlegge interiørverdien.
    ///
    /// For eksempel, hvis du ønsket å få en `Pin` av et felt med noe, kan du bruke dette til å få tilgang til det feltet i en kodelinje.
    /// Imidlertid er det flere gotchas med disse "pinning projections";
    /// se [`pin` module]-dokumentasjonen for ytterligere detaljer om dette emnet.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker.
    /// Du må garantere at dataene du returnerer ikke beveger seg så lenge argumentverdien ikke beveger seg (for eksempel fordi det er et av feltene til den verdien), og også at du ikke beveger deg ut av argumentet du mottar til interiørfunksjonen.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SIKKERHET: sikkerhetskontrakten for `new_unchecked` må være
        // opprettholdes av den som ringer.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Får en delt referanse ut av en nål.
    ///
    /// Dette er trygt fordi det ikke er mulig å flytte ut av en delt referanse.
    /// Det kan virke som om det er et problem her med interiørmutabilitet: faktisk er det *mulig* å flytte en `T` ut av en `&RefCell<T>`.
    /// Dette er imidlertid ikke et problem så lenge det ikke finnes en `Pin<&T>` som peker på de samme dataene, og `RefCell<T>` lar deg ikke lage en festet referanse til innholdet.
    ///
    /// Se diskusjonen på ["pinning projections"] for ytterligere detaljer.
    ///
    /// Note: `Pin` implementerer også `Deref` til målet, som kan brukes til å få tilgang til den indre verdien.
    /// Imidlertid gir `Deref` bare en referanse som lever så lenge lånet til `Pin`, ikke levetiden til selve `Pin`.
    /// Denne metoden gjør det mulig å gjøre `Pin` til en referanse med samme levetid som den originale `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konverterer denne `Pin<&mut T>` til en `Pin<&T>` med samme levetid.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Får en foranderlig referanse til dataene inne i denne `Pin`.
    ///
    /// Dette krever at dataene i denne `Pin` er `Unpin`.
    ///
    /// Note: `Pin` implementerer også `DerefMut` til dataene, som kan brukes til å få tilgang til den indre verdien.
    /// Imidlertid gir `DerefMut` bare en referanse som lever så lenge lånet til `Pin`, ikke levetiden til selve `Pin`.
    ///
    /// Denne metoden gjør det mulig å gjøre `Pin` til en referanse med samme levetid som den originale `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Får en foranderlig referanse til dataene inne i denne `Pin`.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker.
    /// Du må garantere at du aldri vil flytte dataene fra den muterbare referansen du mottar når du ringer til denne funksjonen, slik at invarianter på `Pin`-typen kan opprettholdes.
    ///
    ///
    /// Hvis de underliggende dataene er `Unpin`, bør `Pin::get_mut` brukes i stedet.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Konstruer en ny pin ved å kartlegge den indre verdien.
    ///
    /// For eksempel, hvis du ønsket å få en `Pin` av et felt med noe, kan du bruke dette til å få tilgang til det feltet i en kodelinje.
    /// Imidlertid er det flere gotchas med disse "pinning projections";
    /// se [`pin` module]-dokumentasjonen for ytterligere detaljer om dette emnet.
    ///
    /// # Safety
    ///
    /// Denne funksjonen er usikker.
    /// Du må garantere at dataene du returnerer ikke beveger seg så lenge argumentverdien ikke beveger seg (for eksempel fordi det er et av feltene til den verdien), og også at du ikke beveger deg ut av argumentet du mottar til interiørfunksjonen.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SIKKERHET: innringeren er ansvarlig for ikke å flytte
        // verdien ut av denne referansen.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SIKKERHET: da verdien av `this` garantert ikke vil ha
        // blitt flyttet ut, er denne samtalen til `new_unchecked` trygg.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Få en fastgjort referanse fra en statisk referanse.
    ///
    /// Dette er trygt, fordi `T` er lånt for `'static`-levetiden, som aldri slutter.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SIKKERHET: Den 'statiske lånet garanterer at dataene ikke blir det
        // moved/invalidated til den blir droppet (som aldri er).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Få en fastgjort muterbar referanse fra en statisk muterbar referanse.
    ///
    /// Dette er trygt, fordi `T` er lånt for `'static`-levetiden, som aldri slutter.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SIKKERHET: Den 'statiske lånet garanterer at dataene ikke blir det
        // moved/invalidated til den blir droppet (som aldri er).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: dette betyr at enhver impl. av `CoerceUnsized` som tillater tvang fra
// en type som impliserer `Deref<Target=impl !Unpin>` til en type som impliserer `Deref<Target=Unpin>` er usunt.
// Enhver slik implikasjon vil sannsynligvis være dårlig av andre grunner, så vi trenger bare å passe på å ikke la slike implikasjoner lande i std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}