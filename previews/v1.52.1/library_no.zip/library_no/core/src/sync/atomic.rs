//! Atomtyper
//!
//! Atomtyper gir primitiv delt minnekommunikasjon mellom tråder, og er byggesteinene til andre samtidige typer.
//!
//! Denne modulen definerer atomversjoner av et utvalg av primitive typer, inkludert [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etc.
//! Atomtyper presenterer operasjoner som, når de brukes riktig, synkroniserer oppdateringer mellom tråder.
//!
//! Hver metode tar en [`Ordering`] som representerer styrken til minnebarrieren for den operasjonen.Disse bestillingene er de samme som [C++20 atomic orderings][1].For mer informasjon, se [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomiske variabler er trygge å dele mellom tråder (de implementerer [`Sync`]), men de gir ikke selv mekanismen for deling og følger [threading model](../../../std/thread/index.html#the-threading-model) av Rust.
//!
//! Den vanligste måten å dele en atomvariabel på er å plassere den i en [`Arc`][arc] (en atom-referansetelt delt peker).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomtyper kan lagres i statiske variabler, initialisert ved bruk av konstante initialiserere som [`AtomicBool::new`].Atomisk statikk brukes ofte til lat global initialisering.
//!
//! # Portability
//!
//! Alle atomtyper i denne modulen er garantert [lock-free] hvis de er tilgjengelige.Dette betyr at de ikke internt skaffer seg en global mutex.Atomtyper og operasjoner er garantert ikke ventefrie.
//! Dette betyr at operasjoner som `fetch_or` kan implementeres med en sammenlignings-og-bytte-løkke.
//!
//! Atomoperasjoner kan implementeres ved instruksjonslaget med større størrelse atom.For eksempel bruker noen plattformer 4-byte atominstruksjoner for å implementere `AtomicI8`.
//! Merk at denne emuleringen ikke skal påvirke kodens korrekthet, det er bare noe å være klar over.
//!
//! Atomtypene i denne modulen er kanskje ikke tilgjengelig på alle plattformer.Atomtypene her er imidlertid allment tilgjengelige, og kan generelt stole på eksisterende.Noen bemerkelsesverdige unntak er:
//!
//! * PowerPC og MIPS-plattformer med 32-bits pekere har ikke `AtomicU64`-eller `AtomicI64`-typer.
//! * ARM plattformer som `armv5te` som ikke er for Linux, gir bare `load`-og `store`-operasjoner, og støtter ikke Sammenlign og bytt (CAS)-operasjoner, for eksempel `swap`, `fetch_add`, etc.
//! I tillegg på Linux implementeres disse CAS-operasjonene via [operating system support], som kan komme med en ytelsesstraff.
//! * ARM mål med `thumbv6m` gir bare `load` og `store`-operasjoner, og støtter ikke Sammenlign og bytt (CAS)-operasjoner, for eksempel `swap`, `fetch_add`, etc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Merk at future-plattformer kan legges til som heller ikke har støtte for noen atomoperasjoner.Maksimal bærbar kode vil være forsiktig med hvilke atomtyper som brukes.
//! `AtomicUsize` og `AtomicIsize` er vanligvis de mest bærbare, men selv da er de ikke tilgjengelige overalt.
//! Som referanse krever `std`-biblioteket atomstørrelse, men `core` ikke gjør det.
//!
//! For øyeblikket må du først bruke `#[cfg(target_arch)]` for å kompilere betinget i kode med atom.Det er også en ustabil `#[cfg(target_has_atomic)]` som kan stabiliseres i future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! En enkel spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Vent til den andre tråden frigjør låsen
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Hold et globalt antall live tråder:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// En boolsk type som trygt kan deles mellom tråder.
///
/// Denne typen har den samme representasjonen i minnet som en [`bool`].
///
/// **Merk**: Denne typen er bare tilgjengelig på plattformer som støtter atombelastning og lagring av `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Oppretter en `AtomicBool` initialisert til `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send er implisitt implementert for AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// En rå pekertype som trygt kan deles mellom tråder.
///
/// Denne typen har den samme representasjonen i minnet som en `*mut T`.
///
/// **Merk**: Denne typen er bare tilgjengelig på plattformer som støtter atomlast og lagring av pekere.
/// Størrelsen avhenger av målmarkørens størrelse.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Oppretter en null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomiske minnebestillinger
///
/// Hukommelsesbestillinger angir måten atomoperasjoner synkroniserer minne.
/// I sin svakeste [`Ordering::Relaxed`] er bare minnet som operasjonen berører direkte synkronisert.
/// På den annen side synkroniserer et butikkbelastningspar med [`Ordering::SeqCst`]-operasjoner annet minne mens de i tillegg bevarer en total rekkefølge på slike operasjoner på tvers av alle tråder.
///
///
/// Rust s minnebestillinger er [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// For mer informasjon, se [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Ingen bestillingsbegrensninger, bare atomoperasjoner.
    ///
    /// Tilsvarer [`memory_order_relaxed`] i C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Når det er kombinert med en butikk, blir alle tidligere operasjoner bestilt før belastning av denne verdien med [`Acquire`] (eller sterkere) bestilling.
    ///
    /// Spesielt blir alle tidligere skrivinger synlige for alle tråder som utfører en [`Acquire`] (eller sterkere) belastning av denne verdien.
    ///
    /// Legg merke til at bruk av denne bestillingen for en operasjon som kombinerer last og lagring fører til en [`Relaxed`] lastoperasjon!
    ///
    /// Denne bestillingen gjelder bare for operasjoner som kan utføre en butikk.
    ///
    /// Tilsvarer [`memory_order_release`] i C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Når kombinert med en belastning, hvis den lastede verdien ble skrevet av en butikkoperasjon med [`Release`] (eller sterkere) bestilling, blir alle påfølgende operasjoner bestilt etter den butikken.
    /// Spesielt vil alle påfølgende belastninger se data skrevet før butikken.
    ///
    /// Legg merke til at bruk av denne bestillingen for en operasjon som kombinerer last og lagring fører til en [`Relaxed`] butikkoperasjon!
    ///
    /// Denne bestillingen gjelder bare for operasjoner som kan utføre en belastning.
    ///
    /// Tilsvarer [`memory_order_acquire`] i C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Har effekten av både [`Acquire`] og [`Release`] sammen:
    /// For laster bruker den [`Acquire`]-bestilling.For butikker bruker den [`Release`]-bestillingen.
    ///
    /// Legg merke til at i tilfelle `compare_and_swap` er det mulig at operasjonen ender med å ikke utføre noen butikk, og den har derfor bare [`Acquire`]-bestilling.
    ///
    /// Imidlertid vil `AcqRel` aldri utføre [`Relaxed`]-tilganger.
    ///
    /// Denne bestillingen gjelder bare for operasjoner som kombinerer både laster og butikker.
    ///
    /// Tilsvarer [`memory_order_acq_rel`] i C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Som [`Acquire`]/[`Release`]/[`AcqRel`](for henholdsvis belastning, lagring og last-med-butikk) med den ekstra garantien at alle tråder ser alle sekvensielt konsistente operasjoner i samme rekkefølge .
    ///
    ///
    /// Tilsvarer [`memory_order_seq_cst`] i C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// En [`AtomicBool`] initialisert til `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Oppretter en ny `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Returnerer en foranderlig referanse til den underliggende [`bool`].
    ///
    /// Dette er trygt fordi den mutable referansen garanterer at ingen andre tråder samtidig får tilgang til atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SIKKERHET: den foranderlige referansen garanterer unikt eierskap.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Få atomadgang til en `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SIKKERHET: den foranderlige referansen garanterer unikt eierskap, og
        // justering av både `bool` og `Self` er 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Forbruker atom og returnerer den inneholdte verdien.
    ///
    /// Dette er trygt fordi å overføre `self` etter verdi garanterer at ingen andre tråder samtidig får tilgang til atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Laster inn en verdi fra bool.
    ///
    /// `load` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.
    /// Mulige verdier er [`SeqCst`], [`Acquire`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics hvis `order` er [`Release`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SIKKERHET: ethvert dataløp forhindres av atominnholdet og det rå
        // pekeren som er sendt inn er gyldig fordi vi fikk den fra en referanse.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Lagrer en verdi i bool.
    ///
    /// `store` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.
    /// Mulige verdier er [`SeqCst`], [`Release`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics hvis `order` er [`Acquire`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SIKKERHET: ethvert dataløp forhindres av atominnholdet og det rå
        // pekeren som er sendt inn er gyldig fordi vi fikk den fra en referanse.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Lagrer en verdi i bool, og returnerer den forrige verdien.
    ///
    /// `swap` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
    /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHET: dataløp forhindres av atominnhold.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Lagrer en verdi i [`bool`] hvis den nåværende verdien er den samme som `current`-verdien.
    ///
    /// Returverdien er alltid den forrige verdien.Hvis det er lik `current`, ble verdien oppdatert.
    ///
    /// `compare_and_swap` tar også et [`Ordering`]-argument som beskriver hukommelsesrekkefølgen for denne operasjonen.
    /// Legg merke til at selv når du bruker [`AcqRel`], kan operasjonen mislykkes og dermed bare utføre en `Acquire`-belastning, men ikke ha `Release`-semantikk.
    /// Bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`] hvis det skjer, og bruk av [`Release`] gjør lastdelen [`Relaxed`].
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på `u8`.
    ///
    /// # Overfører til `compare_exchange` og `compare_exchange_weak`
    ///
    /// `compare_and_swap` tilsvarer `compare_exchange` med følgende kartlegging for minnebestillinger:
    ///
    /// Original |Suksess |Feil
    /// -------- | ------- | -------
    /// Avslappet |Avslappet |Avslappet anskaffe |Erverve |Erverve utgivelse |Utgivelse |Avslappet AcqRel |AcqRel |Erverve SeqCst |SeqCst |Sekv
    ///
    /// `compare_exchange_weak` får mislykkes feilaktig selv når sammenligningen lykkes, noe som gjør at kompilatoren kan generere bedre monteringskode når sammenligningen og byttet brukes i en løkke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Lagrer en verdi i [`bool`] hvis den nåværende verdien er den samme som `current`-verdien.
    ///
    /// Returverdien er et resultat som indikerer om den nye verdien ble skrevet og inneholdt den forrige verdien.
    /// Ved suksess er denne verdien garantert å være lik `current`.
    ///
    /// `compare_exchange` tar to [`Ordering`] argumenter for å beskrive hukommelsesrekkefølgen for denne operasjonen.
    /// `success` beskriver den nødvendige rekkefølgen for lese-modifiser-skriv-operasjonen som finner sted hvis sammenligningen med `current` lykkes.
    /// `failure` beskriver den nødvendige bestillingen for lastoperasjonen som finner sted når sammenligningen mislykkes.
    /// Bruk av [`Acquire`] som suksessbestilling gjør butikken til en del av denne operasjonen [`Relaxed`], og bruk av [`Release`] gjør den vellykkede belastningen [`Relaxed`].
    ///
    /// Feilbestillingen kan bare være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og må være ekvivalent med eller svakere enn suksessbestillingen.
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIKKERHET: dataløp forhindres av atominnhold.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Lagrer en verdi i [`bool`] hvis den nåværende verdien er den samme som `current`-verdien.
    ///
    /// I motsetning til [`AtomicBool::compare_exchange`] får denne funksjonen feilaktig mislykkes selv når sammenligningen lykkes, noe som kan resultere i mer effektiv kode på noen plattformer.
    ///
    /// Returverdien er et resultat som indikerer om den nye verdien ble skrevet og inneholdt den forrige verdien.
    ///
    /// `compare_exchange_weak` tar to [`Ordering`] argumenter for å beskrive hukommelsesrekkefølgen for denne operasjonen.
    /// `success` beskriver den nødvendige rekkefølgen for lese-modifiser-skriv-operasjonen som finner sted hvis sammenligningen med `current` lykkes.
    /// `failure` beskriver den nødvendige bestillingen for lastoperasjonen som finner sted når sammenligningen mislykkes.
    /// Bruk av [`Acquire`] som suksessbestilling gjør butikken til en del av denne operasjonen [`Relaxed`], og bruk av [`Release`] gjør den vellykkede belastningen [`Relaxed`].
    /// Feilbestillingen kan bare være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og må være ekvivalent med eller svakere enn suksessbestillingen.
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIKKERHET: dataløp forhindres av atominnhold.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logisk "and" med en boolsk verdi.
    ///
    /// Utfører en logisk "and"-operasjon på gjeldende verdi og argumentet `val`, og setter den nye verdien til resultatet.
    ///
    /// Returnerer forrige verdi.
    ///
    /// `fetch_and` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
    /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHET: dataløp forhindres av atominnhold.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logisk "nand" med en boolsk verdi.
    ///
    /// Utfører en logisk "nand"-operasjon på gjeldende verdi og argumentet `val`, og setter den nye verdien til resultatet.
    ///
    /// Returnerer forrige verdi.
    ///
    /// `fetch_nand` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
    /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Vi kan ikke bruke atomic_nand her fordi det kan resultere i en bool med en ugyldig verdi.
        // Dette skjer fordi atomoperasjonen er utført med et 8-biters heltall internt, som vil sette de øvre 7 bitene.
        //
        // Så vi bruker bare fetch_xor eller bytter i stedet.
        if val {
            // ! (x&true)== !x Vi må invertere bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Vi må sette bool til true.
            //
            self.swap(true, order)
        }
    }

    /// Logisk "or" med en boolsk verdi.
    ///
    /// Utfører en logisk "or"-operasjon på gjeldende verdi og argumentet `val`, og setter den nye verdien til resultatet.
    ///
    /// Returnerer forrige verdi.
    ///
    /// `fetch_or` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
    /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHET: dataløp forhindres av atominnhold.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logisk "xor" med en boolsk verdi.
    ///
    /// Utfører en logisk "xor"-operasjon på gjeldende verdi og argumentet `val`, og setter den nye verdien til resultatet.
    ///
    /// Returnerer forrige verdi.
    ///
    /// `fetch_xor` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
    /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHET: dataløp forhindres av atominnhold.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Returnerer en muterbar peker til den underliggende [`bool`].
    ///
    /// Å gjøre ikke-atomiske leser og skriver på det resulterende heltallet kan være et dataløp.
    /// Denne metoden er mest nyttig for FFI, der funksjonsignaturen kan bruke `*mut bool` i stedet for `&AtomicBool`.
    ///
    /// Å returnere en `*mut`-peker fra en delt referanse til dette atomet er trygt fordi atomtypene fungerer med indre mutabilitet.
    /// Alle modifikasjoner av et atom endrer verdien gjennom en delt referanse, og kan gjøre det trygt så lenge de bruker atomoperasjoner.
    /// Enhver bruk av den returnerte råpekeren krever en `unsafe`-blokk og må fortsatt opprettholde den samme begrensningen: operasjoner på den må være atomare.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Henter verdien og bruker en funksjon til den som returnerer en valgfri ny verdi.Returnerer en `Result` av `Ok(previous_value)` hvis funksjonen returnerte `Some(_)`, ellers `Err(previous_value)`.
    ///
    /// Note: Dette kan ringe til funksjonen flere ganger hvis verdien har blitt endret fra andre tråder i mellomtiden, så lenge funksjonen returnerer `Some(_)`, men funksjonen vil bare ha blitt brukt en gang til den lagrede verdien.
    ///
    ///
    /// `fetch_update` tar to [`Ordering`] argumenter for å beskrive hukommelsesrekkefølgen for denne operasjonen.
    /// Den første beskriver den nødvendige bestillingen for når operasjonen endelig lykkes, mens den andre beskriver den nødvendige bestillingen for belastninger.
    /// Disse tilsvarer suksess-og mislykkede bestillinger av henholdsvis [`AtomicBool::compare_exchange`].
    ///
    /// Bruk av [`Acquire`] som suksessbestilling gjør butikken til en del av denne operasjonen [`Relaxed`], og bruk av [`Release`] gjør den endelige vellykkede belastningen [`Relaxed`].
    /// (failed) lastbestilling kan bare være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og må tilsvare eller svakere enn suksessbestillingen.
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Oppretter en ny `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Returnerer en foranderlig referanse til den underliggende pekeren.
    ///
    /// Dette er trygt fordi den mutable referansen garanterer at ingen andre tråder samtidig får tilgang til atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Få atomatkomst til en peker.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - den foranderlige referansen garanterer unikt eierskap.
        //  - justeringen av `*mut T` og `Self` er den samme på alle plattformer som støttes av rust, som bekreftet ovenfor.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Forbruker atom og returnerer den inneholdte verdien.
    ///
    /// Dette er trygt fordi å overføre `self` etter verdi garanterer at ingen andre tråder samtidig får tilgang til atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Laster inn en verdi fra pekeren.
    ///
    /// `load` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.
    /// Mulige verdier er [`SeqCst`], [`Acquire`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics hvis `order` er [`Release`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SIKKERHET: dataløp forhindres av atominnhold.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Lagrer en verdi i pekeren.
    ///
    /// `store` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.
    /// Mulige verdier er [`SeqCst`], [`Release`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics hvis `order` er [`Acquire`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SIKKERHET: dataløp forhindres av atominnhold.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Lagrer en verdi i pekeren og returnerer den forrige verdien.
    ///
    /// `swap` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
    /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på pekere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SIKKERHET: dataløp forhindres av atominnhold.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Lagrer en verdi i pekeren hvis den nåværende verdien er den samme som `current`-verdien.
    ///
    /// Returverdien er alltid den forrige verdien.Hvis det er lik `current`, ble verdien oppdatert.
    ///
    /// `compare_and_swap` tar også et [`Ordering`]-argument som beskriver hukommelsesrekkefølgen for denne operasjonen.
    /// Legg merke til at selv når du bruker [`AcqRel`], kan operasjonen mislykkes og dermed bare utføre en `Acquire`-belastning, men ikke ha `Release`-semantikk.
    /// Bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`] hvis det skjer, og bruk av [`Release`] gjør lastdelen [`Relaxed`].
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på pekere.
    ///
    /// # Overfører til `compare_exchange` og `compare_exchange_weak`
    ///
    /// `compare_and_swap` tilsvarer `compare_exchange` med følgende kartlegging for minnebestillinger:
    ///
    /// Original |Suksess |Feil
    /// -------- | ------- | -------
    /// Avslappet |Avslappet |Avslappet anskaffe |Erverve |Erverve utgivelse |Utgivelse |Avslappet AcqRel |AcqRel |Erverve SeqCst |SeqCst |Sekv
    ///
    /// `compare_exchange_weak` får mislykkes feilaktig selv når sammenligningen lykkes, noe som gjør at kompilatoren kan generere bedre monteringskode når sammenligningen og byttet brukes i en løkke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Lagrer en verdi i pekeren hvis den nåværende verdien er den samme som `current`-verdien.
    ///
    /// Returverdien er et resultat som indikerer om den nye verdien ble skrevet og inneholdt den forrige verdien.
    /// Ved suksess er denne verdien garantert å være lik `current`.
    ///
    /// `compare_exchange` tar to [`Ordering`] argumenter for å beskrive hukommelsesrekkefølgen for denne operasjonen.
    /// `success` beskriver den nødvendige rekkefølgen for lese-modifiser-skriv-operasjonen som finner sted hvis sammenligningen med `current` lykkes.
    /// `failure` beskriver den nødvendige bestillingen for lastoperasjonen som finner sted når sammenligningen mislykkes.
    /// Bruk av [`Acquire`] som suksessbestilling gjør butikken til en del av denne operasjonen [`Relaxed`], og bruk av [`Release`] gjør den vellykkede belastningen [`Relaxed`].
    ///
    /// Feilbestillingen kan bare være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og må være ekvivalent med eller svakere enn suksessbestillingen.
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på pekere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIKKERHET: dataløp forhindres av atominnhold.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Lagrer en verdi i pekeren hvis den nåværende verdien er den samme som `current`-verdien.
    ///
    /// I motsetning til [`AtomicPtr::compare_exchange`] får denne funksjonen feilaktig mislykkes selv når sammenligningen lykkes, noe som kan resultere i mer effektiv kode på noen plattformer.
    ///
    /// Returverdien er et resultat som indikerer om den nye verdien ble skrevet og inneholdt den forrige verdien.
    ///
    /// `compare_exchange_weak` tar to [`Ordering`] argumenter for å beskrive hukommelsesrekkefølgen for denne operasjonen.
    /// `success` beskriver den nødvendige rekkefølgen for lese-modifiser-skriv-operasjonen som finner sted hvis sammenligningen med `current` lykkes.
    /// `failure` beskriver den nødvendige bestillingen for lastoperasjonen som finner sted når sammenligningen mislykkes.
    /// Bruk av [`Acquire`] som suksessbestilling gjør butikken til en del av denne operasjonen [`Relaxed`], og bruk av [`Release`] gjør den vellykkede belastningen [`Relaxed`].
    /// Feilbestillingen kan bare være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og må være ekvivalent med eller svakere enn suksessbestillingen.
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på pekere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIKKERHET: Denne egenskapen er usikker fordi den fungerer på en rå peker
        // men vi vet helt sikkert at pekeren er gyldig (vi har nettopp fått den fra en `UnsafeCell` som vi har som referanse), og selve atomoperasjonen lar oss trygt mutere `UnsafeCell`-innholdet.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Henter verdien og bruker en funksjon til den som returnerer en valgfri ny verdi.Returnerer en `Result` av `Ok(previous_value)` hvis funksjonen returnerte `Some(_)`, ellers `Err(previous_value)`.
    ///
    /// Note: Dette kan ringe til funksjonen flere ganger hvis verdien har blitt endret fra andre tråder i mellomtiden, så lenge funksjonen returnerer `Some(_)`, men funksjonen vil bare ha blitt brukt en gang til den lagrede verdien.
    ///
    ///
    /// `fetch_update` tar to [`Ordering`] argumenter for å beskrive hukommelsesrekkefølgen for denne operasjonen.
    /// Den første beskriver den nødvendige bestillingen for når operasjonen endelig lykkes, mens den andre beskriver den nødvendige bestillingen for belastninger.
    /// Disse tilsvarer suksess-og mislykkede bestillinger av henholdsvis [`AtomicPtr::compare_exchange`].
    ///
    /// Bruk av [`Acquire`] som suksessbestilling gjør butikken til en del av denne operasjonen [`Relaxed`], og bruk av [`Release`] gjør den endelige vellykkede belastningen [`Relaxed`].
    /// (failed) lastbestilling kan bare være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og må tilsvare eller svakere enn suksessbestillingen.
    ///
    /// **Note:** Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på pekere.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Konverterer en `bool` til en `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Denne makroen ender opp med å være ubrukt på noen arkitekturer.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// En heltallstype som trygt kan deles mellom tråder.
        ///
        /// Denne typen har den samme representasjonen i minnet som den underliggende heltallstypen, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// For mer informasjon om forskjellene mellom atomtyper og ikke-atomare typer, samt informasjon om bærbarhet av denne typen, se [module-level documentation].
        ///
        ///
        /// **Note:** Denne typen er bare tilgjengelig på plattformer som støtter atomlast og lagring av [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Et atom heltall initialisert til `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Send er implisitt implementert.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Oppretter et nytt atom heltall.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Returnerer en foranderlig referanse til det underliggende heltallet.
            ///
            /// Dette er trygt fordi den mutable referansen garanterer at ingen andre tråder samtidig får tilgang til atomdata.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// la mut noe_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (noen_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - den foranderlige referansen garanterer unikt eierskap.
                //  - justeringen av `$int_type` og `Self` er den samme, som lovet av $cfg_align og bekreftet ovenfor.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Forbruker atom og returnerer den inneholdte verdien.
            ///
            /// Dette er trygt fordi å overføre `self` etter verdi garanterer at ingen andre tråder samtidig får tilgang til atomdata.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Laster inn en verdi fra atom heltallet.
            ///
            /// `load` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.
            /// Mulige verdier er [`SeqCst`], [`Acquire`] og [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics hvis `order` er [`Release`] eller [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Lagrer en verdi i atomnummeret.
            ///
            /// `store` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.
            ///  Mulige verdier er [`SeqCst`], [`Release`] og [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics hvis `order` er [`Acquire`] eller [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Lagrer en verdi i atomnummeret, og returnerer den forrige verdien.
            ///
            /// `swap` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
            /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
            ///
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Lagrer en verdi i atomnummeret hvis den nåværende verdien er den samme som `current`-verdien.
            ///
            /// Returverdien er alltid den forrige verdien.Hvis det er lik `current`, ble verdien oppdatert.
            ///
            /// `compare_and_swap` tar også et [`Ordering`]-argument som beskriver hukommelsesrekkefølgen for denne operasjonen.
            /// Legg merke til at selv når du bruker [`AcqRel`], kan operasjonen mislykkes og dermed bare utføre en `Acquire`-belastning, men ikke ha `Release`-semantikk.
            ///
            /// Bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`] hvis det skjer, og bruk av [`Release`] gjør lastdelen [`Relaxed`].
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Overfører til `compare_exchange` og `compare_exchange_weak`
            ///
            /// `compare_and_swap` tilsvarer `compare_exchange` med følgende kartlegging for minnebestillinger:
            ///
            /// Original |Suksess |Feil
            /// -------- | ------- | -------
            /// Avslappet |Avslappet |Avslappet anskaffe |Erverve |Erverve utgivelse |Utgivelse |Avslappet AcqRel |AcqRel |Erverve SeqCst |SeqCst |Sekv
            ///
            /// `compare_exchange_weak` får mislykkes feilaktig selv når sammenligningen lykkes, noe som gjør at kompilatoren kan generere bedre monteringskode når sammenligningen og byttet brukes i en løkke.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Lagrer en verdi i atomnummeret hvis den nåværende verdien er den samme som `current`-verdien.
            ///
            /// Returverdien er et resultat som indikerer om den nye verdien ble skrevet og inneholdt den forrige verdien.
            /// Ved suksess er denne verdien garantert å være lik `current`.
            ///
            /// `compare_exchange` tar to [`Ordering`] argumenter for å beskrive hukommelsesrekkefølgen for denne operasjonen.
            /// `success` beskriver den nødvendige rekkefølgen for lese-modifiser-skriv-operasjonen som finner sted hvis sammenligningen med `current` lykkes.
            /// `failure` beskriver den nødvendige bestillingen for lastoperasjonen som finner sted når sammenligningen mislykkes.
            /// Bruk av [`Acquire`] som suksessbestilling gjør butikken til en del av denne operasjonen [`Relaxed`], og bruk av [`Release`] gjør den vellykkede belastningen [`Relaxed`].
            ///
            /// Feilbestillingen kan bare være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og må være ekvivalent med eller svakere enn suksessbestillingen.
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Lagrer en verdi i atomnummeret hvis den nåværende verdien er den samme som `current`-verdien.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// denne funksjonen får feilaktig mislykkes selv når sammenligningen lykkes, noe som kan føre til mer effektiv kode på noen plattformer.
            /// Returverdien er et resultat som indikerer om den nye verdien ble skrevet og inneholdt den forrige verdien.
            ///
            /// `compare_exchange_weak` tar to [`Ordering`] argumenter for å beskrive hukommelsesrekkefølgen for denne operasjonen.
            /// `success` beskriver den nødvendige rekkefølgen for lese-modifiser-skriv-operasjonen som finner sted hvis sammenligningen med `current` lykkes.
            /// `failure` beskriver den nødvendige bestillingen for lastoperasjonen som finner sted når sammenligningen mislykkes.
            /// Bruk av [`Acquire`] som suksessbestilling gjør butikken til en del av denne operasjonen [`Relaxed`], og bruk av [`Release`] gjør den vellykkede belastningen [`Relaxed`].
            ///
            /// Feilbestillingen kan bare være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og må være ekvivalent med eller svakere enn suksessbestillingen.
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// la mut gamle= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Legger til den nåværende verdien og returnerer den forrige verdien.
            ///
            /// Denne operasjonen brytes rundt på overløp.
            ///
            /// `fetch_add` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
            /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
            ///
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Trekker fra gjeldende verdi, og returnerer den forrige verdien.
            ///
            /// Denne operasjonen brytes rundt på overløp.
            ///
            /// `fetch_sub` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
            /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
            ///
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitvis "and" med gjeldende verdi.
            ///
            /// Utfører en bitvis "and"-operasjon på gjeldende verdi og argumentet `val`, og setter den nye verdien til resultatet.
            ///
            /// Returnerer forrige verdi.
            ///
            /// `fetch_and` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
            /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
            ///
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitvis "nand" med gjeldende verdi.
            ///
            /// Utfører en bitvis "nand"-operasjon på gjeldende verdi og argumentet `val`, og setter den nye verdien til resultatet.
            ///
            /// Returnerer forrige verdi.
            ///
            /// `fetch_nand` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
            /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
            ///
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitvis "or" med gjeldende verdi.
            ///
            /// Utfører en bitvis "or"-operasjon på gjeldende verdi og argumentet `val`, og setter den nye verdien til resultatet.
            ///
            /// Returnerer forrige verdi.
            ///
            /// `fetch_or` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
            /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
            ///
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitvis "xor" med gjeldende verdi.
            ///
            /// Utfører en bitvis "xor"-operasjon på gjeldende verdi og argumentet `val`, og setter den nye verdien til resultatet.
            ///
            /// Returnerer forrige verdi.
            ///
            /// `fetch_xor` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
            /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
            ///
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Henter verdien og bruker en funksjon til den som returnerer en valgfri ny verdi.Returnerer en `Result` av `Ok(previous_value)` hvis funksjonen returnerte `Some(_)`, ellers `Err(previous_value)`.
            ///
            /// Note: Dette kan ringe til funksjonen flere ganger hvis verdien har blitt endret fra andre tråder i mellomtiden, så lenge funksjonen returnerer `Some(_)`, men funksjonen vil bare ha blitt brukt en gang til den lagrede verdien.
            ///
            ///
            /// `fetch_update` tar to [`Ordering`] argumenter for å beskrive hukommelsesrekkefølgen for denne operasjonen.
            /// Den første beskriver den nødvendige bestillingen for når operasjonen endelig lykkes, mens den andre beskriver den nødvendige bestillingen for belastninger.Disse tilsvarer suksess og fiasko bestillinger av
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Bruk av [`Acquire`] som suksessbestilling gjør butikken til en del av denne operasjonen [`Relaxed`], og bruk av [`Release`] gjør den endelige vellykkede belastningen [`Relaxed`].
            /// (failed) lastbestilling kan bare være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og må tilsvare eller svakere enn suksessbestillingen.
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Bestilling: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Bestilling: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maksimum med gjeldende verdi.
            ///
            /// Finner maksimum av gjeldende verdi og argument `val`, og setter den nye verdien til resultatet.
            ///
            /// Returnerer forrige verdi.
            ///
            /// `fetch_max` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
            /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
            ///
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// la bar=42;
            /// la max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// hevder! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum med gjeldende verdi.
            ///
            /// Finner minimum av gjeldende verdi og argumentet `val`, og setter den nye verdien til resultatet.
            ///
            /// Returnerer forrige verdi.
            ///
            /// `fetch_min` tar et [`Ordering`]-argument som beskriver minneordren til denne operasjonen.Alle bestillingsmodi er mulig.
            /// Merk at bruk av [`Acquire`] gjør butikken til en del av denne operasjonen [`Relaxed`], og ved bruk av [`Release`] blir lastdelen [`Relaxed`].
            ///
            ///
            /// **Merk**: Denne metoden er bare tilgjengelig på plattformer som støtter atomoperasjoner på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// la bar=12;
            /// la min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHET: dataløp forhindres av atominnhold.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Returnerer en foranderlig peker til det underliggende heltallet.
            ///
            /// Å gjøre ikke-atomiske leser og skriver på det resulterende heltallet kan være et dataløp.
            /// Denne metoden er stort sett nyttig for FFI, der funksjonssignaturen kan bruke
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Å returnere en `*mut`-peker fra en delt referanse til dette atomet er trygt fordi atomtypene fungerer med indre mutabilitet.
            /// Alle modifikasjoner av et atom endrer verdien gjennom en delt referanse, og kan gjøre det trygt så lenge de bruker atomoperasjoner.
            /// Enhver bruk av den returnerte råpekeren krever en `unsafe`-blokk og må fortsatt opprettholde den samme begrensningen: operasjoner på den må være atomare.
            ///
            ///
            /// # Examples
            ///
            /// `` ignorere (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ekstern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SIKKERHET: Trygt så lenge `my_atomic_op` er atomisk.
            /// usikre {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Returnerer den forrige verdien (som __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Returnerer den forrige verdien (som __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// returnerer maksverdien (signert sammenligning)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// returnerer minverdien (signert sammenligning)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// returnerer maksverdien (usignert sammenligning)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// returnerer minverdien (usignert sammenligning)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Et atomgjerde.
///
/// Avhengig av den angitte rekkefølgen, forhindrer et gjerde kompilatoren og CPUen fra å omorganisere visse typer minneoperasjoner rundt den.
/// Det skaper synkroniserer-med forhold mellom det og atomoperasjoner eller gjerder i andre tråder.
///
/// Et gjerde 'A' som har (i det minste) [`Release`] bestillingssemantikk, synkroniseres med et gjerde 'B' med (minst) [`Acquire`] semantikk, hvis og bare hvis det eksisterer operasjoner X og Y, begge opererer på noe atomobjekt 'M' slik at A blir sekvensert før X, Y synkroniseres før B og Y observerer endringen til M.
/// Dette gir en avhengighet som skjer før A og B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomoperasjoner med [`Release`]-eller [`Acquire`]-semantikk kan også synkroniseres med et gjerde.
///
/// Et gjerde som har [`SeqCst`]-bestilling, i tillegg til å ha både [`Acquire`]-og [`Release`]-semantikk, deltar i den globale programrekkefølgen for de andre [`SeqCst`]-operasjonene og/eller gjerder.
///
/// Godtar bestillinger fra [`Acquire`], [`Release`], [`AcqRel`] og [`SeqCst`].
///
/// # Panics
///
/// Panics hvis `order` er [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // En gjensidig eksklusjon primitiv basert på spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Vent til den gamle verdien er `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Dette gjerdet synkroniseres med butikken i `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SIKKERHET: Å bruke et atomgjerde er trygt.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Et kompilatorminnegjerde.
///
/// `compiler_fence` sender ikke ut noen maskinkode, men begrenser hva slags minne det er mulig å ombestille kompilatoren.Spesielt, avhengig av den gitte [`Ordering`]-semantikken, kan kompilatoren ikke tillates å flytte lese eller skrive fra før eller etter samtalen til den andre siden av samtalen til `compiler_fence`.Merk at det **ikke** hindrer *maskinvaren* i å gjøre slik ombestilling.
///
/// Dette er ikke et problem i en utførelsessammenheng med en tråd, men når andre tråder kan endre minne samtidig, kreves sterkere synkroniseringsprimitiver som [`fence`].
///
/// Ombestillingen forhindret av de forskjellige bestillingssemantikkene er:
///
///  - med [`SeqCst`] er det ikke tillatt å ombestille lesing og skriving over dette punktet.
///  - med [`Release`] kan ikke foregående lese og skrive flyttes forbi påfølgende skriv.
///  - med [`Acquire`] kan påfølgende lese og skrive ikke flyttes foran forrige lesinger.
///  - med [`AcqRel`] håndheves begge ovennevnte regler.
///
/// `compiler_fence` er vanligvis bare nyttig for å forhindre at en tråd løper *med seg selv*.Det vil si hvis en gitt tråd utfører ett stykke kode, og deretter blir avbrutt, og begynner å utføre kode andre steder (mens du fortsatt er i samme tråd, og konseptuelt fremdeles på samme kjerne).I tradisjonelle programmer kan dette bare skje når en signalbehandler er registrert.
/// I mer lavnivåkode kan slike situasjoner også oppstå når du håndterer avbrudd, når du implementerer grønne tråder med forkjøp osv.
/// Nysgjerrige lesere oppfordres til å lese Linux-kjernens diskusjon av [memory barriers].
///
/// # Panics
///
/// Panics hvis `order` er [`Relaxed`].
///
/// # Examples
///
/// Uten `compiler_fence` er `assert_eq!` i følgende kode *ikke* garantert å lykkes, til tross for at alt skjer i en enkelt tråd.
/// For å se hvorfor, husk at kompilatoren er fri til å bytte butikkene til `IMPORTANT_VARIABLE` og `IS_READ`, siden de begge er `Ordering::Relaxed`.Hvis det gjør det, og signalbehandleren påkalles rett etter at `IS_READY` er oppdatert, vil signalbehandleren se `IS_READY=1`, men `IMPORTANT_VARIABLE=0`.
/// Ved å bruke en `compiler_fence` avhjelper denne situasjonen.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // forhindre at tidligere skriv flyttes utover dette punktet
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SIKKERHET: Å bruke et atomgjerde er trygt.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signaler prosessoren om at den er inne i en travel-vent spin-loop ("spin lock").
///
/// Denne funksjonen avvikles til fordel for [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}