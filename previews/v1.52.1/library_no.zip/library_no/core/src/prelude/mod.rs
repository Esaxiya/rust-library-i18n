//! Libcore prelude
//!
//! Denne modulen er ment for brukere av libcore som ikke lenker til libstd også.
//! Denne modulen importeres som standard når `#![no_std]` brukes på samme måte som standardbibliotekets prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 2015-versjonen av kjernen prelude.
///
/// Se [module-level documentation](self) for mer informasjon.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2018-versjonen av kjernen prelude.
///
/// Se [module-level documentation](self) for mer informasjon.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2021-versjonen av kjernen prelude.
///
/// Se [module-level documentation](self) for mer informasjon.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Legg til flere ting.
}