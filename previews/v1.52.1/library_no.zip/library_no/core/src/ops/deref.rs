/// Brukes til uforanderlige dereferensoperasjoner, som `*v`.
///
/// I tillegg til å brukes til eksplisitte dereferensoperasjoner med (unary) `*`-operatøren i uforanderlige sammenhenger, brukes `Deref` også implisitt av kompilatoren under mange omstendigheter.
/// Denne mekanismen kalles ['`Deref` coercion'][more].
/// I foranderlige sammenhenger brukes [`DerefMut`].
///
/// Implementering av `Deref` for smarte pekere gjør det enkelt å få tilgang til dataene bak dem, og det er derfor de implementerer `Deref`.
/// På den annen side ble reglene angående `Deref` og [`DerefMut`] designet spesielt for å imøtekomme smarte pekere.
/// På grunn av dette bør **`Deref` bare implementeres for smarte pekere** for å unngå forvirring.
///
/// Av lignende grunner skal **denne trait aldri mislykkes**.Feil under dereferanse kan være ekstremt forvirrende når `Deref` påberopes implisitt.
///
/// # Mer om `Deref` tvang
///
/// Hvis `T` implementerer `Deref<Target = U>`, og `x` er en verdi av typen `T`, så:
///
/// * I uforanderlige sammenhenger tilsvarer `*x` (hvor `T` verken er en referanse eller en rå peker) `* Deref::deref(&x)`.
/// * Verdiene av typen `&T` blir tvunget til verdiene av typen `&U`
/// * `T` implisitt implementerer alle (immutable)-metodene av typen `U`.
///
/// For mer informasjon, besøk [the chapter in *The Rust Programming Language*][book] samt referanseseksjonene på [the dereference operator][ref-deref-op], [method resolution] og [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// En struktur med ett enkelt felt som er tilgjengelig ved å referere til strukturen.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Den resulterende typen etter dereferanse.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Henviser til verdien.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Brukes til mutable dereferensoperasjoner, som i `*v = 1;`.
///
/// I tillegg til å brukes til eksplisitte dereferensoperasjoner med (unary) `*`-operatøren i foranderlige sammenhenger, brukes `DerefMut` også implisitt av kompilatoren i mange tilfeller.
/// Denne mekanismen kalles ['`Deref` coercion'][more].
/// I uforanderlige sammenhenger brukes [`Deref`].
///
/// Implementering av `DerefMut` for smarte pekere gjør det enkelt å mutere dataene bak dem, og det er derfor de implementerer `DerefMut`.
/// På den annen side ble reglene angående [`Deref`] og `DerefMut` designet spesielt for å imøtekomme smarte pekere.
/// På grunn av dette, bør **`DerefMut` bare implementeres for smarte pekere** for å unngå forvirring.
///
/// Av lignende grunner skal **denne trait aldri mislykkes**.Feil under dereferanse kan være ekstremt forvirrende når `DerefMut` påberopes implisitt.
///
/// # Mer om `Deref` tvang
///
/// Hvis `T` implementerer `DerefMut<Target = U>`, og `x` er en verdi av typen `T`, så:
///
/// * I foranderlige sammenhenger tilsvarer `*x` (der `T` verken er en referanse eller en rå peker) `* DerefMut::deref_mut(&mut x)`.
/// * Verdiene av typen `&mut T` blir tvunget til verdiene av typen `&mut U`
/// * `T` implisitt implementerer alle (mutable)-metodene av typen `U`.
///
/// For mer informasjon, besøk [the chapter in *The Rust Programming Language*][book] samt referanseseksjonene på [the dereference operator][ref-deref-op], [method resolution] og [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// En struktur med et enkelt felt som kan modifiseres ved å referere til strukturen.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Gjennomsnittlig refererer verdien.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indikerer at en struktur kan brukes som metodemottaker uten `arbitrary_self_types`-funksjonen.
///
/// Dette er implementert av stdlib-pekertyper som `Box<T>`, `Rc<T>`, `&T` og `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}