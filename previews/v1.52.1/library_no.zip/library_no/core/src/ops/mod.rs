//! Overlastbare operatører.
//!
//! Implementering av disse traits lar deg overbelaste visse operatører.
//!
//! Noen av disse traits importeres av prelude, så de er tilgjengelige i alle Rust-programmer.Bare operatører støttet av traits kan bli overbelastet.
//! For eksempel kan tilleggsoperatøren (`+`) overbelastes gjennom [`Add`] trait, men siden oppdragsoperatøren (`=`) ikke har noen støtte trait, er det ingen måte å overbelaste dens semantikk.
//! I tillegg gir denne modulen ingen mekanisme for å opprette nye operatører.
//! Hvis det kreves ubegrenset overbelastning eller egendefinerte operatører, bør du se mot makroer eller kompilator-plugins for å utvide Rust s syntaks.
//!
//! Implementeringer av operatør traits bør være overraskende i deres respektive sammenhenger, med tanke på deres vanlige betydninger og [operator precedence].
//! For eksempel, når du implementerer [`Mul`], bør operasjonen ha en viss likhet med multiplikasjon (og dele forventede egenskaper som assosiativitet).
//!
//! Merk at `&&`-og `||`-operatørene kortslutter, det vil si at de bare vurderer sin andre operand hvis det bidrar til resultatet.Siden denne oppførselen ikke kan håndheves av traits, støttes ikke `&&` og `||` som overbelastbare operatører.
//!
//! Mange av operatørene tar sine operander etter verdi.I ikke-generiske sammenhenger som involverer innebygde typer, er dette vanligvis ikke et problem.
//! Bruk av disse operatørene i generisk kode krever imidlertid litt oppmerksomhet hvis verdiene må brukes på nytt i motsetning til å la operatørene konsumere dem.Et alternativ er å av og til bruke [`clone`].
//! Et annet alternativ er å stole på hvilke typer involverte som gir ytterligere operatørimplementeringer for referanser.
//! For eksempel, for en brukerdefinert type `T` som skal støtte tillegg, er det sannsynligvis en god idé å ha både `T` og `&T` til å implementere traits [`Add<T>`][`Add`] og [`Add<&T>`][`Add`] slik at generisk kode kan skrives uten unødvendig kloning.
//!
//!
//! # Examples
//!
//! Dette eksemplet oppretter en `Point`-struktur som implementerer [`Add`] og [`Sub`], og demonstrerer deretter å legge til og trekke fra to `punkt`er.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Se dokumentasjonen for hver trait for et eksempel på implementering.
//!
//! [`Fn`], [`FnMut`] og [`FnOnce`] traits er implementert av typer som kan påberopes som funksjoner.Merk at [`Fn`] tar `&self`, [`FnMut`] tar `&mut self` og [`FnOnce`] tar `self`.
//! Disse tilsvarer de tre typer metoder som kan påberopes på en forekomst: ring-for-referanse, samtale-for-mutabel-referanse og samtale for verdi.
//! Den vanligste bruken av disse traits er å fungere som grenser for funksjoner på høyere nivå som tar funksjoner eller nedleggelser som argumenter.
//!
//! Tar en [`Fn`] som parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Tar en [`FnMut`] som parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Tar en [`FnOnce`] som parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` bruker sine fangede variabler, så den kan ikke kjøres mer enn en gang
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Forsøk på å påkalle `func()` igjen vil kaste en `use of moved value`-feil for `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` kan ikke lenger påberopes på dette punktet
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;