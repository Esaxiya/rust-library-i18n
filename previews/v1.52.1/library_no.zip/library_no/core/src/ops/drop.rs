/// Tilpasset kode i destruktoren.
///
/// Når en verdi ikke lenger er nødvendig, kjører Rust en "destructor" på den verdien.
/// Den vanligste måten at en verdi ikke lenger er nødvendig, er når den går utenfor omfanget.Destruktører kan fremdeles løpe under andre omstendigheter, men vi kommer til å fokusere på muligheten for eksemplene her.
/// For å lære om noen av de andre tilfellene, se [the reference]-delen om destruktører.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Denne destruktoren består av to komponenter:
/// - En samtale til `Drop::drop` for den verdien, hvis denne spesielle `Drop` trait er implementert for sin type.
/// - Den automatisk genererte "drop glue" som rekursivt kaller destruktørene for alle feltene med denne verdien.
///
/// Da Rust automatisk kaller destruktørene for alle felt som er inneholdt, trenger du i de fleste tilfeller ikke implementere `Drop`.
/// Men det er noen tilfeller der det er nyttig, for eksempel for typer som administrerer en ressurs direkte.
/// Den ressursen kan være minne, det kan være en filbeskrivelse, det kan være en nettverkskontakt.
/// Når en verdi av den typen ikke lenger skal brukes, bør den "clean up" sin ressurs ved å frigjøre minnet eller lukke filen eller kontakten.
/// Dette er jobben til en destruktør, og derfor jobben til `Drop::drop`.
///
/// ## Examples
///
/// For å se destruktører i aksjon, la oss ta en titt på følgende program:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust vil først ringe `Drop::drop` for `_x` og deretter for både `_x.one` og `_x.two`, noe som betyr at kjøring av dette vil skrives ut
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Selv om vi fjerner implementeringen av `Drop` for `HasTwoDrop`, blir destruktørene av feltene fortsatt kalt.
/// Dette vil resultere i
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Du kan ikke ringe `Drop::drop` selv
///
/// Fordi `Drop::drop` brukes til å rydde opp i en verdi, kan det være farlig å bruke denne verdien etter at metoden er blitt kalt.
/// Ettersom `Drop::drop` ikke tar eierskap til innspillene, forhindrer Rust misbruk ved ikke å tillate deg å ringe `Drop::drop` direkte.
///
/// Med andre ord, hvis du prøvde å eksplisitt ringe `Drop::drop` i eksemplet ovenfor, vil du få en kompilatorfeil.
///
/// Hvis du eksplisitt vil kalle destruktoren for en verdi, kan [`mem::drop`] brukes i stedet.
///
/// [`mem::drop`]: drop
///
/// ## Drop order
///
/// Men hvilken av våre to `HasDrop` faller først?For strukturer er det samme rekkefølge som de er erklært: først `one`, deretter `two`.
/// Hvis du vil prøve dette selv, kan du endre `HasDrop` ovenfor for å inneholde noen data, som et heltall, og deretter bruke den i `println!` inne i `Drop`.
/// Denne oppførselen er garantert av språket.
///
/// I motsetning til for strukturer, faller lokale variabler i omvendt rekkefølge:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Dette vil skrives ut
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Se [the reference] for fullstendige regler.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` og `Drop` er eksklusive
///
/// Du kan ikke implementere både [`Copy`] og `Drop` på samme type.Typer som er `Copy` blir implisitt duplisert av kompilatoren, noe som gjør det veldig vanskelig å forutsi når og hvor ofte destruktører vil bli utført.
///
/// Som sådan kan disse typene ikke ha destruktorer.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Henretter destruktoren for denne typen.
    ///
    /// Denne metoden kalles implisitt når verdien går utenfor omfanget, og kan ikke kalles eksplisitt (dette er kompilatorfeil [E0040]).
    /// Imidlertid kan [`mem::drop`]-funksjonen i prelude brukes til å kalle argumentets `Drop`-implementering.
    ///
    /// Når denne metoden har blitt kalt, har `self` ennå ikke blitt fordelt.
    /// Det skjer bare etter at metoden er over.
    /// Hvis dette ikke var tilfelle, ville `self` være en dinglende referanse.
    ///
    /// # Panics
    ///
    /// Gitt at en [`panic!`] vil ringe `drop` når den avvikles, vil enhver [`panic!`] i en `drop`-implementering sannsynligvis avbrytes.
    ///
    /// Merk at selv om denne panics, anses verdien å være droppet;
    /// du må ikke føre til at `drop` blir ringt opp igjen.
    /// Dette håndteres normalt automatisk av kompilatoren, men når du bruker usikker kode, kan det noen ganger oppstå utilsiktet, spesielt når du bruker [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}