/// Versjonen av samtaleoperatøren som tar en uforanderlig mottaker.
///
/// Forekomster av `Fn` kan kalles gjentatte ganger uten å mutere tilstanden.
///
/// *Denne trait (`Fn`) skal ikke forveksles med [function pointers] (`fn`).*
///
/// `Fn` implementeres automatisk av lukkinger som bare tar uforanderlige referanser til fangede variabler eller ikke fanger noe i det hele tatt, samt (safe) [function pointers] (med noen forbehold, se dokumentasjonen deres for mer informasjon).
///
/// I tillegg, for alle typer `F` som implementerer `Fn`, implementerer `&F` også `Fn`.
///
/// Siden både [`FnMut`] og [`FnOnce`] er supertrekk på `Fn`, kan enhver forekomst av `Fn` brukes som en parameter der det forventes en [`FnMut`] eller [`FnOnce`].
///
/// Bruk `Fn` som en avgrensning når du vil godta en parameter av funksjonslignende type og trenger å ringe den gjentatte ganger og uten å mutere tilstand (f.eks. Når du ringer til den samtidig).
/// Hvis du ikke trenger så strenge krav, bruk [`FnMut`] eller [`FnOnce`] som grenser.
///
/// Se [chapter on closures in *The Rust Programming Language*][book] for mer informasjon om dette emnet.
///
/// Også bemerket er den spesielle syntaksen for `Fn` traits (f.eks
/// `Fn(usize, bool) -> bruk størrelse ').De som er interessert i de tekniske detaljene i dette, kan henvise til [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kaller en nedleggelse
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Bruker en `Fn`-parameter
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // slik at regex kan stole på den `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Utfører samtaleoperasjonen.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Versjonen av samtaleoperatøren som tar en mutbar mottaker.
///
/// Forekomster av `FnMut` kan kalles gjentatte ganger og kan mutere tilstanden.
///
/// `FnMut` implementeres automatisk av lukkinger som tar foranderlige referanser til fangede variabler, så vel som alle typer som implementerer [`Fn`], f.eks. (safe) [function pointers] (siden `FnMut` er et supertrait av [`Fn`]).
/// I tillegg, for alle typer `F` som implementerer `FnMut`, implementerer `&mut F` også `FnMut`.
///
/// Siden [`FnOnce`] er et supertrait av `FnMut`, kan enhver forekomst av `FnMut` brukes der en [`FnOnce`] forventes, og siden [`Fn`] er et underbilde av `FnMut`, kan enhver forekomst av [`Fn`] brukes der `FnMut` forventes.
///
/// Bruk `FnMut` som en avgrensning når du vil godta en parameter av funksjonslignende type og trenger å ringe den gjentatte ganger, mens du lar den mutere tilstanden.
/// Hvis du ikke vil at parameteren skal mutere tilstand, bruk [`Fn`] som en avgrensning;Hvis du ikke trenger å ringe det gjentatte ganger, bruk [`FnOnce`].
///
/// Se [chapter on closures in *The Rust Programming Language*][book] for mer informasjon om dette emnet.
///
/// Også bemerket er den spesielle syntaksen for `Fn` traits (f.eks
/// `Fn(usize, bool) -> bruk størrelse ').De som er interessert i de tekniske detaljene i dette, kan henvise til [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kaller en mutably fanger nedleggelse
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Bruker en `FnMut`-parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // slik at regex kan stole på den `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Utfører samtaleoperasjonen.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Versjonen av samtaleoperatøren som tar en byverdimottaker.
///
/// Forekomster av `FnOnce` kan kalles, men kan ikke kalles flere ganger.På grunn av dette, hvis det eneste man kjenner til en type er at den implementerer `FnOnce`, kan den bare ringes en gang.
///
/// `FnOnce` implementeres automatisk av nedleggelser som kan konsumere fangede variabler, så vel som alle typer som implementerer [`FnMut`], for eksempel (safe) [function pointers] (siden `FnOnce` er et supertrait av [`FnMut`]).
///
///
/// Siden både [`Fn`] og [`FnMut`] er underretter av `FnOnce`, kan enhver forekomst av [`Fn`] eller [`FnMut`] brukes der det forventes en `FnOnce`.
///
/// Bruk `FnOnce` som en avgrensning når du vil godta en parameter av funksjonslignende type og bare trenger å ringe den en gang.
/// Hvis du trenger å ringe parameteren gjentatte ganger, bruk [`FnMut`] som en avgrensning;Hvis du også trenger det for ikke å mutere tilstand, bruk [`Fn`].
///
/// Se [chapter on closures in *The Rust Programming Language*][book] for mer informasjon om dette emnet.
///
/// Også bemerket er den spesielle syntaksen for `Fn` traits (f.eks
/// `Fn(usize, bool) -> bruk størrelse ').De som er interessert i de tekniske detaljene i dette, kan henvise til [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Bruker en `FnOnce`-parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` bruker sine fangede variabler, så den kan ikke kjøres mer enn en gang.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Forsøk på å påkalle `func()` igjen vil kaste en `use of moved value`-feil for `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` kan ikke lenger påberopes på dette punktet
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // slik at regex kan stole på den `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Den returnerte typen etter at samtaleoperatøren er brukt.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Utfører samtaleoperasjonen.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}