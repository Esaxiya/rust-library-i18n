use crate::marker::Unpin;
use crate::pin::Pin;

/// Resultatet av en gjenopptakelse av generatoren.
///
/// Dette enumet returneres fra `Generator::resume`-metoden og indikerer mulige returverdier for en generator.
/// Foreløpig tilsvarer dette enten et suspensjonspunkt (`Yielded`) eller et avslutningspunkt (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generatoren suspendert med en verdi.
    ///
    /// Denne tilstanden indikerer at en generator er suspendert, og tilsvarer vanligvis en `yield`-setning.
    /// Verdien som er gitt i denne varianten tilsvarer uttrykket sendt til `yield` og lar generatorene gi en verdi hver gang de gir.
    ///
    ///
    Yielded(Y),

    /// Generatoren fullført med en returverdi.
    ///
    /// Denne tilstanden indikerer at en generator er ferdig med utførelsen med den oppgitte verdien.
    /// Når en generator har returnert `Complete`, regnes det som en programmeringsfeil å ringe `resume` igjen.
    ///
    Complete(R),
}

/// trait implementert av innebygde generatorer.
///
/// Generatorer, også ofte referert til som coroutines, er for tiden en eksperimentell språkfunksjon i Rust.
/// Lagt til i [RFC 2033]-generatorer er for tiden ment å primært gi en byggestein for async/await-syntaksen, men vil trolig utvide til også å gi en ergonomisk definisjon for iteratorer og andre primitiver.
///
///
/// Syntaksen og semantikken for generatorer er ustabil og vil kreve ytterligere RFC for stabilisering.På denne tiden er syntaksen liknende:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Mer dokumentasjon av generatorer finner du i den ustabile boka.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Hvilken verdi denne generatoren gir.
    ///
    /// Denne tilknyttede typen tilsvarer `yield`-uttrykket og verdiene som kan returneres hver gang en generator gir.
    ///
    /// For eksempel vil en iterator-som-en-generator sannsynligvis ha denne typen `T`, den typen blir iterert over.
    ///
    type Yield;

    /// Hvilken verdi denne generatoren returnerer.
    ///
    /// Dette tilsvarer typen som returneres fra en generator enten med en `return`-setning eller implisitt som det siste uttrykket for en generator bokstavelig.
    /// For eksempel vil futures bruke dette som `Result<T, E>` da det representerer en fullført future.
    ///
    ///
    type Return;

    /// Gjenopptar kjøringen av denne generatoren.
    ///
    /// Denne funksjonen vil gjenoppta kjøringen av generatoren eller starte kjøringen hvis den ikke allerede har gjort det.
    /// Denne samtalen kommer tilbake til generatorens siste suspensjonspunkt, og gjenopptar kjøringen fra den nyeste `yield`.
    /// Generatoren vil fortsette å kjøre til den enten gir eller returnerer, på hvilket tidspunkt denne funksjonen kommer tilbake.
    ///
    /// # Returverdi
    ///
    /// `GeneratorState`-enum returnert fra denne funksjonen indikerer hvilken tilstand generatoren er i når den returneres.
    /// Hvis `Yielded`-varianten returneres, har generatoren nådd et suspensjonspunkt og en verdi er gitt.
    /// Generatorer i denne tilstanden er tilgjengelig for gjenopptakelse på et senere tidspunkt.
    ///
    /// Hvis `Complete` returneres, er generatoren helt ferdig med den oppgitte verdien.Det er ugyldig at generatoren gjenopptas igjen.
    ///
    /// # Panics
    ///
    /// Denne funksjonen kan panic hvis den kalles etter at `Complete`-varianten er returnert tidligere.
    /// Mens generatorbokstavene på språket garanteres panic når de gjenopptas etter `Complete`, er dette ikke garantert for alle implementeringer av `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}