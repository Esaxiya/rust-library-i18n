use crate::marker::Unsize;

/// Trait som indikerer at dette er en peker eller en innpakning for en, der unsizing kan utføres på pointeen.
///
/// Se [DST coercion RFC][dst-coerce] og [the nomicon entry on coercion][nomicon-coerce] for mer informasjon.
///
/// For innebygde pekertyper vil pekere til `T` tvinge pekere til `U` hvis `T: Unsize<U>` ved å konvertere fra en tynn peker til en fettpeker.
///
/// For tilpassede typer fungerer tvangen her ved å tvinge `Foo<T>` til `Foo<U>` forutsatt at det eksisterer en impl. Av `CoerceUnsized<Foo<U>> for Foo<T>`.
/// En slik impl kan bare skrives hvis `Foo<T>` bare har et enkelt ikke-fantomdatafelt som involverer `T`.
/// Hvis typen av feltet er `Bar<T>`, må det eksistere en implementering av `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Tvangen vil fungere ved å tvinge `Bar<T>`-feltet til `Bar<U>` og fylle ut resten av feltene fra `Foo<T>` for å lage en `Foo<U>`.
/// Dette vil effektivt bore ned til et pekefelt og tvinge det.
///
/// For smarte pekere vil du generelt implementere `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, med en valgfri `?Sized` bundet på selve `T`.
/// For innpakningstyper som legger direkte inn `T` som `Cell<T>` og `RefCell<T>`, kan du implementere `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` direkte.
///
/// Dette vil la tvang av typer som `Cell<Box<T>>` virke.
///
/// [`Unsize`][unsize] brukes til å merke typer som kan tvinges til sommertid hvis de er bak pekere.Den implementeres automatisk av kompilatoren.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *konst T->* konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Dette brukes for objektsikkerhet, for å kontrollere at mottakertypen til en metode kan sendes videre.
///
/// Et eksempel på implementering av trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *konst T->* konst U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}