/// En trait for å tilpasse oppførselen til `?`-operatøren.
///
/// En type som implementerer `Try` er en som har en kanonisk måte å se den på i form av en success/failure-dikotomi.
/// Denne trait tillater både å trekke ut disse suksess-eller feilverdiene fra en eksisterende forekomst og å opprette en ny forekomst fra en suksess-eller feilverdi.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Typen av denne verdien når den blir sett på som vellykket.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Typen av denne verdien når den blir sett på som mislykket.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Gjelder "?"-operatøren.En retur på `Ok(t)` betyr at utførelsen skal fortsette normalt, og resultatet av `?` er verdien `t`.
    /// En retur av `Err(e)` betyr at utførelse skal branch til det innerste som omslutter `catch`, eller returnere fra funksjonen.
    ///
    /// Hvis et `Err(e)`-resultat returneres, vil verdien `e` være "wrapped" i returtypen for det vedlagte omfanget (som selv må implementere `Try`).
    ///
    /// Spesifikt returneres verdien `X::from_error(From::from(e))`, der `X` er returtypen for den omsluttende funksjonen.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Pakk inn en feilverdi for å konstruere det sammensatte resultatet.
    /// For eksempel er `Result::Err(x)` og `Result::from_error(x)` ekvivalente.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Pakk en OK-verdi for å konstruere det sammensatte resultatet.
    /// For eksempel er `Result::Ok(x)` og `Result::from_ok(x)` ekvivalente.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}