//! Panic-støtte for libcore
//!
//! Kjernebiblioteket kan ikke definere panikk, men det erklærer * panikk.
//! Dette betyr at funksjonene inne i libcore er tillatt å panic, men for å være nyttige må en oppstrøms crate definere panikk for libcore å bruke.
//! Det nåværende grensesnittet for panikk er:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Denne definisjonen tillater panikk med noen generell melding, men den tillater ikke feil med en `Box<Any>`-verdi.
//! (`PanicInfo` inneholder bare en `&(dyn Any + Send)`, som vi fyller ut en dummy-verdi i `PanicInfo: : internal_constructor`.) Årsaken til dette er at libcore ikke har lov til å allokere.
//!
//!
//! Denne modulen inneholder noen få andre panikkfunksjoner, men dette er bare de nødvendige langelementene for kompilatoren.Alle panics kanaliseres gjennom denne ene funksjonen.
//! Det faktiske symbolet er erklært gjennom `#[panic_handler]`-attributtet.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Den underliggende implementeringen av libcores `panic!`-makro når ingen formatering brukes.
#[cold]
// aldri inline med mindre panic_immediate_abort for å unngå kodeoppblåsthet på anropssidene så mye som mulig
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // nødvendig av codegen for panic på overløp og andre `Assert` MIR-terminatorer
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Bruk Arguments::new_v1 i stedet for format_args! ("{}", Expr) for potensielt å redusere størrelsesoverhead.
    // Format_argene!makro bruker str's Display trait for å skrive expr, som kaller Formatter::pad, som må imøtekomme strengavkorting og polstring (selv om ingen brukes her).
    //
    // Bruk av Arguments::new_v1 kan tillate kompilatoren å utelate Formatter::pad fra utdatabinæren, og spare opptil noen kilobyte.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // nødvendig for con-evaluert panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // nødvendig av codegen for panic på OOB array/slice-tilgang
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Den underliggende implementeringen av libcores `panic!`-makro når formatering brukes.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // MERKNAD Denne funksjonen krysser aldri FFI-grensen;Det er en Rust-til-Rust-samtale som blir løst til `#[panic_handler]`-funksjonen.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SIKKERHET: `panic_impl` er definert i sikker Rust-kode og er dermed trygg å ringe.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Intern funksjon for `assert_eq!` og `assert_ne!` makroer
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}