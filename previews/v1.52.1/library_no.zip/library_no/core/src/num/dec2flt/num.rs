//! Verktøyfunksjoner for bignums som ikke gir for mye mening å gjøre om til metoder.

// FIXME Denne modulens navn er litt uheldig, siden andre moduler også importerer `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Test om avkorting av alle biter som er mindre signifikante enn `ones_place`, introduserer en relativ feil mindre, lik eller større enn 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Hvis alle gjenværende biter er null, er det= 0.5 ULP, ellers> 0.5 Hvis det ikke er flere biter (half_bit==0), returnerer nedenstående også lik.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Konverterer en ASCII-streng som bare inneholder desimaltegn til en `u64`.
///
/// Utfører ikke kontroller for overløp eller ugyldige tegn, så hvis den som ringer ikke er forsiktig, er resultatet falskt og kan panic (selv om det ikke vil være `unsafe`).
/// I tillegg blir tomme strenger behandlet som null.
/// Denne funksjonen eksisterer pga
///
/// 1. å bruke `FromStr` på `&[u8]` krever `from_utf8_unchecked`, som er dårlig, og
/// 2. å slå sammen resultatene av `integral.parse()` og `fractional.parse()` er mer komplisert enn hele denne funksjonen.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Konverterer en streng med ASCII-sifre til en bignum.
///
/// I likhet med `from_str_unchecked`, er denne funksjonen avhengig av at parseren lukker ut ikke-sifre.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Pakk ut et bignum til et 64-biters heltall.Panics hvis tallet er for stort.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Henter ut en rekke biter.

/// Indeks 0 er den minst betydningsfulle biten, og rekkevidden er halvåpent som vanlig.
/// Panics hvis du blir bedt om å trekke ut flere biter enn det som passer inn i returtypen.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}