//! De forskjellige algoritmene fra papiret.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Antall betydningsbiter i Fp
const P: u32 = 64;

// Vi lagrer ganske enkelt den beste tilnærmingen for *alle* eksponenter, slik at variabelen "h" og tilhørende forhold kan utelates.
// Dette bytter ytelse for et par kilobyte plass.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// I de fleste arkitekturer har flytende punktoperasjoner en eksplisitt bitstørrelse, og derfor bestemmes nøyaktigheten av beregningen per operasjon.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// På x86 brukes x87 FPU for flyteoperasjoner hvis SSE/SSE2-utvidelsene ikke er tilgjengelige.
// x87 FPU opererer med 80 bit presisjon som standard, noe som betyr at operasjoner vil rundes til 80 bits, noe som fører til at dobbel avrunding skjer når verdiene til slutt representeres som
//
// 32/64 bit float verdier.For å overvinne dette kan FPU-kontrollordet settes slik at beregningene utføres i ønsket presisjon.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// En struktur som brukes til å bevare den opprinnelige verdien av FPU-kontrollordet, slik at den kan gjenopprettes når strukturen slippes.
    ///
    ///
    /// x87 FPU er et 16-bits register med felt som følger:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentasjonen for alle feltene er tilgjengelig i IA-32 Architectures Software Developer's Manual (Volume 1).
    ///
    /// Det eneste feltet som er relevant for følgende kode er PC, Precision Control.
    /// Dette feltet bestemmer presisjonen til operasjonene utført av FPU.
    /// Den kan settes til:
    ///  - 0b00, enkelt presisjon, dvs. 32-bits
    ///  - 0b10, dobbel presisjon dvs. 64-bits
    ///  - 0b11, dobbel utvidet presisjon dvs. 80-bits (standardtilstand) 0b01-verdien er reservert og skal ikke brukes.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SIKKERHET: `fldcw`-instruksjonene er revidert for å kunne fungere riktig med
        // hvilken som helst `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Vi bruker ATT-syntaks for å støtte LLVM 8 og LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Stiller presisjonsfeltet til FPU til `T` og returnerer en `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Beregn verdien for Precision Control-feltet som passer for `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 biter
            8 => 0x0200, // 64 bits
            _ => 0x0300, // standard, 80 bits
        };

        // Få den opprinnelige verdien av kontrollordet for å gjenopprette det senere, når `FPUControlWord`-strukturen slippes SIKKERHET: `fnstcw`-instruksjonen har blitt revidert for å kunne fungere riktig med hvilken som helst `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Vi bruker ATT-syntaks for å støtte LLVM 8 og LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Still kontrollordet til ønsket presisjon.
        // Dette oppnås ved å maskere bort den gamle presisjonen (bit 8 og 9, 0x300) og erstatte den med presisjonsflagget beregnet ovenfor.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Den raske banen til Bellerophon ved hjelp av heltall og flyter i maskinstørrelse.
///
/// Dette trekkes ut i en egen funksjon slik at den kan forsøkes før en bignum konstrueres.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Vi sammenligner den eksakte verdien til MAX_SIG nær slutten, dette er bare en rask, billig avvisning (og frigjør også resten av koden fra å bekymre seg for understrøm).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Den raske stien avhenger avgjørende av at aritmetikken blir avrundet til riktig antall biter uten noen mellomrunding.
    // På x86 (uten SSE eller SSE2) krever dette at presisjonen til x87 FPU-stakken endres slik at den direkte avrunder til 64/32-bit.
    // `set_precision`-funksjonen tar seg av å sette presisjonen på arkitekturer som krever innstilling ved å endre den globale tilstanden (som kontrollordet til x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Saken e <0 kan ikke brettes inn i den andre branch.
    // Negative krefter resulterer i en gjentatt brøkdel i binær, som er avrundet, noe som forårsaker reelle (og noen ganger ganske betydningsfulle!) Feil i det endelige resultatet.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritme Bellerophon er triviell kode begrunnet med ikke-triviell numerisk analyse.
///
/// Den avrunder `` f '' til en flottør med 64 biters signifikant og multipliserer den med den beste tilnærmingen til `10^e` (i samme flytende punktformat).Dette er ofte nok til å få riktig resultat.
/// Imidlertid, når resultatet er nær halvveis mellom to tilstøtende (ordinary)-flyter, betyr den sammensatte avrundingsfeilen fra å multiplisere to tilnærminger, at resultatet kan være av med noen få biter.
/// Når dette skjer, løser den iterative algoritmen R ting.
///
/// Den håndbølgede "close to halfway" gjøres presis ved den numeriske analysen i papiret.
/// Med Clinger ord:
///
/// > Slop, uttrykt i enheter med den minste signifikante biten, er en inkluderende grense for feilen
/// > akkumulert under flytpunktberegningen av tilnærmingen til f * 10 ^ e.(Slop er
/// > ikke en bundet for den sanne feilen, men begrenser forskjellen mellom tilnærmingen z og
/// > best mulig tilnærming som bruker p biter av betydning.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Sakene abs(e) <log5(2^N) er i fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Er skråningen stor nok til å gjøre en forskjell når du avrunder til n biter?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// En iterativ algoritme som forbedrer tilnærmet flytende punkt på `f * 10^e`.
///
/// Hver iterasjon kommer til slutt en enhet nærmere, noe som selvfølgelig tar veldig lang tid å konvergere hvis `z0` til og med er mildt av.
/// Heldigvis, når den brukes som tilbakeslag for Bellerophon, er starttilnærmingen av høyst en ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Finn positive heltall `x`, `y` slik at `x / y` er nøyaktig `(f *10^e) / (m* 2^k)`.
        // Dette unngår ikke bare å håndtere tegn på `e` og `k`, vi eliminerer også kraften til to som er felles for `10^e` og `2^k` for å gjøre tallene mindre.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Dette skrives litt vanskelig fordi bignums ikke støtter negative tall, så vi bruker absolutt verdi + tegninformasjon.
        // Multiplikasjonen med m_digits kan ikke flyte over.
        // Hvis `x` eller `y` er store nok til at vi trenger å bekymre oss for overløp, er de også store nok til at `make_ratio` har redusert brøkdelen med en faktor på 2 ^ 64 eller mer.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Trenger ikke x lenger, lagre en clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Trenger fortsatt y, lag en kopi.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Gitt `x = f` og `y = m` der `f` representerer inngangs desimaltall som vanlig og `m` er betydningen av en flytende tilnærming, gjør forholdet `x / y` lik `(f *10^e) / (m* 2^k)`, muligens redusert med en kraft på to som begge har til felles.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, bortsett fra at vi reduserer brøken med en kraft på to.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Dette kan ikke flyte over fordi det krever positivt `e` og negativt `k`, noe som bare kan skje for verdier som er ekstremt nær 1, noe som betyr at `e` og `k` vil være relativt små.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Dette kan ikke flyte over, se ovenfor.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), igjen redusert med en felles kraft på to.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konseptuelt er algoritme M den enkleste måten å konvertere en desimal til en flottør.
///
/// Vi danner et forhold som er lik `f * 10^e`, og kaster deretter krefter på to til det gir en gyldig flottørbetydning.
/// Den binære eksponenten `k` er antall ganger vi multipliserte teller eller nevner med to, dvs. at `f *10^e` til enhver tid er lik `(u / v)* 2^k`.
/// Når vi har funnet ut betydningen, trenger vi bare å runde av ved å inspisere resten av delingen, noe som gjøres i hjelpefunksjoner lenger nedenfor.
///
///
/// Denne algoritmen er veldig treg, selv med optimaliseringen beskrevet i `quick_start()`.
/// Imidlertid er det den enkleste av algoritmene å tilpasse seg for overløp, understrøm og subnormale resultater.
/// Denne implementeringen tar over når Bellerophon og Algorithm R blir overveldet.
/// Det er enkelt å oppdage understrømning og overløp: Forholdet er fortsatt ikke innen rekkevidde, men minimum/maximum-eksponenten er nådd.
/// I tilfelle overløp returnerer vi bare uendelig.
///
/// Håndtering av understrømning og undernormaler er vanskeligere.
/// Et stort problem er at forholdet med minimum eksponent fortsatt kan være for stort for et betydningsfullt.
/// Se underflow() for detaljer.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME mulig optimalisering: generaliser big_to_fp slik at vi kan gjøre tilsvarende fp_to_float(big_to_fp(u)) her, bare uten dobbel avrunding.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Vi må stoppe ved minimumseksponenten, hvis vi venter til `k < T::MIN_EXP_INT`, ville vi ha en faktor på to.
            // Dessverre betyr dette at vi må spesielle tilfeller normale tall med minimum eksponent.
            // FIXME finner en mer elegant formulering, men kjør `tiny-pow10`-testen for å sikre at den faktisk er riktig!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Hopp over de fleste algoritm M-iterasjoner ved å sjekke bitlengden.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitlengden er et estimat av de to grunnleggende logaritmene, og log(u / v) = log(u), log(v).
    // Anslaget er maksimalt av 1, men alltid et underestimat, så feilen på log(u) og log(v) er av samme tegn og avbrytes (hvis begge er store).
    // Derfor er feilen for log(u / v) på det meste også.
    // Målforholdet er en der u/v er i et betydelig omfang.Dermed er termineringstilstanden vår log2(u / v) som er betydningsfulle biter, plus/minus en.
    // FIXME Å se på den andre biten kan forbedre estimatet og unngå noen flere divisjoner.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Understrøm eller undernormal.La det være til hovedfunksjonen.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Flyte.La det være til hovedfunksjonen.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Forholdet er ikke en rekkevidde med minimum eksponent, så vi må avrunde overflødige biter og justere eksponenten deretter.
    // Den virkelige verdien ser nå slik ut:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(representert av rem)
    //
    // Derfor, når de avrundede bitene er!= 0.5 ULP, bestemmer de avrundingen på egenhånd.
    // Når de er like og resten ikke er null, må verdien fortsatt avrundes.
    // Bare når de avrundede bitene er 1/2 og resten er null, har vi en halv til jevn situasjon.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Vanlig rund-til-jevn, tilslørt ved å måtte runde basert på resten av en divisjon.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}