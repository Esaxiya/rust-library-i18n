//! Litt fikling på positive IEEE 754 flottører.Negative tall er ikke og trenger ikke håndteres.
//! Normale flytende tall har en kanonisk representasjon som (frac, exp) slik at verdien er 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) der N er antall bits.
//!
//! Undernormaler er litt forskjellige og rare, men det samme prinsippet gjelder.
//!
//! Her representerer vi dem imidlertid som (sig, k) med f positive, slik at verdien er f *
//! 2 <sup>e</sup> .Foruten å gjøre "hidden bit" eksplisitt, endrer dette eksponenten ved det såkalte mantissaskiftet.
//!
//! Sagt på en annen måte, normalt skrives flåter som (1), men her skrives de som (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Vi kaller (1) for **fraksjonell representasjon** og (2) for **integral representasjon**.
//!
//! Mange funksjoner i denne modulen håndterer bare normale tall.Dec2flt-rutinene tar konservativt den universelt korrekte sakte banen (Algoritme M) for veldig små og veldig store tall.
//! Den algoritmen trenger bare next_float() som håndterer undernormaler og nuller.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// En hjelper trait for å unngå å duplisere i utgangspunktet all konverteringskoden for `f32` og `f64`.
///
/// Se foreldremodulens dokumentkommentar for hvorfor dette er nødvendig.
///
/// Bør **aldri** implementeres for andre typer eller brukes utenfor dec2flt-modulen.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Type brukt av `to_bits` og `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Utfører en rå transmutasjon til et helt tall.
    fn to_bits(self) -> Self::Bits;

    /// Utfører en rå transmutasjon fra et helt tall.
    fn from_bits(v: Self::Bits) -> Self;

    /// Returnerer kategorien som dette tallet faller inn under.
    fn classify(self) -> FpCategory;

    /// Returnerer mantissen, eksponenten og signerer som heltall.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Avkoder flottøren.
    fn unpack(self) -> Unpacked;

    /// Kaster fra et lite heltall som kan vises nøyaktig.
    /// Panic hvis heltallet ikke kan vises, sørger den andre koden i denne modulen for å aldri la det skje.
    fn from_int(x: u64) -> Self;

    /// Henter verdien 10 <sup>e</sup> fra en forhåndsberegnet tabell.
    /// Panics for `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Hva navnet sier.
    /// Det er lettere å kode hardt enn å sjonglere med egenart og håper LLVM konstant bretter det.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // En konservativ bundet til desimaltallene på innganger som ikke kan produsere overløp eller null eller
    /// undernormale.Sannsynligvis desimaleksponenten for den maksimale normale verdien, derav navnet.
    const MAX_NORMAL_DIGITS: usize;

    /// Når det viktigste desimaltallet har en plassverdi større enn dette, er tallet absolutt avrundet til uendelig.
    ///
    const INF_CUTOFF: i64;

    /// Når det viktigste desimaltallet har en plassverdi mindre enn dette, er tallet absolutt avrundet til null.
    ///
    const ZERO_CUTOFF: i64;

    /// Antall bits i eksponenten.
    const EXP_BITS: u8;

    /// Antall bits i signifikant,*inkludert* den skjulte biten.
    const SIG_BITS: u8;

    /// Antall bits i signifikant,*unntatt* den skjulte biten.
    const EXPLICIT_SIG_BITS: u8;

    /// Den maksimale juridiske eksponenten i brøkdel representasjon.
    const MAX_EXP: i16;

    /// Den minste juridiske eksponenten i fraksjonell representasjon, unntatt undernormale.
    const MIN_EXP: i16;

    /// `MAX_EXP` for integrert representasjon, dvs. med skiftet brukt.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodet (dvs. med offset bias)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` for integrert representasjon, dvs. med skiftet brukt.
    const MIN_EXP_INT: i16;

    /// Den maksimale normaliserte signifikansen i integrert representasjon.
    const MAX_SIG: u64;

    /// Den minimale normaliserte betydningen i integrert representasjon.
    const MIN_SIG: u64;
}

// For det meste en løsning for #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Returnerer mantissen, eksponenten og signerer som heltall.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Eksponent bias + mantissa skift
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe er usikker på om `as` runder riktig på alle plattformer.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Returnerer mantissen, eksponenten og signerer som heltall.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Eksponent bias + mantissa skift
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe er usikker på om `as` runder riktig på alle plattformer.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konverterer en `Fp` til nærmeste maskinflytetype.
/// Håndterer ikke unormale resultater.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f er 64 bit, så xe har en mantissaskift på 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Rund 64-bits signifikant til T::SIG_BITS-biter med halv til jevn.
/// Håndterer ikke eksponentoverløp.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Juster mantissaskift
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Invers av `RawFloat::unpack()` for normaliserte tall.
/// Panics hvis signifikant eller eksponent ikke er gyldig for normaliserte tall.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Fjern den skjulte biten
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Juster eksponenten for eksponentforspenning og mantissaskift
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // La tegnbiten være 0 ("+"), våre tall er alle positive
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstruer et subnormalt.En mantissa på 0 er tillatt og konstruerer null.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodet eksponent er 0, tegnbit er 0, så vi må bare tolke bitene på nytt.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Omtrentlig et bignum med en Fp.Runder innen 0.5 ULP med halv til jevn.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Vi kutter av alle biter før indeksen `start`, dvs. vi høyreklikker effektivt med en mengde på `start`, så dette er også eksponenten vi trenger.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Rund (half-to-even) avhengig av de avkortede bitene.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Finner det største flytpunktet strengt mindre enn argumentet.
/// Håndterer ikke undernormale, null eller eksponent understrømning.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Finn det minste flytende nummeret som er strengt større enn argumentet.
// Denne operasjonen er mettende, dvs. next_float(inf) ==inf.
// I motsetning til de fleste koder i denne modulen, håndterer denne funksjonen null, undernormaler og uendeligheter.
// Imidlertid, som alle andre koder her, handler det ikke om NaN og negative tall.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Dette virker for godt til å være sant, men det fungerer.
        // 0.0 er kodet som ordet helt null.Undernormaler er 0x000m ... m hvor m er mantissen.
        // Spesielt er det minste subnormale 0x0 ... 01 og det største er 0x000F ... F.
        // Det minste normale tallet er 0x0010 ... 0, så dette hjørnesaken fungerer også.
        // Hvis inkrementet flyter over mantissen, øker bærebiten eksponenten slik vi vil, og mantissabitene blir null.
        // På grunn av den skjulte bitkonvensjonen, er dette også akkurat det vi vil ha!
        // Til slutt, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}