//! Validere og dekomponere en desimalstreng av skjemaet:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Med andre ord standard syntaks med flytende punkt, med to unntak: Ingen tegn og ingen håndtering av "inf" og "NaN".Disse håndteres av driverfunksjonen (super::dec2flt).
//!
//! Selv om det er relativt enkelt å gjenkjenne gyldige innganger, må denne modulen også avvise de utallige ugyldige variasjonene, aldri panic, og utføre en rekke kontroller som de andre modulene stoler på for ikke å panic (eller overflyt) i sin tur.
//!
//! For å gjøre saken verre, alt som skjer i ett enkelt pass over input.
//! Så vær forsiktig når du endrer noe, og dobbeltsjekk med de andre modulene.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// De interessante delene av en desimalstreng.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Desimaleksponenten har garantert færre enn 18 desimaltegn.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Sjekker om inngangsstrengen er et gyldig flytende nummer, og i så fall finner du den integrerte delen, brøkdelen og eksponenten i den.
/// Håndterer ikke skilt.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Ingen sifre før 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Vi krever minst et enkelt siffer før eller etter poenget.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Etterfølgende søppel etter brøkdel
            }
        }
        _ => Invalid, // Etterfølgende søppel etter førstesifret streng
    }
}

/// Skjærer av desimaltegn opp til det første ikke-sifrede tegnet.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Eksponentutvinning og feilkontroll.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Etterfølgende søppel etter eksponent
    }
    if number.is_empty() {
        return Invalid; // Tom eksponent
    }
    // På dette punktet har vi absolutt en gyldig streng med sifre.Det kan være for lang tid å sette i en `i64`, men hvis den er så stor, er inngangen absolutt null eller uendelig.
    // Siden hvert null i desimaltegnene bare justerer eksponenten med +/-1, vil inngangen ved eksp=10 ^ 18 måtte være 17 exabyte (!) av nuller for å komme til og med eksternt nær å være endelig.
    //
    // Dette er ikke akkurat en brukssak vi trenger å imøtekomme.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}