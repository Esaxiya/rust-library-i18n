//! Konstanter for usignert heltallstype med pekestørrelse.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Ny kode skal bruke de tilknyttede konstantene direkte på den primitive typen.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }