//! Konstanter for 8-biters usignert heltallstype.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Ny kode skal bruke de tilknyttede konstantene direkte på den primitive typen.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }