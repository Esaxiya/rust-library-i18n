//! Konstanter for den 16-bits signerte heltalstypen.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Ny kode skal bruke de tilknyttede konstantene direkte på den primitive typen.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }