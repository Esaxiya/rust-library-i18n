//! Konstanter for den 64-bits signerte heltalstypen.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Ny kode skal bruke de tilknyttede konstantene direkte på den primitive typen.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }