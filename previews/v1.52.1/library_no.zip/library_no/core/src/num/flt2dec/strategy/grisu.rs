//! Rust-tilpasning av Grisu3-algoritmen beskrevet i "Skrive ut flytende punktnumre raskt og nøyaktig med heltall" [^ 1].
//! Den bruker omtrent 1 KB forhåndskalkulert tabell, og i sin tur er det veldig raskt for de fleste innganger.
//!
//! [^1]: Florian Loitsch.2010. Skrive ut flytende tall raskt og
//!   nøyaktig med heltall.SIGPLAN Ikke.45, 6 (juni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// se kommentarene i `format_shortest_opt` for begrunnelsen.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Gitt `x > 0`, returnerer `(k, 10^k)` slik at `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Den korteste modusimplementeringen for Grisu.
///
/// Den returnerer `None` når den ellers ville gitt en unøyaktig representasjon.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // vi trenger minst tre biter med ekstra presisjon

    // start med de normaliserte verdiene med den delte eksponenten
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // finn hvilken som helst `cached = 10^minusk` slik at `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // siden `plus` er normalisert, betyr dette `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // gitt våre valg av `ALPHA` og `GAMMA`, setter dette `plus * cached` i `[4, 2^32)`.
    //
    // det er åpenbart ønskelig å maksimere `GAMMA - ALPHA`, slik at vi ikke trenger mange hurtigbufrede krefter på 10, men det er noen hensyn:
    //
    //
    // 1. Vi ønsker å holde `floor(plus * cached)` innenfor `u32` siden det trenger en kostbar divisjon.
    //    (dette kan ikke unngås, resten kreves for nøyaktighetsestimering.)
    // 2.
    // resten av `floor(plus * cached)` multipliseres gjentatte ganger med 10, og den skal ikke renne over.
    //
    // den første gir `64 + GAMMA <= 32`, mens den andre gir `10 * 2^-ALPHA <= 2^64`;
    // -60 og -32 er det maksimale området med denne begrensningen, og V8 bruker dem også.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skala fps.dette gir maksimal feil på 1 ulp (bevist fra setning 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-faktisk område på minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // over `minus`, `v` og `plus` er *kvantiserte* tilnærminger (feil <1 ulp).
    // ettersom vi ikke vet at feilen er positiv eller negativ, bruker vi to tilnærminger fordelt likt og har den maksimale feilen på 2 ul.
    //
    // "unsafe region" er et liberalt intervall som vi opprinnelig genererer.
    // "safe region" er et konservativt intervall som vi bare aksepterer.
    // vi starter med riktig repr innen den usikre regionen, og prøver å finne den nærmeste repr til `v` som også er innenfor den sikre regionen.
    // hvis vi ikke kan, gir vi opp.
    //
    let plus1 = plus.f + 1;
    // la plus0 = plus.f, 1;//bare for forklaring la minus0 = minus.f + 1;//bare for forklaring
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // delt eksponent

    // del `plus1` i integrerte og brøkdeler.
    // integrerte deler er garantert å passe i u32, siden hurtigbufret kraft garanterer `plus < 2^32` og normalisert `plus.f` alltid er mindre enn `2^64 - 2^4` på grunn av presisjonskravet.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // beregne den største `10^max_kappa` ikke mer enn `plus1` (altså `plus1 < 10^(max_kappa+1)`).
    // dette er en øvre grense på `kappa` nedenfor.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorem 6.2: hvis `k` er det største heltallst
    // `0 <= y mod 10^k <= y - x`,              da er `V = floor(y / 10^k) * 10^k` i `[x, y]` og en av de korteste representasjonene (med minimalt antall signifikante sifre) i det området.
    //
    //
    // finn sifferlengden `kappa` mellom `(minus1, plus1)` i henhold til setning 6.2.
    // Teorem 6.2 kan adopteres for å ekskludere `x` ved å kreve `y mod 10^k < y - x` i stedet.
    // (f.eks. `x` =32000, `y` =32777; `kappa` =2 siden `y mod 10 ^ 3=777 <y, x=777`.) algoritmen er avhengig av den senere bekreftelsesfasen for å ekskludere `y`.
    //
    let delta1 = plus1 - minus1;
    // la delta1int=(delta1>> e) som størrelse;//bare for forklaring
    let delta1frac = delta1 & ((1 << e) - 1);

    // gjengi integrerte deler, mens du sjekker for nøyaktigheten ved hvert trinn.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // sifre som ennå ikke skal gjengis
    loop {
        // vi har alltid minst ett siffer å gjengi, som `plus1 >= 10^kappa`-invarianter:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (det følger at `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // del `remainder` med `10^kappa`.begge er skalert av `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; vi har funnet riktig `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // skala 10 ^ kappa tilbake til den delte eksponenten
            return round_and_weed(
                // SIKKERHET: Vi initialiserte minnet ovenfor.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // bryt løkken når vi har gjengitt alle integrerte sifre.
        // det nøyaktige antallet sifre er `max_kappa + 1` som `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // gjenopprette invarianter
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // gjengi brøkdeler, mens du sjekker for nøyaktigheten ved hvert trinn.
    // denne gangen stoler vi på gjentatte multiplikasjoner, ettersom divisjon vil miste presisjonen.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // neste siffer skal være viktig da vi har testet det før vi bryter ut invarianter, der `m = max_kappa + 1` (antall sifre i den integrerte delen):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // vil ikke flyte over, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // del `remainder` med `10^kappa`.
        // begge er skalert av `2^e / 10^kappa`, så sistnevnte er implisitt her.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // implisitt divisor
            return round_and_weed(
                // SIKKERHET: Vi initialiserte minnet ovenfor.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // gjenopprette invarianter
        kappa -= 1;
        remainder = r;
    }

    // Vi har generert alle viktige sifre på `plus1`, men er ikke sikre på om det er det optimale.
    // for eksempel, hvis `minus1` er 3.14153 ... og `plus1` er 3.14158 ..., er det 5 forskjellige korteste representasjoner fra 3.14154 til 3.14158, men vi har bare den største.
    // Vi må redusere det siste sifferet og kontrollere om dette er den optimale repr.
    // det er på det meste 9 kandidater (..1 til ..9), så dette er ganske raskt.("rounding" fase)
    //
    // funksjonen sjekker om denne "optimal" repr faktisk er innenfor ulp-områdene, og det er også mulig at "second-to-optimal" repr faktisk kan være optimal på grunn av avrundingsfeilen.
    // i begge tilfeller returnerer dette `None`.
    // ("weeding" fase)
    //
    // alle argumenter her skaleres av den vanlige (men implisitte) verdien `k`, slik at:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (og også `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (og også `threshold > plus1v` fra tidligere invarianter)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // produsere to tilnærminger til `v` (faktisk `plus1 - v`) innen 1.5 ulps.
        // den resulterende representasjonen bør være den nærmeste representasjonen for begge.
        //
        // her brukes `plus1 - v` siden beregninger gjøres med hensyn til `plus1` for å unngå overflow/underflow (derav tilsynelatende byttet navn).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // reduser det siste sifferet og stopp ved nærmeste representasjon til `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // vi jobber med de omtrentlige sifrene `w(n)`, som i utgangspunktet er lik `plus1 - plus1 % 10^kappa`.etter å ha kjørt løkkehuset `n` ganger, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // vi setter `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (altså `resten= plus1w(0)`) for å forenkle kontrollene.
            // merk at `plus1w(n)` alltid øker.
            //
            // vi har tre betingelser å avslutte.noen av dem vil gjøre at sløyfen ikke kan fortsette, men vi har minst en gyldig representasjon som er kjent for å være nærmest `v + 1 ulp` uansett.
            // vi vil betegne dem som TC1 til TC3 for kortfattethet.
            //
            // TC1: `w(n) <= v + 1 ulp`, dvs. dette er den siste repr som kan være den nærmeste.
            // dette tilsvarer `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // kombinert med TC2 (som sjekker om `w(n+1)` is valid) forhindrer dette mulig overløp ved beregningen av `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, dvs. neste repr rundes definitivt ikke til `v`.
            // dette tilsvarer `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // venstre side kan renne over, men vi kjenner `threshold > plus1v`, så hvis TC1 er falsk, kan `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` trygt teste om `threshold - plus1w(n) < 10^kappa` i stedet.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, dvs. neste repr er
            // ikke nærmere `v + 1 ulp` enn gjeldende repr.
            // gitt `z(n) = plus1v_up - plus1w(n)`, blir dette `abs(z(n)) <= abs(z(n+1))`.igjen forutsatt at TC1 er falsk, har vi `z(n) > 0`.vi har to saker å vurdere:
            //
            // - når `z(n+1) >= 0`: TC3 blir `z(n) <= z(n+1)`.
            // ettersom `plus1w(n)` øker, bør `z(n)` synke, og dette er helt klart falskt.
            // - når `z(n+1) < 0`:
            //   - TC3a: forutsetningen er `plus1v_up < plus1w(n) + 10^kappa`.antar at TC2 er falsk, `threshold >= plus1w(n) + 10^kappa` slik at den ikke kan renne over.
            //   - TC3b: TC3 blir `z(n) <= -z(n+1)`, dvs. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   den negerte TC1 gir `plus1v_up > plus1w(n)`, slik at den ikke kan renne over eller strømme under kombinasjon med TC3a.
            //
            // derfor bør vi stoppe når `TC1 || TC2 || (TC3a && TC3b)`.det følgende er lik det inverse, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // den korteste repr kan ikke slutte med `0`
                plus1w += ten_kappa;
            }
        }

        // sjekk om denne representasjonen også er den nærmeste representasjonen til `v - 1 ulp`.
        //
        // dette er ganske enkelt det samme som de avsluttende forholdene for `v + 1 ulp`, med alle `plus1v_up` erstattet av `plus1v_down` i stedet.
        // overløpsanalyse holder like.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // nå har vi den nærmeste representasjonen til `v` mellom `plus1` og `minus1`.
        // dette er for liberalt, skjønt, så vi avviser enhver `w(n)` ikke mellom `plus0` og `minus0`, dvs. `plus1 - plus1w(n) <= minus0` eller `plus1 - plus1w(n) >= plus0`.
        // vi bruker fakta som `threshold = plus1 - minus1` og `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Den korteste modusimplementeringen for Grisu med Dragon fallback.
///
/// Dette bør brukes i de fleste tilfeller.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SIKKERHET: Lånekontrollen er ikke smart nok til å la oss bruke `buf`
    // i den andre branch, så vi hvitvasker levetiden her.
    // Men vi bruker bare `buf` på nytt hvis `format_shortest_opt` returnerte `None`, så dette er greit.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Den nøyaktige og faste modusimplementeringen for Grisu.
///
/// Den returnerer `None` når den ellers ville gitt en unøyaktig representasjon.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // vi trenger minst tre biter med ekstra presisjon
    assert!(!buf.is_empty());

    // normalisere og skalere `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // del `v` i integrerte og brøkdeler.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // både gamle `v` og nye `v` (skalert av `10^-k`) har en feil på <1 ulp (Teorem 5.1).
    // ettersom vi ikke vet feilen er positiv eller negativ, bruker vi to tilnærminger fordelt likt og har den maksimale feilen på 2 ulps (samme til det korteste tilfellet).
    //
    //
    // målet er å finne den nøyaktig avrundede siferserien som er felles for både `v - 1 ulp` og `v + 1 ulp`, slik at vi er maksimalt sikre.
    // hvis dette ikke er mulig, vet vi ikke hvilken som er riktig utgang for `v`, så vi gir opp og faller tilbake.
    //
    // `err` er definert som `1 ulp * 2^e` her (samme som ulp i `vfrac`), og vi skalerer den når `v` blir skalert.
    //
    //
    //
    let mut err = 1;

    // beregne den største `10^max_kappa` ikke mer enn `v` (altså `v < 10^(max_kappa+1)`).
    // dette er en øvre grense på `kappa` nedenfor.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // hvis vi jobber med den siste sifferbegrensningen, må vi forkorte bufferen før gjengivelsen for å unngå dobbel avrunding.
    //
    // merk at vi må forstørre bufferen igjen når avrunding skjer!
    let len = if exp <= limit {
        // Ups, vi kan ikke engang produsere *ett* siffer.
        // Dette er mulig når vi si noe som 9.5, og det blir avrundet til 10.
        //
        // i prinsippet kan vi umiddelbart ringe `possibly_round` med en tom buffer, men skalering av `max_ten_kappa << e` med 10 kan føre til overløp.
        //
        // dermed slurver vi her og utvider feilområdet med en faktor 10.
        // dette vil øke den falske negative frekvensen, men bare veldig,*veldig* litt;
        // det kan bare ha betydning merkbart når mantissen er større enn 60 biter.
        //
        // SIKKERHET: `len=0`, så plikten til å ha initialisert dette minnet er triviell.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // gjengi integrerte deler.
    // feilen er helt brøk, så vi trenger ikke å sjekke den i denne delen.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // sifre som ennå ikke skal gjengis
    loop {
        // vi har alltid minst ett siffer for å gjengi invarianter:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (det følger at `remainder = vint % 10^(kappa+1)`)
        //
        //

        // del `remainder` med `10^kappa`.begge er skalert av `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // er bufferen full?løp avrundingskortet med resten.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SIKKERHET: vi har initialisert `len` mange byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // bryt løkken når vi har gjengitt alle integrerte sifre.
        // det nøyaktige antallet sifre er `max_kappa + 1` som `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // gjenopprette invarianter
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // gjengi brøkdeler.
    //
    // i prinsippet kan vi fortsette til det siste tilgjengelige sifferet og sjekke nøyaktigheten.
    // Dessverre jobber vi med endelige størrelser, så vi trenger noen kriterier for å oppdage overløpet.
    // V8 bruker `remainder > err`, som blir falsk når de første `i` signifikante sifrene i `v - 1 ulp` og `v` er forskjellige.
    // dette avviser imidlertid for mange ellers gyldige innspill.
    //
    // siden den senere fasen har riktig overløpsdeteksjon, bruker vi i stedet strammere kriterium:
    // vi fortsetter til `err` overstiger `10^kappa / 2`, slik at området mellom `v - 1 ulp` og `v + 1 ulp` definitivt inneholder to eller flere avrundede representasjoner.
    //
    // dette er det samme som de to første sammenligningene fra `possibly_round`, for referansen.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarianter, der `m = max_kappa + 1` (antall sifre i den integrerte delen):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // vil ikke flyte over, `2^e * 10 < 2^64`
        err *= 10; // vil ikke flyte over, `err * 10 < 2^e * 5 < 2^64`

        // del `remainder` med `10^kappa`.
        // begge er skalert av `2^e / 10^kappa`, så sistnevnte er implisitt her.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // er bufferen full?løp avrundingskortet med resten.
        if i == len {
            // SIKKERHET: vi har initialisert `len` mange byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // gjenopprette invarianter
        remainder = r;
    }

    // ytterligere beregning er ubrukelig (`possibly_round` mislykkes definitivt), så vi gir opp.
    return None;

    // Vi har generert alle etterspurte sifre på `v`, som også skal være de samme som tilsvarende sifre på `v - 1 ulp`.
    // nå sjekker vi om det er en unik representasjon som deles av både `v - 1 ulp` og `v + 1 ulp`;dette kan være det samme for genererte sifre, eller for den avrundede versjonen av disse sifrene.
    //
    // hvis området inneholder flere representasjoner av samme lengde, kan vi ikke være sikre og bør returnere `None` i stedet.
    //
    // alle argumenter her skaleres av den vanlige (men implisitte) verdien `k`, slik at:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SIKKERHET: de første `len` byte av `buf` må initialiseres.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (for referansen angir den stiplede linjen den nøyaktige verdien for mulige representasjoner i et gitt antall sifre.)
        //
        //
        // feilen er for stor til at det er minst tre mulige representasjoner mellom `v - 1 ulp` og `v + 1 ulp`.
        // vi kan ikke bestemme hvilken som er riktig.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // faktisk er 1/2 ulp nok til å introdusere to mulige representasjoner.
        // (husk at vi trenger en unik representasjon for både `v - 1 ulp` og `v + 1 ulp`.) Dette vil ikke flyte over, som `ulp < ten_kappa` fra første sjekk.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // Hvis `v + 1 ulp` er nærmere den avrundede representasjonen (som allerede er i `buf`), kan vi trygt komme tilbake.
        // merk at `v - 1 ulp`*kan* være mindre enn gjeldende representasjon, men som `1 ulp < 10^kappa / 2` er denne tilstanden nok:
        // avstanden mellom `v - 1 ulp` og gjeldende representasjon kan ikke overstige `10^kappa / 2`.
        //
        // tilstanden tilsvarer `remainder + ulp < 10^kappa / 2`.
        // siden dette lett kan gå over, sjekk først om `remainder < 10^kappa / 2`.
        // Vi har allerede bekreftet at `ulp < 10^kappa / 2`, så lenge `10^kappa` ikke overløp, er den andre sjekken greit.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SIKKERHET: innringeren vår initialiserte minnet.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------resten------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // på den annen side, hvis `v - 1 ulp` er nærmere den avrundede representasjonen, bør vi avrunde og returnere.
        // av samme grunn trenger vi ikke å sjekke `v + 1 ulp`.
        //
        // tilstanden tilsvarer `remainder - ulp >= 10^kappa / 2`.
        // igjen sjekker vi først om `remainder > ulp` (merk at dette ikke er `remainder >= ulp`, da `10^kappa` aldri er null).
        //
        // Vær også oppmerksom på at `remainder - ulp <= 10^kappa`, så den andre sjekken ikke flyter over.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SIKKERHET: innringeren vår må ha initialisert minnet.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // bare legg til et ekstra siffer når vi har blitt bedt om fast presisjon.
                // Vi må også sjekke at hvis den opprinnelige bufferen var tom, kan det ekstra sifferet bare legges til når `exp == limit` (tilfelle edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SIKKERHET: vi og innringeren initialiserte minnet.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // ellers er vi dømt (dvs. at noen verdier mellom `v - 1 ulp` og `v + 1 ulp` avrunder og andre avrunder) og gir opp.
        //
        None
    }
}

/// Den nøyaktige og faste modusimplementeringen for Grisu med Dragon fallback.
///
/// Dette bør brukes i de fleste tilfeller.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SIKKERHET: Lånekontrollen er ikke smart nok til å la oss bruke `buf`
    // i den andre branch, så vi hvitvasker levetiden her.
    // Men vi bruker bare `buf` på nytt hvis `format_exact_opt` returnerte `None`, så dette er greit.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}