//! Dekoder en flytende verdi i individuelle deler og feilområder.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekodet usignert endelig verdi, slik at:
///
/// - Den opprinnelige verdien tilsvarer `mant * 2^exp`.
///
/// - Ethvert tall fra `(mant - minus)*2^exp` til `(mant + plus)* 2^exp` vil rundes til den opprinnelige verdien.
/// Rekkevidden inkluderer bare når `inclusive` er `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Den skalerte mantissen.
    pub mant: u64,
    /// Det nedre feilområdet.
    pub minus: u64,
    /// Det øvre feilområdet.
    pub plus: u64,
    /// Den delte eksponenten i base 2.
    pub exp: i16,
    /// Sann når feilområdet er inkludert.
    ///
    /// I IEEE 754 er dette sant når den opprinnelige mantissen var jevn.
    pub inclusive: bool,
}

/// Dekodet usignert verdi.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Uendeligheter, enten positive eller negative.
    Infinite,
    /// Null, enten positiv eller negativ.
    Zero,
    /// Endelige tall med ytterligere dekodede felt.
    Finite(Decoded),
}

/// En flytpunktstype som kan `dekodes`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimum positiv normalisert verdi.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Returnerer et tegn (sant når det er negativt) og `FullDecoded`-verdien fra gitt flytende nummer.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // naboer: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode bevarer alltid eksponenten, så mantissaen er skalert for undernormale.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // naboer: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // der maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // naboer: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}