//! Feiltyper for konvertering til integrerte typer.

use crate::convert::Infallible;
use crate::fmt;

/// Feiltypen returneres når en avkrysset integrert konverteringstype mislykkes.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Match i stedet for å tvinge for å sikre at koden som `From<Infallible> for TryFromIntError` ovenfor vil fortsette å fungere når `Infallible` blir et alias til `!`.
        //
        //
        match never {}
    }
}

/// En feil som kan returneres når du analyserer et heltall.
///
/// Denne feilen brukes som feiltype for `from_str_radix()`-funksjonene på de primitive heltallstypene, for eksempel [`i8::from_str_radix`].
///
/// # Potensielle årsaker
///
/// Blant andre årsaker kan `ParseIntError` kastes på grunn av ledende eller etterfølgende mellomrom i strengen, f.eks. Når den er hentet fra standardinngangen.
///
/// Bruk av [`str::trim()`]-metoden sikrer at det ikke blir noe hvitt mellomrom før analysering.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum for å lagre de forskjellige typene feil som kan føre til at analyse av et helt tall mislykkes.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Verdien som blir analysert er tom.
    ///
    /// Blant andre årsaker vil denne varianten bli konstruert når du analyserer en tom streng.
    Empty,
    /// Inneholder et ugyldig siffer i sin sammenheng.
    ///
    /// Blant andre årsaker vil denne varianten bli konstruert når man analyserer en streng som inneholder en ikke-ASCII-tegn.
    ///
    /// Denne varianten er også konstruert når en `+` eller `-` er feilplassert i en streng enten alene eller i midten av et tall.
    ///
    ///
    InvalidDigit,
    /// Heltall er for stort til å lagres i heltalstypen.
    PosOverflow,
    /// Heltall er for lite til å lagres i mål heltallstype.
    NegOverflow,
    /// Verdien var null
    ///
    /// Denne varianten sendes ut når parsingstrengen har en verdi på null, noe som vil være ulovlig for typer som ikke er null.
    ///
    Zero,
}

impl ParseIntError {
    /// Skriver ut den detaljerte årsaken til at et heltall mislykkes.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}