macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Den minste verdien som kan representeres av denne heltallstypen.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Den største verdien som kan representeres av denne heltallstypen.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Størrelsen på denne heltallstypen i bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konverterer en strengskive i en gitt base til et helt tall.
        ///
        /// Strengen forventes å være et valgfritt `+`-tegn etterfulgt av sifre.
        ///
        /// Ledende og etterfølgende mellomrom representerer en feil.
        /// Sifre er en delmengde av disse tegnene, avhengig av `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Denne funksjonen panics hvis `radix` ikke er i området 2 til 36.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Returnerer antallet av dem i den binære representasjonen av `self`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Returnerer antall nuller i den binære representasjonen av `self`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Returnerer antall ledende nuller i den binære representasjonen av `self`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Returnerer antall etterfølgende nuller i den binære representasjonen av `self`.
        ///
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Returnerer antall ledende i binær representasjon av `self`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Returnerer antall etterfølgende i binær representasjon av `self`.
        ///
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Skifter bitene til venstre med et spesifisert beløp, `n`, innpakning av de avkortede bitene til slutten av det resulterende heltallet.
        ///
        ///
        /// Vær oppmerksom på at dette ikke er den samme operasjonen som `<<` skiftoperatør!
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Skifter bitene til høyre med et spesifisert beløp, `n`, innpakning av de avkortede bitene til begynnelsen av det resulterende heltallet.
        ///
        ///
        /// Vær oppmerksom på at dette ikke er den samme operasjonen som `>>` skiftoperatør!
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Vender byterekkefølgen til heltallet.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// la m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Vender rekkefølgen på bitene i heltallet.
        /// Den minst signifikante biten blir den mest betydningsfulle biten, den nest minst signifikante biten blir den nest mest betydningsfulle biten, etc.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// la m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Konverterer et heltall fra stor endian til målets slutt.
        ///
        /// På stor endian er dette en no-op.
        /// På liten endian byttes bytene.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } annet {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterer et heltall fra lite endian til målets slutt.
        ///
        /// På liten endian er dette en no-op.
        /// På store endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } annet {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterer `self` til stor endian fra målets slutt.
        ///
        /// På stor endian er dette en no-op.
        /// På liten endian byttes bytene.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ellers { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // eller ikke være?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Konverterer `self` til liten endian fra målets slutt.
        ///
        /// På liten endian er dette en no-op.
        /// På store endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ellers { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Sjekket heltallstilsetning.
        /// Beregner `self + rhs`, returnerer `None` hvis overløp oppstod.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ukontrollert heltallstilsetning.Beregner `self + rhs`, forutsatt at overløp ikke kan forekomme.
        /// Dette resulterer i udefinert oppførsel når
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Sjekket heltallstrekk.
        /// Beregner `self - rhs`, returnerer `None` hvis overløp oppstod.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ukontrollert heltall subtraksjon.Beregner `self - rhs`, forutsatt at overløp ikke kan forekomme.
        /// Dette resulterer i udefinert oppførsel når
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Sjekket heltallsmultiplikasjon.
        /// Beregner `self * rhs`, returnerer `None` hvis overløp oppstod.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Umarkert multiplikasjon av heltall.Beregner `self * rhs`, forutsatt at overløp ikke kan forekomme.
        /// Dette resulterer i udefinert oppførsel når
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Sjekket heltallsdeling.
        /// Beregner `self / rhs`, returnerer `None` hvis `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SIKKERHET: div ved null er sjekket ovenfor, og usignerte typer har ingen andre
                // feilmodus for deling
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Sjekket euklidisk divisjon.
        /// Beregner `self.div_euclid(rhs)`, returnerer `None` hvis `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Sjekket heltalls resten.
        /// Beregner `self % rhs`, returnerer `None` hvis `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SIKKERHET: div ved null er sjekket ovenfor, og usignerte typer har ingen andre
                // feilmodus for deling
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Sjekket euklidisk modulo.
        /// Beregner `self.rem_euclid(rhs)`, returnerer `None` hvis `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Sjekket negasjon.Beregner `-self`, returnerer `None` med mindre `self==
        /// 0`.
        ///
        /// Merk at å negere et positivt heltall vil flyte over.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Sjekket skift til venstre.
        /// Beregner `self << rhs`, returnerer `None` hvis `rhs` er større enn eller lik antall bits i `self`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Sjekket skift til høyre.
        /// Beregner `self >> rhs`, returnerer `None` hvis `rhs` er større enn eller lik antall bits i `self`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Sjekket eksponentiering.
        /// Beregner `self.pow(exp)`, returnerer `None` hvis overløp oppstod.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // siden exp!=0, til slutt må exp være 1.
            // Håndter den siste biten av eksponenten hver for seg, siden kvadrering av basen etterpå ikke er nødvendig og kan føre til unødvendig overløp.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Mettende heltalstilsetning.
        /// Beregner `self + rhs`, metter ved de numeriske grensene i stedet for å flyte over.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Metning heltall subtraksjon.
        /// Beregner `self - rhs`, metter ved de numeriske grensene i stedet for å flyte over.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Mettende heltalsmultiplikasjon.
        /// Beregner `self * rhs`, metter ved de numeriske grensene i stedet for å flyte over.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Metning av heltall eksponentiering.
        /// Beregner `self.pow(exp)`, metter ved de numeriske grensene i stedet for å flyte over.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Innpakning av (modular)-tillegg.
        /// Beregner `self + rhs`, vikler rundt på grensen for typen.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Innpakning av (modular)-subtraksjon.
        /// Beregner `self - rhs`, vikler rundt på grensen for typen.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Innpakning av (modular)-multiplikasjon.
        /// Beregner `self * rhs`, vikler rundt på grensen for typen.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// Vær oppmerksom på at dette eksemplet deles mellom heltalstyper.
        /// Noe som forklarer hvorfor `u8` brukes her.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Innpakning (modular) divisjon.Beregner `self / rhs`.
        /// Innpakket inndeling på usignerte typer er bare normal inndeling.
        /// Det er ingen måte innpakning noensinne kan skje.
        /// Denne funksjonen eksisterer, slik at alle operasjoner blir regnskapsført i innpakningsoperasjonene.
        ///
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Innpakning av den euklidiske divisjonen.Beregner `self.div_euclid(rhs)`.
        /// Innpakket inndeling på usignerte typer er bare normal inndeling.
        /// Det er ingen måte innpakning noensinne kan skje.
        /// Denne funksjonen eksisterer, slik at alle operasjoner blir regnskapsført i innpakningsoperasjonene.
        /// Siden, for de positive heltallene, alle vanlige definisjoner av divisjon er like, er dette nøyaktig lik `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Innpakning (modular) resten.Beregner `self % rhs`.
        /// Innpakket restberegning på usignerte typer er bare den vanlige restberegningen.
        ///
        /// Det er ingen måte innpakning noensinne kan skje.
        /// Denne funksjonen eksisterer, slik at alle operasjoner blir regnskapsført i innpakningsoperasjonene.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Innpakning av euklidisk modulo.Beregner `self.rem_euclid(rhs)`.
        /// Innpakket modulo-beregning på usignerte typer er bare den vanlige gjenværende beregningen.
        /// Det er ingen måte innpakning noensinne kan skje.
        /// Denne funksjonen eksisterer, slik at alle operasjoner blir regnskapsført i innpakningsoperasjonene.
        /// Siden, for de positive heltallene, alle vanlige definisjoner av divisjon er like, er dette nøyaktig lik `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Innpakning av (modular)-negasjon.
        /// Beregner `-self`, vikler rundt på grensen for typen.
        ///
        /// Siden usignerte typer ikke har negative ekvivalenter, vil alle applikasjoner av denne funksjonen brytes (bortsett fra `-0`).
        /// For verdier som er mindre enn den korresponderende signerte typen, er resultatet det samme som å kaste den tilsvarende signerte verdien.
        ///
        /// Eventuelle større verdier tilsvarer `MAX + 1 - (val - MAX - 1)` hvor `MAX` er den maksimale signerte typen.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// Vær oppmerksom på at dette eksemplet deles mellom heltalstyper.
        /// Noe som forklarer hvorfor `i8` brukes her.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-fri bitvis skift-venstre;
        /// gir `self << mask(rhs)`, der `mask` fjerner alle høykvalitets biter av `rhs` som vil føre til at skiftet overskrider bitbredden til typen.
        ///
        /// Merk at dette er *ikke* det samme som en roter til venstre;RHS for en innpakning skift-venstre er begrenset til rekkevidden av typen, i stedet for at bitene som er forskjøvet ut av LHS blir returnert til den andre enden.
        /// De primitive heltallstypene implementerer alle en [`rotate_left`](Self::rotate_left)-funksjon, som kan være det du vil ha i stedet.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SIKKERHET: maskeringen av bitstørrelsen av typen sørger for at vi ikke skifter
            // utenfor grensene
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-fri bitvis skift-høyre;
        /// gir `self >> mask(rhs)`, der `mask` fjerner alle høykvalitets biter av `rhs` som vil føre til at skiftet overskrider bitbredden til typen.
        ///
        /// Merk at dette er *ikke* det samme som en roter-høyre;RHS for en innpakning skift-høyre er begrenset til rekkevidden av typen, i stedet for at bitene som er forskjøvet ut av LHS blir returnert til den andre enden.
        /// De primitive heltallstypene implementerer alle en [`rotate_right`](Self::rotate_right)-funksjon, som kan være det du vil ha i stedet.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SIKKERHET: maskeringen av bitstørrelsen av typen sørger for at vi ikke skifter
            // utenfor grensene
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Innpakning av (modular)-eksponentiering.
        /// Beregner `self.pow(exp)`, vikler rundt på grensen for typen.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // siden exp!=0, til slutt må exp være 1.
            // Håndter den siste biten av eksponenten hver for seg, siden kvadrering av basen etterpå ikke er nødvendig og kan føre til unødvendig overløp.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Beregner `self` + `rhs`
        ///
        /// Returnerer en tuple av tilsetningen sammen med en boolsk som indikerer om det vil oppstå et aritmetisk overløp.
        /// Hvis et overløp ville ha oppstått, returneres den innpakkede verdien.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beregner `self`, `rhs`
        ///
        /// Returnerer en tuple av subtraksjonen sammen med en boolsk som indikerer om det vil oppstå et aritmetisk overløp.
        /// Hvis et overløp ville ha oppstått, returneres den innpakkede verdien.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beregner multiplikasjonen av `self` og `rhs`.
        ///
        /// Returnerer en tuple av multiplikasjonen sammen med en boolsk som indikerer om det vil oppstå et aritmetisk overløp.
        /// Hvis et overløp ville ha oppstått, returneres den innpakkede verdien.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// Vær oppmerksom på at dette eksemplet deles mellom heltalstyper.
        /// Noe som forklarer hvorfor `u32` brukes her.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beregner deleren når `self` er delt med `rhs`.
        ///
        /// Returnerer en tupel av deleren sammen med en boolsk som indikerer om det vil oppstå et aritmetisk overløp.
        /// Merk at for usignerte heltall forekommer overløp aldri, så den andre verdien er alltid `false`.
        ///
        /// # Panics
        ///
        /// Denne funksjonen vil panic hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Beregner kvotienten til den euklidiske divisjonen `self.div_euclid(rhs)`.
        ///
        /// Returnerer en tupel av deleren sammen med en boolsk som indikerer om det vil oppstå et aritmetisk overløp.
        /// Merk at for usignerte heltall forekommer overløp aldri, så den andre verdien er alltid `false`.
        /// Siden, for de positive heltallene, alle vanlige definisjoner av divisjon er like, er dette nøyaktig lik `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Denne funksjonen vil panic hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Beregner resten når `self` er delt på `rhs`.
        ///
        /// Returnerer en tuple av resten etter deling sammen med en boolsk som indikerer om det vil oppstå et aritmetisk overløp.
        /// Merk at for usignerte heltall forekommer overløp aldri, så den andre verdien er alltid `false`.
        ///
        /// # Panics
        ///
        /// Denne funksjonen vil panic hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Beregner resten `self.rem_euclid(rhs)` som ved euklidisk divisjon.
        ///
        /// Returnerer en tuppel av modulo etter deling sammen med en boolsk som indikerer om et aritmetisk overløp ville oppstå.
        /// Merk at for usignerte heltall forekommer overløp aldri, så den andre verdien er alltid `false`.
        /// Siden, for de positive heltallene, alle vanlige definisjoner av divisjon er like, er denne operasjonen nøyaktig lik `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Denne funksjonen vil panic hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negerer selv på en overfylt måte.
        ///
        /// Returnerer `!self + 1` ved hjelp av innpakningsoperasjoner for å returnere verdien som representerer negasjonen av denne usignerte verdien.
        /// Vær oppmerksom på at for positive usignerte verdier alltid forekommer overløp, men å negere 0 overløper ikke.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Skifter selv igjen av `rhs` biter.
        ///
        /// Returnerer en tuple av den skiftede versjonen av selv sammen med en boolsk som indikerer om skiftverdien var større enn eller lik antall bits.
        /// Hvis skiftverdien er for stor, maskeres verdien (N-1) der N er antall bits, og denne verdien brukes deretter til å utføre skiftet.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Skifter selvrett med `rhs` biter.
        ///
        /// Returnerer en tuple av den skiftede versjonen av selv sammen med en boolsk som indikerer om skiftverdien var større enn eller lik antall bits.
        /// Hvis skiftverdien er for stor, maskeres verdien (N-1) der N er antall bits, og denne verdien brukes deretter til å utføre skiftet.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Løfter selv kraften til `exp`, ved hjelp av eksponentiering ved å firkant.
        ///
        /// Returnerer en tuppel av eksponentieringen sammen med en bool som indikerer om et overløp skjedde.
        ///
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, sant));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Riperom for lagring av resultater av overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // siden exp!=0, til slutt må exp være 1.
            // Håndter den siste biten av eksponenten hver for seg, siden kvadrering av basen etterpå ikke er nødvendig og kan føre til unødvendig overløp.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Løfter selv kraften til `exp`, ved hjelp av eksponentiering ved å firkant.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // siden exp!=0, til slutt må exp være 1.
            // Håndter den siste biten av eksponenten hver for seg, siden kvadrering av basen etterpå ikke er nødvendig og kan føre til unødvendig overløp.
            //
            //
            acc * base
        }

        /// Utfører euklidisk divisjon.
        ///
        /// Siden, for de positive heltallene, alle vanlige definisjoner av divisjon er like, er dette nøyaktig lik `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Denne funksjonen vil panic hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Beregner den minste resten av `self (mod rhs)`.
        ///
        /// Siden, for de positive heltallene, alle vanlige definisjoner av divisjon er like, er dette nøyaktig lik `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Denne funksjonen vil panic hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Returnerer `true` hvis og bare hvis `self == 2^k` for noen `k`.
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Returnerer en mindre enn neste effekt på to.
        // (For 8u8 er neste kraft på to 8u8 og for 6u8 er det 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Denne metoden kan ikke overløpe, ettersom det i `next_power_of_two`-tilfeller ender med å returnere den maksimale verdien av typen, og kan returnere 0 for 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SIKKERHET: Fordi `p > 0`, kan den ikke bestå helt av ledende nuller.
            // Det betyr at skiftet alltid er innenfor grensene, og noen prosessorer (for eksempel intel pre-haswell) har mer effektiv ctlz-egenutvikling når argumentet ikke er null.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Returnerer den minste effekten på to større enn eller lik `self`.
        ///
        /// Når returverdien renner over (dvs. `self > (1 << (N-1))` for type `uN`), panics i feilsøkingsmodus og returverdien blir pakket inn til 0 i frigjøringsmodus (den eneste situasjonen der metoden kan returnere 0).
        ///
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Returnerer den minste effekten på to større enn eller lik `n`.
        /// Hvis neste effekt på to er større enn typens maksimale verdi, returneres `None`, ellers er effekten på to pakket inn i `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Returnerer den minste effekten på to større enn eller lik `n`.
        /// Hvis neste effekt på to er større enn typens maksimale verdi, blir returverdien pakket inn til `0`.
        ///
        ///
        /// # Examples
        ///
        /// Grunnleggende bruk:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Returner minnepresentasjonen av dette heltallet som et byte-array i stor endian (network) byte-rekkefølge.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Returner minnerepresentasjonen av dette heltallet som en byte-array i liten endian byte-rekkefølge.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Returner minnerepresentasjonen til dette heltallet som et byte-array i naturlig byte-rekkefølge.
        ///
        /// Ettersom målplattformens innfødte endethet brukes, bør bærbar kode bruke [`to_be_bytes`] eller [`to_le_bytes`], etter behov, i stedet.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     byte, hvis cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } annet {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIKKERHET: const-lyd fordi heltall er vanlige gamle datatyper, slik at vi alltid kan
        // overfør dem til byteserier
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SIKKERHET: Heltall er vanlige gamle datatyper, slik at vi alltid kan overføre dem til
            // matriser med byte
            unsafe { mem::transmute(self) }
        }

        /// Returner minnerepresentasjonen til dette heltallet som et byte-array i naturlig byte-rekkefølge.
        ///
        ///
        /// [`to_ne_bytes`] bør foretrekkes fremfor dette når det er mulig.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// la byte= num.as_ne_bytes();
        /// assert_eq!(
        ///     byte, hvis cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } annet {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SIKKERHET: Heltall er vanlige gamle datatyper, slik at vi alltid kan overføre dem til
            // matriser med byte
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Lag en innfødt endian-heltallverdi fra dens representasjon som en byte-array i big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// bruk std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * inngang=hvile;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Lag en innfødt endian-heltallverdi fra dens representasjon som en byte-array i liten endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// bruk std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * inngang=hvile;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Opprett en innfødt endian-heltallverdi fra hukommelsesrepresentasjonen som en byte-array i native endianness.
        ///
        /// Ettersom målplattformens innfødte endelighet brukes, vil bærbar kode sannsynligvis bruke [`from_be_bytes`] eller [`from_le_bytes`], som det er aktuelt i stedet.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } annet {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// bruk std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * inngang=hvile;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIKKERHET: const-lyd fordi heltall er vanlige gamle datatyper, slik at vi alltid kan
        // overføre til dem
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SIKKERHET: heltall er vanlige gamle datatyper, slik at vi alltid kan overføre til dem
            unsafe { mem::transmute(bytes) }
        }

        /// Ny kode bør foretrekke å bruke
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Returnerer den minste verdien som kan representeres av denne heltallstypen.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Ny kode bør foretrekke å bruke
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Returnerer den største verdien som kan representeres av denne heltallstypen.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}