//! Konstanter som er spesifikke for `f32` flytpunkttype med en enkelt presisjon.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Matematiske signifikante tall er gitt i `consts`-undermodulen.
//!
//! For konstanter som er definert direkte i denne modulen (forskjellig fra de som er definert i `consts`-undermodulen), bør ny kode i stedet bruke de tilknyttede konstantene som er definert direkte på `f32`-typen.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radiksen eller basen til den interne representasjonen av `f32`.
/// Bruk [`f32::RADIX`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // tiltenkt måte
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Antall signifikante sifre i base 2.
/// Bruk [`f32::MANTISSA_DIGITS`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // tiltenkt måte
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Omtrentlig antall signifikante sifre i base 10.
/// Bruk [`f32::DIGITS`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // tiltenkt måte
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] verdi for `f32`.
/// Bruk [`f32::EPSILON`] i stedet.
///
/// Dette er forskjellen mellom `1.0` og det neste større representable tallet.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // tiltenkt måte
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Minste endelige `f32`-verdi.
/// Bruk [`f32::MIN`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // tiltenkt måte
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Minste positive normale `f32`-verdi.
/// Bruk [`f32::MIN_POSITIVE`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // tiltenkt måte
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Største endelige `f32`-verdi.
/// Bruk [`f32::MAX`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // tiltenkt måte
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// En større enn minimum mulig normal effekt på 2 eksponenter.
/// Bruk [`f32::MIN_EXP`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // tiltenkt måte
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Maksimal mulig effekt på 2 eksponenter.
/// Bruk [`f32::MAX_EXP`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // tiltenkt måte
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Minimum mulig normaleffekt på 10 eksponenter.
/// Bruk [`f32::MIN_10_EXP`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // tiltenkt måte
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Maksimal mulig effekt på 10 eksponenter.
/// Bruk [`f32::MAX_10_EXP`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // tiltenkt måte
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ikke et nummer (NaN).
/// Bruk [`f32::NAN`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // tiltenkt måte
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Bruk [`f32::INFINITY`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // tiltenkt måte
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Negativ uendelig (−∞).
/// Bruk [`f32::NEG_INFINITY`] i stedet.
///
/// # Examples
///
/// ```rust
/// // utdatert måte
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // tiltenkt måte
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Grunnleggende matematiske konstanter.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: erstatt med matematiske konstanter fra cmath.

    /// Archimedes 'konstante (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Hele sirkelen konstant (τ)
    ///
    /// Tilsvarende 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Eulers nummer (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Radiksen eller basen til den interne representasjonen av `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Antall signifikante sifre i base 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Omtrentlig antall signifikante sifre i base 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] verdi for `f32`.
    ///
    /// Dette er forskjellen mellom `1.0` og det neste større representable tallet.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Minste endelige `f32`-verdi.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Minste positive normale `f32`-verdi.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Største endelige `f32`-verdi.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// En større enn minimum mulig normal effekt på 2 eksponenter.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Maksimal mulig effekt på 2 eksponenter.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Minimum mulig normaleffekt på 10 eksponenter.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Maksimal mulig effekt på 10 eksponenter.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ikke et nummer (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Negativ uendelig (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Returnerer `true` hvis denne verdien er `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` er offentlig utilgjengelig i libcore på grunn av bekymringer for bærbarhet, så denne implementeringen er til privat bruk internt.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Returnerer `true` hvis denne verdien er positiv uendelig eller negativ uendelig, og ellers `false`.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Returnerer `true` hvis dette tallet verken er uendelig eller `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Det er ikke nødvendig å håndtere NaN separat: hvis selv er NaN, er sammenligningen ikke sant, akkurat som ønsket.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Returnerer `true` hvis tallet er [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Verdiene mellom `0` og `min` er undernormale.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Returnerer `true` hvis tallet verken er null, uendelig, [subnormal] eller `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Verdiene mellom `0` og `min` er undernormale.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Returnerer kategorien med flytende punkt.
    /// Hvis bare en egenskap skal testes, er det generelt raskere å bruke det spesifikke predikatet i stedet.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Returnerer `true` hvis `self` har et positivt tegn, inkludert `+0.0`, `NaN`s med positivt tegnbit og positiv uendelig.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Returnerer `true` hvis `self` har et negativt tegn, inkludert `-0.0`, `NaN`s med negativ tegnbit og negativ uendelig.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 sier: isSignMinus(x) er sant hvis og bare hvis x har negativt tegn.
        // isSignMinus gjelder også for nuller og NaN.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Tar den gjensidige (inverse) av et nummer, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Konverterer radianer til grader.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Bruk en konstant for bedre presisjon.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Konverterer grader til radianer.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Returnerer maksimalt av de to tallene.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Hvis ett av argumentene er NaN, returneres det andre argumentet.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Returnerer minimum av de to tallene.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Hvis ett av argumentene er NaN, returneres det andre argumentet.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Runder mot null og konverterer til en hvilken som helst primitiv heltallstype, forutsatt at verdien er endelig og passer inn i den typen.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Verdien må:
    ///
    /// * Ikke vær `NaN`
    /// * Ikke vær uendelig
    /// * Vær representativ i returtypen `Int` etter å ha avkortet den brøkdel
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SIKKERHET: innringeren må opprettholde sikkerhetskontrakten for `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Rå transmutasjon til `u32`.
    ///
    /// Dette er for tiden identisk med `transmute::<f32, u32>(self)` på alle plattformer.
    ///
    /// Se `from_bits` for noen diskusjoner om portabiliteten til denne operasjonen (det er nesten ingen problemer).
    ///
    /// Merk at denne funksjonen er forskjellig fra `as`-casting, som prøver å bevare *numerisk* verdi, og ikke bitvis verdi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() er ikke casting!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SIKKERHET: `u32` er en vanlig gammel datatype, slik at vi alltid kan overføre til den
        unsafe { mem::transmute(self) }
    }

    /// Rå transmutasjon fra `u32`.
    ///
    /// Dette er for tiden identisk med `transmute::<u32, f32>(v)` på alle plattformer.
    /// Det viser seg at dette er utrolig bærbart, av to grunner:
    ///
    /// * Floats and Ints har samme endianness på alle støttede plattformer.
    /// * IEEE-754 spesifiserer veldig nøyaktig bitoppsettet til flottører.
    ///
    /// Imidlertid er det en advarsel: før 2008-versjonen av IEEE-754 ble det ikke spesifisert hvordan tolke NaN-signalbiten.
    /// De fleste plattformer (spesielt x86 og ARM) valgte tolkningen som til slutt ble standardisert i 2008, men noen gjorde ikke (spesielt MIPS).
    /// Som et resultat er alle signalerende NaN-er på MIPS stille NaN-er på x86, og omvendt.
    ///
    /// I stedet for å prøve å bevare signalplasseringsgrensesnittet, favoriserer denne implementeringen å bevare de eksakte bitene.
    /// Dette betyr at eventuelle nyttelaster som er kodet i NaNs, blir bevart selv om resultatet av denne metoden blir sendt over nettverket fra en x86-maskin til en MIPS-maskin.
    ///
    ///
    /// Hvis resultatene av denne metoden bare blir manipulert av den samme arkitekturen som produserte dem, er det ingen bekymring for bærbarhet.
    ///
    /// Hvis inngangen ikke er NaN, er det ingen bekymring for bærbarhet.
    ///
    /// Hvis du ikke bryr deg om signalering (veldig sannsynlig), er det ingen bekymring for bærbarhet.
    ///
    /// Merk at denne funksjonen er forskjellig fra `as`-casting, som prøver å bevare *numerisk* verdi, og ikke bitvis verdi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SIKKERHET: `u32` er en vanlig gammel datatype, slik at vi alltid kan overføre fra den
        // Det viser seg at sikkerhetsproblemene med sNaN ble overblåst!Hurra!
        unsafe { mem::transmute(v) }
    }

    /// Returner minnepresentasjonen av dette flytende punktet som en byte-array i stor endian (network) byte-rekkefølge.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Returner minnerepresentasjonen av dette flytende punktet som en byte-array i liten endian byte-rekkefølge.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Returner hukommelsesrepresentasjonen av dette flytende punktet som en byte-array i naturlig byte-rekkefølge.
    ///
    /// Ettersom målplattformens innfødte endethet brukes, bør bærbar kode bruke [`to_be_bytes`] eller [`to_le_bytes`], etter behov, i stedet.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Returner hukommelsesrepresentasjonen av dette flytende punktet som en byte-array i naturlig byte-rekkefølge.
    ///
    ///
    /// [`to_ne_bytes`] bør foretrekkes fremfor dette når det er mulig.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SIKKERHET: `f32` er en vanlig gammel datatype, slik at vi alltid kan overføre til den
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Lag en flytende verdi fra representasjonen som en byte-array i stor endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Lag en flytende verdi fra representasjonen som en byte-array i liten endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Lag en flytende verdi fra dens representasjon som en byte-array i native endian.
    ///
    /// Ettersom målplattformens innfødte endelighet brukes, vil bærbar kode sannsynligvis bruke [`from_be_bytes`] eller [`from_le_bytes`], som det er aktuelt i stedet.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Returnerer en ordre mellom selvtillit og andre verdier.
    /// I motsetning til standard delvis sammenligning mellom flytende nummer, gir denne sammenligningen alltid en ordre i samsvar med totalbestillingspredikatet som definert i IEEE 754 (2008 revisjon) flytende punktstandard.
    /// Verdiene er ordnet i følgende rekkefølge:
    /// - Negativ stille NaN
    /// - Negativ signalering av NaN
    /// - Negativ uendelig
    /// - Negative tall
    /// - Negative subnormale tall
    /// - Negativ null
    /// - Positivt null
    /// - Positive subnormale tall
    /// - Positive tall
    /// - Positiv uendelig
    /// - Positiv signalering NaN
    /// - Positiv stille NaN
    ///
    /// Merk at denne funksjonen ikke alltid stemmer overens med [`PartialOrd`]-og [`PartialEq`]-implementeringene av `f32`.Spesielt anser de negativt og positivt null som like, mens `total_cmp` ikke gjør det.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // I tilfelle negativer, snu alle biter bortsett fra tegnet for å oppnå en lignende layout som to komplement heltall
        //
        // Hvorfor fungerer dette?IEEE 754 flottører består av tre felt:
        // Sign bit, eksponent og mantissa.Settet eksponent-og mantissafelt som helhet har den egenskapen at deres bitvise rekkefølge er lik den numeriske størrelsen der størrelsen er definert.
        // Størrelsen er normalt ikke definert på NaN-verdier, men IEEE 754 total Order definerer NaN-verdiene også for å følge bitvis rekkefølge.Dette fører til orden forklart i dok. Kommentaren.
        // Representasjonen av størrelsen er imidlertid den samme for negative og positive tall-bare tegnbiten er forskjellig.
        // For å enkelt sammenligne flottørene som signerte heltall, må vi snu eksponent-og mantissabitene i tilfelle negative tall.
        // Vi konverterer tallene effektivt til "two's complement"-skjema.
        //
        // For å snu, konstruerer vi en maske og XOR mot den.
        // Vi beregner grenfritt en "all-ones except for the sign bit"-maske fra negativt signerte verdier: høyre skiftende tegn utvider heltallet, så vi "fill" masken med tegnbiter, og konverterer deretter til usignert for å skyve en nullbit til.
        //
        // På positive verdier er masken alle nuller, så det er en no-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Begrens en verdi til et bestemt intervall med mindre det er NaN.
    ///
    /// Returnerer `max` hvis `self` er større enn `max`, og `min` hvis `self` er mindre enn `min`.
    /// Ellers returnerer dette `self`.
    ///
    /// Merk at denne funksjonen returnerer NaN hvis den opprinnelige verdien også var NaN.
    ///
    /// # Panics
    ///
    /// Panics hvis `min > max`, `min` er NaN, eller `max` er NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}