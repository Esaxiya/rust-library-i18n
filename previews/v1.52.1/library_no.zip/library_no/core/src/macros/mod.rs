#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Utvides til enten `$crate::panic::panic_2015` eller `$crate::panic::panic_2021`, avhengig av utgaven av innringeren.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Påstår at to uttrykk er like hverandre (ved bruk av [`PartialEq`]).
///
/// På panic vil denne makroen skrive ut verdiene til uttrykkene med feilsøkingsrepresentasjonene.
///
///
/// I likhet med [`assert!`] har denne makroen en annen form, der en tilpasset panic-melding kan leveres.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Gjentakelsene nedenfor er forsettlige.
                    // Uten dem initialiseres stakksporet for lånet allerede før verdiene sammenlignes, noe som fører til en merkbar bremsing.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Gjentakelsene nedenfor er forsettlige.
                    // Uten dem initialiseres stakksporet for lånet allerede før verdiene sammenlignes, noe som fører til en merkbar bremsing.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Påstår at to uttrykk ikke er like hverandre (ved bruk av [`PartialEq`]).
///
/// På panic vil denne makroen skrive ut verdiene til uttrykkene med feilsøkingsrepresentasjonene.
///
///
/// I likhet med [`assert!`] har denne makroen en annen form, der en tilpasset panic-melding kan leveres.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Gjentakelsene nedenfor er forsettlige.
                    // Uten dem initialiseres stakksporet for lånet allerede før verdiene sammenlignes, noe som fører til en merkbar bremsing.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Gjentakelsene nedenfor er forsettlige.
                    // Uten dem initialiseres stakksporet for lånet allerede før verdiene sammenlignes, noe som fører til en merkbar bremsing.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Påstår at et boolsk uttrykk er `true` ved kjøretid.
///
/// Dette vil påkalle [`panic!`]-makroen hvis det angitte uttrykket ikke kan evalueres til `true` ved kjøretid.
///
/// I likhet med [`assert!`] har denne makroen også en andre versjon, der en tilpasset panic-melding kan leveres.
///
/// # Uses
///
/// I motsetning til [`assert!`] er `debug_assert!`-setninger bare aktivert i ikke-optimaliserte bygg som standard.
/// En optimalisert build vil ikke utføre `debug_assert!`-setninger med mindre `-C debug-assertions` sendes til kompilatoren.
/// Dette gjør `debug_assert!` nyttig for sjekker som er for dyre til å være til stede i en utgivelsesutgave, men kan være nyttig under utviklingen.
/// Resultatet av å utvide `debug_assert!` blir alltid typekontrollert.
///
/// En ukontrollert påstand lar et program i inkonsekvent tilstand fortsette å kjøre, noe som kan ha uventede konsekvenser, men som ikke innfører usikkerhet så lenge dette bare skjer i sikker kode.
///
/// Ytelseskostnaden for påstander er imidlertid ikke målbar generelt.
/// Utskifting av [`assert!`] med `debug_assert!` oppfordres altså bare etter grundig profilering, og enda viktigere, bare i sikker kode!
///
/// # Examples
///
/// ```
/// // panic-meldingen for disse påstandene er den strengede verdien av uttrykket som er gitt.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // en veldig enkel funksjon
/// debug_assert!(some_expensive_computation());
///
/// // hevder med en tilpasset melding
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Påstår at to uttrykk er like hverandre.
///
/// På panic vil denne makroen skrive ut verdiene til uttrykkene med feilsøkingsrepresentasjonene.
///
/// I motsetning til [`assert_eq!`] er `debug_assert_eq!`-setninger bare aktivert i ikke-optimaliserte bygg som standard.
/// En optimalisert build vil ikke utføre `debug_assert_eq!`-setninger med mindre `-C debug-assertions` sendes til kompilatoren.
/// Dette gjør `debug_assert_eq!` nyttig for sjekker som er for dyre til å være til stede i en utgivelsesutgave, men kan være nyttig under utviklingen.
///
/// Resultatet av å utvide `debug_assert_eq!` blir alltid typekontrollert.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Påstår at to uttrykk ikke er like hverandre.
///
/// På panic vil denne makroen skrive ut verdiene til uttrykkene med feilsøkingsrepresentasjonene.
///
/// I motsetning til [`assert_ne!`] er `debug_assert_ne!`-setninger bare aktivert i ikke-optimaliserte bygg som standard.
/// En optimalisert build vil ikke utføre `debug_assert_ne!`-setninger med mindre `-C debug-assertions` sendes til kompilatoren.
/// Dette gjør `debug_assert_ne!` nyttig for sjekker som er for dyre til å være til stede i en utgivelsesutgave, men kan være nyttig under utviklingen.
///
/// Resultatet av å utvide `debug_assert_ne!` blir alltid typekontrollert.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Returnerer om det gitte uttrykket samsvarer med noen av de gitte mønstrene.
///
/// Som i et `match`-uttrykk, kan mønsteret etterfølges av `if` og et vaktuttrykk som har tilgang til navn bundet av mønsteret.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Pakk ut et resultat eller forplanter feilen.
///
/// `?`-operatøren ble lagt til for å erstatte `try!` og bør brukes i stedet.
/// Videre er `try` et reservert ord i Rust 2018, så hvis du må bruke det, må du bruke [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` samsvarer med gitt [`Result`].I tilfelle `Ok`-varianten har uttrykket verdien av den innpakkede verdien.
///
/// I tilfelle `Err`-varianten henter den den indre feilen.`try!` utfører deretter konvertering ved hjelp av `From`.
/// Dette gir automatisk konvertering mellom spesialiserte feil og mer generelle feil.
/// Den resulterende feilen returneres deretter umiddelbart.
///
/// På grunn av tidlig retur kan `try!` bare brukes i funksjoner som returnerer [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Den foretrukne metoden for raskt å returnere feil
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Den forrige metoden for raskt å returnere feil
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Dette tilsvarer:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Skriver formaterte data til en buffer.
///
/// Denne makroen godtar en 'writer', en formatstreng og en liste over argumenter.
/// Argumenter blir formatert i henhold til den angitte formatstrengen, og resultatet vil bli sendt til forfatteren.
/// Forfatteren kan være hvilken som helst verdi med en `write_fmt`-metode;generelt kommer dette fra en implementering av enten [`fmt::Write`] eller [`io::Write`] trait.
/// Makroen returnerer hva `write_fmt`-metoden returnerer;vanligvis en [`fmt::Result`] eller en [`io::Result`].
///
/// Se [`std::fmt`] for mer informasjon om formatstrengssyntaks.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// En modul kan importere både `std::fmt::Write` og `std::io::Write` og ringe `write!` på objekter som implementerer enten, ettersom objekter vanligvis ikke implementerer begge deler.
///
/// Imidlertid må modulen importere traits-kvalifiserte, slik at navnene ikke kommer i konflikt:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // bruker fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // bruker io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Denne makroen kan også brukes i `no_std`-oppsett.
/// I et `no_std`-oppsett er du ansvarlig for implementeringsdetaljene til komponentene.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Skriv formaterte data i en buffer, med en ny linje lagt til.
///
/// På alle plattformer er den nye linjen LINE FEED-karakteren (`\n`/`U+000A`) alene (ingen ekstra CARRIAGE RETURN (`\r`/`U+000D`).
///
/// For mer informasjon, se [`write!`].For informasjon om formatet streng syntaks, se [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// En modul kan importere både `std::fmt::Write` og `std::io::Write` og ringe `write!` på objekter som implementerer enten, ettersom objekter vanligvis ikke implementerer begge deler.
/// Imidlertid må modulen importere traits-kvalifiserte, slik at navnene ikke kommer i konflikt:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // bruker fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // bruker io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indikerer utilgjengelig kode.
///
/// Dette er nyttig når som helst kompilatoren ikke kan fastslå at noen kode ikke kan nås.For eksempel:
///
/// * Match armer med beskyttelsesforhold.
/// * Sløyfer som dynamisk avsluttes.
/// * Iteratorer som dynamisk avsluttes.
///
/// Hvis bestemmelsen om at koden ikke kan nås viser seg å være feil, avsluttes programmet umiddelbart med en [`panic!`].
///
/// Den usikre motstykket til denne makroen er [`unreachable_unchecked`]-funksjonen, som vil forårsake udefinert oppførsel hvis koden blir nådd.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Dette vil alltid [`panic!`].
///
/// # Examples
///
/// Match armer:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // kompiler feil hvis kommentert
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // en av de fattigste implementeringene av x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indikerer uimplementert kode ved å få panikk med en melding om "not implemented".
///
/// Dette gjør at koden din kan sjekke, noe som er nyttig hvis du prototyper eller implementerer en trait som krever flere metoder som du ikke har tenkt å bruke alle.
///
/// Forskjellen mellom `unimplemented!` og [`todo!`] er at mens `todo!` formidler en hensikt om å implementere funksjonaliteten senere, og meldingen er "not yet implemented", gir `unimplemented!` ingen slike krav.
/// Meldingen er "not implemented".
/// Også noen IDEer vil markere `todo!` S.
///
/// # Panics
///
/// Dette vil alltid [`panic!`] fordi `unimplemented!` bare er en stenografi for `panic!` med en fast, spesifikk melding.
///
/// I likhet med `panic!` har denne makroen et andre skjema for visning av egendefinerte verdier.
///
/// # Examples
///
/// Si at vi har en trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Vi ønsker å implementere `Foo` for 'MyStruct', men av en eller annen grunn er det bare fornuftig å implementere `bar()`-funksjonen.
/// `baz()` og `qux()` må fremdeles defineres i implementeringen av `Foo`, men vi kan bruke `unimplemented!` i deres definisjoner for å tillate at koden kompileres.
///
/// Vi vil fortsatt ha at programmet vårt slutter å kjøre hvis de ikke implementerte metodene blir nådd.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Det gir ingen mening å `baz` en `MyStruct`, så vi har ingen logikk her i det hele tatt.
/////
///         // Dette viser "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Vi har litt logikk her, vi kan legge til en melding til uimplementert!for å vise utelatelsen vår.
///         // Dette vil vise: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indikerer uferdig kode.
///
/// Dette kan være nyttig hvis du prototyper og bare ønsker å ha kodetypekontrollen.
///
/// Forskjellen mellom [`unimplemented!`] og `todo!` er at mens `todo!` formidler en hensikt om å implementere funksjonaliteten senere, og meldingen er "not yet implemented", gir `unimplemented!` ingen slike krav.
/// Meldingen er "not implemented".
/// Også noen IDEer vil markere `todo!` S.
///
/// # Panics
///
/// Dette vil alltid [`panic!`].
///
/// # Examples
///
/// Her er et eksempel på noen pågående kode.Vi har en trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Vi ønsker å implementere `Foo` på en av våre typer, men vi vil også jobbe med bare `bar()` først.For at koden skal kunne kompileres, må vi implementere `baz()`, slik at vi kan bruke `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementering går her
///     }
///
///     fn baz(&self) {
///         // la oss ikke bekymre oss for å implementere baz() for nå
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // vi bruker ikke engang baz(), så dette er greit.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definisjoner av innebygde makroer.
///
/// De fleste makroegenskapene (stabilitet, synlighet osv.) Er hentet fra kildekoden her, med unntak av utvidelsesfunksjoner som transformerer makroinnganger til utganger, disse funksjonene leveres av kompilatoren.
///
///
pub(crate) mod builtin {

    /// Fører til at kompilering mislykkes med den gitte feilmeldingen når den oppstår.
    ///
    /// Denne makroen skal brukes når en crate bruker en betinget kompileringsstrategi for å gi bedre feilmeldinger for feilaktige forhold.
    ///
    /// Det er kompileringsnivåformen til [`panic!`], men avgir en feil under *kompilering* i stedet for ved *kjøretid*.
    ///
    /// # Examples
    ///
    /// To slike eksempler er makroer og `#[cfg]`-miljøer.
    ///
    /// Send ut bedre kompilatorfeil hvis en makro overføres ugyldige verdier.
    /// Uten den endelige branch, vil kompilatoren fremdeles avgi en feil, men feilmeldingen nevner ikke de to gyldige verdiene.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Send ut kompilatorfeil hvis en av en rekke funksjoner ikke er tilgjengelig.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstruerer parametere for de andre strengformateringsmakroene.
    ///
    /// Denne makroen fungerer ved å ta en formateringsstreng som inneholder `{}` for hvert ekstra argument som sendes.
    /// `format_args!` forbereder tilleggsparametrene for å sikre at utdataene kan tolkes som en streng og kanoniserer argumentene til en enkelt type.
    /// Enhver verdi som implementerer [`Display`] trait kan overføres til `format_args!`, som enhver [`Debug`]-implementering kan overføres til en `{:?}` i formateringsstrengen.
    ///
    ///
    /// Denne makroen produserer en verdi av typen [`fmt::Arguments`].Denne verdien kan overføres til makroene i [`std::fmt`] for å utføre nyttig omdirigering.
    /// Alle andre formateringsmakroer ([`format!`], [`write!`], [`println!`], osv.) Sendes gjennom denne.
    /// `format_args!`, i motsetning til dets avledede makroer, unngår du haugetildelinger.
    ///
    /// Du kan bruke [`fmt::Arguments`]-verdien som `format_args!` returnerer i `Debug`-og `Display`-sammenhenger som vist nedenfor.
    /// Eksemplet viser også at `Debug` og `Display` format til det samme: den interpolerte formatstrengen i `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// For mer informasjon, se dokumentasjonen i [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Samme som `format_args`, men legger til en ny linje til slutt.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspiserer en miljøvariabel ved kompileringstidspunktet.
    ///
    /// Denne makroen utvides til verdien av den navngitte miljøvariabelen ved kompileringstidspunktet, og gir et uttrykk av typen `&'static str`.
    ///
    ///
    /// Hvis miljøvariabelen ikke er definert, sendes en kompileringsfeil.
    /// For å ikke sende ut en kompileringsfeil, bruk [`option_env!`]-makroen i stedet.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Du kan tilpasse feilmeldingen ved å sende en streng som den andre parameteren:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Hvis miljøvariabelen `documentation` ikke er definert, får du følgende feil:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Valgfritt inspiserer en miljøvariabel ved kompileringstidspunktet.
    ///
    /// Hvis den navngitte miljøvariabelen er til stede ved kompileringstidspunktet, utvides dette til et uttrykk av typen `Option<&'static str>` hvis verdi er `Some` av verdien til miljøvariabelen.
    /// Hvis miljøvariabelen ikke er tilstede, utvides dette til `None`.
    /// Se [`Option<T>`][Option] for mer informasjon om denne typen.
    ///
    /// En kompilerende tidsfeil sendes aldri ut når du bruker denne makroen, uavhengig av om miljøvariabelen er tilstede eller ikke.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sammenkobler identifikatorer til en identifikator.
    ///
    /// Denne makroen tar et hvilket som helst antall kommaadskilte identifikatorer og sammenkobler dem alle til en, noe som gir et uttrykk som er en ny identifikator.
    /// Merk at hygiene gjør det slik at denne makroen ikke kan fange lokale variabler.
    /// Som hovedregel er makroer bare tillatt i element-, setnings-eller uttrykksposisjon.
    /// Det betyr at mens du kan bruke denne makroen til å referere til eksisterende variabler, funksjoner eller moduler osv., Kan du ikke definere en ny med den.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//ikke brukbar på denne måten!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sammenkobler bokstaver til en statisk strengskive.
    ///
    /// Denne makroen tar et hvilket som helst antall kommaseparerte bokstaver, og gir et uttrykk av typen `&'static str` som representerer alle bokstavene sammenkoblet fra venstre til høyre.
    ///
    ///
    /// Heltall og flytende bokstav bokstavene er strenget for å bli sammenkoblet.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Utvides til linjenummeret det ble påkalt på.
    ///
    /// Med [`column!`] og [`file!`] gir disse makroene feilsøkingsinformasjon for utviklere om plasseringen i kilden.
    ///
    /// Det utvidede uttrykket har typen `u32` og er 1-basert, så den første linjen i hver fil evalueres til 1, den andre til 2 osv.
    /// Dette stemmer overens med feilmeldinger fra vanlige kompilatorer eller populære redaktører.
    /// Den returnerte linjen er *ikke nødvendigvis* linjen til selve `line!`-påkallingen, men snarere den første makroinnkallelsen som fører til påkallingen av `line!`-makroen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Utvides til kolonnenummeret der den ble påkalt.
    ///
    /// Med [`line!`] og [`file!`] gir disse makroene feilsøkingsinformasjon for utviklere om plasseringen i kilden.
    ///
    /// Det utvidede uttrykket har typen `u32` og er 1-basert, så den første kolonnen i hver linje evalueres til 1, den andre til 2 osv.
    /// Dette stemmer overens med feilmeldinger fra vanlige kompilatorer eller populære redaktører.
    /// Den returnerte kolonnen er *ikke nødvendigvis* linjen til selve `column!`-påkallingen, men heller den første makroinnkallelsen som fører til påkallingen av `column!`-makroen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Utvides til filnavnet der den ble påkalt.
    ///
    /// Med [`line!`] og [`column!`] gir disse makroene feilsøkingsinformasjon for utviklere om plasseringen i kilden.
    ///
    /// Det utvidede uttrykket har typen `&'static str`, og den returnerte filen er ikke påkallingen av selve `file!`-makroen, men heller den første makrooppfordringen som fører til påkallingen av `file!`-makroen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Strenker argumentene.
    ///
    /// Denne makroen vil gi et uttrykk av typen `&'static str` som er strengingen av alle tokens som sendes til makroen.
    /// Det er ingen begrensninger for syntaksen til selve makroinnkallelsen.
    ///
    /// Merk at de utvidede resultatene av inngangen tokens kan endres i future.Du bør være forsiktig hvis du stoler på utdataene.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inkluderer en UTF-8-kodet fil som en streng.
    ///
    /// Filen ligger i forhold til den nåværende filen (på samme måte som hvordan moduler blir funnet).
    /// Den angitte banen tolkes på en plattformspesifikk måte ved kompileringstidspunktet.
    /// Så for eksempel vil en påkallelse med en Windows-bane som inneholder tilbakeslag `\`, ikke kompileres riktig på Unix.
    ///
    ///
    /// Denne makroen gir et uttrykk av typen `&'static str` som er innholdet i filen.
    ///
    /// # Examples
    ///
    /// Anta at det er to filer i samme katalog med følgende innhold:
    ///
    /// Fil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Å kompilere 'main.rs' og kjøre den resulterende binæren vil skrive ut "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inkluderer en fil som referanse til et byte-utvalg.
    ///
    /// Filen ligger i forhold til den nåværende filen (på samme måte som hvordan moduler blir funnet).
    /// Den angitte banen tolkes på en plattformspesifikk måte ved kompileringstidspunktet.
    /// Så for eksempel vil en påkallelse med en Windows-bane som inneholder tilbakeslag `\`, ikke kompileres riktig på Unix.
    ///
    ///
    /// Denne makroen gir et uttrykk av typen `&'static [u8; N]` som er innholdet i filen.
    ///
    /// # Examples
    ///
    /// Anta at det er to filer i samme katalog med følgende innhold:
    ///
    /// Fil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Å kompilere 'main.rs' og kjøre den resulterende binæren vil skrive ut "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Utvides til en streng som representerer den nåværende modulbanen.
    ///
    /// Den nåværende modulbanen kan betraktes som hierarkiet av moduler som fører tilbake til crate root.
    /// Den første komponenten i den returnerte banen er navnet på crate som for øyeblikket blir kompilert.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evaluerer boolske kombinasjoner av konfigurasjonsflagg ved kompileringstid.
    ///
    /// I tillegg til `#[cfg]`-attributtet, er denne makroen gitt for å tillate evaluering av boolsk uttrykk av konfigurasjonsflagg.
    /// Dette fører ofte til mindre duplisert kode.
    ///
    /// Syntaksen til denne makroen er den samme syntaksen som [`cfg`]-attributtet.
    ///
    /// `cfg!`, i motsetning til `#[cfg]`, fjerner ikke noen kode og vurderes bare til sant eller usant.
    /// For eksempel må alle blokker i et if/else-uttrykk være gyldig når `cfg!` brukes til tilstanden, uavhengig av hva `cfg!` vurderer.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parserer en fil som et uttrykk eller et element i henhold til konteksten.
    ///
    /// Filen ligger i forhold til den nåværende filen (på samme måte som hvordan moduler blir funnet).Den angitte banen tolkes på en plattformspesifikk måte ved kompileringstidspunktet.
    /// Så for eksempel vil en påkallelse med en Windows-bane som inneholder tilbakeslag `\`, ikke kompileres riktig på Unix.
    ///
    /// Å bruke denne makroen er ofte en dårlig ide, for hvis filen blir analysert som et uttrykk, vil den plasseres i den omkringliggende koden uhygienisk.
    /// Dette kan føre til at variabler eller funksjoner er forskjellige fra hva filen forventet hvis det er variabler eller funksjoner som har samme navn i den nåværende filen.
    ///
    ///
    /// # Examples
    ///
    /// Anta at det er to filer i samme katalog med følgende innhold:
    ///
    /// Fil 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Å kompilere 'main.rs' og kjøre den resulterende binæren vil skrive ut "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Påstår at et boolsk uttrykk er `true` ved kjøretid.
    ///
    /// Dette vil påkalle [`panic!`]-makroen hvis det angitte uttrykket ikke kan evalueres til `true` ved kjøretid.
    ///
    /// # Uses
    ///
    /// Påstander blir alltid sjekket i både feilsøkings-og utgivelsesbygger, og kan ikke deaktiveres.
    /// Se [`debug_assert!`] for påstander som ikke er aktivert i utgivelsesbygger som standard.
    ///
    /// Usikker kode kan stole på `assert!` for å håndheve invarianter i løpetid som kan føre til utrygghet hvis det krenkes.
    ///
    /// Andre brukstilfeller av `assert!` inkluderer testing og håndhevelse av kjøretidsinvariere i sikker kode (hvis brudd ikke kan føre til usikkerhet).
    ///
    ///
    /// # Egendefinerte meldinger
    ///
    /// Denne makroen har et andre skjema, der en tilpasset panic-melding kan leveres med eller uten argumenter for formatering.
    /// Se [`std::fmt`] for syntaks for dette skjemaet.
    /// Uttrykk brukt som formatargumenter vil bare bli evaluert hvis påstanden mislykkes.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // panic-meldingen for disse påstandene er den strengede verdien av uttrykket som er gitt.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // en veldig enkel funksjon
    ///
    /// assert!(some_computation());
    ///
    /// // hevder med en tilpasset melding
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Integrert montering.
    ///
    /// Les [unstable book] for bruk.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-stil innebygd montering.
    ///
    /// Les [unstable book] for bruk.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Integrert montering på modulnivå.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Utskrift passerte tokens inn i standardutgangen.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Aktiverer eller deaktiverer sporingsfunksjonalitet som brukes til feilsøking av andre makroer.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Attributtmakro som brukes til å bruke avledede makroer.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attributtmakro brukt på en funksjon for å gjøre den om til en enhetstest.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Attributtmakro brukt på en funksjon for å gjøre den om til en referansetest.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// En implementeringsdetalj av `#[test]`-og `#[bench]`-makroene.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Attributtmakro brukt på en statisk for å registrere den som en global tildeler.
    ///
    /// Se også [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Beholder varen den er brukt på hvis den passerte banen er tilgjengelig, og fjerner den ellers.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Utvider alle `#[cfg]`-og `#[cfg_attr]`-attributter i kodefragmentet den brukes på.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Ustabil implementeringsdetalj av `rustc`-kompilatoren, ikke bruk.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Ustabil implementeringsdetalj av `rustc`-kompilatoren, ikke bruk.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}