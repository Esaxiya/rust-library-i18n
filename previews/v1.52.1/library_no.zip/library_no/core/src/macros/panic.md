Panics den gjeldende tråden.

Dette gjør at et program kan avsluttes umiddelbart og gi tilbakemelding til innringeren av programmet.
`panic!` skal brukes når et program når en uopprettelig tilstand.

Denne makroen er den perfekte måten å hevde forhold i eksempelkode og i tester.
`panic!` er nært knyttet til `unwrap`-metoden i både [`Option`][ounwrap]-og [`Result`][runwrap]-enums.
Begge implementeringene kaller `panic!` når de er satt til [`None`]-eller [`Err`]-varianter.

Når du bruker `panic!()`, kan du spesifisere en streng nyttelast som er bygget ved hjelp av [`format!`]-syntaksen.
Denne nyttelasten brukes når vi injiserer panic i den kallende Rust-tråden, noe som får tråden til panic helt.

Oppførselen til standard `std` hook, dvs.
koden som kjører direkte etter at panic er påkalt, er å skrive ut nyttelasten til `stderr` sammen med file/line/column-informasjonen til `panic!()`-samtalen.

Du kan overstyre panic hook ved hjelp av [`std::panic::set_hook()`].
Inne i hook kan en panic nås som en `&dyn Any + Send`, som inneholder enten en `&str` eller `String` for vanlige `panic!()`-påkallinger.
Til panic med en verdi av en annen type, kan [`panic_any`] brukes.

[`Result`] enum er ofte en bedre løsning for å gjenopprette feil enn å bruke `panic!`-makroen.
Denne makroen skal brukes for å unngå å fortsette å bruke feil verdier, for eksempel fra eksterne kilder.
Detaljert informasjon om feilhåndtering finnes i [book].

Se også makroen [`compile_error!`] for å få opp feil under kompilering.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Gjeldende implementering

Hvis hovedtråden panics vil den avslutte alle trådene dine og avslutte programmet med koden `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





