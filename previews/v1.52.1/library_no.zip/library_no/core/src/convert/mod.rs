//! Traits for konvertering mellom typer.
//!
//! traits i denne modulen gir en måte å konvertere fra en type til en annen type.
//! Hver trait tjener et annet formål:
//!
//! - Implementere [`AsRef`] trait for billige referanse-til-referanse-konverteringer
//! - Implementer [`AsMut`] trait for billige mutable-til-mutable konverteringer
//! - Implementere [`From`] trait for å konsumere verdi-til-verdi-konverteringer
//! - Implementere [`Into`] trait for å konsumere verdi-til-verdi-konverteringer til typer utenfor gjeldende crate
//! - [`TryFrom`] og [`TryInto`] traits oppfører seg som [`From`] og [`Into`], men bør implementeres når konverteringen kan mislykkes.
//!
//! traits i denne modulen brukes ofte som trait bounds for generiske funksjoner slik at argumenter av flere typer støttes.Se dokumentasjonen til hver trait for eksempler.
//!
//! Som biblioteksforfatter bør du alltid foretrekke å implementere [`From<T>`][`From`] eller [`TryFrom<T>`][`TryFrom`] i stedet for [`Into<U>`][`Into`] eller [`TryInto<U>`][`TryInto`], da [`From`] og [`TryFrom`] gir større fleksibilitet og tilbyr tilsvarende [`Into`]-eller [`TryInto`]-implementeringer gratis, takket være en teppeimplementering i standardbiblioteket.
//! Når du målretter mot en versjon før Rust 1.41, kan det være nødvendig å implementere [`Into`] eller [`TryInto`] direkte når du konverterer til en type utenfor gjeldende crate.
//!
//! # Generiske implementeringer
//!
//! - [`AsRef`] og [`AsMut`] automatisk referanse hvis den indre typen er en referanse
//! - [`From`]`<U>for T` innebærer [`Into`]`</u><T><U>for U`</u>
//! - [`TryFrom`]`<U>for T` innebærer [`TryInto`]`</u><T><U>for U`</u>
//! - [`From`] og [`Into`] er refleksive, noe som betyr at alle typer kan `into` selv og `from` selv
//!
//! Se hver trait for brukseksempler.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Identitetsfunksjonen.
///
/// To ting er viktig å merke seg om denne funksjonen:
///
/// - Det tilsvarer ikke alltid en lukking som `|x| x`, siden lukkingen kan tvinge `x` til en annen type.
///
/// - Den flytter inngangen `x` sendt til funksjonen.
///
/// Selv om det kan virke rart å ha en funksjon som bare returnerer inngangen, er det noen interessante bruksområder.
///
///
/// # Examples
///
/// Bruke `identity` til å gjøre noe i en rekke andre, interessante funksjoner:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // La oss late som å legge til en er en interessant funksjon.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Bruke `identity` som en "do nothing" basissak i en betinget:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Gjør mer interessante ting ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Bruke `identity` til å beholde `Some`-variantene av en iterator av `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Brukes til å gjøre en billig referanse til referanse konvertering.
///
/// Denne trait ligner på [`AsMut`] som brukes til å konvertere mellom mutable referanser.
/// Hvis du trenger å gjøre en kostbar konvertering, er det bedre å implementere [`From`] med type `&T` eller skrive en tilpasset funksjon.
///
/// `AsRef` har samme signatur som [`Borrow`], men [`Borrow`] er forskjellig i få aspekter:
///
/// - I motsetning til `AsRef` har [`Borrow`] et teppeimpl for alle `T`, og kan brukes til å godta enten en referanse eller en verdi.
/// - [`Borrow`] krever også at [`Hash`], [`Eq`] og [`Ord`] for lånte verdi tilsvarer verdiene til den eide verdien.
/// Av denne grunn, hvis du bare vil låne et enkelt felt i en struktur, kan du implementere `AsRef`, men ikke [`Borrow`].
///
/// **Note: Denne trait må ikke mislykkes **.Hvis konverteringen kan mislykkes, bruk en dedikert metode som returnerer en [`Option<T>`] eller en [`Result<T, E>`].
///
/// # Generiske implementeringer
///
/// - `AsRef` auto-dereferences hvis den indre typen er en referanse eller en mutbar referanse (f.eks: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Ved å bruke trait bounds kan vi akseptere argumenter av forskjellige typer så lenge de kan konverteres til den spesifiserte typen `T`.
///
/// For eksempel: Ved å lage en generisk funksjon som tar en `AsRef<str>`, uttrykker vi at vi vil akseptere alle referanser som kan konverteres til [`&str`] som et argument.
/// Siden både [`String`] og [`&str`] implementerer `AsRef<str>`, kan vi godta begge som inputargument.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Utfører konverteringen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Brukes til å gjøre en billig referansekonvertering som kan forandres til å endre.
///
/// Denne trait ligner på [`AsRef`], men brukes til å konvertere mellom mutable referanser.
/// Hvis du trenger å gjøre en kostbar konvertering, er det bedre å implementere [`From`] med type `&mut T` eller skrive en tilpasset funksjon.
///
/// **Note: Denne trait må ikke mislykkes **.Hvis konverteringen kan mislykkes, bruk en dedikert metode som returnerer en [`Option<T>`] eller en [`Result<T, E>`].
///
/// # Generiske implementeringer
///
/// - `AsMut` auto-dereferences hvis den indre typen er en mutbar referanse (f.eks: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ved å bruke `AsMut` som trait bound for en generisk funksjon kan vi akseptere alle mutable referanser som kan konverteres til type `&mut T`.
/// Fordi [`Box<T>`] implementerer `AsMut<T>`, kan vi skrive en funksjon `add_one` som tar alle argumenter som kan konverteres til `&mut u64`.
/// Fordi [`Box<T>`] implementerer `AsMut<T>`, godtar `add_one` også argumenter av typen `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Utfører konverteringen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// En verdi-til-verdi-konvertering som forbruker inngangsverdien.Det motsatte av [`From`].
///
/// Man bør unngå å implementere [`Into`] og implementere [`From`] i stedet.
/// Implementering av [`From`] gir automatisk en implementering av [`Into`] takket være teppimplementeringen i standardbiblioteket.
///
/// Foretrekker å bruke [`Into`] over [`From`] når du spesifiserer trait bounds på en generisk funksjon for å sikre at typer som bare implementerer [`Into`] også kan brukes.
///
/// **Note: Denne trait må ikke mislykkes **.Hvis konverteringen kan mislykkes, bruk [`TryInto`].
///
/// # Generiske implementeringer
///
/// - [`Fra`]`<T>for U` innebærer `Into<U> for T`
/// - [`Into`] er refleksiv, noe som betyr at `Into<T> for T` er implementert
///
/// # Implementering av [`Into`] for konvertering til eksterne typer i gamle versjoner av Rust
///
/// Før Rust 1.41, hvis destinasjonstypen ikke var en del av gjeldende crate, kunne du ikke implementere [`From`] direkte.
/// Ta for eksempel denne koden:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Dette kan ikke kompileres i eldre versjoner av språket fordi Rust s foreldreløse regler pleide å være litt strengere.
/// For å omgå dette, kan du implementere [`Into`] direkte:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Det er viktig å forstå at [`Into`] ikke gir en [`From`]-implementering (som [`From`] gjør med [`Into`]).
/// Derfor bør du alltid prøve å implementere [`From`] og deretter falle tilbake til [`Into`] hvis [`From`] ikke kan implementeres.
///
/// # Examples
///
/// [`String`] implementerer [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// For å uttrykke at vi ønsker at en generisk funksjon skal ta alle argumenter som kan konverteres til en spesifisert type `T`, kan vi bruke en trait bound av [`Into`]`<T>`.
///
/// For eksempel: Funksjonen `is_hello` tar alle argumenter som kan konverteres til en [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Utfører konverteringen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Brukes til å gjøre verdi-til-verdi-konverteringer mens du forbruker inngangsverdien.Det er gjensidig av [`Into`].
///
/// Man bør alltid foretrekke å implementere `From` fremfor [`Into`] fordi implementering av `From` automatisk gir en implementering av [`Into`] takket være teppeimplementeringen i standardbiblioteket.
///
///
/// Implementer bare [`Into`] når du målretter mot en versjon før Rust 1.41 og konverterer til en type utenfor gjeldende crate.
/// `From` var ikke i stand til å gjøre denne typen konverteringer i tidligere versjoner på grunn av Rust s foreldreløse regler.
/// Se [`Into`] for mer informasjon.
///
/// Foretrekker å bruke [`Into`] fremfor å bruke `From` når du spesifiserer trait bounds på en generisk funksjon.
/// På denne måten kan typer som direkte implementerer [`Into`] også brukes som argumenter.
///
/// `From` er også veldig nyttig når du utfører feilhåndtering.Når du konstruerer en funksjon som er i stand til å mislykkes, vil returtypen generelt være av formen `Result<T, E>`.
/// `From` trait forenkler feilhåndtering ved å la en funksjon returnere en enkelt feiltype som innkapsler flere feiltyper.Se "Examples"-delen og [the book][book] for mer informasjon.
///
/// **Note: Denne trait må ikke mislykkes **.Hvis konverteringen kan mislykkes, bruk [`TryFrom`].
///
/// # Generiske implementeringer
///
/// - `From<T> for U` innebærer [`Into`]`<U>for T`</u>
/// - `From` er refleksiv, noe som betyr at `From<T> for T` er implementert
///
/// # Examples
///
/// [`String`] implementerer `From<&str>`:
///
/// En eksplisitt konvertering fra en `&str` til en streng gjøres som følger:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Når du utfører feilhåndtering, er det ofte nyttig å implementere `From` for din egen feiltype.
/// Ved å konvertere underliggende feiltyper til vår egen tilpassede feiltype som innkapsler den underliggende feiltypen, kan vi returnere en enkelt feiltype uten å miste informasjon om den underliggende årsaken.
/// '?'-operatøren konverterer automatisk den underliggende feiltypen til vår tilpassede feiltype ved å ringe `Into<CliError>::into`, som automatisk blir gitt når `From` implementeres.
/// Kompilatoren avgjør deretter hvilken implementering av `Into` som skal brukes.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Utfører konverteringen.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Et konverteringsforsøk som bruker `self`, som kanskje eller ikke kan være dyrt.
///
/// Biblioteksforfattere bør vanligvis ikke implementere denne trait direkte, men foretrekker å implementere [`TryFrom`] trait, som gir større fleksibilitet og gir en tilsvarende `TryInto`-implementering gratis, takket være en teppeimplementering i standardbiblioteket.
/// For mer informasjon om dette, se dokumentasjonen for [`Into`].
///
/// # Implementering av `TryInto`
///
/// Dette har samme begrensninger og resonnementer som å implementere [`Into`], se der for detaljer.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Typen som returneres i tilfelle en konverteringsfeil.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Utfører konverteringen.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Enkel og sikker type konvertering som kan mislykkes på en kontrollert måte under noen omstendigheter.Det er gjensidig av [`TryInto`].
///
/// Dette er nyttig når du gjør en type konvertering som trivielt kan lykkes, men som også kan trenge spesiell håndtering.
/// For eksempel er det ingen måte å konvertere en [`i64`] til en [`i32`] ved hjelp av [`From`] trait, fordi en [`i64`] kan inneholde en verdi som en [`i32`] ikke kan representere, og slik at konverteringen vil miste data.
///
/// Dette kan håndteres ved å kutte [`i64`] til en [`i32`] (i hovedsak gi [`i64`] s verdi modulo [`i32::MAX`]) eller ved å bare returnere [`i32::MAX`], eller ved hjelp av en annen metode.
/// [`From`] trait er ment for perfekte konverteringer, så `TryFrom` trait informerer programmereren når en type konvertering kan gå dårlig og lar dem bestemme hvordan de skal håndtere den.
///
/// # Generiske implementeringer
///
/// - `TryFrom<T> for U` innebærer [`TryInto`]`<U>for T`</u>
/// - [`try_from`] er refleksiv, noe som betyr at `TryFrom<T> for T` er implementert og ikke kan mislykkes-den tilhørende `Error`-typen for å ringe `T::try_from()` på en verdi av typen `T` er [`Infallible`].
/// Når [`!`]-typen er stabilisert, vil [`Infallible`] og [`!`] være likeverdige.
///
/// `TryFrom<T>` kan implementeres som følger:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Som beskrevet implementerer [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Trunkerer `big_number` stille, krever oppdagelse og håndtering av avkuttingen etter det faktum.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Returnerer en feil fordi `big_number` er for stor til å passe i en `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Returnerer `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Typen som returneres i tilfelle en konverteringsfeil.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Utfører konverteringen.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERISKE IMPLER
////////////////////////////////////////////////////////////////////////////////

// Som heiser over&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Som heiser over &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): erstatt implisatene ovenfor for&/&mut med følgende mer generelle:
// // Som heiser over Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut løfter over &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): erstatt impl. Over for &mut med følgende mer generelle:
// // AsMut løfter seg over DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Størrelse> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Fra innebærer Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Fra (og dermed inn i) er refleksiv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabilitetsmerknad:** Dette impl eksisterer ennå ikke, men vi er "reserving space" for å legge det til i future.
/// Se [rust-lang/rust#64715][#64715] for detaljer.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): gjør en prinsipiell løsning i stedet.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom innebærer TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Ufeilbare konverteringer er semantisk ekvivalente med feilbare konverteringer med ubebodd feiltype.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETONGIMPLER
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// INGEN FEIL FEILTYPE
////////////////////////////////////////////////////////////////////////////////

/// Feiltypen for feil som aldri kan skje.
///
/// Siden denne enum ikke har noen variant, kan en verdi av denne typen faktisk aldri eksistere.
/// Dette kan være nyttig for generiske API-er som bruker [`Result`] og parameteriserer feiltypen, for å indikere at resultatet alltid er [`Ok`].
///
/// For eksempel har [`TryFrom`] trait (konvertering som returnerer en [`Result`]) en teppeimplementering for alle typer der det finnes en omvendt [`Into`]-implementering.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future-kompatibilitet
///
/// Dette enum har samme rolle som [the `!`“never”type][never], som er ustabil i denne versjonen av Rust.
/// Når `!` er stabilisert, planlegger vi å gjøre `Infallible` til et typealias for det:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... og til slutt avskaffe `Infallible`.
///
/// Imidlertid er det et tilfelle der `!`-syntaks kan brukes før `!` stabiliseres som en fullverdig type: i posisjonen til en funksjons returtype.
/// Spesielt er det mulig implementeringer for to forskjellige funksjonspekertyper:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Da `Infallible` er enum, er denne koden gyldig.
/// Imidlertid når `Infallible` blir et alias for never type, vil de to `impl`ene begynne å overlappe hverandre og vil derfor ikke bli tillatt av språkets trait-koherensregler.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}