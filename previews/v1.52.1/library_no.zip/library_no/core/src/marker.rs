//! Primitive traits og typer som representerer grunnleggende egenskaper for typene.
//!
//! Rust-typer kan klassifiseres på forskjellige nyttige måter i henhold til deres iboende egenskaper.
//! Disse klassifiseringene er representert som traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Typer som kan overføres over trådgrenser.
///
/// Denne trait implementeres automatisk når kompilatoren bestemmer at den er passende.
///
/// Et eksempel på en ikke-Send-type er referansetellingspekeren [`rc::Rc`][`Rc`].
/// Hvis to tråder prøver å klone [`Rc`] som peker på den samme referansetelte verdien, kan de prøve å oppdatere referansetellingen samtidig, som er [undefined behavior][ub] fordi [`Rc`] ikke bruker atomoperasjoner.
///
/// Fetteren [`sync::Arc`][arc] bruker atomoperasjoner (påløper noe overhead) og er dermed `Send`.
///
/// Se [the Nomicon](../../nomicon/send-and-sync.html) for mer informasjon.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Typer med konstant størrelse kjent ved kompileringstid.
///
/// Alle typeparametere har en implisitt avgrensning på `Sized`.Den spesielle syntaksen `?Sized` kan brukes til å fjerne denne grensen hvis den ikke er passende.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//feil: Størrelse er ikke implementert for [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Det eneste unntaket er den implisitte `Self`-typen av en trait.
/// En trait har ikke en implisitt `Sized`-bundet, da dette er inkompatibelt med [trait-objekt] der, per definisjon, trait trenger å jobbe med alle mulige implementatorer, og dermed kan være hvilken som helst størrelse.
///
///
/// Selv om Rust lar deg binde `Sized` til en trait, vil du ikke kunne bruke den til å danne et trait-objekt senere:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // la y: &dyn Bar= &Impl;//feil: trait `Bar` kan ikke gjøres til et objekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // for Standard, for eksempel, som krever at `[T]: !Default` kan evalueres
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Typer som kan være "unsized" til en dynamisk størrelse.
///
/// For eksempel implementerer den store matrisen `[i8; 2]` `Unsize<[i8]>` og `Unsize<dyn fmt::Debug>`.
///
/// Alle implementeringer av `Unsize` leveres automatisk av kompilatoren.
///
/// `Unsize` er implementert for:
///
/// - `[T; N]` er `Unsize<[T]>`
/// - `T` er `Unsize<dyn Trait>` når `T: Trait`
/// - `Foo<..., T, ...>` er `Unsize<Foo<..., U, ...>>` hvis:
///   - `T: Unsize<U>`
///   - Foo er en struktur
///   - Bare det siste feltet i `Foo` har en type som involverer `T`
///   - `T` er ikke en del av typen andre felt
///   - `Bar<T>: Unsize<Bar<U>>`, hvis det siste feltet i `Foo` har typen `Bar<T>`
///
/// `Unsize` brukes sammen med [`ops::CoerceUnsized`] for å tillate at "user-defined"-containere som [`Rc`] inneholder typer av dynamisk størrelse.
/// Se [DST coercion RFC][RFC982] og [the nomicon entry on coercion][nomicon-coerce] for mer informasjon.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Nødvendig trait for konstanter som brukes i mønsterkamper.
///
/// Enhver type som kommer fra `PartialEq` implementerer automatisk denne trait,*uansett* om typeparametrene implementerer `Eq`.
///
/// Hvis et `const`-element inneholder en type som ikke implementerer denne trait, implementerer den typen enten (1.) ikke `PartialEq` (noe som betyr at konstanten ikke gir den sammenligningsmetoden, som kodegenerering antar er tilgjengelig), eller (2.) den implementerer *sin egen* versjon av `PartialEq` (som vi antar ikke samsvarer med en strukturell-likhet-sammenligning).
///
///
/// I et av de to scenariene ovenfor avviser vi bruk av en slik konstant i en mønsterkamp.
///
/// Se også [structural match RFC][RFC1445] og [issue 63438] som motiverte migrering fra attributtbasert design til denne trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Nødvendig trait for konstanter som brukes i mønsterkamper.
///
/// Enhver type som kommer fra `Eq` implementerer automatisk denne trait,*uansett* om typeparametrene implementerer `Eq`.
///
/// Dette er et hack for å omgå en begrensning i vårt typesystem.
///
/// # Background
///
/// Vi ønsker å kreve at typer consts brukt i mønster samsvarer har attributtet `#[derive(PartialEq, Eq)]`.
///
/// I en mer ideell verden kunne vi sjekke dette kravet ved å bare sjekke at den gitte typen implementerer både `StructuralPartialEq` trait *og*`Eq` trait.
/// Du kan imidlertid ha ADT-er som *gjør*`derive(PartialEq, Eq)`, og være en sak som vi vil at kompilatoren skal godta, og likevel unnlater konstantens type å implementere `Eq`.
///
/// Nemlig en sak som denne:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Problemet i koden ovenfor er at `Wrap<fn(&())>` ikke implementerer `PartialEq`, heller ikke `Eq`, fordi `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Derfor kan vi ikke stole på naiv sjekk for `StructuralPartialEq` og bare `Eq`.
///
/// Som et hack for å omgå dette bruker vi to separate traits injisert av hver av de to avledninger (`#[derive(PartialEq)]` og `#[derive(Eq)]`) og sjekker at begge er til stede som en del av strukturell matchkontroll.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Typer hvis verdier kan dupliseres ganske enkelt ved å kopiere biter.
///
/// Som standard har variable bindinger "flytt semantikk".Med andre ord:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` har flyttet til `y`, og kan derfor ikke brukes
///
/// // println! ("{: ?}", x);//feil: bruk av flyttet verdi
/// ```
///
/// Imidlertid, hvis en type implementerer `Copy`, har den i stedet 'copy semantics':
///
/// ```
/// // Vi kan utlede en `Copy`-implementering.
/// // `Clone` er også nødvendig, da det er et supertrait av `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` er en kopi av `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Det er viktig å merke seg at i disse to eksemplene er den eneste forskjellen om du har tilgang til `x` etter oppgaven.
/// Under panseret kan både en kopi og et trekk føre til at biter blir kopiert i minnet, selv om dette noen ganger er optimalisert borte.
///
/// ## Hvordan kan jeg implementere `Copy`?
///
/// Det er to måter å implementere `Copy` på din type.Det enkleste er å bruke `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Du kan også implementere `Copy` og `Clone` manuelt:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Det er en liten forskjell mellom de to: `derive`-strategien vil også plassere en `Copy` bundet på typeparametere, noe som ikke alltid er ønsket.
///
/// ## Hva er forskjellen mellom `Copy` og `Clone`?
///
/// Kopier skjer implisitt, for eksempel som en del av en oppgave `y = x`.Oppførselen til `Copy` er ikke overbelastbar;det er alltid en enkel bitvis kopi.
///
/// Kloning er en eksplisitt handling, `x.clone()`.Implementeringen av [`Clone`] kan gi enhver type spesifikk oppførsel som er nødvendig for å duplisere verdier trygt.
/// For eksempel må implementeringen av [`Clone`] for [`String`] kopiere den pekte til strengbufferen i bunken.
/// En enkel bitvis kopi av [`String`]-verdier vil bare kopiere pekeren, noe som fører til en dobbel ledig nedover linjen.
/// Av denne grunn er [`String`] [`Clone`], men ikke `Copy`.
///
/// [`Clone`] er et supertrait av `Copy`, så alt som er `Copy` må også implementere [`Clone`].
/// Hvis en type er `Copy`, trenger [`Clone`]-implementeringen bare å returnere `*self` (se eksemplet ovenfor).
///
/// ## Når kan typen min være `Copy`?
///
/// En type kan implementere `Copy` hvis alle komponentene implementerer `Copy`.For eksempel kan denne strukturen være `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// En struktur kan være `Copy`, og [`i32`] er `Copy`, derfor er `Point` kvalifisert til å være `Copy`.
/// Derimot, vurder
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Strukturen `PointList` kan ikke implementere `Copy`, fordi [`Vec<T>`] ikke er `Copy`.Hvis vi prøver å utlede en `Copy`-implementering, får vi en feil:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Delte referanser (`&T`) er også `Copy`, så en type kan være `Copy`, selv når den har delte referanser av typene `T` som ikke er * `Copy`.
/// Tenk på følgende struktur, som kan implementere `Copy`, fordi den bare har en *delt referanse* til vår ikke-kopi-type `PointList` ovenfra:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Når *kan ikke* typen min være `Copy`?
///
/// Noen typer kan ikke kopieres trygt.For eksempel vil kopiering av `&mut T` opprette en alias mutabel referanse.
/// Kopiering av [`String`] vil duplisere ansvaret for å administrere [`` String '' 's buffer, noe som fører til en dobbel gratis.
///
/// Generelt sistnevnte tilfelle, kan enhver type som implementerer [`Drop`] ikke være `Copy`, fordi den administrerer noen ressurser i tillegg til sine egne [`size_of::<T>`]-byte.
///
/// Hvis du prøver å implementere `Copy` på en struktur eller enum som inneholder data som ikke er 'Kopi', får du feilen [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Når *skal* typen min være `Copy`?
///
/// Generelt sett, hvis din type _can_ implementerer `Copy`, burde den.
/// Husk imidlertid at implementering av `Copy` er en del av det offentlige API-et av din type.
/// Hvis typen kanskje ikke blir "Kopi" i future, kan det være forsvarlig å utelate `Copy`-implementeringen nå, for å unngå en ødeleggende API-endring.
///
/// ## Flere implementatorer
///
/// I tillegg til [implementors listed below][impls] implementerer følgende typer også `Copy`:
///
/// * Funksjonstyper (dvs. de forskjellige typene som er definert for hver funksjon)
/// * Funksjonstypetyper (f.eks. `fn() -> i32`)
/// * Array-typer, for alle størrelser, hvis varetypen også implementerer `Copy` (f.eks. `[i32; 123456]`)
/// * Tupeltyper, hvis hver komponent også implementerer `Copy` (f.eks. `()`, `(i32, bool)`)
/// * Lukkingstyper, hvis de ikke fanger noen verdi fra miljøet, eller hvis alle slike fangede verdier implementerer `Copy` selv.
///   Vær oppmerksom på at variabler fanget av delt referanse alltid implementerer `Copy` (selv om referenten ikke gjør det), mens variabler fanget av mutabel referanse aldri implementerer `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Dette tillater kopiering av en type som ikke implementerer `Copy` på grunn av utilfredse levetidsgrenser (kopiering av `A<'_>` når bare `A<'static>: Copy` og `A<'_>: Clone`).
// Vi har denne egenskapen her for nå bare fordi det allerede er mange spesialiseringer på `Copy` som allerede finnes i standardbiblioteket, og det er ingen måte å trygt ha denne oppførselen akkurat nå.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Hent makro som genererer en impl. Av trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Typer som det er trygt å dele referanser mellom tråder.
///
/// Denne trait implementeres automatisk når kompilatoren bestemmer at den er passende.
///
/// Den presise definisjonen er: en type `T` er [`Sync`] hvis og bare hvis `&T` er [`Send`].
/// Med andre ord, hvis det ikke er mulighet for [undefined behavior][ub] (inkludert dataløp) når `&T`-referanser sendes mellom tråder.
///
/// Som man kunne forvente, er primitive typer som [`u8`] og [`f64`] alle [`Sync`], og det er også enkle aggregattyper som inneholder dem, som tupler, bånd og enums.
/// Flere eksempler på grunnleggende [`Sync`]-typer inkluderer "immutable"-typer som `&T`, og de med enkel arvet mutabilitet, for eksempel [`Box<T>`][box], [`Vec<T>`][vec] og de fleste andre samlingstyper.
///
/// (Generiske parametere må være [`Sync`] for at beholderen skal være [`Sync`].)
///
/// En noe overraskende konsekvens av definisjonen er at `&mut T` er `Sync` (hvis `T` er `Sync`), selv om det virker som det kan gi usynkronisert mutasjon.
/// Trikset er at en foranderlig referanse bak en delt referanse (det vil si `& &mut T`) blir skrivebeskyttet, som om det var en `& &T`.
/// Derfor er det ingen risiko for et dataløp.
///
/// Typer som ikke er `Sync`, er de som har "interior mutability" i en ikke-trådsikker form, for eksempel [`Cell`][cell] og [`RefCell`][refcell].
/// Disse typene tillater mutasjon av innholdet selv gjennom en uforanderlig, delt referanse.
/// For eksempel tar `set`-metoden på [`Cell<T>`][cell] `&self`, så den krever bare en delt referanse [`&Cell<T>`][cell].
/// Metoden utfører ingen synkronisering, og [`Cell`][cell] kan derfor ikke være `Sync`.
///
/// Et annet eksempel på en ikke-synk-type er referansetellingspekeren [`Rc`][rc].
/// Gitt hvilken som helst referanse [`&Rc<T>`][rc], kan du klone en ny [`Rc<T>`][rc], og endre referansetallene på en ikke-atomær måte.
///
/// For tilfeller der man trenger trådsikker interiørmutabilitet, gir Rust [atomic data types], samt eksplisitt låsing via [`sync::Mutex`][mutex] og [`sync::RwLock`][rwlock].
/// Disse typene sikrer at mutasjoner ikke kan forårsake dataløp, derfor er typene `Sync`.
/// På samme måte gir [`sync::Arc`][arc] en trådsikker analog av [`Rc`][rc].
///
/// Alle typer med interiørmutabilitet må også bruke [`cell::UnsafeCell`][unsafecell]-omslaget rundt value(s) som kan muteres gjennom en delt referanse.
/// Unnlater å gjøre dette er [undefined behavior][ub].
/// For eksempel er [`transmute`][transmute]-ing fra `&T` til `&mut T` ugyldig.
///
/// Se [the Nomicon][nomicon-send-and-sync] for mer informasjon om `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): gang støtte for å legge til notater i `rustc_on_unimplemented` lander i beta, og det er utvidet for å sjekke om en lukking er noe sted i kravkjeden, utvide den som sådan (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nullstørrelse brukes til å merke ting som "act like" de eier en `T`.
///
/// Å legge til et `PhantomData<T>`-felt til typen din forteller kompilatoren at typen din fungerer som om den lagrer en verdi av typen `T`, selv om den ikke gjør det.
/// Denne informasjonen brukes når du beregner visse sikkerhetsegenskaper.
///
/// For en mer inngående forklaring på hvordan du bruker `PhantomData<T>`, se [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Et uhyggelig notat 👻👻👻
///
/// Selv om de begge har skumle navn, er `PhantomData` og 'fantomtyper' beslektede, men ikke identiske.En fantomtypeparameter er ganske enkelt en typeparameter som aldri brukes.
/// I Rust får dette ofte kompilatoren til å klage, og løsningen er å legge til en "dummy"-bruk ved hjelp av `PhantomData`.
///
/// # Examples
///
/// ## Ubrukt livstidsparameter
///
/// Kanskje den vanligste brukssaken for `PhantomData` er en struktur som har en ubrukt levetidsparameter, vanligvis som en del av en usikker kode.
/// For eksempel er her en struktur `Slice` som har to pekere av typen `*const T`, som antagelig peker inn i en matrise et sted:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Hensikten er at de underliggende dataene bare er gyldige i hele livet `'a`, så `Slice` skal ikke overleve `'a`.
/// Imidlertid kommer ikke denne hensikten til uttrykk i koden, siden det ikke brukes noen levetid på `'a`, og det er derfor ikke klart hvilke data den gjelder for.
/// Vi kan rette dette ved å fortelle kompilatoren å handle *som om*`Slice`-strukturen inneholdt en referanse `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Dette krever i sin tur også merknaden `T: 'a`, noe som indikerer at eventuelle referanser i `T` er gyldige over hele `'a`.
///
/// Når du initialiserer en `Slice`, oppgir du bare verdien `PhantomData` for feltet `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Ubrukt typeparameter
///
/// Noen ganger hender det at du har ubrukte typeparametere som indikerer hvilken type data en struct er "tied" til, selv om disse dataene faktisk ikke finnes i selve strukturen.
/// Her er et eksempel der dette oppstår med [FFI].
/// Det utenlandske grensesnittet bruker håndtak av typen `*mut ()` for å referere til Rust-verdier av forskjellige typer.
/// Vi sporer Rust-typen ved hjelp av en fantomtypeparameter på strukturen `ExternalResource` som bryter et håndtak.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Eierskap og drop check
///
/// Å legge til et felt av typen `PhantomData<T>` indikerer at typen din eier data av typen `T`.Dette innebærer igjen at når typen din blir droppet, kan den slippe en eller flere forekomster av typen `T`.
/// Dette har betydning for Rust-kompilatorens [drop check]-analyse.
///
/// Hvis strukturen din faktisk ikke *eier* dataene av typen `T`, er det bedre å bruke en referansetype, som `PhantomData<&'a T>` (ideally) eller `PhantomData<*const T>` (hvis ingen levetid gjelder), for ikke å indikere eierskap.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-intern trait brukes til å indikere typen enum-diskriminanter.
///
/// Denne trait implementeres automatisk for alle typer og gir ingen garantier for [`mem::Discriminant`].
/// Det er **udefinert oppførsel** å transmittere mellom `DiscriminantKind::Discriminant` og `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Typen av diskriminanten som må tilfredsstille trait bounds som kreves av `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-intern trait brukes til å bestemme om en type inneholder noen `UnsafeCell` internt, men ikke gjennom en indireksjon.
///
/// Dette påvirker for eksempel om en `static` av den typen plasseres i skrivebeskyttet statisk minne eller skrivbart statisk minne.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Typer som kan flyttes trygt etter å ha blitt festet.
///
/// Rust selv har ingen forestillinger om ubevegelige typer, og anser at bevegelser (f.eks. Gjennom oppdrag eller [`mem::replace`]) alltid er trygge.
///
/// [`Pin`][Pin]-typen brukes i stedet for å forhindre bevegelser gjennom typesystemet.Pekere `P<T>` innpakket i [`Pin<P<T>>`][Pin]-innpakningen kan ikke flyttes ut.
/// Se [`pin` module]-dokumentasjonen for mer informasjon om festing.
///
/// Implementering av `Unpin` trait for `T` løfter begrensningene for å feste av typen, som deretter tillater å flytte `T` ut av [`Pin<P<T>>`][Pin] med funksjoner som [`mem::replace`].
///
///
/// `Unpin` har ingen konsekvens i det hele tatt for ikke-festede data.
/// Spesielt flytter [`mem::replace`] gjerne `!Unpin`-data (det fungerer for alle `&mut T`, ikke bare når `T: Unpin`).
/// Du kan imidlertid ikke bruke [`mem::replace`] på data pakket inn i en [`Pin<P<T>>`][Pin] fordi du ikke kan få den `&mut T` du trenger for det, og *det* er det som får dette systemet til å fungere.
///
/// Så dette kan for eksempel bare gjøres på typer som implementerer `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Vi trenger en foranderlig referanse for å ringe `mem::replace`.
/// // Vi kan få en slik referanse ved (implicitly) å påkalle `Pin::deref_mut`, men det er bare mulig fordi `String` implementerer `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Denne trait implementeres automatisk for nesten alle typer.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// En merketype som ikke implementerer `Unpin`.
///
/// Hvis en type inneholder en `PhantomPinned`, vil den ikke implementere `Unpin` som standard.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementeringer av `Copy` for primitive typer.
///
/// Implementeringer som ikke kan beskrives i Rust implementeres i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Delte referanser kan kopieres, men mutable referanser *kan ikke*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}