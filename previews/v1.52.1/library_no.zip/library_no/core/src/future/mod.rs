#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynkrone verdier.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Denne typen er nødvendig fordi:
///
/// a) Generatorer kan ikke implementere `for<'a, 'b> Generator<&'a mut Context<'b>>`, så vi må sende en rå peker (se <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Rå pekere og `NonNull` er ikke `Send` eller `Sync`, så det vil gjøre hver eneste future non-Send/Sync også, og vi vil ikke ha det.
///
/// Det forenkler også HIR-senking av `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Pakk en generator i en future.
///
/// Denne funksjonen returnerer en `GenFuture` under, men skjuler den i `impl Trait` for å gi bedre feilmeldinger (`impl Future` i stedet for `GenFuture<[closure.....]>`).
///
// Dette er `const` for å unngå ekstra feil etter at vi gjenoppretter fra `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Vi stoler på det faktum at async/await futures er ubevegelige for å skape selvreferanselån i den underliggende generatoren.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SIKKERHET: Trygt fordi vi er !Unpin + !Drop, og dette er bare en feltprojeksjon.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Gjenoppta generatoren, og gjør `&mut Context` til en råpeker `NonNull`.
            // `.await` senking vil trygt kaste den tilbake til en `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SIKKERHET: innringeren må garantere at `cx.0` er en gyldig peker
    // som oppfyller alle kravene for en mutbar referanse.
    unsafe { &mut *cx.0.as_ptr().cast() }
}