#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// En future representerer en asynkron beregning.
///
/// En future er en verdi som kanskje ikke er ferdig med databehandlingen ennå.
/// Denne typen "asynchronous value" gjør det mulig for en tråd å fortsette å gjøre nyttig arbeid mens den venter på at verdien skal bli tilgjengelig.
///
///
/// # `poll`-metoden
///
/// Kjernemetoden til future, `poll`,*forsøker* å løse future til en endelig verdi.
/// Denne metoden blokkerer ikke hvis verdien ikke er klar.
/// I stedet er den nåværende oppgaven planlagt å bli vekket når det er mulig å gjøre ytterligere fremgang ved å `avstemme` igjen.
/// `context` sendt til `poll`-metoden kan gi en [`Waker`], som er et håndtak for å vekke opp gjeldende oppgave.
///
/// Når du bruker en future, vil du vanligvis ikke ringe `poll` direkte, men i stedet `.await` verdien.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Verditypen produsert ved ferdigstillelse.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Forsøk å løse future til en endelig verdi, og registrer den gjeldende oppgaven for oppvåkning hvis verdien ennå ikke er tilgjengelig.
    ///
    /// # Returverdi
    ///
    /// Denne funksjonen returnerer:
    ///
    /// - [`Poll::Pending`] hvis future ikke er klar ennå
    /// - [`Poll::Ready(val)`] med resultatet `val` av denne future hvis den ble fullført.
    ///
    /// Når en future er ferdig, bør klienter ikke `poll` den igjen.
    ///
    /// Når en future ikke er klar ennå, returnerer `poll` `Poll::Pending` og lagrer en klon av [`Waker`] kopiert fra gjeldende [`Context`].
    /// Denne [`Waker`] blir deretter vekket når future kan gjøre fremskritt.
    /// For eksempel vil en future som venter på at en stikkontakt blir lesbar, ringe `.clone()` på [`Waker`] og lagre den.
    /// Når et signal ankommer et annet sted som indikerer at kontakten er lesbar, blir [`Waker::wake`] kalt og kontakten future s oppgave blir vekket.
    /// Når en oppgave er vekket, bør den prøve å `poll` future igjen, noe som kanskje eller ikke gir en endelig verdi.
    ///
    /// Merk at ved flere samtaler til `poll`, er det bare [`Waker`] fra [`Context`] som er sendt til den siste samtalen, som skal planlegges for å motta en oppvåkning.
    ///
    /// # Kjøretidsegenskaper
    ///
    /// Futures alene er *inerte*;de må være *aktivt*`avstemt` for å gjøre fremgang, noe som betyr at hver gang den gjeldende oppgaven blir vekket, bør den aktivt re-polle i påvente av futures som den fremdeles har interesse av.
    ///
    /// `poll`-funksjonen kalles ikke gjentatte ganger i en tett løkke-i stedet bør den bare kalles når future indikerer at den er klar til å gjøre fremgang (ved å ringe `wake()`).
    /// Hvis du er kjent med `poll(2)`-eller `select(2)`-syskallene på Unix, er det verdt å merke seg at futures vanligvis *ikke* lider de samme problemene som "all wakeups must poll all events";de er mer som `epoll(4)`.
    ///
    /// En implementering av `poll` bør forsøke å komme tilbake raskt, og bør ikke blokkere.Å returnere raskt forhindrer unødvendig tilstopping av tråder eller hendelsessløyfe.
    /// Hvis det er kjent på forhånd at en samtale til `poll` kan ende opp med å ta en stund, bør arbeidet lastes ned til et trådbasseng (eller noe lignende) for å sikre at `poll` kan komme tilbake raskt.
    ///
    /// # Panics
    ///
    /// Når en future er fullført (returnerte `Ready` fra `poll`), kan det å ringe `poll`-metoden igjen panic, blokkere for alltid eller forårsake andre typer problemer;`Future` trait stiller ingen krav til effekten av en slik samtale.
    /// Da `poll`-metoden ikke er merket `unsafe`, gjelder imidlertid Rust s vanlige regler: samtaler må aldri forårsake udefinert oppførsel (minnekorrupsjon, feil bruk av `unsafe`-funksjoner eller lignende), uavhengig av tilstanden til future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}