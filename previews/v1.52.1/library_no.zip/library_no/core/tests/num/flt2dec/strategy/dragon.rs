use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri er for treg
fn exact_sanity_test() {
    // Denne testen ender med å kjøre det jeg bare kan anta er et hjørne-tilfelle av `exp2`-biblioteksfunksjonen, definert i uansett C-kjøretid vi bruker.
    // I VS 2013 hadde denne funksjonen tilsynelatende en feil da denne testen mislyktes når den ble koblet, men med VS 2015 virker feilen løst da testen går helt fint.
    //
    // Feilen ser ut til å være en forskjell i returverdien på `exp2(-1057)`, hvor den i VS 2013 returnerer en dobbel med bitmønsteret 0x2 og i VS 2015 returnerer den 0x20000.
    //
    //
    // For nå er det bare å ignorere denne testen helt på MSVC, da den uansett er testet andre steder, og vi er ikke veldig interessert i å teste hver plattforms exp2-implementering.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}