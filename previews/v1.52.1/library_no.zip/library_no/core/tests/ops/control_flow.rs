use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Dette er ikke stabilt overflate, men hjelper med å holde `?` billig mellom dem, selv om LLVM ikke alltid kan dra nytte av det akkurat nå.
    //
    // (Dessverre er resultat og alternativ inkonsekvente, så ControlFlow kan ikke matche begge deler.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}