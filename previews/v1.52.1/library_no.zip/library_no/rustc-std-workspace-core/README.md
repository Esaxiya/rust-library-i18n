# `rustc-std-workspace-core` crate

Denne crate er en blank og tom crate som ganske enkelt avhenger av `libcore` og eksporterer alt innholdet på nytt.
crate er kjernen i å gi standardbiblioteket mulighet til å være avhengig av crates fra crates.io

Crates på crates.io som standardbiblioteket er avhengig av, må avhenge av `rustc-std-workspace-core` crate fra crates.io, som er tomt.

Vi bruker `[patch]` for å overstyre den til denne crate i dette depotet.
Som et resultat vil crates på crates.io trekke en avhengighet edge til `libcore`, den versjonen som er definert i dette depotet.
Det bør trekke alle avhengighetskanter for å sikre at Cargo bygger crates vellykket!

Merk at crates på crates.io må være avhengig av denne crate med navnet `core` for at alt skal fungere riktig.For å gjøre det kan de bruke:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Gjennom bruk av `package`-tasten blir crate omdøpt til `core`, noe som betyr at det vil se ut som

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

når Cargo påkaller kompilatoren og tilfredsstiller det implisitte `extern crate core`-direktivet som er injisert av kompilatoren.




