#![feature(no_core)]
#![no_core]

// Pogledajte zašto je potreban ovaj crate, pogledajte rustc-std-workspace-core.

// Preimenujte crate kako biste izbjegli sukob s aloc modulom u liballoc.
extern crate alloc as foo;

pub use foo::*;