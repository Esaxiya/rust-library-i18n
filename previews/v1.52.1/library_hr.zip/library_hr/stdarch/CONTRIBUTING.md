# Doprinosi stdarchu

`stdarch` crate je više nego spreman prihvatiti doprinose!Prvo ćete vjerojatno htjeti provjeriti spremište i provjeriti da li testovi prolaze umjesto vas:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Gdje je `<your-target-arch>` ciljna trojka kako je koristi `rustup`, npr. `x86_x64-unknown-linux-gnu` (bez prethodnih `nightly-` ili slično).
Također imajte na umu da ovo spremište zahtijeva noćni kanal Rust!
Gore navedeni testovi zapravo zahtijevaju da rust bude noćni zadani zadani postav u vašem sustavu za postavljanje koji koriste `rustup default nightly` (i `rustup default stable` za vraćanje).

Ako bilo koji od gore navedenih koraka ne uspije, [please let us know][new]!

Dalje možete pomoći [find an issue][issues], odabrali smo nekoliko s oznakama [`help wanted`][help] i [`impl-period`][impl] koje bi mogle posebno koristiti neku pomoć. 
Možda će vas najviše zanimati [#40][vendor], koji implementira sve značajke dobavljača na x86.Taj broj ima nekoliko dobrih uputa o tome odakle započeti!

Ako imate općenita pitanja, slobodno se obratite [join us on gitter][gitter] i raspitajte se!Slobodno pitajte ili@BurntSushi ili@alexcrichton s pitanjima.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Kako napisati primjere za stdarch intrinsics

Postoji nekoliko značajki koje moraju biti omogućene da bi dani suštinski ispravno radili, a primjer mora pokrenuti `cargo test --doc` samo kada značajku podržava CPU.

Kao rezultat, zadani `fn main` koji generira `rustdoc` neće raditi (u većini slučajeva).
Razmislite o korištenju sljedećeg kao vodiča kako biste osigurali da vaš primjer radi kako se očekuje.

```rust
/// # // Treba nam cfg_target_feature da osiguramo da je primjer samo
/// # // pokreće `cargo test --doc` kada CPU podržava tu značajku
/// # #![feature(cfg_target_feature)]
/// # // Treba nam target_feature da bi intrinzično funkcioniralo
/// # #![feature(target_feature)]
/// #
/// # // rustdoc prema zadanim postavkama koristi `extern crate stdarch`, ali trebamo
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Prava glavna funkcija
/// # fn main() {
/// #     // Pokrenite ovo samo ako je podržan `<target feature>`
/// #     ako je cfg_feature_enabled! ("<target feature>"){
/// #         // Stvorite `worker` funkciju koja će se pokretati samo ako je ciljana značajka
/// #         // je podržan i osigurajte da je za vašeg radnika omogućen `target_feature`
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         nesigurno fn worker() {
/// // Napišite svoj primjer ovdje.Ovdje će funkcionirati značajke specifične za značajke!Poludi!
///
/// #         }
///
/// #         nesigurni { worker(); }
/// #     }
/// # }
```

Ako neka od gornjih sintaksa ne izgleda poznato, [Documentation as tests] odjeljak [Rust Book] prilično dobro opisuje sintaksu `rustdoc`.
Kao i uvijek, budite slobodni za [join us on gitter][gitter] i pitajte nas ako ste udarili bilo kakav zahvat i hvala vam što ste pomogli poboljšati dokumentaciju o `stdarch`!

# Alternativne upute za ispitivanje

Općenito se preporučuje da za pokretanje testova koristite `ci/run.sh`.
Međutim, ovo možda neće raditi za vas, npr. Ako ste na Windows.

U tom slučaju možete se vratiti na pokretanje `cargo +nightly test` i `cargo +nightly test --release -p core_arch` za testiranje generiranja koda.
Imajte na umu da za to treba instalirati noćni lanac alata kako bi `rustc` znao o vašoj ciljanoj trojki i njenom CPU-u.
Posebno trebate postaviti varijablu okruženja `TARGET` kao što biste to učinili za `ci/run.sh`.
Uz to trebate postaviti `RUSTCFLAGS` (trebate `C`) da naznači ciljne značajke, npr `RUSTCFLAGS="-C -target-features=+avx2"`.
Također možete postaviti `-C -target-cpu=native` ako se "just" razvija prema vašem trenutnom CPU-u.

Upozorite da kada koristite ove alternativne upute, npr. [things may go less smoothly than they would with `ci/run.sh`][ci-run-good]
testovi generiranja uputa mogu propasti jer ih je rastavljač drugačije imenovao, npr
može generirati `vaesenc` umjesto uputa `aesenc` unatoč tome što se ponašaju isto.
Također ove upute izvršavaju manje testova nego što bi se to uobičajeno radilo, zato nemojte se iznenaditi da će se kad na kraju povučete zahtjev pojaviti neke pogreške za testove koji ovdje nisu obrađeni.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






