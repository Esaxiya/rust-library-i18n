`core::arch` - Osnovne značajke arhitekture osnovne knjižnice Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modul `core::arch` implementira svojstva ovisna o arhitekturi (npr. SIMD).

# Usage 

`core::arch` dostupan je kao dio `libcore` i ponovno ga izvozi `libstd`.Radije ga koristite putem `core::arch` ili `std::arch` nego putem ovog crate.
Nestabilne značajke često su dostupne u noćnom Rust putem `feature(stdsimd)`.

Korištenje `core::arch` putem ovog crate zahtijeva noćni Rust i često se može (i može) slomiti.Jedini slučajevi u kojima biste trebali razmotriti upotrebu putem ovog crate su:

* ako trebate sami ponovno sastaviti `core::arch`, npr. s omogućenim određenim ciljnim značajkama koje nisu omogućene za `libcore`/`libstd`.
Note: ako ga trebate ponovno sastaviti za nestandardni cilj, radije upotrijebite `xargo` i ponovno sastavite `libcore`/`libstd` prema potrebi, umjesto da koristite ovaj crate.
  
* koristeći neke značajke koje možda neće biti dostupne čak i iza nestabilnih Rust značajki.Pokušavamo ih svesti na najmanju moguću mjeru.
Ako trebate koristiti neke od ovih značajki, otvorite izdanje kako bismo ih mogli izložiti u noćnom Rust, a vi ih odatle možete koristiti.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` primarno se distribuira pod uvjetima MIT licence i Apache licence (verzija 2.0), s dijelovima pokrivenim raznim BSD-sličnim licencama.

Pogledajte LICENSE-APACHE i LICENSE-MIT za detalje.

# Contribution

Ako izričito ne navedete drugačije, bilo koji doprinos koji ste namjerno poslali na uvrštavanje u `core_arch`, kako je definirano u licenci Apache-2.0, bit će dvostruko licenciran kao gore, bez ikakvih dodatnih uvjeta ili odredbi.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












