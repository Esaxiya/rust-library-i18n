use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Koristi se kako bi našim `#[assert_instr]` napomenama rekli da su svi simd sadržaji dostupni za testiranje njihovog kodegena, jer su neki postavljeni iza dodatnog `-Ctarget-feature=+unimplemented-simd128` koji trenutno nema nikakav ekvivalent u `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}