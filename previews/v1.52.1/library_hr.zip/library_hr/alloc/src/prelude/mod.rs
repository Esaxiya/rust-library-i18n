//! Alok Prelude
//!
//! Svrha ovog modula je ublažiti uvoz najčešće korištenih predmeta `alloc` crate dodavanjem glob uvoza na vrh modula:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;