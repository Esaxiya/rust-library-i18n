#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipovi i Traits za rad s asinkronim zadacima.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Provedba buđenja zadatka na izvršitelju.
///
/// Ovaj Portrait može se koristiti za stvaranje [`Waker`].
/// Izvršitelj može definirati provedbu ovog Portrait i pomoću njega konstruirati Waker za prelazak na zadatke koji se izvršavaju na tom izvršitelju.
///
/// Ovaj Portrait memorijski je sigurna i ergonomska alternativa konstrukciji [`RawWaker`].
/// Podržava uobičajeni dizajn izvršitelja u kojem se podaci koji se koriste za buđenje zadatka pohranjuju u [`Arc`].
/// Neki izvršitelji (posebno oni za ugrađene sustave) ne mogu koristiti ovaj API, zbog čega [`RawWaker`] postoji kao alternativa tim sustavima.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Osnovna `block_on` funkcija koja uzima future i izvodi ga do završetka na trenutnoj niti.
///
/// **Note:** Ovaj primjer trguje ispravnošću radi jednostavnosti.
/// Da bi se spriječile mrtve točke, implementacije proizvodne klase također će trebati obraditi posredne pozive na `thread::unpark` kao i ugniježđene pozive.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker koji budi trenutnu nit kad je pozvan.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Pokrenite future do kraja na trenutnoj niti.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Prikvačite future kako bi mogao biti anketiran.
///     let mut fut = Box::pin(fut);
///
///     // Stvorite novi kontekst koji će se proslijediti future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Pokrenite future do kraja.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Probudi ovaj zadatak.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Probudite ovaj zadatak bez trošenja wakera.
    ///
    /// Ako izvršitelj podržava jeftiniji način buđenja bez trošenja wakera, trebao bi nadjačati ovu metodu.
    /// Prema zadanim postavkama klonira [`Arc`] i poziva klon [`wake`] na klonu.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SIGURNOST: Ovo je sigurno jer raw_waker sigurno konstruira
        // RawWaker iz Arca<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ova privatna funkcija za izgradnju RawWaker-a koristi se umjesto
// ugrađujući to u `From<Arc<W>> for RawWaker` impl, kako bi se osiguralo da sigurnost `From<Arc<W>> for Waker` ne ovisi o ispravnoj Portrait otpremnici, umjesto toga oba impl-a pozivaju ovu funkciju izravno i eksplicitno.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Povećajte referentni broj luka da biste ga klonirali.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Buđenje po vrijednosti, premještanje luka u funkciju Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Probudite se po referenci, zamotajte waker u ManuallyDrop kako biste izbjegli ispuštanje
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Smanjite referentni broj luka pri padu
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}