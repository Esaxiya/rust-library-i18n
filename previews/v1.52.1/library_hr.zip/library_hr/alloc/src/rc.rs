//! Pokazivači za brojanje referenci s jednim navojem.'Rc' je kratica za 'Referenca'
//! Counted'.
//!
//! Tip [`Rc<T>`][`Rc`] pruža zajedničko vlasništvo nad vrijednošću tipa `T`, dodijeljenom u hrpi.
//! Pozivanje [`clone`][clone] na [`Rc`] stvara novi pokazivač na istu dodjelu u hrpi.
//! Kada se uništi posljednji [`Rc`] pokazivač na datu dodjelu, vrijednost pohranjena u toj dodjeli (koja se često naziva "inner value") također se ispušta.
//!
//! Dijeljene reference u Rust prema zadanim postavkama onemogućuju mutaciju, a [`Rc`] nije iznimka: općenito ne možete dobiti promjenjivu referencu na nešto unutar [`Rc`].
//! Ako trebate promjenjivost, stavite [`Cell`] ili [`RefCell`] unutar [`Rc`];vidi [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] koristi neatomsko brojanje referenci.
//! To znači da su režijski troškovi vrlo niski, ali [`Rc`] se ne može poslati između niti, pa stoga [`Rc`] ne implementira [`Send`][send].
//! Kao rezultat toga, kompajler Rust provjerit će *u vrijeme sastavljanja* da ne šaljete [`Rc`] s između niti.
//! Ako trebate brojanje atomskih referenci s više niti, upotrijebite [`sync::Arc`][arc].
//!
//! Metoda [`downgrade`][downgrade] može se koristiti za stvaranje neovlaštenog pokazivača [`Weak`].
//! Pokazivač [`Weak`] može se [`nadograditi '][nadograditi] d na [`Rc`], ali to će vratiti [`None`] ako je vrijednost pohranjena u dodjeli već ispuštena.
//! Drugim riječima, pokazivači `Weak` ne održavaju vrijednost unutar alokacije živom;međutim, oni *održavaju* alokaciju (skladište za unutarnju vrijednost) na životu.
//!
//! Ciklus između pokazivača [`Rc`] nikada se neće ukloniti.
//! Iz tog se razloga [`Weak`] koristi za razbijanje ciklusa.
//! Na primjer, stablo može imati snažne pokazivače [`Rc`] od roditeljskih čvorova do djece, a [`Weak`] pokazivače od djece natrag do roditelja.
//!
//! `Rc<T>` automatski preusmjerava na `T` (putem [`Deref`] Portrait), tako da možete nazvati `T` metode na vrijednosti tipa [`Rc<T>`][`Rc`].
//! Da bi se izbjegle kolizije imena s metodama `T`, metode [`Rc<T>`][`Rc`] same su pridružene funkcije, pozvane pomoću [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Implementacije traits poput `Clone` također se mogu pozvati koristeći potpuno kvalificiranu sintaksu.
//! Neki radije koriste potpuno kvalificiranu sintaksu, dok drugi više vole sintaksu metoda-poziva.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaksa poziva-metode
//! let rc2 = rc.clone();
//! // Potpuno kvalificirana sintaksa
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ne automatski preusmjerava na `T`, jer je unutarnja vrijednost možda već ispuštena.
//!
//! # Referencije o kloniranju
//!
//! Stvaranje nove reference na istu dodjelu kao i postojeći pokazivač s brojenim referencama vrši se pomoću `Clone` Portrait implementiranog za [`Rc<T>`][`Rc`] i [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Dvije sintakse u nastavku su ekvivalentne.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a i b oba pokazuju na isto mjesto memorije kao foo.
//! ```
//!
//! Sintaksa `Rc::clone(&from)` je najizrazitija jer eksplicitnije prenosi značenje koda.
//! U gornjem primjeru, ova sintaksa olakšava uočavanje da ovaj kôd stvara novu referencu, a ne kopira cijeli sadržaj foo-a.
//!
//! # Examples
//!
//! Razmotrimo scenarij u kojem je skup `Gadgeta` u vlasništvu određenog `Owner`.
//! Želimo da naša naprava bude usmjerena na njihov `Owner`.To ne možemo učiniti s jedinstvenim vlasništvom, jer više gadgeta može pripadati istom `Owner`.
//! [`Rc`] omogućuje nam da dijelimo `Owner` između više `gadgeta` i da `Owner` ostane dodijeljen sve dok bilo koji `Gadget` usmjerava na njega.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... druga polja
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... druga polja
//! }
//!
//! fn main() {
//!     // Stvorite `Owner` s brojem referenci.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Stvorite `Gadget` koji pripadaju `gadget_owner`.
//!     // Kloniranje `Rc<Owner>` daje nam novi pokazivač na isto dodjeljivanje `Owner`, povećavajući broj referenci u procesu.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Odložite našu lokalnu varijablu `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Unatoč odustajanju od `gadget_owner`, još uvijek možemo ispisati ime `Owner` iz `Gadgeta`.
//!     // To je zato što smo ispustili samo jedan `Rc<Owner>`, a ne `Owner` na koji upućuje.
//!     // Sve dok postoji i drugi `Rc<Owner>` koji upućuje na istu dodjelu `Owner`, on će ostati aktivan.
//!     // Projekcija polja `gadget1.owner.name` funkcionira jer se `Rc<Owner>` automatski preusmjerava na `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Na kraju funkcije, `gadget1` i `gadget2` su uništeni, a s njima i posljednje prebrojane reference na naš `Owner`.
//!     // Gadget Man sada također postaje uništen.
//!     //
//! }
//! ```
//!
//! Ako se naši zahtjevi promijene, a također trebamo biti u mogućnosti prijeći se s `Owner` na `Gadget`, naići ćemo na probleme.
//! Pokazivač [`Rc`] od `Owner` do `Gadget` uvodi ciklus.
//! To znači da njihov referentni broj nikada ne može doseći 0, a dodjela nikada neće biti uništena:
//! curenje sjećanja.Da bismo to zaobišli, možemo koristiti pokazivače [`Weak`].
//!
//! Rust zapravo donekle otežava stvaranje ove petlje.Da bi na kraju dobili dvije vrijednosti koje upućuju jedna na drugu, jedna od njih mora biti promjenjiva.
//! To je teško jer [`Rc`] provodi sigurnost memorije davanjem samo zajedničkih referenci na vrijednost koju obavija, a one ne dopuštaju izravnu mutaciju.
//! Moramo umotati dio vrijednosti koji želimo mutirati u [`RefCell`], koji pruža *unutarnju promjenjivost*: metodu za postizanje promjenjivosti putem zajedničke reference.
//! [`RefCell`] provodi pravila posudbe Rust tijekom izvođenja.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... druga polja
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... druga polja
//! }
//!
//! fn main() {
//!     // Stvorite `Owner` s brojem referenci.
//!     // Imajte na umu da smo stavili `Owner` vector`Gadgeta` unutar `RefCell` tako da ga možemo mutirati putem zajedničke reference.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Stvorite `gadgete` koji pripadaju `gadget_owner`, kao i prije.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Dodajte `Gadgete` njihovim `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ovdje se završava dinamično posuđivanje.
//!     }
//!
//!     // Ponavljajte naše `Gadgete` ispisujući njihove detalje.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` je `Weak<Gadget>`.
//!         // Budući da pokazivači `Weak` ne mogu jamčiti da dodjela još uvijek postoji, moramo nazvati `upgrade`, koji vraća `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // U ovom slučaju znamo da dodjela još uvijek postoji, tako da jednostavno `unwrap` `Option`.
//!         // U složenijem programu možda će vam trebati graciozno rješavanje pogrešaka za rezultat `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Na kraju funkcije uništavaju se `gadget_owner`, `gadget1` i `gadget2`.
//!     // Sada nema jakih pokazivača (`Rc`) na uređaje, pa su uništeni.
//!     // To poništava broj referenci na Gadget Manu, pa i on postaje uništen.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ovo je dokaz od repr(C) do future protiv mogućeg preuređivanja polja, što bi ometalo inače siguran [into|from]_raw() transmutabilnih unutarnjih tipova.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Pokazivač za brojanje referenci s jednim niti.'Rc' je kratica za 'Referenca'
/// Counted'.
///
/// Pogledajte [module-level documentation](./index.html) za više detalja.
///
/// Sve svojstvene metode `Rc` su sve pridružene funkcije, što znači da ih morate nazvati npr. [`Rc::get_mut(&mut value)`][get_mut] umjesto `value.get_mut()`.
/// Time se izbjegavaju sukobi s metodama unutarnjeg tipa `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ova nesigurnost je u redu jer dok je ovaj Rc živ garantiramo da je unutarnji pokazivač valjan.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konstruira novi `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Postoji implicitni slabi pokazivač u vlasništvu svih jakih pokazivača, koji osigurava da slabi destruktor nikada ne oslobađa alokaciju dok je jaki destruktor pokrenut, čak i ako je slabi pokazivač pohranjen unutar jakog.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konstruira novi `Rc<T>` koristeći slabu referencu na sebe.
    /// Pokušaj nadogradnje slabe reference prije nego što se ova funkcija vrati rezultirat će vrijednošću `None`.
    ///
    /// Međutim, slaba referenca može se slobodno klonirati i pohraniti za kasnije korištenje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... još polja
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Konstruirajte unutrašnjost u stanju "uninitialized" s jednom slabom referencom.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Važno je da se ne odričemo vlasništva nad slabim pokazivačem, inače bi memorija mogla biti oslobođena dok se `data_fn` vrati.
        // Ako bismo stvarno htjeli prenijeti vlasništvo, mogli bismo stvoriti dodatni slabi pokazivač za sebe, ali to bi rezultiralo dodatnim ažuriranjima broja slabih referenci koja inače ne bi bila potrebna.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Jake reference trebale bi zajednički posjedovati zajedničku slabu referencu, zato nemojte pokretati destruktor za našu staru slabu referencu.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruira novi `Rc` s neinicijaliziranim sadržajem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruira novi `Rc` s neinicijaliziranim sadržajem, s memorijom koja je napunjena bajtovima `0`.
    ///
    ///
    /// Pogledajte [`MaybeUninit::zeroed`][zeroed] za primjere ispravne i netočne uporabe ove metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruira novi `Rc<T>`, vraća grešku ako dodjela ne uspije
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Postoji implicitni slabi pokazivač u vlasništvu svih jakih pokazivača, koji osigurava da slabi destruktor nikada ne oslobađa alokaciju dok je jaki destruktor pokrenut, čak i ako je slabi pokazivač pohranjen unutar jakog.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Konstruira novi `Rc` s neinicijaliziranim sadržajem, vraća pogrešku ako dodjela ne uspije
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruira novi `Rc` s neinicijaliziranim sadržajem, s memorijom koja je napunjena bajtovima `0`, vraćajući pogrešku ako dodjela ne uspije
    ///
    ///
    /// Pogledajte [`MaybeUninit::zeroed`][zeroed] za primjere ispravne i netočne uporabe ove metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konstruira novi `Pin<Rc<T>>`.
    /// Ako `T` ne implementira `Unpin`, tada će `value` biti pričvršćen u memoriju i ne može se premjestiti.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Vraća unutarnju vrijednost ako `Rc` ima točno jednu snažnu referencu.
    ///
    /// Inače, vraća se [`Err`] s istim `Rc` koji je proslijeđen.
    ///
    ///
    /// To će uspjeti čak i ako postoje izvanredne slabe reference.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopirajte sadržani objekt

                // Uputi Slaksima da ih ne može promovirati smanjenjem jakog broja, a zatim ukloni implicitni pokazivač "strong weak", a istovremeno rukuje logikom ispuštanja samo izradom lažnog Slabaša.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Konstruira novi presjek s brojem referenci s neinicijaliziranim sadržajem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Konstruira novu kriško brojenu referencu s neinicijaliziranim sadržajem, s memorijom koja je napunjena bajtovima `0`.
    ///
    ///
    /// Pogledajte [`MaybeUninit::zeroed`][zeroed] za primjere ispravne i netočne uporabe ove metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Pretvara u `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Kao i kod [`MaybeUninit::assume_init`], na pozivatelju je da osigura da je unutarnja vrijednost stvarno u inicijaliziranom stanju.
    ///
    /// To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje trenutno nedefinirano ponašanje.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Pretvara u `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Kao i kod [`MaybeUninit::assume_init`], na pozivatelju je da osigura da je unutarnja vrijednost stvarno u inicijaliziranom stanju.
    ///
    /// To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje trenutno nedefinirano ponašanje.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Konzumira `Rc` vraćajući zamotani pokazivač.
    ///
    /// Da bi se izbjeglo curenje memorije, pokazivač se mora pretvoriti natrag u `Rc` pomoću [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Pruža neobrađeni pokazivač na podatke.
    ///
    /// Na brojanje to ne utječe ni na koji način i `Rc` se ne troši.
    /// Pokazivač vrijedi sve dok u `Rc` postoje jaka računanja.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SIGURNOST: Ovo ne može proći Deref::deref ili Rc::inner jer
        // to je potrebno za zadržavanje raw/mut provenijencije tako da npr
        // `get_mut` može pisati kroz pokazivač nakon što se Rc oporavi kroz `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Konstruira `Rc<T>` iz sirovog pokazivača.
    ///
    /// Neobrađeni pokazivač mora biti prethodno vraćen pozivom na [`Rc<U>::into_raw`][into_raw] gdje `U` mora imati istu veličinu i poravnanje kao `T`.
    /// To je trivijalno točno ako je `U` `T`.
    /// Imajte na umu da ako `U` nije `T`, ali ima istu veličinu i poravnanje, to je u osnovi poput pretvaranja referenci različitih vrsta.
    /// Pogledajte [`mem::transmute`][transmute] za više informacija o tome koja se ograničenja primjenjuju u ovom slučaju.
    ///
    /// Korisnik `from_raw` mora osigurati da određena vrijednost `T` padne samo jednom.
    ///
    /// Ova funkcija nije sigurna jer nepravilna uporaba može dovesti do nesigurnosti memorije, čak i ako se vraćenom `Rc<T>` nikad ne pristupi.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Vratite se na `Rc` kako biste spriječili curenje.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Daljnji pozivi na `Rc::from_raw(x_ptr)` bili bi nesigurni u memoriji.
    /// }
    ///
    /// // Sjećanje se oslobodilo kad je `x` izašao iz gornjeg opsega, pa `x_ptr` sada visi!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Preokrenite pomak da biste pronašli izvorni RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Stvara novi [`Weak`] pokazivač na ovu dodjelu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Pazite da ne stvorimo viseći Slabi
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Dobiva broj [`Weak`] pokazivača na ovu dodjelu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Dobiva broj snažnih (`Rc`) pokazivača na ovu dodjelu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Vraća `true` ako nema drugih pokazivača `Rc` ili [`Weak`] na ovu dodjelu.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Vraća promjenjivu referencu u zadani `Rc`, ako nema drugih pokazivača `Rc` ili [`Weak`] na istu dodjelu.
    ///
    ///
    /// U suprotnom vraća [`None`], jer nije sigurno mutirati zajedničku vrijednost.
    ///
    /// Vidi također [`make_mut`][make_mut], koji će [`clone`][clone] dobiti unutarnju vrijednost kada postoje drugi pokazivači.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Vraća promjenjivu referencu u zadani `Rc`, bez ikakve provjere.
    ///
    /// Pogledajte također [`get_mut`], koji je siguran i vrši odgovarajuće provjere.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Bilo koji drugi pokazivač `Rc` ili [`Weak`] na istu dodjelu ne smije se dereferencirati za vrijeme vraćenog posudbe.
    ///
    /// To je trivijalan slučaj ako takvi pokazivači ne postoje, na primjer odmah nakon `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Pazimo da *ne* stvorimo referencu koja pokriva polja "count", jer bi to bilo u sukobu s pristupima brojevima referenci (npr.
        // do `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Vraća `true` ako dva `Rc`-a upućuju na istu dodjelu (u veni sličnoj [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Daje promjenjivu referencu na zadani `Rc`.
    ///
    /// Ako postoje drugi `Rc` pokazivači na istu dodjelu, tada će `make_mut` [`clone`] unijeti unutarnju vrijednost na novu dodjelu kako bi se osiguralo jedinstveno vlasništvo.
    /// To se također naziva klonom-na-pisanje.
    ///
    /// Ako nema drugih pokazivača `Rc` za ovu dodjelu, tada će se razdvojiti pokazivači [`Weak`] za ovu dodjelu.
    ///
    /// Vidi također [`get_mut`], koji će propasti umjesto kloniranja.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Neće klonirati ništa
    /// let mut other_data = Rc::clone(&data);    // Neće klonirati unutarnje podatke
    /// *Rc::make_mut(&mut data) += 1;        // Klonira unutarnje podatke
    /// *Rc::make_mut(&mut data) += 1;        // Neće klonirati ništa
    /// *Rc::make_mut(&mut other_data) *= 2;  // Neće klonirati ništa
    ///
    /// // Sada `data` i `other_data` upućuju na različita izdvajanja.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] pokazivači će biti razdvojeni:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Moram klonirati podatke, postoje i drugi Rcs.
            // Unaprijed dodijelite memoriju kako biste omogućili izravno pisanje klonirane vrijednosti.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Možete samo ukrasti podatke, preostao je samo Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Uklonite implicitni jak-slabi ref (ovdje ne treba stvarati lažni Slabi-znamo da nas drugi Slabi mogu očistiti)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ova nesigurnost je u redu jer smo zajamčeni da je vraćeni pokazivač *jedini* pokazivač koji će ikada biti vraćen na T.
        // U ovom trenutku zajamčeno je da je naš referentni broj 1, a tražili smo da sam `Rc<T>` bude `mut`, pa vraćamo jedinu moguću referencu na dodjelu.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Pokušaj `Rc<dyn Any>` spustiti na konkretnu vrstu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Dodjeljuje `RcBox<T>` s dovoljnim prostorom za možda neodmjerenu unutarnju vrijednost tamo gdje vrijednost ima predviđeni raspored.
    ///
    /// Funkcija `mem_to_rcbox` poziva se s pokazivačem podataka i mora vratiti (potencijalno masni) pokazivač za `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Izračunajte izgled koristeći zadani raspored vrijednosti.
        // Prije se raspored izračunavao na izrazu `&*(ptr as* const RcBox<T>)`, ali to je stvorilo pogrešno poravnanu referencu (vidi #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Dodjeljuje `RcBox<T>` s dovoljno prostora za potencijalno neodređenu unutarnju vrijednost gdje vrijednost ima predviđeni izgled, vraća pogrešku ako dodjela ne uspije.
    ///
    ///
    /// Funkcija `mem_to_rcbox` poziva se s pokazivačem podataka i mora vratiti (potencijalno masni) pokazivač za `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Izračunajte izgled koristeći zadani raspored vrijednosti.
        // Prije se raspored izračunavao na izrazu `&*(ptr as* const RcBox<T>)`, ali to je stvorilo pogrešno poravnanu referencu (vidi #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Dodijelite za izgled.
        let ptr = allocate(layout)?;

        // Inicijalizirajte RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Dodjeljuje `RcBox<T>` s dovoljno prostora za neodređenu unutarnju vrijednost
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Dodijelite za `RcBox<T>` koristeći zadanu vrijednost.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopiraj vrijednost u bajtovima
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Oslobodite alokaciju bez ispuštanja sadržaja
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Dodjeljuje `RcBox<[T]>` zadane duljine.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopirajte elemente iz kriške u novo dodijeljeni Rc <\[T\]>
    ///
    /// Nesigurno jer pozivatelj mora ili preuzeti vlasništvo ili povezati `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Konstruira `Rc<[T]>` iz iteratora za koji se zna da je određene veličine.
    ///
    /// Ponašanje je nedefinirano ako je veličina pogrešna.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic štitnik dok klonira T elemente.
        // U slučaju panic, elementi koji su zapisani u novi RcBox bit će ispušteni, a zatim oslobođena memorija.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pokazivač na prvi element
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Sve jasno.Zaboravite čuvara kako ne bi oslobodio novi RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specijalizacija Portrait korištena za `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Ispušta `Rc`.
    ///
    /// To će smanjiti snažni broj referenci.
    /// Ako broj snažnih referenci dosegne nulu, tada su jedine druge reference (ako postoje) [`Weak`], pa `drop` dobivamo unutarnju vrijednost.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ne ispisuje ništa
    /// drop(foo2);   // Ispisuje "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // uništiti sadržani objekt
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // uklonite implicitni pokazivač "strong weak" sada kada smo uništili sadržaj.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Izrađuje klon pokazivača `Rc`.
    ///
    /// To stvara još jedan pokazivač na istu dodjelu, povećavajući jaki broj referenci.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Stvara novi `Rc<T>`, s vrijednošću `Default` za `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack za omogućavanje specijalizacije za `Eq` iako `Eq` ima metodu.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ovu specijalizaciju radimo ovdje, a ne kao općenitu optimizaciju na `&T`, jer bi to inače dodalo trošak svim provjerama jednakosti na ref.
/// Pretpostavljamo da se `Rc` koriste za pohranu velikih vrijednosti, koje se sporo kloniraju, ali i teže provjeravaju jednakost, zbog čega se ovaj trošak lakše isplati.
///
/// Također je vjerojatnije da imaju dva `Rc` klona koja upućuju na istu vrijednost, nego dva `&T`-a.
///
/// To možemo učiniti samo kada `T: Eq` kao `PartialEq` može biti namjerno nefleksivan.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Jednakost za dva `Rc`-a.
    ///
    /// Dvije `Rc` su jednake ako su njihove unutarnje vrijednosti jednake, čak i ako su pohranjene u različitom rasporedu.
    ///
    /// Ako `T` također implementira `Eq` (što podrazumijeva refleksivnost jednakosti), dva `Rc-a koja ukazuju na istu raspodjelu uvijek su jednaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Nejednakost za dva `Rc`-a.
    ///
    /// Dvije `Rc` su nejednake ako su njihove unutarnje vrijednosti nejednake.
    ///
    /// Ako `T` također implementira `Eq` (što podrazumijeva refleksivnost jednakosti), dva `Rc` koja ukazuju na istu raspodjelu nikada nisu nejednaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Djelomična usporedba za dva `Rc`-a.
    ///
    /// Njih dvije uspoređuju se pozivanjem `partial_cmp()` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Manje od usporedbe za dva `Rc`-a.
    ///
    /// Njih dvije uspoređuju se pozivanjem `<` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Usporedba "Manje ili jednako" za dva "Rc-a".
    ///
    /// Njih dvije uspoređuju se pozivanjem `<=` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Veća usporedba za dva `Rc`-a.
    ///
    /// Njih dvije uspoređuju se pozivanjem `>` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Usporedba "Veća ili jednaka" za dva "Rc".
    ///
    /// Njih dvije uspoređuju se pozivanjem `>=` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Usporedba za dva `Rc`-a.
    ///
    /// Njih dvije uspoređuju se pozivanjem `cmp()` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Dodijelite referentno brojenu krišku i napunite je kloniranjem stavki `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Dodijelite referentno prebrojanu krišku niza i u nju kopirajte `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Dodijelite referentno prebrojanu krišku niza i u nju kopirajte `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Premjestite uokvireni objekt u novu, dodijeljenu, brojenu referencu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Dodijelite kriško brojenu referencu i u nju premjestite stavke `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Dopustite Vecu da oslobodi svoju memoriju, ali ne i uništi njegov sadržaj
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Uzima svaki element u `Iterator` i prikuplja ga u `Rc<[T]>`.
    ///
    /// # Karakteristike izvedbe
    ///
    /// ## Opći slučaj
    ///
    /// U pravilu se prikupljanje u `Rc<[T]>` vrši prvo sakupljanjem u `Vec<T>`.Odnosno, kada pišete sljedeće:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ovo se ponaša kao da smo napisali:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ovdje se događa prvi skup dodjela.
    ///     .into(); // Ovdje se događa druga dodjela za `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ovo će dodijeliti onoliko puta koliko je potrebno za konstrukciju `Vec<T>`, a zatim će dodijeliti jednom za pretvaranje `Vec<T>` u `Rc<[T]>`.
    ///
    ///
    /// ## Iteratori poznate duljine
    ///
    /// Kada vaš `Iterator` implementira `TrustedLen` i bude točne veličine, dodijelit će se jedno dodijeljivanje za `Rc<[T]>`.Na primjer:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Ovdje se događa samo jedna dodjela.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specijalizacija Portrait koja se koristi za prikupljanje u `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // To je slučaj za `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SIGURNOST: Moramo osigurati da iterator ima točnu duljinu kao i mi.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Vratite se normalnoj provedbi.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` je verzija [`Rc`] koja sadrži neposedujuću referencu na upravljanu dodjelu.Dodjeli se pristupa pozivom [`upgrade`] na pokazivaču `Weak`, koji vraća [`Option`]`<`[`Rc`] `<T>>`.
///
/// Budući da se referenca `Weak` ne računa u vlasništvo, neće spriječiti ispuštanje vrijednosti pohranjene u dodjeli, a sam `Weak` ne daje jamstva da je vrijednost još uvijek prisutna.
/// Stoga može vratiti [`None`] kada [`nadogradnja`] d.
/// Međutim, imajte na umu da referenca `Weak`*ne* sprječava oslobađanje same alokacije (spremišta).
///
/// Pokazivač `Weak` koristan je za zadržavanje privremene reference na dodjelu kojom upravlja [`Rc`], bez sprječavanja ispuštanja njegove unutarnje vrijednosti.
/// Također se koristi za sprečavanje kružnih referenci između pokazivača [`Rc`], jer međusobne reference posjedovanja nikada ne bi omogućile ispuštanje bilo kojeg [`Rc`].
/// Na primjer, stablo može imati snažne pokazivače [`Rc`] od roditeljskih čvorova do djece, a `Weak` pokazivače od djece natrag do roditelja.
///
/// Tipičan način dobivanja pokazivača `Weak` je pozivanje [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ovo je `NonNull` kako bi se omogućila optimizacija veličine ove vrste u enumima, ali to nije nužno valjani pokazivač.
    //
    // `Weak::new` postavlja ovo na `usize::MAX` tako da ne treba dodijeliti prostor na hrpi.
    // To nije vrijednost koju će pravi pokazivač ikada imati jer RcBox ima poravnanje najmanje 2.
    // To je moguće samo kada `T: Sized`;neodređeni `T` nikad se ne mota.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Konstruira novi `Weak<T>`, bez izdvajanja memorije.
    /// Pozivanje [`upgrade`] na povratnu vrijednost uvijek daje [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Vrsta pomoćnika za omogućavanje pristupa brojanju referenci bez davanja bilo kakvih tvrdnji o podatkovnom polju.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Vraća sirovi pokazivač na objekt `T` na koji ukazuje ovaj `Weak<T>`.
    ///
    /// Pokazivač vrijedi samo ako postoje neke jake reference.
    /// Pokazivač može biti viseći, nesaglašen ili čak [`null`] u suprotnom.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Oboje upućuju na isti objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Snažni ga ovdje održava na životu, tako da i dalje možemo pristupiti objektu.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ali ne više.
    /// // Možemo weak.as_ptr(), ali pristup pokazivaču vodio bi nedefiniranom ponašanju.
    /// // assert_eq! ("zdravo", nesigurno {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ako se pokazivač klati, vratit ćemo stražu izravno.
            // Ovo ne može biti valjana adresa korisnog tereta, jer je nosivost poravnata barem kao RcBox (usize).
            ptr as *const T
        } else {
            // SIGURNOST: ako is_dangling vrati false, tada se pokazivač ne može preusmjeriti.
            // Korisni teret u ovom trenutku može pasti, a mi moramo održavati provenijenciju, stoga koristite manipulaciju sirovim pokazivačem.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Konzumira `Weak<T>` i pretvara ga u neobrađeni pokazivač.
    ///
    /// To pretvara slabi pokazivač u neobrađeni pokazivač, a istovremeno zadržava vlasništvo nad jednom slabom referencom (ova operacija ne mijenja slabi broj).
    /// Može se vratiti natrag u `Weak<T>` s [`from_raw`].
    ///
    /// Primjenjuju se ista ograničenja pristupa cilju pokazivača kao i kod [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Pretvara sirovi pokazivač koji je prethodno stvorio [`into_raw`] natrag u `Weak<T>`.
    ///
    /// To se može koristiti za sigurno dobivanje jake reference (pozivanjem [`upgrade`] kasnije) ili za oslobađanje broja slabih ako ispustite `Weak<T>`.
    ///
    /// Potrebno je vlasništvo nad jednom slabom referencom (osim pokazivača kreiranih od [`new`], jer oni ne posjeduju ništa; metoda i dalje djeluje na njih).
    ///
    /// # Safety
    ///
    /// Pokazivač sigurno potječe iz [`into_raw`] i još uvijek mora posjedovati potencijalno slabu referencu.
    ///
    /// Dopušteno je da broj jakih brojeva bude 0 u trenutku poziva.
    /// Ipak, ovo preuzima vlasništvo nad jednom slabom referencom koja je trenutno predstavljena kao neobrađeni pokazivač (ova operacija ne mijenja slabi broj) i stoga mora biti uparena s prethodnim pozivom na [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Umanji posljednje slabo brojanje.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Pogledajte Weak::as_ptr za kontekst o tome kako je izveden ulazni pokazivač.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ovo je viseći Slab.
            ptr as *mut RcBox<T>
        } else {
            // U suprotnom, zajamčeno nam je da pokazivač dolazi od neupitnog Slabaša.
            // SIGURNOST: data_offset je sigurno nazvati, jer ptr upućuje na stvarni (potencijalno ispušteni) T.
            let offset = unsafe { data_offset(ptr) };
            // Dakle, preokrećemo pomak da bismo dobili cijeli RcBox.
            // SIGURNOST: pokazivač potječe iz slabosti, tako da je ovaj pomak siguran.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIGURNOST: sada smo obnovili izvorni slabi pokazivač, tako da možemo stvoriti slab.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Pokušaji nadogradnje pokazivača `Weak` na [`Rc`], odgađajući ispuštanje unutarnje vrijednosti ako je uspješno.
    ///
    ///
    /// Vraća [`None`] ako je unutarnja vrijednost u međuvremenu ispuštena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Uništite sve snažne pokazivače.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Dobiva broj snažnih pokazivača (`Rc`) koji upućuju na ovu dodjelu.
    ///
    /// Ako je `self` stvoren pomoću [`Weak::new`], vratit će se 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Dobiva broj `Weak` pokazivača koji upućuju na ovu dodjelu.
    ///
    /// Ako ne ostanu jaki pokazivači, to će vratiti nulu.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // oduzmi implicitni slabi ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Vraća `None` kada se pokazivač klati i nema dodijeljenog `RcBox` (tj. Kada je ovaj `Weak` stvorio `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Pazimo da *ne* stvorimo referencu koja pokriva polje "data", jer polje može istodobno biti mutirano (na primjer, ako se odustane od posljednjeg `Rc`, polje podataka bit će na mjestu).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Vraća `true` ako dva `Slaba` usmjeravaju na istu dodjelu (slično kao [`ptr::eq`]) ili ako oba ne upućuju na bilo koju dodjelu (jer su stvoreni s `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Budući da ovo uspoređuje pokazivače, to znači da će se `Weak::new()` međusobno izjednačiti, iako ne upućuju na bilo kakvu dodjelu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Uspoređujući `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Ispušta pokazivač `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ne ispisuje ništa
    /// drop(foo);        // Ispisuje "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // broj slabih započinje s 1, a ići će na nulu samo ako su nestali svi snažni pokazivači.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Izrađuje klon pokazivača `Weak` koji upućuje na istu dodjelu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruira novi `Weak<T>`, alocirajući memoriju za `T` bez inicijalizacije.
    /// Pozivanje [`upgrade`] na povratnu vrijednost uvijek daje [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Ovdje smo provjerili_dodali kako bismo sigurno riješili mem::forget.Posebno
// ako imate mem::forget Rcs (ili Slabi), brojanje ref-a može se preliti, a zatim možete osloboditi alokaciju dok postoje izvanredni Rcs (ili Slabi).
//
// Prekidamo jer je ovo toliko degeneriran scenarij da nas nije briga što će se dogoditi-niti jedan pravi program to nikada ne bi trebao doživjeti.
//
// Ovo bi trebalo imati zanemarive troškove, jer zapravo ne trebate toliko klonirati u Rust zahvaljujući vlasništvu i semantici premještanja.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Želimo prekinuti preljev umjesto da ispustimo vrijednost.
        // Kad se to pozove, referentni broj nikada neće biti nula;
        // unatoč tome, ovdje ubacujemo prekid kako bismo nagovijestili LLVM na inače propuštenu optimizaciju.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Želimo prekinuti preljev umjesto da ispustimo vrijednost.
        // Kad se to pozove, referentni broj nikada neće biti nula;
        // unatoč tome, ovdje ubacujemo prekid kako bismo nagovijestili LLVM na inače propuštenu optimizaciju.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Dobijte odmak unutar `RcBox` za nosivost iza pokazivača.
///
/// # Safety
///
/// Pokazivač mora ukazivati na (i imati valjane metapodatke za) prethodno važeću instancu T, ali T se smije ispustiti.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Poravnajte neodređenu vrijednost s krajem RcBox-a.
    // Budući da je RcBox repr(C), to će uvijek biti posljednje polje u memoriji.
    // SIGURNOST: budući da su jedini mogući neodređeni tipovi kriške, Portrait objekti,
    // i extern tipova, ulazni sigurnosni zahtjev trenutno je dovoljan da zadovolji zahtjeve align_of_val_raw;ovo je detalj provedbe jezika na koji se ne može pouzdati izvan std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}