#![stable(feature = "rust1", since = "1.0.0")]

//! Pokazivači za brojanje referenci sigurni u niti.
//!
//! Za više pojedinosti pogledajte dokumentaciju [`Arc<T>`][Arc].

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Meko ograničenje količine referenci na `Arc`.
///
/// Prelazak ovog ograničenja prekinut će vaš program (iako ne nužno) na referencama _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ne podržava memorijske ograde.
// Da biste izbjegli lažno pozitivna izvješća u implementaciji Arc/Weak, umjesto sinkronizacije koristite atomska opterećenja.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Pokazivač za brojanje referenci siguran u nit.'Arc' je skraćenica za "Atomically Reference Count".
///
/// Tip `Arc<T>` pruža zajedničko vlasništvo nad vrijednošću tipa `T`, dodijeljenom u hrpi.Pozivanje [`clone`][clone] na `Arc` stvara novu instancu `Arc`, koja ukazuje na istu dodjelu na hrpi kao izvor `Arc`, uz istovremeno povećanje broja referenci.
/// Kada se uništi posljednji `Arc` pokazivač na datu dodjelu, vrijednost pohranjena u toj dodjeli (koja se često naziva "inner value") također se ispušta.
///
/// Dijeljene reference u Rust prema zadanim postavkama onemogućuju mutaciju, a `Arc` nije iznimka: općenito ne možete dobiti promjenjivu referencu na nešto unutar `Arc`.Ako trebate mutirati putem `Arc`, upotrijebite [`Mutex`][mutex], [`RwLock`][rwlock] ili jednu od vrsta [`Atomic`][atomic].
///
/// ## Sigurnost navoja
///
/// Za razliku od [`Rc<T>`], `Arc<T>` koristi atomske operacije za svoje brojanje referenci.To znači da je zaštićen niti.Nedostatak je što su atomske operacije skuplje od uobičajenih pristupa memoriji.Ako ne dijelite raspodjelu brojenu referencama između niti, razmislite o upotrebi [`Rc<T>`] za niže troškove.
/// [`Rc<T>`] je sigurno zadano, jer će kompajler uhvatiti svaki pokušaj slanja [`Rc<T>`] između niti.
/// Međutim, knjižnica bi mogla odabrati `Arc<T>` kako bi korisnicima knjižnice pružila veću fleksibilnost.
///
/// `Arc<T>` implementirat će [`Send`] i [`Sync`] sve dok `T` implementira [`Send`] i [`Sync`].
/// Zašto ne možete staviti tip `T` koji nije siguran u nit u `Arc<T>` da bi bio siguran u nitima?Ovo je u početku možda pomalo kontra-intuitivno: na kraju krajeva, nije li poanta sigurnosti niti `Arc<T>`?Ključ je sljedeći: `Arc<T>` čini višestruko vlasništvo nad istim podacima višestrukim vlasništvom, ali svojim podacima ne dodaje sigurnost niti.
///
/// Razmotrite `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] nije [`Sync`], a ako je `Arc<T>` uvijek bio [`Send`], `Arc <` [`RefCell<T>`]`>`također bi bilo.
/// Ali tada bismo imali problem:
/// [`RefCell<T>`] nije zaštićen niti;prati broj posudbi koristeći neatomske operacije.
///
/// Na kraju, to znači da ćete možda trebati upariti `Arc<T>` s nekom vrstom [`std::sync`], obično [`Mutex<T>`][mutex].
///
/// ## Prekidni ciklusi s `Weak`
///
/// Metoda [`downgrade`][downgrade] može se koristiti za stvaranje pokazivača koji ne posjeduje [`Weak`].Pokazivač [`Weak`] može se [`nadograditi '][nadograditi] d na `Arc`, ali to će vratiti [`None`] ako je vrijednost pohranjena u dodjeli već ispuštena.
/// Drugim riječima, pokazivači `Weak` ne održavaju vrijednost unutar alokacije živom;međutim, oni *ne* održavaju alokaciju (sigurnosnu memoriju vrijednosti) živom.
///
/// Ciklus između pokazivača `Arc` nikada se neće ukloniti.
/// Iz tog se razloga [`Weak`] koristi za razbijanje ciklusa.Na primjer, stablo može imati snažne pokazivače `Arc` od roditeljskih čvorova do djece, a [`Weak`] pokazivače od djece natrag do roditelja.
///
/// # Referencije o kloniranju
///
/// Stvaranje nove reference iz postojećeg pokazivača s brojanjem referenci vrši se pomoću `Clone` Portrait implementiranog za [`Arc<T>`][Arc] i [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Dvije sintakse u nastavku su ekvivalentne.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b i foo su svi lukovi koji upućuju na isto memorijsko mjesto
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatski preusmjerava na `T` (putem [`Deref`][deref] Portrait), tako da možete pozvati `T` metode na vrijednosti tipa `Arc<T>`.Da bi se izbjegle kolizije imena s metodama `T`, metode samog `Arc<T>` su pridružene funkcije, pozvane pomoću [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Implementacije traits poput `Clone` također se mogu pozvati koristeći potpuno kvalificiranu sintaksu.
/// Neki radije koriste potpuno kvalificiranu sintaksu, dok drugi više vole sintaksu metoda-poziva.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaksa poziva-metode
/// let arc2 = arc.clone();
/// // Potpuno kvalificirana sintaksa
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ne automatski preusmjerava na `T`, jer je unutarnja vrijednost možda već ispuštena.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Dijeljenje nekih nepromjenjivih podataka između niti:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Imajte na umu da ovdje **ne izvršavamo** ove testove.
// Graditelji windows postaju super nesretni ako nit nadživi glavnu nit, a zatim istodobno izađe (nešto zastoj), pa to jednostavno izbjegavamo ne izvršavanjem ovih testova.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Dijeljenje promjenjivog [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Pogledajte [`rc` documentation][rc_examples] za više primjera brojanja referenci općenito.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` je verzija [`Arc`] koja sadrži neposedujuću referencu na upravljanu dodjelu.
/// Dodjeli se pristupa pozivom [`upgrade`] na pokazivaču `Weak`, koji vraća [`Option`]`<`[`Arc`] `<T>>`.
///
/// Budući da se referenca `Weak` ne računa u vlasništvo, neće spriječiti ispuštanje vrijednosti pohranjene u dodjeli, a sam `Weak` ne daje jamstva da je vrijednost još uvijek prisutna.
///
/// Stoga može vratiti [`None`] kada [`nadogradnja`] d.
/// Međutim, imajte na umu da referenca `Weak`*ne* sprječava oslobađanje same alokacije (spremišta).
///
/// Pokazivač `Weak` koristan je za zadržavanje privremene reference na dodjelu kojom upravlja [`Arc`], bez sprječavanja ispuštanja njegove unutarnje vrijednosti.
/// Također se koristi za sprečavanje kružnih referenci između pokazivača [`Arc`], jer međusobne reference posjedovanja nikada ne bi omogućile ispuštanje bilo kojeg [`Arc`].
/// Na primjer, stablo može imati snažne pokazivače [`Arc`] od roditeljskih čvorova do djece, a `Weak` pokazivače od djece natrag do roditelja.
///
/// Tipičan način dobivanja pokazivača `Weak` je pozivanje [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ovo je `NonNull` kako bi se omogućila optimizacija veličine ove vrste u enumima, ali to nije nužno valjani pokazivač.
    //
    // `Weak::new` postavlja ovo na `usize::MAX` tako da ne treba dodijeliti prostor na hrpi.
    // To nije vrijednost koju će pravi pokazivač ikada imati jer RcBox ima poravnanje najmanje 2.
    // To je moguće samo kada `T: Sized`;neodređeni `T` nikad se ne mota.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ovo je dokaz od repr(C) do future protiv mogućeg preuređivanja polja, što bi ometalo inače siguran [into|from]_raw() transmutabilnih unutarnjih tipova.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // vrijednost usize::MAX djeluje kao stražar za privremeno "locking" sposobnost nadogradnje slabih pokazivača ili spuštanja jačih;ovo se koristi za izbjegavanje utrka u `make_mut` i `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstruira novi `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Počnite računati slab pokazivač kao 1, a to je slabi pokazivač koji drže svi jaki pokazivači (kinda), pogledajte std/rc.rs za više informacija
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstruira novi `Arc<T>` koristeći slabu referencu na sebe.
    /// Pokušaj nadogradnje slabe reference prije nego što se ova funkcija vrati rezultirat će vrijednošću `None`.
    /// Međutim, slaba referenca može se slobodno klonirati i pohraniti za kasnije korištenje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstruirajte unutrašnjost u stanju "uninitialized" s jednom slabom referencom.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Važno je da se ne odričemo vlasništva nad slabim pokazivačem, inače bi memorija mogla biti oslobođena dok se `data_fn` vrati.
        // Ako bismo stvarno htjeli prenijeti vlasništvo, mogli bismo stvoriti dodatni slabi pokazivač za sebe, ali to bi rezultiralo dodatnim ažuriranjima broja slabih referenci koja inače ne bi bila potrebna.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Sada možemo pravilno inicijalizirati unutarnju vrijednost i našu slabu referencu pretvoriti u jaku referencu.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Gornje upisivanje u podatkovno polje mora biti vidljivo svim nitima koje promatraju jaki broj koji nije nula.
            // Stoga nam je potrebno najmanje "Release" naručivanje kako bismo se sinkronizirali s `compare_exchange_weak` u `Weak::upgrade`.
            //
            // "Acquire" naručivanje nije potrebno.
            // Kada razmatramo moguće ponašanje `data_fn`, trebamo pogledati samo što bi mogao učiniti s referencom na `Weak` koji se ne može nadograditi:
            //
            // - Može *klonirati*`Weak`, povećavajući broj slabih referenci.
            // - Može ispustiti te klonove, smanjujući broj slabih referenci (ali nikada na nulu).
            //
            // Ove nuspojave ne utječu na nas ni na koji način, a nikakve druge nuspojave nisu moguće samo sa sigurnim kodom.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Jake reference trebale bi zajednički posjedovati zajedničku slabu referencu, zato nemojte pokretati destruktor za našu staru slabu referencu.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruira novi `Arc` s neinicijaliziranim sadržajem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruira novi `Arc` s neinicijaliziranim sadržajem, s memorijom koja je napunjena bajtovima `0`.
    ///
    ///
    /// Pogledajte [`MaybeUninit::zeroed`][zeroed] za primjere ispravne i netočne uporabe ove metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruira novi `Pin<Arc<T>>`.
    /// Ako `T` ne implementira `Unpin`, tada će `data` biti pričvršćen u memoriju i ne može se premjestiti.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstruira novi `Arc<T>`, vraća grešku ako dodjeljivanje ne uspije.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Počnite računati slab pokazivač kao 1, a to je slabi pokazivač koji drže svi jaki pokazivači (kinda), pogledajte std/rc.rs za više informacija
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstruira novi `Arc` s neinicijaliziranim sadržajem, vraća grešku ako dodjela ne uspije.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruira novi `Arc` s neinicijaliziranim sadržajem, s memorijom koja se puni bajtovima `0`, vraćajući pogrešku u slučaju da dodjela ne uspije.
    ///
    ///
    /// Pogledajte [`MaybeUninit::zeroed`][zeroed] za primjere ispravne i netočne uporabe ove metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Vraća unutarnju vrijednost ako `Arc` ima točno jednu snažnu referencu.
    ///
    /// Inače, vraća se [`Err`] s istim `Arc` koji je proslijeđen.
    ///
    ///
    /// To će uspjeti čak i ako postoje izvanredne slabe reference.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Napravite slab pokazivač da biste očistili implicitnu jako-slabu referencu
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstruira novu presječenu atomsku referentnu krišku s neinicijaliziranim sadržajem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstruira novu presječenu atomsku referentnu krišku s neinicijaliziranim sadržajem, s memorijom koja je napunjena bajtovima `0`.
    ///
    ///
    /// Pogledajte [`MaybeUninit::zeroed`][zeroed] za primjere ispravne i netočne uporabe ove metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Pretvara u `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Kao i kod [`MaybeUninit::assume_init`], na pozivatelju je da osigura da je unutarnja vrijednost stvarno u inicijaliziranom stanju.
    ///
    /// To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje trenutno nedefinirano ponašanje.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Pretvara u `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Kao i kod [`MaybeUninit::assume_init`], na pozivatelju je da osigura da je unutarnja vrijednost stvarno u inicijaliziranom stanju.
    ///
    /// To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje trenutno nedefinirano ponašanje.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odgođena inicijalizacija:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Konzumira `Arc` vraćajući zamotani pokazivač.
    ///
    /// Da bi se izbjeglo curenje memorije, pokazivač se mora pretvoriti natrag u `Arc` pomoću [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Pruža neobrađeni pokazivač na podatke.
    ///
    /// Na brojanje to ne utječe ni na koji način i `Arc` se ne troši.
    /// Pokazivač vrijedi sve dok u `Arc` postoji jako brojanje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SIGURNOST: Ovo ne može proći Deref::deref ili RcBoxPtr::inner jer
        // to je potrebno za zadržavanje raw/mut provenijencije tako da npr
        // `get_mut` može pisati kroz pokazivač nakon što se Rc oporavi kroz `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstruira `Arc<T>` iz sirovog pokazivača.
    ///
    /// Neobrađeni pokazivač mora biti prethodno vraćen pozivom na [`Arc<U>::into_raw`][into_raw] gdje `U` mora imati istu veličinu i poravnanje kao `T`.
    /// To je trivijalno točno ako je `U` `T`.
    /// Imajte na umu da ako `U` nije `T`, ali ima istu veličinu i poravnanje, to je u osnovi poput pretvaranja referenci različitih vrsta.
    /// Pogledajte [`mem::transmute`][transmute] za više informacija o tome koja se ograničenja primjenjuju u ovom slučaju.
    ///
    /// Korisnik `from_raw` mora osigurati da određena vrijednost `T` padne samo jednom.
    ///
    /// Ova funkcija nije sigurna jer nepravilna uporaba može dovesti do nesigurnosti memorije, čak i ako se vraćenom `Arc<T>` nikad ne pristupi.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Vratite se na `Arc` kako biste spriječili curenje.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Daljnji pozivi na `Arc::from_raw(x_ptr)` bili bi nesigurni u memoriji.
    /// }
    ///
    /// // Sjećanje se oslobodilo kad je `x` izašao iz gornjeg opsega, pa `x_ptr` sada visi!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Preokrenite pomak da biste pronašli izvorni ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Stvara novi [`Weak`] pokazivač na ovu dodjelu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Ovo je opušteno u redu jer provjeravamo vrijednost u CAS-u ispod.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // provjerite je li slab brojač trenutno "locked";ako je tako, zavrtite se.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ovaj kod trenutno zanemaruje mogućnost preljeva
            // u usize::MAX;općenito i Rc i Arc treba prilagoditi da bi se nosilo s preljevom.
            //

            // Za razliku od Clone(), ovo nam treba biti čitanje Acquire za sinkronizaciju s upisom koji dolazi iz `is_unique`, tako da se događaji prije tog pisanja događaju prije ovog čitanja.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Pazite da ne stvorimo viseći Slabi
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Dobiva broj [`Weak`] pokazivača na ovu dodjelu.
    ///
    /// # Safety
    ///
    /// Ova metoda je sama po sebi sigurna, ali pravilna uporaba zahtijeva dodatnu brigu.
    /// Druga nit može u bilo kojem trenutku promijeniti broj slabih, uključujući potencijalno između pozivanja ove metode i djelovanja na rezultat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ova je tvrdnja deterministička jer nismo dijelili `Arc` ili `Weak` između niti.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ako je trenutno slabo zaključano, vrijednost brojača bila je 0 neposredno prije zaključavanja.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Dobiva broj snažnih (`Arc`) pokazivača na ovu dodjelu.
    ///
    /// # Safety
    ///
    /// Ova metoda je sama po sebi sigurna, ali pravilna uporaba zahtijeva dodatnu brigu.
    /// Druga nit može u bilo kojem trenutku promijeniti jaki broj, uključujući potencijalno između pozivanja ove metode i djelovanja na rezultat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ova je tvrdnja deterministička jer nismo dijelili `Arc` između niti.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Pojača jaki broj referenci na `Arc<T>` povezan s navedenim pokazivačem za jedan.
    ///
    /// # Safety
    ///
    /// Pokazivač mora biti dobiven putem `Arc::into_raw`, a pridružena instanca `Arc` mora biti valjana (tj
    /// jaki broj mora biti najmanje 1) za vrijeme trajanja ove metode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ova je tvrdnja deterministička jer nismo dijelili `Arc` između niti.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Zadržite Arc, ali ne dodirujte ponovno brojanje umotavanjem u ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Sada povećajte ponovno brojanje, ali ne ispuštajte ni novo
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Brojanje jakih referenci na `Arc<T>` povezanom s navedenim pokazivačem smanjuje za jedan.
    ///
    /// # Safety
    ///
    /// Pokazivač mora biti dobiven putem `Arc::into_raw`, a pridružena instanca `Arc` mora biti valjana (tj
    /// jaki broj mora biti najmanje 1) pri pozivanju na ovu metodu.
    /// Ova se metoda može koristiti za oslobađanje konačnog `Arc` i sigurnosne memorije, ali **se ne smije** pozivati nakon što je izdan konačni `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Te su tvrdnje determinističke jer nismo dijelili `Arc` između niti.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ova nesigurnost je u redu jer dok je ovaj luk živ jamčimo da je unutarnji pokazivač valjan.
        // Nadalje, znamo da je sama struktura `ArcInner` `Sync`, jer su i unutarnji podaci `Sync`, tako da smo u mogućnosti posuditi nepromjenjivi pokazivač na ovaj sadržaj.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Neugrađeni dio `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Trenutno uništite podatke, iako možda nećemo osloboditi samu dodjelu okvira (možda još uvijek postoje slabi pokazivači).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Odbacite slabe kritike koje kolektivno drže sve jake reference
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Vraća `true` ako dva `Arc` usmjeravaju na istu dodjelu (u veni sličnoj [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Dodjeljuje `ArcInner<T>` s dovoljnim prostorom za možda neodmjerenu unutarnju vrijednost tamo gdje vrijednost ima predviđeni raspored.
    ///
    /// Funkcija `mem_to_arcinner` poziva se s pokazivačem podataka i mora vratiti (potencijalno masni) pokazivač za `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Izračunajte izgled koristeći zadani raspored vrijednosti.
        // Prije se raspored izračunavao na izrazu `&*(ptr as* const ArcInner<T>)`, ali to je stvorilo pogrešno poravnanu referencu (vidi #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Dodjeljuje `ArcInner<T>` s dovoljno prostora za potencijalno neodređenu unutarnju vrijednost gdje vrijednost ima predviđeni izgled, vraća pogrešku ako dodjela ne uspije.
    ///
    ///
    /// Funkcija `mem_to_arcinner` poziva se s pokazivačem podataka i mora vratiti (potencijalno masni) pokazivač za `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Izračunajte izgled koristeći zadani raspored vrijednosti.
        // Prije se raspored izračunavao na izrazu `&*(ptr as* const ArcInner<T>)`, ali to je stvorilo pogrešno poravnanu referencu (vidi #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicijalizirajte ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Dodjeljuje `ArcInner<T>` s dovoljno prostora za neodređenu unutarnju vrijednost.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Dodijelite za `ArcInner<T>` koristeći zadanu vrijednost.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopiraj vrijednost u bajtovima
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Oslobodite alokaciju bez ispuštanja sadržaja
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Dodjeljuje `ArcInner<[T]>` zadane duljine.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopirajte elemente iz kriške u novo dodijeljeni luk <\[T\]>
    ///
    /// Nesigurno jer pozivatelj mora ili preuzeti vlasništvo ili povezati `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstruira `Arc<[T]>` iz iteratora za koji se zna da je određene veličine.
    ///
    /// Ponašanje je nedefinirano ako je veličina pogrešna.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic štitnik dok klonira T elemente.
        // U slučaju panic, elementi koji su zapisani u novi ArcInner bit će ispušteni, a zatim oslobođena memorija.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pokazivač na prvi element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Sve jasno.Zaboravite stražara da ne oslobodi novi ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specijalizacija Portrait korištena za `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Izrađuje klon pokazivača `Arc`.
    ///
    /// To stvara još jedan pokazivač na istu dodjelu, povećavajući jaki broj referenci.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Korištenje opuštenog redoslijeda ovdje je u redu, jer poznavanje izvorne reference sprječava druge niti da pogrešno izbrišu objekt.
        //
        // Kao što je objašnjeno u [Boost documentation][1], povećanje brojača referenci uvijek se može izvršiti pomoću memory_order_relaxed: Nove reference na objekt mogu se oblikovati samo iz postojeće reference, a prosljeđivanje postojeće reference iz jedne niti u drugu već mora osigurati potrebnu sinkronizaciju.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Međutim, moramo se čuvati masovnih ponovnih brojanja u slučaju da netko `pamti: : zaboravlja lukove.
        // Ako to ne učinimo, brojanje se može preliti i korisnici će nakon toga koristiti besplatno.
        // Izuzetno zasićujemo `isize::MAX` pod pretpostavkom da nema ~2 milijardi niti koje povećavaju broj referenci odjednom.
        //
        // Ovaj branch nikada neće biti snimljen u bilo kojem realističnom programu.
        //
        // Prekidamo jer je takav program nevjerojatno degeneriran i ne brinemo se za njega.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Daje promjenjivu referencu na zadani `Arc`.
    ///
    /// Ako postoje drugi pokazivači `Arc` ili [`Weak`] na istu dodjelu, tada će `make_mut` stvoriti novu dodjelu i pozvati [`clone`][clone] na unutarnju vrijednost kako bi osigurao jedinstveno vlasništvo.
    /// To se također naziva klonom-na-pisanje.
    ///
    /// Imajte na umu da se to razlikuje od ponašanja [`Rc::make_mut`] koji razdvaja sve preostale pokazivače `Weak`.
    ///
    /// Vidi također [`get_mut`][get_mut], koji će propasti umjesto kloniranja.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Neće klonirati ništa
    /// let mut other_data = Arc::clone(&data); // Neće klonirati unutarnje podatke
    /// *Arc::make_mut(&mut data) += 1;         // Klonira unutarnje podatke
    /// *Arc::make_mut(&mut data) += 1;         // Neće klonirati ništa
    /// *Arc::make_mut(&mut other_data) *= 2;   // Neće klonirati ništa
    ///
    /// // Sada `data` i `other_data` upućuju na različita izdvajanja.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Imajte na umu da imamo i jaku i slabu referencu.
        // Dakle, puštanje samo naše snažne reference samo po sebi neće dovesti do uklanjanja memorije.
        //
        // Upotrijebite Acquire kako biste osigurali da uočimo bilo kakva upisivanja u `weak` koja se dogode prije upisivanja izdanja (tj. Dekrecije) u `strong`.
        // Budući da imamo slab broj, nema šanse da se sam ArcInner može osloboditi.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Postoji još jedan snažan pokazivač, pa moramo klonirati.
            // Unaprijed dodijelite memoriju kako biste omogućili izravno pisanje klonirane vrijednosti.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Opušteno je dovoljno u gore navedenom jer je ovo u osnovi optimizacija: uvijek se utrkujemo sa ispadanjem slabih pokazivača.
            // U najgorem slučaju, na kraju smo nepotrebno dodijelili novi luk.
            //

            // Uklonili smo posljednju jaku preporuku, ali preostali su još slabi.
            // Sadržaj ćemo premjestiti u novi Arc i onesposobiti ostale slabe reference.
            //

            // Imajte na umu da čitanje `weak` ne može dati usize::MAX (tj. Zaključano), jer slab broj može zaključati samo nit s jakom referencom.
            //
            //

            // Materijalizirajte naš vlastiti implicitni slabi pokazivač, tako da može očistiti ArcInner po potrebi.
            //
            let _weak = Weak { ptr: this.ptr };

            // Možete samo ukrasti podatke, preostao je samo Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Bili smo jedina referenca bilo koje vrste;povećati broj snažnih ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Kao i kod `get_mut()`, nesigurnost je u redu jer je naša referenca za početak bila jedinstvena ili je postala kloniranjem sadržaja.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Vraća promjenjivu referencu u zadani `Arc`, ako nema drugih pokazivača `Arc` ili [`Weak`] na istu dodjelu.
    ///
    ///
    /// U suprotnom vraća [`None`], jer nije sigurno mutirati zajedničku vrijednost.
    ///
    /// Vidi također [`make_mut`][make_mut], koji će [`clone`][clone] dobiti unutarnju vrijednost kada postoje drugi pokazivači.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ova nesigurnost je u redu jer smo zajamčeni da je vraćeni pokazivač *jedini* pokazivač koji će ikada biti vraćen na T.
            // U ovom trenutku zajamčeno je da je naš referentni broj 1, a mi smo tražili da sam luk bude `mut`, pa vraćamo jedinu moguću referencu na unutarnje podatke.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Vraća promjenjivu referencu u zadani `Arc`, bez ikakve provjere.
    ///
    /// Pogledajte također [`get_mut`], koji je siguran i vrši odgovarajuće provjere.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Bilo koji drugi pokazivač `Arc` ili [`Weak`] na istu dodjelu ne smije se dereferencirati za vrijeme vraćenog posudbe.
    ///
    /// To je trivijalan slučaj ako takvi pokazivači ne postoje, na primjer odmah nakon `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Pazimo da *ne* stvorimo referencu koja pokriva polja "count", jer bi to bilo zamjensko ime uz istovremeni pristup brojanju referenci (npr.
        // do `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Utvrdite je li ovo jedinstvena referenca (uključujući slabe reference) na temeljne podatke.
    ///
    ///
    /// Imajte na umu da ovo zahtijeva zaključavanje slabog broja ref.
    fn is_unique(&mut self) -> bool {
        // zaključajte broj slabih pokazivača ako se čini da smo jedini držač slabog pokazivača.
        //
        // Oznaka za nabavu ovdje osigurava odnos prije bilo kojeg upisa u `strong` (posebno u `Weak::upgrade`) prije smanjenja broja `weak` (putem `Weak::drop`, koji koristi izdanje).
        // Ako nadograđeni slabi ref nikada nije ispušten, CAS ovdje neće uspjeti pa se ne brinemo za sinkronizaciju.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ovo mora biti `Acquire` da bi se sinkronizirao s dekretom brojača `strong` u `drop`-jedini pristup koji se događa kada se odbaci bilo koja referenca, osim posljednje.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Puštanje izdanja ovdje se sinkronizira s čitanjem u `downgrade`, učinkovito sprečavajući da se gore navedeno čitanje `strong` dogodi nakon pisanja.
            //
            //
            self.inner().weak.store(1, Release); // otpustite bravu
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Ispušta `Arc`.
    ///
    /// To će smanjiti snažni broj referenci.
    /// Ako broj snažnih referenci dosegne nulu, tada su jedine druge reference (ako postoje) [`Weak`], pa `drop` dobivamo unutarnju vrijednost.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ne ispisuje ništa
    /// drop(foo2);   // Ispisuje "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Budući da je `fetch_sub` već atomski, ne trebamo sinkronizirati s drugim nitima ako ne želimo izbrisati objekt.
        // Ista se logika odnosi na donji `fetch_sub` na broj `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ova je ograda potrebna kako bi se spriječilo preuređivanje upotrebe podataka i brisanje podataka.
        // Budući da je označen `Release`, smanjenje broja referenci sinkronizira se s ovom ogradom `Acquire`.
        // To znači da se upotreba podataka događa prije smanjenja broja referenci, što se događa prije ove ograde, što se događa prije brisanja podataka.
        //
        // Kao što je objašnjeno u [Boost documentation][1],
        //
        // > Važno je nametnuti svaki mogući pristup objektu u jednom
        // > nit (kroz postojeću referencu) da se *dogodi prije* brisanja
        // > objekt u drugoj niti.To postiže "release"
        // > operacija nakon ispuštanja reference (bilo koji pristup objektu
        // > kroz ovu referencu očito se moralo dogoditi prije), i an
        // > "acquire" operacija prije brisanja objekta.
        //
        // Konkretno, iako je sadržaj Luka obično nepromjenjiv, moguće je imati unutarnje zapise na nešto poput Mutexa<T>.
        // Budući da se Mutex ne stječe kada se briše, ne možemo se osloniti na njegovu logiku sinkronizacije kako bi upisi u nit A bili vidljivi destruktoru pokrenutom u niti B.
        //
        //
        // Također imajte na umu da bi se ograda Acquire ovdje vjerojatno mogla zamijeniti teretom Acquire, što bi moglo poboljšati performanse u vrlo spornim situacijama.Pogledajte [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Pokušaj `Arc<dyn Any + Send + Sync>` spustiti na konkretnu vrstu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstruira novi `Weak<T>`, bez izdvajanja memorije.
    /// Pozivanje [`upgrade`] na povratnu vrijednost uvijek daje [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Vrsta pomoćnika za omogućavanje pristupa brojanju referenci bez davanja bilo kakvih tvrdnji o podatkovnom polju.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Vraća sirovi pokazivač na objekt `T` na koji ukazuje ovaj `Weak<T>`.
    ///
    /// Pokazivač vrijedi samo ako postoje neke jake reference.
    /// Pokazivač može biti viseći, nesaglašen ili čak [`null`] u suprotnom.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Oboje upućuju na isti objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Snažni ga ovdje održava na životu, tako da i dalje možemo pristupiti objektu.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ali ne više.
    /// // Možemo weak.as_ptr(), ali pristup pokazivaču vodio bi nedefiniranom ponašanju.
    /// // assert_eq! ("zdravo", nesigurno {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ako se pokazivač klati, vratit ćemo stražu izravno.
            // Ovo ne može biti važeća adresa korisnog tereta, jer je nosivost poravnata barem kao ArcInner (usize).
            ptr as *const T
        } else {
            // SIGURNOST: ako is_dangling vrati false, tada se pokazivač ne može preusmjeriti.
            // Korisni teret u ovom trenutku može pasti, a mi moramo održavati provenijenciju, stoga koristite manipulaciju sirovim pokazivačem.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Konzumira `Weak<T>` i pretvara ga u neobrađeni pokazivač.
    ///
    /// To pretvara slabi pokazivač u neobrađeni pokazivač, a istovremeno zadržava vlasništvo nad jednom slabom referencom (ova operacija ne mijenja slabi broj).
    /// Može se vratiti natrag u `Weak<T>` s [`from_raw`].
    ///
    /// Primjenjuju se ista ograničenja pristupa cilju pokazivača kao i kod [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Pretvara sirovi pokazivač koji je prethodno stvorio [`into_raw`] natrag u `Weak<T>`.
    ///
    /// To se može koristiti za sigurno dobivanje jake reference (pozivanjem [`upgrade`] kasnije) ili za oslobađanje broja slabih ako ispustite `Weak<T>`.
    ///
    /// Potrebno je vlasništvo nad jednom slabom referencom (osim pokazivača kreiranih od [`new`], jer oni ne posjeduju ništa; metoda i dalje djeluje na njih).
    ///
    /// # Safety
    ///
    /// Pokazivač sigurno potječe iz [`into_raw`] i još uvijek mora posjedovati potencijalno slabu referencu.
    ///
    /// Dopušteno je da broj jakih brojeva bude 0 u trenutku poziva.
    /// Ipak, ovo preuzima vlasništvo nad jednom slabom referencom koja je trenutno predstavljena kao neobrađeni pokazivač (ova operacija ne mijenja slabi broj) i stoga mora biti uparena s prethodnim pozivom na [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Umanji posljednje slabo brojanje.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Pogledajte Weak::as_ptr za kontekst o tome kako je izveden ulazni pokazivač.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ovo je viseći Slab.
            ptr as *mut ArcInner<T>
        } else {
            // U suprotnom, zajamčeno nam je da pokazivač dolazi od neupitnog Slabaša.
            // SIGURNOST: data_offset je sigurno nazvati, jer ptr upućuje na stvarni (potencijalno ispušteni) T.
            let offset = unsafe { data_offset(ptr) };
            // Dakle, preokrećemo pomak da bismo dobili cijeli RcBox.
            // SIGURNOST: pokazivač potječe iz slabosti, tako da je ovaj pomak siguran.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIGURNOST: sada smo obnovili izvorni slabi pokazivač, tako da možemo stvoriti slab.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Pokušaji nadogradnje pokazivača `Weak` na [`Arc`], odgađajući ispuštanje unutarnje vrijednosti ako je uspješno.
    ///
    ///
    /// Vraća [`None`] ako je unutarnja vrijednost u međuvremenu ispuštena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Uništite sve snažne pokazivače.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Koristimo CAS petlju za povećavanje jakog broja umjesto fetch_add, jer ova funkcija nikada ne bi trebala uzimati referentni broj od nule do jedan.
        //
        //
        let inner = self.inner()?;

        // Opušteno opterećenje jer svako zapisivanje 0 koje možemo promatrati ostavlja polje u trajno nultom stanju (tako da je očitanje "stale" od 0 u redu), a bilo koja druga vrijednost potvrđuje se putem CAS-a u nastavku.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Pogledajte komentare u `Arc::clone` zašto to radimo (za `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Opušteno je u redu za slučaj neuspjeha jer nemamo nikakva očekivanja o novoj državi.
            // Acquire je neophodan za sinkronizaciju slučaja uspjeha s `Arc::new_cyclic`, kada se unutarnja vrijednost može inicijalizirati nakon što su `Weak` reference već stvorene.
            // U tom slučaju očekujemo promatrati potpuno inicijaliziranu vrijednost.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nula označena gore
                Err(old) => n = old,
            }
        }
    }

    /// Dobiva broj snažnih pokazivača (`Arc`) koji upućuju na ovu dodjelu.
    ///
    /// Ako je `self` stvoren pomoću [`Weak::new`], vratit će se 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Dobiva aproksimaciju broja pokazivača `Weak` koji upućuju na ovu dodjelu.
    ///
    /// Ako je `self` stvoren pomoću [`Weak::new`] ili ako nema preostalih jakih pokazivača, vratit će se 0.
    ///
    /// # Accuracy
    ///
    /// Zbog detalja implementacije, vraćena vrijednost može se isključiti za 1 u bilo kojem smjeru kada druge niti manipuliraju bilo kojim `Arc`s ili`Weak`s koji upućuju na istu dodjelu.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Budući da smo primijetili da je postojao barem jedan snažni pokazivač nakon čitanja slabog brojača, znamo da je implicitna slaba referenca (prisutna kad god su neke snažne reference žive) još uvijek bila prisutna kad smo promatrali slabo brojanje i stoga je možemo sigurno oduzeti.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Vraća `None` kada se pokazivač klati i nema dodijeljenog `ArcInner` (tj. Kada je ovaj `Weak` stvorio `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Pazimo da *ne* stvorimo referencu koja pokriva polje "data", jer polje može istodobno biti mutirano (na primjer, ako se odustane od posljednjeg `Arc`, polje podataka bit će na mjestu).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Vraća `true` ako dva `Slaba` usmjeravaju na istu dodjelu (slično kao [`ptr::eq`]) ili ako oba ne upućuju na bilo koju dodjelu (jer su stvoreni s `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Budući da ovo uspoređuje pokazivače, to znači da će se `Weak::new()` međusobno izjednačiti, iako ne upućuju na bilo kakvu dodjelu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Uspoređujući `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Izrađuje klon pokazivača `Weak` koji upućuje na istu dodjelu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Pogledajte komentare u Arc::clone() zašto je to opušteno.
        // Tu se može koristiti fetch_add (zanemarujući zaključavanje) jer se slab broj zaključava samo tamo gdje *nema drugih* slabih pokazivača.
        //
        // (Dakle, u tom slučaju ne možemo pokretati ovaj kod).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Pogledajte komentare u Arc::clone() zašto to radimo (za mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruira novi `Weak<T>`, bez izdvajanja memorije.
    /// Pozivanje [`upgrade`] na povratnu vrijednost uvijek daje [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Ispušta pokazivač `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ne ispisuje ništa
    /// drop(foo);        // Ispisuje "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ako otkrijemo da smo bili zadnji slabi pokazivač, vrijeme je da u potpunosti oslobodimo podatke.Pogledajte raspravu u Arc::drop() o narudžbama memorije
        //
        // Ovdje nije potrebno provjeravati zaključano stanje, jer se broj slabih može zaključati samo ako je postojao točno jedan slabi ref, što znači da se pad mogao naknadno pokrenuti ON na onom preostalom slabom ref, što se može dogoditi tek nakon otpuštanja zaključavanja.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ovu specijalizaciju radimo ovdje, a ne kao općenitu optimizaciju na `&T`, jer bi to inače dodalo trošak svim provjerama jednakosti na ref.
/// Pretpostavljamo da se `Arc` koriste za pohranu velikih vrijednosti, koje se sporo kloniraju, ali i teže provjeravaju jednakost, zbog čega se ovaj trošak lakše isplati.
///
/// Također je vjerojatnije da imaju dva `Arc` klona koja upućuju na istu vrijednost, nego dva `&T`-a.
///
/// To možemo učiniti samo kada `T: Eq` kao `PartialEq` može biti namjerno nefleksivan.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Jednakost za dva `Arc`-a.
    ///
    /// Dvije `Arc` su jednake ako su njihove unutarnje vrijednosti jednake, čak i ako su pohranjene u različitom rasporedu.
    ///
    /// Ako `T` također implementira `Eq` (što podrazumijeva refleksivnost jednakosti), dva `Arc-a koja upućuju na istu raspodjelu uvijek su jednaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Nejednakost za dva `Arc`-a.
    ///
    /// Dvije `Arc` su nejednake ako su njihove unutarnje vrijednosti nejednake.
    ///
    /// Ako `T` također implementira `Eq` (što podrazumijeva refleksivnost jednakosti), dva `Arc-a koji upućuju na istu vrijednost nikada nisu nejednaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Djelomična usporedba za dva `Arc`.
    ///
    /// Njih dvije uspoređuju se pozivanjem `partial_cmp()` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Manje od usporedbe za dva `Arc`-a.
    ///
    /// Njih dvije uspoređuju se pozivanjem `<` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Usporedba "Manje ili jednako" za dva "Arc".
    ///
    /// Njih dvije uspoređuju se pozivanjem `<=` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Veća usporedba za dva `Arc`-a.
    ///
    /// Njih dvije uspoređuju se pozivanjem `>` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Usporedba "veća ili jednaka" za dva "luka".
    ///
    /// Njih dvije uspoređuju se pozivanjem `>=` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Usporedba za dva `Arc`.
    ///
    /// Njih dvije uspoređuju se pozivanjem `cmp()` na temelju njihovih unutarnjih vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Stvara novi `Arc<T>`, s vrijednošću `Default` za `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Dodijelite referentno brojenu krišku i napunite je kloniranjem stavki `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Dodijelite referentno brojeni `str` i u njega kopirajte `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Dodijelite referentno brojeni `str` i u njega kopirajte `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Premjestite uokvireni objekt na novu dodijeljenu brojenu referencu.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Dodijelite kriško brojenu referencu i u nju premjestite stavke `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Dopustite Vecu da oslobodi svoju memoriju, ali ne i uništi njegov sadržaj
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Uzima svaki element u `Iterator` i prikuplja ga u `Arc<[T]>`.
    ///
    /// # Karakteristike izvedbe
    ///
    /// ## Opći slučaj
    ///
    /// U pravilu se prikupljanje u `Arc<[T]>` vrši prvo sakupljanjem u `Vec<T>`.Odnosno, kada pišete sljedeće:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ovo se ponaša kao da smo napisali:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ovdje se događa prvi skup dodjela.
    ///     .into(); // Ovdje se događa druga dodjela za `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ovo će dodijeliti onoliko puta koliko je potrebno za konstrukciju `Vec<T>`, a zatim će dodijeliti jednom za pretvaranje `Vec<T>` u `Arc<[T]>`.
    ///
    ///
    /// ## Iteratori poznate duljine
    ///
    /// Kada vaš `Iterator` implementira `TrustedLen` i bude točne veličine, dodijelit će se jedno dodijeljivanje za `Arc<[T]>`.Na primjer:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Ovdje se događa samo jedna dodjela.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specijalizacija Portrait koja se koristi za prikupljanje u `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // To je slučaj za `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SIGURNOST: Moramo osigurati da iterator ima točnu duljinu kao i mi.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Vratite se normalnoj provedbi.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Dobijte odmak unutar `ArcInner` za nosivost iza pokazivača.
///
/// # Safety
///
/// Pokazivač mora ukazivati na (i imati valjane metapodatke za) prethodno važeću instancu T, ali T se smije ispustiti.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Poravnajte neodređenu vrijednost na kraj ArcInnera.
    // Budući da je RcBox repr(C), to će uvijek biti posljednje polje u memoriji.
    // SIGURNOST: budući da su jedini mogući neodređeni tipovi kriške, Portrait objekti,
    // i extern tipova, ulazni sigurnosni zahtjev trenutno je dovoljan da zadovolji zahtjeve align_of_val_raw;ovo je detalj provedbe jezika na koji se ne može pouzdati izvan std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}