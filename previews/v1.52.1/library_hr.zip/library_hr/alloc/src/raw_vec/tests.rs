use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Pisanje testa integracije između alokatora treće strane i `RawVec` pomalo je nezgodno jer API `RawVec` ne izlaže pogrešnim metodama raspodjele, pa ne možemo provjeriti što se događa kada se alokator iscrpi (osim otkrivanja panic).
    //
    //
    // Umjesto toga, ovo samo provjerava da `RawVec` metode prolaze barem kroz Allocator API kada rezerviraju pohranu.
    //
    //
    //
    //
    //

    // Nijemi razdjelnik koji troši fiksnu količinu goriva prije nego što pokušaji dodjele počnu propadati.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (uzrokuje realloc, tako da se koristi 50 + 150=200 jedinica goriva)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Prvo, `reserve` izdvaja poput `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 je više nego dvostruko od 7, pa bi `reserve` trebao raditi kao `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 manje je od polovice 12, pa `reserve` mora rasti eksponencijalno.
        // U vrijeme pisanja ovog testa faktor rasta je 2, tako da je novi kapacitet 24, međutim, faktor rasta i 1.5 je u redu.
        //
        // Stoga `>= 18` tvrdi.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}