//! Neprekidni tip matričnog masiva sa sadržajem dodijeljenim hrpom, napisan `Vec<T>`.
//!
//! Vectors imaju `O(1)` indeksiranje, amortizirani `O(1)` push (do kraja) i `O(1)` skok (od kraja).
//!
//!
//! Vectors osiguravaju da nikada ne dodijele više od `isize::MAX` bajtova.
//!
//! # Examples
//!
//! Možete izričito stvoriti [`Vec`] s [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ili pomoću makronaredbe [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // deset nula
//! ```
//!
//! Vrijednosti [`push`] možete na kraju vector (koji će vector rasti po potrebi):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Iskakanje vrijednosti djeluje na sličan način:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors također podržavaju indeksiranje (kroz [`Index`] i [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Susjedni tip polja koji se može uzgajati, napisan kao `Vec<T>` i izgovara se 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Makronaredba [`vec!`] osigurana je kako bi inicijalizacija bila praktičnija:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Također može inicijalizirati svaki element `Vec<T>` s danom vrijednošću.
/// To može biti učinkovitije od izvođenja dodjele i inicijalizacije u odvojenim koracima, posebno kada se inicijalizira vector nula:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Sljedeće je ekvivalentno, ali potencijalno sporije:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Za više informacija pogledajte [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Koristite `Vec<T>` kao učinkovit stog:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Otisci 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Tip `Vec` omogućuje pristup vrijednostima po indeksu, jer implementira [`Index`] Portrait.Primjer će biti jasniji:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // prikazat će '2'
/// ```
///
/// No budite oprezni: ako pokušate pristupiti indeksu koji nije u `Vec`, vaš će softver biti panic!Ti ne možeš ovo napraviti:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Upotrijebite [`get`] i [`get_mut`] ako želite provjeriti nalazi li se indeks u `Vec`.
///
/// # Slicing
///
/// `Vec` može biti promjenjiv.S druge strane, kriške su objekti samo za čitanje.
/// Da biste dobili [slice][prim@slice], upotrijebite [`&`].Primjer:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... i to je sve!
/// // možete i ovako:
/// let u: &[usize] = &v;
/// // ili ovako:
/// let u: &[_] = &v;
/// ```
///
/// U Rust, češće je prosljeđivanje kriški kao argumenata, nego vectors kada samo želite pružiti pristup za čitanje.Isto vrijedi i za [`String`] i [`&str`].
///
/// # Kapacitet i preraspodjela
///
/// Kapacitet vector je količina prostora dodijeljena bilo kojim future elementima koji će se dodati na vector.To se ne smije zamijeniti s *duljinom* vector, koja određuje broj stvarnih elemenata unutar vector.
/// Ako duljina vector premaši njegov kapacitet, kapacitet će se automatski povećati, ali njegovi će se elementi morati preraspodijeliti.
///
/// Na primjer, vector kapaciteta 10 i duljine 0 bio bi prazan vector s prostorom za još 10 elemenata.Guranje 10 ili manje elemenata na vector neće promijeniti njegov kapacitet niti uzrokovati preraspodjelu.
/// Međutim, ako se duljina vector poveća na 11, morat će se preraspodijeliti, što može biti sporo.Iz tog razloga preporučuje se koristiti [`Vec::with_capacity`] kad god je to moguće kako biste odredili koliko se vector očekuje.
///
/// # Guarantees
///
/// Zbog svoje nevjerojatno temeljne prirode, `Vec` daje puno jamstava o svom dizajnu.To osigurava da je to što je moguće manje općenito u općenitom slučaju i da se njime može nesigurno kodirati ispravno na primitivan način.Imajte na umu da se ova jamstva odnose na nekvalificirani `Vec<T>`.
/// Ako se dodaju dodatni parametri tipa (npr. Za podršku prilagođenim alokatorima), nadjačavanje njihovih zadanih postavki može promijeniti ponašanje.
///
/// Najvažnije je da `Vec` jest i uvijek će biti trostruki (pokazivač, kapacitet, duljina).Ni više ni manje.Redoslijed ovih polja potpuno je neodređen i trebali biste koristiti odgovarajuće metode da biste ih izmijenili.
/// Pokazivač nikada neće biti null, pa je ovaj tip optimiziran za null-pointer.
///
/// Međutim, pokazivač možda zapravo ne pokazuje na dodijeljenu memoriju.
/// Konkretno, ako konstruirate `Vec` kapaciteta 0 preko [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] ili pozivanjem [`shrink_to_fit`] na praznom Vecu, neće dodijeliti memoriju.Slično tome, ako pohranite tipove nulte veličine unutar `Vec`, neće im dodijeliti prostor.
/// *Imajte na umu da u ovom slučaju `Vec` možda neće prijaviti [`capacity`] od 0*.
/// `Vec` dodijelit će ako i samo ako [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Općenito, detalji o dodjeli `Veca` vrlo su suptilni-ako namjeravate dodijeliti memoriju pomoću `Vec` i koristiti je za nešto drugo (ili za prosljeđivanje na nesigurni kôd, ili za izgradnju vlastite kolekcije podržane memorijom), budite sigurni osloboditi ovu memoriju pomoću `from_raw_parts` za oporavak `Vec`, a zatim ispuštanjem.
///
/// Ako `Vec` * ima dodijeljenu memoriju, tada se memorija na koju upućuje nalazi na hrpi (kako je definirano raspodjeljivačem Rust konfigurirano da se koristi prema zadanim postavkama), a pokazivač pokazuje na [`len`] inicijalizirane, susjedne elemente redom (što biste željeli pogledajte jeste li je prisilili na krišku), nakon čega slijede [`kapacitet`]`,`[`len`] logično neinicijalizirani, susjedni elementi.
///
///
/// vector koji sadrži elemente `'a'` i `'b'` kapaciteta 4 može se vizualizirati na sljedeći način.Gornji dio je struktura `Vec`, sadrži pokazivač na glavu dodjele u hrpi, duljinu i kapacitet.
/// Donji dio je alokacija na hrpi, susjedni memorijski blok.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** predstavlja memoriju koja nije inicijalizirana, pogledajte [`MaybeUninit`].
/// - Note: ABI nije stabilan i `Vec` ne daje nikakva jamstva o svom rasporedu memorije (uključujući redoslijed polja).
///
/// `Vec` nikada neće izvesti "small optimization" gdje su elementi zapravo pohranjeni na stogu iz dva razloga:
///
/// * To bi otežavalo nesigurnom kodu da pravilno manipulira `Vec`.Sadržaj `Vec` ne bi imao stabilnu adresu da je samo premješten, a bilo bi teže odrediti je li `Vec` stvarno dodijelio memoriju.
///
/// * To bi kaznilo opći slučaj, uzrokujući dodatni branch na svaki pristup.
///
/// `Vec` nikada se neće automatski smanjiti, čak i ako je potpuno prazan.To osigurava da se ne dogodi nepotrebno dodjeljivanje ili razrješenje.Pražnjenje `Vec` i ponovno punjenje natrag do istog [`len`] ne bi trebalo izazvati pozive alokatoru.Ako želite osloboditi neiskorištenu memoriju, upotrijebite [`shrink_to_fit`] ili [`shrink_to`].
///
/// [`push`] i [`insert`] nikada (pre) neće dodijeliti ako je prijavljeni kapacitet dovoljan.[`push`] i [`insert`]*će*(ponovno) dodijeliti ako je [`len`]`==`[`kapacitet`].Odnosno, prijavljeni kapacitet potpuno je točan i na njega se može pouzdati.Po potrebi se može koristiti i za ručno oslobađanje memorije dodijeljene `Vec`.
/// Skupne metode umetanja *mogu* preraspodijeliti, čak i kada to nije potrebno.
///
/// `Vec` ne jamči nikakvu određenu strategiju rasta prilikom preraspodjele kad je puna, niti kada je pozvan [`reserve`].Trenutna strategija je osnovna i može se pokazati poželjnim koristiti nestalni faktor rasta.Kakva god strategija da se koristi, naravno jamči *O*(1) amortizirani [`push`].
///
/// `vec![x; n]`, Svi `vec![a, b, c, d]` i [`Vec::with_capacity(n)`][`Vec::with_capacity`] proizvest će `Vec` točno potrebnog kapaciteta.
/// Ako je [`len`]`==`[`kapacitet`], (kao što je slučaj za makronaredbu [`vec!`]), tada se `Vec<T>` može pretvoriti u i iz [`Box<[T]>`][owned slice] bez preraspodjele ili premještanja elemenata.
///
/// `Vec` neće izričito prebrisati bilo koji podatak koji je s njega uklonjen, ali ga također neće posebno sačuvati.Njegova neinicijalizirana memorija prostor je za ogrebotine koji može koristiti kako god želi.Obično će raditi samo ono što je najučinkovitije ili je na drugi način jednostavno implementirati.Ne oslanjajte se na to da će se uklonjeni podaci izbrisati iz sigurnosnih razloga.
/// Čak i ako ispustite `Vec`, njegov međuspremnik jednostavno može ponovno upotrijebiti drugi `Vec`.
/// Čak i ako prvo nulirate "Vec" memoriju, to se zapravo neće dogoditi jer optimizator to ne smatra nuspojavom koju treba sačuvati.
/// Međutim, postoji jedan slučaj koji nećemo razbiti: korištenje `unsafe` koda za pisanje na višak kapaciteta, a zatim povećanje duljine kako bi se podudaralo, uvijek vrijedi.
///
/// Trenutno `Vec` ne jamči redoslijedom ispuštanja elemenata.
/// Redoslijed se promijenio u prošlosti i može se ponovno promijeniti.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Inherentne metode
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Konstruira novi, prazni `Vec<T>`.
    ///
    /// vector se neće dodijeliti dok se na njega ne naguraju elementi.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Konstruira novi, prazni `Vec<T>` s navedenim kapacitetom.
    ///
    /// vector moći će držati točno `capacity` elemente bez preraspodjele.
    /// Ako je `capacity` 0, vector neće dodijeliti.
    ///
    /// Važno je napomenuti da iako vraćeni vector ima zadani *kapacitet*, vector će imati nultu *duljinu*.
    ///
    /// Za objašnjenje razlike između duljine i kapaciteta pogledajte *[Kapacitet i preraspodjela]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector ne sadrži predmete, iako ima kapacitet za više
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Sve se to radi bez preraspodjele ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ali ovo može vector preraspodijeliti
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Stvara `Vec<T>` izravno od sirovih komponenata drugog vector.
    ///
    /// # Safety
    ///
    /// Ovo je vrlo nesigurno, zbog broja invarijanata koji nisu provjereni:
    ///
    /// * `ptr` mora biti prethodno dodijeljen putem [`String`]/`Vec<T>`(barem će vrlo vjerojatno biti netočno ako nije).
    /// * `T` mora imati jednaku veličinu i poravnanje kao ono s čim je dodijeljen `ptr`.
    ///   (`T` s manje strogim poravnanjem nije dovoljan, poravnanje zaista mora biti jednako kako bi se udovoljio zahtjevu [`dealloc`] da memorija mora biti dodijeljena i oslobođena istim izgledom.)
    ///
    /// * `length` mora biti manji ili jednak `capacity`.
    /// * `capacity` mora biti kapacitet s kojim je pokazivač dodijeljen.
    ///
    /// Njihovo kršenje može uzrokovati probleme poput oštećenja internih struktura podataka dodjeljivača.Na primjer,**nije** sigurno graditi `Vec<u8>` od pokazivača do niza C `char` duljine `size_t`.
    /// Također nije sigurno izgraditi jedan od `Vec<u16>` i njegove duljine, jer je raspodjeljivaču stalo do poravnanja, a ove dvije vrste imaju različita poravnanja.
    /// Međuspremnik je dodijeljen s poravnanjem 2 (za `u16`), ali nakon pretvaranja u `Vec<u8>` bit će prebačen s poravnanjem 1.
    ///
    /// Vlasništvo nad `ptr` učinkovito se prenosi na `Vec<T>` koji tada može izvršiti oslobađanje, preraspodjelu ili promjenu sadržaja memorije na koji pokazuje pokazivač po volji.
    /// Osigurajte da ništa drugo ne koristi pokazivač nakon poziva ove funkcije.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Ažurirajte ovo kad se vec_into_raw_parts stabilizira.
    ///     // Spriječite pokretanje destruktora `v` tako da imamo potpunu kontrolu nad dodjelom.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Izvucite razne važne podatke o `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Prepišite memoriju s 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Vratite sve zajedno u Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Konstruira novi, prazni `Vec<T, A>`.
    ///
    /// vector se neće dodijeliti dok se na njega ne naguraju elementi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Konstruira novi, prazni `Vec<T, A>` zadanog kapaciteta s dodijeljenim raspodjeljivačem.
    ///
    /// vector moći će držati točno `capacity` elemente bez preraspodjele.
    /// Ako je `capacity` 0, vector neće dodijeliti.
    ///
    /// Važno je napomenuti da iako vraćeni vector ima zadani *kapacitet*, vector će imati nultu *duljinu*.
    ///
    /// Za objašnjenje razlike između duljine i kapaciteta pogledajte *[Kapacitet i preraspodjela]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector ne sadrži predmete, iako ima kapacitet za više
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Sve se to radi bez preraspodjele ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ali ovo može vector preraspodijeliti
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Stvara `Vec<T, A>` izravno od sirovih komponenata drugog vector.
    ///
    /// # Safety
    ///
    /// Ovo je vrlo nesigurno, zbog broja invarijanata koji nisu provjereni:
    ///
    /// * `ptr` mora biti prethodno dodijeljen putem [`String`]/`Vec<T>`(barem će vrlo vjerojatno biti netočno ako nije).
    /// * `T` mora imati jednaku veličinu i poravnanje kao ono s čim je dodijeljen `ptr`.
    ///   (`T` s manje strogim poravnanjem nije dovoljan, poravnanje zaista mora biti jednako kako bi se udovoljio zahtjevu [`dealloc`] da memorija mora biti dodijeljena i oslobođena istim izgledom.)
    ///
    /// * `length` mora biti manji ili jednak `capacity`.
    /// * `capacity` mora biti kapacitet s kojim je pokazivač dodijeljen.
    ///
    /// Njihovo kršenje može uzrokovati probleme poput oštećenja internih struktura podataka dodjeljivača.Na primjer,**nije** sigurno graditi `Vec<u8>` od pokazivača do niza C `char` duljine `size_t`.
    /// Također nije sigurno izgraditi jedan od `Vec<u16>` i njegove duljine, jer je raspodjeljivaču stalo do poravnanja, a ove dvije vrste imaju različita poravnanja.
    /// Međuspremnik je dodijeljen s poravnanjem 2 (za `u16`), ali nakon pretvaranja u `Vec<u8>` bit će prebačen s poravnanjem 1.
    ///
    /// Vlasništvo nad `ptr` učinkovito se prenosi na `Vec<T>` koji tada može izvršiti oslobađanje, preraspodjelu ili promjenu sadržaja memorije na koji pokazuje pokazivač po volji.
    /// Osigurajte da ništa drugo ne koristi pokazivač nakon poziva ove funkcije.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Ažurirajte ovo kad se vec_into_raw_parts stabilizira.
    ///     // Spriječite pokretanje destruktora `v` tako da imamo potpunu kontrolu nad dodjelom.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Izvucite razne važne podatke o `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Prepišite memoriju s 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Vratite sve zajedno u Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Razlaže `Vec<T>` na njegove sirove komponente.
    ///
    /// Vraća sirovi pokazivač na temeljne podatke, duljinu vector (u elementima) i dodijeljeni kapacitet podataka (u elementima).
    /// To su isti argumenti istim redoslijedom kao i argumenti [`from_raw_parts`].
    ///
    /// Nakon poziva ove funkcije, pozivatelj je odgovoran za memoriju kojom je ranije upravljao `Vec`.
    /// Jedini način da se to učini je pretvoriti sirovi pokazivač, duljinu i kapacitet natrag u `Vec` s funkcijom [`from_raw_parts`], omogućavajući destruktoru da izvede čišćenje.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Sada možemo napraviti promjene na komponentama, kao što je pretvaranje sirovog pokazivača u kompatibilni tip.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Razlaže `Vec<T>` na njegove sirove komponente.
    ///
    /// Vraća sirovi pokazivač na temeljne podatke, duljinu vector (u elementima), dodijeljeni kapacitet podataka (u elementima) i alokator.
    /// To su isti argumenti istim redoslijedom kao i argumenti [`from_raw_parts_in`].
    ///
    /// Nakon poziva ove funkcije, pozivatelj je odgovoran za memoriju kojom je ranije upravljao `Vec`.
    /// Jedini način da se to učini je pretvoriti sirovi pokazivač, duljinu i kapacitet natrag u `Vec` s funkcijom [`from_raw_parts_in`], omogućavajući destruktoru da izvede čišćenje.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Sada možemo napraviti promjene na komponentama, kao što je pretvaranje sirovog pokazivača u kompatibilni tip.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Vraća broj elemenata koje vector može sadržavati bez preraspodjele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Rezervira kapacitet za najmanje `additional` više elemenata koji će se umetnuti u zadani `Vec<T>`.
    /// Zbirka može rezervirati više prostora kako bi se izbjegle česte preraspodjele.
    /// Nakon pozivanja `reserve`, kapacitet će biti veći ili jednak `self.len() + additional`.
    /// Ne čini ništa ako je kapacitet već dovoljan.
    ///
    /// # Panics
    ///
    /// Panics ako novi kapacitet premašuje `isize::MAX` bajtova.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Rezervira minimalni kapacitet za točno `additional` dodatnih elemenata koji će se umetnuti u zadani `Vec<T>`.
    ///
    /// Nakon pozivanja `reserve_exact`, kapacitet će biti veći ili jednak `self.len() + additional`.
    /// Ne čini ništa ako je kapacitet već dovoljan.
    ///
    /// Imajte na umu da alokator zbirci može dati više prostora nego što zahtijeva.
    /// Stoga se ne može pouzdati da je kapacitet upravo minimalan.
    /// Dajte prednost `reserve` ako se očekuju umetanja future.
    ///
    /// # Panics
    ///
    /// Panics ako novi kapacitet pređe `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Pokušava rezervirati kapacitet za najmanje `additional` više elemenata koji će se umetnuti u zadani `Vec<T>`.
    /// Zbirka može rezervirati više prostora kako bi se izbjegle česte preraspodjele.
    /// Nakon pozivanja `try_reserve`, kapacitet će biti veći ili jednak `self.len() + additional`.
    /// Ne čini ništa ako je kapacitet već dovoljan.
    ///
    /// # Errors
    ///
    /// Ako se kapacitet prelije ili ako raspodijelivač prijavi kvar, vraća se pogreška.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Unaprijed rezervirajte memoriju, izađite ako ne možemo
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Sada znamo da ovo ne može OOM usred našeg složenog posla
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // vrlo komplicirano
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Pokušava rezervirati minimalni kapacitet za točno `additional` elemente koji će se umetnuti u zadani `Vec<T>`.
    /// Nakon pozivanja `try_reserve_exact`, kapacitet će biti veći ili jednak `self.len() + additional` ako vrati `Ok(())`.
    ///
    /// Ne čini ništa ako je kapacitet već dovoljan.
    ///
    /// Imajte na umu da alokator zbirci može dati više prostora nego što zahtijeva.
    /// Stoga se ne može pouzdati da je kapacitet upravo minimalan.
    /// Dajte prednost `reserve` ako se očekuju umetanja future.
    ///
    /// # Errors
    ///
    /// Ako se kapacitet prelije ili ako raspodijelivač prijavi kvar, vraća se pogreška.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Unaprijed rezervirajte memoriju, izađite ako ne možemo
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Sada znamo da ovo ne može OOM usred našeg složenog posla
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // vrlo komplicirano
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Smanjuje kapacitet vector što je više moguće.
    ///
    /// Smanjit će se što je moguće bliže duljini, ali raspodjeljivač će možda još uvijek obavijestiti vector da ima mjesta za još nekoliko elemenata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kapacitet nikad nije manji od duljine i nema ništa za napraviti kada su jednaki, tako da slučaj panic u `RawVec::shrink_to_fit` možemo izbjeći tako da ga nazovemo većim kapacitetom.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Smanjuje kapacitet vector s donjom granicom.
    ///
    /// Kapacitet će ostati barem toliko velik koliko i duljina i isporučena vrijednost.
    ///
    ///
    /// Ako je trenutni kapacitet manji od donje granice, to je ne-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Pretvara vector u [`Box<[T]>`][owned slice].
    ///
    /// Imajte na umu da će ovo smanjiti sav višak kapaciteta.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Ukloni se svaki višak kapaciteta:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Skraćuje vector, zadržavajući prve `len` elemente, a ispuštajući ostale.
    ///
    /// Ako je `len` veća od trenutne duljine vector, to nema učinka.
    ///
    /// Metoda [`drain`] može oponašati `truncate`, ali uzrokuje vraćanje viška elemenata umjesto ispuštanja.
    ///
    ///
    /// Imajte na umu da ova metoda nema utjecaja na dodijeljeni kapacitet vector.
    ///
    /// # Examples
    ///
    /// Skraćivanje pet elemenata vector na dva elementa:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Ne dolazi do kršenja kada je `len` veća od trenutne duljine vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Skraćivanje kada je `len == 0` ekvivalent pozivu metode [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Ovo je sigurno jer:
        //
        // * kriška proslijeđena `drop_in_place` vrijedi;slučaj `len > self.len` izbjegava stvaranje nevaljane kriške i
        // * `len` vector se smanjuje prije pozivanja `drop_in_place`, tako da niti jedna vrijednost neće biti ispuštena dva puta u slučaju da je `drop_in_place` jednom panic (ako je panics dva puta, program prekida).
        //
        //
        //
        unsafe {
            // Note: Namjerno je da je ovo `>`, a ne `>=`.
            //       Promjena u `>=` u nekim slučajevima ima negativne implikacije na performanse.
            //       Pogledajte #78884 za više.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Izdvaja krišku koja sadrži cijeli vector.
    ///
    /// Ekvivalentno `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Ekstrahira promjenjivu krišku cijelog vector.
    ///
    /// Ekvivalentno `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Vraća sirovi pokazivač na međuspremnik vector.
    ///
    /// Pozivatelj mora osigurati da vector nadživi pokazivač koji ova funkcija vraća, inače će na kraju ukazati na smeće.
    /// Izmjena vector može dovesti do preraspodjele njegovog međuspremnika, što bi također učinilo sve pokazivače na njega nevaljanim.
    ///
    /// Pozivatelj također mora osigurati da memorija na koju pokazuje pokazivač (non-transitively) nikada ne bude upisana (osim unutar `UnsafeCell`) pomoću ovog pokazivača ili bilo kojeg pokazivača izvedenog iz njega.
    /// Ako trebate mutirati sadržaj kriške, upotrijebite [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Sjenčamo istoimenu metodu kriške kako bismo izbjegli prolazak kroz `deref`, što stvara među referencu.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Vraća nesigurni promjenjivi pokazivač na međuspremnik vector.
    ///
    /// Pozivatelj mora osigurati da vector nadživi pokazivač koji ova funkcija vraća, inače će na kraju ukazati na smeće.
    ///
    /// Izmjena vector može dovesti do preraspodjele njegovog međuspremnika, što bi također učinilo sve pokazivače na njega nevaljanim.
    ///
    /// # Examples
    ///
    /// ```
    /// // Dodijelite vector dovoljno velik za 4 elementa.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inicijalizirajte elemente putem sirovih upisa pokazivača, a zatim postavite duljinu.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Sjenčamo istoimenu metodu kriške kako bismo izbjegli prolazak kroz `deref_mut`, što stvara među referencu.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Vraća referencu na osnovni alokator.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Prisiljava duljinu vector na `new_len`.
    ///
    /// Ovo je operacija na niskoj razini koja ne održava niti jednu normalnu invarijantu tipa.
    /// Obično se promjena duljine vector vrši umjesto korištenja jedne od sigurnih operacija, poput [`truncate`], [`resize`], [`extend`] ili [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` mora biti manji ili jednak [`capacity()`].
    /// - Elementi u `old_len..new_len` moraju se inicijalizirati.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Ova metoda može biti korisna u situacijama u kojima vector služi kao međuspremnik za drugi kôd, posebno preko FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ovo je samo minimalni kostur za primjer dokumenta;
    /// # // nemojte ovo koristiti kao početnu točku za pravu knjižnicu.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Prema dokumentima FFI metode, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SIGURNOST: Kada `deflateGetDictionary` vrati `Z_OK`, vrijedi sljedeće:
    ///     // 1. `dict_length` elementi su inicijalizirani.
    ///     // 2.
    ///     // `dict_length` <=kapacitet (32_768) što čini `set_len` sigurnim za pozivanje.
    ///     unsafe {
    ///         // Uputi FFI poziv ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... i ažurirajte duljinu na ono što je inicijalizirano.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Iako je sljedeći primjer zvuk, dolazi do curenja memorije jer unutarnji vectors nisu bili oslobođeni prije poziva `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` je prazan pa nijedan element nije potrebno inicijalizirati.
    /// // 2. `0 <= capacity` uvijek drži ono što `capacity` jest.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Obično bi se ovdje umjesto [`clear`] koristio za pravilno ispuštanje sadržaja i na taj način ne propuštanje memorije.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Uklanja element iz vector i vraća ga.
    ///
    /// Uklonjeni element zamjenjuje se posljednjim elementom vector.
    ///
    /// Ovo ne čuva narudžbu, ali je O(1).
    ///
    /// # Panics
    ///
    /// Panics ako je `index` izvan granica.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Zamjenjujemo self [indeks] posljednjim elementom.
            // Imajte na umu da ako gornja provjera granica uspije, mora postojati zadnji element (koji može biti sam self [index]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Umeće element u položaj `index` unutar vector, pomičući sve elemente nakon njega udesno.
    ///
    ///
    /// # Panics
    ///
    /// Panics ako je `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // prostor za novi element
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // nepogrešivo Mjesto za stavljanje nove vrijednosti
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Pomaknite sve kako biste napravili prostor.
                // (Umnožavanje elementa `index` na dva uzastopna mjesta.)
                ptr::copy(p, p.offset(1), len - index);
                // Upišite ga, prepisujući prvu kopiju elementa `indeksa`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Uklanja i vraća element na položaju `index` unutar vector, pomičući sve elemente nakon njega ulijevo.
    ///
    ///
    /// # Panics
    ///
    /// Panics ako je `index` izvan granica.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // mjesto s kojeg preuzimamo.
                let ptr = self.as_mut_ptr().add(index);
                // kopirajte ga, nesigurno imajući istovremeno kopiju vrijednosti na stogu i u vector.
                //
                ret = ptr::read(ptr);

                // Pomaknite sve prema dolje da popunite to mjesto.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Zadržava samo elemente navedene u predikatu.
    ///
    /// Drugim riječima, uklonite sve elemente `e` tako da `f(&e)` vrati `false`.
    /// Ova metoda djeluje na mjestu, posjećujući svaki element točno jednom u izvornom redoslijedu i čuva redoslijed zadržanih elemenata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Budući da se elementi posjećuju točno jednom u izvornom redoslijedu, vanjsko se stanje može koristiti za odlučivanje koje će se elemente zadržati.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Izbjegavajte dvostruko ispuštanje ako se zaštitni mehanizam ne izvrši, jer tijekom postupka možemo napraviti neke rupe.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-obrađena leća-> |^-pored provjere
        //                  | <-izbrisani cnt-> |
        //      | <-original_len-> |Zadržano: Elementi kojima se predikat vraća true.
        //
        // Rupa: Premješteni ili ispušteni utor elementa.
        // Neprovjereno: Neprovjereni važeći elementi.
        //
        // Ovaj će se zaštitnik od pada aktivirati kada se predikat ili `drop` elementa uspaniče.
        // Nekontrolirane elemente prebacuje na rupe i `set_len` na ispravnu duljinu.
        // U slučajevima kada se predikat i `drop` nikad ne uspaniče, optimizirat će se.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SIGURNOST: prateći neprovjereni predmeti moraju biti valjani jer ih nikada ne dodirujemo.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SIGURNOST: Nakon popunjavanja rupa, svi se predmeti nalaze u neprekidnoj memoriji.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SIGURNOST: Neoznačeni element mora biti valjan.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Napredujte kako biste izbjegli dvostruko ispuštanje ako se `drop_in_place` uspaniči.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SIGURNOST: Nikada više ne dodirujemo ovaj element nakon pada.
                unsafe { ptr::drop_in_place(cur) };
                // Već smo unaprijedili brojač.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SIGURNOST: `deleted_cnt`> 0, tako da se otvor za otvor ne smije preklapati s trenutnim elementom.
                // Za premještanje koristimo kopiju i nikada više ne dodirujemo ovaj element.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Sve stavke su obrađene.Ovo može LLVM optimizirati na `set_len`.
        drop(g);
    }

    /// Uklanja sve osim prvog uzastopnog elementa u vector koji se rješava na isti ključ.
    ///
    ///
    /// Ako je vector sortiran, to uklanja sve duplikate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Uklanja sve uzastopne elemente osim prvog u vector koji zadovoljavaju zadanu relaciju jednakosti.
    ///
    /// Funkciji `same_bucket` prosljeđuju se reference na dva elementa iz vector i ona mora utvrditi da li se elementi uspoređuju jednako.
    /// Elementi se prenose u suprotnom redoslijedu od njihovog redoslijeda u rezanju, pa ako `same_bucket(a, b)` vrati `true`, `a` se uklanja.
    ///
    ///
    /// Ako je vector sortiran, to uklanja sve duplikate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Dodaje element na poleđinu zbirke.
    ///
    /// # Panics
    ///
    /// Panics ako novi kapacitet premašuje `isize::MAX` bajtova.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // To će panic prekinuti ili će se prekinuti ako dodijelimo> isize::MAX bajtova ili ako se prirast duljine prelije za tipove nulte veličine.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Uklanja zadnji element iz vector i vraća ga, ili [`None`] ako je prazan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Premješta sve elemente `other` u `Self`, ostavljajući `other` praznim.
    ///
    /// # Panics
    ///
    /// Panics ako broj elemenata u vector prelazi `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Dodaje elemente u `Self` iz drugog međuspremnika.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Stvara odvodni iterator koji uklanja navedeni raspon u vector i daje uklonjene stavke.
    ///
    /// Kad padne iterator **, svi elementi u rasponu uklanjaju se iz vector, čak i ako iterator nije potrošen u potpunosti.
    /// Ako iterator **nije** ispušten (na primjer s [`mem::forget`]), nije određeno koliko je elemenata uklonjeno.
    ///
    /// # Panics
    ///
    /// Panics ako je početna točka veća od krajnje točke ili ako je krajnja točka veća od duljine vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Cijeli asortiman briše vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Sigurnost pamćenja
        //
        // Kada se Drain prvi put kreira, on skraćuje duljinu izvornog vector kako bi bio siguran da uopće nisu dostupni neinicijalizirani ili premješteni elementi ako destruktor Drain nikad ne bude pokrenut.
        //
        //
        // Drain će ptr::read izbaciti vrijednosti za uklanjanje.
        // Po završetku preostali rep veca se kopira natrag da pokrije rupu, a vector duljina se vraća na novu duljinu.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // postavite duljinu self.vec na početak, kako biste bili sigurni u slučaju curenja Drain
            self.set_len(start);
            // Upotrijebite posuđenicu u IterMutu da označite ponašanje posuđivanja cijelog iteratora Drain (poput &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Briše vector uklanjanjem svih vrijednosti.
    ///
    /// Imajte na umu da ova metoda nema utjecaja na dodijeljeni kapacitet vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Vraća broj elemenata u vector, koji se naziva i njegov 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Vraća `true` ako vector ne sadrži elemente.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Dijeli zbirku na dvoje pri zadanom indeksu.
    ///
    /// Vraća novo dodijeljeni vector koji sadrži elemente u rasponu `[at, len)`.
    /// Nakon poziva ostat će izvorni vector koji sadrži elemente `[0, at)` s prethodnim kapacitetom nepromijenjenim.
    ///
    ///
    /// # Panics
    ///
    /// Panics ako je `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // novi vector može preuzeti izvorni međuspremnik i izbjeći kopiju
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Nesigurno `set_len` i kopirajte stavke u `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Na mjestu mijenja veličinu `Vec` tako da je `len` jednak `new_len`.
    ///
    /// Ako je `new_len` veći od `len`, `Vec` se produžava za razliku, sa svakim dodatnim utorom ispunjenim rezultatom poziva na zatvaranje `f`.
    ///
    /// Povratne vrijednosti iz `f` završit će u `Vec` redoslijedom kojim su generirane.
    ///
    /// Ako je `new_len` manji od `len`, `Vec` se jednostavno skraćuje.
    ///
    /// Ova metoda koristi zatvaranje za stvaranje novih vrijednosti na svakom pritisku.Ako više volite [`Clone`] zadanu vrijednost, upotrijebite [`Vec::resize`].
    /// Ako želite koristiti [`Default`] Portrait za generiranje vrijednosti, možete dodati [`Default::default`] kao drugi argument.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Konzumira i propušta `Vec`, vraćajući promjenjivu referencu na sadržaj, `&'a mut [T]`.
    /// Imajte na umu da tip `T` mora nadživjeti izabrani vijek trajanja `'a`.
    /// Ako tip ima samo statičke reference ili ih uopće nema, tada se to može odabrati kao `'static`.
    ///
    /// Ova je funkcija slična funkciji [`leak`][Box::leak] na [`Box`], osim što ne postoji način da se obnovi procurila memorija.
    ///
    ///
    /// Ova je funkcija korisna uglavnom za podatke koji žive do kraja života programa.
    /// Ispuštanje vraćene reference uzrokovat će curenje memorije.
    ///
    /// # Examples
    ///
    /// Jednostavno korištenje:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Vraća preostali rezervni kapacitet vector kao dio `MaybeUninit<T>`.
    ///
    /// Vraćena kriška može se koristiti za popunjavanje vector podacima (npr
    /// čitanjem iz datoteke) prije označavanja podataka kao inicijaliziranih metodom [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Dodijelite vector dovoljno velik za 10 elemenata.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Ispunite prva 3 elementa.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Označi prva 3 elementa vector kao inicijalizirana.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ova metoda nije implementirana u smislu `split_at_spare_mut`, kako bi se spriječilo poništavanje pokazivača na međuspremnik.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Vraća sadržaj vector kao krišku `T`, zajedno s preostalim rezervnim kapacitetom vector kao krišku `MaybeUninit<T>`.
    ///
    /// Vraćena kriška slobodnog kapaciteta može se koristiti za popunjavanje vector podacima (npr. Čitanjem iz datoteke) prije nego što se podaci označe kao inicijalizirani metodom [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Imajte na umu da je ovo API niske razine koji bi se trebao pažljivo koristiti u svrhu optimizacije.
    /// Ako trebate dodati podatke na `Vec`, možete koristiti [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ili [`resize_with`], ovisno o vašim točnim potrebama.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Rezervirajte dodatni prostor dovoljno velik za 10 elemenata.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Ispunite sljedeća 4 elementa.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Označite 4 elementa vector kao inicijalizirana.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len se ignorira i tako se nikada nije promijenio
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sigurnost: promjena vraćenog .2 (&mut usize) smatra se istim kao pozivanje `.set_len(_)`.
    ///
    /// Ova metoda koristi se za jedinstveni pristup svim vec dijelovima odjednom u `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` zajamčeno vrijedi za `len` elemente
        // - `spare_ptr` usmjerava jedan element preko međuspremnika, tako da se ne preklapa s `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Na mjestu mijenja veličinu `Vec` tako da je `len` jednak `new_len`.
    ///
    /// Ako je `new_len` veći od `len`, `Vec` se produžava za razliku, sa svakim dodatnim utorom ispunjenim `value`.
    ///
    /// Ako je `new_len` manji od `len`, `Vec` se jednostavno skraćuje.
    ///
    /// Ova metoda zahtijeva da `T` implementira [`Clone`] kako bi mogao klonirati prosljeđenu vrijednost.
    /// Ako vam je potrebna veća fleksibilnost (ili se želite osloniti na [`Default`] umjesto na [`Clone`]), upotrijebite [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klonira i dodaje sve elemente u krišku na `Vec`.
    ///
    /// Interatira preko kriška `other`, klonira svaki element, a zatim ga dodaje ovom `Vec`.
    /// `other` vector prelazi se redoslijedom.
    ///
    /// Imajte na umu da je ova funkcija ista kao i [`extend`], osim što je specijalizirana za rad s kriškama.
    ///
    /// Ako i kada Rust dobije specijalizaciju, ova će funkcija vjerojatno biti zastarjela (ali i dalje dostupna).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopira elemente iz raspona `src` na kraj vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` jamči da zadani raspon vrijedi za samoindeksiranje
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ovaj kod generalizira `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Proširite vector za vrijednosti `n`, koristeći zadani generator.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Upotrijebite SetLenOnDrop za zaobilaženje bugova gdje kompajler možda neće shvatiti da pohrana kroz `ptr` do self.set_len() ne zamjenjuje.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Napišite sve elemente osim posljednjeg
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Povećavajte duljinu u svakom koraku u slučaju next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Posljednji element možemo izravno napisati bez kloniranja bez potrebe
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len postavljen stražom opsega
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Uklanja uzastopne ponovljene elemente u vector prema implementaciji [`PartialEq`] Portrait.
    ///
    ///
    /// Ako je vector sortiran, to uklanja sve duplikate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Interne metode i funkcije
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` mora biti važeći indeks
    /// - `self.capacity() - self.len()` mora biti `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len se povećava tek nakon inicijalizacije elemenata
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - pozivatelj jamči da je src valjani indeks
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element je upravo inicijaliziran s `MaybeUninit::write`, pa je u redu povećati ga
            // - leća se povećava nakon svakog elementa kako bi se spriječilo curenje (vidi izdanje #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - pozivatelj jamči da je `src` valjani indeks
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Oba pokazivača stvorena su od jedinstvenih referenci kriški (`&mut [_]`), tako da su valjane i ne preklapaju se.
            //
            // - Elementi su: Kopiraj, pa je u redu da ih kopirate, a da ne radite ništa s izvornim vrijednostima
            // - `count` je jednak leni `source`, tako da izvor vrijedi za `count` čitanja
            // - `.reserve(count)` jamči da `spare.len() >= count` tako rezervni vrijedi za `count` zapise
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elemente je upravo inicijalizirao `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Uobičajene implementacije Portrait za Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): s cfg(test) svojstvena metoda `[T]::to_vec`, koja je potrebna za definiciju ove metode, nije dostupna.
    // Umjesto toga upotrijebite funkciju `slice::to_vec` koja je dostupna samo s cfg(test) NB, pogledajte slice::hack modul u slice.rs za više informacija
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // ispustite sve što se neće prebrisati
        self.truncate(other.len());

        // self.len <= other.len zbog gornjeg odsječka, tako da su ovdje kriške uvijek u granicama.
        //
        let (init, tail) = other.split_at(self.len());

        // ponovno upotrijebite sadržane vrijednosti allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Stvara konzumirajući iterator, odnosno onaj koji pomiče svaku vrijednost iz vector (od početka do kraja).
    /// vector se ne može koristiti nakon poziva.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ima tip String, a ne &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // metoda lista na koju razne implementacije SpecFrom/SpecExtend delegiraju kada nemaju daljnje optimizacije za primjenu
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // To je slučaj s općim iteratorom.
        //
        // Ova bi funkcija trebala biti moralni ekvivalent:
        //
        //      za stavku u iteratoru {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Napomena se ne može prelijevati jer bismo morali dodijeliti adresni prostor
                self.set_len(len + 1);
            }
        }
    }

    /// Stvara iterator spajanja koji zamjenjuje navedeni raspon u vector s datim `replace_with` iteratorom i daje uklonjene stavke.
    ///
    /// `replace_with` ne mora biti iste dužine kao `range`.
    ///
    /// `range` uklanja se čak i ako se iterator ne potroši do kraja.
    ///
    /// Nije određeno koliko se elemenata uklanja iz vector ako procuri vrijednost `Splice`.
    ///
    /// Ulazni iterator `replace_with` troši se samo kada se padne vrijednost `Splice`.
    ///
    /// To je optimalno ako:
    ///
    /// * Rep (elementi u vector nakon `range`) je prazan,
    /// * ili `replace_with` daje manje ili jednakih elemenata od duljine `raspona`
    /// * ili je donja granica `size_hint()` točna.
    ///
    /// U suprotnom, dodjeljuje se privremeni vector i rep se pomiče dva puta.
    ///
    /// # Panics
    ///
    /// Panics ako je početna točka veća od krajnje točke ili ako je krajnja točka veća od duljine vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Stvara iterator koji koristi zatvaranje da utvrdi treba li element ukloniti.
    ///
    /// Ako se zatvaranje vrati true, tada se element uklanja i daje.
    /// Ako se zatvaranje vrati false, element će ostati u vector i iterator mu neće dati.
    ///
    /// Korištenje ove metode ekvivalentno je sljedećem kodu:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // vaš kod ovdje
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ali `drain_filter` je jednostavniji za upotrebu.
    /// `drain_filter` je također učinkovitiji, jer skupno može pomaknuti elemente niza.
    ///
    /// Imajte na umu da `drain_filter` također omogućuje mutiranje svakog elementa u zatvaranju filtra, bez obzira na to jeste li ga zadržali ili uklonili.
    ///
    ///
    /// # Examples
    ///
    /// Dijeljenje niza na nivelete i izglede, ponovna upotreba izvorne alokacije:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Čuvajte se da nam ne procuri (pojačanje curenja)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Proširite implementaciju koja kopira elemente iz referenci prije nego što ih gurnete na Vec.
///
/// Ova je implementacija specijalizirana za iteratore kriška, gdje koristi [`copy_from_slice`] za dodavanje cijele kriške odjednom.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Provodi usporedbu vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Provodi naručivanje vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // koristite pad za [T] koristite sirovu krišku kako biste elemente vector označili kao najslabiji potreban tip;
            //
            // mogao izbjeći pitanja valjanosti u određenim slučajevima
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec upravlja rješavanjem problema
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Stvara prazan `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test uvlači libstd, što ovdje uzrokuje pogreške
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test uvlači libstd, što ovdje uzrokuje pogreške
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Dobiva cjelokupni sadržaj `Vec<T>` kao niz, ako se njegova veličina točno podudara s veličinom traženog niza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Ako se duljina ne podudara, ulaz se vraća u `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ako ste u redu sa samo dobivanjem prefiksa `Vec<T>`, prvo možete nazvati [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SIGURNOST: `.set_len(0)` je uvijek zvuk.
        unsafe { vec.set_len(0) };

        // SIGURNOST: Pokazivač `Vec` uvijek je pravilno poravnan i
        // poravnanje koje treba niz je isto kao i stavke.
        // Ranije smo provjerili imamo li dovoljno predmeta.
        // Stavke se neće dvostruko ispuštati jer `set_len` kaže `Vec` da ih također ne ispušta.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}