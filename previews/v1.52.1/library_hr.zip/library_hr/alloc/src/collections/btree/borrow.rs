use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelira ponovno pokretanje neke jedinstvene reference, kada znate da se ponovna pozajmica i svi njezini potomci (tj. Svi pokazivači i reference izvedeni iz nje) više neće koristiti u nekom trenutku, nakon čega želite ponovno koristiti izvornu jedinstvenu referencu .
///
///
/// Provjera posudbe obično obrađuje ovo slaganje posuđenih stvari za vas, ali neki kontrolni tokovi koji ostvaruju ovo slaganje previše su složeni da bi ih kompajler mogao slijediti.
/// `DormantMutRef` omogućuje vam provjeru posudbe, istovremeno izražavajući njegovu složenu prirodu i enkapsulaciju sirovog koda pokazivača potrebnog za to bez nedefiniranog ponašanja.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Snimite jedinstvenu posudbu i odmah je ponovno posudite.
    /// Za kompajler je vijek trajanja nove reference jednak vijeku trajanja izvorne reference, ali promise ćete je koristiti kraće vrijeme.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SIGURNOST: posuđivanje držimo u cijelosti putem a `_marker` i izlažemo
        // samo ova referenca, pa je jedinstvena.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Vratite se na jedinstvenu posuđenu izvorno snimljenu.
    ///
    /// # Safety
    ///
    /// Ponovno posudba mora biti završena, tj. Referenca koju vraća `new` i svi pokazivači i reference izvedene iz nje, više se ne smiju koristiti.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SIGURNOST: vlastiti uvjeti sigurnosti podrazumijevaju da je ova referenca opet jedinstvena.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;