use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Dodaje sve parove ključ/vrijednost iz objedinjavanja dvaju uzlaznih iteratora, povećavajući `length` varijablu usput.Potonje olakšava pozivatelju da izbjegne curenje kad se rukovatelj padom uspaniči.
    ///
    /// Ako oba iteratora proizvode isti ključ, ova metoda ispušta par iz lijevog iteratora i dodaje par iz desnog iteratora.
    ///
    /// Ako želite da stablo završi u strogo rastućem redoslijedu, kao za `BTreeMap`, oba bi iteratora trebala proizvesti ključeve u strogo rastućem redoslijedu, svaki veći od svih ključeva na drvetu, uključujući sve ključeve koji se već nalaze u stablu pri ulasku.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Pripremamo se za spajanje `left` i `right` u razvrstani niz u linearnom vremenu.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // U međuvremenu iz sortiranog niza gradimo stablo u linearnom vremenu.
        self.bulk_push(iter, length)
    }

    /// Gura sve parove ključ/vrijednost na kraj stabla, uvećavajući `length` varijablu usput.
    /// Potonje olakšava pozivatelju da izbjegne curenje kad se iterator uspaniči.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Prelistajte sve parove ključ/vrijednost, gurajući ih u čvorove na pravoj razini.
        for (key, value) in iter {
            // Pokušajte ugurati par ključ/vrijednost u trenutni čvor lista.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Nema više mjesta, idite gore i gurnite tamo.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Pronašli smo čvor s preostalim prostorom, gurnite ovdje.
                                open_node = parent;
                                break;
                            } else {
                                // Idi opet gore.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Na vrhu smo, stvorimo novi korijenski čvor i gurnemo tamo.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Pritisnite par ključ/vrijednost i novo desno podstablo.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Ponovno se spustite na krajnji desni list.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Povećavajte duljinu svake iteracije kako biste bili sigurni da karta ispušta dodane elemente čak i ako napredovanje iteratora uspaniči.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterator za spajanje dviju razvrstanih sekvenci u jednu
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ako su dva ključa jednaka, vraća par ključ/vrijednost s desnog izvora.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}