// Ovo je pokušaj provedbe koja slijedi ideal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Budući da Rust zapravo nema ovisne tipove i polimorfnu rekurziju, snalazimo se s puno nesigurnosti.
//

// Glavni cilj ovog modula je izbjeći složenost tretiranjem stabla kao generičkog (ako je neobično oblikovanog) spremnika i izbjegavanjem postupanja s većinom B-Tree invarijanata.
//
// Kao takav, ovaj modul ne zanima jesu li unosi sortirani, koji čvorovi mogu biti nedovoljni ili čak što znači nedovoljno ispunjeni.Međutim, oslanjamo se na nekoliko invarijanata:
//
// - Drveće mora imati jednoliki depth/height.To znači da svaka staza do lista s određenog čvora ima potpuno jednaku duljinu.
// - Čvor duljine `n` ima tipke `n`, vrijednosti `n` i rubove `n + 1`.
//   To implicira da čak i prazan čvor ima barem jedan edge.
//   Za čvor krila, "having an edge" samo znači da možemo identificirati položaj u čvoru, jer su rubovi listova prazni i ne trebaju predstavljanje podataka.
// U internom čvoru, edge identificira položaj i sadrži pokazivač na podređeni čvor.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Osnovni prikaz čvorova lista i dio prikaza unutarnjih čvorova.
struct LeafNode<K, V> {
    /// Želimo biti kovarijantni u `K` i `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Indeks ovog čvora u nizu `edges` nadređenog čvora.
    /// `*node.parent.edges[node.parent_idx]` treba biti ista stvar kao i `node`.
    /// Zajamčeno je da će se inicijalizirati samo kada `parent` nije null.
    parent_idx: MaybeUninit<u16>,

    /// Broj ključeva i vrijednosti koje ovaj čvor pohranjuje.
    len: u16,

    /// Nizovi koji spremaju stvarne podatke čvora.
    /// Samo su prvi `len` elementi svakog polja inicijalizirani i valjani.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicijalizira novi `LeafNode` na mjestu.
    unsafe fn init(this: *mut Self) {
        // Kao opću politiku ostavljamo polja neinicijalizirana ako to mogu, jer bi to trebalo biti nešto brže i lakše pratiti u Valgrindu.
        //
        unsafe {
            // parent_idx, ključevi i vals svi su MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Stvara novi `LeafNode` u kutiji.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Temeljni prikaz unutarnjih čvorova.Kao i kod `LeafNode`-a, oni bi trebali biti skriveni iza`BoxedNode`-a kako bi se spriječilo ispuštanje neinicijaliziranih ključeva i vrijednosti.
/// Bilo koji pokazivač na `InternalNode` može se izravno lijevati u pokazivač na temeljni `LeafNode` dio čvora, omogućavajući kodu da generički djeluje na listove i unutarnje čvorove, a da uopće ne mora provjeriti na koje od ta dva pokazivača pokazuje.
///
/// Ovo je svojstvo omogućeno upotrebom `repr(C)`.
///
#[repr(C)]
// gdb_providers.py koristi ovaj naziv tipa za introspekciju.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Pokazivači na djecu ovog čvora.
    /// `len + 1` od njih se smatraju inicijaliziranim i važećim, osim što se pri kraju, dok se drvo drži putem posuđenog tipa `Dying`, neki od ovih pokazivača vise.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Stvara novi `InternalNode` u kutiji.
    ///
    /// # Safety
    /// Invarijant internih čvorova je da imaju barem jedan inicijalizirani i važeći edge.
    /// Ova funkcija ne postavlja takav edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Trebamo samo inicijalizirati podatke;rubovi su MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Upravljani, ne-null pokazivač na čvor.Ovo je ili pokazivač u vlasništvu na `LeafNode<K, V>` ili vlasnik pokazivača na `InternalNode<K, V>`.
///
/// Međutim, `BoxedNode` ne sadrži informacije o tome koji od ta dva tipa čvorova zapravo sadrži, a djelomično i zbog nedostatka informacija nije zaseban tip i nema destruktor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Korijenski čvor stabla u vlasništvu.
///
/// Imajte na umu da ovaj uređaj nema destruktor i mora se ručno očistiti.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Vraća novo stablo u vlasništvu, s vlastitim korijenskim čvorom koji je u početku prazan.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ne smije biti nula.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Promjenjivo posuđuje korijenski čvor u vlasništvu.
    /// Za razliku od `reborrow_mut`, ovo je sigurno jer se povratna vrijednost ne može koristiti za uništavanje korijena i ne mogu postojati druge reference na stablo.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Pomalo promjenjivo posuđuje korijenski čvor u vlasništvu.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nepovratno se prelazi na referencu koja dopušta prijelaz i nudi destruktivne metode i malo toga drugog.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Dodaje novi unutarnji čvor s jednim edge koji pokazuje na prethodni korijenski čvor, učini taj novi čvor korijenskim čvorom i vrati ga.
    /// To povećava visinu za 1 i suprotno je od `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, osim što smo jednostavno zaboravili da smo sada interni:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Uklanja unutarnji korijenski čvor, koristeći prvo podređeno tijelo kao novi korijenski čvor.
    /// Budući da je namijenjen pozivu samo kada korijenski čvor ima samo jedno dijete, ne vrši se čišćenje niti jedne tipke, vrijednosti i druge podređene jedinice.
    ///
    /// To smanjuje visinu za 1 i suprotno je od `push_internal_level`.
    ///
    /// Zahtijeva ekskluzivni pristup `Root` objektu, ali ne i korijenskom čvoru;
    /// neće poništiti druge ručke ili reference na korijenski čvor.
    ///
    /// Panics ako nema unutarnje razine, tj. Ako je korijenski čvor list.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SIGURNOST: tvrdili smo da smo interni.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SIGURNOST: posudili smo isključivo `self` i njegova vrsta posuđivanja je isključiva.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SIGURNOST: prvi se edge uvijek inicijalizira.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` je uvijek kovarijant u `K` i `V`, čak i kada je `BorrowType` `Mut`.
// To je tehnički pogrešno, ali ne može dovesti do nesigurnosti zbog interne upotrebe `NodeRef`, jer ostajemo potpuno generički u odnosu na `K` i `V`.
//
// Međutim, kad god javni tip zamota `NodeRef`, provjerite ima li ispravnu varijancu.
//
/// Referenca na čvor.
///
/// Ova vrsta ima niz parametara koji kontroliraju kako se ponaša:
/// - `BorrowType`: Lažni tip koji opisuje vrstu posuđivanja i traje cijeli život.
///    - Kada je ovo `Immut<'a>`, `NodeRef` djeluje otprilike poput `&'a Node`.
///    - Kada je ovo `ValMut<'a>`, `NodeRef` djeluje otprilike poput `&'a Node` s obzirom na ključeve i strukturu stabla, ali također omogućava koegzistiranje mnogih promjenjivih referenci na vrijednosti na cijelom stablu.
///    - Kada je ovo `Mut<'a>`, `NodeRef` djeluje otprilike poput `&'a mut Node`, iako metode umetanja omogućuju koegzistenciju promjenjivog pokazivača na vrijednost.
///    - Kada je ovo `Owned`, `NodeRef` djeluje otprilike poput `Box<Node>`, ali nema destruktor i mora se ručno očistiti.
///    - Kada je ovo `Dying`, `NodeRef` se i dalje ponaša otprilike poput `Box<Node>`, ali ima metode za uništavanje stabla malo po malo, a uobičajene metode, iako nisu označene kao nesigurne za pozivanje, mogu pozivati UB ako su pogrešno pozvane.
///
///   Budući da bilo koji `NodeRef` omogućuje navigaciju kroz stablo, `BorrowType` se učinkovito odnosi na cijelo stablo, a ne samo na sam čvor.
/// - `K` i `V`: To su vrste ključeva i vrijednosti pohranjene u čvorovima.
/// - `Type`: To može biti `Leaf`, `Internal` ili `LeafOrInternal`.
/// Kada je ovo `Leaf`, `NodeRef` pokazuje na čvor krila, kada je ovo `Internal`, `NodeRef` pokazuje na unutarnji čvor, a kada je ovo `LeafOrInternal`, `NodeRef` može ukazivati na bilo koju vrstu čvora.
///   `Type` naziva se `NodeType` kada se koristi izvan `NodeRef`.
///
/// I `BorrowType` i `NodeType` ograničavaju metode koje primjenjujemo kako bi iskoristili sigurnost statičkog tipa.Postoje ograničenja u načinu na koja možemo primijeniti takva ograničenja:
/// - Za svaki parametar tipa možemo definirati metodu samo generički ili za jedan određeni tip.
/// Na primjer, ne možemo definirati metodu poput `into_kv` generički za sve `BorrowType` ili jednom za sve tipove koji imaju životni vijek, jer želimo da vrati reference `&'a`.
///   Stoga ga definiramo samo za najsnažniji tip `Immut<'a>`.
/// - Ne možemo dobiti implicitnu prisilu od recimo `Mut<'a>` do `Immut<'a>`.
///   Stoga moramo izričito nazvati `reborrow` na moćnijem `NodeRef` kako bismo došli do metode poput `into_kv`.
///
/// Sve metode na `NodeRef` koje vraćaju neku vrstu reference, bilo:
/// - Uzmite `self` prema vrijednosti i vratite životni vijek koji nosi `BorrowType`.
///   Ponekad, da bismo se pozvali na takvu metodu, moramo nazvati `reborrow_mut`.
/// - Uzmite `self` po referenci, a (implicitly) vraća životni vijek te reference, umjesto životnog vijeka koji nosi `BorrowType`.
/// Na taj način, provjera posudbe jamči da `NodeRef` ostaje posuđen sve dok se koristi vraćena referenca.
///   Metode koje podržavaju umetak savijaju ovo pravilo vraćajući neobrađeni pokazivač, tj. Referencu bez ikakvog životnog vijeka.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Broj razina koje čvor i razina listova razdvajaju, konstanta čvora koju `Type` ne može u potpunosti opisati i koju čvor sam ne pohranjuje.
    /// Trebamo pohraniti samo visinu korijenskog čvora i iz njega izvesti visinu svakog drugog čvora.
    /// Mora biti nula ako je `Type` `Leaf` i nula ako je `Type` `Internal`.
    ///
    ///
    height: usize,
    /// Pokazivač na list ili unutarnji čvor.
    /// Definicija `InternalNode` osigurava da pokazivač vrijedi u bilo kojem slučaju.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Raspakirajte referencu čvora koji je pakiran kao `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Izlaže podatke unutarnjeg čvora.
    ///
    /// Vraća neobrađeni ptr kako bi se izbjeglo poništavanje drugih referenci na ovaj čvor.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SIGURNOST: tip statičkog čvora je `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Posuđuje ekskluzivni pristup podacima internog čvora.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Pronalazi duljinu čvora.Ovo je broj ključeva ili vrijednosti.
    /// Broj rubova je `len() + 1`.
    /// Imajte na umu da, iako je sigurno, pozivanje ove funkcije može imati nuspojavu poništavanja promjenjivih referenci koje je stvorio nesigurni kôd.
    ///
    pub fn len(&self) -> usize {
        // Ključno je što ovdje pristupamo samo polju `len`.
        // Ako je BorrowType marker::ValMut, možda postoje izvrsne izmjenjive reference na vrijednosti koje ne smijemo poništiti.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Vraća broj razina koje su čvor i listovi odvojeni.
    /// Nulta visina znači da je čvor sam list.
    /// Ako slikate stabla s korijenom na vrhu, broj govori na kojoj se nadmorskoj visini pojavljuje čvor.
    /// Ako zamislite drveće s lišćem na vrhu, broj govori koliko se visoko drvo proteže iznad čvora.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Privremeno uklanja drugu, nepromjenjivu referencu na isti čvor.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Otkriva dio lista bilo kojeg lista ili unutarnjeg čvora.
    ///
    /// Vraća neobrađeni ptr kako bi se izbjeglo poništavanje drugih referenci na ovaj čvor.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Čvor mora biti valjan barem za dio LeafNode.
        // Ovo nije referenca u tipu NodeRef jer ne znamo treba li biti jedinstvena ili dijeljena.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Pronalazi roditelja trenutnog čvora.
    /// Vraća `Ok(handle)` ako trenutni čvor stvarno ima nadređenog, gdje `handle` pokazuje na edge roditelja koji ukazuje na trenutni čvor.
    ///
    /// Vraća `Err(self)` ako trenutni čvor nema roditelja, vraća izvorni `NodeRef`.
    ///
    /// Naziv metode pretpostavlja da slikate stabla s korijenskim čvorom na vrhu.
    ///
    /// `edge.descend().ascend().unwrap()` i `node.ascend().unwrap().descend()` bi nakon uspjeha trebali učiniti ništa.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Moramo koristiti sirove pokazivače na čvorove jer, ako je BorrowType marker::ValMut, možda postoje izvanredne promjenjive reference na vrijednosti koje ne smijemo poništiti.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Imajte na umu da `self` ne smije biti prazan.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Imajte na umu da `self` ne smije biti prazan.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Otkriva dio lista bilo kojeg lista ili unutarnjeg čvora na nepromjenjivom stablu.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SIGURNOST: na ovom stablu ne mogu biti promjenjive reference posuđene kao `Immut`.
        unsafe { &*ptr }
    }

    /// Posuđuje pogled na tipke pohranjene u čvoru.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Slično kao kod `ascend`, dobiva referencu na roditeljski čvor čvora, ali ujedno i oslobađa trenutni čvor u procesu.
    /// To nije sigurno jer će trenutni čvor i dalje biti dostupan unatoč tome što je oslobođen.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Prevoditelju nesigurno tvrdi statične informacije da je ovaj čvor `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Prevoditelju nesigurno tvrdi statične informacije da je ovaj čvor `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Privremeno uklanja drugu, promjenjivu referencu na isti čvor.Pripazite, jer je ova metoda vrlo opasna, dvostruko jer se možda neće odmah učiniti opasnom.
    ///
    /// Budući da promjenjivi pokazivači mogu lutati bilo gdje oko stabla, vraćeni pokazivač lako se može koristiti kako bi izvorni pokazivač visio, izvan granica ili bio nevaljan prema složenim pravilima posuđivanja.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) razmislite o dodavanju još jednog parametra tipa u `NodeRef` koji ograničava upotrebu navigacijskih metoda na ponovno posuđenim pokazivačima, sprječavajući ovu nesigurnost.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Posuđuje ekskluzivan pristup dijelu lista bilo kojeg lista ili unutarnjeg čvora.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SIGURNOST: imamo ekskluzivan pristup cijelom čvoru.
        unsafe { &mut *ptr }
    }

    /// Nudi ekskluzivan pristup dijelu lista bilo kojeg lista ili unutarnjeg čvora.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SIGURNOST: imamo ekskluzivan pristup cijelom čvoru.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Posuđuje ekskluzivni pristup elementu područja za pohranu ključeva.
    ///
    /// # Safety
    /// `index` je u granicama od 0..KAPACITET
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SIGURNOST: pozivatelj neće moći samostalno pozvati daljnje metode
        // sve dok referenca ključnog odsječka ne padne, jer imamo jedinstveni pristup za vrijeme trajanja posuđivanja.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Posuđuje ekskluzivni pristup elementu ili odsječku područja za čuvanje vrijednosti čvora.
    ///
    /// # Safety
    /// `index` je u granicama od 0..KAPACITET
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SIGURNOST: pozivatelj neće moći samostalno pozvati daljnje metode
        // dok se referenca kriška vrijednosti ne izbaci, jer imamo jedinstveni pristup za vrijeme trajanja posuđivanja.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Posuđuje ekskluzivni pristup elementu ili dijelu područja za pohranu čvora za sadržaj edge.
    ///
    /// # Safety
    /// `index` je u granicama od 0..KAPACITET + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SIGURNOST: pozivatelj neće moći samostalno pozvati daljnje metode
        // sve dok se referenca edge odsječka ne odbaci, jer imamo jedinstveni pristup za vrijeme trajanja posuđenog.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Čvor ima više od `idx` inicijaliziranih elemenata.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Stvaramo referencu samo na jedan element koji nas zanima, kako bismo izbjegli spajanje izvanrednih referenci na druge elemente, posebno one vraćene pozivatelju u ranijim iteracijama.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Moramo se prisiliti na pokazivače na niz veličine zbog Rust izdanja #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Posuđuje ekskluzivni pristup duljini čvora.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Postavlja vezu čvora na nadređeni edge, bez nevaljanja drugih referenci na čvor.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Briše korijensku vezu do nadređenog edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Dodaje par ključ/vrijednost na kraj čvora.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Svaka stavka koju vrati `range` valjani je edge indeks za čvor.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Dodaje par ključ/vrijednost i edge da ide desno od tog para, na kraj čvora.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Provjerava je li čvor čvor `Internal` ili čvor `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Referenca na određeni par ključ/vrijednost ili edge unutar čvora.
/// Parametar `Node` mora biti `NodeRef`, dok `Type` može biti `KV` (označava ručicu na paru ključ/vrijednost) ili `Edge` (označava ručicu na edge).
///
/// Imajte na umu da čak i `Leaf` čvorovi mogu imati `Edge` ručke.
/// Umjesto da predstavljaju pokazivač na podređeni čvor, oni predstavljaju prostore gdje bi podređeni pokazivači išli između parova ključ/vrijednost.
/// Na primjer, u čvoru duljine 2 postojala bi 3 moguća mjesta edge, jedno s lijeve strane čvora, jedno između dva para i jedno s desne strane čvora.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Ne treba nam puna općenitost `#[derive(Clone)]`, jer će jedini put kada će `Node` biti `Clone` moguće kada je nepromjenjiva referenca, a samim tim i `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Dohvaća čvor koji sadrži edge ili par ključ/vrijednost na koji upućuje ova ručka.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Vraća položaj ove ručke u čvoru.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Stvara novu ručicu za par ključ/vrijednost u `node`.
    /// Nesigurno jer pozivatelj mora osigurati da `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Može biti javna implementacija PartialEq-a, ali koristi se samo u ovom modulu.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Privremeno vadi drugu, nepromjenjivu ručku na istom mjestu.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ne možemo koristiti Handle::new_kv ili Handle::new_edge jer ne znamo svoj tip
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Prevoditelju nesigurno tvrdi statične informacije da je čvor ručice `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Privremeno vadi drugu, promjenjivu ručku na istom mjestu.
    /// Pripazite, jer je ova metoda vrlo opasna, dvostruko jer se možda neće odmah učiniti opasnom.
    ///
    ///
    /// Za detalje pogledajte `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ne možemo koristiti Handle::new_kv ili Handle::new_edge jer ne znamo svoj tip
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Stvara novu ručicu za edge u `node`.
    /// Nesigurno jer pozivatelj mora osigurati da `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// S obzirom na indeks edge gdje ga želimo umetnuti u čvor ispunjen do zadnjeg mjesta, izračunava osjetljivi KV indeks točke razdvajanja i gdje izvršiti umetanje.
///
/// Cilj točke razdvajanja je da njegov ključ i vrijednost završe u nadređenom čvoru;
/// tipke, vrijednosti i rubovi lijevo od točke razdvajanja postaju lijevo dijete;
/// tipke, vrijednosti i rubovi desno od točke razdvajanja postaju pravo dijete.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust izdanje #74834 pokušava objasniti ova simetrična pravila.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Umeće novi par ključ/vrijednost između parova ključ/vrijednost s desne i lijeve strane ovog edge.
    /// Ova metoda pretpostavlja da u čvoru ima dovoljno prostora da stane novi par.
    ///
    /// Vraćeni pokazivač pokazuje na umetnutu vrijednost.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Umeće novi par ključ/vrijednost između parova ključ/vrijednost s desne i lijeve strane ovog edge.
    /// Ova metoda dijeli čvor ako nema dovoljno mjesta.
    ///
    /// Vraćeni pokazivač pokazuje na umetnutu vrijednost.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ispravlja roditeljski pokazivač i indeks u podređenom čvoru na koji se povezuje ovaj edge.
    /// Ovo je korisno kada se promijeni redoslijed rubova,
    fn correct_parent_link(self) {
        // Stvorite backpointer bez poništavanja drugih referenci na čvor.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Umeće novi par ključ/vrijednost i edge koji će ići desno od tog novog para između ovog edge i para ključ/vrijednost desno od ovog edge.
    /// Ova metoda pretpostavlja da u čvoru ima dovoljno prostora da stane novi par.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Umeće novi par ključ/vrijednost i edge koji će ići desno od tog novog para između ovog edge i para ključ/vrijednost desno od ovog edge.
    /// Ova metoda dijeli čvor ako nema dovoljno mjesta.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Umeće novi par ključ/vrijednost između parova ključ/vrijednost s desne i lijeve strane ovog edge.
    /// Ova metoda dijeli čvor ako nema dovoljno mjesta i pokušava rekurzivno umetnuti odijeljeni dio u roditeljski čvor dok se ne postigne korijen.
    ///
    ///
    /// Ako je vraćeni rezultat `Fit`, čvor njegove ručke može biti čvor ovog edge ili predak.
    /// Ako je vraćeni rezultat `Split`, polje `left` bit će korijenski čvor.
    /// Vraćeni pokazivač pokazuje na umetnutu vrijednost.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Pronalazi čvor na koji ukazuje ovaj edge.
    ///
    /// Naziv metode pretpostavlja da slikate stabla s korijenskim čvorom na vrhu.
    ///
    /// `edge.descend().ascend().unwrap()` i `node.ascend().unwrap().descend()` bi nakon uspjeha trebali učiniti ništa.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Moramo koristiti sirove pokazivače na čvorove jer, ako je BorrowType marker::ValMut, možda postoje izvanredne promjenjive reference na vrijednosti koje ne smijemo poništiti.
        // Pristup polju visine bez brige je jer se ta vrijednost kopira.
        // Imajte na umu da, nakon što se dereferencira pokazivač čvora, pristupimo nizu rubova s referencom (Rust izdanje #73987) i poništimo sve druge reference na ili unutar polja, ako ih ima.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ne možemo pozvati zasebne metode ključa i vrijednosti, jer pozivanje drugog poništava referencu koju je vratila prva.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Zamijenite ključ i vrijednost na koje se odnosi KV ručka.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Pomaže u implementacijama `split` za određeni `NodeType`, brinući se o podacima o listovima.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Podijeli osnovni čvor na tri dijela:
    ///
    /// - Čvor je skraćen da sadrži samo parove ključ/vrijednost lijevo od ove ručke.
    /// - Izdvajaju se ključ i vrijednost na koje ukazuje ova ručka.
    /// - Svi parovi ključ/vrijednost s desne strane ove ručice stavljaju se u novo dodijeljeni čvor.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Uklanja par ključ/vrijednost na koji ukazuje ova ručka i vraća ga, zajedno sa edge u koji se par ključ/vrijednost srušio.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Podijeli osnovni čvor na tri dijela:
    ///
    /// - Čvor je skraćen da sadrži samo rubove i parove ključ/vrijednost lijevo od ove ručke.
    /// - Izdvajaju se ključ i vrijednost na koje ukazuje ova ručka.
    /// - Svi rubovi i parovi ključ/vrijednost s desne strane ove ručice stavljaju se u novo dodijeljeni čvor.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Predstavlja sesiju za procjenu i izvođenje operacije uravnoteženja oko unutarnjeg para ključ/vrijednost.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Odabire kontekst uravnoteženja koji uključuje čvor kao dijete, dakle između KV neposredno lijevo ili desno u roditeljskom čvoru.
    /// Vraća `Err` ako nema roditelja.
    /// Panics ako je roditelj prazan.
    ///
    /// Preferira lijevu stranu, da bi bila optimalna ako je dati čvor nekako nedovoljno ispunjen, što ovdje znači samo da ima manje elemenata od svog lijevog brata i od desnog brata, ako oni postoje.
    /// U tom je slučaju spajanje s lijevim bratom ili sestrom brže, jer trebamo samo premjestiti N elemenata čvora, umjesto da ih pomaknemo udesno i pomaknemo više od N elemenata ispred.
    /// Krađa s lijevog brata ili sestre također je obično brža, jer trebamo samo pomaknuti N elemenata čvora udesno, umjesto da barem N elemenata brata i sestre pomaknemo ulijevo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Vraća je li moguće spajanje, tj. Ima li dovoljno mjesta u čvoru za kombiniranje središnjeg KV s oba susjedna podređena čvora.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Izvodi spajanje i dopušta zatvaranje da odluči što će se vratiti.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SIGURNOST: visina čvorova koji se spajaju jedna je ispod visine
                // čvora ovog edge, dakle iznad nule, pa su unutarnji.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Spaja roditeljski par ključ/vrijednost i oba susjedna podređena čvora u lijevi podređeni čvor i vraća skupljeni roditeljski čvor.
    ///
    ///
    /// Panics, osim ako nismo `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Spaja roditeljski par ključ/vrijednost i oba susjedna podređena čvora u lijevi podređeni čvor i vraća taj podređeni čvor.
    ///
    ///
    /// Panics, osim ako nismo `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Spaja roditeljski par ključ/vrijednost i oba susjedna podređena čvora u lijevi podređeni čvor i vraća hvataljku edge u tom podređenom čvoru gdje je praćeno dijete edge završilo,
    ///
    ///
    /// Panics, osim ako nismo `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Uklanja par ključ/vrijednost s lijevog djeteta i smješta ga u spremište ključ/vrijednost roditelja, dok stari roditeljski par ključ/vrijednost gura u desno dijete.
    ///
    /// Vraća ručicu edge u desnom podređenom dijelu koji odgovara mjestu gdje je završio izvorni edge naveden u `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Uklanja par ključ/vrijednost s desnog djeteta i smješta ga u spremište ključ/vrijednost roditelja, dok stari roditeljski par ključ/vrijednost gura na lijevo dijete.
    ///
    /// Vraća ručku edge u lijevom podređenom djetetu navedenom od `track_left_edge_idx`, a koje se nije pomaknulo.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// To krade slično `steal_left`, ali krade više elemenata odjednom.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pobrinite se da možemo sigurno krasti.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Premještanje podataka o lišću.
            {
                // Napravite mjesta za ukradene elemente u pravom djetetu.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Premjestite elemente s lijevog djeteta na desno.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Premjestite najkraći lijevi par roditelju.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Premjestite roditeljski par ključ/vrijednost na desno dijete.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Napravite mjesta za ukradene rubove.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Ukrasti rubove.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Simetrični klon `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pobrinite se da možemo sigurno krasti.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Premještanje podataka o lišću.
            {
                // Premjestite najdesniji ukradeni par roditelju.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Premjestite roditeljski par ključ/vrijednost na lijevo dijete.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Premjestite elemente s desnog djeteta na lijevo.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Ispunite prazninu tamo gdje su nekada bili ukradeni elementi.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ukrasti rubove.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Ispunite prazninu tamo gdje su nekad bili ukradeni rubovi.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Uklanja sve statičke podatke koji tvrde da je ovaj čvor `Leaf` čvor.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Uklanja sve statičke podatke koji tvrde da je ovaj čvor `Internal` čvor.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Provjerava je li temeljni čvor čvor `Internal` ili čvor `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Premjestite sufiks nakon `self` s jednog čvora na drugi.`right` mora biti prazan.
    /// Prvi edge `right` ostaje nepromijenjen.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Rezultat umetanja, kada se čvor trebao proširiti izvan svojih mogućnosti.
pub struct SplitResult<'a, K, V, NodeType> {
    // Izmijenjeni čvor u postojećem stablu s elementima i rubovima koji pripadaju lijevo od `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Neki ključ i vrijednost su se razdvojili i umetnuli negdje drugdje.
    pub kv: (K, V),
    // U vlasništvu, nevezani, novi čvor s elementima i rubovima koji pripadaju desnoj strani `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Dopuštaju li reference čvorova ovog tipa posuđivanja prelazak na druge čvorove u stablu.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Prelazak nije potreban, to se događa pomoću rezultata `borrow_mut`.
        // Onemogućivanjem prelaska i samo stvaranjem novih referenci na korijene, znamo da je svaka referenca tipa `Owned` na korijenski čvor.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Umeće vrijednost u krišku inicijaliziranih elemenata praćenih jednim neinicijaliziranim elementom.
///
/// # Safety
/// Kriška ima više od `idx` elemenata.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Uklanja i vraća vrijednost iz kriška svih inicijaliziranih elemenata, ostavljajući iza sebe jedan neizostavljeni element.
///
///
/// # Safety
/// Kriška ima više od `idx` elemenata.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Pomiče elemente u križnom položaju `distance` ulijevo.
///
/// # Safety
/// Kriška ima najmanje `distance` elemenata.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Pomjera elemente u krišnom položaju `distance` udesno.
///
/// # Safety
/// Kriška ima najmanje `distance` elemenata.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Premješta sve vrijednosti s kriška inicijaliziranih elemenata na krišak neinicijaliziranih elemenata, ostavljajući za sobom `src` kao i sve neinicijalizirane.
///
/// Radi poput `dst.copy_from_slice(src)`, ali ne zahtijeva da `T` bude `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;