// rsbegin.o i rsend.o su takozvani "compiler runtime startup objects".
// Sadrže kôd potreban za ispravnu inicijalizaciju vremena izvođenja kompajlera.
//
// Kada se poveže izvršna ili dylib slika, sav korisnički kod i knjižnice su "sandwiched" između ove dvije objektne datoteke, tako da kod ili podaci iz rsbegin.o postaju prvi u odgovarajućim odjeljcima slike, dok kod i podaci iz rsend.o postaju posljednji.
// Ovaj se efekt može koristiti za postavljanje simbola na početak ili na kraj odjeljka, kao i za umetanje svih potrebnih zaglavlja ili podnožja.
//
// Imajte na umu da se stvarna ulazna točka modula nalazi u pokretačkom objektu C izvođenja (obično se naziva `crtX.o`), koji zatim poziva povratne pozive inicijalizacije ostalih runtime komponenata (registriranih putem još jednog posebnog odjeljka slike).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Označava početak odjeljka s informacijama o odvijanju okvira snopa
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Ogrebite prostor za unutarnje knjigovodstvo odvijača.
    // To je definirano kao `struct object` u $ GCC/odvijati-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Opustite info registration/deregistration rutine.
    // Pogledajte dokumente libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registrirajte informacije o odmotavanju prilikom pokretanja modula
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // poništi registraciju pri isključivanju
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Uobičajena registracija init/uninit za MinGW
    pub mod mingw_init {
        // MinGW-ovi startni objekti (crt0.o/dllcrt0.o) pozvat će globalne konstruktore u odjeljcima .ctors i .dtors prilikom pokretanja i izlaska.
        // U slučaju DLL-ova, to se radi kad se DLL učita i istovari.
        //
        // Veznik će sortirati odjeljke, što osigurava da se naši povratni pozivi nalaze na kraju popisa.
        // Budući da se konstruktori izvode u obrnutom redoslijedu, to osigurava da su naši povratni pozivi prvi i zadnji izvršeni.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C povratni pozivi za inicijalizaciju
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Povratni pozivi za završetak
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}