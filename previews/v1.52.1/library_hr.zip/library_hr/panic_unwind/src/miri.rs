//! Odmotavanje panics za Miri.
use alloc::boxed::Box;
use core::any::Any;

// Vrsta korisnog tereta koji Miri motor širi odmotavanjem za nas.
// Mora biti veličine pokazivača.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Vanjska funkcija koju je Miri osigurala za početak odmotavanja.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Korisni teret koji prosljeđujemo `miri_start_panic`-u bit će upravo argument koji dobivamo u donjem `cleanup`-u.
    // Dakle, samo ga jednom upakiramo, da dobijemo nešto veličine pokazivača.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Obnovite temeljni `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}