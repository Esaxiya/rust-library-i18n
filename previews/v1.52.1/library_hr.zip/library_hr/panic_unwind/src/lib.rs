//! Implementacija panics odmotavanjem gomile
//!
//! Ovaj crate je implementacija panics u Rust koristeći "most native" mehanizam za odmotavanje steka platforme za koju se kompilira.
//! Ovo se u biti trenutno kategorizira u tri segmenta:
//!
//! 1. MSVC ciljevi koriste SEH u datoteci `seh.rs`.
//! 2. Emscripten koristi C++ iznimke u datoteci `emcc.rs`.
//! 3. Svi ostali ciljevi koriste libunwind/libgcc u datoteci `gcc.rs`.
//!
//! Više dokumentacije o svakoj implementaciji može se naći u odgovarajućem modulu.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` se ne koristi s Miri, pa upozorenja o tišini.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust runtime pokrenuti objekti ovise o tim simbolima, pa ih učinite javnim.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Ciljevi koji ne podržavaju odmotavanje.
        // - arch=wasm32
        // - os=nema ("bare metal" ciljevi)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Upotrijebite Miri vrijeme izvođenja.
        // Još uvijek trebamo učitati i normalno uobičajeno vrijeme izvođenja, jer rustc očekuje da se od tamo definiraju određene lang stavke.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Upotrijebite stvarno vrijeme izvođenja.
        use real_imp as imp;
    }
}

extern "C" {
    /// Rukovatelj u libstd poziva se kada se panic objekt ispusti izvan `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Rukovatelj u libstd zove se kad se uhvati strana iznimka.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Ulazna točka za stvaranje iznimke, samo delegati za implementaciju specifičnu za platformu.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}