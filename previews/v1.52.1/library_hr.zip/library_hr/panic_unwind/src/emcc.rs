//! Odmotavanje za *emscripten* cilj.
//!
//! Dok se uobičajena implementacija odmotavanja Rust za platforme Unix direktno poziva na libunwind API-je, na Emscripten umjesto toga pozivamo C++ API-je za odmotavanje.
//! Ovo je samo korisnost jer Emscriptenovo vrijeme izvođenja uvijek implementira te API-je i ne provodi libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Ovo odgovara izgledu std::type_info u C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Vodeći bajt `\x01` ovdje je zapravo čarobni signal LLVM-u da *ne* primijeni bilo koje drugo rukovanje poput prefiksa sa znakom `_`.
    //
    //
    // Ovaj simbol je vtable koji koristi C++ `std::type_info`.
    // Objekti tipa `std::type_info`, deskriptori tipa, imaju pokazivač na ovu tablicu.
    // Na deskriptore tipa upućuju se gore definiranim C++ EH strukturama, a mi ih konstruiramo u nastavku.
    //
    // Imajte na umu da je stvarna veličina veća od 3 veličine, ali trebamo samo našu vtable da pokazuje na treći element.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info za klasu rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Obično bismo koristili .as_ptr().add(2), ali to ne funkcionira u kontekstu const.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Ovo namjerno ne koristi uobičajenu shemu mangling naziva, jer ne želimo da C++ može proizvesti ili uhvatiti Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // To je neophodno jer C++ kôd može zabilježiti naše izuzeće s std::exception_ptr i vratiti ga više puta, možda čak i u drugoj niti.
    //
    //
    caught: AtomicBool,

    // To treba biti opcija, jer životni vijek objekta slijedi semantiku C++ : kad catch_unwind pomakne Box izuzetak, i dalje mora objekt iznimke ostaviti u valjanom stanju jer će njegov destruktor i dalje pozivati __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try zapravo nam daje pokazivač na ovu strukturu.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Budući da cleanup() ne smije panic, mi samo prekidamo.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}