//! Biblioteka podrške za autore makronaredbi pri definiranju novih makronaredbi.
//!
//! Ova knjižnica, osigurana standardnom distribucijom, pruža tipove konzumirane u sučeljima proceduralno definiranih definicija makronaredbi, poput makronaredbi nalik funkciji `#[proc_macro]`, atributima makronaredbi `#[proc_macro_attribute]` i prilagođenim izvedbenim atributima `#[proc_macro_derive]`.
//!
//!
//! Pogledajte [the book] za više.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Utvrđuje je li proc_macro učinjen dostupnim trenutno pokrenutom programu.
///
/// Proc_macro crate namijenjen je samo upotrebi unutar implementacije proceduralnih makronaredbi.Sve funkcije u ovom crate panic ako se pozivaju izvan proceduralne makronaredbe, kao što je skripta gradnje ili jedinični test ili obična Rust binarna datoteka.
///
/// Uzimajući u obzir knjižnice Rust koje su dizajnirane da podržavaju i slučajeve korištenja makronaredbi i makronaredbe, `proc_macro::is_available()` pruža nepaničan način otkrivanja je li infrastruktura potrebna za upotrebu API-ja proc_macro trenutno dostupna.
/// Vraća true ako je pozvan iznutra proceduralne makronaredbe, false ako je pozvan iz bilo koje druge binarne datoteke.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Glavni tip koji pruža ovaj crate, predstavlja apstraktni tok tokens, ili, preciznije, slijed token stabala.
/// Tip pruža sučelja za iteraciju preko tih token stabala i, obratno, sakupljanje određenog broja token stabala u jedan tok.
///
///
/// Ovo je i ulaz i izlaz definicija `#[proc_macro]`, `#[proc_macro_attribute]` i `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Pogreška vraćena iz `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Vraća prazan `TokenStream` koji ne sadrži stabla token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Provjerava je li ovaj `TokenStream` prazan.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Pokušaji razbijanja niza u tokens i raščlanjivanje tih tokens u token tok.
/// Može propasti iz više razloga, na primjer, ako niz sadrži neuravnotežene graničnike ili znakove koji ne postoje u jeziku.
///
/// Svi tokens u raščlanjenom toku dobivaju `Span::call_site()` raspone.
///
/// NOTE: neke pogreške mogu uzrokovati panics umjesto vraćanja `LexError`.Zadržavamo pravo da ove pogreške kasnije promijenimo u `LexError`.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Napomena: most nudi samo `to_string`, na njemu implementirajte `fmt::Display` (obrnuto od uobičajenog odnosa između njih dvoje).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Ispisuje tok token kao niz koji bi trebao biti konvertibilan bez gubitaka natrag u isti tok token (modulo raspona), osim moguće `TokenTree: : Group`s s graničnicima `Delimiter::None` i negativnim numeričkim literalima.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ispisuje token u obliku prikladnom za ispravljanje pogrešaka.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Stvara token tok koji sadrži jedno token stablo.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Prikuplja niz token stabala u jedan tok.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// "flattening" operacija na token potocima, sakuplja token stabla iz više token tokova u jedan tok.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Koristite optimiziranu moguću implementaciju if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Pojedinosti o javnoj implementaciji za tip `TokenStream`, poput iteratora.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iterator preko `TokenTree`a`TokenStreama`.
    /// Iteracija je "shallow", npr. Iterator se ne ponavlja u odijeljene grupe i vraća cijele grupe kao token stabla.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` prihvaća proizvoljne tokens i proširuje se u `TokenStream` koji opisuje ulaz.
/// Na primjer, `quote!(a + b)` će stvoriti izraz koji, kada se procijeni, konstruira `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Poništavanje citiranja vrši se s `$` i funkcionira tako da se sljedeći ident prepozna kao nenavedeni pojam.
/// Za citiranje samog `$` upotrijebite `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Područje izvornog koda, zajedno s informacijama o proširenju makronaredbi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Stvara novi `Diagnostic` s danim `message` na rasponu `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Raspon koji se rješava na mjestu definicije makronaredbe.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Raspon poziva trenutne proceduralne makronaredbe.
    /// Identifikatori stvoreni s ovim rasponom riješit će se kao da su napisani izravno na mjestu makro poziva (higijena mjesta poziva), a drugi kôd na mjestu poziva makronaredbi također će se moći pozivati na njih.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Raspon koji predstavlja higijenu `macro_rules`, a ponekad se rješava na mjestu definicije makronaredbe (lokalne varijable, oznake, `$crate`), a ponekad na mjestu poziva makronaredbi (sve ostalo).
    ///
    /// Mjesto raspona preuzeto je s mjesta poziva.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Izvorna izvorna datoteka u koju upućuje ovaj raspon.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` za tokens u prethodnom proširenju makronaredbi iz kojeg je generiran `self`, ako postoji.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Raspon izvornog koda iz kojeg je generiran `self`.
    /// Ako ovaj `Span` nije generiran iz drugih proširenja makronaredbi, tada je povratna vrijednost ista kao `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Dobiva početni line/column u izvornoj datoteci za ovaj raspon.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Dobiva završetak line/column u izvornoj datoteci za ovaj raspon.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Stvara novi raspon koji obuhvaća `self` i `other`.
    ///
    /// Vraća `None` ako su `self` i `other` iz različitih datoteka.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Stvara novi raspon s istim informacijama o line/column kao i `self`, ali koji razrješava simbole kao da su na `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Stvara novi raspon s istim ponašanjem razlučivosti imena kao `self`, ali s line/column informacijama `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// U usporedbi s rasponima da se vidi jesu li jednaki.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Vraća izvorni tekst iza raspona.
    /// Ovo čuva izvorni izvorni kod, uključujući razmake i komentare.
    /// Rezultat vraća samo ako raspon odgovara stvarnom izvornom kodu.
    ///
    /// Note: Uočljivi rezultat makronaredbe trebao bi se oslanjati samo na tokens, a ne i na ovaj izvorni tekst.
    ///
    /// Rezultat ove funkcije je najbolji napor koji se koristi samo za dijagnostiku.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Ispisuje raspon u obliku prikladnom za otklanjanje pogrešaka.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Par linija-stupac koji predstavlja početak ili kraj `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Linija indeksirana 1 u izvornoj datoteci na kojoj raspon započinje ili završava (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0-indeksirani stupac (u znakovima UTF-8) u izvornoj datoteci na kojem raspon započinje ili završava (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Izvorna datoteka datog `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Dobiva put do ove izvorne datoteke.
    ///
    /// ### Note
    /// Ako je raspon koda pridružen ovom `SourceFile` generirao vanjski makronaredba, ova makronaredba, to možda nije stvarna staza u datotečnom sustavu.
    /// Upotrijebite [`is_real`] za provjeru.
    ///
    /// Također imajte na umu da čak i ako `is_real` vraća `true`, ako je `--remap-path-prefix` propušten u naredbenom retku, put kao što je zadani možda zapravo nije valjan.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Vraća `true` ako je ova izvorna datoteka stvarna izvorna datoteka i nije generirana eksternim proširenjem makronaredbe.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ovo je hakiranje dok se ne implementiraju interkratni rasponi i ne možemo imati stvarne izvorne datoteke za raspone generirane u vanjskim makronaredbama.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Pojedinačni token ili ograničeni slijed stabala token (npr. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Potok token okružen graničnicima zagrada.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identifikator.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Jedan interpunkcijski znak (`+`, `,`, `$` itd.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Doslovni znak (`'a'`), niz (`"hello"`), broj (`2.3`) itd.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Vraća raspon ovog stabla delegirajući na metodu `span` sadržanog token ili odvojenog toka.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfigurira raspon za *samo ovaj token*.
    ///
    /// Imajte na umu da ako je ovaj token `Group`, tada ova metoda neće konfigurirati raspon svakog od internih tokens, već će jednostavno prenijeti na `set_span` metodu svake varijante.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Ispisuje stablo token u obliku prikladnom za otklanjanje pogrešaka.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Svaki od njih ima ime u tipu struct u izvedenom otklanjanju pogrešaka, zato se ne zamarajte dodatnim slojem neizravnosti
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Napomena: most nudi samo `to_string`, na njemu implementirajte `fmt::Display` (obrnuto od uobičajenog odnosa između njih dvoje).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Ispisuje stablo token kao niz koji bi trebao biti konvertibilan bez gubitaka natrag u isto stablo token (modulo raspona), osim moguće `TokenTree: : Group`s s `Delimiter::None` graničnicima i negativnim numeričkim slovima.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ograničeni token tok.
///
/// `Group` interno sadrži `TokenStream` koji je okružen `Delimiterima`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Opisuje kako je ograničen slijed stabala token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Implicitni graničnik, koji se može, na primjer, pojaviti oko tokens koji dolazi iz "macro variable" `$var`.
    /// Važno je sačuvati prioritete operatora u slučajevima kao što je `$var * 3` gdje je `$var` `1 + 2`.
    /// Implicitni graničnici možda neće preživjeti kružno putovanje token toka kroz niz.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Stvara novi `Group` s danim graničnikom i token streamom.
    ///
    /// Ovaj konstruktor postavit će raspon za ovu skupinu na `Span::call_site()`.
    /// Da biste promijenili raspon, možete upotrijebiti donju metodu `set_span`.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Vraća graničnik ovog `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Vraća `TokenStream` od tokens koji su razgraničeni u ovom `Group`.
    ///
    /// Imajte na umu da vraćeni tok token ne uključuje gornji graničnik.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Vraća raspon graničnika ovog token toka, obuhvaćajući cijeli `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Vraća raspon koji pokazuje na početni graničnik ove grupe.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Vraća raspon koji pokazuje na završni graničnik ove grupe.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfigurira raspon za graničnike ove `Grupe`, ali ne i njezine unutarnje tokens.
    ///
    /// Ova metoda **neće** postaviti raspon svih unutarnjih tokens obuhvaćenih ovom skupinom, već će postaviti raspon graničnika tokens samo na razini `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Napomena: most nudi samo `to_string`, na njemu implementirajte `fmt::Display` (obrnuto od uobičajenog odnosa između njih dvoje).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ispisuje grupu kao niz koji bi trebao biti konvertibilan bez gubitaka natrag u istu grupu (modulo rasponi), osim moguće `TokenTree: : Group`s s graničnicima `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` je jedan interpunkcijski znak poput `+`, `-` ili `#`.
///
/// Operatori s više znakova poput `+=` predstavljeni su kao dva primjerka `Punct` s vraćenim različitim oblicima `Spacing`.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Bez obzira slijedi li `Punct` odmah drugi `Punct` ili slijedi li drugi token ili razmak.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// npr. `+` je `Alone` u `+ =`, `+ident` ili `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// npr. `+` je `Joint` u `+=` ili `'#`.
    /// Uz to, jednostruka navodnica `'` može se spojiti s identifikatorima kako bi oblikovala vijek trajanja `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Stvara novi `Punct` od zadanog znaka i razmaka.
    /// Argument `ch` mora biti važeći interpunkcijski znak koji jezik dopušta, u suprotnom će funkcija biti panic.
    ///
    /// Vraćeni `Punct` imat će zadani raspon `Span::call_site()` koji se može dalje konfigurirati dolje navedenom metodom `set_span`.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Vraća vrijednost ovog interpunkcijskog znaka kao `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Vraća razmak ovog interpunkcijskog znaka, naznačujući je li iza njega odmah slijedi drugi `Punct` u token streamu, tako da se potencijalno mogu kombinirati u operator s više znakova (`Joint`), ili slijedi neki drugi token ili razmak (`Alone`), tako da operator sigurno ima završeno.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Vraća raspon za ovaj interpunkcijski znak.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurirajte raspon za ovaj interpunkcijski znak.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Napomena: most nudi samo `to_string`, na njemu implementirajte `fmt::Display` (obrnuto od uobičajenog odnosa između njih dvoje).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ispisuje interpunkcijski znak kao niz koji bi trebao biti konvertibilan bez gubitaka natrag u isti znak.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Identifikator (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Stvara novi `Ident` s danim `string` kao i navedenim `span`.
    /// Argument `string` mora biti valjani identifikator koji jezik dopušta (uključujući ključne riječi, npr. `self` ili `fn`).U suprotnom, funkcija će biti panic.
    ///
    /// Imajte na umu da `span`, trenutno u rustc, konfigurira higijenske podatke za ovaj identifikator.
    ///
    /// Od ovog trenutka `Span::call_site()` se izričito uključuje u higijenu "call-site", što znači da će se identifikatori stvoreni s ovim rasponom rješavati kao da su napisani izravno na mjestu makro poziva, a drugi kôd na mjestu poziva makronaredbi moći će se pozivati na njih također.
    ///
    ///
    /// Kasniji rasponi poput `Span::def_site()` omogućit će prijavu za higijenu "definition-site", što znači da će se identifikatori stvoreni s ovim rasponom rješavati na mjestu definicije makronaredbe, a drugi kôd na mjestu poziva makronaredbi neće se moći na njih pozivati.
    ///
    /// Zbog trenutne važnosti higijene, ovaj konstruktor, za razliku od ostalih tokens, zahtijeva da se `Span` navede u gradnji.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Isto kao i `Ident::new`, ali stvara neobrađeni identifikator (`r#ident`).
    /// Argument `string` mora biti valjani identifikator koji jezik dopušta (uključujući ključne riječi, npr. `fn`).
    /// Ključne riječi korisne u segmentima puta (npr
    /// `self`, `super`) nisu podržani i uzrokovat će panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Vraća raspon ovog `Ident`, obuhvaćajući cijeli niz koji je vratio [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurira raspon ovog `Ident`, moguće mijenjajući njegov higijenski kontekst.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Napomena: most nudi samo `to_string`, na njemu implementirajte `fmt::Display` (obrnuto od uobičajenog odnosa između njih dvoje).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ispisuje identifikator kao niz koji bi se trebao konvertirati bez gubitaka natrag u isti identifikator.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Doslovni niz (`"hello"`), bajtni niz (`b"hello"`), znak (`'a'`), bajtni znak (`b'a'`), cijeli broj ili broj s pomičnim zarezom sa ili bez sufiksa (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Logički literali kao što su `true` i `false` ne pripadaju ovdje, oni su `Ident`ovi.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Stvara novi sufiksni cjelobrojni literal s navedenom vrijednošću.
        ///
        /// Ova će funkcija stvoriti cijeli broj poput `1u32` gdje je navedena cjelobrojna vrijednost prvi dio token, a integral je također sufiksiran na kraju.
        /// Doslovci stvoreni od negativnih brojeva možda neće preživjeti kružno putovanje kroz `TokenStream` ili nizove i mogu se podijeliti u dva tokens (`-` i pozitivni doslovni).
        ///
        ///
        /// Literali stvoreni ovom metodom prema zadanim postavkama imaju raspon `Span::call_site()`, koji se može konfigurirati pomoću donje metode `set_span`.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Stvara novi nesifiksni cjeloviti literal s navedenom vrijednošću.
        ///
        /// Ova će funkcija stvoriti cijeli broj poput `1` gdje je navedena cjelobrojna vrijednost prvi dio token.
        /// Na ovom token nije naveden nijedan sufiks, što znači da su pozivi poput `Literal::i8_unsuffixed(1)` ekvivalentni `Literal::u32_unsuffixed(1)`.
        /// Literali stvoreni od negativnih brojeva možda neće preživjeti rountripove kroz `TokenStream` ili nizove i mogu se podijeliti u dva tokens (`-` i pozitivni doslovni).
        ///
        ///
        /// Literali stvoreni ovom metodom prema zadanim postavkama imaju raspon `Span::call_site()`, koji se može konfigurirati pomoću donje metode `set_span`.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Stvara novi nesifiksni doslov s pomičnom zarezom.
    ///
    /// Ovaj je konstruktor sličan onima poput `Literal::i8_unsuffixed` gdje se vrijednost floata emitira izravno u token, ali se ne koristi sufiks, pa se kasnije može zaključiti da je `f64` u kompajleru.
    ///
    /// Literali stvoreni od negativnih brojeva možda neće preživjeti rountripove kroz `TokenStream` ili nizove i mogu se podijeliti u dva tokens (`-` i pozitivni doslovni).
    ///
    /// # Panics
    ///
    /// Ova funkcija zahtijeva da je navedeni float konačan, na primjer ako je beskonačan ili NaN, ova funkcija će panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Stvara novi sufiksni doslov s pomičnim zarezom.
    ///
    /// Ovaj konstruktor stvorit će literal poput `1.0f32` gdje je navedena vrijednost prethodni dio token, a `f32` sufiks token.
    /// Za ovaj token uvijek će se pretpostavljati da je `f32` u kompajleru.
    /// Literali stvoreni od negativnih brojeva možda neće preživjeti rountripove kroz `TokenStream` ili nizove i mogu se podijeliti u dva tokens (`-` i pozitivni doslovni).
    ///
    ///
    /// # Panics
    ///
    /// Ova funkcija zahtijeva da je navedeni float konačan, na primjer ako je beskonačan ili NaN, ova funkcija će panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Stvara novi nesifiksni doslov s pomičnom zarezom.
    ///
    /// Ovaj je konstruktor sličan onima poput `Literal::i8_unsuffixed` gdje se vrijednost floata emitira izravno u token, ali se ne koristi sufiks, pa se kasnije može zaključiti da je `f64` u kompajleru.
    ///
    /// Literali stvoreni od negativnih brojeva možda neće preživjeti rountripove kroz `TokenStream` ili nizove i mogu se podijeliti u dva tokens (`-` i pozitivni doslovni).
    ///
    /// # Panics
    ///
    /// Ova funkcija zahtijeva da je navedeni float konačan, na primjer ako je beskonačan ili NaN, ova funkcija će panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Stvara novi sufiksni doslov s pomičnim zarezom.
    ///
    /// Ovaj konstruktor stvorit će literal poput `1.0f64` gdje je navedena vrijednost prethodni dio token, a `f64` sufiks token.
    /// Za ovaj token uvijek će se pretpostavljati da je `f64` u kompajleru.
    /// Literali stvoreni od negativnih brojeva možda neće preživjeti rountripove kroz `TokenStream` ili nizove i mogu se podijeliti u dva tokens (`-` i pozitivni doslovni).
    ///
    ///
    /// # Panics
    ///
    /// Ova funkcija zahtijeva da je navedeni float konačan, na primjer ako je beskonačan ili NaN, ova funkcija će panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String doslovno.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Znak doslovno.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Doslovni niz bajta.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Vraća raspon koji obuhvaća ovaj doslovni.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurira raspon pridružen ovom doslovcu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Vraća `Span` koji je podskup `self.span()` koji sadrži samo izvorne bajtove u rasponu `range`.
    /// Vraća `None` ako je potencijalno skraćeni raspon izvan granica `self`.
    ///
    // FIXME(SergioBenitez): provjerite započinje li i završava li raspon bajtova na UTF-8 granici izvora.
    // u suprotnom, vjerojatno će se panic pojaviti negdje drugdje kad se ispiše izvorni tekst.
    // FIXME(SergioBenitez): korisnik ne može znati na što se zapravo `self.span()` preslikava, pa se ova metoda trenutno može nazvati samo slijepo.
    // Na primjer, `to_string()` za znak 'c' vraća "'\u{63}'";korisnik ne može znati je li izvorni tekst 'c' ili '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) nešto slično `Option::cloned`, ali za `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Napomena: most nudi samo `to_string`, na njemu implementirajte `fmt::Display` (obrnuto od uobičajenog odnosa između njih dvoje).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ispisuje doslovni kao niz koji bi trebao biti konvertibilan bez gubitaka natrag u isti (osim mogućeg zaokruživanja za pomične točke).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Praćeni pristup varijablama okoline.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Dohvatite varijablu okruženja i dodajte je za izgradnju podataka o ovisnosti.
    /// Sustav gradnje koji izvršava kompajler znat će da je varijabli pristupano tijekom kompilacije i moći će ponoviti izgradnju kad se vrijednost te varijable promijeni.
    ///
    /// Osim praćenja ovisnosti, ova bi funkcija trebala biti ekvivalentna `env::var` iz standardne knjižnice, osim što argument mora biti UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}