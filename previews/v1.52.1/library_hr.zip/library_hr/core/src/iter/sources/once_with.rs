use crate::iter::{FusedIterator, TrustedLen};

/// Stvara iterator koji lijeno generira vrijednost točno jednom pozivajući se na predviđeno zatvaranje.
///
/// To se obično koristi za prilagođavanje jednog generatora vrijednosti u [`chain()`] drugih vrsta iteracija.
/// Možda imate iterator koji pokriva gotovo sve, ali trebate dodatni poseban slučaj.
/// Možda imate funkciju koja radi na iteratorima, ali trebate obraditi samo jednu vrijednost.
///
/// Za razliku od [`once()`], ova će funkcija lijeno generirati vrijednost na zahtjev.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::iter;
///
/// // jedan je najusamljeniji broj
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // samo jedan, to je sve što smo dobili
/// assert_eq!(None, one.next());
/// ```
///
/// Povezivanje lanca s drugim iteratorom.
/// Recimo da želimo ponoviti svaku datoteku direktorija `.foo`, ali i konfiguracijsku datoteku,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // moramo pretvoriti iz iteratora DirEntry-a u iterator PathBufsa, pa koristimo map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // sada, naš iterator samo za našu konfiguracijsku datoteku
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // povezati dva iteratora u jedan veliki iterator
/// let files = dirs.chain(config);
///
/// // ovo će nam dati sve datoteke u .foo, kao i .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iterator koji daje jedan element tipa `A` primjenom predviđenog zatvarača `F: FnOnce() -> A`.
///
///
/// Ovaj `struct` kreira funkcija [`once_with()`].
/// Pogledajte dokumentaciju za više.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}