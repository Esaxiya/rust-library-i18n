use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Objekti koji imaju pojam *nasljednika* i *prethodnika* operacija.
///
/// Operacija *nasljednik* kreće se prema vrijednostima koje se uspoređuju veće.
/// Operacija *prethodnik* kreće se prema vrijednostima koje uspoređuju manje.
///
/// # Safety
///
/// Ovaj Portrait je `unsafe`, jer njegova primjena mora biti ispravna radi sigurnosti implementacija `unsafe trait TrustedLen`, a `unsafe` kôd inače može vjerovati da su rezultati korištenja ovog Portrait ispravni i da ispunjava navedene obveze.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Vraća broj koraka *nasljednika* potrebnih za prelazak iz `start` u `end`.
    ///
    /// Vraća `None` ako bi broj koraka prešao `usize` (ili je beskonačan ili ako `end` nikad ne bi bio dosegnut).
    ///
    ///
    /// # Invariants
    ///
    /// Za bilo koji `a`, `b` i `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` ako i samo ako `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` ako i samo ako `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` samo ako `a <= b`
    ///   * Posljedica: `steps_between(&a, &b) == Some(0)` ako i samo ako je `a == b`
    ///   * Imajte na umu da `a <= b` _not_ implicira `steps_between(&a, &b) != None`;
    ///     ovo je slučaj kada bi za dosezanje `b` bilo potrebno više od `usize::MAX` koraka
    /// * `steps_between(&a, &b) == None` ako `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Vraća vrijednost koja bi se dobila uzimajući *nasljednika*`self` `count` puta.
    ///
    /// Ako bi ovo preraslo raspon vrijednosti podržanih od `Self`, vraća `None`.
    ///
    /// # Invariants
    ///
    /// Za bilo koji `a`, `n` i `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Za bilo koji `a`, `n` i `m` gdje se `n + m` ne prelijeva:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Za bilo koji `a` i `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Vraća vrijednost koja bi se dobila uzimajući *nasljednika*`self` `count` puta.
    ///
    /// Ako bi ovo preraslo raspon vrijednosti podržanih od `Self`, ovoj je funkciji dopušteno panic, zamotavanje ili zasićenje.
    ///
    /// Predloženo ponašanje je prema panic kada su omogućene tvrdnje za otklanjanje pogrešaka, a za umotavanje ili zasićenje na drugi način.
    ///
    /// Nesigurni kôd ne bi se trebao oslanjati na ispravnost ponašanja nakon prelijevanja.
    ///
    /// # Invariants
    ///
    /// Za bilo koji `a`, `n` i `m`, gdje se ne dogodi prelijevanje:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Za bilo koji `a` i `n`, gdje se ne događa preljev:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Vraća vrijednost koja bi se dobila uzimajući *nasljednika*`self` `count` puta.
    ///
    /// # Safety
    ///
    /// Nedefinirano je ponašanje ove operacije da prelazi raspon vrijednosti podržanih od `Self`.
    /// Ako ne možete jamčiti da se to neće prelijevati, umjesto toga upotrijebite `forward` ili `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Za bilo koji `a`:
    ///
    /// * ako postoji `b` kao što je `b > a`, sigurno je nazvati `Step::forward_unchecked(a, 1)`
    /// * ako postoji `b`, `n` takav da je `steps_between(&a, &b) == Some(n)`, sigurno je nazvati `Step::forward_unchecked(a, m)` za bilo koji `m <= n`.
    ///
    ///
    /// Za bilo koji `a` i `n`, gdje se ne događa preljev:
    ///
    /// * `Step::forward_unchecked(a, n)` je ekvivalentan `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Vraća vrijednost koja bi se dobila uzimajući *prethodnika* od `self` `count` puta.
    ///
    /// Ako bi ovo preraslo raspon vrijednosti podržanih od `Self`, vraća `None`.
    ///
    /// # Invariants
    ///
    /// Za bilo koji `a`, `n` i `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Za bilo koji `a` i `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Vraća vrijednost koja bi se dobila uzimajući *prethodnika* od `self` `count` puta.
    ///
    /// Ako bi ovo preraslo raspon vrijednosti podržanih od `Self`, ovoj je funkciji dopušteno panic, zamotavanje ili zasićenje.
    ///
    /// Predloženo ponašanje je prema panic kada su omogućene tvrdnje za otklanjanje pogrešaka, a za umotavanje ili zasićenje na drugi način.
    ///
    /// Nesigurni kôd ne bi se trebao oslanjati na ispravnost ponašanja nakon prelijevanja.
    ///
    /// # Invariants
    ///
    /// Za bilo koji `a`, `n` i `m`, gdje se ne dogodi prelijevanje:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Za bilo koji `a` i `n`, gdje se ne događa preljev:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Vraća vrijednost koja bi se dobila uzimajući *prethodnika* od `self` `count` puta.
    ///
    /// # Safety
    ///
    /// Nedefinirano je ponašanje ove operacije da prelazi raspon vrijednosti podržanih od `Self`.
    /// Ako ne možete jamčiti da se to neće prelijevati, umjesto toga upotrijebite `backward` ili `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Za bilo koji `a`:
    ///
    /// * ako postoji `b` kao što je `b < a`, sigurno je nazvati `Step::backward_unchecked(a, 1)`
    /// * ako postoji `b`, `n` takav da je `steps_between(&b, &a) == Some(n)`, sigurno je nazvati `Step::backward_unchecked(a, m)` za bilo koji `m <= n`.
    ///
    ///
    /// Za bilo koji `a` i `n`, gdje se ne događa preljev:
    ///
    /// * `Step::backward_unchecked(a, n)` je ekvivalentan `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Oni se i dalje generiraju makronaredbama jer se cjelobrojni literali razlučuju na različite tipove.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SIGURNOST: pozivatelj mora jamčiti da se `start + n` neće prelijevati.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // SIGURNOST: pozivatelj mora jamčiti da se `start - n` neće prelijevati.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // U izgradnjama za otklanjanje pogrešaka okidajte panic pri preljevu.
            // Ovo bi trebalo potpuno optimizirati u verzijama izdanja.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Obavljajte zamotavanje matematike da biste omogućili npr `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // U izgradnjama za otklanjanje pogrešaka okidajte panic pri preljevu.
            // Ovo bi trebalo potpuno optimizirati u verzijama izdanja.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Obavljajte zamotavanje matematike da biste omogućili npr `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ovo se oslanja na $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ako je n izvan dosega, `unsigned_start + n` je također
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ako je n izvan dosega, `unsigned_start - n` je također
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ovo se oslanja na $i_narrower <=usize
                        //
                        // Lijevanje u veličinu proširuje širinu, ali zadržava znak.
                        // Upotrijebite wrapping_sub u isize prostoru i bacite na usize da biste izračunali razliku koja se možda ne uklapa u raspon izize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Omotavanje obrađuje slučajeve poput `Step::forward(-120_i8, 200) == Some(80_i8)`, iako je 200 izvan dometa i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Dodatak je preliven
                            }
                        }
                        // Ako je n izvan dosega npr
                        // u8, tada je veći nego što je čitav raspon za i8 širok pa `any_i8 + n` nužno prelijeva i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Omotavanje obrađuje slučajeve poput `Step::forward(-120_i8, 200) == Some(80_i8)`, iako je 200 izvan dometa i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Oduzimanje se prelijelo
                            }
                        }
                        // Ako je n izvan dosega npr
                        // u8, tada je veći nego što je čitav raspon za i8 širok pa `any_i8 - n` nužno prelijeva i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Ako je razlika prevelika za npr
                            // i128, također će biti prevelik za upotrebu s manje bitova.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SIGURNOST: res je važeći unicode skalar
            // (ispod 0x110000, a ne u 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SIGURNOST: res je važeći unicode skalar
        // (ispod 0x110000, a ne u 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SIGURNOST: pozivatelj mora jamčiti da se to neće prelijevati
        // raspon vrijednosti za char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SIGURNOST: pozivatelj mora jamčiti da se to neće prelijevati
            // raspon vrijednosti za char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // SIGURNOST: zbog prethodnog ugovora ovo je zajamčeno
        // od strane pozivatelja da bude valjani znak.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SIGURNOST: pozivatelj mora jamčiti da se to neće prelijevati
        // raspon vrijednosti za char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SIGURNOST: pozivatelj mora jamčiti da se to neće prelijevati
            // raspon vrijednosti za char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // SIGURNOST: zbog prethodnog ugovora ovo je zajamčeno
        // od strane pozivatelja da bude valjani znak.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SIGURNOST: upravo provjeren preduvjet
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SIGURNOST: upravo provjeren preduvjet
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Ovi makronaredbe generiraju `ExactSizeIterator` impulse za različite tipove raspona.
//
// * `ExactSizeIterator::len` je potreban da uvijek vrati točan `usize`, tako da nijedan raspon ne može biti duži od `usize::MAX`.
//
// * Za cjelobrojne tipove u `Range<_>` to je slučaj za tipove uže ili šire od `usize`.
//   Za cjelobrojne tipove u `RangeInclusive<_>` to je slučaj za tipove *strogo uži* od `usize`, jer npr
//   `(0..=u64::MAX).len()` bio bi `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // To su inkorektno prema gore navedenom obrazloženju, ali njihovo uklanjanje bila bi velika promjena jer su stabilizirani u Rust 1.0.0.
    // Tako npr
    // `(0..66_000_u32).len()` na primjer, kompajlirat će se bez pogrešaka i upozorenja na 16-bitnim platformama, ali i dalje daje pogrešan rezultat.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // To su inkorektno prema gore navedenom obrazloženju, ali njihovo uklanjanje bila bi velika promjena jer su stabilizirani u Rust 1.26.0.
    // Tako npr
    // `(0..=u16::MAX).len()` na primjer, kompajlirat će se bez pogrešaka i upozorenja na 16-bitnim platformama, ali i dalje daje pogrešan rezultat.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SIGURNOST: upravo provjeren preduvjet
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SIGURNOST: upravo provjeren preduvjet
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SIGURNOST: upravo provjeren preduvjet
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SIGURNOST: upravo provjeren preduvjet
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SIGURNOST: upravo provjeren preduvjet
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SIGURNOST: upravo provjeren preduvjet
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}