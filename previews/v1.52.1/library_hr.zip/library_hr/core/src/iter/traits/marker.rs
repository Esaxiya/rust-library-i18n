/// Iterator koji uvijek nastavlja s izdavanjem `None` kada se iscrpi.
///
/// Sljedeći poziv na stopljenom iteratoru koji je jednom vratio `None` zajamčeno je da će opet vratiti [`None`].
/// Ovaj Portrait trebali bi implementirati svi iteratori koji se tako ponašaju jer omogućuje optimizaciju [`Iterator::fuse()`].
///
///
/// Note: Općenito, ne biste trebali koristiti `FusedIterator` u generičkim granicama ako vam je potreban stopljeni iterator.
/// Umjesto toga, trebali biste samo pozvati [`Iterator::fuse()`] na iteratoru.
/// Ako je iterator već stopljen, dodatni [`Fuse`] omot neće biti dostupan bez kažnjavanja performansi.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterator koji izvještava o točnoj duljini pomoću size_hint.
///
/// Iterator izvještava o nagovještaju veličine gdje je točan (donja granica jednaka je gornjoj granici) ili je gornja granica [`None`].
///
/// Gornja granica mora biti [`None`] samo ako je stvarna duljina iteratora veća od [`usize::MAX`].
/// U tom slučaju, donja granica mora biti [`usize::MAX`], što rezultira [`Iterator::size_hint()`] od `(usize::MAX, None)`.
///
/// Iterator mora proizvesti točno onoliko elemenata koje je prijavio ili se razići prije nego što dođe do kraja.
///
/// # Safety
///
/// Ovaj Portrait mora se primijeniti samo kad se ugovor održi.
/// Potrošači ovog Portrait moraju pregledati gornju granicu [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iterator koji je prilikom odavanja predmeta uzeo barem jedan element iz temeljnog [`SourceIter`].
///
/// Pozivanje bilo koje metode koja unapređuje iterator, npr
/// [`next()`] ili [`try_fold()`], garantira da je za svaki korak maknuta barem jedna vrijednost osnovnog izvora iteratora i da se rezultat lanca iteratora može umetnuti na njegovo mjesto, pod pretpostavkom da strukturna ograničenja izvora dopuštaju takvo umetanje.
///
/// Drugim riječima, ovaj Portrait ukazuje na to da se iteracijski cjevovod može prikupiti na mjestu.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}