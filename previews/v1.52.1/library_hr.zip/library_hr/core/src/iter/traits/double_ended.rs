use crate::ops::{ControlFlow, Try};

/// Iterator u stanju dati elemente s oba kraja.
///
/// Nešto što implementira `DoubleEndedIterator` ima jednu dodatnu sposobnost u odnosu na nešto što implementira [`Iterator`]: mogućnost uzimanja `predmeta` s leđa, kao i s prednje strane.
///
///
/// Važno je napomenuti da i naprijed i natrag rade na istom rasponu i ne prelaze se: iteracija je gotova kad se sretnu u sredini.
///
/// Na sličan način kao protokol [`Iterator`], jednom kada `DoubleEndedIterator` vrati [`None`] s [`next_back()`], pozivajući ga opet, možda više nikada neće vratiti [`Some`].
/// [`next()`] i [`next_back()`] su u tu svrhu zamjenjivi.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Uklanja i vraća element s kraja iteratora.
    ///
    /// Vraća `None` kada više nema elemenata.
    ///
    /// Dokumenti [trait-level] sadrže više pojedinosti.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Elementi dobiveni metodama `DoubleEndedIterator` mogu se razlikovati od onih dobivenih metodama [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Elementi `n` unapređuju iterator sa stražnje strane.
    ///
    /// `advance_back_by` je obrnuta verzija [`advance_by`].Ova metoda željno će preskočiti `n` elemente počevši od straga pozivanjem [`next_back`] do `n` puta dok se ne naiđe na [`None`].
    ///
    /// `advance_back_by(n)` vratit će [`Ok(())`] ako iterator uspješno napreduje po elementima `n`, ili [`Err(k)`] ako se naiđe na [`None`], gdje je `k` broj elemenata kojima je iterator unaprijeđen prije nego što ponestane elemenata (tj.
    /// duljina iteratora).
    /// Imajte na umu da je `k` uvijek manji od `n`.
    ///
    /// Pozivanje `advance_back_by(0)` ne troši nikakve elemente i uvijek vraća [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // preskočen je samo `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Vraća `n`ti element s kraja iteratora.
    ///
    /// Ovo je u osnovi obrnuta verzija [`Iterator::nth()`].
    /// Iako kao i većina operacija indeksiranja, brojanje započinje od nule, pa `nth_back(0)` vraća prvu vrijednost s kraja, `nth_back(1)` drugu i tako dalje.
    ///
    ///
    /// Imajte na umu da će se potrošiti svi elementi između kraja i vraćenog elementa, uključujući vraćeni element.
    /// To također znači da će pozivanje `nth_back(0)` više puta na isti iterator vratiti različite elemente.
    ///
    /// `nth_back()` vratit će [`None`] ako je `n` veća ili jednaka duljini iteratora.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Pozivanje `nth_back()` više puta ne premotava iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Vraća se `None` ako ima manje od `n + 1` elemenata:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ovo je obrnuta verzija [`Iterator::try_fold()`]: uzima elemente koji počinju sa stražnje strane iteratora.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Budući da je došlo do kratkog spoja, preostali su elementi i dalje dostupni putem iteratora.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metoda iteratora koja smanjuje elemente iteratora na jednu, konačnu vrijednost, počevši od stražnje strane.
    ///
    /// Ovo je obrnuta verzija [`Iterator::fold()`]: uzima elemente koji počinju sa stražnje strane iteratora.
    ///
    /// `rfold()` uzima dva argumenta: početnu vrijednost i zatvaranje s dva argumenta: 'accumulator' i element.
    /// Zatvaranje vraća vrijednost koju bi akumulator trebao imati za sljedeću iteraciju.
    ///
    /// Početna vrijednost je vrijednost koju će akumulator imati na prvom pozivu.
    ///
    /// Nakon primjene ovog zatvarača na svaki element iteratora, `rfold()` vraća akumulator.
    ///
    /// Ova se operacija ponekad naziva 'reduce' ili 'inject'.
    ///
    /// Presavijanje je korisno kad god imate zbirku nečega i želite iz toga proizvesti jednu vrijednost.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // zbroj svih elemenata a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ovaj primjer gradi niz, počevši od početne vrijednosti i nastavljajući sa svakim elementom od stražnje strane do prednje strane:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Traži element iteratora sa stražnje strane koji zadovoljava predikat.
    ///
    /// `rfind()` uzima zatvarač koji vraća `true` ili `false`.
    /// Primjenjuje ovo zatvaranje na svaki element iteratora, počevši od kraja, a ako bilo koji od njih vrati `true`, tada `rfind()` vraća [`Some(element)`].
    /// Ako svi vrate `false`, vraća [`None`].
    ///
    /// `rfind()` je kratki spoj;drugim riječima, zaustavit će se obrada čim zatvaranje vrati `true`.
    ///
    /// Budući da `rfind()` uzima referencu, a mnogi iteratori prelaze preko referenci, to dovodi do moguće zbunjujuće situacije kada je argument dvostruka referenca.
    ///
    /// Ovaj efekt možete vidjeti u primjerima u nastavku, s `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Zaustavljanje na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // još uvijek možemo koristiti `iter`, jer ima više elemenata.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}