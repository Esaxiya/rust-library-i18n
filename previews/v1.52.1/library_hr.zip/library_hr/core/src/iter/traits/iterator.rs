// ignore-tidy-filelength Ova datoteka se gotovo isključivo sastoji od definicije `Iterator`.
// Ne možemo to podijeliti u više datoteka.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Sučelje za rad s iteratorima.
///
/// Ovo je glavni iterator Portrait.
/// Za više informacija o konceptu iteratora općenito, pogledajte [module-level documentation].
/// Konkretno, možda biste željeli znati kako [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Vrsta elemenata koji se ponavljaju.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Napreduje iterator i vraća sljedeću vrijednost.
    ///
    /// Vraća [`None`] kada je iteracija završena.
    /// Pojedinačne implementacije iteratora mogu odlučiti da nastave iteraciju, pa tako ponovno pozivanje `next()` u nekom trenutku može ili ne mora početi vraćati [`Some(Item)`].
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Poziv na next() vraća sljedeću vrijednost ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... i onda None nakon što završi.
    /// assert_eq!(None, iter.next());
    ///
    /// // Više poziva može i ne mora vratiti `None`.Evo, uvijek će.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Vraća granice preostale duljine iteratora.
    ///
    /// Konkretno, `size_hint()` vraća tuple gdje je prvi element donja granica, a drugi element gornja granica.
    ///
    /// Druga polovica korpice koja se vraća je [`Option`]`<`[`usize`] `>`.
    /// [`None`] ovdje znači da ili ne postoji poznata gornja granica, ili je gornja granica veća od [`usize`].
    ///
    /// # Napomene o provedbi
    ///
    /// Ne provodi se da implementacija iteratora daje deklarirani broj elemenata.Pogrešni iterator može dati manje od donje granice ili više od gornje granice elemenata.
    ///
    /// `size_hint()` namijenjen je prvenstveno korištenju za optimizacije kao što je rezerviranje prostora za elemente iteratora, ali ne smije mu se vjerovati da npr. izostavlja provjere granica u nesigurnom kodu.
    /// Neispravna implementacija `size_hint()` ne bi trebala dovesti do kršenja sigurnosti memorije.
    ///
    /// Međutim, implementacija bi trebala dati ispravnu procjenu, jer bi u protivnom predstavljala kršenje protokola Portrait.
    ///
    /// Zadana implementacija vraća `(0,` [`None`]`)`što je točno za bilo koji iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Složeniji primjer:
    ///
    /// ```
    /// // Parni brojevi od nule do deset.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Mogli bismo ponoviti od nule do deset puta.
    /// // Znanje da je točno pet ne bi bilo moguće bez izvršavanja filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Dodajmo još pet brojeva s chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // sada su obje granice povećane za pet
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Povratak `None` za gornju granicu:
    ///
    /// ```
    /// // beskonačni iterator nema gornju i najveću moguću donju granicu
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Potroši iterator, brojeći broj iteracija i vraćajući ga.
    ///
    /// Ova će metoda pozivati [`next`] više puta dok se ne naiđe na [`None`], vraćajući broj puta kada je vidio [`Some`].
    /// Imajte na umu da se [`next`] mora pozvati barem jednom, čak i ako iterator nema elemenata.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Ponašanje preljeva
    ///
    /// Metoda ne štiti od preljeva, pa brojanje elemenata iteratora s više od [`usize::MAX`] elemenata daje ili pogrešan rezultat ili panics.
    ///
    /// Ako su omogućene tvrdnje za otklanjanje pogrešaka, panic je zajamčen.
    ///
    /// # Panics
    ///
    /// Ova funkcija može panic ako iterator ima više od [`usize::MAX`] elemenata.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Konzumira iterator, vraća zadnji element.
    ///
    /// Ova metoda će procjenjivati iterator sve dok ne vrati [`None`].
    /// Pritom bilježi trenutni element.
    /// Nakon vraćanja [`None`], `last()` će vratiti zadnji element koji je vidio.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Napreduje iterator za `n` elemente.
    ///
    /// Ova metoda željno će preskočiti `n` elemente pozivajući [`next`] do `n` puta dok se ne naiđe na [`None`].
    ///
    /// `advance_by(n)` vratit će [`Ok(())`][Ok] ako iterator uspješno napreduje po elementima `n`, ili [`Err(k)`][Err] ako se naiđe na [`None`], gdje je `k` broj elemenata kojima je iterator unaprijeđen prije nego što ponestane elemenata (tj.
    /// duljina iteratora).
    /// Imajte na umu da je `k` uvijek manji od `n`.
    ///
    /// Pozivanje `advance_by(0)` ne troši nikakve elemente i uvijek vraća [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // preskočen je samo `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Vraća `n`ti element iteratora.
    ///
    /// Kao i većina operacija indeksiranja, brojanje započinje od nule, pa `nth(0)` vraća prvu vrijednost, `nth(1)` drugu i tako dalje.
    ///
    /// Imajte na umu da će se svi prethodni elementi, kao i vraćeni element, potrošiti iz iteratora.
    /// To znači da će prethodni elementi biti odbačeni, kao i da će pozivanje `nth(0)` više puta na isti iterator vratiti različite elemente.
    ///
    ///
    /// `nth()` vratit će [`None`] ako je `n` veća ili jednaka duljini iteratora.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Pozivanje `nth()` više puta ne premotava iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Vraća se `None` ako ima manje od `n + 1` elemenata:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Stvara iterator s početkom u istoj točki, ali korakom za zadani iznos na svakoj iteraciji.
    ///
    /// Napomena 1: Prvi element iteratora uvijek će se vratiti, bez obzira na zadani korak.
    ///
    /// Napomena 2: Vrijeme povlačenja zanemarenih elemenata nije fiksno.
    /// `StepBy` ponaša se poput niza `next(), nth(step-1), nth(step-1),…`, ali se također može ponašati poput niza
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Koji se način koristi može se promijeniti za neke iteratore iz razloga izvedbe.
    /// Drugi će način unaprijediti iterator ranije i možda će potrošiti više predmeta.
    ///
    /// `advance_n_and_return_first` je ekvivalent:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metoda će panic ako je zadani korak `0`.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Uzima dva iteratora i stvara novi iterator za oba u nizu.
    ///
    /// `chain()` vratit će novi iterator koji će prvo itirirati preko vrijednosti iz prvog iteratora, a zatim preko vrijednosti iz drugog iteratora.
    ///
    /// Drugim riječima, povezuje dva iteratora zajedno, u lanac.🔗
    ///
    /// [`once`] se obično koristi za prilagodbu jedne vrijednosti u lanac drugih vrsta iteracija.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Budući da argument za `chain()` koristi [`IntoIterator`], možemo proslijediti sve što se može pretvoriti u [`Iterator`], a ne samo u sam [`Iterator`].
    /// Na primjer, kriške (`&[T]`) implementiraju [`IntoIterator`] i tako se mogu izravno proslijediti na `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ako radite s API-jem Windows, možda ćete htjeti pretvoriti [`OsStr`] u `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Spaja dva' iteratora u jedan iterator parova.
    ///
    /// `zip()` vraća novi iterator koji će se itirirati preko dva druga iteratora, vraćajući tuple gdje prvi element dolazi iz prvog iteratora, a drugi element dolazi iz drugog iteratora.
    ///
    ///
    /// Drugim riječima, spaja dva iteratora u jedan.
    ///
    /// Ako bilo koji iterator vrati [`None`], [`next`] iz zipiranog iteratora vratit će [`None`].
    /// Ako prvi iterator vrati [`None`], `zip` će doći do kratkog spoja i `next` neće biti pozvan na drugom iteratoru.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Budući da argument za `zip()` koristi [`IntoIterator`], možemo proslijediti sve što se može pretvoriti u [`Iterator`], a ne samo u sam [`Iterator`].
    /// Na primjer, kriške (`&[T]`) implementiraju [`IntoIterator`] i tako se mogu izravno proslijediti na `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` često se koristi za spajanje beskonačnog iteratora u konačni.
    /// To djeluje jer će konačni iterator na kraju vratiti [`None`], završavajući patentni zatvarač.Komprimiranje s `(0..)` može izgledati slično [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Stvara novi iterator koji kopiju `separator` postavlja između susjednih stavki izvornog iteratora.
    ///
    /// U slučaju da `separator` ne implementira [`Clone`] ili ga treba izračunati svaki put, upotrijebite [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Prvi element iz `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separator.
    /// assert_eq!(a.next(), Some(&1));   // Sljedeći element iz `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separator.
    /// assert_eq!(a.next(), Some(&2));   // Posljednji element iz `a`.
    /// assert_eq!(a.next(), None);       // Iterator je gotov.
    /// ```
    ///
    /// `intersperse` može biti vrlo korisno pridružiti stavke iteratora koristeći zajednički element:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Stvara novi iterator koji postavlja stavku generiranu `separator` između susjednih stavki izvornog iteratora.
    ///
    /// Zatvaranje će se pozvati točno jednom svaki put kad se stavka stavi između dvije susjedne stavke iz temeljnog iteratora;
    /// konkretno, zatvaranje se ne poziva ako temeljni iterator daje manje od dvije stavke i nakon što se dobije posljednja stavka.
    ///
    ///
    /// Ako stavka iteratora implementira [`Clone`], možda će biti lakše koristiti [`intersperse`].
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Prvi element iz `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separator.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Sljedeći element iz `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separator.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Posljednji element iz `v`.
    /// assert_eq!(it.next(), None);               // Iterator je gotov.
    /// ```
    ///
    /// `intersperse_with` može se koristiti u situacijama kada treba izračunati separator:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Zatvaranje promjenjivo posuđuje svoj kontekst da bi generirao stavku.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Uzima zatvaranje i stvara iterator koji poziva to zatvaranje na svakom elementu.
    ///
    /// `map()` pretvara jedan iterator u drugi pomoću svog argumenta:
    /// nešto što implementira [`FnMut`].Izrađuje novi iterator koji poziva zatvaranje svakog elementa izvornog iteratora.
    ///
    /// Ako dobro razmišljate u tipovima, o `map()` možete razmišljati ovako:
    /// Ako imate iterator koji vam daje elemente neke vrste `A`, a želite iterator neke druge vrste `B`, možete upotrijebiti `map()`, prolazeći kroz zatvarač koji uzima `A` i vraća `B`.
    ///
    ///
    /// `map()` konceptualno je sličan petlji [`for`].Međutim, kako je `map()` lijen, najbolje ga je koristiti kada već radite s drugim iteratorima.
    /// Ako radite neku vrstu petlje radi nuspojave, idiomatičnije je koristiti [`for`] nego `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ako radite neku vrstu nuspojava, radije [`for`] umjesto `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ne radi ovo:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // neće ni izvršiti, jer je lijen.Rust će vas upozoriti na ovo.
    ///
    /// // Umjesto toga koristite za:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Poziva zatvaranje svakog elementa iteratora.
    ///
    /// To je ekvivalentno korištenju petlje [`for`] na iteratoru, iako `break` i `continue` nisu mogući iz zatvaranja.
    /// Općenito je idiomatičnije koristiti petlju `for`, ali `for_each` može biti čitljiviji pri obradi predmeta na kraju dužih iteratorskih lanaca.
    ///
    /// U nekim slučajevima `for_each` može biti i brži od petlje, jer će koristiti internu iteraciju na adapterima poput `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Za tako mali primjer, petlja `for` može biti čišća, ali možda bi bilo poželjnije da `for_each` zadrži funkcionalni stil s dužim iteratorima:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Stvara iterator koji koristi zatvaranje da utvrdi treba li dati element.
    ///
    /// S obzirom na element, zatvarač mora vratiti `true` ili `false`.Vraćeni iterator dat će samo elemente za koje zatvaranje vraća istinu.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Budući da zatvaranje proslijeđeno `filter()` uzima referencu, a mnogi iteratori prelaze preko referenci, to dovodi do moguće zbunjujuće situacije, kada je vrsta zatvaranja dvostruka referenca:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // trebaju dva * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Uobičajeno je da umjesto argumenta koristite destrukturiranje da biste ga uklonili:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // oba i *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ili oboje:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dva &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ovih slojeva.
    ///
    /// Imajte na umu da je `iter.filter(f).next()` ekvivalentan `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Stvara iterator koji filtrira i mapira.
    ///
    /// Vraćeni iterator daje samo `vrijednosti` za koje isporučeno zatvaranje vraća `Some(value)`.
    ///
    /// `filter_map` mogu se koristiti za lance X10X i [`map`] da budu sažetiji.
    /// Primjer u nastavku pokazuje kako se `map().filter().map()` može skratiti na jedan poziv na `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Evo istog primjera, ali s [`filter`] i [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Stvara iterator koji daje trenutni broj iteracija kao i sljedeću vrijednost.
    ///
    /// Vraćeni iterator daje parove `(i, val)`, gdje je `i` trenutni indeks iteracije, a `val` vrijednost koju je iterator vratio.
    ///
    ///
    /// `enumerate()` drži se kao [`usize`].
    /// Ako želite računati s cijelim brojem druge veličine, funkcija [`zip`] pruža sličnu funkcionalnost.
    ///
    /// # Ponašanje preljeva
    ///
    /// Metoda ne štiti od preljeva, pa nabrajanje više od [`usize::MAX`] elemenata daje ili pogrešan rezultat ili panics.
    /// Ako su omogućene tvrdnje za otklanjanje pogrešaka, panic je zajamčen.
    ///
    /// # Panics
    ///
    /// Vraćeni iterator mogao bi biti panic ako bi indeks koji se vraća prebacio [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Stvara iterator koji može koristiti [`peek`] za gledanje sljedećeg elementa iteratora bez da ga troši.
    ///
    /// Dodaje metodu [`peek`] u iterator.Pogledajte dokumentaciju za više informacija.
    ///
    /// Imajte na umu da je temeljni iterator i dalje napredan kada se [`peek`] pozove prvi put: Da bi se dohvatio sljedeći element, [`next`] se poziva na temeljni iterator, dakle bilo kakve nuspojave (tj.
    ///
    /// dogodit će se sve osim dohvaćanja sljedeće vrijednosti) metode [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() omogućuje nam uvid u future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // možemo peek() više puta, iterator neće napredovati
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // nakon završetka iteratora i peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Stvara iterator koji [`preskače`] elemente na temelju predikata.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` uzima zatvaranje kao argument.Pozvat će ovo zatvaranje za svaki element iteratora i ignorirati elemente dok ne vrati `false`.
    ///
    /// Nakon što se vrati `false`, posao `skip_while()`'s je gotov, a ostatak elemenata se daje.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Budući da zatvaranje proslijeđeno `skip_while()` uzima referencu, a mnogi iteratori prelaze preko referenci, to dovodi do moguće zbunjujuće situacije, gdje je vrsta argumenta zatvaranja dvostruka referenca:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // trebaju dva * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zaustavljanje nakon početnog `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // iako bi ovo bilo netačno, budući da smo već dobili netačno, skip_while() se više ne koristi
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Stvara iterator koji daje elemente na temelju predikata.
    ///
    /// `take_while()` uzima zatvaranje kao argument.Pozvat će ovo zatvaranje za svaki element iteratora i dati elemente dok vraća `true`.
    ///
    /// Nakon vraćanja `false`, posao `take_while()`'s je gotov, a ostali se elementi zanemaruju.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Budući da zatvaranje proslijeđeno `take_while()` uzima referencu, a mnogi iteratori prelaze preko referenci, to dovodi do moguće zbunjujuće situacije, kada je vrsta zatvaranja dvostruka referenca:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // trebaju dva * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zaustavljanje nakon početnog `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Imamo više elemenata koji su manji od nule, ali budući da smo već dobili false, take_while() se više ne koristi
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Budući da `take_while()` mora pogledati vrijednost kako bi vidio treba li je uključiti ili ne, konzumenti iteratori vidjet će da je uklonjena:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` više nije tamo, jer je potrošen kako bi se vidjelo treba li zaustaviti iteraciju, ali nije vraćen u iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Stvara iterator koji oba daje elemente na temelju predikata i mapa.
    ///
    /// `map_while()` uzima zatvaranje kao argument.
    /// Pozvat će ovo zatvaranje za svaki element iteratora i dati elemente dok vraća [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Evo istog primjera, ali s [`take_while`] i [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zaustavljanje nakon početnog [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Imamo više elemenata koji bi mogli stati u u32 (4, 5), ali `map_while` je vratio `None` za `-3` (kao što je `predicate` vratio `None`) i `collect` se zaustavlja na prvom `None` nađenom.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Budući da `map_while()` mora pogledati vrijednost kako bi vidio treba li je uključiti ili ne, konzumenti iteratori vidjet će da je uklonjena:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` više nije tamo, jer je potrošen kako bi se vidjelo treba li zaustaviti iteraciju, ali nije vraćen u iterator.
    ///
    /// Imajte na umu da za razliku od [`take_while`] ovaj iterator **nije** stopljen.
    /// Također nije navedeno što ovaj iterator vraća nakon što se vrati prvi [`None`].
    /// Ako trebate stopljeni iterator, upotrijebite [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Stvara iterator koji preskače prve `n` elemente.
    ///
    /// Nakon što se potroše, daje se ostatak elemenata.
    /// Umjesto da ovu metodu izravno nadjačate, umjesto `nth` metode.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Stvara iterator koji daje svoje prve `n` elemente.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` često se koristi s beskonačnim iteratorom, kako bi bio konačan:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ako je dostupno manje od `n` elemenata, `take` će se ograničiti na veličinu osnovnog iteratora:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adapter za iterator sličan [`fold`] koji ima unutarnje stanje i stvara novi iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` uzima dva argumenta: početnu vrijednost koja zasniva unutarnje stanje i zatvaranje s dva argumenta, od kojih je prvi promjenjiva referenca na unutarnje stanje, a drugi element iteratora.
    ///
    /// Zatvaranje može unutarnjem stanju dodijeliti stanje dijeljenja između iteracija.
    ///
    /// Na iteraciji će se zatvaranje primijeniti na svaki element iteratora, a iterator daje povratnu vrijednost iz zatvarača, [`Option`].
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // svaku iteraciju pomnožit ćemo stanje s elementom
    ///     *state = *state * x;
    ///
    ///     // onda ćemo ustupiti negaciju države
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Stvara iterator koji radi poput mape, ali poravna ugniježđenu strukturu.
    ///
    /// [`map`] adapter je vrlo koristan, ali samo kada argument zatvaranja daje vrijednosti.
    /// Ako umjesto toga proizvede iterator, postoji dodatni sloj indirektnosti.
    /// `flat_map()` uklonit će ovaj dodatni sloj samostalno.
    ///
    /// Možete smatrati `flat_map(f)` semantičkim ekvivalentom [`map`] ping, a zatim [`flatten`] ingom kao u `map(f).flatten()`.
    ///
    /// Drugi način razmišljanja o `flat_map()`: Zatvaranje [`map`] vraća po jednu stavku za svaki element, a zatvaranje `flat_map()`'s vraća iterator za svaki element.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vraća iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Stvara iterator koji izravnava ugniježđenu strukturu.
    ///
    /// Ovo je korisno kada imate iterator iteratora ili iterator stvari koje se mogu pretvoriti u iteratore i želite ukloniti jednu razinu indirektnosti.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapiranje, a zatim ravnanje:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vraća iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ovo također možete prepisati u smislu [`flat_map()`], što je poželjnije u ovom slučaju jer jasnije prenosi namjeru:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vraća iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Izravnavanjem se istodobno uklanja samo jedna razina gniježđenja:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Ovdje vidimo da `flatten()` ne izvodi "deep" poravnanje.
    /// Umjesto toga uklanja se samo jedna razina gniježđenja.Odnosno, ako `flatten()` trodimenzionalni niz, rezultat će biti dvodimenzionalan, a ne jednodimenzionalan.
    /// Da biste dobili jednodimenzionalnu strukturu, morate ponovno `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Stvara iterator koji završava nakon prvog [`None`].
    ///
    /// Nakon što iterator vrati [`None`], pozivi future mogu ili ne moraju ponovno dati [`Some(T)`].
    /// `fuse()` prilagođava iterator, osiguravajući da će nakon davanja [`None`] uvijek vratiti [`None`] zauvijek.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// // iterator koji izmjenjuje Some i None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ako je paran, Some(i32), inače Nijedan
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // možemo vidjeti kako se naš iterator kreće naprijed-natrag
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // međutim, kad ga spojimo ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // uvijek će vratiti `None` nakon prvog puta.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Radi nešto sa svakim elementom iteratora, prosljeđujući vrijednost dalje.
    ///
    /// Kada koristite iteratore, često ćete povezati nekoliko njih.
    /// Dok radite na takvom kodu, možda biste htjeli provjeriti što se događa na raznim dijelovima cjevovoda.Da biste to učinili, umetnite poziv na `inspect()`.
    ///
    /// Uobičajenije je da se `inspect()` koristi kao alat za uklanjanje pogrešaka nego da postoji u vašem konačnom kodu, ali aplikacije mogu smatrati korisnim u određenim situacijama kada se pogreške moraju evidentirati prije odbacivanja.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ovaj je iteratorski slijed složen.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // dodajmo nekoliko poziva inspect() da istražimo što se događa
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ovo će ispisati:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Prijava pogrešaka prije nego što ih odbacite:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ovo će ispisati:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Posudi iterator, umjesto da ga potroši.
    ///
    /// To je korisno za omogućavanje primjene adaptera iteratora, a da se i dalje zadržava vlasništvo nad izvornim iteratorom.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ako ponovo pokušamo koristiti iter, neće uspjeti.
    /// // Sljedeći redak daje "pogrešku: upotreba premještene vrijednosti: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // pokušajmo to opet
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // umjesto toga dodajemo .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // sad je ovo sasvim u redu:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Pretvara iterator u zbirku.
    ///
    /// `collect()` može uzeti sve što je moguće i pretvoriti u odgovarajuću zbirku.
    /// Ovo je jedna od najsnažnijih metoda u standardnoj knjižnici, koja se koristi u raznim kontekstima.
    ///
    /// Najosnovniji obrazac u kojem se koristi `collect()` je pretvaranje jedne kolekcije u drugu.
    /// Uzmete zbirku, na nju nazovete [`iter`], napravite hrpu transformacija, a zatim `collect()` na kraju.
    ///
    /// `collect()` također može stvoriti primjerke tipova koji nisu tipične zbirke.
    /// Na primjer, [`String`] se može graditi iz [`char`] s, a iterator [`Result<T, E>`][`Result`] predmeta može se prikupiti u `Result<Collection<T>, E>`.
    ///
    /// Pogledajte primjere u nastavku za više.
    ///
    /// Budući da je `collect()` toliko općenit, može uzrokovati probleme s zaključivanjem tipa.
    /// Kao takav, `collect()` je jedan od rijetkih slučajeva koji ćete vidjeti sintaksu koja je od milja poznata kao 'turbofish': `::<>`.
    /// To pomaže algoritmu zaključivanja da konkretno shvati u koju zbirku pokušavate prikupiti.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Imajte na umu da nam je `: Vec<i32>` trebao s lijeve strane.To je zato što bismo umjesto toga mogli prikupiti u, na primjer, [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Upotreba 'turbofish' umjesto bilježenja `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Budući da je `collect()` stalo samo do onoga što sakupljate, s turbofishom i dalje možete koristiti djelomični savjet tipa `_`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Korištenje `collect()` za izradu [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ako imate popis [`Rezultat<T, E>`][`Rezultat`], pomoću `collect()` možete provjeriti je li bilo koji od njih propao:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // daje nam prvu pogrešku
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // daje nam popis odgovora
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Potroši iterator, stvarajući od njega dvije zbirke.
    ///
    /// Predikat proslijeđen u `partition()` može vratiti `true` ili `false`.
    /// `partition()` vraća par, sve elemente za koje je vratio `true` i sve elemente za koje je vratio `false`.
    ///
    ///
    /// Vidi također [`is_partitioned()`] i [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Preuređuje elemente ovog iteratora *na mjestu* prema danom predikatu, tako da svi oni koji vraćaju `true` prethode onima koji vraćaju `false`.
    ///
    /// Vraća broj pronađenih `true` elemenata.
    ///
    /// Relativni redoslijed podijeljenih predmeta se ne održava.
    ///
    /// Vidi također [`is_partitioned()`] i [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Podjela na mjestu između nivelmana i šansi
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: trebamo li se brinuti da li broj preplavi?Jedini način da imate više od
        // `usize::MAX` promjenjive reference su sa ZST-ovima, koje nisu korisne za particiju ...

        // Ove funkcije zatvaranja "factory" postoje kako bi se izbjegla generičnost u `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Nekoliko puta pronađite prvi `false` i zamijenite ga sa posljednjim `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Provjerava jesu li elementi ovog iteratora podijeljeni prema danom predikatu, tako da svi oni koji vraćaju `true` prethode onima koji vraćaju `false`.
    ///
    ///
    /// Vidi također [`partition()`] i [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ili sve stavke testiraju `true`, ili se prva klauzula zaustavlja na `false`, a mi provjeravamo da nakon toga više nema stavki `true`.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Metoda iteratora koja primjenjuje funkciju sve dok se uspješno vraća, stvarajući jednu, konačnu vrijednost.
    ///
    /// `try_fold()` uzima dva argumenta: početnu vrijednost i zatvaranje s dva argumenta: 'accumulator' i element.
    /// Zatvaranje se ili vraća uspješno, s vrijednošću koju bi akumulator trebao imati za sljedeću iteraciju, ili vraća neuspjeh, s vrijednošću pogreške koja se odmah prenosi na pozivatelja (short-circuiting).
    ///
    ///
    /// Početna vrijednost je vrijednost koju će akumulator imati na prvom pozivu.Ako je primjena zatvaranja uspjela za svaki element iteratora, `try_fold()` vraća konačni akumulator kao uspjeh.
    ///
    /// Presavijanje je korisno kad god imate zbirku nečega i želite iz toga proizvesti jednu vrijednost.
    ///
    /// # Napomena za implementatore
    ///
    /// Neke druge metode (forward) imaju zadane implementacije u smislu ove, pa pokušajte to izričito primijeniti ako može učiniti nešto bolje od zadane implementacije petlje `for`.
    ///
    /// Konkretno, pokušajte da ovaj poziv `try_fold()` bude na unutarnjim dijelovima od kojih je sastavljen ovaj iterator.
    /// Ako je potrebno više poziva, operater `?` može biti prikladan za ulančavanje vrijednosti akumulatora, ali pripazite na sve invarijante koje treba podržati prije tih ranih povratka.
    /// Ovo je `&mut self` metoda, pa se ponavljanje mora ponoviti nakon što ovdje naiđete na pogrešku.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // provjereni zbroj svih elemenata niza
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Ova se suma prelijeva pri dodavanju elementa 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Budući da je došlo do kratkog spoja, preostali su elementi i dalje dostupni putem iteratora.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metoda iteratora koja primjenjuje pogrešnu funkciju na svaku stavku u iteratoru, zaustavljajući se na prvoj pogrešci i vraćajući tu pogrešku.
    ///
    ///
    /// To se također može smatrati nepogrešivim oblikom [`for_each()`] ili verzijom [`try_fold()`] bez državljanstva.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Kratko je spojen, pa su preostale stavke još uvijek u iteratoru:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Presavija svaki element u akumulator primjenjujući operaciju, vraćajući konačni rezultat.
    ///
    /// `fold()` uzima dva argumenta: početnu vrijednost i zatvaranje s dva argumenta: 'accumulator' i element.
    /// Zatvaranje vraća vrijednost koju bi akumulator trebao imati za sljedeću iteraciju.
    ///
    /// Početna vrijednost je vrijednost koju će akumulator imati na prvom pozivu.
    ///
    /// Nakon primjene ovog zatvarača na svaki element iteratora, `fold()` vraća akumulator.
    ///
    /// Ova se operacija ponekad naziva 'reduce' ili 'inject'.
    ///
    /// Presavijanje je korisno kad god imate zbirku nečega i želite iz toga proizvesti jednu vrijednost.
    ///
    /// Note: `fold()` i slične metode koje prelaze čitav iterator, možda se neće završiti s beskonačnim iteratorima, čak ni na traits za koje je rezultat moguće odrediti u ograničenom vremenu.
    ///
    /// Note: [`reduce()`] se može koristiti za korištenje prvog elementa kao početne vrijednosti, ako su vrsta akumulatora i vrsta predmeta jednake.
    ///
    /// # Napomena za implementatore
    ///
    /// Neke druge metode (forward) imaju zadane implementacije u smislu ove, pa pokušajte to izričito primijeniti ako može učiniti nešto bolje od zadane implementacije petlje `for`.
    ///
    ///
    /// Konkretno, pokušajte da ovaj poziv `fold()` bude na unutarnjim dijelovima od kojih je sastavljen ovaj iterator.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // zbroj svih elemenata niza
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Prođimo ovdje kroz svaki korak iteracije:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// I tako, naš konačni rezultat, `6`.
    ///
    /// Uobičajeno je da ljudi koji nisu puno koristili iteratore koriste petlju `for` sa popisom stvari za stvaranje rezultata.Oni se mogu pretvoriti u `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // za petlju:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // oni su isti
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Smanjuje elemente na jedan, više puta primjenjujući operaciju smanjenja.
    ///
    /// Ako je iterator prazan, vraća [`None`];u suprotnom, vraća rezultat smanjenja.
    ///
    /// Za iteratore s najmanje jednim elementom, to je isto kao [`fold()`] s prvim elementom iteratora kao početnom vrijednošću, preklapajući svaki sljedeći element u njega.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Pronađite maksimalnu vrijednost:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Testira podudara li se svaki element iteratora s predikatom.
    ///
    /// `all()` uzima zatvarač koji vraća `true` ili `false`.Primjenjuje ovo zatvaranje na svaki element iteratora, a ako svi vrate `true`, onda to čini i `all()`.
    /// Ako bilo koji od njih vrati `false`, vraća `false`.
    ///
    /// `all()` je kratki spoj;drugim riječima, zaustavit će se obrada čim pronađe `false`, s obzirom da će, bez obzira na sve drugo, rezultat biti i `false`.
    ///
    ///
    /// Prazan iterator vraća `true`.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Zaustavljanje na prvom `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // još uvijek možemo koristiti `iter`, jer ima više elemenata.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Testira podudara li se bilo koji element iteratora s predikatom.
    ///
    /// `any()` uzima zatvarač koji vraća `true` ili `false`.Primjenjuje ovo zatvaranje na svaki element iteratora, a ako bilo koji od njih vrati `true`, onda to čini i `any()`.
    /// Ako svi vrate `false`, vraća `false`.
    ///
    /// `any()` je kratki spoj;drugim riječima, zaustavit će se obrada čim pronađe `true`, s obzirom da će, bez obzira na sve drugo, rezultat biti i `true`.
    ///
    ///
    /// Prazan iterator vraća `false`.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Zaustavljanje na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // još uvijek možemo koristiti `iter`, jer ima više elemenata.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Traži element iteratora koji zadovoljava predikat.
    ///
    /// `find()` uzima zatvarač koji vraća `true` ili `false`.
    /// Primjenjuje ovo zatvaranje na svaki element iteratora, a ako bilo koji od njih vrati `true`, tada `find()` vraća [`Some(element)`].
    /// Ako svi vrate `false`, vraća [`None`].
    ///
    /// `find()` je kratki spoj;drugim riječima, zaustavit će se obrada čim zatvaranje vrati `true`.
    ///
    /// Budući da `find()` uzima referencu, a mnogi iteratori prelaze preko referenci, to dovodi do moguće zbunjujuće situacije kada je argument dvostruka referenca.
    ///
    /// Ovaj efekt možete vidjeti u primjerima u nastavku, s `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Zaustavljanje na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // još uvijek možemo koristiti `iter`, jer ima više elemenata.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Imajte na umu da je `iter.find(f)` ekvivalentan `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Primjenjuje funkciju na elemente iteratora i vraća prvi rezultat koji nije nijedan.
    ///
    ///
    /// `iter.find_map(f)` je ekvivalentan `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Primjenjuje funkciju na elemente iteratora i vraća prvi istiniti rezultat ili prvu pogrešku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Traži element u iteratoru, vraća njegov indeks.
    ///
    /// `position()` uzima zatvarač koji vraća `true` ili `false`.
    /// Primjenjuje ovo zatvaranje na svaki element iteratora, a ako jedan od njih vrati `true`, tada `position()` vraća [`Some(index)`].
    /// Ako svi vrate `false`, vraća [`None`].
    ///
    /// `position()` je kratki spoj;drugim riječima, zaustavit će obradu čim pronađe `true`.
    ///
    /// # Ponašanje preljeva
    ///
    /// Metoda ne štiti od preljeva, pa ako postoji više od [`usize::MAX`] nepodudarajućih elemenata, ili daje pogrešan rezultat ili panics.
    ///
    /// Ako su omogućene tvrdnje za otklanjanje pogrešaka, panic je zajamčen.
    ///
    /// # Panics
    ///
    /// Ova funkcija može panic ako iterator ima više od `usize::MAX` nepodudarajućih elemenata.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Zaustavljanje na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // još uvijek možemo koristiti `iter`, jer ima više elemenata.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Vraćeni indeks ovisi o stanju iteratora
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Traži element u iteratoru s desne strane, vraća njegov indeks.
    ///
    /// `rposition()` uzima zatvarač koji vraća `true` ili `false`.
    /// Primjenjuje ovo zatvaranje na svaki element iteratora, počevši od kraja, a ako jedan od njih vrati `true`, tada `rposition()` vraća [`Some(index)`].
    ///
    /// Ako svi vrate `false`, vraća [`None`].
    ///
    /// `rposition()` je kratki spoj;drugim riječima, zaustavit će obradu čim pronađe `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Zaustavljanje na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // još uvijek možemo koristiti `iter`, jer ima više elemenata.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Ovdje nije potrebna provjera preljeva, jer `ExactSizeIterator` podrazumijeva da broj elemenata stane u `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Vraća maksimalni element iteratora.
    ///
    /// Ako je nekoliko elemenata jednako maksimalno, vraća se zadnji element.
    /// Ako je iterator prazan, vraća se [`None`].
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Vraća minimalni element iteratora.
    ///
    /// Ako je nekoliko elemenata jednako najmanje, vraća se prvi element.
    /// Ako je iterator prazan, vraća se [`None`].
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Vraća element koji daje maksimalnu vrijednost iz navedene funkcije.
    ///
    ///
    /// Ako je nekoliko elemenata jednako maksimalno, vraća se zadnji element.
    /// Ako je iterator prazan, vraća se [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Vraća element koji daje maksimalnu vrijednost s obzirom na navedenu funkciju usporedbe.
    ///
    ///
    /// Ako je nekoliko elemenata jednako maksimalno, vraća se zadnji element.
    /// Ako je iterator prazan, vraća se [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Vraća element koji daje minimalnu vrijednost iz navedene funkcije.
    ///
    ///
    /// Ako je nekoliko elemenata jednako najmanje, vraća se prvi element.
    /// Ako je iterator prazan, vraća se [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Vraća element koji daje minimalnu vrijednost s obzirom na navedenu funkciju usporedbe.
    ///
    ///
    /// Ako je nekoliko elemenata jednako najmanje, vraća se prvi element.
    /// Ako je iterator prazan, vraća se [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Obrne smjer iteratora.
    ///
    /// Obično se iteratori ponavljaju slijeva udesno.
    /// Nakon upotrebe `rev()`, iterator će umjesto toga ponavljati zdesna ulijevo.
    ///
    /// To je moguće samo ako iterator ima kraj, pa `rev()` radi samo na [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Pretvara iterator parova u par spremnika.
    ///
    /// `unzip()` troši čitav iterator parova, stvarajući dvije zbirke: jednu iz lijevih elemenata parova i jednu iz desnih elemenata.
    ///
    ///
    /// Ova je funkcija u nekom smislu suprotna [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Stvara iterator koji kopira sve njegove elemente.
    ///
    /// To je korisno kada imate iterator preko `&T`, ali potreban vam je iterator preko `T`.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopirano je isto kao i .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Stvara iterator koji [`clone`] ima sve svoje elemente.
    ///
    /// To je korisno kada imate iterator preko `&T`, ali potreban vam je iterator preko `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned je isto što i .map(|&x| x), za cijele brojeve
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Beskrajno ponavlja iterator.
    ///
    /// Umjesto da se zaustavi na [`None`], iterator će umjesto toga početi ponovno, od početka.Nakon ponovnog ponavljanja, započet će ponovno na početku.I opet.
    /// I opet.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Zbraja elemente iteratora.
    ///
    /// Uzima svaki element, zbraja ih i vraća rezultat.
    ///
    /// Prazan iterator vraća nultu vrijednost tipa.
    ///
    /// # Panics
    ///
    /// Prilikom pozivanja `sum()` i vraćanja primitivnog cijelog broja, ova metoda će panic ako je izračun dopušten i ako su omogućene tvrdnje o otklanjanju pogrešaka.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Interakcija se odvija kroz čitav iterator, množeći sve elemente
    ///
    /// Prazan iterator vraća jednu vrijednost tipa.
    ///
    /// # Panics
    ///
    /// Prilikom pozivanja `product()` i vraćanja primitivnog cijelog broja, metoda će panic ako je izračun dopušten i ako su omogućene tvrdnje o otklanjanju pogrešaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) uspoređuje elemente ovog [`Iterator`] s elementima drugog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) uspoređuje elemente ovog [`Iterator`] s elementima drugog s obzirom na navedenu funkciju usporedbe.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) uspoređuje elemente ovog [`Iterator`] s elementima drugog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) uspoređuje elemente ovog [`Iterator`] s elementima drugog s obzirom na navedenu funkciju usporedbe.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Utvrđuje jesu li elementi ovog [`Iterator`] jednaki elementima drugog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Utvrđuje jesu li elementi ovog [`Iterator`] jednaki elementima drugog s obzirom na navedenu funkciju jednakosti.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Utvrđuje jesu li elementi ovog [`Iterator`] nejednaki elementima drugog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Utvrđuje jesu li elementi ovog [`Iterator`] [lexicographically](Ord#lexicographical-comparison) manji od elemenata drugog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Utvrđuje jesu li elementi ovog [`Iterator`] [lexicographically](Ord#lexicographical-comparison) manji ili jednaki elementima drugog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Utvrđuje jesu li elementi ovog [`Iterator`] [lexicographically](Ord#lexicographical-comparison) veći od elemenata drugog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Utvrđuje jesu li elementi ovog [`Iterator`] [lexicographically](Ord#lexicographical-comparison) veći ili jednaki elementima drugog.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Provjerava jesu li elementi ovog iteratora sortirani.
    ///
    /// Odnosno, za svaki element `a` i sljedeći element `b` mora odgovarati `a <= b`.Ako iterator daje točno nula ili jedan element, vraća se `true`.
    ///
    /// Imajte na umu da ako je `Self::Item` samo `PartialOrd`, ali ne i `Ord`, gornja definicija podrazumijeva da ova funkcija vraća `false` ako bilo koje dvije uzastopne stavke nisu usporedive.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Provjerava jesu li elementi ovog iteratora sortirani pomoću zadane funkcije usporedbe.
    ///
    /// Umjesto da koristi `PartialOrd::partial_cmp`, ova funkcija koristi zadanu funkciju `compare` za određivanje redoslijeda dvaju elemenata.
    /// Osim toga, ekvivalentan je [`is_sorted`];za više informacija pogledajte njegovu dokumentaciju.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Provjerava jesu li elementi ovog iteratora sortirani pomoću zadane funkcije ekstrakcije ključa.
    ///
    /// Umjesto izravne usporedbe elemenata iteratora, ova funkcija uspoređuje tipke elemenata, kako je određeno `f`.
    /// Osim toga, ekvivalentan je [`is_sorted`];za više informacija pogledajte njegovu dokumentaciju.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Pogledajte [TrustedRandomAccess]
    // Neobičan naziv je izbjegavanje sudara imena u razlučivosti metode, vidi #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}