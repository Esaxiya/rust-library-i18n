Panics trenutna nit.

To omogućuje programu da odmah prekine i pruži povratne informacije pozivatelju programa.
`panic!` treba koristiti kada program dosegne nepopravljivo stanje.

Ovaj je makronaredba savršen način za utvrđivanje uvjeta u primjeru koda i u testovima.
`panic!` usko je povezan s `unwrap` metodom i popisa [`Option`][ounwrap] i [`Result`][runwrap].
Obje implementacije pozivaju `panic!` kada su postavljene na inačice [`None`] ili [`Err`].

Kada upotrebljavate `panic!()`, možete odrediti korisni teret niza koji se gradi pomoću sintakse [`format!`].
Taj se korisni teret koristi prilikom ubrizgavanja panic u pozivajuću nit Rust, što dovodi do toga da nit u potpunosti panic.

Ponašanje zadanog `std` hook, tj
kôd koji se izvodi neposredno nakon poziva panic je ispis korisnog tereta poruke na `stderr` zajedno s file/line/column informacijama o pozivu `panic!()`.

panic hook možete nadjačati pomoću [`std::panic::set_hook()`].
Unutar hook panic se može pristupiti kao `&dyn Any + Send`, koji sadrži `&str` ili `String` za redovite pozive `panic!()`.
Za panic s vrijednošću druge vrste, može se koristiti [`panic_any`].

[`Result`] enum je često bolje rješenje za oporavak od pogrešaka od upotrebe makronaredbe `panic!`.
Ovu makronaredbu treba koristiti za izbjegavanje nastavka s pogrešnim vrijednostima, primjerice iz vanjskih izvora.
Detaljne informacije o rukovanju pogreškama nalaze se u [book].

Pogledajte i makronaredbu [`compile_error!`] za pojačavanje pogrešaka tijekom kompilacije.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Trenutna provedba

Ako je glavna nit panics, ona će završiti sve vaše niti i završiti vaš program s kodom `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





