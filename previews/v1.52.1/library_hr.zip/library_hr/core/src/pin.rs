//! Tipovi koji prikvačuju podatke na njihovo mjesto u memoriji.
//!
//! Ponekad je korisno imati predmete za koje se jamči da se neće micati, u smislu da se njihovo smještanje u memoriju ne mijenja i da se na njih može pouzdati.
//! Primarni primjer takvog scenarija bila bi izgradnja autoreferencijalnih struktura, jer će ih premještanje objekta s pokazivačima onesposobiti, što bi moglo prouzročiti nedefinirano ponašanje.
//!
//! Na visokoj razini, [`Pin<P>`] osigurava da pokazivač bilo kojeg tipa pokazivača `P` ima stabilno mjesto u memoriji, što znači da se ne može premjestiti negdje drugdje i da se njegova memorija ne može osloboditi dok ne padne.Kažemo da je poentirani "pinned".Stvari postaju suptilnije kada se raspravlja o vrstama koje kombiniraju prikvačene podatke s neprikvačenim podacima;[see below](#projections-and-structural-pinning) za više detalja.
//!
//! Prema zadanim postavkama sve su vrste u Rust pokretne.
//! Rust omogućuje prosljeđivanje svih vrsta po vrijednosti, a uobičajeni tipovi pametnih pokazivača poput [`Box<T>`] i `&mut T` omogućuju zamjenu i premještanje vrijednosti koje sadrže: možete se iseliti iz [`Box<T>`] ili možete koristiti [`mem::swap`].
//! [`Pin<P>`] obavija pokazivač tipa `P`, pa [`Pin`]`<`[`Box`] `<T>>`funkcionira slicno regularnom
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`ispadne, pa tako i njegov sadržaj, a memorija dobiva
//!
//! razmješteno.Slično tome, [`Pin`]`<&mut T>`mnogo je nalik na `&mut T`.Međutim, [`Pin<P>`] ne dopušta klijentima da zapravo pribave [`Box<T>`] ili `&mut T` za prikvačene podatke, što znači da ne možete koristiti operacije poput [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` treba `&mut T`, ali ga ne možemo dobiti.
//!     // Zapeli smo, ne možemo zamijeniti sadržaj ovih referenci.
//!     // Mogli bismo koristiti `Pin::get_unchecked_mut`, ali to nije sigurno s razlogom:
//!     // ne smijemo ga koristiti za premještanje stvari iz `Pin`.
//! }
//! ```
//!
//! Vrijedno je ponoviti da [`Pin<P>`]*ne* mijenja činjenicu da kompajler Rust smatra sve vrste pokretnima.[`mem::swap`] ostaje dostupan za bilo koji `T`.Umjesto toga, [`Pin<P>`] sprječava pomicanje određenih *vrijednosti*(na koje ukazuju pokazivači umotani u [`Pin<P>`]) onemogućujući pozivanje metoda koje na njima zahtijevaju `&mut T` (poput [`mem::swap`]).
//!
//! [`Pin<P>`] može se koristiti za umotavanje bilo kojeg tipa pokazivača `P` i kao takav komunicira s [`Deref`] i [`DerefMut`].[`Pin<P>`] gdje `P: Deref` treba smatrati "`P`-style pointer" na prikvačeni `P::Target`-dakle, [`Pin`]`<`[`Box`] `<T>>`posjeduje pokazivač na prikvačeni `T` i [`Prikvači`] `<` [`Rc`]`<T>>`je pokazivač brojen referencama na prikvačeni `T`.
//! Radi ispravnosti, [`Pin<P>`] se oslanja na implementacije [`Deref`] i [`DerefMut`] kako se ne bi pomaknuli s njihovog parametra `self`, već samo da bi vratili pokazivač na prikvačene podatke kada su pozvani na prikvačenom pokazivaču.
//!
//! # `Unpin`
//!
//! Mnoge su vrste uvijek slobodno pokretne, čak i kad su prikvačene, jer se ne oslanjaju na stabilnu adresu.To uključuje sve osnovne tipove (poput [`bool`], [`i32`] i reference), kao i tipove koji se sastoje isključivo od tih tipova.Tipovi kojima nije stalo do pričvršćivanja implementiraju [`Unpin`] auto-Portrait, koji poništava učinak [`Pin<P>`].
//! Za `T: Unpin`, [`Prikvači ']` <`[` Kutija`]`<T>> `i [`Box<T>`] funkcioniraju identično, kao i [` Pin`]`<&mut T>` i `&mut T`.
//!
//! Imajte na umu da prikvačivanje i [`Unpin`] utječu samo na usmjereni tip `P::Target`, a ne i na sam tip pokazivača `P` koji je umotan u [`Pin<P>`].Na primjer, je li [`Box<T>`] [`Unpin`] ili nema, nema utjecaja na ponašanje [`Pin`]`<`[`Box`] `<T>>`(ovdje je `T` usmjereni tip).
//!
//! # Primjer: autoreferencijalna struktura
//!
//! Prije nego što uđemo u više detalja kako bismo objasnili jamstva i izbore povezane s `Pin<T>`, raspravit ćemo nekoliko primjera kako se on može koristiti.
//! Slobodno za [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ovo je autoreferencijalna struktura jer polje presjeka pokazuje na polje podataka.
//! // O tome ne možemo obavijestiti sastavljača normalnom referencom, jer se ovaj obrazac ne može opisati uobičajenim pravilima posuđivanja.
//! //
//! // Umjesto toga koristimo sirovi pokazivač, iako onaj za koji se zna da nije null, jer znamo da pokazuje na niz.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Da bismo osigurali da se podaci ne pomaknu kad se funkcija vrati, smjestimo ih u hrpu gdje će ostati tijekom života objekta, a jedini način da im se pristupi bio bi kroz pokazivač na nju.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // pokazivač stvaramo samo kad su podaci na mjestu, inače će se već pomaknuti prije nego što smo uopće započeli
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // znamo da je ovo sigurno jer izmjena polja ne pomiče cijelu strukturu
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Pokazivač treba ukazivati na ispravno mjesto, sve dok se struktura nije pomaknula.
//! //
//! // U međuvremenu možemo slobodno pomicati pokazivač.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Budući da naš tip ne implementira Unpin, ovo se neće uspjeti kompajlirati:
//! // neka mut novo_nemovirano= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Primjer: nametljivi dvostruko povezani popis
//!
//! Na nametljivom dvostruko povezanom popisu zbirka zapravo ne dodjeljuje memoriju za same elemente.
//! Dodjelom upravljaju klijenti, a elementi mogu živjeti na okviru steka koji živi kraće nego što to čini kolekcija.
//!
//! Da bi to uspjelo, svaki element ima pokazivače na svog prethodnika i nasljednika na popisu.Elementi se mogu dodati samo kad su prikvačeni, jer bi pomicanje elemenata onesposobilo pokazivače.Štoviše, implementacija [`Drop`] povezanog elementa popisa zakrpit će pokazivače svog prethodnika i nasljednika kako bi se uklonila s popisa.
//!
//! Ključno je da se moramo moći osloniti na poziv [`drop`].Ako bi se element mogao osloboditi ili na drugi način onesposobiti bez pozivanja [`drop`], pokazivači na njega iz susjednih elemenata postali bi nevaljani, što bi razbilo strukturu podataka.
//!
//! Stoga se prikvačivanje isporučuje i s jamstvom vezanim za [`drop`].
//!
//! # `Drop` guarantee
//!
//! Svrha prikvačivanja je osloniti se na smještanje nekih podataka u memoriju.
//! Da bi ovo uspjelo, nije ograničeno samo premještanje podataka;Ograničeno je i oslobađanje, prenamjena ili na drugi način poništavanje memorije koja se koristi za pohranu podataka.
//! Konkretno, za prikvačene podatke morate zadržati invarijant da *njegova memorija neće biti onesposobljena ili prenamijenjena od trenutka kada je prikvačena pa sve do poziva [`drop`]*.Tek nakon što se vrati [`drop`] ili panics, memorija se može ponovno koristiti.
//!
//! Memorija može biti "invalidated" oslobađanjem, ali i zamjenom [`Some(v)`] sa [`None`] ili pozivanjem [`Vec::set_len`] na "kill" nekih elemenata sa vector.Može se prenamijeniti upotrebom [`ptr::write`] za njegovo prepisivanje bez prethodnog pozivanja destruktora.Ništa od ovoga nije dopušteno za prikvačene podatke bez pozivanja [`drop`].
//!
//! Upravo je to vrsta garancije da nametljivi povezani popis iz prethodnog odjeljka treba pravilno funkcionirati.
//!
//! Primijetite da ovo jamstvo *ne* znači da memorija ne curi!I dalje je potpuno u redu da nikada ne pozovete [`drop`] na prikvačenom elementu (npr. Još uvijek možete nazvati [`mem::forget`] na [`Pin`]`<`[`Box`] `<T>>`).U primjeru dvostruko povezanog popisa taj bi element jednostavno ostao na popisu.Međutim, ne možete osloboditi ili ponovno koristiti pohranu *bez pozivanja [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Ako vaš tip koristi pričvršćivanje (kao što su dva gornja primjera), morate biti oprezni kada implementirate [`Drop`].Funkcija [`drop`] uzima `&mut self`, ali to se naziva *čak i ako je vaš tip prethodno bio prikvačen*!To je kao da je kompajler automatski nazvao [`Pin::get_unchecked_mut`].
//!
//! To nikada ne može stvoriti problem u sigurnom kodu, jer implementacija tipa koji se oslanja na prikvačivanje zahtijeva nesigurni kôd, ali imajte na umu da odlučivanje upotrebe prikvačivanja u vašem tipu (na primjer, provođenjem neke operacije na [`Prikvači`]`<&Self>`ili [`Pin`] `<&mut Self>`) ima posljedice i na vašu implementaciju [`Drop`]: ako je element vašeg tipa mogao biti prikvačen, s [`Drop`] morate postupati kao s implicitnim uzimanjem [`Pin`]`<&mut Self>`.
//!
//!
//! Na primjer, možete implementirati `Drop` na sljedeći način:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` je u redu jer znamo da se ova vrijednost više nikad ne koristi nakon ispuštanja.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Stvarni kod za pad ide ovdje.
//!         }
//!     }
//! }
//! ```
//!
//! Funkcija `inner_drop` ima tip koji bi trebao imati [`drop`] *, pa to osigurava da slučajno ne upotrijebite `self`/`this` na način koji je u suprotnosti s prikvačivanjem.
//!
//! Štoviše, ako je vaš tip `#[repr(packed)]`, kompajler će automatski premještati polja kako bi ih mogao ispustiti.To bi čak mogao učiniti i za polja koja su slučajno dovoljno poravnana.Kao posljedicu, ne možete koristiti pričvršćivanje s tipom `#[repr(packed)]`.
//!
//! # Projekcije i strukturno pričvršćivanje
//!
//! Kada radite s prikvačenim strukturama, postavlja se pitanje kako se može pristupiti poljima te strukture u metodi koja uzima samo [`Prikvači ']` <&mut Struct> `.
//! Uobičajeni pristup je pisanje pomoćnih metoda (tzv.*Projekcije*) koje pretvaraju [`Prikvačiti ']` <&mut Struct> `u referencu na polje, ali koju vrstu bi ta referenca trebala imati?Je li to [`Pin ']`<&mut Field>`ili `&mut Field`?
//! Isto se pitanje postavlja s poljima `enum`, a također i kada se razmatraju tipovi container/wrapper poput [`Vec<T>`], [`Box<T>`] ili [`RefCell<T>`].
//! (Ovo se pitanje odnosi i na izmjenjive i na zajedničke reference, ovdje samo koristimo uobičajeni slučaj promjenjivih referenci za ilustraciju.)
//!
//! Ispada da je zapravo na autoru strukture podataka da odluči hoće li prikvačena projekcija za određeno polje pretvoriti [`Pin`]`<&mut Struct>`u [`Pin`] `<&mut Field>` ili `&mut Field`.Ipak postoje neka ograničenja, a najvažnije ograničenje je *dosljednost*:
//! svako polje može se *ili* projicirati na prikvačenu referencu,*ili* ukloniti prikvačivanje kao dio projekcije.
//! Ako su oba učinjena za isto polje, to će vjerojatno biti nerazumno!
//!
//! Kao autor strukture podataka, za svako polje morate odlučiti hoćete li "propagates" pričvrstiti u ovo polje ili ne.
//! Prikvačivanje koje se širi naziva se i "structural", jer slijedi strukturu tipa.
//! U sljedećim pododjeljcima opisujemo razmatranja koja treba uzeti u obzir za bilo koji izbor.
//!
//! ## Prikvačivanje *nije* strukturno za `field`
//!
//! Možda se čini kontra-intuitivnim da polje prikvačene strukture možda neće biti prikvačeno, ali to je zapravo najlakši izbor: ako se nikada ne stvori [`Prikvači ']` <&mut Polje> `, ništa ne može poći po zlu!Dakle, ako odlučite da neko polje nema strukturno pričvršćivanje, sve što morate osigurati je da nikada ne stvorite prikvačenu referencu na to polje.
//!
//! Polja bez strukturnog pričvršćivanja mogu imati metodu projekcije koja pretvara [`Pin`]`<&mut Struct>`u `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // To je u redu jer se `field` nikad ne smatra prikvačenim.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Možete i `impl Unpin for Struct`*, čak i ako* vrsta `field` nije [`Unpin`].Ono što ta vrsta misli o prikvačenju nije relevantno kada se nikad ne stvori [`Prikvači ']` <&mut Field> `.
//!
//! ## Prikvačivanje *je* strukturno za `field`
//!
//! Druga je mogućnost odlučiti da je prikvačivanje "structural" za `field`, što znači da ako je prikvačena struktura onda je to i polje.
//!
//! To omogućuje pisanje projekcije koja stvara [`Prikvačiti ']` <&mut Polje> `, svjedočeći tako da je polje prikvačeno:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // To je u redu jer je `field` prikvačen kad je `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Međutim, strukturno pričvršćivanje dolazi s nekoliko dodatnih zahtjeva:
//!
//! 1. Struktura mora biti [`Unpin`] samo ako su sva strukturna polja [`Unpin`].To je zadano, ali [`Unpin`] je siguran Portrait, pa je kao autor strukture vaša odgovornost *ne* dodati nešto poput `impl<T> Unpin for Struct<T>`.
//! (Primijetite da dodavanje operacije projiciranja zahtijeva nesigurni kôd, pa činjenica da je [`Unpin`] siguran Portrait ne krši načelo da se o bilo čemu od toga morate brinuti samo ako koristite `nesigurno`.)
//! 2. Destruktor strukture ne smije pomicati strukturna polja iz svog argumenta.To je točno pitanje koje je istaknuto u [previous section][drop-impl]: `drop` uzima `&mut self`, ali struktura (a time i njena polja) možda su već bila zakačena.
//!     Morate jamčiti da nećete premjestiti polje unutar svoje implementacije [`Drop`].
//!     Kao što je prethodno objašnjeno, to posebno znači da vaša struktura *ne* mora biti `#[repr(packed)]`.
//!     Pogledajte taj odjeljak kako napisati [`drop`] na način da vam prevodilac pomogne da slučajno ne prekinete pričvršćivanje.
//! 3. Morate biti sigurni da podržavate [`Drop` guarantee][drop-guarantee]:
//!     nakon što je vaša struktura prikvačena, memorija koja sadrži sadržaj neće se prebrisati ili ukloniti bez pozivanja destruktora sadržaja.
//!     To može biti nezgodno, kao što svjedoči [`VecDeque<T>`]: destruktor [`VecDeque<T>`] ne može pozvati [`drop`] na svim elementima ako je jedan od destruktora panics.To krši jamstvo [`Drop`], jer može dovesti do uklanjanja elemenata bez pozivanja njihovog destruktora.([`VecDeque<T>`] nema izbočenja za pričvršćivanje, pa to ne uzrokuje zvuk.)
//! 4. Ne smijete nuditi nikakve druge radnje koje bi mogle dovesti do premještanja podataka iz strukturnih polja kad je vaš tip prikvačen.Na primjer, ako struktura sadrži [`Option<T>`] i postoji operacija nalik `take` s tipom `fn(Pin<&mut Struct<T>>) -> Option<T>`, ta se operacija može koristiti za premještanje `T` iz prikvačenog `Struct<T>`-što znači da prikvačivanje ne može biti strukturno za polje koje drži ovo podaci.
//!
//!     Za složeniji primjer premještanja podataka iz prikvačenog tipa, zamislite da li [`RefCell<T>`] ima metodu `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Tada bismo mogli učiniti sljedeće:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Ovo je katastrofalno, znači da prvo možemo prikvačiti sadržaj [`RefCell<T>`] (pomoću `RefCell::get_pin_mut`), a zatim taj sadržaj premjestiti pomoću promjenjive reference koju smo dobili kasnije.
//!
//! ## Examples
//!
//! Za tip poput [`Vec<T>`] obje mogućnosti (strukturno pričvršćivanje ili ne) imaju smisla.
//! [`Vec<T>`] sa strukturnim pričvršćivanjem mogao bi imati `get_pin`/`get_pin_mut` metode za dobivanje prikvačenih referenci na elemente.Međutim, to *ne može* dopustiti pozivanje [`pop`][Vec::pop] na prikvačenom [`Vec<T>`], jer bi to premjestilo (strukturno prikvačeni) sadržaj!Niti je mogao dopustiti [`push`][Vec::push], koji bi mogao preraspodijeliti, a time i premjestiti sadržaj.
//!
//! [`Vec<T>`] bez strukturnog pričvršćivanja mogao bi `impl<T> Unpin for Vec<T>`, jer se sadržaj nikad ne prikvači, a sam [`Vec<T>`] je u redu s premještanjem.
//! U tom trenutku pričvršćivanje jednostavno uopće nema utjecaja na vector.
//!
//! U standardnoj knjižnici, tipovi pokazivača uglavnom nemaju strukturno pričvršćivanje, pa stoga ne nude projekcije prikvačenja.Zbog toga `Box<T>: Unpin` vrijedi za sve `T`.
//! Ima smisla to učiniti za vrste pokazivača, jer pomicanje `Box<T>` zapravo ne pomiče `T`: [`Box<T>`] može biti slobodno pomičan (aka `Unpin`), čak i ako `T` nije.U stvari, čak i [`Pin`]`<`[`Box`] `<T>>`i [`Pin`] `<&mut T>` su uvijek sami [`Unpin`], iz istog razloga: njihov sadržaj (`T`) je prikvačen, ali sami pokazivači mogu se premještati bez premještanja prikvačenih podataka.
//! Za [`Box<T>`] i [`Pin`]`<`[`Box`] `<T>>`, je li sadržaj prikvačen u potpunosti neovisno o tome je li prikvačen pokazivač, što znači da prikvačivanje *nije* strukturno.
//!
//! Kad implementirate [`Future`] kombinator, obično će vam trebati strukturno pričvršćivanje za ugniježđene futures, jer trebate dobiti prikvačene reference na njih da biste pozvali [`poll`].
//! Ali ako vaš kombinator sadrži bilo koje druge podatke koje nije potrebno prikvačiti, ta polja možete učiniti nestrukturnima i stoga im slobodno pristupiti s promjenjivom referencom, čak i ako samo imate [`Prikvači ']` <&mut Self> `(poput kao u vlastitoj implementaciji [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Prikvačeni pokazivač.
///
/// Ovo je omot oko neke vrste pokazivača koji tom pokazivaču "pin" čini vrijednost na mjestu, sprečavajući pomicanje vrijednosti na koju se odnosi taj pokazivač, osim ako ne implementira [`Unpin`].
///
///
/// *Objašnjenje pričvršćivanja potražite u dokumentaciji [`pin` module].*
///
/// [`pin` module]: self
///
// Note: donji izveden `Clone` uzrokuje nesmotrenost kako je to moguće implementirati
// `Clone` za izmjenjive reference.
// Pogledajte <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> za više detalja.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Sljedeće implementacije nisu izvedene kako bi se izbjegli problemi sa zvukom.
// `&self.pointer` ne bi trebao biti dostupan nepouzdanim implementacijama Portrait.
//
// Pogledajte <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> za više detalja.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Konstruirajte novi `Pin<P>` oko pokazivača na neke podatke tipa koji implementira [`Unpin`].
    ///
    /// Za razliku od `Pin::new_unchecked`, ova metoda je sigurna jer se pokazivač `P` preusmjerava na tip [`Unpin`], što ukida jamstva pričvršćivanja.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SIGURNOST: vrijednost na koju se ukazuje je `Unpin`, pa nema zahtjeva
        // oko prikvačenja.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Omotava ovaj `Pin<P>` vraćajući osnovni pokazivač.
    ///
    /// To zahtijeva da podaci unutar ovog `Pin` budu [`Unpin`] kako bismo mogli ignorirati invarijante prikvačivanja kada ih raspakiramo.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstruirajte novi `Pin<P>` oko reference na neke podatke tipa koji mogu ili ne moraju implementirati `Unpin`.
    ///
    /// Ako se `pointer` preusmjerava na tip `Unpin`, umjesto njega treba koristiti `Pin::new`.
    ///
    /// # Safety
    ///
    /// Ovaj konstruktor nije siguran jer ne možemo jamčiti da su podaci na koje je ukazao `pointer` prikvačeni, što znači da se podaci neće premještati ili će njihova pohrana biti onesposobljena dok ne padne.
    /// Ako konstruirani `Pin<P>` ne jamči da su podaci na koje `P` upućuje prikvačeni, to predstavlja kršenje API ugovora i može dovesti do nedefiniranog ponašanja u kasnijim operacijama (safe).
    ///
    /// Korištenjem ove metode izrađujete promise o implementacijama `P::Deref` i `P::DerefMut`, ako one postoje.
    /// Što je najvažnije, ne smiju se maknuti iz svojih argumenata `self`: `Pin::as_mut` i `Pin::as_ref` pozvat će `DerefMut::deref_mut` i `Deref::deref`*na prikvačenom pokazivaču* i očekivati da će ove metode podržati invarijante prikvačenja.
    /// Štoviše, pozivanjem ove metode vi promise iz kojeg referentne reference `P` više neće biti premještene;posebno ne smije biti moguće dobiti `&mut P::Target`, a zatim se pomaknuti s te reference (koristeći, na primjer, [`mem::swap`]).
    ///
    ///
    /// Na primjer, pozivanje `Pin::new_unchecked` na `&'a mut T` nije sigurno, iako ga možete prikvačiti za određeni vijek trajanja `'a`, nemate kontrolu nad tim hoće li se zadržati prikvačenim kad `'a` završi:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // To bi trebalo značiti da se poentirani `a` više nikada ne može pomaknuti.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adresa `a` promijenila se u slog sloga `b`, pa je `a` premješten iako smo ga prethodno prikvačili!Prekršili smo ugovor o prikvačenju API-ja.
    /////
    /// }
    /// ```
    ///
    /// Vrijednost, jednom prikvačena, mora ostati zauvijek prikvačena (osim ako njezin tip ne implementira `Unpin`).
    ///
    /// Slično tome, pozivanje `Pin::new_unchecked` na `Rc<T>` nije sigurno, jer mogu postojati pseudonimi istih podataka koji ne podliježu ograničenjima pričvršćivanja:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // To bi trebalo značiti da se pointe više nikad ne može pomaknuti.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Sada, ako je `x` bila jedina referenca, imamo promjenjivu referencu na podatke koje smo prikvačili gore, a koje bismo mogli koristiti za njihovo premještanje kao što smo vidjeli u prethodnom primjeru.
    ///     // Prekršili smo ugovor o prikvačenju API-ja.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Dohvaća prikvačenu zajedničku referencu iz ovog prikvačenog pokazivača.
    ///
    /// Ovo je generička metoda za prelazak s `&Pin<Pointer<T>>` na `Pin<&T>`.
    /// Sigurno je jer se, kao dio ugovora `Pin::new_unchecked`, poentirani ne može pomicati nakon što je `Pin<Pointer<T>>` stvoren.
    ///
    /// "Malicious" implementacije `Pointer::Deref` također su isključene ugovorom `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SIGURNOST: pogledajte dokumentaciju o ovoj funkciji
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Omotava ovaj `Pin<P>` vraćajući osnovni pokazivač.
    ///
    /// # Safety
    ///
    /// Ova funkcija nije sigurna.Morate jamčiti da ćete i nakon tretmana pokazivača `P` postupati s prikvačenim nakon pozivanja ove funkcije, tako da se invarijanti tipa `Pin` mogu podržati.
    /// Ako kôd koji koristi rezultirajući `P` i dalje ne održava invarijante pričvršćivanja, to predstavlja kršenje API ugovora i može dovesti do nedefiniranog ponašanja u kasnijim operacijama (safe).
    ///
    ///
    /// Ako su temeljni podaci [`Unpin`], umjesto njih treba koristiti [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Dohvaća prikvačenu promjenjivu referencu iz ovog prikvačenog pokazivača.
    ///
    /// Ovo je generička metoda za prelazak s `&mut Pin<Pointer<T>>` na `Pin<&mut T>`.
    /// Sigurno je jer se, kao dio ugovora `Pin::new_unchecked`, poentirani ne može pomicati nakon što je `Pin<Pointer<T>>` stvoren.
    ///
    /// "Malicious" implementacije `Pointer::DerefMut` također su isključene ugovorom `Pin::new_unchecked`.
    ///
    /// Ova je metoda korisna pri obavljanju višestrukih poziva funkcijama koje koriste prikvačeni tip.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // učini nešto
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` troši `self`, pa ponovo posudite `Pin<&mut Self>` putem `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SIGURNOST: pogledajte dokumentaciju o ovoj funkciji
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Dodijeljuje novu vrijednost memoriji iza prikvačene reference.
    ///
    /// Ovo prepisuje prikvačene podatke, ali to je u redu: njegov se destruktor pokreće prije nego što se prepiše, tako da nije povrijeđeno jamstvo prikvačivanja.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstruira novu iglu mapiranjem unutarnje vrijednosti.
    ///
    /// Na primjer, ako ste željeli dobiti `Pin` polja nečega, to biste mogli koristiti za pristup tom polju u jednom retku koda.
    /// Međutim, postoji nekoliko problema s ovim "pinning projections";
    /// potražite dokumentaciju [`pin` module] za daljnje detalje o toj temi.
    ///
    /// # Safety
    ///
    /// Ova funkcija nije sigurna.
    /// Morate jamčiti da se podaci koje vraćate neće pomicati sve dok se vrijednost argumenta ne pomakne (na primjer, jer je to jedno od polja te vrijednosti), kao i da se nećete iseliti iz argumenta koji primite u unutarnja funkcija.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SIGURNOST: mora biti ugovor o sigurnosti za `new_unchecked`
        // podržao pozivatelj.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Dohvaća zajedničku referencu iz pribadače.
    ///
    /// To je sigurno jer nije moguće pomaknuti se iz zajedničke reference.
    /// Možda se čini da ovdje postoji problem s promjenljivošću interijera: zapravo je *moguće* premjestiti `T` iz `&RefCell<T>`.
    /// Međutim, to nije problem sve dok ne postoji i `Pin<&T>` koji upućuje na iste podatke, a `RefCell<T>` vam ne dopušta stvaranje stvorene reference na njegov sadržaj.
    ///
    /// Za više detalja pogledajte raspravu o ["pinning projections"].
    ///
    /// Note: `Pin` također implementira `Deref` na cilj, koji se može koristiti za pristup unutarnjoj vrijednosti.
    /// Međutim, `Deref` pruža samo referencu koja živi sve dok posuđuje `Pin`, a ne vijek trajanja samog `Pin`.
    /// Ova metoda omogućuje pretvaranje `Pin` u referencu s istim vijekom trajanja kao i originalni `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Pretvara ovaj `Pin<&mut T>` u `Pin<&T>` s istim vijekom trajanja.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Dobiva promjenjivu referencu na podatke unutar ovog `Pin`.
    ///
    /// To zahtijeva da podaci unutar ovog `Pin` budu `Unpin`.
    ///
    /// Note: `Pin` također implementira `DerefMut` u podatke koji se mogu koristiti za pristup unutarnjoj vrijednosti.
    /// Međutim, `DerefMut` pruža samo referencu koja živi sve dok posuđuje `Pin`, a ne vijek trajanja samog `Pin`.
    ///
    /// Ova metoda omogućuje pretvaranje `Pin` u referencu s istim vijekom trajanja kao i originalni `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Dobiva promjenjivu referencu na podatke unutar ovog `Pin`.
    ///
    /// # Safety
    ///
    /// Ova funkcija nije sigurna.
    /// Morate jamčiti da nikada nećete premjestiti podatke iz promjenjive reference koju primite kad pozovete ovu funkciju, tako da se invarijanti tipa `Pin` mogu podržati.
    ///
    ///
    /// Ako su temeljni podaci `Unpin`, umjesto njih treba koristiti `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Konstruirajte novi klin mapiranjem unutarnje vrijednosti.
    ///
    /// Na primjer, ako ste željeli dobiti `Pin` polja nečega, to biste mogli koristiti za pristup tom polju u jednom retku koda.
    /// Međutim, postoji nekoliko problema s ovim "pinning projections";
    /// potražite dokumentaciju [`pin` module] za daljnje detalje o toj temi.
    ///
    /// # Safety
    ///
    /// Ova funkcija nije sigurna.
    /// Morate jamčiti da se podaci koje vraćate neće pomicati sve dok se vrijednost argumenta ne pomakne (na primjer, jer je to jedno od polja te vrijednosti), kao i da se nećete iseliti iz argumenta koji primite u unutarnja funkcija.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SIGURNOST: pozivatelj je odgovoran za nepomicanje
        // vrijednost izvan ove reference.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SIGURNOST: jer zajamčeno nema vrijednosti `this`
        // je premješten, ovaj poziv na `new_unchecked` je siguran.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Dohvatite prikvačenu referencu iz statičke reference.
    ///
    /// To je sigurno, jer `T` posuđuje se za životni vijek `'static`, koji nikad ne završava.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SIGURNOST: 'Statično posuđivanje jamči da podataka neće biti
        // moved/invalidated dok ne padne (što nikad nije).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Nabavite prikvačenu promjenjivu referencu iz statičke promjenjive reference.
    ///
    /// To je sigurno, jer `T` posuđuje se za životni vijek `'static`, koji nikad ne završava.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SIGURNOST: 'Statično posuđivanje jamči da podataka neće biti
        // moved/invalidated dok ne padne (što nikad nije).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: to znači da svaki impl `CoerceUnsized` koji omogućuje prisilu od
// tip koji implicira `Deref<Target=impl !Unpin>` na tip koji implicira `Deref<Target=Unpin>` nije zvučan.
// Bilo koji takav impl bi vjerojatno bio nerazuman iz drugih razloga, pa samo trebamo paziti da takvi implici ne sletnu u std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}