//! Promjenjivi spremnici koji se mogu dijeliti.
//!
//! Sigurnost memorije Rust temelji se na ovom pravilu: S obzirom na objekt `T`, moguće je imati samo jedno od sljedećeg:
//!
//! - Imati nekoliko nepromjenjivih referenci (`&T`) na objekt (također poznat kao **aliasing**).
//! - Imati jednu promjenjivu referencu (`&mut T`) na objekt (također poznat kao **promjenjivost**).
//!
//! To provodi kompajler Rust.Međutim, postoje situacije u kojima ovo pravilo nije dovoljno fleksibilno.Ponekad je potrebno imati više referenci na objekt, a opet ga mutirati.
//!
//! Postoje izmjenjivi spremnici koji se mogu dijeliti kako bi se omogućila promjenjivost na kontroliran način, čak i u prisutnosti aliasa.I [`Cell<T>`] i [`RefCell<T>`] omogućuju to na jedan navoj.
//! Međutim, ni `Cell<T>` ni `RefCell<T>` nisu zaštićeni niti (ne primjenjuju [`Sync`]).
//! Ako trebate napraviti aliasing i mutaciju između više niti, moguće je koristiti vrste [`Mutex<T>`], [`RwLock<T>`] ili [`atomic`].
//!
//! Vrijednosti tipova `Cell<T>` i `RefCell<T>` mogu se mutirati putem zajedničkih referenci (tj
//! uobičajeni tip `&T`), dok se većina tipova Rust može mutirati samo putem jedinstvenih (`&mut T`) referenci.
//! Kažemo da `Cell<T>` i `RefCell<T>` pružaju "unutarnju promjenjivost", za razliku od tipičnih tipova Rust koji pokazuju "naslijeđenu promjenjivost".
//!
//! Tipovi stanica dolaze u dva okusa: `Cell<T>` i `RefCell<T>`.`Cell<T>` implementira unutarnju promjenjivost premještanjem vrijednosti u `Cell<T>` i izvan njega.
//! Da biste koristili reference umjesto vrijednosti, morate upotrijebiti tip `RefCell<T>`, stječući zaključavanje upisa prije mutiranja.`Cell<T>` nudi metode za dohvaćanje i promjenu trenutne unutarnje vrijednosti:
//!
//!  - Za tipove koji implementiraju [`Copy`], metoda [`get`](Cell::get) dohvaća trenutnu unutarnju vrijednost.
//!  - Za tipove koji implementiraju [`Default`], metoda [`take`](Cell::take) zamjenjuje trenutnu unutarnju vrijednost s [`Default::default()`] i vraća zamijenjenu vrijednost.
//!  - Za sve vrste, metoda [`replace`](Cell::replace) zamjenjuje trenutnu unutarnju vrijednost i vraća zamijenjenu vrijednost, a metoda [`into_inner`](Cell::into_inner) troši `Cell<T>` i vraća unutarnju vrijednost.
//!  Uz to, metoda [`set`](Cell::set) zamjenjuje unutarnju vrijednost, ispuštajući zamijenjenu vrijednost.
//!
//! `RefCell<T>` koristi životni vijek Rust da implementira 'dinamičko posuđivanje', postupak u kojem se može zatražiti privremeni, isključivi, promjenjivi pristup unutarnjoj vrijednosti.
//! Posuđuje za `RefCell<T>`s se prate 'tijekom izvođenja', za razliku od izvornih referentnih tipova Rust koji se u potpunosti prate statički, u vrijeme kompajliranja.
//! Budući da su posude `RefCell<T>` dinamične, moguće je pokušati posuditi vrijednost koja je već promjenjivo posuđena;kada se to dogodi rezultira nitom panic.
//!
//! # Kada odabrati promjenjivost interijera
//!
//! Uobičajena naslijeđena promjenjivost, gdje mora imati jedinstveni pristup za mutiranje vrijednosti, jedan je od ključnih jezičnih elemenata koji omogućava Rust da snažno razmišlja o aliasiranju pokazivača, statički sprječavajući padove.
//! Zbog toga se daje prednost nasljednoj promjenjivosti, a unutarnja promjenjivost je krajnje utočište.
//! Budući da tipovi stanica omogućuju mutaciju tamo gdje ona inače ne bi bila dopuštena, postoje slučajevi kada unutarnja promjenjivost može biti prikladna ili se čak mora koristiti *, npr.
//!
//! * Predstavljamo mutabilnost 'inside' nečeg nepromjenjivog
//! * Detalji provedbe logički nepromjenjivih metoda.
//! * Mutirajuće implementacije [`Clone`].
//!
//! ## Predstavljamo mutabilnost 'inside' nečeg nepromjenjivog
//!
//! Mnogi zajednički tipovi pametnih pokazivača, uključujući [`Rc<T>`] i [`Arc<T>`], pružaju spremnike koji se mogu klonirati i dijeliti između više strana.
//! Budući da sadržane vrijednosti mogu biti multiplicirane, mogu se posuditi samo s `&`, a ne s `&mut`.
//! Bez stanica uopće ne bi bilo moguće mutirati podatke unutar ovih pametnih pokazivača.
//!
//! Tada je vrlo često stavljanje `RefCell<T>` unutar dijeljenih tipova pokazivača kako bi se ponovo uvela promjenjivost:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Stvorite novi blok kako biste ograničili opseg dinamičkog posuđivanja
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Imajte na umu da ako nismo dopustili da prethodno posuđivanje predmemorije ispadne iz opsega, onda bi sljedeće posudbe uzrokovalo dinamičku nit panic.
//!     //
//!     // To je glavna opasnost od upotrebe `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Imajte na umu da ovaj primjer koristi `Rc<T>`, a ne `Arc<T>`.`RefCell<T>`s su za jednonitne scenarije.Razmislite o upotrebi [`RwLock<T>`] ili [`Mutex<T>`] ako vam je potrebna zajednička promjenjivost u situaciji s više niti.
//!
//! ## Detalji provedbe logički nepromjenjivih metoda
//!
//! Povremeno može biti poželjno da se u API-ju ne izloži da se događa mutacija "under the hood".
//! To je možda zato što je logično da je operacija nepromjenjiva, ali npr. Predmemoriranje prisiljava implementaciju na izvođenje mutacije;ili zato što morate primijeniti mutaciju da biste implementirali Portrait metodu koja je prvotno definirana da uzima `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Ovdje ide skupo računanje
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutirajuće implementacije `Clone`
//!
//! Ovo je jednostavno poseban, ali čest slučaj prethodnog: skrivanje promjenjivosti za operacije koje se čine nepromjenjivima.
//! Očekuje se da metoda [`clone`](Clone::clone) neće promijeniti izvornu vrijednost, a deklarirano je da uzima `&self`, a ne `&mut self`.
//! Stoga, svaka mutacija koja se dogodi u metodi `clone` mora koristiti tipove stanica.
//! Na primjer, [`Rc<T>`] održava svoj referentni broj unutar `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Promjenjivo memorijsko mjesto.
///
/// # Examples
///
/// U ovom primjeru možete vidjeti da `Cell<T>` omogućuje mutaciju unutar nepromjenjive strukture.
/// Drugim riječima, omogućuje "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // POGREŠKA: `my_struct` je nepromjenjiv
/// // my_struct.regular_field =nova_vrijednost;
///
/// // DJELA: iako je `my_struct` nepromjenjiv, `special_field` je `Cell`,
/// // koji se uvijek mogu mutirati
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Pogledajte [module-level documentation](self) za više.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Stvara `Cell<T>`, s vrijednošću `Default` za T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Stvara novi `Cell` koji sadrži zadanu vrijednost.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Postavlja sadržanu vrijednost.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Mijenja vrijednosti dvije ćelije.
    /// Razlika s `std::mem::swap` je u tome što za ovu funkciju nije potrebna referenca `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SIGURNOST: To može biti rizično ako se zove iz zasebnih niti, ali `Cell`
        // je `!Sync` pa se to neće dogoditi.
        // Ovo također neće onesposobiti nijedan pokazivač, jer `Cell` osigurava da ništa drugo neće biti usmjereno ni na jednu od ovih `ćelija`.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Zamjenjuje sadržanu vrijednost s `val` i vraća staru sadržanu vrijednost.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SIGURNOST: To može izazvati utrke podataka ako se pozivaju iz zasebne niti,
        // ali `Cell` je `!Sync` pa se to neće dogoditi.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Omotava vrijednost.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Vraća kopiju sadržane vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SIGURNOST: To može izazvati utrke podataka ako se pozivaju iz zasebne niti,
        // ali `Cell` je `!Sync` pa se to neće dogoditi.
        unsafe { *self.value.get() }
    }

    /// Ažurira sadržanu vrijednost pomoću funkcije i vraća novu vrijednost.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Vraća sirovi pokazivač na osnovne podatke u ovoj ćeliji.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Vraća izmjenjivu referencu na osnovne podatke.
    ///
    /// Ovaj poziv posuđuje `Cell` na mjerljiv način (u vrijeme sastavljanja) što jamči da posjedujemo jedinu referencu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Vraća `&Cell<T>` iz `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SIGURNOST: `&mut` osigurava jedinstveni pristup.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Uzima vrijednost ćelije, ostavljajući `Default::default()` na svom mjestu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Vraća `&[Cell<T>]` iz `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SIGURNOST: `Cell<T>` ima isti raspored memorije kao i `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Promjenjivo memorijsko mjesto s dinamički provjerenim pravilima posuđivanja
///
/// Pogledajte [module-level documentation](self) za više.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Pogrešku je vratio [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Pogrešku je vratio [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Pozitivne vrijednosti predstavljaju broj aktivnih `Ref`.Negativne vrijednosti predstavljaju broj aktivnih `RefMut`.
// Višestruki `RefMut` mogu istovremeno biti aktivni samo ako se odnose na različite komponente koje se ne preklapaju (npr. Različiti rasponi kriška).
//
// `Ref` i `RefMut` su dvije riječi u veličini, tako da vjerojatno nikada neće biti dovoljno `Ref`-ova ili`RefMut-a` da pređu polovicu raspona `usize`.
// Dakle, `BorrowFlag` se vjerojatno nikada neće prelijevati ili prelijevati.
// Međutim, to nije jamstvo, jer bi patološki program mogao više puta stvoriti, a zatim mem::forget `Ref`s ili`RefMut`s.
// Stoga sav kôd mora izričito provjeriti preljev i preljev kako bi se izbjegla nesigurnost ili se barem ponašao ispravno u slučaju da se dogodi preljev ili podlijevanje (npr. Vidi BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Stvara novi `RefCell` koji sadrži `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Konzumira `RefCell`, vraća umotanu vrijednost.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Budući da ova funkcija uzima `self` (`RefCell`) po vrijednosti, kompajler statički provjerava da trenutno nije posuđena.
        //
        self.value.into_inner()
    }

    /// Zamjenjuje umotanu vrijednost novom, vraćajući staru vrijednost, bez deinicijalizacije bilo koje.
    ///
    ///
    /// Ova funkcija odgovara [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost trenutno posuđena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Zamjenjuje zamotanu vrijednost novom izračunatom iz `f`, vraćajući staru vrijednost, bez deinicijalizacije bilo koje.
    ///
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost trenutno posuđena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Mijenja zamotanu vrijednost `self` s zamotanom vrijednošću `other`, bez deinicijalizacije bilo koje.
    ///
    ///
    /// Ova funkcija odgovara [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost u bilo kojem `RefCell` trenutno posuđena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Nepromjenjivo posuđuje zamotanu vrijednost.
    ///
    /// Posudba traje sve dok vraćeni `Ref` ne izađe iz opsega.
    /// Mogu se istodobno uzeti više nepromjenjivih posudbi.
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost trenutno mutabilno posuđena.
    /// Za inačicu bez panike koristite [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Primjer panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Neizmjenjivo posuđuje umotanu vrijednost, vraćajući pogrešku ako je vrijednost trenutno zamjenjivo.
    ///
    ///
    /// Posudba traje sve dok vraćeni `Ref` ne izađe iz opsega.
    /// Mogu se istodobno uzeti više nepromjenjivih posudbi.
    ///
    /// Ovo je inačica [`borrow`](#method.borrow) bez panike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SIGURNOST: `BorrowRef` osigurava samo nepromjenjivi pristup
            // na vrijednost dok je posuđena.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Promjenjivo posuđuje zamotanu vrijednost.
    ///
    /// Posudba traje sve dok vraćeni `RefMut` ili svi `RefMut` izvedeni iz opsega izlaza.
    ///
    /// Vrijednost se ne može posuditi dok je ta posudba aktivna.
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost trenutno posuđena.
    /// Za inačicu bez panike koristite [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Primjer panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Promjenjivo posuđuje umotanu vrijednost, vraćajući pogrešku ako je vrijednost trenutno posuđena.
    ///
    ///
    /// Posudba traje sve dok vraćeni `RefMut` ili svi `RefMut` izvedeni iz opsega izlaza.
    /// Vrijednost se ne može posuditi dok je ta posudba aktivna.
    ///
    /// Ovo je inačica [`borrow_mut`](#method.borrow_mut) bez panike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SIGURNOST: `BorrowRef` jamči jedinstveni pristup.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Vraća sirovi pokazivač na osnovne podatke u ovoj ćeliji.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Vraća izmjenjivu referencu na osnovne podatke.
    ///
    /// Ovaj poziv posuđuje `RefCell` na zamjenski način (u vrijeme sastavljanja), tako da nema potrebe za dinamičkim provjerama.
    ///
    /// No budite oprezni: ova metoda očekuje da će `self` biti promjenjiv, što obično nije slučaj kada se koristi `RefCell`.
    ///
    /// Umjesto toga, pogledajte metodu [`borrow_mut`] ako `self` nije promjenjiv.
    ///
    /// Također, imajte na umu da je ova metoda namijenjena samo posebnim okolnostima i obično nije ono što želite.
    /// U slučaju sumnje, umjesto toga upotrijebite [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Poništite učinak procurjelih zaštitnika na stanje posuđivanja `RefCell`.
    ///
    /// Ovaj je poziv sličan modelu [`get_mut`], ali je specijaliziraniji.
    /// Izmjenjivo posuđuje `RefCell` kako bi se osiguralo da ne postoje zajmovi, a zatim resetira zajedničke posudbe za praćenje stanja.
    /// Ovo je relevantno ako su procurile neke posude `Ref` ili `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Neizmjenjivo posuđuje umotanu vrijednost, vraćajući pogrešku ako je vrijednost trenutno zamjenjivo.
    ///
    /// # Safety
    ///
    /// Za razliku od `RefCell::borrow`, ova metoda nije sigurna jer ne vraća `Ref`, čime zastavica posuđivanja ostaje netaknuta.
    /// Izmjenjivo posuđivanje `RefCell` dok je referenca vraćena ovom metodom živa je nedefinirano ponašanje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SIGURNOST: Provjeravamo da sada nitko aktivno ne piše, ali jest
            // odgovornost pozivatelja da osigura da nitko ne piše dok se vraćena referenca više ne koristi.
            // Također, `self.value.get()` se odnosi na vrijednost u vlasništvu `self` i stoga je zajamčeno da vrijedi za život `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Uzima zamotanu vrijednost, ostavljajući `Default::default()` na svom mjestu.
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost trenutno posuđena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ako je vrijednost trenutno mutabilno posuđena.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Stvara `RefCell<T>`, s vrijednošću `Default` za T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ako je vrijednost u bilo kojem `RefCell` trenutno posuđena.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ako je vrijednost u bilo kojem `RefCell` trenutno posuđena.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ako je vrijednost u bilo kojem `RefCell` trenutno posuđena.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ako je vrijednost u bilo kojem `RefCell` trenutno posuđena.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ako je vrijednost u bilo kojem `RefCell` trenutno posuđena.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ako je vrijednost u bilo kojem `RefCell` trenutno posuđena.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ako je vrijednost u bilo kojem `RefCell` trenutno posuđena.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Povećavanje posudbe može rezultirati vrijednošću koja nije očitana (<=0) u ovim slučajevima:
            // 1. Bilo je <0, tj. Postoje zajmovi za pisanje, tako da ne možemo dopustiti čitanje posuđivanja zbog Rust-ovih pravila aliasinga referenci
            // 2.
            // To je bio isize::MAX (maksimalan iznos pozajmljivanja za čitanje) i prelio se u isize::MIN (maksimalni iznos zajmova za pisanje), tako da ne možemo dopustiti dodatno posuđivanje za čitanje, jer isize ne može predstavljati toliko pročitanih posuđivanja (to se može dogoditi samo vi mem::forget više od male konstantne količine `Ref-a`, što nije dobra praksa)
            //
            //
            //
            //
            None
        } else {
            // Povećavanje posudbe može rezultirati vrijednošću čitanja (> 0) u sljedećim slučajevima:
            // 1. Bilo je=0, tj. Nije posuđeno, a uzimamo prvo pročitano posuđivanje
            // 2. Bilo je> 0 i <isize::MAX, tj
            // bilo je pročitanih posuđenih predmeta, a isize je dovoljno velik da predstavlja još jedno pročitano posuđivanje
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Budući da ovaj Ref postoji, znamo da je zastava posuđivanja posudba za čitanje.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Spriječite da se brojač posudbi prelije u zajmove koji se upisuju.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Umotava posuđenu referencu na vrijednost u okvir `RefCell`.
/// Vrsta omota za nepromjenjivo posuđenu vrijednost iz `RefCell<T>`.
///
/// Pogledajte [module-level documentation](self) za više.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopira `Ref`.
    ///
    /// `RefCell` je već nepromjenjivo posuđen, pa to ne može uspjeti.
    ///
    /// Ovo je pridružena funkcija koja se mora koristiti kao `Ref::clone(...)`.
    /// Implementacija `Clone` ili metoda ometati će široku upotrebu `r.borrow().clone()` za kloniranje sadržaja `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Izrađuje novi `Ref` za komponentu posuđenih podataka.
    ///
    /// `RefCell` je već nepromjenjivo posuđen, pa to ne može uspjeti.
    ///
    /// Ovo je pridružena funkcija koja se mora koristiti kao `Ref::map(...)`.
    /// Metoda bi ometala istoimene metode na sadržaju `RefCell` koji se koristi kroz `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Izrađuje novi `Ref` za opcijsku komponentu posuđenih podataka.
    /// Izvorni štitnik vraća se kao `Err(..)` ako zatvarač vrati `None`.
    ///
    /// `RefCell` je već nepromjenjivo posuđen, pa to ne može uspjeti.
    ///
    /// Ovo je pridružena funkcija koja se mora koristiti kao `Ref::filter_map(...)`.
    /// Metoda bi ometala istoimene metode na sadržaju `RefCell` koji se koristi kroz `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Dijeli `Ref` na više `refova` za različite komponente posuđenih podataka.
    ///
    /// `RefCell` je već nepromjenjivo posuđen, pa to ne može uspjeti.
    ///
    /// Ovo je pridružena funkcija koja se mora koristiti kao `Ref::map_split(...)`.
    /// Metoda bi ometala istoimene metode na sadržaju `RefCell` koji se koristi kroz `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Pretvori u referencu na osnovne podatke.
    ///
    /// Temeljni `RefCell` nikada se više ne može mijenjati i uvijek će se činiti već nepromjenjivo posuđenim.
    ///
    /// Nije dobra ideja propuštati više od stalnog broja referenci.
    /// `RefCell` se može ponovno posuditi nepromjenjivo ako se ukupno dogodio samo manji broj curenja.
    ///
    /// Ovo je pridružena funkcija koja se mora koristiti kao `Ref::leak(...)`.
    /// Metoda bi ometala istoimene metode na sadržaju `RefCell` koji se koristi kroz `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Zaboravljanjem ovog Ref osiguravamo da se brojač posudbi u RefCell-u ne može vratiti na UNUSED tijekom životnog vijeka `'b`.
        // Resetiranje stanja praćenja referenci zahtijevalo bi jedinstvenu referencu na posuđenu RefCell.
        // Iz izvorne ćelije ne mogu se stvoriti daljnje izmjenjive reference.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Izrađuje novi `RefMut` za komponentu posuđenih podataka, npr. Varijantu nabrajanja.
    ///
    /// `RefCell` je već zamjenljivo posuđen, pa to ne može uspjeti.
    ///
    /// Ovo je pridružena funkcija koja se mora koristiti kao `RefMut::map(...)`.
    /// Metoda bi ometala istoimene metode na sadržaju `RefCell` koji se koristi kroz `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): popraviti posuđivanje-ček
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Izrađuje novi `RefMut` za opcijsku komponentu posuđenih podataka.
    /// Izvorni štitnik vraća se kao `Err(..)` ako zatvarač vrati `None`.
    ///
    /// `RefCell` je već zamjenljivo posuđen, pa to ne može uspjeti.
    ///
    /// Ovo je pridružena funkcija koja se mora koristiti kao `RefMut::filter_map(...)`.
    /// Metoda bi ometala istoimene metode na sadržaju `RefCell` koji se koristi kroz `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): popraviti posuđivanje-ček
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SIGURNOST: funkcija zadržava ekskluzivnu referencu tijekom trajanja
        // svog poziva kroz `orig`, a pokazivač je dereferenciran samo unutar poziva funkcije, nikad ne dopuštajući da ekskluzivna referenca pobjegne.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SIGURNOST: isto kao gore.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Dijeli `RefMut` na više `RefMut-ova` za različite komponente posuđenih podataka.
    ///
    /// Temeljni `RefCell` ostat će zamjenski posuđen sve dok oba vraćena `RefMuta` ne izlaze iz opsega.
    ///
    /// `RefCell` je već zamjenljivo posuđen, pa to ne može uspjeti.
    ///
    /// Ovo je pridružena funkcija koja se mora koristiti kao `RefMut::map_split(...)`.
    /// Metoda bi ometala istoimene metode na sadržaju `RefCell` koji se koristi kroz `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Pretvorite u promjenjivu referencu na temeljne podatke.
    ///
    /// Temeljni `RefCell` ne može se ponovno posuditi i uvijek će se činiti već promjenjivo posuđenim, što čini vraćenu referencu jedinom za interijer.
    ///
    ///
    /// Ovo je pridružena funkcija koja se mora koristiti kao `RefMut::leak(...)`.
    /// Metoda bi ometala istoimene metode na sadržaju `RefCell` koji se koristi kroz `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Zaboravljajući ovaj BorrowRefMut osiguravamo da se brojač zajmova u RefCell-u ne može vratiti na UNUSED unutar životnog vijeka `'b`.
        // Resetiranje stanja praćenja referenci zahtijevalo bi jedinstvenu referencu na posuđenu RefCell.
        // U tom se životnom vijeku ne mogu stvoriti daljnje reference iz izvorne ćelije, što čini trenutnu posuđivanje jedinom referencom za preostali životni vijek.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Za razliku od BorrowRefMut::clone, new se poziva da stvori inicijal
        // promjenjiva referenca, tako da trenutno ne smije postojati postojeća referenca.
        // Dakle, dok klon uvećava promjenjivi brojač, ovdje izričito dopuštamo samo prelazak s UNUSED na UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klonira `BorrowRefMut`.
    //
    // To vrijedi samo ako se svaki `BorrowRefMut` koristi za praćenje promjenjive reference na različit, nepreklapajući raspon izvornog objekta.
    //
    // Ovo nije u impliciranju Clone, tako da ga kod ne implicitno poziva.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Spriječite da se brojač posuđenih sredstava ne izlijeva.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Vrsta omota za mutabilno posuđenu vrijednost iz `RefCell<T>`.
///
/// Pogledajte [module-level documentation](self) za više.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Osnovni primitiv za unutarnju promjenjivost u Rust.
///
/// Ako imate referencu `&T`, tada u Rust kompajler izvodi optimizacije na temelju znanja da `&T` upućuje na nepromjenjive podatke.Mutiranje tih podataka, na primjer putem zamjenskog imena ili pretvaranjem `&T` u `&mut T`, smatra se nedefiniranim ponašanjem.
/// `UnsafeCell<T>` isključenje jamstva nepromjenjivosti za `&T`: zajednička referenca `&UnsafeCell<T>` može ukazivati na podatke koji se mutiraju.To se naziva "interior mutability".
///
/// Sve druge vrste koje dopuštaju unutarnju promjenjivost, poput `Cell<T>` i `RefCell<T>`, interno koriste `UnsafeCell` za umotavanje svojih podataka.
///
/// Imajte na umu da `UnsafeCell` utječe samo na jamstvo nepromjenjivosti za zajedničke reference.To ne utječe na jamstvo jedinstvenosti za izmjenjive reference.Ne postoji * zakonit način za dobivanje pseudonima `&mut`, čak ni kod `UnsafeCell<T>`.
///
/// Sam API `UnsafeCell` tehnički je vrlo jednostavan: [`.get()`] daje sirovi pokazivač `*mut T` na njegov sadržaj.Do _you_ kao dizajnera apstrakcije ovisi hoće li ispravno koristiti taj sirovi pokazivač.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Precizna alias pravila Rust donekle su u promjeni, ali glavne točke nisu sporne:
///
/// - Ako stvorite sigurnu referencu s vijekom trajanja `'a` (bilo referencu `&T` ili `&mut T`) kojoj je dostupan sigurni kôd (na primjer, zato što ste je vratili), ne smijete pristupiti podacima na bilo koji način koji je u suprotnosti s tom referencom za ostatak od `'a`.
/// Na primjer, to znači da ako uzmete `*mut T` iz `UnsafeCell<T>` i prebacite ga na `&T`, tada podaci u `T` moraju ostati nepromjenjivi (naravno svi moduli `UnsafeCell` pronađeni unutar `T`) dok ne istekne životni vijek te reference.
/// Slično tome, ako kreirate referencu `&mut T` koja je puštena u sigurni kod, tada ne smijete pristupati podacima unutar `UnsafeCell` dok ta referenca ne istekne.
///
/// - U svakom trenutku morate izbjegavati podatkovne utrke.Ako više niti ima pristup istom `UnsafeCell`, tada svako zapisivanje mora imati odgovarajući odnos prije svih ostalih pristupa (ili koristiti atomiku).
///
/// Da bi se pomoglo u pravilnom dizajnu, sljedeći su scenariji izričito proglašeni legalnim za jednonitni kôd:
///
/// 1. Referenca `&T` može se objaviti na sigurnom kodu i tamo može koegzistirati s drugim referencama `&T`, ali ne i s `&mut T`
///
/// 2. Referenca `&mut T` može se objaviti na sigurnom kodu pod uvjetom da niti drugi `&mut T` niti `&T` ne postoje zajedno s njim.`&mut T` uvijek mora biti jedinstven.
///
/// Imajte na umu da, iako je mutiranje sadržaja `&UnsafeCell<T>` (čak i dok drugi `&UnsafeCell<T>` referencira alias ćeliju) u redu (pod uvjetom da gore navedene invarijante primijenite na neki drugi način), još uvijek nije definirano ponašanje imati više `&mut UnsafeCell<T>` pseudonima.
/// Odnosno, `UnsafeCell` je omot dizajniran da ima posebnu interakciju s _shared_ accesses (_i.e._, putem reference `&UnsafeCell<_>`);nema nikakve čarolije kada se radi s _exclusive_ accesses (_e.g._, kroz `&mut UnsafeCell<_>`): ni ćelija ni umotana vrijednost ne mogu biti otuđeni tijekom trajanja tog posuđenog `&mut`.
///
/// To pokazuje [`.get_mut()`] dodatak, koji je _safe_ getter koji daje `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Evo primjera koji prikazuje kako zvučno mutirati sadržaj `UnsafeCell<_>`-a, unatoč tome što je više referenci stavilo pseudonime na ćeliju:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Nabavite višestruke/zajedničke reference na isti `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SIGURNOST: u ovom opsegu nema drugih referenci na sadržaj `x`-a,
///     // tako da je naš zapravo jedinstven.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- posuditi-+
///     *p1_exclusive += 27; // |
/// } // <---------- ne može ići dalje od ove točke -------------------+
///
/// unsafe {
///     // SIGURNOST: u ovom opsegu nitko ne očekuje ekskluzivan pristup sadržaju `x`-a,
///     // tako da istovremeno možemo imati više zajedničkih pristupa.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Sljedeći primjer prikazuje činjenicu da ekskluzivni pristup `UnsafeCell<T>` podrazumijeva ekskluzivni pristup njegovom `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // s ekskluzivnim pristupima,
///                         // `UnsafeCell` je prozirni no-op omot, tako da ovdje nema potrebe za `unsafe`.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Nabavite jedinstvenu referencu na `x` provjerenu tijekom kompajliranja.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Ekskluzivnom referencom možemo besplatno mutirati sadržaj.
/// *p_unique.get_mut() = 0;
/// // Ili, ekvivalentno:
/// x = UnsafeCell::new(0);
///
/// // Kad posjedujemo vrijednost, možemo besplatno izdvojiti sadržaj.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Konstruira novu instancu `UnsafeCell` koja će umotati navedenu vrijednost.
    ///
    ///
    /// Sav pristup unutarnjoj vrijednosti putem metoda je `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Omotava vrijednost.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Dobiva promjenjivi pokazivač na zamotanu vrijednost.
    ///
    /// To se može baciti na pokazivač bilo koje vrste.
    /// Osigurajte da je pristup jedinstven (bez aktivnih referenci, promjenjivih ili ne) prilikom emitiranja na `&mut T` i osigurajte da se ne događaju mutacije ili promjenjivi aliasi prilikom emitiranja na `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Zbog #[repr(transparent)] možemo jednostavno prebaciti pokazivač iz `UnsafeCell<T>` u `T`.
        // Ovo iskorištava poseban status libstd-a, ne postoji jamstvo za korisnički kod da će to raditi u future verzijama prevoditelja!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Vraća izmjenjivu referencu na osnovne podatke.
    ///
    /// Ovaj poziv `UnsafeCell` posuđuje na mutalan način (u vrijeme sastavljanja) što jamči da posjedujemo jedinu referencu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Dobiva promjenjivi pokazivač na zamotanu vrijednost.
    /// Razlika u odnosu na [`get`] je u tome što ova funkcija prihvaća sirovi pokazivač, što je korisno za izbjegavanje stvaranja privremenih referenci.
    ///
    /// Rezultat se može prebaciti na pokazivač bilo koje vrste.
    /// Osigurajte da je pristup jedinstven (bez aktivnih referenci, promjenjivih ili ne) prilikom emitiranja na `&mut T` i osigurajte da se ne vrše mutacije ili promjenjivi pseudonimi prilikom emitiranja na `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Za postupnu inicijalizaciju `UnsafeCell` potreban je `raw_get`, jer bi pozivanje `get` zahtijevalo stvaranje reference na neinicijalizirane podatke:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Zbog #[repr(transparent)] možemo jednostavno prebaciti pokazivač iz `UnsafeCell<T>` u `T`.
        // Ovo iskorištava poseban status libstd-a, ne postoji jamstvo za korisnički kod da će to raditi u future verzijama prevoditelja!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Stvara `UnsafeCell`, s vrijednošću `Default` za T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}