//! API-ji za dodjelu memorije

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Pogreška `AllocError` ukazuje na neuspjeh alokacije koji je možda posljedica iscrpljenosti resursa ili nečega pogrešnog pri kombiniranju zadanih ulaznih argumenata s ovim alokatorom.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ovo nam treba za nizvodno impl. pogreške Portrait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Implementacija `Allocator` može dodijeliti, povećati, smanjiti i osloboditi proizvoljne blokove podataka opisane putem [`Layout`][].
///
/// `Allocator` je dizajniran za implementaciju na ZST-ove, reference ili pametne pokazivače jer se raspoređivač poput `MyAlloc([u8; N])` ne može premjestiti bez ažuriranja pokazivača na dodijeljenu memoriju.
///
/// Za razliku od [`GlobalAlloc`][], u `Allocator` su dopuštene dodjele nulte veličine.
/// Ako osnovni alokator to ne podržava (poput jemalloc) ili ne vraća null pokazivač (kao što je `libc::malloc`), to implementacija mora uhvatiti.
///
/// ### Trenutno dodijeljena memorija
///
/// Neke od metoda zahtijevaju da se memorijski blok *trenutno dodjeljuje* putem alokatora.Ovo znači to:
///
/// * početnu adresu za taj memorijski blok prethodno su vratili [`allocate`], [`grow`] ili [`shrink`] i
///
/// * memorijski blok nije naknadno oslobođen, pri čemu se blokovi ili oslobađaju izravno prenošenjem na [`deallocate`] ili su promijenjeni prosljeđivanjem u [`grow`] ili [`shrink`] koji vraća `Ok`.
///
/// Ako su `grow` ili `shrink` vratili `Err`, proslijeđeni pokazivač ostaje važeći.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Uklapanje memorije
///
/// Neke od metoda zahtijevaju da raspored *stane* u memorijski blok.
/// Što znači za izgled na "fit" memorijski blok znači (ili što je jednako tome, za memorijski blok na "fit" raspored) je da moraju biti ispunjeni sljedeći uvjeti:
///
/// * Blok mora biti dodijeljen s istim poravnanjem kao i [`layout.align()`] i
///
/// * Navedeni [`layout.size()`] mora spadati u raspon `min ..= max`, gdje:
///   - `min` je veličina izgleda koji je posljednji put korišten za dodjelu bloka i
///   - `max` je najnovija stvarna veličina vraćena iz [`allocate`], [`grow`] ili [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Memorijski blokovi vraćeni iz alokatora moraju usmjeravati na valjanu memoriju i zadržati svoju valjanost sve dok instanca i svi njezini klonovi ne budu ispušteni,
///
/// * kloniranje ili premještanje alokatora ne smije poništiti memorijske blokove vraćene iz ovog alokatora.Klonirani alokator mora se ponašati poput istog alocatora, i
///
/// * bilo koji pokazivač na memorijski blok koji je [*currently allocated*] može se proslijediti bilo kojoj drugoj metodi raspodjeljivača.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Pokušaji dodjeljivanja bloka memorije.
    ///
    /// Nakon uspjeha vraća [`NonNull<[u8]>`][NonNull] koji ispunjava garancije veličine i poravnanja kao `layout`.
    ///
    /// Vraćeni blok može imati veću veličinu od one koju je odredio `layout.size()`, a njegov sadržaj može i ne mora biti inicijaliziran.
    ///
    /// # Errors
    ///
    /// Vraćanje `Err` znači da je ili memorija iscrpljena ili `layout` ne zadovoljava ograničenja veličine ili poravnanja alokatora.
    ///
    /// Implementacije se potiču da `Err` vrate na iscrpljivanje memorije, a ne na paniku ili prekid, ali to nije strog zahtjev.
    /// (Točnije: legalno je * implementirati ovaj Portrait iznad osnovne izvorne alokacijske knjižnice koja prekida pri iscrpljivanju memorije.)
    ///
    /// Klijenti koji žele prekinuti izračunavanje kao odgovor na pogrešku dodjele potiču se da pozovu funkciju [`handle_alloc_error`], umjesto da izravno pozivaju `panic!` ili slično.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Ponaša se poput `allocate`, ali također osigurava da se vraćena memorija nulta inicijalizira.
    ///
    /// # Errors
    ///
    /// Vraćanje `Err` znači da je ili memorija iscrpljena ili `layout` ne zadovoljava ograničenja veličine ili poravnanja alokatora.
    ///
    /// Implementacije se potiču da `Err` vrate na iscrpljivanje memorije, a ne na paniku ili prekid, ali to nije strog zahtjev.
    /// (Točnije: legalno je * implementirati ovaj Portrait iznad osnovne izvorne alokacijske knjižnice koja prekida pri iscrpljivanju memorije.)
    ///
    /// Klijenti koji žele prekinuti izračunavanje kao odgovor na pogrešku dodjele potiču se da pozovu funkciju [`handle_alloc_error`], umjesto da izravno pozivaju `panic!` ili slično.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SIGURNOST: `alloc` vraća važeći memorijski blok
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Dodijeljuje memoriju na koju se poziva `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` mora označavati blok memorije [*currently allocated*] putem ovog alokatora, i
    /// * `layout` mora [*fit*] taj blok memorije.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Pokušaji proširenja memorijskog bloka.
    ///
    /// Vraća novi [`NonNull<[u8]>`][NonNull] koji sadrži pokazivač i stvarnu veličinu dodijeljene memorije.Pokazivač je prikladan za čuvanje podataka opisanih u `new_layout`.
    /// Da bi to postigao, raspodjeljivač može proširiti dodjelu na koju se poziva `ptr` kako bi odgovarao novom rasporedu.
    ///
    /// Ako ovo vrati `Ok`, tada je vlasništvo nad memorijskim blokom na koji se poziva `ptr` preneseno na ovaj alocator.
    /// Memorija je možda oslobođena ili ne, te bi se trebala smatrati neupotrebljivom ako nije ponovno vraćena pozivatelju putem povratne vrijednosti ove metode.
    ///
    /// Ako ova metoda vrati `Err`, tada vlasništvo nad memorijskim blokom nije preneseno na ovaj alokator, a sadržaj memorijskog bloka je nepromijenjen.
    ///
    /// # Safety
    ///
    /// * `ptr` mora označavati blok memorije [*currently allocated*] putem ovog alokatora.
    /// * `old_layout` mora [*fit*] taj blok memorije (argument `new_layout` ne mora mu odgovarati.).
    /// * `new_layout.size()` mora biti veći ili jednak `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vraća `Err` ako novi izgled ne udovoljava veličini i ograničenjima poravnanja alokatora ili ako rast na drugi način ne uspije.
    ///
    /// Implementacije se potiču da `Err` vrate na iscrpljivanje memorije, a ne na paniku ili prekid, ali to nije strog zahtjev.
    /// (Točnije: legalno je * implementirati ovaj Portrait iznad osnovne izvorne alokacijske knjižnice koja prekida pri iscrpljivanju memorije.)
    ///
    /// Klijenti koji žele prekinuti izračunavanje kao odgovor na pogrešku dodjele potiču se da pozovu funkciju [`handle_alloc_error`], umjesto da izravno pozivaju `panic!` ili slično.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIGURNOST: jer `new_layout.size()` mora biti veći ili jednak
        // `old_layout.size()`, i stara i nova dodjela memorije vrijede za čitanje i pisanje za `old_layout.size()` bajtove.
        // Također, budući da stara dodjela još nije bila oslobođena, ne može se preklapati s `new_ptr`.
        // Stoga je poziv na `copy_nonoverlapping` siguran.
        // Pozivatelj mora održati sigurnosni ugovor za `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ponaša se poput `grow`, ali također osigurava da se novi sadržaj postavi na nulu prije vraćanja.
    ///
    /// Memorijski blok sadržavat će sljedeći sadržaj nakon uspješnog poziva na
    /// `grow_zeroed`:
    ///   * Bajtovi `0..old_layout.size()` sačuvani su iz izvorne dodjele.
    ///   * Bajtovi `old_layout.size()..old_size` bit će ili sačuvani ili nulirani, ovisno o implementaciji alokatora.
    ///   `old_size` odnosi se na veličinu memorijskog bloka prije poziva `grow_zeroed`, koja može biti veća od veličine koja je prvotno tražena kada je dodijeljena.
    ///   * Bajtovi `old_size..new_size` su nulirani.`new_size` odnosi se na veličinu memorijskog bloka koji je vratio poziv `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` mora označavati blok memorije [*currently allocated*] putem ovog alokatora.
    /// * `old_layout` mora [*fit*] taj blok memorije (argument `new_layout` ne mora mu odgovarati.).
    /// * `new_layout.size()` mora biti veći ili jednak `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vraća `Err` ako novi izgled ne udovoljava veličini i ograničenjima poravnanja alokatora ili ako rast na drugi način ne uspije.
    ///
    /// Implementacije se potiču da `Err` vrate na iscrpljivanje memorije, a ne na paniku ili prekid, ali to nije strog zahtjev.
    /// (Točnije: legalno je * implementirati ovaj Portrait iznad osnovne izvorne alokacijske knjižnice koja prekida pri iscrpljivanju memorije.)
    ///
    /// Klijenti koji žele prekinuti izračunavanje kao odgovor na pogrešku dodjele potiču se da pozovu funkciju [`handle_alloc_error`], umjesto da izravno pozivaju `panic!` ili slično.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SIGURNOST: jer `new_layout.size()` mora biti veći ili jednak
        // `old_layout.size()`, i stara i nova dodjela memorije vrijede za čitanje i pisanje za `old_layout.size()` bajtove.
        // Također, budući da stara dodjela još nije bila oslobođena, ne može se preklapati s `new_ptr`.
        // Stoga je poziv na `copy_nonoverlapping` siguran.
        // Pozivatelj mora održati sigurnosni ugovor za `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Pokušaji smanjenja memorijskog bloka.
    ///
    /// Vraća novi [`NonNull<[u8]>`][NonNull] koji sadrži pokazivač i stvarnu veličinu dodijeljene memorije.Pokazivač je prikladan za čuvanje podataka opisanih u `new_layout`.
    /// Da bi to postigao, raspodjeljivač može smanjiti dodjelu na koju se poziva `ptr` kako bi odgovarao novom rasporedu.
    ///
    /// Ako ovo vrati `Ok`, tada je vlasništvo nad memorijskim blokom na koji se poziva `ptr` preneseno na ovaj alocator.
    /// Memorija je možda oslobođena ili ne, te bi se trebala smatrati neupotrebljivom ako nije ponovno vraćena pozivatelju putem povratne vrijednosti ove metode.
    ///
    /// Ako ova metoda vrati `Err`, tada vlasništvo nad memorijskim blokom nije preneseno na ovaj alokator, a sadržaj memorijskog bloka je nepromijenjen.
    ///
    /// # Safety
    ///
    /// * `ptr` mora označavati blok memorije [*currently allocated*] putem ovog alokatora.
    /// * `old_layout` mora [*fit*] taj blok memorije (argument `new_layout` ne mora mu odgovarati.).
    /// * `new_layout.size()` mora biti manji ili jednak `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vraća `Err` ako novi raspored ne udovoljava veličini i ograničenjima poravnanja raspodjeljivača ili ako skupljanje na drugi način ne uspije.
    ///
    /// Implementacije se potiču da `Err` vrate na iscrpljivanje memorije, a ne na paniku ili prekid, ali to nije strog zahtjev.
    /// (Točnije: legalno je * implementirati ovaj Portrait iznad osnovne izvorne alokacijske knjižnice koja prekida pri iscrpljivanju memorije.)
    ///
    /// Klijenti koji žele prekinuti izračunavanje kao odgovor na pogrešku dodjele potiču se da pozovu funkciju [`handle_alloc_error`], umjesto da izravno pozivaju `panic!` ili slično.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIGURNOST: jer `new_layout.size()` mora biti niži ili jednak
        // `old_layout.size()`, i stara i nova dodjela memorije vrijede za čitanje i pisanje za `new_layout.size()` bajtove.
        // Također, budući da stara dodjela još nije bila oslobođena, ne može se preklapati s `new_ptr`.
        // Stoga je poziv na `copy_nonoverlapping` siguran.
        // Pozivatelj mora održati sigurnosni ugovor za `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Stvara "by reference" adapter za ovaj primjerak `Allocator`.
    ///
    /// Vraćeni adapter također implementira `Allocator` i jednostavno će ga posuditi.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SIGURNOST: pozivatelj mora održati ugovor o sigurnosti
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURNOST: pozivatelj mora održati ugovor o sigurnosti
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURNOST: pozivatelj mora održati ugovor o sigurnosti
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURNOST: pozivatelj mora održati ugovor o sigurnosti
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}