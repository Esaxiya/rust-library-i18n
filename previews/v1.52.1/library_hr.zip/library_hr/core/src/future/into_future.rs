use crate::future::Future;

/// Konverzija u `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Izlaz koji će future proizvesti po završetku.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// U koju vrstu future pretvaramo ovo?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Stvara future od vrijednosti.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}