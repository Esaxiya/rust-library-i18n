#![stable(feature = "futures_api", since = "1.36.0")]

//! Asinkrone vrijednosti.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Ova vrsta je potrebna jer:
///
/// a) Generatori ne mogu implementirati `for<'a, 'b> Generator<&'a mut Context<'b>>`, pa moramo proslijediti sirovi pokazivač (vidi <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Sirovi pokazivači i `NonNull` nisu `Send` ili `Sync`, pa bi to također činilo svaki pojedini future non-Send/Sync, a mi to ne želimo.
///
/// Također pojednostavljuje HIR spuštanje `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Zamotajte generator u future.
///
/// Ova funkcija vraća `GenFuture` odozdo, ali ga skriva u `impl Trait` dajući bolje poruke o pogreškama (`impl Future`, a ne `GenFuture<[closure.....]>`).
///
// Ovo je `const` kako bi se izbjegle dodatne pogreške nakon što se oporavimo od `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Oslanjamo se na činjenicu da su async/await futures nepokretne kako bi stvorile samoreferencijalne posude u osnovnom generatoru.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SIGURNOST: Sigurno jer smo !Unpin + !Drop, a ovo je samo projekcija polja.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Ponovno pokrenite generator, pretvarajući `&mut Context` u `NonNull` sirovi pokazivač.
            // Spuštanje `.await` sigurno će to vratiti na `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SIGURNOST: pozivatelj mora jamčiti da je `cx.0` valjani pokazivač
    // koji ispunjava sve zahtjeve za promjenjivu referencu.
    unsafe { &mut *cx.0.as_ptr().cast() }
}