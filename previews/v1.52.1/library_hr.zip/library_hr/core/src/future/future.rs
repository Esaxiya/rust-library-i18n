#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future predstavlja asinkrono računanje.
///
/// future je vrijednost koja možda još nije završila računanje.
/// Ova vrsta "asynchronous value" omogućuje niti da nastavi obavljati koristan posao dok čeka da vrijednost postane dostupna.
///
///
/// # Metoda `poll`
///
/// Osnovna metoda future, `poll`,*pokušava* razriješiti future u konačnu vrijednost.
/// Ova metoda ne blokira ako vrijednost nije spremna.
/// Umjesto toga, predviđeno je buđenje trenutnog zadatka kada je moguće daljnji napredak ponovnim `anketiranjem`.
/// `context` proslijeđen metodi `poll` može pružiti [`Waker`], koji je ručica za buđenje trenutnog zadatka.
///
/// Kada koristite future, općenito nećete pozivati `poll` izravno, već `.await` vrijednost.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Vrsta vrijednosti koja se stvara nakon završetka.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Pokušajte riješiti future na konačnu vrijednost, registrirajući trenutni zadatak za buđenje ako vrijednost još nije dostupna.
    ///
    /// # Povratna vrijednost
    ///
    /// Ova funkcija vraća:
    ///
    /// - [`Poll::Pending`] ako future još nije spreman
    /// - [`Poll::Ready(val)`] s rezultatom `val` ovog future ako je uspješno završio.
    ///
    /// Kad je future gotov, klijenti ga više ne bi smjeli `poll`.
    ///
    /// Kada future još nije spreman, `poll` vraća `Poll::Pending` i pohranjuje klon [`Waker`] kopiran iz trenutnog [`Context`].
    /// Ovaj [`Waker`] se zatim probudi kad future može napredovati.
    /// Na primjer, future koji čeka da utičnica postane čitljiva nazvat će `.clone()` na [`Waker`] i pohraniti je.
    /// Kada signal stigne negdje drugdje koji ukazuje da je utičnica čitljiva, poziva se [`Waker::wake`] i budi se zadatak utičnice future.
    /// Jednom kad se zadatak probudi, trebao bi ponovno pokušati `poll` future, što može ili ne mora dati konačnu vrijednost.
    ///
    /// Imajte na umu da na više poziva na `poll`, samo [`Waker`] iz [`Context`] proslijeđen na najnoviji poziv treba biti zakazan za primanje buđenja.
    ///
    /// # Karakteristike izvođenja
    ///
    /// Futures sami su *inertni*;oni moraju biti *aktivno*`anketirani 'kako bi napredovali, što znači da bi svaki put kada se trenutni zadatak probudi, on trebao aktivno ponovno` anketirati' do futures za koji još uvijek ima interesa.
    ///
    /// Funkcija `poll` ne poziva se uzastopno u uskoj petlji-umjesto toga, trebala bi je pozivati samo kada future pokaže da je spremna za napredak (pozivanjem `wake()`).
    /// Ako ste upoznati s syscallovima `poll(2)` ili `select(2)` na Unix, vrijedi napomenuti da futures obično *ne* trpi iste probleme kao i "all wakeups must poll all events";više su poput `epoll(4)`.
    ///
    /// Implementacija `poll` trebala bi se nastojati vratiti brzo i ne bi trebala blokirati.Povratak brzo sprječava nepotrebno začepljenje niti ili petlje događaja.
    /// Ako se unaprijed zna da poziv na `poll` može potrajati neko vrijeme, rad treba isprazniti u spremište niti (ili nešto slično) kako bi se osiguralo da se `poll` može brzo vratiti.
    ///
    /// # Panics
    ///
    /// Jednom kada se future dovrši (vratio `Ready` iz `poll`), ponovno pozivanje njegove metode `poll` može panic, zauvijek blokirati ili uzrokovati druge vrste problema;`Future` Portrait ne postavlja zahtjeve za učinke takvog poziva.
    /// Međutim, kako metoda `poll` nije označena kao `unsafe`, primjenjuju se uobičajena pravila Rust: pozivi nikada ne smiju uzrokovati nedefinirano ponašanje (oštećenje memorije, pogrešna upotreba funkcija `unsafe` ili slično), bez obzira na stanje future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}