//! Ručno upravljajte memorijom kroz sirove pokazivače.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Mnoge funkcije u ovom modulu uzimaju sirove pokazivače kao argumente i čitaju iz njih ili pišu na njih.Da bi ovo bilo sigurno, ovi pokazivači moraju biti *valjani*.
//! Je li pokazivač valjan, ovisi o operaciji za koju se koristi (čitanje ili pisanje) i opsegu memorije kojoj se pristupa (tj. Koliko je bajtova read/written).
//! Većina funkcija koristi `*mut T` i `* const T` za pristup samo jednoj vrijednosti, u kojem slučaju dokumentacija izostavlja veličinu i implicitno pretpostavlja da je to `size_of::<T>()` bajtova.
//!
//! Precizna pravila valjanosti još nisu utvrđena.Jamstva koja su u ovom trenutku vrlo minimalna:
//!
//! * Pokazivač [null] ne vrijedi *nikad*, čak ni za pristupe [size zero][zst].
//! * Da bi pokazivač bio valjan, potrebno je, ali ne uvijek i dovoljno, da pokazivač bude *bez reference*: opseg memorije zadane veličine počevši od pokazivača mora biti u granicama jednog dodijeljenog objekta.
//!
//! Imajte na umu da se u Rust svaka varijabla (stack-allocated) smatra zasebnim dodijeljenim objektom.
//! * Čak i za operacije [size zero][zst], pokazivač ne smije usmjeravati na oslobođenu memoriju, tj. Oslobađanje čini pokazivače nevaljanima čak i za operacije nulte veličine.
//! Međutim, lijevanje bilo kojeg broja koji nije nula *literal* u pokazivač vrijedi za pristupe nulte veličine, čak i ako slučajno postoji neka memorija na toj adresi koja se oslobodi.
//! To odgovara pisanju vlastitog alokatora: dodjeljivanje objekata nulte veličine nije jako teško.
//! Kanonski način dobivanja pokazivača koji vrijedi za pristupe nulte veličine je [`NonNull::dangling`].
//! * Svi pristupi koje izvode funkcije u ovom modulu su *neatomski* u smislu [atomic operations] koji se koriste za sinkronizaciju između niti.
//! To znači da je nedefinirano ponašanje izvoditi dva istovremena pristupa istom mjestu iz različitih niti, osim ako oba pristupa čitaju samo iz memorije.
//! Primijetite da ovo izričito uključuje [`read_volatile`] i [`write_volatile`]: Hlapljivi pristupi ne mogu se koristiti za sinkronizaciju među nitima.
//! * Rezultat lijevanja reference na pokazivač vrijedi sve dok je temeljni objekt aktivan i nijedna referenca (samo sirovi pokazivači) ne koristi se za pristup istoj memoriji.
//!
//! Ti su aksiomi, uz pažljivu upotrebu [`offset`] za aritmetiku pokazivača, dovoljni da ispravno implementiraju mnoge korisne stvari u nesigurni kod.
//! Jača jamstva bit će pružena na kraju, kako se utvrđuju pravila [aliasing].
//! Za više informacija pogledajte [book], kao i odjeljak u uputi posvećenoj [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Valjani sirovi pokazivači kako su gore definirani nisu nužno pravilno poravnati (gdje je poravnanje "proper" definirano vrstom pokazivača, tj. `*const T` mora biti poravnato s `mem::align_of::<T>()`).
//! Međutim, većina funkcija zahtijeva da njihovi argumenti budu ispravno usklađeni i izričito će navesti taj zahtjev u svojoj dokumentaciji.
//! Značajne iznimke od toga su [`read_unaligned`] i [`write_unaligned`].
//!
//! Kada funkcija zahtijeva pravilno poravnanje, to čini čak i ako pristup ima veličinu 0, tj. Čak i ako memorija zapravo nije dodirnuta.Razmislite o upotrebi [`NonNull::dangling`] u takvim slučajevima.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Izvršava destruktor (ako postoji) usmjerene vrijednosti.
///
/// To je semantički ekvivalent pozivanju [`ptr::read`] i odbacivanju rezultata, ali ima sljedeće prednosti:
///
/// * *Potrebno je* koristiti `drop_in_place` za ispuštanje neodređenih tipova kao što su Portrait objekti, jer ih se ne može očitati u stog i normalno ispustiti.
///
/// * Optimizatoru je ugodnije to učiniti preko [`ptr::read`] kada ispušta ručno dodijeljenu memoriju (npr. U implementacijama `Box`/`Rc`/`Vec`), jer kompajler ne mora dokazati da zvuk izmiče kopiji.
///
///
/// * Može se koristiti za ispuštanje podataka [pinned] kada `T` nije `repr(packed)` (prikvačeni podaci ne smiju se premještati prije ispuštanja).
///
/// Neusklađene vrijednosti ne mogu se ispustiti na mjesto, već ih prvo treba kopirati na poravnato mjesto pomoću [`ptr::read_unaligned`].Za spakirane strukture, ovaj premještaj automatski vrši kompajlator.
/// To znači da se polja spakiranih struktura ne ostavljaju na mjestu.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * `to_drop` mora biti [valid] za čitanje i pisanje.
///
/// * `to_drop` mora biti pravilno poravnan.
///
/// * Vrijednost na koju upućuje `to_drop` mora biti valjana za ispuštanje, što može značiti da mora podržati dodatne invarijante, što ovisi o tipu.
///
/// Uz to, ako `T` nije [`Copy`], upotreba usmjerene vrijednosti nakon poziva `drop_in_place` može prouzročiti nedefinirano ponašanje.Imajte na umu da se `*to_drop = foo` računa kao upotreba jer će uzrokovati ponovno ispuštanje vrijednosti.
/// [`write()`] može se koristiti za prepisivanje podataka bez uzrokovanja njihovog ispuštanja.
///
/// Imajte na umu da čak i ako `T` ima veličinu `0`, pokazivač mora biti NULL i pravilno poravnan.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ručno uklonite posljednju stavku iz vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Nabavite sirovi pokazivač na posljednji element u `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Skratite `v` kako biste spriječili ispuštanje posljednje stavke.
///     // To radimo prvo, kako bismo spriječili probleme ako je `drop_in_place` ispod panics.
///     v.set_len(1);
///     // Bez poziva `drop_in_place`, zadnja stavka nikada ne bi bila ispuštena, a memorija kojom upravlja procurila bi.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Obavezno ispustite zadnju stavku.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Primijetite da prevoditelj automatski izvodi ovu kopiju kada ispušta upakirane strukture, tj. Obično se ne morate brinuti o takvim problemima ako `drop_in_place` ne pozovete ručno.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kod ovdje nije važan, prevodilac ga zamjenjuje pravim ljepilom.
    //

    // SIGURNOST: vidi komentar gore
    unsafe { drop_in_place(to_drop) }
}

/// Stvara null sirovi pokazivač.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Stvara null promjenjivi sirovi pokazivač.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Ručni impl potreban da bi se izbjegao vezani `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Ručni impl potreban da bi se izbjegao vezani `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Formira sirovu krišku od pokazivača i dužine.
///
/// Argument `len` je broj **elemenata**, a ne broj bajtova.
///
/// Ova je funkcija sigurna, ali zapravo korištenje povratne vrijednosti nije sigurno.
/// Pogledajte dokumentaciju [`slice::from_raw_parts`] za sigurnosne zahtjeve za rezanje.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // izradite pokazivač na krišku kad započinjete s pokazivačem na prvi element
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SIGURNOST: Pristup vrijednosti iz unije `Repr` siguran je jer je * const [T]
        //
        // i FatPtr imaju iste rasporede memorije.Samo std može dati ovo jamstvo.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Izvodi istu funkciju kao [`slice_from_raw_parts`], osim što se vraća sirova promjenjiva kriška, za razliku od sirove nepromjenjive kriške.
///
///
/// Pogledajte dokumentaciju [`slice_from_raw_parts`] za više detalja.
///
/// Ova je funkcija sigurna, ali zapravo korištenje povratne vrijednosti nije sigurno.
/// Pogledajte dokumentaciju [`slice::from_raw_parts_mut`] za sigurnosne zahtjeve za rezanje.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // dodijeliti vrijednost indeksu u presjeku
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SIGURNOST: Pristup vrijednosti iz `Repr` unije je siguran jer je * mut [T]
        // i FatPtr imaju iste rasporede memorije
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Mijenja vrijednosti na dva izmjenjiva mjesta istog tipa, bez deinicijalizacije.
///
/// Ali za sljedeće dvije iznimke, ova je funkcija semantički ekvivalentna [`mem::swap`]:
///
///
/// * Djeluje na sirovim pokazivačima umjesto na referencama.
/// Kad su reference dostupne, treba dati prednost [`mem::swap`].
///
/// * Dvije usmjerene vrijednosti mogu se preklapati.
/// Ako se vrijednosti preklapaju, tada će se koristiti preklapajuće područje memorije iz `x`.
/// To je prikazano u drugom primjeru u nastavku.
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * I `x` i `y` moraju biti [valid] za čitanje i pisanje.
///
/// * I `x` i `y` moraju biti pravilno poravnati.
///
/// Imajte na umu da čak i ako `T` ima veličinu `0`, pokazivači moraju biti NULL i pravilno poravnati.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Zamjena dviju regija koje se ne preklapaju:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ovo je `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ovo je `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Zamjena dviju preklapajućih regija:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ovo je `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ovo je `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indeksi `1..3` kriška preklapaju se između `x` i `y`.
///     // Razumni bi rezultati bili za njih `[2, 3]`, tako da su indeksi `0..3` `[1, 2, 3]` (podudaranje s `y` prije `swap`);ili da budu `[0, 1]` tako da indeksi `1..4` budu `[0, 1, 2]` (podudaraju se s `x` prije `swap`).
/////
///     // Ova je primjena definirana kako bi se potonji izbor.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Dajte si malo ogrebotina za rad.
    // Ne moramo se brinuti zbog kapi: `MaybeUninit` ne čini ništa kad padne.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Izvršite zamjenu SIGURNOST: pozivatelj mora jamčiti da su `x` i `y` valjani za upise i pravilno poravnati.
    // `tmp` ne može se preklapati ni `x` ni `y` jer je `tmp` upravo dodijeljen na stogu kao zasebni dodijeljeni objekt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` i `y` se mogu preklapati
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Mijenja bajtove `count * size_of::<T>()` između dvije regije memorije počevši od `x` i `y`.
/// Dvije se regije ne smiju * preklapati.
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * I `x` i `y` moraju biti [valid] za čitanje i upisivanje broja `count *
///   veličina: :<T>() `bajtova.
///
/// * I `x` i `y` moraju biti pravilno poravnati.
///
/// * Područje memorije koja počinje s `x` s veličinom `count *
///   veličina: :<T>() `bajtovi se ne smiju * preklapati s područjem memorije koje počinje s `y` iste veličine.
///
/// Imajte na umu da čak i ako efektivno kopirana veličina (`count * size_of: :<T>()`) je `0`, pokazivači moraju biti NULL i pravilno poravnati.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SIGURNOST: pozivatelj mora jamčiti da jesu `x` i `y`
    // vrijedi za upise i pravilno poravnan.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Za tipove manje od donje optimizacije blokova, samo izravno zamijenite kako biste izbjegli pesimizovanje kodegena.
    //
    if mem::size_of::<T>() < 32 {
        // SIGURNOST: pozivatelj mora jamčiti da su `x` i `y` valjani
        // za upisivanje, pravilno poravnano i bez preklapanja.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Pristup ovdje je korištenje simda za učinkovitu zamjenu x&y.
    // Testiranje otkriva da je zamjena 32 ili 64 bajta istodobno najučinkovitija za procesore Intel Haswell E.
    // LLVM je sposobniji optimizirati ako strukturi damo #[repr(simd)], čak iako ovu strukturu zapravo ne koristimo izravno.
    //
    //
    // FIXME repr(simd) neispravan na emscriptu i redox-u
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Prelistajte x&y, kopirajte ih po `Block` Optimizator bi trebao u potpunosti razviti petlju za većinu vrsta NB.
    // Ne možemo koristiti for petlju jer `range` impl rekurzivno poziva `mem::swap`
    //
    let mut i = 0;
    while i + block_size <= len {
        // Stvorite neinicijaliziranu memoriju kao prostor za ogrebotine. Izjavom `t` ovdje se izbjegava poravnavanje stoga kad se ova petlja ne koristi
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SIGURNOST: Kao `i < len` i pozivatelj mora jamčiti da su `x` i `y` valjani
        // za bajtove `len`, `x + i` i `y + i` moraju biti važeće adrese, što ispunjava sigurnosni ugovor za `add`.
        //
        // Također, pozivatelj mora jamčiti da `x` i `y` vrijede za upisivanje, pravilno poravnavanje i nepreklapanje, što ispunjava sigurnosni ugovor za `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Zamijenite blok bajtova x&y, koristeći t kao privremeni međuspremnik. To bi trebalo biti optimizirano u učinkovite SIMD operacije tamo gdje je to dostupno
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Zamijenite sve preostale bajtove
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SIGURNOST: vidi prethodni sigurnosni komentar.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Premješta `src` u šiljasti `dst`, vraćajući prethodnu vrijednost `dst`.
///
/// Nijedna vrijednost nije ispuštena.
///
/// Ova je funkcija semantički ekvivalentna [`mem::replace`], osim što radi na sirovim pokazivačima umjesto na referencama.
/// Kad su reference dostupne, treba dati prednost [`mem::replace`].
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * `dst` mora biti [valid] za čitanje i pisanje.
///
/// * `dst` mora biti pravilno poravnan.
///
/// * `dst` mora ukazivati na ispravno inicijaliziranu vrijednost tipa `T`.
///
/// Imajte na umu da čak i ako `T` ima veličinu `0`, pokazivač mora biti NULL i pravilno poravnan.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` bi imao isti učinak bez da je potreban nesigurni blok.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SIGURNOST: pozivatelj mora jamčiti da je `dst` valjan
    // prebaci na promjenjivu referencu (vrijedi za upisivanje, poravnanje, inicijalizaciju) i ne može se preklapati s `src` jer `dst` mora ukazivati na zasebni dodijeljeni objekt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ne mogu se preklapati
    }
    src
}

/// Očitava vrijednost iz `src` bez pomicanja.To ostavlja memoriju u `src` nepromijenjenom.
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * `src` mora biti [valid] za čitanje.
///
/// * `src` mora biti pravilno poravnan.Ako to nije slučaj, upotrijebite [`read_unaligned`].
///
/// * `src` mora ukazivati na ispravno inicijaliziranu vrijednost tipa `T`.
///
/// Imajte na umu da čak i ako `T` ima veličinu `0`, pokazivač mora biti NULL i pravilno poravnan.
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ručno implementirajte [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Stvorite bitnu kopiju vrijednosti na `a` u `tmp`.
///         let tmp = ptr::read(a);
///
///         // Izlazak u ovom trenutku (ili eksplicitnim vraćanjem ili pozivanjem funkcije koja panics) uzrokuje ispuštanje vrijednosti u `tmp` dok se na istu vrijednost još uvijek poziva `a`.
///         // To bi moglo pokrenuti nedefinirano ponašanje ako `T` nije `Copy`.
/////
/////
///
///         // Stvorite bitnu kopiju vrijednosti na `b` u `a`.
///         // To je sigurno jer zamjenjive reference ne mogu imati zamjensko ime.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kao i gore, izlazak ovdje mogao bi pokrenuti nedefinirano ponašanje jer se na istu vrijednost pozivaju `a` i `b`.
/////
///
///         // Premjestite `tmp` u `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` je premješten (`write` preuzima vlasništvo nad svojim drugim argumentom), tako da se ovdje ništa implicitno ne ispušta.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Vlasništvo nad vraćenom vrijednošću
///
/// `read` stvara bitnu kopiju `T`, bez obzira je li `T` [`Copy`].
/// Ako `T` nije [`Copy`], upotreba i vraćene vrijednosti i vrijednosti na `*src` može narušiti sigurnost memorije.
/// Imajte na umu da se dodjeljivanje `*src` računa kao upotreba jer će pokušati ispustiti vrijednost na `* src`.
///
/// [`write()`] može se koristiti za prepisivanje podataka bez uzrokovanja njihovog ispuštanja.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` sada pokazuje na istu temeljnu memoriju kao i `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Dodjela `s2` uzrokuje ispuštanje izvorne vrijednosti.
///     // Nakon ove točke, `s` se više ne smije koristiti, jer je oslobođena temeljna memorija.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Dodjela `s` dovela bi do ponovnog ispuštanja stare vrijednosti, što bi rezultiralo nedefiniranim ponašanjem.
/////
///     // s= String::from("bar");//POGREŠKA
///
///     // `ptr::write` može se koristiti za prepisivanje vrijednosti bez ispuštanja.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIGURNOST: pozivatelj mora jamčiti da `src` vrijedi za čitanje.
    // `src` ne može se preklapati s `tmp` jer je `tmp` upravo dodijeljen na stogu kao zasebni dodijeljeni objekt.
    //
    //
    // Također, budući da smo upravo napisali valjanu vrijednost u `tmp`, zajamčeno je da će biti pravilno inicijalizirana.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Očitava vrijednost iz `src` bez pomicanja.To ostavlja memoriju u `src` nepromijenjenom.
///
/// Za razliku od [`read`], `read_unaligned` radi s neusklađenim pokazivačima.
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * `src` mora biti [valid] za čitanje.
///
/// * `src` mora ukazivati na ispravno inicijaliziranu vrijednost tipa `T`.
///
/// Poput [`read`], `read_unaligned` stvara bitnu kopiju `T`, bez obzira je li `T` [`Copy`].
/// Ako `T` nije [`Copy`], upotreba i vraćene vrijednosti i vrijednosti na `*src` može [violate memory safety][read-ownership].
///
/// Imajte na umu da čak i ako `T` ima veličinu `0`, pokazivač mora biti NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Na `packed` strukturama
///
/// Trenutno je nemoguće stvoriti sirove pokazivače na neusklađena polja spakirane strukture.
///
/// Pokušaj stvaranja sirovog pokazivača na `unaligned` strukturno polje s izrazom kao što je `&packed.unaligned as *const FieldType` stvara prijelaznu neusklađenu referencu prije pretvorbe u neobrađeni pokazivač.
///
/// To što je ova referenca privremena i odmah emitirana, nije bitno, jer prevodilac uvijek očekuje da reference budu pravilno poravnate.
/// Kao rezultat, upotreba `&packed.unaligned as *const FieldType` uzrokuje trenutno* nedefinirano ponašanje * u vašem programu.
///
/// Primjer onoga što ne treba raditi i kako se to odnosi na `read_unaligned` je:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Ovdje pokušavamo uzeti adresu 32-bitnog cijelog broja koji nije poravnat.
///     let unaligned =
///         // Ovdje se stvara privremena neusklađena referenca koja rezultira nedefiniranim ponašanjem bez obzira koristi li se referenca ili ne.
/////
///         &packed.unaligned
///         // Emitiranje na sirovi pokazivač ne pomaže;pogreška se već dogodila.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Međutim, izravni pristup nesravnjenim poljima, npr. S `packed.unaligned`, siguran je.
///
///
///
///
///
///
// FIXME: Ažurirajte dokumente na temelju ishoda RFC #2582 i prijatelja.
/// # Examples
///
/// Očitavanje vrijednosti usize iz bajtnog međuspremnika:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIGURNOST: pozivatelj mora jamčiti da `src` vrijedi za čitanje.
    // `src` ne može se preklapati s `tmp` jer je `tmp` upravo dodijeljen na stogu kao zasebni dodijeljeni objekt.
    //
    //
    // Također, budući da smo upravo napisali valjanu vrijednost u `tmp`, zajamčeno je da će biti pravilno inicijalizirana.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Prepisuje memorijsko mjesto s danom vrijednošću bez čitanja ili ispuštanja stare vrijednosti.
///
/// `write` ne ispušta sadržaj `dst`.
/// Ovo je sigurno, ali može procuriti dodjelu ili resurse, pa treba paziti da ne prepišete objekt koji treba ispustiti.
///
///
/// Uz to, ne ispušta `src`.Semantički se `src` premješta na mjesto na koje ukazuje `dst`.
///
/// To je prikladno za inicijalizaciju neinicijalizirane memorije ili prepisivanje memorije iz koje je prethodno bilo [`read`].
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * `dst` mora biti [valid] za upisivanje.
///
/// * `dst` mora biti pravilno poravnan.Ako to nije slučaj, upotrijebite [`write_unaligned`].
///
/// Imajte na umu da čak i ako `T` ima veličinu `0`, pokazivač mora biti NULL i pravilno poravnan.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ručno implementirajte [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Stvorite bitnu kopiju vrijednosti na `a` u `tmp`.
///         let tmp = ptr::read(a);
///
///         // Izlazak u ovom trenutku (ili eksplicitnim vraćanjem ili pozivanjem funkcije koja panics) uzrokuje ispuštanje vrijednosti u `tmp` dok se na istu vrijednost još uvijek poziva `a`.
///         // To bi moglo pokrenuti nedefinirano ponašanje ako `T` nije `Copy`.
/////
/////
///
///         // Stvorite bitnu kopiju vrijednosti na `b` u `a`.
///         // To je sigurno jer zamjenjive reference ne mogu imati zamjensko ime.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kao i gore, izlazak ovdje mogao bi pokrenuti nedefinirano ponašanje jer se na istu vrijednost pozivaju `a` i `b`.
/////
///
///         // Premjestite `tmp` u `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` je premješten (`write` preuzima vlasništvo nad svojim drugim argumentom), tako da se ovdje ništa implicitno ne ispušta.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Intrinsics zovemo izravno kako bismo izbjegli pozive funkcija u generiranom kodu jer je `intrinsics::copy_nonoverlapping` funkcija omotača.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SIGURNOST: pozivatelj mora jamčiti da `dst` vrijedi za upise.
    // `dst` ne može se preklapati s `src` jer pozivatelj ima promjenjiv pristup `dst` dok je `src` u vlasništvu ove funkcije.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Prepisuje memorijsko mjesto s danom vrijednošću bez čitanja ili ispuštanja stare vrijednosti.
///
/// Za razliku od [`write()`], pokazivač možda nije poravnat.
///
/// `write_unaligned` ne ispušta sadržaj `dst`.Ovo je sigurno, ali može procuriti dodjelu ili resurse, pa treba paziti da ne prepišete objekt koji treba ispustiti.
///
/// Uz to, ne ispušta `src`.Semantički se `src` premješta na mjesto na koje ukazuje `dst`.
///
/// Ovo je prikladno za inicijalizaciju neinicijalizirane memorije ili prepisivanje memorije koja je prethodno pročitana s [`read_unaligned`].
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * `dst` mora biti [valid] za upisivanje.
///
/// Imajte na umu da čak i ako `T` ima veličinu `0`, pokazivač mora biti NULL.
///
/// [valid]: self#safety
///
/// ## Na `packed` strukturama
///
/// Trenutno je nemoguće stvoriti sirove pokazivače na neusklađena polja spakirane strukture.
///
/// Pokušaj stvaranja sirovog pokazivača na `unaligned` strukturno polje s izrazom kao što je `&packed.unaligned as *const FieldType` stvara prijelaznu neusklađenu referencu prije pretvorbe u neobrađeni pokazivač.
///
/// To što je ova referenca privremena i odmah emitirana, nije bitno, jer prevodilac uvijek očekuje da reference budu pravilno poravnate.
/// Kao rezultat, upotreba `&packed.unaligned as *const FieldType` uzrokuje trenutno* nedefinirano ponašanje * u vašem programu.
///
/// Primjer onoga što ne treba raditi i kako se to odnosi na `write_unaligned` je:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Ovdje pokušavamo uzeti adresu 32-bitnog cijelog broja koji nije poravnat.
///     let unaligned =
///         // Ovdje se stvara privremena neusklađena referenca koja rezultira nedefiniranim ponašanjem bez obzira koristi li se referenca ili ne.
/////
///         &mut packed.unaligned
///         // Emitiranje na sirovi pokazivač ne pomaže;pogreška se već dogodila.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Međutim, izravni pristup nesravnjenim poljima, npr. S `packed.unaligned`, siguran je.
///
///
///
///
///
///
///
///
///
// FIXME: Ažurirajte dokumente na temelju ishoda RFC #2582 i prijatelja.
/// # Examples
///
/// Napišite bazu podataka u međuspremnik:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SIGURNOST: pozivatelj mora jamčiti da `dst` vrijedi za upise.
    // `dst` ne može se preklapati s `src` jer pozivatelj ima promjenjiv pristup `dst` dok je `src` u vlasništvu ove funkcije.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Intrinzično zovemo izravno kako bismo izbjegli pozive funkcija u generiranom kodu.
        intrinsics::forget(src);
    }
}

/// Izvodi hlapljivo očitavanje vrijednosti iz `src` bez pomicanja.To ostavlja memoriju u `src` nepromijenjenom.
///
/// Hlapive operacije namijenjene su djelovanju na memoriju I/O, a zajamčeno je da ih kompajler neće ukloniti ili preurediti u druge hlapljive operacije.
///
/// # Notes
///
/// Rust trenutno nema strogo i formalno definiran model memorije, pa se precizna semantika onoga što ovdje znači "volatile" može vremenom mijenjati.
/// To je rečeno, semantika će gotovo uvijek na kraju biti prilično slična [C11's definition of volatile][c11].
///
/// Prevoditelj ne bi trebao mijenjati relativni redoslijed ili broj volatilnih operacija memorije.
/// Međutim, volatilne operacije memorije na tipovima nulte veličine (npr. Ako se tip nulte veličine prosljeđuje `read_volatile`) su petlje i mogu se zanemariti.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * `src` mora biti [valid] za čitanje.
///
/// * `src` mora biti pravilno poravnan.
///
/// * `src` mora ukazivati na ispravno inicijaliziranu vrijednost tipa `T`.
///
/// Poput [`read`], `read_volatile` stvara bitnu kopiju `T`, bez obzira je li `T` [`Copy`].
/// Ako `T` nije [`Copy`], upotreba i vraćene vrijednosti i vrijednosti na `*src` može [violate memory safety][read-ownership].
/// Međutim, pohranjivanje tipova koji nisu [`Copy`] u hlapljivu memoriju gotovo je sigurno netočno.
///
/// Imajte na umu da čak i ako `T` ima veličinu `0`, pokazivač mora biti NULL i pravilno poravnan.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Baš kao u C-u, je li volatilna operacija uopće ne utječe na pitanja koja uključuju istodobni pristup iz više niti.Hlapljivi pristupi ponašaju se u tom pogledu točno poput neatomskih pristupa.
///
/// Konkretno, utrka između `read_volatile` i bilo koje operacije upisivanja na isto mjesto je nedefinirano ponašanje.
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Bez panike kako bi utjecaj kodegena bio manji.
        abort();
    }
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Izvodi hlapljivo upisivanje memorijskog mjesta s danom vrijednošću bez čitanja ili ispuštanja stare vrijednosti.
///
/// Hlapive operacije namijenjene su djelovanju na memoriju I/O, a zajamčeno je da ih kompajler neće ukloniti ili preurediti u druge hlapljive operacije.
///
/// `write_volatile` ne ispušta sadržaj `dst`.Ovo je sigurno, ali može procuriti dodjelu ili resurse, pa treba paziti da ne prepišete objekt koji treba ispustiti.
///
/// Uz to, ne ispušta `src`.Semantički se `src` premješta na mjesto na koje ukazuje `dst`.
///
/// # Notes
///
/// Rust trenutno nema strogo i formalno definiran model memorije, pa se precizna semantika onoga što ovdje znači "volatile" može vremenom mijenjati.
/// To je rečeno, semantika će gotovo uvijek na kraju biti prilično slična [C11's definition of volatile][c11].
///
/// Prevoditelj ne bi trebao mijenjati relativni redoslijed ili broj volatilnih operacija memorije.
/// Međutim, volatilne operacije memorije na tipovima nulte veličine (npr. Ako se tip nulte veličine prosljeđuje `write_volatile`) su petlje i mogu se zanemariti.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uvjeta:
///
/// * `dst` mora biti [valid] za upisivanje.
///
/// * `dst` mora biti pravilno poravnan.
///
/// Imajte na umu da čak i ako `T` ima veličinu `0`, pokazivač mora biti NULL i pravilno poravnan.
///
/// [valid]: self#safety
///
/// Baš kao u C-u, je li volatilna operacija uopće ne utječe na pitanja koja uključuju istodobni pristup iz više niti.Hlapljivi pristupi ponašaju se u tom pogledu točno poput neatomskih pristupa.
///
/// Konkretno, utrka između `write_volatile` i bilo koje druge operacije (čitanje ili pisanje) na istom mjestu nedefinirano je ponašanje.
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Bez panike kako bi utjecaj kodegena bio manji.
        abort();
    }
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Poravnajte pokazivač `p`.
///
/// Izračunajte pomak (u smislu elemenata koraka `stride`) koji se mora primijeniti na pokazivač `p` kako bi se pokazivač `p` poravnao s `a`.
///
/// Note: Ova je implementacija pažljivo prilagođena da nije panic.UB je za ovo do panic.
/// Jedina stvarna promjena koja se ovdje može napraviti je promjena `INV_TABLE_MOD_16` i pridruženih konstanti.
///
/// Ako ikad odlučimo omogućiti da intrinzično s `a` nazovemo snagom dvojke, vjerojatno će biti pametnije jednostavno prijeći na naivnu implementaciju, umjesto da to pokušamo prilagoditi kako bi se prilagodilo toj promjeni.
///
///
/// Sva pitanja idite na@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Izravna upotreba ovih osobina značajno poboljšava kodegen na opt-razini <=
    // 1, gdje verzije metoda ovih operacija nisu ucrtane.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Izračunajte multiplikativni modularni inverzni `x` modulo `m`.
    ///
    /// Ova implementacija je prilagođena `align_offset` i ima sljedeće preduvjete:
    ///
    /// * `m` je snaga dva;
    /// * `x < m`; (ako je `x ≥ m`, umjesto toga unesite `x % m`)
    ///
    /// Provedba ove funkcije neće panic.Ikad.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikativni modularni inverzni stol modul 2⁴=16.
        ///
        /// Imajte na umu da ova tablica ne sadrži vrijednosti gdje inverzna ne postoji (tj. Za `0⁻¹ mod 16`, `2⁻¹ mod 16` itd.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modul za koji je `INV_TABLE_MOD_16` namijenjen.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SIGURNOST: `m` mora biti snaga dva, dakle nije nula.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Ponavljamo "up" koristeći sljedeću formulu:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // do 2²ⁿ ≥ m.Tada možemo smanjiti na željeni `m` uzimajući rezultat `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Imajte na umu da ovdje namjerno koristimo operacije zamatanja-izvorna formula koristi npr. Oduzimanje `mod n`.
                // Sasvim je u redu umjesto njih napraviti `mod usize::MAX`, jer ionako uzimamo rezultat `mod n`.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SIGURNOST: `a` je snaga dva, dakle nije nula.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Slučaj se može jednostavnije izračunati putem `-p (mod a)`, ali to onemogućava LLVM-u mogućnost odabira uputa poput `lea`.Umjesto toga izračunavamo
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // koja distribuira operacije oko nosivog tereta, ali pesimizira `and` dovoljno da LLVM može iskoristiti razne optimizacije za koje zna.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Već poravnato.Yay!
        return 0;
    } else if stride == 0 {
        // Ako pokazivač nije poravnat, a element je nulte veličine, tada nijedna količina elemenata neće poravnati pokazivač.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SIGURNOST: a je snaga dva, dakle nije nula.stride==0 slučaj je obrađen gore.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SIGURNOST: gcdpow ima gornju granicu koja je najviše broj bitova u veličini.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SIGURNOST: gcd je uvijek veći ili jednak 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ovaj branch rješava za sljedeću linearnu jednačinu sukladnosti:
        //
        // ` p + so = 0 mod a `
        //
        // `p` ovdje je vrijednost pokazivača, `s`, iskorak `T`, pomak `o` u `T`s, i `a`, traženo poravnanje.
        //
        // S `g = gcd(a, s)` i gornjim uvjetom koji tvrdi da je `p` također djeljiv sa `g`, možemo označiti `a' = a/g`, `s' = s/g`, `p' = p/g`, tada to postaje ekvivalent:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Prvi je pojam "the relative alignment of `p` to `a`" (podijeljen s `g`), drugi izraz je "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (opet podijeljen s `g`).
        //
        // Podjela s `g` potrebna je da bi se inverza dobro oblikovala ako `a` i `s` nisu ko-prosti.
        //
        // Nadalje, rezultat dobiven ovim rješenjem nije "minimal", pa je potrebno uzeti rezultat `o mod lcm(s, a)`.`lcm(s, a)` možemo zamijeniti samo `a'`.
        //
        //
        //
        //
        //

        // SIGURNOST: `gcdpow` ima gornju granicu koja nije veća od broja pratećih 0-bitova u `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SIGURNOST: `a2` nije nula.Pomicanjem `a` za `gcdpow` ne može se pomaknuti niti jedan od postavljenih bitova
        // u `a` (od kojih ih ima točno jedan).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SIGURNOST: `gcdpow` ima gornju granicu koja nije veća od broja pratećih 0-bitova u `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SIGURNOST: `gcdpow` ima gornju granicu koja nije veća od broja pratećih 0-bitova
        // `a`.
        // Nadalje, oduzimanje se ne može preliti, jer će `a2 = a >> gcdpow` uvijek biti strogo veći od `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SIGURNOST: `a2` je snaga dva, kao što je gore dokazano.`s2` je strogo manji od `a2`
        // jer je `(s % a) >> gcdpow` strogo manji od `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Uopće se ne može poravnati.
    usize::MAX
}

/// Uspoređuje sirove upute za jednakost.
///
/// To je isto kao i korištenje operatora `==`, ali manje općenito:
/// argumenti moraju biti `*const T` sirovi pokazivači, a ne bilo što što implementira `PartialEq`.
///
/// To se može upotrijebiti za usporedbu referenci `&T` (koje implicitno prisiljavaju `*const T`) prema njihovoj adresi, umjesto uspoređivanja vrijednosti na koje upućuju (što `PartialEq for &T` implementacija čini).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Kriške se također uspoređuju po dužini (pokazivači masti):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits također se uspoređuju prema njihovoj implementaciji:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Pokazivači imaju jednake adrese.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objekti imaju jednake adrese, ali `Trait` ima različite implementacije.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Pretvaranje reference u `*const u8` uspoređuje se prema adresi.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash sirovi pokazivač.
///
/// To se može koristiti za raspršivanje reference `&T` (koja implicitno prisiljava `*const T`) prema njezinoj adresi, a ne prema vrijednosti na koju ukazuje (na što `Hash for &T` implementacija i radi).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Podrazumijeva pokazivače na funkcije
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Za AVR je potreban srednji odljev u obliku veličine
                // tako da se adresni prostor pokazivača funkcije izvora sačuva u završnom pokazivaču funkcije.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Za AVR je potreban srednji odljev u obliku veličine
                // tako da se adresni prostor pokazivača funkcije izvora sačuva u završnom pokazivaču funkcije.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Nema varijadičnih funkcija s 0 parametara
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Stvorite `const` sirovi pokazivač na mjesto, bez stvaranja posredne reference.
///
/// Stvaranje reference s `&`/`&mut` dopušteno je samo ako je pokazivač pravilno poravnat i usmjerava na inicijalizirane podatke.
/// U slučajevima kada ti zahtjevi ne vrijede, umjesto njih treba koristiti sirove pokazivače.
/// Međutim, `&expr as *const _` stvara referencu prije nego što je pošalje na neobrađeni pokazivač, a ta referenca podliježe istim pravilima kao i sve ostale reference.
///
/// Ova makronaredba može stvoriti sirovi pokazivač *bez* prethodnog stvaranja reference.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` stvorila bi nesvrstanu referencu i tako bila nedefinirano ponašanje!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Stvorite `mut` sirovi pokazivač na mjesto, bez stvaranja posredne reference.
///
/// Stvaranje reference s `&`/`&mut` dopušteno je samo ako je pokazivač pravilno poravnat i usmjerava na inicijalizirane podatke.
/// U slučajevima kada ti zahtjevi ne vrijede, umjesto njih treba koristiti sirove pokazivače.
/// Međutim, `&mut expr as *mut _` stvara referencu prije nego što je pošalje na neobrađeni pokazivač, a ta referenca podliježe istim pravilima kao i sve ostale reference.
///
/// Ova makronaredba može stvoriti sirovi pokazivač *bez* prethodnog stvaranja reference.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` stvorila bi nesvrstanu referencu i tako bila nedefinirano ponašanje!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` prisiljava kopiranje polja umjesto stvaranja reference.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}