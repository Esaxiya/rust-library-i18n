#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Pruža tip metapodataka pokazivača bilo kojeg usmjerenog tipa.
///
/// # Metapodaci pokazivača
///
/// Tipovi sirovih pokazivača i referentni tipovi u Rust mogu se smatrati izrađenim iz dva dijela:
/// pokazivač podataka koji sadrži memorijsku adresu vrijednosti i neke metapodatke.
///
/// Za tipove statičke veličine (koji implementiraju `Sized` traits), kao i za tipove `extern`, kaže se da su pokazivači "tanki": metapodaci su nulte veličine, a njihov tip je `()`.
///
///
/// Kaže se da su pokazivači na [dynamically-sized types][dst] "široki" ili "debeli", oni imaju metapodatke koji nisu nulte veličine:
///
/// * Za strukture čije je posljednje polje DST, metapodaci su metapodaci za posljednje polje
/// * Za tip `str` metapodaci su duljina u bajtovima kao `usize`
/// * Za vrste kriški poput `[T]`, metapodaci su duljina stavki kao `usize`
/// * Za Portrait objekte poput `dyn SomeTrait`, metapodaci su [`DynMetadata<Self>`][DynMetadata] (npr. `DynMetadata<dyn SomeTrait>`)
///
/// U future, jezik Rust može dobiti nove vrste tipova koji imaju različite metapodatke pokazivača.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` Portrait
///
/// Poanta ovog Portrait je njegov pridruženi tip `Metadata`, a to je `()` ili `usize` ili `DynMetadata<_>` kako je gore opisano.
/// Automatski se implementira za svaku vrstu.
/// Može se pretpostaviti da se provodi u generičkom kontekstu, čak i bez odgovarajuće veze.
///
/// # Usage
///
/// Sirovi pokazivači mogu se rastaviti na komponente podataka i adrese metapodataka njihovom metodom [`to_raw_parts`].
///
/// Alternativno, samo metapodaci mogu se izdvojiti pomoću funkcije [`metadata`].
/// Referenca se može proslijediti na [`metadata`] i implicitno prisiliti.
///
/// Pokazivač (possibly-wide) može se sastaviti iz adrese i metapodataka s [`from_raw_parts`] ili [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Tip metapodataka u pokazivačima i reference na `Self`.
    #[lang = "metadata_type"]
    // NOTE: Zadržite Portrait bounds u `static_assert_expected_bounds_for_metadata`
    //
    // u `library/core/src/ptr/metadata.rs` sinkronizirano s onima ovdje:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Pokazatelji na tipove koji implementiraju ovaj pseudonim Portrait su "tanki".
///
/// To uključuje tipove "Veličine" i tipove `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: nemojte to stabilizirati prije nego što se pseudonimi Portrait stabilizuju u jeziku?
pub trait Thin = Pointee<Metadata = ()>;

/// Izdvojite komponentu metapodataka pokazivača.
///
/// Vrijednosti tipa `*mut T`, `&T` ili `&mut T` mogu se proslijediti izravno ovoj funkciji jer se implicitno prisiljavaju na `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SIGURNOST: Pristup vrijednosti iz unije `PtrRepr` siguran je jer je * const T
    // i PtrComponents<T>imaju iste rasporede memorije.
    // Samo std može dati ovo jamstvo.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Formira (possibly-wide) sirovi pokazivač iz adrese podataka i metapodataka.
///
/// Ova je funkcija sigurna, ali vraćeni pokazivač nije nužno siguran za dereferenciranje.
/// Za kriške pogledajte dokumentaciju [`slice::from_raw_parts`] radi sigurnosnih zahtjeva.
/// Za Portrait objekte, metapodaci moraju dolaziti iz pokazivača na isti temeljni izbrisani tip.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SIGURNOST: Pristup vrijednosti iz unije `PtrRepr` siguran je jer je * const T
    // i PtrComponents<T>imaju iste rasporede memorije.
    // Samo std može dati ovo jamstvo.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Izvodi istu funkciju kao [`from_raw_parts`], osim što se vraća sirovi `*mut` pokazivač, za razliku od sirovog `* const` pokazivača.
///
///
/// Pogledajte dokumentaciju [`from_raw_parts`] za više detalja.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SIGURNOST: Pristup vrijednosti iz unije `PtrRepr` siguran je jer je * const T
    // i PtrComponents<T>imaju iste rasporede memorije.
    // Samo std može dati ovo jamstvo.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Ručni impl potreban da bi se izbjegao vezani `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Ručni impl potreban da bi se izbjegao vezani `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metapodaci za tip objekta `Dyn = dyn SomeTrait` Portrait.
///
/// To je pokazivač na vtable (virtualna tablica poziva) koji predstavlja sve potrebne informacije za manipulaciju konkretnim tipom pohranjenim unutar Portrait objekta.
/// Vtable koji sadrži:
///
/// * veličina tipa
/// * poravnanje tipa
/// * pokazivač na tip `drop_in_place` impl (može biti ne-op za obične-stare-podatke)
/// * uputi na sve metode za izvedbu tipa Portrait
///
/// Imajte na umu da su prva tri posebna jer su potrebna za dodjelu, ispuštanje i oslobađanje bilo kojeg objekta Portrait.
///
/// Ovu strukturu moguće je imenovati parametrom tipa koji nije `dyn` Portrait objekt (na primjer `DynMetadata<u64>`), ali ne i dobiti značajnu vrijednost te strukture.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Uobičajeni prefiks svih vtables.Slijede pokazivači funkcija za metode Portrait.
///
/// Privatni detalj implementacije `DynMetadata::size_of` itd.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Vraća veličinu tipa pridruženog ovom vtableu.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Vraća poravnanje tipa pridruženog ovom vtableu.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Vraća veličinu i poravnanje zajedno kao `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SIGURNOST: prevodilac je emitirao ovaj vtable za beton tipa Rust koji
        // poznato je da ima valjan izgled.Isto obrazloženje kao u `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ručni impulsi potrebni da bi se izbjegle granice `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}