use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Vraća `true` ako je pokazivač null.
    ///
    /// Imajte na umu da neodređeni tipovi imaju mnogo mogućih null pokazivača, jer se uzima u obzir samo pokazivač neobrađenih podataka, a ne njihova duljina, vtable itd.
    /// Stoga se dva pokazivača koji su null možda još uvijek neće međusobno uspoređivati.
    ///
    /// ## Ponašanje tijekom ocjene const
    ///
    /// Kada se ova funkcija koristi tijekom procjene const, ona može vratiti `false` za pokazivače za koje se ispostavi da su nula tijekom izvođenja.
    /// Točnije, kada se pokazivač na neku memoriju pomakne izvan svojih granica na takav način da rezultirajući pokazivač bude nula, funkcija će i dalje vraćati `false`.
    ///
    /// CTFE ne može znati apsolutni položaj te memorije, pa ne možemo utvrditi je li pokazivač nula ili nije.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Usporedite putem gipsa s tankim pokazivačem, pa masni pokazivači samo razmatraju svoj "data" dio za ništavost.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Emitira pokazivač druge vrste.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Razložite (moguće široki) pokazivač na komponente adrese i metapodataka.
    ///
    /// Pokazivač se kasnije može rekonstruirati s [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Vraća `None` ako je pokazivač null ili inače vraća zajedničku referencu na vrijednost umotanu u `Some`.Ako se vrijednost može neinicijalizirati, umjesto nje mora se upotrijebiti [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Kada pozivate ovu metodu, morate osigurati da je *ili* pokazivač NULL *ili* da je istinito sve sljedeće:
    ///
    /// * Pokazivač mora biti pravilno poravnat.
    ///
    /// * To mora biti "dereferencable" u smislu definiranom u [the module documentation].
    ///
    /// * Pokazivač mora ukazivati na inicijaliziranu instancu `T`.
    ///
    /// * Morate provesti Zaslanjajuća pravila Rust, jer je vraćeni vijek trajanja `'a` proizvoljno izabran i ne odražava nužno stvarni vijek trajanja podataka.
    ///   Konkretno, tijekom trajanja ovog životnog vijeka, memorija na koju pokazuje pokazivač ne smije biti mutirana (osim unutar `UnsafeCell`).
    ///
    /// To vrijedi čak i ako je rezultat ove metode neiskorišten!
    /// (Dio o inicijalizaciji još nije u potpunosti odlučen, ali dok se to ne dogodi, jedini siguran pristup je osigurati da oni zaista budu inicijalizirani.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Ništa neprovjerena verzija
    ///
    /// Ako ste sigurni da pokazivač nikad ne može biti null i tražite neku vrstu `as_ref_unchecked` koja vraća `&T` umjesto `Option<&T>`, znajte da pokazivač možete dereferencirati izravno.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SIGURNOST: pozivatelj mora jamčiti da je `self` valjan
        // za referencu ako nije null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Vraća `None` ako je pokazivač null ili inače vraća zajedničku referencu na vrijednost umotanu u `Some`.
    /// Za razliku od [`as_ref`], ovo ne zahtijeva da vrijednost mora biti inicijalizirana.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kada pozivate ovu metodu, morate osigurati da je *ili* pokazivač NULL *ili* da je istinito sve sljedeće:
    ///
    /// * Pokazivač mora biti pravilno poravnat.
    ///
    /// * To mora biti "dereferencable" u smislu definiranom u [the module documentation].
    ///
    /// * Morate provesti Zaslanjajuća pravila Rust, jer je vraćeni vijek trajanja `'a` proizvoljno izabran i ne odražava nužno stvarni vijek trajanja podataka.
    ///
    ///   Konkretno, tijekom trajanja ovog životnog vijeka, memorija na koju pokazuje pokazivač ne smije biti mutirana (osim unutar `UnsafeCell`).
    ///
    /// To vrijedi čak i ako je rezultat ove metode neiskorišten!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SIGURNOST: pozivatelj mora jamčiti da `self` ispunjava sve
        // zahtjevi za referencom.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Izračunava pomak iz pokazivača.
    ///
    /// `count` je u jedinicama T;npr. `count` od 3 predstavlja pomak pokazivača od `3 * size_of::<T>()` bajtova.
    ///
    /// # Safety
    ///
    /// Ako se prekrši bilo koji od sljedećih uvjeta, rezultat je Nedefinirano ponašanje:
    ///
    /// * I početni i rezultirajući pokazivač moraju biti u granicama ili jedan bajt iza kraja istog dodijeljenog objekta.
    /// Imajte na umu da se u Rust svaka varijabla (stack-allocated) smatra zasebnim dodijeljenim objektom.
    ///
    /// * Izračunati pomak,**u bajtovima**, ne može prekoračiti `isize`.
    ///
    /// * Pomak u granicama ne može se osloniti na "wrapping around" adresni prostor.Odnosno, zbroj beskonačne preciznosti **u bajtovima** mora stati u veličinu.
    ///
    /// Kompajler i standardna knjižnica općenito nastoje osigurati da dodjele nikada ne dosegnu veličinu kod koje je pomak zabrinut.
    /// Na primjer, `Vec` i `Box` osiguravaju da nikada ne dodijele više od `isize::MAX` bajtova, tako da je `vec.as_ptr().add(vec.len())` uvijek siguran.
    ///
    /// Većina platformi u osnovi ne može konstruirati takvu raspodjelu.
    /// Na primjer, nijedna poznata 64-bitna platforma nikada ne može poslužiti zahtjev za 2 <sup>63</sup> bajta zbog ograničenja tablice stranica ili razdvajanja adresnog prostora.
    /// Međutim, neke 32-bitne i 16-bitne platforme mogu uspješno poslužiti zahtjev za više od `isize::MAX` bajtova sa stvarima kao što je Physical Address Extension.
    ///
    /// Kao takva, memorija stečena izravno iz alokatora ili datoteka preslikanih u memoriju * može biti prevelika za rukovanje ovom funkcijom.
    ///
    /// Razmislite o upotrebi [`wrapping_offset`] umjesto toga ako je teško zadovoljiti ta ograničenja.
    /// Jedina prednost ove metode je što omogućuje agresivniju optimizaciju kompajlera.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Izračunava pomak od pokazivača pomoću aritmetike zamotavanja.
    ///
    /// `count` je u jedinicama T;npr. `count` od 3 predstavlja pomak pokazivača od `3 * size_of::<T>()` bajtova.
    ///
    /// # Safety
    ///
    /// Sama je ova operacija uvijek sigurna, ali upotreba rezultirajućeg pokazivača nije.
    ///
    /// Rezultirajući pokazivač ostaje pričvršćen na isti dodijeljeni objekt na koji pokazuje `self`.
    /// Ne može se *koristiti* za pristup drugom dodijeljenom objektu.Imajte na umu da se u Rust svaka varijabla (stack-allocated) smatra zasebnim dodijeljenim objektom.
    ///
    /// Drugim riječima, `let z = x.wrapping_offset((y as isize) - (x as isize))`*ne* čini `z` istim kao `y`, čak i ako pretpostavimo da `T` ima veličinu `1` i da nema preljeva: `z` je i dalje pričvršćen na objekt na koji je pričvršćen `x`, a preusmjeravanje je Nedefinirano ponašanje osim ako `x` i `y` usmjeravaju u isti dodijeljeni objekt.
    ///
    /// U usporedbi s [`offset`], ova metoda u osnovi odgađa zahtjev zadržavanja unutar istog dodijeljenog objekta: [`offset`] je trenutno Nedefinirano ponašanje prilikom prelaska granica objekta;`wrapping_offset` stvara pokazivač, ali i dalje dovodi do Nedefiniranog ponašanja ako je pokazivač dereferenciran kada je izvan okvira objekta na koji je povezan.
    /// [`offset`] može se bolje optimizirati i stoga je poželjniji u kodu osjetljivom na performanse.
    ///
    /// Odgođena provjera uzima u obzir samo vrijednost pokazivača koji je dereferenciran, a ne srednje vrijednosti korištene tijekom izračuna konačnog rezultata.
    /// Na primjer, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` je uvijek isti kao `x`.Drugim riječima, dopušteno je napuštanje dodijeljenog objekta i ponovni ulazak u njega kasnije.
    ///
    /// Ako trebate prijeći granice objekta, prebacite pokazivač na cijeli broj i tamo napravite aritmetiku.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// // Iteracija pomoću sirovog pokazivača u koracima od dva elementa
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Ova petlja ispisuje "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIGURNOST: `arith_offset` intrinsic nema preduvjete za pozivanje.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Izračunava udaljenost između dva pokazivača.Vraćena vrijednost je u jedinicama T: udaljenost u bajtovima podijeljena je s `mem::size_of::<T>()`.
    ///
    /// Ova je funkcija obrnuta od [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Ako se prekrši bilo koji od sljedećih uvjeta, rezultat je Nedefinirano ponašanje:
    ///
    /// * I početni i drugi pokazivač moraju biti u granicama ili jedan bajt iza kraja istog dodijeljenog objekta.
    /// Imajte na umu da se u Rust svaka varijabla (stack-allocated) smatra zasebnim dodijeljenim objektom.
    ///
    /// * Oba pokazivača moraju biti izvedena iz * pokazivača na isti objekt.
    ///   (Primjer pogledajte u nastavku.)
    ///
    /// * Udaljenost između pokazivača, u bajtovima, mora biti točan umnožak veličine `T`.
    ///
    /// * Udaljenost između pokazivača,**u bajtovima**, ne može premašiti `isize`.
    ///
    /// * Udaljenost u granicama ne može se osloniti na "wrapping around" adresni prostor.
    ///
    /// Tipovi Rust nikada nisu veći od `isize::MAX`, a dodjele Rust nikada se ne omotavaju oko adresnog prostora, pa će dva pokazivača unutar neke vrijednosti bilo kojeg tipa Rust tipa `T` uvijek zadovoljiti zadnja dva uvjeta.
    ///
    /// Standardna knjižnica također općenito osigurava da izdvajanja nikada ne dosegnu veličinu kod koje je pomak zabrinut.
    /// Na primjer, `Vec` i `Box` osiguravaju da nikada ne dodijele više od `isize::MAX` bajtova, tako da `ptr_into_vec.offset_from(vec.as_ptr())` uvijek udovoljava zadnja dva uvjeta.
    ///
    /// Većina platformi u osnovi ne može niti konstruirati tako veliku dodjelu.
    /// Na primjer, nijedna poznata 64-bitna platforma nikada ne može poslužiti zahtjev za 2 <sup>63</sup> bajta zbog ograničenja tablice stranica ili razdvajanja adresnog prostora.
    /// Međutim, neke 32-bitne i 16-bitne platforme mogu uspješno poslužiti zahtjev za više od `isize::MAX` bajtova sa stvarima kao što je Physical Address Extension.
    /// Kao takva, memorija stečena izravno iz alokatora ili datoteka preslikanih u memoriju * može biti prevelika za rukovanje ovom funkcijom.
    /// (Imajte na umu da [`offset`] i [`add`] također imaju slična ograničenja i stoga se ne mogu koristiti ni na tako velikim dodjelama.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ova funkcija panics ako je `T` nulti tip ("ZST").
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Neispravna* upotreba:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Neka ptr2_other bude "alias" od ptr2, ali izveden iz ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Budući da su ptr2_other i ptr2 izvedeni iz pokazivača na različite objekte, računanje njihovog pomaka nedefinirano je ponašanje, iako pokazuju na istu adresu!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Nedefinirano ponašanje
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Daje zajamčeno da su dva pokazivača jednaka.
    ///
    /// Za vrijeme izvođenja ova se funkcija ponaša kao `self == other`.
    /// Međutim, u nekim kontekstima (npr. Procjena vremena kompajliranja) nije uvijek moguće utvrditi jednakost dvaju pokazivača, pa ova funkcija može lažno vratiti `false` za pokazivače za koje se kasnije zapravo pokaže da su jednaki.
    ///
    /// Ali kad vrati `true`, pokazivači će zajamčeno biti jednaki.
    ///
    /// Ova je funkcija zrcalo [`guaranteed_ne`], ali nije njegova inverzna vrijednost.Postoje usporedbe pokazivača za koje obje funkcije vraćaju `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Povratna vrijednost može se mijenjati ovisno o verziji kompajlera, a nesigurni kôd možda se neće osloniti na ispravnost rezultata ove funkcije.
    /// Predlaže se korištenje ove funkcije samo za optimizaciju izvedbe gdje lažne povratne vrijednosti `false` od strane ove funkcije ne utječu na ishod, već samo na izvedbu.
    /// Posljedice korištenja ove metode kako bi se različiti programi ponašali u vrijeme izvođenja i vremena kompajliranja nisu istražene.
    /// Ovu se metodu ne bi smjelo koristiti za uvođenje takvih razlika, a također je ne bi trebalo stabilizirati prije nego što bolje razumijemo ovo pitanje.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Vraća je li zajamčeno da su dva pokazivača nejednaka.
    ///
    /// Za vrijeme izvođenja ova se funkcija ponaša kao `self != other`.
    /// Međutim, u nekim kontekstima (npr. Procjena vremena kompajliranja) nije uvijek moguće utvrditi nejednakost dva pokazivača, pa ova funkcija može lažno vratiti `false` za pokazivače koji se kasnije u stvari pokažu nejednakim.
    ///
    /// Ali kad vrati `true`, pokazivači će zajamčeno biti nejednaki.
    ///
    /// Ova je funkcija zrcalo [`guaranteed_eq`], ali nije njegova inverzna vrijednost.Postoje usporedbe pokazivača za koje obje funkcije vraćaju `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Povratna vrijednost može se mijenjati ovisno o verziji kompajlera, a nesigurni kôd možda se neće osloniti na ispravnost rezultata ove funkcije.
    /// Predlaže se korištenje ove funkcije samo za optimizaciju izvedbe gdje lažne povratne vrijednosti `false` od strane ove funkcije ne utječu na ishod, već samo na izvedbu.
    /// Posljedice korištenja ove metode kako bi se različiti programi ponašali u vrijeme izvođenja i vremena kompajliranja nisu istražene.
    /// Ovu se metodu ne bi smjelo koristiti za uvođenje takvih razlika, a također je ne bi trebalo stabilizirati prije nego što bolje razumijemo ovo pitanje.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Izračunava pomak iz pokazivača (pogodnost za `.offset(count as isize)`).
    ///
    /// `count` je u jedinicama T;npr. `count` od 3 predstavlja pomak pokazivača od `3 * size_of::<T>()` bajtova.
    ///
    /// # Safety
    ///
    /// Ako se prekrši bilo koji od sljedećih uvjeta, rezultat je Nedefinirano ponašanje:
    ///
    /// * I početni i rezultirajući pokazivač moraju biti u granicama ili jedan bajt iza kraja istog dodijeljenog objekta.
    /// Imajte na umu da se u Rust svaka varijabla (stack-allocated) smatra zasebnim dodijeljenim objektom.
    ///
    /// * Izračunati pomak,**u bajtovima**, ne može prekoračiti `isize`.
    ///
    /// * Pomak u granicama ne može se osloniti na "wrapping around" adresni prostor.Odnosno, zbroj beskonačne preciznosti mora stati u `usize`.
    ///
    /// Kompajler i standardna knjižnica općenito nastoje osigurati da dodjele nikada ne dosegnu veličinu kod koje je pomak zabrinut.
    /// Na primjer, `Vec` i `Box` osiguravaju da nikada ne dodijele više od `isize::MAX` bajtova, tako da je `vec.as_ptr().add(vec.len())` uvijek siguran.
    ///
    /// Većina platformi u osnovi ne može konstruirati takvu raspodjelu.
    /// Na primjer, nijedna poznata 64-bitna platforma nikada ne može poslužiti zahtjev za 2 <sup>63</sup> bajta zbog ograničenja tablice stranica ili razdvajanja adresnog prostora.
    /// Međutim, neke 32-bitne i 16-bitne platforme mogu uspješno poslužiti zahtjev za više od `isize::MAX` bajtova sa stvarima kao što je Physical Address Extension.
    ///
    /// Kao takva, memorija stečena izravno iz alokatora ili datoteka preslikanih u memoriju * može biti prevelika za rukovanje ovom funkcijom.
    ///
    /// Razmislite o upotrebi [`wrapping_add`] umjesto toga ako je teško ograničiti ta ograničenja.
    /// Jedina prednost ove metode je što omogućuje agresivniju optimizaciju kompajlera.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Izračunava pomak iz pokazivača (pogodnost za `.offset ((računa se kao isize).wrapping_neg())`).
    ///
    /// `count` je u jedinicama T;npr. `count` od 3 predstavlja pomak pokazivača od `3 * size_of::<T>()` bajtova.
    ///
    /// # Safety
    ///
    /// Ako se prekrši bilo koji od sljedećih uvjeta, rezultat je Nedefinirano ponašanje:
    ///
    /// * I početni i rezultirajući pokazivač moraju biti u granicama ili jedan bajt iza kraja istog dodijeljenog objekta.
    /// Imajte na umu da se u Rust svaka varijabla (stack-allocated) smatra zasebnim dodijeljenim objektom.
    ///
    /// * Izračunati pomak ne može premašiti `isize::MAX`**bajtova**.
    ///
    /// * Pomak u granicama ne može se osloniti na "wrapping around" adresni prostor.Odnosno, zbroj beskonačne preciznosti mora stati u veličinu.
    ///
    /// Kompajler i standardna knjižnica općenito nastoje osigurati da dodjele nikada ne dosegnu veličinu kod koje je pomak zabrinut.
    /// Na primjer, `Vec` i `Box` osiguravaju da nikada ne dodijele više od `isize::MAX` bajtova, tako da je `vec.as_ptr().add(vec.len()).sub(vec.len())` uvijek siguran.
    ///
    /// Većina platformi u osnovi ne može konstruirati takvu raspodjelu.
    /// Na primjer, nijedna poznata 64-bitna platforma nikada ne može poslužiti zahtjev za 2 <sup>63</sup> bajta zbog ograničenja tablice stranica ili razdvajanja adresnog prostora.
    /// Međutim, neke 32-bitne i 16-bitne platforme mogu uspješno poslužiti zahtjev za više od `isize::MAX` bajtova sa stvarima kao što je Physical Address Extension.
    ///
    /// Kao takva, memorija stečena izravno iz alokatora ili datoteka preslikanih u memoriju * može biti prevelika za rukovanje ovom funkcijom.
    ///
    /// Razmislite o upotrebi [`wrapping_sub`] umjesto toga ako je teško zadovoljiti ta ograničenja.
    /// Jedina prednost ove metode je što omogućuje agresivniju optimizaciju kompajlera.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Izračunava pomak od pokazivača pomoću aritmetike zamotavanja.
    /// (pogodnost za `.wrapping_offset(count as isize)`)
    ///
    /// `count` je u jedinicama T;npr. `count` od 3 predstavlja pomak pokazivača od `3 * size_of::<T>()` bajtova.
    ///
    /// # Safety
    ///
    /// Sama je ova operacija uvijek sigurna, ali upotreba rezultirajućeg pokazivača nije.
    ///
    /// Rezultirajući pokazivač ostaje pričvršćen na isti dodijeljeni objekt na koji pokazuje `self`.
    /// Ne može se *koristiti* za pristup drugom dodijeljenom objektu.Imajte na umu da se u Rust svaka varijabla (stack-allocated) smatra zasebnim dodijeljenim objektom.
    ///
    /// Drugim riječima, `let z = x.wrapping_add((y as usize) - (x as usize))`*ne* čini `z` istim kao `y`, čak i ako pretpostavimo da `T` ima veličinu `1` i da nema prelijevanja: `z` je i dalje pričvršćen na objekt na koji je pričvršćen `x`, a preusmjeravanje je Nedefinirano ponašanje osim ako `x` i `y` usmjeravaju u isti dodijeljeni objekt.
    ///
    /// U usporedbi s [`add`], ova metoda u osnovi odgađa zahtjev zadržavanja unutar istog dodijeljenog objekta: [`add`] je trenutno Nedefinirano ponašanje prilikom prelaska granica objekta;`wrapping_add` stvara pokazivač, ali i dalje dovodi do Nedefiniranog ponašanja ako je pokazivač dereferenciran kada je izvan okvira objekta na koji je povezan.
    /// [`add`] može se bolje optimizirati i stoga je poželjniji u kodu osjetljivom na performanse.
    ///
    /// Odgođena provjera uzima u obzir samo vrijednost pokazivača koji je dereferenciran, a ne srednje vrijednosti korištene tijekom izračuna konačnog rezultata.
    /// Na primjer, `x.wrapping_add(o).wrapping_sub(o)` je uvijek isti kao `x`.Drugim riječima, dopušteno je napuštanje dodijeljenog objekta i ponovni ulazak u njega kasnije.
    ///
    /// Ako trebate prijeći granice objekta, prebacite pokazivač na cijeli broj i tamo napravite aritmetiku.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// // Iteracija pomoću sirovog pokazivača u koracima od dva elementa
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ova petlja ispisuje "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Izračunava pomak od pokazivača pomoću aritmetike zamotavanja.
    /// (pogodnost za `.wrapping_offset ((računa se kao isize).wrapping_neg())`)
    ///
    /// `count` je u jedinicama T;npr. `count` od 3 predstavlja pomak pokazivača od `3 * size_of::<T>()` bajtova.
    ///
    /// # Safety
    ///
    /// Sama je ova operacija uvijek sigurna, ali upotreba rezultirajućeg pokazivača nije.
    ///
    /// Rezultirajući pokazivač ostaje pričvršćen na isti dodijeljeni objekt na koji pokazuje `self`.
    /// Ne može se *koristiti* za pristup drugom dodijeljenom objektu.Imajte na umu da se u Rust svaka varijabla (stack-allocated) smatra zasebnim dodijeljenim objektom.
    ///
    /// Drugim riječima, `let z = x.wrapping_sub((x as usize) - (y as usize))`*ne* čini `z` istim kao `y`, čak i ako pretpostavimo da `T` ima veličinu `1` i da nema prelijevanja: `z` je i dalje pričvršćen na objekt na koji je pričvršćen `x`, a preusmjeravanje je Nedefinirano ponašanje osim ako `x` i `y` usmjeravaju u isti dodijeljeni objekt.
    ///
    /// U usporedbi s [`sub`], ova metoda u osnovi odgađa zahtjev zadržavanja unutar istog dodijeljenog objekta: [`sub`] je trenutno Nedefinirano ponašanje prilikom prelaska granica objekta;`wrapping_sub` stvara pokazivač, ali i dalje dovodi do Nedefiniranog ponašanja ako je pokazivač dereferenciran kada je izvan okvira objekta na koji je povezan.
    /// [`sub`] može se bolje optimizirati i stoga je poželjniji u kodu osjetljivom na performanse.
    ///
    /// Odgođena provjera uzima u obzir samo vrijednost pokazivača koji je dereferenciran, a ne srednje vrijednosti korištene tijekom izračuna konačnog rezultata.
    /// Na primjer, `x.wrapping_add(o).wrapping_sub(o)` je uvijek isti kao `x`.Drugim riječima, dopušteno je napuštanje dodijeljenog objekta i ponovni ulazak u njega kasnije.
    ///
    /// Ako trebate prijeći granice objekta, prebacite pokazivač na cijeli broj i tamo napravite aritmetiku.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// // Ponavljajte pomoću neobrađenog pokazivača u koracima dva elementa (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ova petlja ispisuje "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Postavlja vrijednost pokazivača na `ptr`.
    ///
    /// U slučaju da je `self` pokazivač (fat) na neodređeni tip, ova će operacija utjecati samo na dio pokazivača, dok za pokazivače (thin) na veličine, to ima isti učinak kao i jednostavno dodjeljivanje.
    ///
    /// Rezultirajući pokazivač imat će porijeklo `val`, tj. Za masni pokazivač ova je operacija semantički ista kao i stvaranje novog masnog pokazivača s vrijednošću podatkovnog pokazivača `val`, ali metapodacima `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ova je funkcija prvenstveno korisna za omogućavanje bajtne aritmetike pokazivača na potencijalno masnim pokazivačima:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // ispisat će "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SIGURNOST: U slučaju tankog pokazivača, ove su operacije identične
        // na jednostavan zadatak.
        // U slučaju masnog pokazivača, s trenutnom implementacijom rasporeda pokazivača masnog sloja, prvo polje takvog pokazivača uvijek je pokazivač podataka, koji je također dodijeljen.
        //
        unsafe { *thin = val };
        self
    }

    /// Očitava vrijednost iz `self` bez pomicanja.
    /// To ostavlja memoriju u `self` nepromijenjenom.
    ///
    /// Pogledajte [`ptr::read`] za sigurnosna pitanja i primjere.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `read`.
        unsafe { read(self) }
    }

    /// Izvodi hlapljivo očitavanje vrijednosti iz `self` bez pomicanja.To ostavlja memoriju u `self` nepromijenjenom.
    ///
    /// Hlapive operacije namijenjene su djelovanju na memoriju I/O, a zajamčeno je da ih kompajler neće ukloniti ili preurediti u druge hlapljive operacije.
    ///
    ///
    /// Pogledajte [`ptr::read_volatile`] za sigurnosna pitanja i primjere.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Očitava vrijednost iz `self` bez pomicanja.
    /// To ostavlja memoriju u `self` nepromijenjenom.
    ///
    /// Za razliku od `read`, pokazivač možda nije poravnat.
    ///
    /// Pogledajte [`ptr::read_unaligned`] za sigurnosna pitanja i primjere.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopira `count * size_of<T>` bajtove od `self` do `dest`.
    /// Izvor i odredište mogu se preklapati.
    ///
    /// NOTE: ovo ima redoslijed argumenata *isti* kao [`ptr::copy`].
    ///
    /// Pogledajte [`ptr::copy`] za sigurnosna pitanja i primjere.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopira `count * size_of<T>` bajtove od `self` do `dest`.
    /// Izvor i odredište mogu se *ne* preklapati.
    ///
    /// NOTE: ovo ima redoslijed argumenata *isti* kao [`ptr::copy_nonoverlapping`].
    ///
    /// Pogledajte [`ptr::copy_nonoverlapping`] za sigurnosna pitanja i primjere.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Izračunava pomak koji treba primijeniti na pokazivač kako bi se poravnao s `align`.
    ///
    /// Ako pokazivač nije moguće poravnati, implementacija vraća `usize::MAX`.
    /// Dopušteno je da implementacija *uvijek* vrati `usize::MAX`.
    /// Samo izvedba vašeg algoritma može ovisiti o dobivanju korisnog odstupanja ovdje, a ne o njegovoj ispravnosti.
    ///
    /// Pomak se izražava u broju `T` elemenata, a ne u bajtovima.Vraćena vrijednost može se koristiti s metodom `wrapping_add`.
    ///
    /// Ne postoje nikakva jamstva da se pomicanje pokazivača neće prelijevati ili ići dalje od dodjele na koju pokazivač pokazuje.
    ///
    /// Na pozivatelju je da osigura da li je vraćeni pomak točan u svim uvjetima, osim u poravnanju.
    ///
    /// # Panics
    ///
    /// Funkcija panics ako `align` nije snaga dva.
    ///
    /// # Examples
    ///
    /// Pristup susjednom `u8` kao `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // dok se pokazivač može poravnati putem `offset`, usmjeravao bi se izvan alokacije
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SIGURNOST: Provjereno je da `align` ima snagu od 2 iznad
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Vraća duljinu sirove kriške.
    ///
    /// Vraćena vrijednost je broj **elemenata**, a ne broj bajtova.
    ///
    /// Ova je funkcija sigurna, čak i kada se sirova kriška ne može prebaciti na referencu kriške jer je pokazivač null ili neravni.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIGURNOST: ovo je sigurno jer `*const [T]` i `FatPtr<T>` imaju isti izgled.
            // Samo `std` može dati ovo jamstvo.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Vraća sirovi pokazivač na međuspremnik presjeka.
    ///
    /// To je ekvivalentno lijevanju `self` na `*const T`, ali više je sigurno.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Vraća sirovi pokazivač na element ili podrezivanje, bez provjere granica.
    ///
    /// Pozivanje ove metode s indeksom izvan granica ili kada `self` nije moguće preusmjeriti je *[nedefinirano ponašanje]* čak i ako se rezultirajući pokazivač ne koristi.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SIGURNOST: pozivatelj osigurava da se `self` ne može preusmjeriti i da je `index` unutar granica.
        unsafe { index.get_unchecked(self) }
    }

    /// Vraća `None` ako je pokazivač null ili u suprotnom vraća dijeljenu krišku na vrijednost umotanu u `Some`.
    /// Za razliku od [`as_ref`], ovo ne zahtijeva da vrijednost mora biti inicijalizirana.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kada pozivate ovu metodu, morate osigurati da je *ili* pokazivač NULL *ili* da je istinito sve sljedeće:
    ///
    /// * Pokazivač mora biti [valid] za čitanje za `ptr.len() * mem::size_of::<T>()` mnogo bajtova i mora biti pravilno poravnan.To posebno znači:
    ///
    ///     * Čitav opseg memorije ove kriške mora biti sadržan u jednom dodijeljenom objektu!
    ///       Kriške se nikada ne mogu proširiti na više dodijeljenih objekata.
    ///
    ///     * Pokazivač mora biti poravnat čak i za kriške nulte duljine.
    ///     Jedan od razloga za to je taj što se optimizacije rasporeda nabrajanja mogu oslanjati na poravnanje referenci (uključujući kriške bilo koje duljine) i one koje nisu nule kako bi se razlikovale od ostalih podataka.
    ///
    ///     Pomoću [`NonNull::dangling()`] možete dobiti pokazivač koji se koristi kao `data` za kriške nulte duljine.
    ///
    /// * Ukupna veličina kriške `ptr.len() * mem::size_of::<T>()` ne smije biti veća od `isize::MAX`.
    ///   Pogledajte sigurnosnu dokumentaciju za [`pointer::offset`].
    ///
    /// * Morate provesti Zaslanjajuća pravila Rust, jer je vraćeni vijek trajanja `'a` proizvoljno izabran i ne odražava nužno stvarni vijek trajanja podataka.
    ///   Konkretno, tijekom trajanja ovog životnog vijeka, memorija na koju pokazuje pokazivač ne smije biti mutirana (osim unutar `UnsafeCell`).
    ///
    /// To vrijedi čak i ako je rezultat ove metode neiskorišten!
    ///
    /// Vidi također [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Jednakost za pokazivače
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Usporedba pokazivača
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}