// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Rotira raspon `[mid-left, mid+right)` tako da element na `mid` postane prvi element.Jednako tako, okreće raspon `left` elemenata ulijevo ili `right` elemenata udesno.
///
/// # Safety
///
/// Navedeni raspon mora biti valjan za čitanje i pisanje.
///
/// # Algorithm
///
/// Algoritam 1 koristi se za male vrijednosti `left + right` ili za velike `T`.
/// Elementi se premještaju u svoje konačne položaje jedan po jedan, počevši od `mid - left` i napredujući `right` koracima modulo `left + right`, tako da je potreban samo jedan privremeni.
/// Na kraju se vraćamo u `mid - left`.
/// Međutim, ako `gcd(left + right, right)` nije 1, gornji koraci preskaču elemente.
/// Na primjer:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Srećom, broj preskočenih elemenata između finaliziranih elemenata uvijek je jednak, tako da možemo samo nadoknaditi početnu poziciju i napraviti više krugova (ukupan broj krugova je `gcd(left + right, right)` value).
///
/// Krajnji rezultat je da se svi elementi finaliziraju jednom i samo jednom.
///
/// Algoritam 2 koristi se ako je `left + right` velik, ali `min(left, right)` je dovoljno mali da stane u međuspremnik steka.
/// Elementi `min(left, right)` kopiraju se u međuspremnik, `memmove` se primjenjuje na ostale, a oni koji se nalaze u međuspremniku vraćaju se u rupu na suprotnoj strani mjesta na kojem su nastali.
///
/// Algoritmi koji se mogu vektorizirati nadmašuju gore navedeno kada `left + right` postane dovoljno velik.
/// Algoritam 1 može se vektorizirati dijeljenjem i izvođenjem više rundi odjednom, ali ima premalo rundi dok `left + right` ne postane ogroman, a najgori slučaj jedne runde uvijek postoji.
/// Umjesto toga, algoritam 3 koristi ponovljeno mijenjanje `min(left, right)` elemenata sve dok ne ostane manji problem rotiranja.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kada se `left < right` zamjena dogodi s lijeve strane.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. donji algoritmi mogu propasti ako se ti slučajevi ne provjere
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritam 1 Mikrobenčmarci pokazuju da su prosječne performanse za slučajne pomake bolje sve do otprilike `left + right == 32`, ali najlošiji učinak čak je oko 16.
            // 24 je odabran kao sredina.
            // Ako je veličina `T` veća od 4 `usize`-a, ovaj algoritam također nadmašuje ostale algoritme.
            //
            //
            let x = unsafe { mid.sub(left) };
            // početak prvog kruga
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` može se naći prije izračunavanja `gcd(left + right, right)`, ali brže je napraviti jednu petlju koja izračunava gcd kao nuspojavu, a zatim raditi ostatak dijela
            //
            //
            let mut gcd = right;
            // mjerila otkrivaju da je brže zamijeniti privremene stranice, umjesto da jednom privremeno pročitate jedno, kopirate unatrag, a zatim to privremeno napišete na samom kraju.
            // To je vjerojatno zbog činjenice da zamjena ili zamjena privremenih stranica koristi samo jednu memorijsku adresu u petlji, umjesto da treba upravljati dvjema.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // umjesto da povećavamo `i`, a zatim provjeravamo je li izvan granica, provjeravamo hoće li `i` izaći izvan granica na sljedećem povećanju.
                // To sprječava umotavanje pokazivača ili `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // kraj prvog kruga
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ovaj uvjet mora biti ovdje ako je `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // završite komad s više rundi
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nije tip nulte veličine, pa je u redu podijeliti ga po veličini.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritam 2 Ovdje `[T; 0]` želi osigurati da je to na odgovarajući način poravnato za T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritam 3 Postoji alternativni način zamjene koji uključuje pronalaženje gdje bi bila posljednja zamjena ovog algoritma i zamjena pomoću tog posljednjeg dijela umjesto zamjene susjednih dijelova kao što to radi ovaj algoritam, ali ovaj je način ipak brži.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritam 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}