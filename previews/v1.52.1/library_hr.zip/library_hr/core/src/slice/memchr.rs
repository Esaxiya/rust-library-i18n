// Izvorna provedba preuzeta iz rust-memchr.
// Copyright 2015 Andrew Gallant, bluss i Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Koristite skraćivanje.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Vraća `true` ako `x` sadrži bilo koji bajt nula.
///
/// Iz *Matters Computational*, J. Arndt:
///
/// "Ideja je oduzeti po jedan od svakog bajta, a zatim potražiti bajtove gdje se posuđivanje širi sve do najznačajnijih
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Vraća prvi indeks koji odgovara bajtu `x` u `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Brzi put za male kriške
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Tražite vrijednost od jednog bajta čitajući istovremeno dvije `usize` riječi.
    //
    // Split `text` u tri dijela
    // - neusklađeni početni dio, prije prve adrese poravnate u tekstu
    // - tijelo, skeniraj po 2 riječi istodobno
    // - zadnji preostali dio, <2 riječi

    // traži do poravnate granice
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // pretražite tijelo teksta
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SIGURNOST: predikat while jamči udaljenost od najmanje 2 * usize_bytes
        // između pomaka i kraja kriške.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break ako postoji odgovarajući bajt
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Pronađite bajt nakon točke zaustavljene tjelesne petlje.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Vraća zadnji indeks koji se podudara s bajtom `x` u `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Tražite vrijednost od jednog bajta čitajući istovremeno dvije `usize` riječi.
    //
    // Split `text` u tri dijela:
    // - nesravnjeni rep, nakon zadnje adrese u tekstu poravnate,
    // - tijelo, skenirano po 2 riječi istodobno,
    // - prvi preostali bajt, veličina <2 riječi.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // To nazivamo samo da bismo dobili duljinu prefiksa i sufiksa.
        // U sredini uvijek obradimo dva komada odjednom.
        // SIGURNOST: pretvaranje `[u8]` u `[usize]` je sigurno, osim zbog razlika u veličini kojima se bavi `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Pretražite tijelo teksta, pazite da ne prijeđemo min_aligned_offset.
    // pomak je uvijek poravnat, tako da je dovoljno samo testiranje `>` i izbjegava moguće preljevanje.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SIGURNOST: pomak započinje s lenom, suffix.len(), sve dok je veći od
        // min_aligned_offset (prefix.len()) preostala udaljenost je najmanje 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Prekini ako postoji odgovarajući bajt.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Pronađite bajt prije točke zaustavljene tjelesne petlje.
    text[..offset].iter().rposition(|elt| *elt == x)
}