use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Sučelje za rješavanje asinkronih iteratora.
///
/// Ovo je glavni tok Portrait.
/// Za više informacija o konceptu općenito strujanja, pogledajte [module-level documentation].
/// Konkretno, možda biste željeli znati kako [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Vrsta predmeta koje daje tok.
    type Item;

    /// Pokušaj izvlačenja sljedeće vrijednosti ovog toka, registriranje trenutnog zadatka za buđenje ako vrijednost još nije dostupna i vraćanje `None` ako je tok iscrpljen.
    ///
    /// # Povratna vrijednost
    ///
    /// Postoji nekoliko mogućih povratnih vrijednosti, od kojih svaka ukazuje na zasebno stanje toka:
    ///
    /// - `Poll::Pending` znači da sljedeća vrijednost ovog streama još nije spremna.Implementacije će osigurati da će trenutni zadatak biti obaviješten kad sljedeća vrijednost bude spremna.
    ///
    /// - `Poll::Ready(Some(val))` znači da je tok uspješno proizveo vrijednost, `val`, i može proizvesti daljnje vrijednosti u sljedećim pozivima `poll_next`.
    ///
    /// - `Poll::Ready(None)` znači da je tok završen i `poll_next` se ne smije ponovno pozivati.
    ///
    /// # Panics
    ///
    /// Kad se tok završi (vrati `Ready(None)` from `poll_next`), ponovno pozivanje njegove metode `poll_next` može panic, zauvijek blokirati ili uzrokovati druge vrste problema; `Stream` Portrait ne postavlja zahtjeve za učinke takvog poziva.
    ///
    /// Međutim, kako metoda `poll_next` nije označena kao `unsafe`, primjenjuju se uobičajena pravila Rust: pozivi nikada ne smiju uzrokovati nedefinirano ponašanje (oštećenje memorije, nepravilna upotreba funkcija `unsafe` ili slično), bez obzira na stanje toka.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Vraća granice preostale duljine toka.
    ///
    /// Konkretno, `size_hint()` vraća tuple gdje je prvi element donja granica, a drugi element gornja granica.
    ///
    /// Druga polovica korpice koja se vraća je [`Option`]`<`[`usize`] `>`.
    /// [`None`] ovdje znači da ili ne postoji poznata gornja granica, ili je gornja granica veća od [`usize`].
    ///
    /// # Napomene o provedbi
    ///
    /// Ne provodi se da implementacija toka daje deklarirani broj elemenata.Struja buggy-a može donijeti manje od donje granice ili više od gornje granice elemenata.
    ///
    /// `size_hint()` namijenjen je prvenstveno korištenju za optimizacije kao što je rezerviranje prostora za elemente toka, ali ne smije mu se vjerovati da npr. izostavlja provjere granica u nesigurnom kodu.
    /// Neispravna implementacija `size_hint()` ne bi trebala dovesti do kršenja sigurnosti memorije.
    ///
    /// Međutim, implementacija bi trebala dati ispravnu procjenu, jer bi u protivnom predstavljala kršenje protokola Portrait.
    ///
    /// Zadana implementacija vraća `(0,` [`None`]`)`što je točno za bilo koji tok.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}