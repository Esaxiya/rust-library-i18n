//! Sastavljiva asinkrona iteracija.
//!
//! Ako su futures asinkrone vrijednosti, tada su tokovi asinkroni iteratori.
//! Ako ste se našli s nekom vrstom asinkrone zbirke i trebate izvršiti operaciju nad elementima navedene zbirke, brzo ćete naletjeti na 'streams'.
//! Potoci se intenzivno koriste u idiomatskom asinkronom Rust kodu, pa je vrijedno upoznati se s njima.
//!
//! Prije objašnjavanja više, razgovarajmo o strukturi ovog modula:
//!
//! # Organization
//!
//! Ovaj je modul uglavnom organiziran po vrstama:
//!
//! * [Traits] su osnovni dio: ovi traits definiraju kakve vrste tokova postoje i što s njima možete učiniti.Metode ovih traits vrijede uložiti neko dodatno vrijeme za proučavanje.
//! * Funkcije pružaju neke korisne načine za stvaranje nekih osnovnih tokova.
//! * Strukture su često povratne vrste različitih metoda na traits ovog modula.Obično ćete htjeti pogledati metodu koja stvara `struct`, a ne sam `struct`.
//! Za više detalja o tome, pogledajte '[Implementacija toka](#implementacija-tok)'.
//!
//! [Traits]: #traits
//!
//! To je to!Kopajmo u potoke.
//!
//! # Stream
//!
//! Srce i duša ovog modula je [`Stream`] Portrait.Jezgra [`Stream`] izgleda ovako:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Za razliku od `Iterator`, `Stream` pravi razliku između metode [`poll_next`] koja se koristi prilikom implementacije `Stream` i metode (to-be-implemented) `next` koja se koristi kada troši tok.
//!
//! Potrošači `Stream` trebaju uzeti u obzir samo `next`, koji kada se pozove, vraća future koji daje `Option<Stream::Item>`.
//!
//! future koji je vratio `next` davat će `Some(Item)` sve dok postoje elementi, a nakon što se svi iscrpe, dat će `None` da pokaže da je iteracija završena.
//! Ako čekamo da se nešto asinkrono riješi, future će pričekati dok stream ne bude spreman za ponovno popuštanje.
//!
//! Pojedinačni tokovi mogu se odlučiti za nastavak ponavljanja, pa tako ponovno pozivanje `next` može u nekom trenutku opet ili ne mora dati `Some(Item)`.
//!
//! Potpuna definicija [`Stream`] uključuje i brojne druge metode, ali to su zadane metode, izgrađene na vrhu [`poll_next`], pa ih dobivate besplatno.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Provedba toka
//!
//! Stvaranje vlastitog toka uključuje dva koraka: stvaranje `struct` za zadržavanje stanja streama, a zatim implementacija [`Stream`] za taj `struct`.
//!
//! Napravimo stream pod nazivom `Counter` koji se broji od `1` do `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Prvo, struktura:
//!
//! /// Potok koji broji od jedan do pet
//! struct Counter {
//!     count: usize,
//! }
//!
//! // želimo da naše brojanje započne u jedan, pa dodajmo new() metodu u pomoć.
//! // To nije strogo potrebno, ali je prikladno.
//! // Imajte na umu da `count` započinjemo s nulom, a u nastavku ćemo vidjeti zašto u implementaciji `poll_next()`'s.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Zatim implementiramo `Stream` za naš `Counter`:
//!
//! impl Stream for Counter {
//!     // računat ćemo s usizeom
//!     type Item = usize;
//!
//!     // poll_next() je jedina potrebna metoda
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Povećajte naše brojanje.Zbog toga smo započeli s nulom.
//!         self.count += 1;
//!
//!         // Provjerite jesmo li završili s brojanjem ili nismo.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Potoci su *lijeni*.To znači da samo stvaranje streama ne znači puno _do_.Ništa se zapravo ne događa dok ne nazovete `next`.
//! To ponekad dovodi do zabune pri stvaranju streama isključivo zbog njegovih nuspojava.
//! Prevoditelj će nas upozoriti na takvo ponašanje:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;