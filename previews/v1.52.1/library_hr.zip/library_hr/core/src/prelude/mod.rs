//! Libcore prelude
//!
//! Ovaj je modul namijenjen korisnicima libcore-a koji se također ne povezuju na libstd.
//! Ovaj se modul uvozi prema zadanim postavkama kada se `#![no_std]` koristi na isti način kao i prelude standardne knjižnice.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Verzija jezgre prelude iz 2015. godine.
///
/// Pogledajte [module-level documentation](self) za više.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Verzija jezgre prelude iz 2018. godine.
///
/// Pogledajte [module-level documentation](self) za više.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Verzija jezgre prelude iz 2021. godine.
///
/// Pogledajte [module-level documentation](self) za više.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Dodajte još stvari.
}