//! Načini za stvaranje `str` od bajtnog odsječka.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Pretvara krišku bajtova u krišku niza.
///
/// Odrezak niza ([`&str`]) sastoji se od bajtova ([`u8`]), a odsječak bajtova ([`&[u8]`][byteslice]) od bajtova, pa se ova funkcija pretvara između njih.
/// Nisu sve kriške bajtova valjane kriške niza, međutim: [`&str`] zahtijeva da vrijedi UTF-8.
/// `from_utf8()` provjerava jesu li bajtovi valjani UTF-8, a zatim izvršava pretvorbu.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ako ste sigurni da je bajtni odsječak valjan UTF-8 i ne želite pretjerivati u provjeru valjanosti, postoji nesigurna verzija ove funkcije, [`from_utf8_unchecked`], koja se ponaša na isti način, ali preskače provjeru.
///
///
/// Ako vam je potreban `String` umjesto `&str`, razmislite o [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Budući da možete dodijeliti `[u8; N]` u stog, a možete uzeti i [`&[u8]`][byteslice], ova je funkcija jedan od načina da se niz dodeli za skup.Primjer za to je u odjeljku primjera u nastavku.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Vraća `Err` ako presjek nije UTF-8 s opisom zašto dostavljeni odsječak nije UTF-8.
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::str;
///
/// // neki bajtovi, u vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Znamo da su ti bajtovi valjani, zato samo upotrijebite `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Netočni bajtovi:
///
/// ```
/// use std::str;
///
/// // neki nevaljani bajtovi, u vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Pogledajte dokumente za [`Utf8Error`] za više pojedinosti o vrstama pogrešaka koje se mogu vratiti.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // nekoliko bajtova, u nizu dodijeljenom hrpom
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Znamo da su ti bajtovi valjani, zato samo upotrijebite `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIGURNOST: Upravo pokrenuta provjera valjanosti.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Pretvara promjenjivu krišku bajtova u promjenjivu krišku niza.
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" kao promjenjiv vektor
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Kao što znamo da ovi bajtovi vrijede, možemo koristiti `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Netočni bajtovi:
///
/// ```
/// use std::str;
///
/// // Neki nevaljani bajtovi u promjenjivom vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Pogledajte dokumente za [`Utf8Error`] za više pojedinosti o vrstama pogrešaka koje se mogu vratiti.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIGURNOST: Upravo pokrenuta provjera valjanosti.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Pretvara krišku bajtova u krišku niza bez provjere sadrži li niz valjani UTF-8.
///
/// Pogledajte sigurnu verziju [`from_utf8`] za više informacija.
///
/// # Safety
///
/// Ova funkcija nije sigurna jer ne provjerava jesu li bajtovi koji su joj proslijeđeni valjani UTF-8.
/// Ako se ovo ograničenje prekrši, rezultira nedefinirano ponašanje, jer ostatak Rust pretpostavlja da su [`&str`] s važeći UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::str;
///
/// // neki bajtovi, u vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SIGURNOST: pozivatelj mora jamčiti da su bajtovi `v` valjani UTF-8.
    // Također se oslanja na `&str` i `&[u8]` koji imaju isti izgled.
    unsafe { mem::transmute(v) }
}

/// Pretvara krišku bajtova u krišku niza bez provjere sadrži li niz valjani UTF-8;promjenjiva verzija.
///
///
/// Pogledajte nepromjenjivu verziju [`from_utf8_unchecked()`] za više informacija.
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SIGURNOST: pozivatelj mora jamčiti da bajtovi `v`
    // vrijede UTF-8, tako da je prebacivanje na `*mut str` sigurno.
    // Također, preusmjeravanje pokazivača je sigurno jer taj pokazivač dolazi od reference koja zajamčeno vrijedi za upise.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}