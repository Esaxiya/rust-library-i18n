//! Trait implementacije za `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Provodi poredak nizova.
///
/// Nizovi su poredani [lexicographically](Ord#lexicographical-comparison) prema njihovim bajt-vrijednostima.
/// To naručuje Unicode kodne točke na temelju njihovih položaja na grafikonima koda.
/// To nije nužno isto kao narudžba "alphabetical", koja se razlikuje ovisno o jeziku i jeziku.
/// Za sortiranje nizova prema kulturno prihvaćenim standardima potrebni su podaci specifični za lokalno područje koji su izvan dosega tipa `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Provodi operacije usporedbe na nizovima.
///
/// Nizovi se uspoređuju s [lexicographically](Ord#lexicographical-comparison) prema njihovim bajt vrijednostima.
/// Ovim se uspoređuju Unicode kodne točke na temelju njihovih položaja na grafikonima koda.
/// To nije nužno isto kao narudžba "alphabetical", koja se razlikuje ovisno o jeziku i jeziku.
/// Usporedba nizova prema kulturno prihvaćenim standardima zahtijeva podatke specifične za lokalno područje koji su izvan dosega tipa `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Provodi rezanje podniza sintaksom `&self[..]` ili `&mut self[..]`.
///
/// Vraća odsječak cijelog niza, tj. Vraća `&self` ili `&mut self`.Ekvivalentno `&self [0 ..
/// len] `ili`&mut self [0 ..
/// len]`.
/// Za razliku od drugih operacija indeksiranja, to nikada ne može biti panic.
///
/// Ova operacija je *O*(1).
///
/// Prije 1.20.0, ove su operacije indeksiranja i dalje bile podržane izravnom implementacijom `Index` i `IndexMut`.
///
/// Ekvivalentno `&self[0 .. len]` ili `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Provodi rezanje podniza sintaksom `&self[begin .. end]` ili `&mut self[begin .. end]`.
///
/// Vraća odrezak zadanog niza iz raspona bajtova [`begin`, `end`).
///
/// Ova operacija je *O*(1).
///
/// Prije 1.20.0, ove su operacije indeksiranja i dalje bile podržane izravnom implementacijom `Index` i `IndexMut`.
///
/// # Panics
///
/// Panics ako `begin` ili `end` ne upućuje na pomak početnog bajta znaka (kako je definirano `is_char_boundary`), ako `begin > end` ili ako `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ovo će panic:
/// // bajt 2 nalazi se unutar `ö`:
/// // &s [2.3.];
///
/// // bajt 8 nalazi se unutar `老`&s [1 ..
/// // 8];
///
/// // bajt 100 je izvan niza&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURNOST: upravo provjerili jesu li `start` i `end` na granici znakova,
            // i prosljeđujemo sigurnu referencu, pa će i povratna vrijednost biti jedna.
            // Također smo provjerili granice znakova, pa je ovo važeći UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURNOST: upravo provjerili jesu li `start` i `end` na granici znakova.
            // Znamo da je pokazivač jedinstven jer smo ga dobili od `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIGURNOST: pozivatelj jamči da je `self` u granicama `slice`
        // koji zadovoljava sve uvjete za `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIGURNOST: vidi komentare za `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary provjerava je li indeks u [0, .len()] ne može ponovno upotrijebiti `get` kao gore, zbog problema s NLL-om
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURNOST: upravo provjerili jesu li `start` i `end` na granici znakova,
            // i prosljeđujemo sigurnu referencu, pa će i povratna vrijednost biti jedna.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Provodi rezanje podniza sintaksom `&self[.. end]` ili `&mut self[.. end]`.
///
/// Vraća odrezak datog niza iz raspona bajtova [`0`, `end`).
/// Ekvivalentno `&self[0 .. end]` ili `&mut self[0 .. end]`.
///
/// Ova operacija je *O*(1).
///
/// Prije 1.20.0, ove su operacije indeksiranja i dalje bile podržane izravnom implementacijom `Index` i `IndexMut`.
///
/// # Panics
///
/// Panics ako `end` ne ukazuje na pomak početnog bajta znaka (kako je definirano `is_char_boundary`), ili ako `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIGURNOST: upravo provjerili je li `end` na granici znakova,
            // i prosljeđujemo sigurnu referencu, pa će i povratna vrijednost biti jedna.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIGURNOST: upravo provjerili je li `end` na granici znakova,
            // i prosljeđujemo sigurnu referencu, pa će i povratna vrijednost biti jedna.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SIGURNOST: upravo provjerili je li `end` na granici znakova,
            // i prosljeđujemo sigurnu referencu, pa će i povratna vrijednost biti jedna.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Provodi rezanje podniza sintaksom `&self[begin ..]` ili `&mut self[begin ..]`.
///
/// Vraća odrezak zadanog niza iz raspona bajtova [`begin`, `len`).Ekvivalentno `&self [započeti ..
/// len] `ili`&mut self [započeti ..
/// len]`.
///
/// Ova operacija je *O*(1).
///
/// Prije 1.20.0, ove su operacije indeksiranja i dalje bile podržane izravnom implementacijom `Index` i `IndexMut`.
///
/// # Panics
///
/// Panics ako `begin` ne ukazuje na pomak početnog bajta znaka (kako je definirano `is_char_boundary`), ili ako `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIGURNOST: upravo provjerili je li `start` na granici znakova,
            // i prosljeđujemo sigurnu referencu, pa će i povratna vrijednost biti jedna.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIGURNOST: upravo provjerili je li `start` na granici znakova,
            // i prosljeđujemo sigurnu referencu, pa će i povratna vrijednost biti jedna.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIGURNOST: pozivatelj jamči da je `self` u granicama `slice`
        // koji zadovoljava sve uvjete za `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIGURNOST: identično `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SIGURNOST: upravo provjerili je li `start` na granici znakova,
            // i prosljeđujemo sigurnu referencu, pa će i povratna vrijednost biti jedna.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Provodi rezanje podniza sintaksom `&self[begin ..= end]` ili `&mut self[begin ..= end]`.
///
/// Vraća odrezak zadanog niza iz raspona bajtova [`begin`, `end`].Ekvivalentno `&self [begin .. end + 1]` ili `&mut self[begin .. end + 1]`, osim ako `end` ima maksimalnu vrijednost za `usize`.
///
/// Ova operacija je *O*(1).
///
/// # Panics
///
/// Panics ako `begin` ne upućuje na pomak početnog bajta znaka (kako je definirano `is_char_boundary`), ako `end` ne pokazuje pomak završnog bajta znaka (`end + 1` je ili pomak početnog bajta ili jednak `len`), ako je `begin > end`, ili ako je `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Provodi rezanje podniza sintaksom `&self[..= end]` ili `&mut self[..= end]`.
///
/// Vraća odrezak zadanog niza iz bajtnog raspona [0, `end`].
/// Ekvivalentno `&self [0 .. end + 1]`, osim ako `end` ima maksimalnu vrijednost za `usize`.
///
/// Ova operacija je *O*(1).
///
/// # Panics
///
/// Panics ako `end` ne pokazuje krajnji pomak bajta znaka (`end + 1` je ili početni pomak bajta kako je definirano `is_char_boundary` ili je jednak `len`), ili ako `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analizirajte vrijednost iz niza
///
/// `FromStr`-ova metoda [`from_str`] često se koristi implicitno, putem [`str`]-ove [`parse`] metode.
/// Primjere potražite u dokumentaciji [`parse`].
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nema parametar trajanja, tako da možete raščlaniti samo tipove koji sami ne sadrže parametar trajanja.
///
/// Drugim riječima, `i32` možete raščlaniti s `FromStr`, ali ne i `&i32`.
/// Možete raščlaniti strukturu koja sadrži `i32`, ali ne i onu koja sadrži `&i32`.
///
/// # Examples
///
/// Osnovna implementacija `FromStr` na primjeru tipa `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Povezana pogreška koja se može vratiti raščlanjivanjem.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analizira niz `s` za vraćanje vrijednosti ove vrste.
    ///
    /// Ako je raščlanjivanje uspjelo, vratite vrijednost unutar [`Ok`], u suprotnom, kada je niz loše oblikovan, vratite pogrešku specifičnu za unutarnji [`Err`].
    /// Vrsta pogreške specifična je za implementaciju Portrait.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba s [`i32`], tipom koji implementira `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analizirajte `bool` iz niza.
    ///
    /// Daje `Result<bool, ParseBoolError>`, jer `s` zapravo može ili ne mora biti raščlanjiv.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Imajte na umu da je u mnogim slučajevima metoda `.parse()` na `str` prikladnija.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}