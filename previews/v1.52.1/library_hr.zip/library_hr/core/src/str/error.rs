//! Definira vrstu pogreške utf8.

use crate::fmt;

/// Pogreške koje se mogu pojaviti pri pokušaju tumačenja niza [`u8`] kao niza.
///
/// Kao takve, obitelj funkcija i metoda `from_utf8` i za [`String`] i [`&str`] koriste ovu pogrešku, na primjer.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Metode ove vrste pogreške mogu se koristiti za stvaranje funkcionalnosti slične `String::from_utf8_lossy` bez dodjeljivanja hrpe memorije:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Vraća indeks u zadanom nizu do kojeg je provjeren valjani UTF-8.
    ///
    /// To je maksimalni indeks takav da bi `from_utf8(&input[..index])` vratio `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::str;
    ///
    /// // neki nevaljani bajtovi, u vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 vraća Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // drugi bajt ovdje nije valjan
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Pruža više informacija o kvaru:
    ///
    /// * `None`: kraj unosa je neočekivano dosegnut.
    ///   `self.valid_up_to()` je 1 do 3 bajta od kraja unosa.
    ///   Ako se protok bajtova (kao što je datoteka ili mrežna utičnica) dekodira postupno, to bi mogao biti valjani `char` čiji se redoslijed bajtova UTF-8 obuhvaća više dijelova.
    ///
    ///
    /// * `Some(len)`: nađen je neočekivani bajt.
    ///   Navedena duljina je nevažeće sekvence bajtova koja započinje indeksom koji daje `valid_up_to()`.
    ///   Dekodiranje bi se trebalo nastaviti nakon te sekvence (nakon umetanja [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) u slučaju dekodiranja s gubitkom.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Pogreška vraćena kada raščlanjivanje `bool` pomoću [`from_str`] ne uspije
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}