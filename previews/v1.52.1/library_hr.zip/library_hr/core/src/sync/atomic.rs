//! Atomske vrste
//!
//! Atomski tipovi pružaju primitivnu komunikaciju dijeljene memorije između niti i gradivni su blokovi ostalih istodobnih tipova.
//!
//! Ovaj modul definira atomske verzije odabranog broja primitivnih tipova, uključujući [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] itd.
//! Atomske vrste predstavljaju operacije koje, kada se pravilno koriste, sinkroniziraju ažuriranja između niti.
//!
//! Svaka metoda uzima [`Ordering`] koji predstavlja snagu memorijske barijere za tu operaciju.Ove su narudžbe jednake [C++20 atomic orderings][1].Za više informacija pogledajte [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomske varijable sigurno je dijeliti između niti (one implementiraju [`Sync`]), ali same ne pružaju mehanizam za dijeljenje i slijede [threading model](../../../std/thread/index.html#the-threading-model) Rust.
//!
//! Najčešći način dijeljenja atomske varijable je stavljanje u [`Arc`][arc] (dijeljeni pokazivač s brojanjem atomskih referenci).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomski tipovi mogu se pohraniti u statičke varijable, inicijalizirane pomoću konstantnih inicijalizatora poput [`AtomicBool::new`].Atomska se statika često koristi za lijenu globalnu inicijalizaciju.
//!
//! # Portability
//!
//! Svi atomski tipovi u ovom modulu zajamčeno su [lock-free] ako su dostupni.To znači da oni interno ne stječu globalni mutex.Atomske vrste i postupci ne mogu se čekati bez čekanja.
//! To znači da se operacije poput `fetch_or` mogu provoditi pomoću petlje usporedi i zamjeni.
//!
//! Atomske operacije mogu se provoditi na sloju instrukcija s atomikom veće veličine.Na primjer, neke platforme koriste 4-bajtne atomske upute za implementaciju `AtomicI8`.
//! Imajte na umu da ova emulacija ne bi trebala imati utjecaja na ispravnost koda, to je samo nešto čega treba biti svjestan.
//!
//! Atomski tipovi u ovom modulu možda neće biti dostupni na svim platformama.Ovdje su svi atomski tipovi široko dostupni i na njih se općenito može pouzdati.Neke značajne iznimke su:
//!
//! * PowerPC i MIPS platforme s 32-bitnim pokazivačima nemaju tipove `AtomicU64` ili `AtomicI64`.
//! * ARM platforme poput `armv5te` koje nisu za Linux pružaju samo operacije `load` i `store` i ne podržavaju operacije Usporedba i zamjena (CAS), kao što su `swap`, `fetch_add` itd.
//! Pored toga, na Linux, ove CAS operacije se provode putem [operating system support], što može doći s kaznom izvedbe.
//! * ARM ciljevi s `thumbv6m` pružaju samo operacije `load` i `store` i ne podržavaju operacije usporedbe i zamjene (CAS), kao što su `swap`, `fetch_add` itd.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Imajte na umu da se mogu dodati platforme future koje također nemaju podršku za neke atomske operacije.Maksimalno prenosivi kod željet će biti oprezan oko toga koji se atomski tipovi koriste.
//! `AtomicUsize` i `AtomicIsize` općenito su najnosiviji, ali čak i tada nisu svugdje dostupni.
//! Za referencu, knjižnica `std` zahtijeva atomiku veličine pokazivača, iako `core` ne.
//!
//! Trenutno ćete `#[cfg(target_arch)]` trebati koristiti prvenstveno za uvjetno kompiliranje u kodu s atomikom.Postoji i nestabilan `#[cfg(target_has_atomic)]` koji se može stabilizirati u future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Jednostavan spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Pričekajte da druga nit otpusti bravu
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Vodite globalno brojanje živih niti:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Logički tip koji se može sigurno dijeliti između niti.
///
/// Ovaj tip ima isti prikaz u memoriji kao [`bool`].
///
/// **Napomena**: Ova vrsta je dostupna samo na platformama koje podržavaju atomska opterećenja i pohrane `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Stvara `AtomicBool` inicijaliziran za `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send je implicitno implementiran za AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Neobrađeni tip pokazivača koji se može sigurno dijeliti između niti.
///
/// Ovaj tip ima isti prikaz u memoriji kao `*mut T`.
///
/// **Napomena**: Ova vrsta je dostupna samo na platformama koje podržavaju atomska opterećenja i spremišta pokazivača.
/// Njegova veličina ovisi o veličini ciljnog pokazivača.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Stvara nulu `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Poredak atomske memorije
///
/// Poredak memorije određuje način na koji atomske operacije sinkroniziraju memoriju.
/// U najslabijem [`Ordering::Relaxed`] sinkronizira se samo memorija koju je operacija izravno dotaknula.
/// S druge strane, spremište-učitavanje para [`Ordering::SeqCst`] operacija sinkronizira drugu memoriju, uz istovremeno očuvanje ukupnog redoslijeda takvih operacija u svim nitima.
///
///
/// Rust-ove narudžbe memorije su [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Za više informacija pogledajte [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Nema ograničenja za naručivanje, samo atomske operacije.
    ///
    /// Odgovara [`memory_order_relaxed`] u C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// U kombinaciji s pohranom, sve prethodne operacije postaju poredane prije bilo kakvog učitavanja ove vrijednosti s narudžbom [`Acquire`] (ili jačom).
    ///
    /// Konkretno, sva prethodna upisivanja postaju vidljiva svim nitima koje izvršavaju [`Acquire`] (ili jače) opterećenje ove vrijednosti.
    ///
    /// Primijetite da upotreba ove narudžbe za operaciju koja kombinira opterećenja i pohrane dovodi do operacije opterećenja [`Relaxed`]!
    ///
    /// Ova se narudžba odnosi samo na operacije koje mogu izvršiti trgovinu.
    ///
    /// Odgovara [`memory_order_release`] u C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// U kombinaciji s opterećenjem, ako je učitana vrijednost napisana operacijom spremanja s narudžbom [`Release`] (ili jačom), tada sve sljedeće operacije postaju poredane nakon tog spremišta.
    /// Konkretno, za sva sljedeća učitavanja vidjet će se podaci zapisani prije pohrane.
    ///
    /// Primijetite da upotreba ove narudžbe za operaciju koja kombinira opterećenja i spremišta dovodi do rada trgovine [`Relaxed`]!
    ///
    /// Ova se narudžba odnosi samo na operacije koje mogu izvesti opterećenje.
    ///
    /// Odgovara [`memory_order_acquire`] u C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Ima učinke i [`Acquire`] i [`Release`] zajedno:
    /// Za opterećenja koristi narudžbu [`Acquire`].Za trgovine koristi narudžbu [`Release`].
    ///
    /// Primijetite da je u slučaju `compare_and_swap` moguće da operacija na kraju ne izvrši nijednu trgovinu i stoga ima samo [`Acquire`] naručivanje.
    ///
    /// Međutim, `AcqRel` nikada neće izvršiti pristupe [`Relaxed`].
    ///
    /// Ova se narudžba odnosi samo na operacije koje kombiniraju i teret i zalihe.
    ///
    /// Odgovara [`memory_order_acq_rel`] u C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Poput [`Acquire`]/[`Release`]/[`AcqRel`](za operacije učitavanja, spremanja i učitavanja s pohranom) s dodatnim jamstvom da sve niti vide sve sekvencijalno dosljedne operacije u istom redoslijedu .
    ///
    ///
    /// Odgovara [`memory_order_seq_cst`] u C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] inicijaliziran za `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Stvara novi `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Vraća promjenjivu referencu na temeljni [`bool`].
    ///
    /// To je sigurno jer promjenjiva referenca jamči da niti jedna nit istovremeno ne pristupa atomskim podacima.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SIGURNOST: promjenjiva referenca jamči jedinstveno vlasništvo.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Nabavite atomski pristup `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SIGURNOST: promjenjiva referenca jamči jedinstveno vlasništvo i
        // poravnanje i `bool` i `Self` je 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Troši atomsku i vraća sadržanu vrijednost.
    ///
    /// To je sigurno jer prosljeđivanje `self` po vrijednosti jamči da niti jedna nit istovremeno ne pristupa atomskim podacima.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Učitava vrijednost iz bool.
    ///
    /// `load` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.
    /// Moguće vrijednosti su [`SeqCst`], [`Acquire`] i [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ako je `order` [`Release`] ili [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SIGURNOST: atomske osobine i sirovi podaci sprečavaju bilo kakve utrke podataka
        // predani pokazivač je valjan jer smo ga dobili iz reference.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Pohranjuje vrijednost u bool.
    ///
    /// `store` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.
    /// Moguće vrijednosti su [`SeqCst`], [`Release`] i [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ako je `order` [`Acquire`] ili [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SIGURNOST: atomske osobine i sirovi podaci sprečavaju bilo kakve utrke podataka
        // predani pokazivač je valjan jer smo ga dobili iz reference.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Pohranjuje vrijednost u bool vraćajući prethodnu vrijednost.
    ///
    /// `swap` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
    /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
    ///
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Pohranjuje vrijednost u [`bool`] ako je trenutna vrijednost ista kao vrijednost `current`.
    ///
    /// Povratna vrijednost je uvijek prethodna vrijednost.Ako je jednako `current`, tada je vrijednost ažurirana.
    ///
    /// `compare_and_swap` također uzima [`Ordering`] argument koji opisuje redoslijed memorije ove operacije.
    /// Primijetite da čak i kada koristite [`AcqRel`], operacija možda neće uspjeti i stoga samo izvršava `Acquire` učitavanje, ali neće imati `Release` semantiku.
    /// Korištenje [`Acquire`] čini pohranu dijelom ove operacije [`Relaxed`] ako se dogodi, a korištenje [`Release`] čini dio učitavanja [`Relaxed`].
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na `u8`.
    ///
    /// # Prelazak na `compare_exchange` i `compare_exchange_weak`
    ///
    /// `compare_and_swap` ekvivalentan je `compare_exchange` sa sljedećim mapiranjem za naručivanje memorije:
    ///
    /// Izvornik |Uspjeh |Neuspjeh
    /// -------- | ------- | -------
    /// Opušteno |Opušteno |Opušteno stjecanje |Stjecanje |Otpustite |Izdanje |Opušteno AcqRel |AcqRel |Nabavite SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` dopušteno je da lažno ne uspije čak i kada usporedba uspije, što omogućuje prevoditelju da generira bolji sklopni kod kada se usporedba i zamjena koriste u petlji.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Pohranjuje vrijednost u [`bool`] ako je trenutna vrijednost ista kao vrijednost `current`.
    ///
    /// Povratna vrijednost rezultat je koji pokazuje je li nova vrijednost napisana i sadrži li prethodnu vrijednost.
    /// U uspjehu će ova vrijednost biti zajamčena jednaka `current`.
    ///
    /// `compare_exchange` uzima dva [`Ordering`] argumenta za opisivanje redoslijeda memorije ove operacije.
    /// `success` opisuje potrebno naručivanje za operaciju čitanja-izmjene-pisanja koja se odvija ako usporedba s `current` uspije.
    /// `failure` opisuje potrebno naručivanje za rad opterećenja koji se odvija kada usporedba ne uspije.
    /// Korištenje [`Acquire`] kao uspješnog naručivanja čini pohranu dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini uspješno učitavanje [`Relaxed`].
    ///
    /// Naručivanje kvara može biti samo [`SeqCst`], [`Acquire`] ili [`Relaxed`] i mora biti jednako ili slabije od narudžbe uspjeha.
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Pohranjuje vrijednost u [`bool`] ako je trenutna vrijednost ista kao vrijednost `current`.
    ///
    /// Za razliku od [`AtomicBool::compare_exchange`], ovoj funkciji je dopušteno da lažno zakaže čak i kada usporedba uspije, što može rezultirati učinkovitijim kodom na nekim platformama.
    ///
    /// Povratna vrijednost rezultat je koji pokazuje je li nova vrijednost napisana i sadrži li prethodnu vrijednost.
    ///
    /// `compare_exchange_weak` uzima dva [`Ordering`] argumenta za opisivanje redoslijeda memorije ove operacije.
    /// `success` opisuje potrebno naručivanje za operaciju čitanja-izmjene-pisanja koja se odvija ako usporedba s `current` uspije.
    /// `failure` opisuje potrebno naručivanje za rad opterećenja koji se odvija kada usporedba ne uspije.
    /// Korištenje [`Acquire`] kao uspješnog naručivanja čini pohranu dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini uspješno učitavanje [`Relaxed`].
    /// Naručivanje kvara može biti samo [`SeqCst`], [`Acquire`] ili [`Relaxed`] i mora biti jednako ili slabije od narudžbe uspjeha.
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logički "and" s logičkom vrijednošću.
    ///
    /// Izvodi logičku operaciju "and" na trenutnoj vrijednosti i argumentu `val` i postavlja novu vrijednost na rezultat.
    ///
    /// Vraća prethodnu vrijednost.
    ///
    /// `fetch_and` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
    /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
    ///
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logički "nand" s logičkom vrijednošću.
    ///
    /// Izvodi logičku operaciju "nand" na trenutnoj vrijednosti i argumentu `val` i postavlja novu vrijednost na rezultat.
    ///
    /// Vraća prethodnu vrijednost.
    ///
    /// `fetch_nand` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
    /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
    ///
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Ovdje ne možemo koristiti atomic_nand jer to može rezultirati bool s nevaljanom vrijednošću.
        // To se događa jer se atomska operacija interno vrši s 8-bitnim cijelim brojem, koji bi postavio gornjih 7 bitova.
        //
        // Dakle, umjesto toga koristimo samo fetch_xor ili swap.
        if val {
            // ! (x&true)== !x Moramo obrnuti bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Moramo postaviti bool na true.
            //
            self.swap(true, order)
        }
    }

    /// Logički "or" s logičkom vrijednošću.
    ///
    /// Izvodi logičku operaciju "or" na trenutnoj vrijednosti i argumentu `val` i postavlja novu vrijednost na rezultat.
    ///
    /// Vraća prethodnu vrijednost.
    ///
    /// `fetch_or` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
    /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
    ///
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logički "xor" s logičkom vrijednošću.
    ///
    /// Izvodi logičku operaciju "xor" na trenutnoj vrijednosti i argumentu `val` i postavlja novu vrijednost na rezultat.
    ///
    /// Vraća prethodnu vrijednost.
    ///
    /// `fetch_xor` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
    /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
    ///
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Vraća promjenjivi pokazivač na temeljni [`bool`].
    ///
    /// Neatomsko čitanje i pisanje rezultirajućeg cijelog broja može biti podatkovna utrka.
    /// Ova metoda je uglavnom korisna za FFI, gdje potpis funkcije može koristiti `*mut bool` umjesto `&AtomicBool`.
    ///
    /// Vraćanje pokazivača `*mut` iz zajedničke reference na ovaj atom je sigurno jer atomski tipovi rade s unutarnjom promjenjivošću.
    /// Sve modifikacije atoma mijenjaju vrijednost pomoću zajedničke reference i to mogu učiniti sigurno dok koriste atomske operacije.
    /// Svaka upotreba vraćenog sirovog pokazivača zahtijeva `unsafe` blok i još uvijek mora poštovati isto ograničenje: operacije na njemu moraju biti atomske.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Dohvaća vrijednost i na nju primjenjuje funkciju koja vraća neobaveznu novu vrijednost.Vraća `Result` od `Ok(previous_value)` ako je funkcija vratila `Some(_)`, inače `Err(previous_value)`.
    ///
    /// Note: To može pozvati funkciju više puta ako je vrijednost u međuvremenu promijenjena iz ostalih niti, sve dok funkcija vraća `Some(_)`, ali funkcija će biti primijenjena samo jednom na pohranjenu vrijednost.
    ///
    ///
    /// `fetch_update` uzima dva [`Ordering`] argumenta za opisivanje redoslijeda memorije ove operacije.
    /// Prva opisuje traženo naručivanje kada operacija konačno uspije, dok druga opisuje traženo naručivanje tereta.
    /// Oni odgovaraju narudžbi uspjeha i neuspjeha [`AtomicBool::compare_exchange`].
    ///
    /// Korištenje [`Acquire`] kao uspješnog naručivanja čini pohranu dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini konačno uspješno učitavanje [`Relaxed`].
    /// Naručivanje opterećenja (failed) može biti samo [`SeqCst`], [`Acquire`] ili [`Relaxed`] i mora biti jednako ili slabije od narudžbe uspjeha.
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Stvara novi `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Vraća promjenjivu referencu na osnovni pokazivač.
    ///
    /// To je sigurno jer promjenjiva referenca jamči da niti jedna nit istovremeno ne pristupa atomskim podacima.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Dobiti atomski pristup pokazivaču.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - promjenjiva referenca jamči jedinstveno vlasništvo.
        //  - poravnanje `*mut T` i `Self` je isto na svim platformama koje podržava rust, kao što je gore provjereno.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Troši atomsku i vraća sadržanu vrijednost.
    ///
    /// To je sigurno jer prosljeđivanje `self` po vrijednosti jamči da niti jedna nit istovremeno ne pristupa atomskim podacima.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Učitava vrijednost iz pokazivača.
    ///
    /// `load` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.
    /// Moguće vrijednosti su [`SeqCst`], [`Acquire`] i [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ako je `order` [`Release`] ili [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Pohranjuje vrijednost u pokazivač.
    ///
    /// `store` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.
    /// Moguće vrijednosti su [`SeqCst`], [`Release`] i [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ako je `order` [`Acquire`] ili [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Pohranjuje vrijednost u pokazivač, vraćajući prethodnu vrijednost.
    ///
    /// `swap` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
    /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
    ///
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na pokazivače.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Pohranjuje vrijednost u pokazivač ako je trenutna vrijednost jednaka vrijednosti `current`.
    ///
    /// Povratna vrijednost je uvijek prethodna vrijednost.Ako je jednako `current`, tada je vrijednost ažurirana.
    ///
    /// `compare_and_swap` također uzima [`Ordering`] argument koji opisuje redoslijed memorije ove operacije.
    /// Primijetite da čak i kada koristite [`AcqRel`], operacija možda neće uspjeti i stoga samo izvršava `Acquire` učitavanje, ali neće imati `Release` semantiku.
    /// Korištenje [`Acquire`] čini pohranu dijelom ove operacije [`Relaxed`] ako se dogodi, a korištenje [`Release`] čini dio učitavanja [`Relaxed`].
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na pokazivače.
    ///
    /// # Prelazak na `compare_exchange` i `compare_exchange_weak`
    ///
    /// `compare_and_swap` ekvivalentan je `compare_exchange` sa sljedećim mapiranjem za naručivanje memorije:
    ///
    /// Izvornik |Uspjeh |Neuspjeh
    /// -------- | ------- | -------
    /// Opušteno |Opušteno |Opušteno stjecanje |Stjecanje |Otpustite |Izdanje |Opušteno AcqRel |AcqRel |Nabavite SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` dopušteno je da lažno ne uspije čak i kada usporedba uspije, što omogućuje prevoditelju da generira bolji sklopni kod kada se usporedba i zamjena koriste u petlji.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Pohranjuje vrijednost u pokazivač ako je trenutna vrijednost jednaka vrijednosti `current`.
    ///
    /// Povratna vrijednost rezultat je koji pokazuje je li nova vrijednost napisana i sadrži li prethodnu vrijednost.
    /// U uspjehu će ova vrijednost biti zajamčena jednaka `current`.
    ///
    /// `compare_exchange` uzima dva [`Ordering`] argumenta za opisivanje redoslijeda memorije ove operacije.
    /// `success` opisuje potrebno naručivanje za operaciju čitanja-izmjene-pisanja koja se odvija ako usporedba s `current` uspije.
    /// `failure` opisuje potrebno naručivanje za rad opterećenja koji se odvija kada usporedba ne uspije.
    /// Korištenje [`Acquire`] kao uspješnog naručivanja čini pohranu dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini uspješno učitavanje [`Relaxed`].
    ///
    /// Naručivanje kvara može biti samo [`SeqCst`], [`Acquire`] ili [`Relaxed`] i mora biti jednako ili slabije od narudžbe uspjeha.
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na pokazivače.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIGURNOST: atomske značajke sprečavaju utrke podataka.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Pohranjuje vrijednost u pokazivač ako je trenutna vrijednost jednaka vrijednosti `current`.
    ///
    /// Za razliku od [`AtomicPtr::compare_exchange`], ovoj funkciji je dopušteno da lažno zakaže čak i kada usporedba uspije, što može rezultirati učinkovitijim kodom na nekim platformama.
    ///
    /// Povratna vrijednost rezultat je koji pokazuje je li nova vrijednost napisana i sadrži li prethodnu vrijednost.
    ///
    /// `compare_exchange_weak` uzima dva [`Ordering`] argumenta za opisivanje redoslijeda memorije ove operacije.
    /// `success` opisuje potrebno naručivanje za operaciju čitanja-izmjene-pisanja koja se odvija ako usporedba s `current` uspije.
    /// `failure` opisuje potrebno naručivanje za rad opterećenja koji se odvija kada usporedba ne uspije.
    /// Korištenje [`Acquire`] kao uspješnog naručivanja čini pohranu dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini uspješno učitavanje [`Relaxed`].
    /// Naručivanje kvara može biti samo [`SeqCst`], [`Acquire`] ili [`Relaxed`] i mora biti jednako ili slabije od narudžbe uspjeha.
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na pokazivače.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIGURNOST: Ova suštinska osobina nije sigurna jer djeluje na sirovom pokazivaču
        // ali sigurno znamo da je pokazivač valjan (upravo smo ga dobili od `UnsafeCell`-a koji imamo referencom) i sama atomska operacija omogućuje nam sigurnu mutaciju sadržaja `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Dohvaća vrijednost i na nju primjenjuje funkciju koja vraća neobaveznu novu vrijednost.Vraća `Result` od `Ok(previous_value)` ako je funkcija vratila `Some(_)`, inače `Err(previous_value)`.
    ///
    /// Note: To može pozvati funkciju više puta ako je vrijednost u međuvremenu promijenjena iz ostalih niti, sve dok funkcija vraća `Some(_)`, ali funkcija će biti primijenjena samo jednom na pohranjenu vrijednost.
    ///
    ///
    /// `fetch_update` uzima dva [`Ordering`] argumenta za opisivanje redoslijeda memorije ove operacije.
    /// Prva opisuje traženo naručivanje kada operacija konačno uspije, dok druga opisuje traženo naručivanje tereta.
    /// Oni odgovaraju narudžbi uspjeha i neuspjeha [`AtomicPtr::compare_exchange`].
    ///
    /// Korištenje [`Acquire`] kao uspješnog naručivanja čini pohranu dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini konačno uspješno učitavanje [`Relaxed`].
    /// Naručivanje opterećenja (failed) može biti samo [`SeqCst`], [`Acquire`] ili [`Relaxed`] i mora biti jednako ili slabije od narudžbe uspjeha.
    ///
    /// **Note:** Ova je metoda dostupna samo na platformama koje podržavaju atomske operacije na pokazivače.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Pretvara `bool` u `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Ova makronaredba na kraju se ne koristi na nekim arhitekturama.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Cijeli broj koji se može sigurno dijeliti između niti.
        ///
        /// Ovaj tip ima isti prikaz u memoriji kao osnovni cijeli broj, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Za više informacija o razlikama između atomskih i neatomskih tipova, kao i informacije o prenosivosti ovog tipa, pogledajte [module-level documentation].
        ///
        ///
        /// **Note:** Ova vrsta je dostupna samo na platformama koje podržavaju atomska opterećenja i pohrane [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Atomski cijeli broj inicijaliziran u `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Send se implicitno provodi.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Stvara novi atomski cijeli broj.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Vraća promjenjivu referencu na temeljni cijeli broj.
            ///
            /// To je sigurno jer promjenjiva referenca jamči da niti jedna nit istovremeno ne pristupa atomskim podacima.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// neka mut neka_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - promjenjiva referenca jamči jedinstveno vlasništvo.
                //  - poravnanje `$int_type` i `Self` je isto, kao što je obećao $cfg_align i prethodno provjereno.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Troši atomsku i vraća sadržanu vrijednost.
            ///
            /// To je sigurno jer prosljeđivanje `self` po vrijednosti jamči da niti jedna nit istovremeno ne pristupa atomskim podacima.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Učitava vrijednost iz atomskog cijelog broja.
            ///
            /// `load` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.
            /// Moguće vrijednosti su [`SeqCst`], [`Acquire`] i [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ako je `order` [`Release`] ili [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Pohranjuje vrijednost u atomski cijeli broj.
            ///
            /// `store` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.
            ///  Moguće vrijednosti su [`SeqCst`], [`Release`] i [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ako je `order` [`Acquire`] ili [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Pohranjuje vrijednost u atomski cijeli broj, vraćajući prethodnu vrijednost.
            ///
            /// `swap` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
            /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
            ///
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Pohranjuje vrijednost u atomski cijeli broj ako je trenutna vrijednost jednaka vrijednosti `current`.
            ///
            /// Povratna vrijednost je uvijek prethodna vrijednost.Ako je jednako `current`, tada je vrijednost ažurirana.
            ///
            /// `compare_and_swap` također uzima [`Ordering`] argument koji opisuje redoslijed memorije ove operacije.
            /// Primijetite da čak i kada koristite [`AcqRel`], operacija možda neće uspjeti i stoga samo izvršava `Acquire` učitavanje, ali neće imati `Release` semantiku.
            ///
            /// Korištenje [`Acquire`] čini pohranu dijelom ove operacije [`Relaxed`] ako se dogodi, a korištenje [`Release`] čini dio učitavanja [`Relaxed`].
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Prelazak na `compare_exchange` i `compare_exchange_weak`
            ///
            /// `compare_and_swap` ekvivalentan je `compare_exchange` sa sljedećim mapiranjem za naručivanje memorije:
            ///
            /// Izvornik |Uspjeh |Neuspjeh
            /// -------- | ------- | -------
            /// Opušteno |Opušteno |Opušteno stjecanje |Stjecanje |Otpustite |Izdanje |Opušteno AcqRel |AcqRel |Nabavite SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` dopušteno je da lažno ne uspije čak i kada usporedba uspije, što omogućuje prevoditelju da generira bolji sklopni kod kada se usporedba i zamjena koriste u petlji.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Pohranjuje vrijednost u atomski cijeli broj ako je trenutna vrijednost jednaka vrijednosti `current`.
            ///
            /// Povratna vrijednost rezultat je koji pokazuje je li nova vrijednost napisana i sadrži li prethodnu vrijednost.
            /// U uspjehu će ova vrijednost biti zajamčena jednaka `current`.
            ///
            /// `compare_exchange` uzima dva [`Ordering`] argumenta za opisivanje redoslijeda memorije ove operacije.
            /// `success` opisuje potrebno naručivanje za operaciju čitanja-izmjene-pisanja koja se odvija ako usporedba s `current` uspije.
            /// `failure` opisuje potrebno naručivanje za rad opterećenja koji se odvija kada usporedba ne uspije.
            /// Korištenje [`Acquire`] kao uspješnog naručivanja čini pohranu dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini uspješno učitavanje [`Relaxed`].
            ///
            /// Naručivanje kvara može biti samo [`SeqCst`], [`Acquire`] ili [`Relaxed`] i mora biti jednako ili slabije od narudžbe uspjeha.
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Pohranjuje vrijednost u atomski cijeli broj ako je trenutna vrijednost jednaka vrijednosti `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ova funkcija smije lažno zakazati čak i kada usporedba uspije, što može rezultirati učinkovitijim kodom na nekim platformama.
            /// Povratna vrijednost rezultat je koji pokazuje je li nova vrijednost napisana i sadrži li prethodnu vrijednost.
            ///
            /// `compare_exchange_weak` uzima dva [`Ordering`] argumenta za opisivanje redoslijeda memorije ove operacije.
            /// `success` opisuje potrebno naručivanje za operaciju čitanja-izmjene-pisanja koja se odvija ako usporedba s `current` uspije.
            /// `failure` opisuje potrebno naručivanje za rad opterećenja koji se odvija kada usporedba ne uspije.
            /// Korištenje [`Acquire`] kao uspješnog naručivanja čini pohranu dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini uspješno učitavanje [`Relaxed`].
            ///
            /// Naručivanje kvara može biti samo [`SeqCst`], [`Acquire`] ili [`Relaxed`] i mora biti jednako ili slabije od narudžbe uspjeha.
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// neka mut stari= val.load(Ordering::Relaxed);
            /// petlja {neka nova=stara * 2;
            ///     podudaranje val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Dodaje trenutnoj vrijednosti vraćajući prethodnu vrijednost.
            ///
            /// Ova se operacija obavija pri prelijevanju.
            ///
            /// `fetch_add` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
            /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
            ///
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Oduzima trenutnu vrijednost, vraća prethodnu vrijednost.
            ///
            /// Ova se operacija obavija pri prelijevanju.
            ///
            /// `fetch_sub` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
            /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
            ///
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitno "and" s trenutnom vrijednošću.
            ///
            /// Izvodi bitovnu operaciju "and" na trenutnoj vrijednosti i argumentu `val` i postavlja novu vrijednost na rezultat.
            ///
            /// Vraća prethodnu vrijednost.
            ///
            /// `fetch_and` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
            /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
            ///
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitno "nand" s trenutnom vrijednošću.
            ///
            /// Izvodi bitovnu operaciju "nand" na trenutnoj vrijednosti i argumentu `val` i postavlja novu vrijednost na rezultat.
            ///
            /// Vraća prethodnu vrijednost.
            ///
            /// `fetch_nand` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
            /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
            ///
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13 i 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitno "or" s trenutnom vrijednošću.
            ///
            /// Izvodi bitovnu operaciju "or" na trenutnoj vrijednosti i argumentu `val` i postavlja novu vrijednost na rezultat.
            ///
            /// Vraća prethodnu vrijednost.
            ///
            /// `fetch_or` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
            /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
            ///
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitno "xor" s trenutnom vrijednošću.
            ///
            /// Izvodi bitovnu operaciju "xor" na trenutnoj vrijednosti i argumentu `val` i postavlja novu vrijednost na rezultat.
            ///
            /// Vraća prethodnu vrijednost.
            ///
            /// `fetch_xor` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
            /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
            ///
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Dohvaća vrijednost i na nju primjenjuje funkciju koja vraća neobaveznu novu vrijednost.Vraća `Result` od `Ok(previous_value)` ako je funkcija vratila `Some(_)`, inače `Err(previous_value)`.
            ///
            /// Note: To može pozvati funkciju više puta ako je vrijednost u međuvremenu promijenjena iz ostalih niti, sve dok funkcija vraća `Some(_)`, ali funkcija će biti primijenjena samo jednom na pohranjenu vrijednost.
            ///
            ///
            /// `fetch_update` uzima dva [`Ordering`] argumenta za opisivanje redoslijeda memorije ove operacije.
            /// Prva opisuje traženo naručivanje kada operacija konačno uspije, dok druga opisuje traženo naručivanje tereta.Oni odgovaraju naredbama za uspjeh i neuspjeh
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Korištenje [`Acquire`] kao uspješnog naručivanja čini pohranu dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini konačno uspješno učitavanje [`Relaxed`].
            /// Naručivanje opterećenja (failed) može biti samo [`SeqCst`], [`Acquire`] ili [`Relaxed`] i mora biti jednako ili slabije od narudžbe uspjeha.
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Poredak: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Poredak: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maksimalno s trenutnom vrijednošću.
            ///
            /// Pronalazi maksimum trenutne vrijednosti i argumenta `val` i postavlja novu vrijednost na rezultat.
            ///
            /// Vraća prethodnu vrijednost.
            ///
            /// `fetch_max` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
            /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
            ///
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// neka traka=42;
            /// neka max_foo=foo.fetch_max (traka, Ordering::SeqCst).max(bar);
            /// tvrditi! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimalno s trenutnom vrijednošću.
            ///
            /// Pronalazi minimum trenutne vrijednosti i argumenta `val` i postavlja novu vrijednost rezultatu.
            ///
            /// Vraća prethodnu vrijednost.
            ///
            /// `fetch_min` uzima argument [`Ordering`] koji opisuje redoslijed memorije ove operacije.Mogući su svi načini naručivanja.
            /// Imajte na umu da korištenje [`Acquire`] čini spremište dijelom ove operacije [`Relaxed`], a korištenje [`Release`] čini utovarni dio [`Relaxed`].
            ///
            ///
            /// **Napomena**: Ova metoda je dostupna samo na platformama koje podržavaju atomske operacije na
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// neka traka=12;
            /// neka min_foo=foo.fetch_min (traka, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURNOST: atomske značajke sprečavaju utrke podataka.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Vraća promjenjivi pokazivač na temeljni cijeli broj.
            ///
            /// Neatomsko čitanje i pisanje rezultirajućeg cijelog broja može biti podatkovna utrka.
            /// Ova metoda je uglavnom korisna za FFI, gdje se može koristiti potpis funkcije
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Vraćanje pokazivača `*mut` iz zajedničke reference na ovaj atom je sigurno jer atomski tipovi rade s unutarnjom promjenjivošću.
            /// Sve modifikacije atoma mijenjaju vrijednost pomoću zajedničke reference i to mogu učiniti sigurno dok koriste atomske operacije.
            /// Svaka upotreba vraćenog sirovog pokazivača zahtijeva `unsafe` blok i još uvijek mora poštovati isto ograničenje: operacije na njemu moraju biti atomske.
            ///
            ///
            /// # Examples
            ///
            /// `` `zanemari (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// vanjski "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SIGURNOST: Sigurno sve dok je `my_atomic_op` atomski.
            /// nesigurno {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Vraća prethodnu vrijednost (poput __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Vraća prethodnu vrijednost (poput __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// vraća maksimalnu vrijednost (potpisana usporedba)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// vraća minimalnu vrijednost (potpisana usporedba)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// vraća maksimalnu vrijednost (nepotpisana usporedba)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// vraća minimalnu vrijednost (nepotpisana usporedba)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atomska ograda.
///
/// Ovisno o navedenom redoslijedu, ograda sprečava kompajler i CPU da preuređuju određene vrste memorijskih operacija oko sebe.
/// To stvara sinkronizaciju-s odnosima između njega i atomskih operacija ili ograda u drugim nitima.
///
/// Ograda 'A' koja ima (barem) [`Release`] poredak semantike, sinkronizira se s ogradom 'B' s (najmanje) [`Acquire`] semantikom, ako i samo ako postoje operacije X i Y, obje koje rade na nekom atomskom objektu 'M', tako da je A sekvencirano prije X, Y se sinkronizira prije nego što B i Y primijete promjenu u M.
/// To osigurava ovisnost između A i B. koja se dogodi prije.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomske operacije sa semantikom [`Release`] ili [`Acquire`] također se mogu sinkronizirati s ogradom.
///
/// Ograda koja ima [`SeqCst`] poredak, osim što ima i [`Acquire`] i [`Release`] semantiku, sudjeluje u globalnom programskom redoslijedu ostalih operacija i/ili ograda [`SeqCst`].
///
/// Prihvaća narudžbe [`Acquire`], [`Release`], [`AcqRel`] i [`SeqCst`].
///
/// # Panics
///
/// Panics ako je `order` [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Primitiv uzajamnog isključivanja zasnovan na spinlocku.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Pričekajte dok stara vrijednost ne postane `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Ova se ograda sinkronizira s trgovinom u `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SIGURNOST: korištenje atomske ograde je sigurno.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Ograda memorije kompajlera.
///
/// `compiler_fence` ne emitira nikakav strojni kôd, ali ograničava vrste prekomjernog redoslijeda memorije što je dopušteno prevoditelju.Točnije, ovisno o datoj semantici [`Ordering`], kompajleru se može zabraniti premještanje čitanja ili pisanja prije ili nakon poziva na drugu stranu poziva na `compiler_fence`.Imajte na umu da **ne** sprječava *hardver* da izvrši takvo ponovno naručivanje.
///
/// To nije problem u kontekstu izvođenja s jednim niti, ali kad druge niti mogu istodobno mijenjati memoriju, potrebni su jači primitivi za sinkronizaciju kao što je [`fence`].
///
/// Preuređivanje koje sprječavaju različite semantike poredavanja su:
///
///  - s [`SeqCst`] nije dopušteno preuređivanje čitanja i pisanja preko ove točke.
///  - s [`Release`], prethodna čitanja i upisivanja ne mogu se premjestiti prošla sljedeća upisivanja.
///  - kod [`Acquire`], sljedeća čitanja i upisivanja ne mogu se pomicati ispred prethodnih čitanja.
///  - s [`AcqRel`], provode se oba gore navedena pravila.
///
/// `compiler_fence` je općenito korisno samo za sprečavanje niti da se utrkuje *sa sobom*.To jest, ako zadana nit izvršava jedan dio koda, a zatim se prekida i započinje izvršavanje koda negdje drugdje (dok je još uvijek u istoj niti, a konceptualno još uvijek na istoj jezgri).U tradicionalnim programima to se može dogoditi samo kada je registriran obrađivač signala.
/// U kodu niže razine takve se situacije mogu pojaviti i prilikom rukovanja prekidima, kod implementacije zelenih niti s predujmom itd.
/// Znatiželjni čitatelji potiču se da pročitaju raspravu o [memory barriers] jezgru Linux.
///
/// # Panics
///
/// Panics ako je `order` [`Relaxed`].
///
/// # Examples
///
/// Bez `compiler_fence`, `assert_eq!` u sljedećem kodu *ne* jamči uspjeh, unatoč svemu što se događa u jednoj niti.
/// Da biste vidjeli zašto, sjetite se da je prevoditelj slobodan zamijeniti trgovine na `IMPORTANT_VARIABLE` i `IS_READ`, jer su obje `Ordering::Relaxed`.Ako se dogodi, a obrađivač signala se poziva odmah nakon ažuriranja `IS_READY`, tada će obrađivač signala vidjeti `IS_READY=1`, ali `IMPORTANT_VARIABLE=0`.
/// Korištenje `compiler_fence` rješava ovu situaciju.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // spriječiti pomicanje ranijih zapisa izvan ove točke
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SIGURNOST: korištenje atomske ograde je sigurno.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signalizira procesor da je unutar spin-loop-a zauzetog čekanja ("spin lock").
///
/// Ova je funkcija zastarjela u korist [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}