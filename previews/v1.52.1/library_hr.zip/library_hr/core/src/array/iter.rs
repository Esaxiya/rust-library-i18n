//! Definira iterator za nizove u vlasništvu `IntoIter`.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Vrijednosni iterator [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ovo je niz preko kojeg ponavljamo.
    ///
    /// Elementi s indeksom `i` gdje `alive.start <= i < alive.end` još nisu uneseni i važeći su unosi polja.
    /// Elementi s indeksima `i < alive.start` ili `i >= alive.end` već su dati i više im se ne smije pristupiti!Ti mrtvi elementi mogli bi biti čak i u potpuno neinicijaliziranom stanju!
    ///
    ///
    /// Dakle, invarijante su:
    /// - `data[alive]` je živ (tj. sadrži valjane elemente)
    /// - `data[..alive.start]` i `data[alive.end..]` su mrtvi (tj. elementi su već pročitani i više ih se ne smije dirati!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Elementi u `data` koji još nisu ustupljeni.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Stvara novi iterator nad danim `array`.
    ///
    /// *Napomena*: ova metoda možda će biti zastarjela u future, nakon [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Tip `value` ovdje je `i32`, umjesto `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SIGURNOST: Ovdje je transmuta zapravo siguran.Dokumenti `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` zajamčena je jednaka veličina i poravnanje
        // > kao `T`.
        //
        // Dokumenti čak prikazuju transmutiranje iz niza `MaybeUninit<T>` u niz `T`.
        //
        //
        // Uz to, ova inicijalizacija zadovoljava invarijante.

        // FIXME(LukasKalbertodt): zapravo upotrijebite `mem::transmute` ovdje, nakon što uspije s const genericima:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Do tada, možemo koristiti `mem::transmute_copy` za stvaranje bitne kopije kao drugi tip, a zatim zaboraviti `array` kako ne bi bio ispušten.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Vraća nepromjenjivi dio svih elemenata koji još nisu ustupljeni.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SIGURNOST: Znamo da su svi elementi unutar `alive` pravilno inicijalizirani.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Vraća promjenjivu krišku svih elemenata koji još nisu ustupljeni.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SIGURNOST: Znamo da su svi elementi unutar `alive` pravilno inicijalizirani.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Uzmite sljedeći indeks s prednje strane.
        //
        // Povećanje `alive.start` za 1 zadržava invarijantu u odnosu na `alive`.
        // Međutim, zbog ove promjene, na kratko vrijeme, zona živih više nije `data[alive]`, već `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Pročitajte element iz niza.
            // SIGURNOST: `idx` je indeks nekadašnje "alive" regije
            // niz.Čitanje ovog elementa znači da se `data[idx]` sada smatra mrtvim (tj. Ne dodirujte).
            // Kako je `idx` bio početak žive zone, živa zona sada je opet `data[alive]`, obnavljajući sve invarijante.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Uzmi sljedeći indeks s leđa.
        //
        // Smanjivanje `alive.end` za 1 zadržava invarijantu u odnosu na `alive`.
        // Međutim, zbog ove promjene, na kratko vrijeme, zona živih više nije `data[alive]`, već `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Pročitajte element iz niza.
            // SIGURNOST: `idx` je indeks nekadašnje "alive" regije
            // niz.Čitanje ovog elementa znači da se `data[idx]` sada smatra mrtvim (tj. Ne dodirujte).
            // Kako je `idx` bio kraj žive zone, živa zona sada je opet `data[alive]`, obnavljajući sve invarijante.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SIGURNOST: Ovo je sigurno: `as_mut_slice` vraća točno podrezak
        // elemenata koji još nisu pomaknuti i koji će se još ispustiti.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nikad se neće prelijevati zbog nepromjenjivog `live.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterator doista prijavljuje točnu duljinu.
// Broj "alive" elemenata (koji će se i dalje dobiti) duljina je raspona `alive`.
// Duljina ovog raspona smanjuje se u `next` ili `next_back`.
// U tim se metodama uvijek smanjuje s 1, ali samo ako se vrati `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Imajte na umu da zapravo ne trebamo podudarati točno isti raspon živih, tako da možemo samo klonirati u pomak 0 bez obzira gdje se nalazi `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonirajte sve žive elemente.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Napišite klon u novi niz, a zatim ažurirajte njegov živi raspon.
            // Ako kloniramo panics, ispravno ćemo ispustiti prethodne stavke.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ispisujte samo elemente koji još nisu ustupljeni: ustupljenim elementima više ne možemo pristupiti.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}