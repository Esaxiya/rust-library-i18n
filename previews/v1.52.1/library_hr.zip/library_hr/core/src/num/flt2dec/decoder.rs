//! Dekodira vrijednost s pomičnom zarezom u pojedinačne dijelove i područja pogrešaka.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekodirana nepotpisana konačna vrijednost, takva da:
///
/// - Izvorna vrijednost jednaka je `mant * 2^exp`.
///
/// - Bilo koji broj od `(mant - minus)*2^exp` do `(mant + plus)* 2^exp` zaokružit će se na izvornu vrijednost.
/// Raspon uključuje samo kada je `inclusive` `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Izmjerena mantisa.
    pub mant: u64,
    /// Donji raspon pogrešaka.
    pub minus: u64,
    /// Gornji raspon pogrešaka.
    pub plus: u64,
    /// Podijeljeni eksponent u bazi 2.
    pub exp: i16,
    /// Tačno kada je obuhvaćen raspon pogrešaka.
    ///
    /// U IEEE 754 to je istina kad je izvorna mantisa bila parna.
    pub inclusive: bool,
}

/// Dekodirana nepotpisana vrijednost.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Beskonačnosti, bilo pozitivne bilo negativne.
    Infinite,
    /// Nula, bilo pozitivna ili negativna.
    Zero,
    /// Konačni brojevi s daljnjim dekodiranim poljima.
    Finite(Decoded),
}

/// Tip s pomičnom zarezom koji se može `dekodirati`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimalna pozitivna normalizirana vrijednost.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Vraća znak (tačno kada je negativno) i vrijednost `FullDecoded` iz zadanog broja s pomičnom zarezom.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // susjedi: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode uvijek čuva eksponent, pa se mantisa skalira za subnormale.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // susjedi: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // gdje je maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // susjedi: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}