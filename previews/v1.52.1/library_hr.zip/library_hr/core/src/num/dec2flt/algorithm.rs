//! Različiti algoritmi iz rada.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Broj značajnih i bitova u Fp
const P: u32 = 64;

// Jednostavno pohranjujemo najbolju aproksimaciju za *sve* eksponente, tako da varijabla "h" i pridruženi uvjeti mogu biti izostavljeni.
// Ovo mijenja performanse za nekoliko kilobajta prostora.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// U većini arhitektura operacije s pomičnim zarezom imaju eksplicitnu bitnu veličinu, stoga se preciznost izračuna određuje na osnovi operacije.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Na x86, x87 FPU koristi se za plutajuće operacije ako proširenja SSE/SSE2 nisu dostupna.
// x87 FPU prema zadanim postavkama radi s preciznošću od 80 bitova, što znači da će se operacije zaokružiti na 80 bita, što dovodi do dvostrukog zaokruživanja kada se vrijednosti na kraju prikažu kao
//
// 32/64 bit float vrijednosti.Da bi se to prevladalo, FPU upravljačka riječ može se postaviti tako da se proračuni izvode u željenoj preciznosti.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struktura koja se koristi za očuvanje izvorne vrijednosti FPU kontrolne riječi, tako da se može obnoviti kad se struktura ispusti.
    ///
    ///
    /// x87 FPU je 16-bitni registar čija su polja sljedeća:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentacija za sva polja dostupna je u Priručniku za razvoj softverskog softvera IA-32 (svezak 1.).
    ///
    /// Jedino polje koje je relevantno za sljedeći kod je PC, Precision Control.
    /// Ovo polje određuje preciznost operacija koje izvodi FPU.
    /// Može se postaviti na:
    ///  - 0b00, jednostruka preciznost, tj. 32 bita
    ///  - 0b10, dvostruka preciznost, tj., 64 bita
    ///  - 0b11, dvostruko proširena preciznost, tj. 80-bit (zadano stanje) Vrijednost 0b01 je rezervirana i ne smije se koristiti.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SIGURNOST: `fldcw` uputa je revidirana kako bi mogla ispravno raditi s njom
        // bilo koji `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Koristimo ATT sintaksu za podršku LLVM 8 i LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Postavlja polje preciznosti FPU-a na `T` i vraća `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Izračunajte vrijednost za polje Precision Control koja odgovara `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bita
            8 => 0x0200, // 64 bita
            _ => 0x0300, // zadano, 80 bita
        };

        // Nabavite izvornu vrijednost kontrolne riječi da biste je kasnije obnovili, kada `FPUControlWord` struktura padne SIGURNOST: `fnstcw` instrukcija je revidirana kako bi mogla ispravno raditi s bilo kojim `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Koristimo ATT sintaksu za podršku LLVM 8 i LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Postavite kontrolnu riječ na željenu preciznost.
        // To se postiže maskiranjem stare preciznosti (bitovi 8 i 9, 0x300) i zamjenom s prethodno izračunatom zastavicom preciznosti.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Brzi put Bellerophona koristeći cijele brojeve i plutajuće strojeve.
///
/// To se izdvaja u zasebnu funkciju tako da se može pokušati prije konstrukcije bignuma.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Točnu vrijednost uspoređujemo s MAX_SIG pri kraju, ovo je samo brzo, jeftino odbijanje (i također oslobađa ostatak koda od brige zbog nedovoljnog protoka).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Brzi put presudno ovisi o tome da se aritmetika zaokruži na točan broj bitova bez ikakvog međuzaokruživanja.
    // Na x86 (bez SSE ili SSE2) to zahtijeva promjenu preciznosti x87 FPU stoga tako da se izravno zaokružuje na bit 64/32.
    // Funkcija `set_precision` brine se o podešavanju preciznosti na arhitekturama koje je zahtijevaju postavljanjem promjenom globalnog stanja (poput kontrolne riječi x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Slučaj e <0 ne može se preklopiti u drugi branch.
    // Negativne moći rezultiraju ponavljanjem frakcijskog dijela u binarnom sustavu, koji je zaokružen, što uzrokuje stvarne (i povremeno prilično značajne!) Pogreške u konačnom rezultatu.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritam Bellerophon trivijalni je kod opravdan ne-trivijalnom numeričkom analizom.
///
/// Zaokružuje ``f`` do plutajućeg slova sa 64-bitnim značenjem i množi ga najboljom aproksimacijom `10^e` (u istom formatu s pomičnom zarezom).To je često dovoljno za dobivanje točnog rezultata.
/// Međutim, kada je rezultat blizu pola između dva susjedna plutajuća (ordinary), pogreška zaokruživanja složenog množenja dvije aproksimacije znači da se rezultat može isključiti za nekoliko bitova.
/// Kada se to dogodi, iterativni algoritam R popravlja stvari.
///
/// Numeričkom analizom u radu precizan je ručno valoviti "close to halfway".
/// Riječima Clingera:
///
/// > Nagib, izražen u jedinicama najmanje značajnog bita, uključiva je granica pogreške
/// > nakupljena tijekom izračuna plutajuće točke aproksimacije na f * 10 ^ e.(Slop je
/// > nije granica za istinsku pogrešku, ali ograničava razliku između aproksimacije z i
/// > najbolja moguća aproksimacija koja koristi p bitova značenja.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Slučajevi abs(e) <log5(2^N) nalaze se u fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Je li nagib dovoljno velik da napravi razliku prilikom zaokruživanja na n bitova?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Iterativni algoritam koji poboljšava približavanje `f * 10^e` s pomičnim zarezom.
///
/// Svaka iteracija približi jednu jedinicu na posljednjem mjestu, što naravno traje užasno dugo da se konvergira ako je `z0` čak i blago isključen.
/// Srećom, kada se koristi kao zamjenski za Bellerophon, početno približavanje isključuje najviše jedan ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Pronađite pozitivne cijele brojeve `x`, `y` takve da je `x / y` točno `(f *10^e) / (m* 2^k)`.
        // Ovo ne samo da izbjegava bavljenje znakovima `e` i `k`, već eliminiramo snagu dvaju zajedničkih `10^e` i `2^k` kako bismo brojeve učinili manjim.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Ovo je napisano pomalo nespretno jer naši bignumi ne podržavaju negativne brojeve, pa koristimo podatke o apsolutnoj vrijednosti + znaku.
        // Množenje s m_digits ne može se preliti.
        // Ako su `x` ili `y` dovoljno veliki da se moramo brinuti zbog prelijevanja, tada su i dovoljno veliki da je `make_ratio` udio smanjio za faktor 2 ^ 64 ili više.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Ne treba vam više x, spremite clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Ipak trebate, napravite kopiju.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// S obzirom na `x = f` i `y = m` gdje `f` predstavljaju ulazne decimalne znamenke kao i obično, a `m` je značaj aproksimacije s pomičnim zarezom, učinite omjer `x / y` jednakim `(f *10^e) / (m* 2^k)`, možda umanjenom za snagu dviju zajedničkih.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, osim što ulomak smanjimo za neku snagu dvojke.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m To se ne može prelijevati, jer zahtijeva pozitivne `e` i negativne `k`, što se može dogoditi samo za vrijednosti izuzetno blizu 1, što znači da će `e` i `k` biti relativno maleni.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ni ovo se ne može preliti, vidi gore.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), opet smanjujući zajedničkom snagom dvojke.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konceptualno, Algoritam M je najjednostavniji način pretvaranja decimalnog u float.
///
/// Formiramo omjer koji je jednak `f * 10^e`, a zatim ubacujemo snage dvojke dok ne dobije valjani plutajući značaj.
/// Binarni eksponent `k` je koliko smo puta pomnožili brojnik ili nazivnik s dva, tj. U svakom trenutku `f *10^e` je jednako `(u / v)* 2^k`.
/// Kad otkrijemo značajno, trebamo zaokružiti samo pregledavanjem ostatka podjele, što je učinjeno u pomoćnim funkcijama dalje u nastavku.
///
///
/// Ovaj algoritam je super spor, čak i uz optimizaciju opisanu u `quick_start()`.
/// Međutim, to je najjednostavniji algoritam za prilagodbu rezultatima preljeva, preljeva i subnormalnih.
/// Ova implementacija preuzima kada su Bellerophon i Algorithm R preplavljeni.
/// Otkrivanje preljeva i preljeva je jednostavno: omjer još uvijek nije značajan u dometu, no postignut je minimum/maximum eksponent.
/// U slučaju prelijevanja, jednostavno vraćamo beskonačnost.
///
/// Rukovanje podtokom i subnormama je složenije.
/// Veliki je problem što bi, s minimalnim eksponentom, omjer i dalje mogao biti prevelik za značenje.
/// Za detalje pogledajte underflow().
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME moguća optimizacija: generalizirajte big_to_fp tako da ovdje možemo napraviti ekvivalent fp_to_float(big_to_fp(u)), samo bez dvostrukog zaokruživanja.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Moramo se zaustaviti na minimalnom eksponentu, ako pričekamo do `k < T::MIN_EXP_INT`, tada ćemo biti faktor dva.
            // Nažalost, to znači da moramo koristiti normalne brojeve s minimalnim eksponentom.
            // FIXME pronađi elegantniju formulaciju, ali pokrenite `tiny-pow10` test kako biste se uvjerili da je to točno!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Preskače većinu iteracija algoritma M provjerom duljine bita.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Duljina bita je procjena osnovnog dva logaritma i log(u / v) = log(u), log(v).
    // Procjena je isključena za najviše 1, ali uvijek je premala, pa je pogreška na log(u) i log(v) istog znaka i poništava se (ako su obje velike).
    // Stoga je i pogreška za log(u / v) najviše jedna.
    // Ciljani omjer je onaj gdje je u/v u značenju unutar dosega.Stoga je naš uvjet završetka log2(u / v) kao bitni i bit, a plus/minus jedan.
    // FIXME Pogled na drugi bit mogao bi poboljšati procjenu i izbjeći još neke podjele.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Podliv ili subnormalan.Prepustite glavnoj funkciji.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Prelijevanje.Prepustite glavnoj funkciji.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Omjer nije značajka u dosegu s minimalnim eksponentom, stoga moramo zaokružiti višak bitova i prilagoditi eksponent u skladu s tim.
    // Prava vrijednost sada izgleda ovako:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(zastupa rem)
    //
    // Stoga, kada su zaobljeni bitovi!= 0.5 ULP, oni sami odlučuju o zaokruživanju.
    // Kada su jednaki, a ostatak nije nula, vrijednost još treba zaokružiti.
    // Tek kada su zaokruženi bitovi 1/2, a ostatak je nula, imamo situaciju od pola do čak.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Uobičajeni zaokruženi do parni, zamračeni zaokruživanjem na temelju ostatka podjele.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}