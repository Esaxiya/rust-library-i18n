use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Vrsta omota za konstrukciju neinicijaliziranih primjeraka `T`.
///
/// # Invarijanta inicijalizacije
///
/// Kompajler, općenito, pretpostavlja da je varijabla pravilno inicijalizirana u skladu sa zahtjevima tipa varijable.Na primjer, varijabla referentnog tipa mora biti poravnana i ne-NULL.
/// Ovo je invarijant koji se mora *uvijek* podržavati, čak i u nesigurnom kodu.
/// Kao posljedica toga, nulta inicijalizacija varijable referentnog tipa uzrokuje trenutni [undefined behavior][ub], bez obzira na to koristi li se ta referenca za pristup memoriji:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // nedefinirano ponašanje!⚠️
/// // Ekvivalentni kod s `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // nedefinirano ponašanje!⚠️
/// ```
///
/// Kompajler to koristi za razne optimizacije, poput uklanjanja provjera vremena izvođenja i optimizacije izgleda `enum`.
///
/// Slično tome, potpuno neinicijalizirana memorija može imati bilo kakav sadržaj, dok `bool` uvijek mora biti `true` ili `false`.Stoga je stvaranje neinicijaliziranog `bool` nedefinirano ponašanje:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // nedefinirano ponašanje!⚠️
/// // Ekvivalentni kod s `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinirano ponašanje!⚠️
/// ```
///
/// Štoviše, neinicijalizirana memorija posebna je po tome što nema fiksnu vrijednost ("fixed" što znači "it won't change without being written to").Čitanje istog neinicijaliziranog bajta više puta može dati različite rezultate.
/// To čini nedefinirano ponašanje neinicijaliziranim podacima u varijabli, čak i ako ta varijabla ima cijeli broj, koji inače može sadržavati bilo koji *fiksni* bitni uzorak:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // nedefinirano ponašanje!⚠️
/// // Ekvivalentni kod s `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinirano ponašanje!⚠️
/// ```
/// (Primijetite da pravila oko neinicijaliziranih cijelih brojeva još nisu finalizirana, ali dok nisu, poželjno ih je izbjegavati.)
///
/// Povrh toga, imajte na umu da većina tipova ima dodatne invarijante osim što se smatraju samo inicijaliziranima na razini tipa.
/// Na primjer, `1` inicijalizirani [`Vec<T>`] smatra se inicijaliziranim (prema trenutnoj implementaciji; to ne predstavlja stabilno jamstvo), jer je jedini preduvjet koji kompajler zna o tome da pokazivač podataka mora biti ne-null.
/// Stvaranje takvog `Vec<T>` ne uzrokuje *trenutno* nedefinirano ponašanje, ali će uzrokovati nedefinirano ponašanje kod većine sigurnih operacija (uključujući ispuštanje).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` služi za omogućavanje nesigurnog koda za rad s neinicijaliziranim podacima.
/// To je signal kompajleru koji ukazuje na to da ovdje navedeni podaci * možda neće biti inicijalizirani:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Stvorite eksplicitno neinicijaliziranu referencu.
/// // Prevoditelj zna da podaci unutar `MaybeUninit<T>` mogu biti nevaljani, pa stoga ovo nije UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Postavite je na valjanu vrijednost.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Izdvojite inicijalizirane podatke-to je dopušteno *samo nakon* pravilne inicijalizacije `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Kompajler tada zna da na ovom kodu ne donosi neispravne pretpostavke ili optimizacije.
///
/// Možete smatrati da je `MaybeUninit<T>` pomalo sličan `Option<T>`, ali bez ikakvog praćenja vremena izvođenja i bez ikakvih sigurnosnih provjera.
///
/// ## out-pointers
///
/// Možete koristiti `MaybeUninit<T>` za implementaciju "out-pointers": umjesto vraćanja podataka iz funkcije, dodajte joj pokazivač na neku memoriju (uninitialized) u koji ćete staviti rezultat.
/// To može biti korisno kada je pozivatelju važno kontrolirati kako se memorija u kojoj se pohranjuje rezultat dodjeljuje i ako želite izbjeći nepotrebne poteze.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ne ispušta stari sadržaj, što je važno.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Sada znamo da je `v` inicijaliziran!Ovo također osigurava da vector pravilno padne.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicijalizacija niza element po element
///
/// `MaybeUninit<T>` može se koristiti za inicijalizaciju velikog polja element po element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Stvorite neinicijalizirani niz `MaybeUninit`.
///     // `assume_init` je siguran jer je tip za koji tvrdimo da je ovdje inicijaliziran gomila `MoždaUninita`, koji ne zahtijevaju inicijalizaciju.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Ispuštanje `MaybeUninit` ne znači ništa.
///     // Stoga upotreba sirove dodjele pokazivača umjesto `ptr::write` ne dovodi do odbacivanja stare neinicijalizirane vrijednosti.
/////
///     // Također, ako tijekom ove petlje postoji panic, imamo curenje memorije, ali nema problema sa sigurnošću memorije.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Sve je inicijalizirano.
///     // Transmutiraj niz u inicijalizirani tip.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Također možete raditi s djelomično inicijaliziranim nizovima, koji se mogu naći u niskorazinskim podatkovnim strukturama.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Stvorite neinicijalizirani niz `MaybeUninit`.
/// // `assume_init` je siguran jer je tip za koji tvrdimo da je ovdje inicijaliziran gomila `MoždaUninita`, koji ne zahtijevaju inicijalizaciju.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Prebrojite broj elemenata koje smo dodijelili.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Za svaku stavku u polju ispustite ako smo je dodijelili.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicijalizacija strukture polje po polje
///
/// Možete koristiti `MaybeUninit<T>` i makronaredbu [`std::ptr::addr_of_mut`] za inicijalizaciju struktura polje po polje:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicijalizacija polja `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicijalizacija `list` polja Ako ovdje postoji panic, tada `String` u polju `name` curi.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Sva su polja inicijalizirana, pa pozivamo `assume_init` da dobijemo inicijalizirani Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` zajamčeno je da imaju istu veličinu, poravnanje i ABI kao `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Međutim, imajte na umu da tip *koji sadrži*`MaybeUninit<T>` nije nužno istog izgleda;Rust općenito ne garantira da polja `Foo<T>` imaju isti redoslijed kao `Foo<U>`, čak i ako `T` i `U` imaju jednaku veličinu i poravnanje.
///
/// Nadalje, jer bilo koja vrijednost bita vrijedi za `MaybeUninit<T>`, kompajler ne može primijeniti non-zero/niche-filling optimizacije, što bi potencijalno moglo rezultirati većom veličinom:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ako je `T` siguran za FFI, onda je i `MaybeUninit<T>`.
///
/// Iako je `MaybeUninit` `#[repr(transparent)]` (što znači da jamči istu veličinu, poravnanje i ABI kao `T`), to *ne* mijenja niti jedno od prethodnih upozorenja.
/// `Option<T>` i `Option<MaybeUninit<T>>` i dalje mogu imati različite veličine, a tipovi koji sadrže polje tipa `T` mogu se rasporediti (i veličine) drugačije nego da je to polje `MaybeUninit<T>`.
/// `MaybeUninit` je tip sindikata, a `#[repr(transparent)]` na sindikatima je nestabilan (vidi [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Vremenom se mogu razvijati točna jamstva `#[repr(transparent)]` za sindikate, a `MaybeUninit` može ili ne mora ostati `#[repr(transparent)]`.
/// Ipak, `MaybeUninit<T>` će *uvijek* jamčiti da ima jednaku veličinu, poravnanje i ABI kao `T`;samo se način na koji `MaybeUninit` implementira to jamstvo može razvijati.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Predmet jezika kako bismo u njega mogli umotati druge vrste.Ovo je korisno za generatore.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ne pozivajući `T::clone()`, ne možemo znati jesmo li dovoljno inicijalizirani za to.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Stvara novi `MaybeUninit<T>` inicijaliziran zadanom vrijednošću.
    /// Sigurno je nazvati [`assume_init`] za povratnu vrijednost ove funkcije.
    ///
    /// Imajte na umu da ispuštanje `MaybeUninit<T>` nikada neće nazvati `T`-ov padajući kod.
    /// Vaša je odgovornost osigurati da `T` padne ako je inicijaliziran.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Stvara novi `MaybeUninit<T>` u neinicijaliziranom stanju.
    ///
    /// Imajte na umu da ispuštanje `MaybeUninit<T>` nikada neće nazvati `T`-ov padajući kod.
    /// Vaša je odgovornost osigurati da `T` padne ako je inicijaliziran.
    ///
    /// Pogledajte [type-level documentation][MaybeUninit] za neke primjere.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Stvorite novi niz `MaybeUninit<T>` predmeta u neinicijaliziranom stanju.
    ///
    /// Note: u verziji future Rust ova metoda može postati nepotrebna kada sintaksa doslovnog niza dopušta [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Primjer u nastavku tada može koristiti `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Vraća (moguće manju) krišku podataka koji su zapravo pročitani
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SIGURNOST: Vrijedi neinicijalizirani `[MaybeUninit<_>; LEN]`.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Stvara novi `MaybeUninit<T>` u neinicijaliziranom stanju, s memorijom koja je napunjena bajtovima `0`.O `T` ovisi hoće li to već omogućiti pravilnu inicijalizaciju.
    ///
    /// Na primjer, `MaybeUninit<usize>::zeroed()` je inicijaliziran, ali `MaybeUninit<&'static i32>::zeroed()` nije jer reference ne smiju biti nule.
    ///
    /// Imajte na umu da ispuštanje `MaybeUninit<T>` nikada neće nazvati `T`-ov padajući kod.
    /// Vaša je odgovornost osigurati da `T` padne ako je inicijaliziran.
    ///
    /// # Example
    ///
    /// Ispravna upotreba ove funkcije: inicijalizacija strukture nulom, pri čemu sva polja strukture mogu držati bitni uzorak 0 kao valjanu vrijednost.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Neispravna* upotreba ove funkcije: pozivanje `x.zeroed().assume_init()` kada `0` nije važeći bit-obrazac za tip:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Unutar para kreiramo `NotZero` koji nema valjani diskriminant.
    /// // To je nedefinirano ponašanje.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SIGURNOST: `u.as_mut_ptr()` usmjerava na dodijeljenu memoriju.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Postavlja vrijednost `MaybeUninit<T>`.
    /// Ovo prepisuje bilo koju prethodnu vrijednost, a da je ne ispustite, pa pazite da je ne upotrijebite dva puta, osim ako ne želite preskočiti pokretanje destruktora.
    ///
    /// Radi vaše udobnosti, ovo također vraća promjenljivu referencu na (sada sigurno inicijalizirani) sadržaj `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SIGURNOST: Upravo smo inicijalizirali ovu vrijednost.
        unsafe { self.assume_init_mut() }
    }

    /// Dobiva pokazivač na sadržanu vrijednost.
    /// Čitanje iz ovog pokazivača ili njegovo pretvaranje u referencu nedefinirano je ponašanje, osim ako je `MaybeUninit<T>` inicijaliziran.
    /// Zapisivanje u memoriju na koje upućuje ovaj pokazivač (non-transitively) je nedefinirano ponašanje (osim unutar `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Ispravna uporaba ove metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Stvorite referencu za `MaybeUninit<T>`.To je u redu jer smo ga inicijalizirali.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Neispravna* upotreba ove metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Stvorili smo referencu na neinicijalizirani vector!To je nedefinirano ponašanje.⚠️
    /// ```
    ///
    /// (Primijetite da pravila oko upućivanja na neinicijalizirane podatke još nisu finalizirana, ali dok nisu, poželjno ih je izbjegavati.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` i `ManuallyDrop` su oba `repr(transparent)`, tako da možemo emitirati pokazivač.
        self as *const _ as *const T
    }

    /// Dobiva promjenjivi pokazivač na sadržanu vrijednost.
    /// Čitanje iz ovog pokazivača ili njegovo pretvaranje u referencu nedefinirano je ponašanje, osim ako je `MaybeUninit<T>` inicijaliziran.
    ///
    /// # Examples
    ///
    /// Ispravna uporaba ove metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Stvorite referencu za `MaybeUninit<Vec<u32>>`.
    /// // To je u redu jer smo ga inicijalizirali.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Neispravna* upotreba ove metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Stvorili smo referencu na neinicijalizirani vector!To je nedefinirano ponašanje.⚠️
    /// ```
    ///
    /// (Primijetite da pravila oko upućivanja na neinicijalizirane podatke još nisu finalizirana, ali dok nisu, poželjno ih je izbjegavati.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` i `ManuallyDrop` su oba `repr(transparent)`, tako da možemo emitirati pokazivač.
        self as *mut _ as *mut T
    }

    /// Izdvaja vrijednost iz spremnika `MaybeUninit<T>`.Ovo je izvrstan način da osigurate pad podataka jer će rezultirajući `T` podlijegati uobičajenom rukovanju ispuštanjem.
    ///
    /// # Safety
    ///
    /// Na pozivatelju je da jamči da je `MaybeUninit<T>` stvarno u inicijaliziranom stanju.To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje trenutno nedefinirano ponašanje.
    /// [type-level documentation][inv] sadrži više informacija o ovoj invarijanti inicijalizacije.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Povrh toga, imajte na umu da većina tipova ima dodatne invarijante osim što se smatraju samo inicijaliziranima na razini tipa.
    /// Na primjer, `1` inicijalizirani [`Vec<T>`] smatra se inicijaliziranim (prema trenutnoj implementaciji; to ne predstavlja stabilno jamstvo), jer je jedini preduvjet koji kompajler zna o tome da pokazivač podataka mora biti ne-null.
    ///
    /// Stvaranje takvog `Vec<T>` ne uzrokuje *trenutno* nedefinirano ponašanje, ali će uzrokovati nedefinirano ponašanje kod većine sigurnih operacija (uključujući ispuštanje).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Ispravna uporaba ove metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Neispravna* upotreba ove metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` još nije bio inicijaliziran, pa je ovaj posljednji redak prouzročio nedefinirano ponašanje.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SIGURNOST: pozivatelj mora jamčiti da je `self` inicijaliziran.
        // To također znači da `self` mora biti inačica `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Očitava vrijednost iz spremnika `MaybeUninit<T>`.Dobiveni `T` podliježe uobičajenom rukovanju ispuštanjem.
    ///
    /// Kad god je to moguće, poželjno je umjesto toga koristiti [`assume_init`], koji sprječava dupliciranje sadržaja `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Na pozivatelju je da jamči da je `MaybeUninit<T>` stvarno u inicijaliziranom stanju.To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje nedefinirano ponašanje.
    /// [type-level documentation][inv] sadrži više informacija o ovoj invarijanti inicijalizacije.
    ///
    /// Štoviše, ovo ostavlja kopiju istih podataka u `MaybeUninit<T>`-u.
    /// Kada upotrebljavate više kopija podataka (pozivanjem `assume_init_read` više puta ili prvo pozivanjem `assume_init_read`, a zatim [`assume_init`]), vaša je odgovornost osigurati da se ti podaci doista mogu duplicirati.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Ispravna uporaba ove metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` je `Copy`, tako da možemo čitati više puta.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Dupliciranje vrijednosti `None` je u redu, pa možemo čitati više puta.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Neispravna* upotreba ove metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Sada smo stvorili dvije kopije istog vector, što je dovelo do dvostrukog besplatnog ⚠️ kad obje padnu!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SIGURNOST: pozivatelj mora jamčiti da je `self` inicijaliziran.
        // Čitanje s `self.as_ptr()` sigurno je jer `self` treba inicijalizirati.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Ispušta sadržanu vrijednost na mjesto.
    ///
    /// Ako ste vlasnik `MaybeUninit`, umjesto njega možete koristiti [`assume_init`].
    ///
    /// # Safety
    ///
    /// Na pozivatelju je da jamči da je `MaybeUninit<T>` stvarno u inicijaliziranom stanju.To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje nedefinirano ponašanje.
    ///
    /// Povrh toga, svi dodatni invarijanti tipa `T` moraju biti zadovoljeni, jer se implementacija `Drop` `T` (ili njegovih članova) može na to osloniti.
    /// Na primjer, `1` inicijalizirani [`Vec<T>`] smatra se inicijaliziranim (prema trenutnoj implementaciji; to ne predstavlja stabilno jamstvo), jer je jedini preduvjet koji kompajler zna o tome da pokazivač podataka mora biti ne-null.
    ///
    /// Međutim, ispuštanje takvog `Vec<T>` uzrokovat će nedefinirano ponašanje.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SIGURNOST: pozivatelj mora jamčiti da je `self` inicijaliziran i
        // zadovoljava sve invarijante `T`.
        // Ispuštanje vrijednosti na mjesto sigurno je ako je to slučaj.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Dobiva zajedničku referencu na sadržanu vrijednost.
    ///
    /// To može biti korisno kada želimo pristupiti `MaybeUninit` koji je inicijaliziran, ali nema vlasništvo nad `MaybeUninit` (sprječava upotrebu `.assume_init()`).
    ///
    /// # Safety
    ///
    /// To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje nedefinirano ponašanje: na pozivatelju je da jamči da je `MaybeUninit<T>` stvarno u inicijaliziranom stanju.
    ///
    ///
    /// # Examples
    ///
    /// ### Ispravna uporaba ove metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicijalizirajte `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Sad kad se zna da je naš `MaybeUninit<_>` inicijaliziran, u redu je stvoriti zajedničku referencu na njega:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SIGURNOST: `x` je inicijaliziran.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Neispravna* upotreba ove metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Stvorili smo referencu na neinicijalizirani vector!To je nedefinirano ponašanje.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicijalizirajte `MaybeUninit` pomoću `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referenca na neinicijalizirani `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SIGURNOST: pozivatelj mora jamčiti da je `self` inicijaliziran.
        // To također znači da `self` mora biti inačica `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Dobiva promjenjivu referencu (unique) na sadržanu vrijednost.
    ///
    /// To može biti korisno kada želimo pristupiti `MaybeUninit` koji je inicijaliziran, ali nema vlasništvo nad `MaybeUninit` (sprječava upotrebu `.assume_init()`).
    ///
    /// # Safety
    ///
    /// To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje nedefinirano ponašanje: na pozivatelju je da jamči da je `MaybeUninit<T>` stvarno u inicijaliziranom stanju.
    /// Na primjer, `.assume_init_mut()` se ne može koristiti za inicijalizaciju `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Ispravna uporaba ove metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicijalizira *svih* bajtova ulaznog međuspremnika.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicijalizirajte `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Sada znamo da je `buf` inicijaliziran, pa bismo ga mogli `.assume_init()`.
    /// // Međutim, upotreba `.assume_init()` može pokrenuti `memcpy` od 2048 bajtova.
    /// // Da bismo tvrdili da je naš međuspremnik inicijaliziran bez kopiranja, nadogradimo `&mut MaybeUninit<[u8; 2048]>` na `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SIGURNOST: `buf` je inicijaliziran.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Sada `buf` možemo koristiti kao normalnu krišku:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Neispravna* upotreba ove metode:
    ///
    /// Ne možete koristiti `.assume_init_mut()` za inicijalizaciju vrijednosti:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Izradili smo referencu (mutable) za neinicijalizirani `bool`!
    ///     // To je nedefinirano ponašanje.⚠️
    /// }
    /// ```
    ///
    /// Na primjer, ne možete [`Read`] u neinicijalizirani međuspremnik:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referenca na neinicijaliziranu memoriju!
    ///                             // To je nedefinirano ponašanje.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ne možete koristiti izravni pristup polju za postupnu inicijalizaciju polja po polja:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referenca na neinicijaliziranu memoriju!
    ///                  // To je nedefinirano ponašanje.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referenca na neinicijaliziranu memoriju!
    ///                  // To je nedefinirano ponašanje.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Trenutno se oslanjamo na to da je gore navedeno netočno, tj. Imamo reference na neinicijalizirane podatke (npr. U `libcore/fmt/float.rs`).
    // Konačnu odluku o pravilima trebali bismo donijeti prije stabilizacije.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SIGURNOST: pozivatelj mora jamčiti da je `self` inicijaliziran.
        // To također znači da `self` mora biti inačica `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Izdvaja vrijednosti iz niza kontejnera `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Na pozivatelju je da jamči da su svi elementi niza u inicijaliziranom stanju.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SIGURNOST: Sada na sigurnom jer smo inicijalizirali sve elemente
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Pozivatelj jamči da su svi elementi niza inicijalizirani
        // * `MaybeUninit<T>` i T zajamčeno imaju isti izgled
        // * MoždaUnint ne pada, tako da nema dvostrukih oslobađanja, pa je pretvorba sigurna
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Pod pretpostavkom da su svi elementi inicijalizirani, uzmite im krišku.
    ///
    /// # Safety
    ///
    /// Na pozivatelju je da jamči da su `MaybeUninit<T>` elementi stvarno u inicijaliziranom stanju.
    ///
    /// To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje nedefinirano ponašanje.
    ///
    /// Pogledajte [`assume_init_ref`] za više detalja i primjera.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SIGURNOST: lijevanje kriške na `*const [T]` sigurno je jer to pozivatelj jamči
        // `slice` je inicijaliziran, a zajamčeno je da će "MaybeUninit"imati isti izgled kao i `T`.
        // Dobiveni pokazivač vrijedi jer se odnosi na memoriju u vlasništvu `slice` koja je referenca i stoga je zajamčena da vrijedi za čitanje.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Pod pretpostavkom da su svi elementi inicijalizirani, uzmite im promjenjivu krišku.
    ///
    /// # Safety
    ///
    /// Na pozivatelju je da jamči da su `MaybeUninit<T>` elementi stvarno u inicijaliziranom stanju.
    ///
    /// To pozivanje kada sadržaj još nije u potpunosti inicijaliziran uzrokuje nedefinirano ponašanje.
    ///
    /// Pogledajte [`assume_init_mut`] za više detalja i primjera.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SIGURNOST: slično sigurnosnim napomenama za `slice_get_ref`, ali imamo a
        // promjenjiva referenca koja je također zajamčena da vrijedi za upise.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Dobiva pokazivač na prvi element niza.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Dobiva promjenjivi pokazivač na prvi element niza.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopira elemente iz `src` u `this`, vraćajući promjenjivu referencu na sada inicirani sadržaj `this`.
    ///
    /// Ako `T` ne implementira `Copy`, upotrijebite [`write_slice_cloned`]
    ///
    /// Ovo je slično [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ova će funkcija panic ako dvije kriške imaju različite duljine.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIGURNOST: upravo smo kopirali sve elemente lena u rezervni kapacitet
    /// // prvi src.len() elementi veca sada vrijede.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SIGURNOST: &[T] i&[MoždaUninit<T>] imaju isti izgled
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SIGURNOST: Važeći elementi upravo su kopirani u `this`, tako da je početni
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonira elemente od `src` do `this`, vraćajući promjenljivu referencu na sada inicirani sadržaj `this`.
    /// Svi već inicializirani elementi neće se ispustiti.
    ///
    /// Ako `T` implementira `Copy`, upotrijebite [`write_slice`]
    ///
    /// Ovo je slično [`slice::clone_from_slice`], ali ne ispušta postojeće elemente.
    ///
    /// # Panics
    ///
    /// Ova će funkcija panic ako dvije kriške imaju različite duljine ili ako je implementacija `Clone` panics.
    ///
    /// Ako postoji panic, ispustit će se već klonirani elementi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIGURNOST: upravo smo klonirali sve elemente lena u rezervni kapacitet
    /// // prvi src.len() elementi veca sada vrijede.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // za razliku od copy_from_slice, ovo ne poziva clone_from_slice na rezanju, to je zato što `MaybeUninit<T: Clone>` ne implementira Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SIGURNOST: ova sirova kriška sadržavat će samo inicijalizirane objekte
                // zato ga je i dopušteno ispustiti.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Moramo ih izričito narezati na istu dužinu
        // za brisanje provjere granica, a optimizator će generirati memcpy za jednostavne slučajeve (na primjer T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // potreban je zaštitnik b/c panic može se dogoditi tijekom klona
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SIGURNOST: Važeći elementi upravo su upisani u `this` pa je početnim slovima
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}