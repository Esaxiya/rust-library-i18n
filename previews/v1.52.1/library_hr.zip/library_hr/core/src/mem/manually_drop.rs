use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Omotač koji sprečava kompajler da automatski ne pozove destruktor `T`-a.
/// Ovaj omot ima 0 troškova.
///
/// `ManuallyDrop<T>` podliježe istoj optimizaciji izgleda kao i `T`.
/// Kao posljedica toga, on nema *nikakav utjecaj* na pretpostavke koje je sastavljač dao o svom sadržaju.
/// Na primjer, inicijalizacija `ManuallyDrop<&mut T>` s [`mem::zeroed`] je nedefinirano ponašanje.
/// Ako trebate rukovati neinicijaliziranim podacima, umjesto toga upotrijebite [`MaybeUninit<T>`].
///
/// Imajte na umu da je pristup vrijednosti unutar `ManuallyDrop<T>` siguran.
/// To znači da `ManuallyDrop<T>` čiji je sadržaj ispušten ne smije biti izložen putem javno sigurnog API-ja.
/// Sukladno tome, `ManuallyDrop::drop` nije siguran.
///
/// # `ManuallyDrop` i odustati od narudžbe.
///
/// Rust ima dobro definirane vrijednosti [drop order].
/// Da biste bili sigurni da se polja ili lokalni podaci ispuštaju u određenom redoslijedu, preuredite deklaracije tako da je implicitni redoslijed ispuštanja ispravan.
///
/// Moguće je koristiti `ManuallyDrop` za kontrolu redoslijeda ispuštanja, ali to zahtijeva nesigurni kôd i teško je to učiniti ispravno u prisutnosti odmotavanja.
///
///
/// Na primjer, ako želite biti sigurni da je određeno polje ispušteno nakon ostalih, učinite to posljednjim poljem strukture:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` bit će ispušten nakon `children`.
///     // Rust jamči da će se polja ispustiti redoslijedom deklaracije.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Zamotajte vrijednost koja će se ručno ispustiti.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Još uvijek možete sigurno upravljati vrijednošću
    /// assert_eq!(*x, "Hello");
    /// // Ali `Drop` ovdje neće biti pokrenut
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Izdvaja vrijednost iz spremnika `ManuallyDrop`.
    ///
    /// To omogućuje ponovno ispuštanje vrijednosti.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Ovo ispušta `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Izvadi vrijednost iz spremnika `ManuallyDrop<T>`.
    ///
    /// Ova je metoda prvenstveno namijenjena za pomicanje vrijednosti u padu.
    /// Umjesto da koristite [`ManuallyDrop::drop`] za ručno ispuštanje vrijednosti, ovom metodom možete uzeti vrijednost i koristiti je kako god želite.
    ///
    /// Kad god je to moguće, poželjno je umjesto toga koristiti [`into_inner`][`ManuallyDrop::into_inner`], koji sprječava dupliciranje sadržaja `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Ova funkcija semantički premješta sadržanu vrijednost bez sprečavanja daljnje upotrebe, ostavljajući stanje ovog spremnika nepromijenjenim.
    /// Vaša je odgovornost osigurati da se ovaj `ManuallyDrop` više ne koristi.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SIGURNOST: čitamo iz reference koja je zajamčena
        // da vrijedi za čitanja.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ručno ispušta sadržanu vrijednost.To je točno ekvivalentno pozivu [`ptr::drop_in_place`] s pokazivačem na sadržanu vrijednost.
    /// Kao takav, ako sadržana vrijednost nije upakirana struktura, destruktor će se pozvati na mjestu bez premještanja vrijednosti, pa se stoga može koristiti za sigurno ispuštanje [pinned] podataka.
    ///
    /// Ako ste vlasnik vrijednosti, umjesto toga možete upotrijebiti [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Ova funkcija pokreće destruktor sadržane vrijednosti.
    /// Osim promjena koje je izvršio sam destruktor, memorija ostaje nepromijenjena, pa što se tiče kompajlera i dalje sadrži bitni obrazac koji vrijedi za tip `T`.
    ///
    ///
    /// Međutim, ova vrijednost "zombie" ne bi trebala biti izložena sigurnom kodu, a ovu funkciju ne treba pozivati više puta.
    /// Upotreba vrijednosti nakon što je ispuštena ili ispuštanje vrijednosti više puta, može uzrokovati nedefinirano ponašanje (ovisno o tome što `drop` radi).
    /// To tipski sustav obično sprječava, ali korisnici `ManuallyDrop` moraju podržati ta jamstva bez pomoći prevoditelja.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SIGURNOST: ispuštamo vrijednost na koju ukazuje promjenjiva referenca
        // što zajamčeno vrijedi za upise.
        // Na pozivatelju je da osigura da `slot` ponovo ne padne.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}