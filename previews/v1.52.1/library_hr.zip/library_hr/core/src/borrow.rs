//! Modul za rad s posuđenim podacima.

#![stable(feature = "rust1", since = "1.0.0")]

/// A Portrait za posuđivanje podataka.
///
/// U Rust uobičajeno je davati različite prikaze tipa za različite slučajeve upotrebe.
/// Na primjer, mjesto pohrane i upravljanje vrijednošću mogu se posebno odabrati kao prikladni za određenu upotrebu putem tipova pokazivača kao što su [`Box<T>`] ili [`Rc<T>`].
/// Osim ovih generičkih omotača koji se mogu koristiti s bilo kojom vrstom, neki tipovi nude opcijske aspekte koji pružaju potencijalno skupu funkcionalnost.
/// Primjer za takav tip je [`String`] koji dodaje mogućnost proširenja niza osnovnom [`str`].
/// To zahtijeva zadržavanje dodatnih podataka nepotrebnih za jednostavan, nepromjenjivi niz.
///
/// Ove vrste omogućuju pristup temeljnim podacima putem referenci na vrstu tih podataka.Za njih se kaže da su "posuđeni kao" takav tip.
/// Na primjer, [`Box<T>`] se može posuditi kao `T`, dok se [`String`] može posuditi kao `str`.
///
/// Tipovi izražavaju da se mogu posuditi kao neki tip `T` primjenom `Borrow<T>`, pružajući referencu na `T` u Portrait-ovoj [`borrow`] metodi.Tip se može posuditi kao nekoliko različitih vrsta.
/// Ako se želi mutabilno posuditi kao tip-dopuštajući izmjenu osnovnih podataka, može dodatno implementirati [`BorrowMut<T>`].
///
/// Dalje, prilikom pružanja implementacija za dodatne traits, treba razmotriti trebaju li se ponašati identično onima osnovnog tipa kao posljedice djelovanja kao reprezentacija tog temeljnog tipa.
/// Generički kod obično koristi `Borrow<T>` kada se oslanja na identično ponašanje ovih dodatnih implementacija Portrait.
/// Ove traits vjerojatno će se pojaviti kao dodatni Portrait bounds.
///
/// Konkretno `Eq`, `Ord` i `Hash` moraju biti ekvivalentni za posuđene i posjedovane vrijednosti: `x.borrow() == y.borrow()` treba dati isti rezultat kao `x == y`.
///
/// Ako generički kod samo treba raditi za sve tipove koji mogu pružiti referencu na srodni tip `T`, često je bolje koristiti [`AsRef<T>`] jer ga više tipova može sigurno implementirati.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Kao zbirka podataka, [`HashMap<K, V>`] posjeduje i ključeve i vrijednosti.Ako su stvarni podaci ključa zamotani u neku vrstu upravljanja, međutim, i dalje bi trebalo biti moguće potražiti vrijednost pomoću reference na podatke ključa.
/// Na primjer, ako je ključ niz, tada se vjerojatno pohranjuje s hash mapom kao [`String`], dok bi trebalo biti moguće pretraživati pomoću [`&str`][`str`].
/// Dakle, `insert` mora raditi na `String`, dok `get` mora moći koristiti `&str`.
///
/// Pomalo pojednostavljeni, relevantni dijelovi `HashMap<K, V>` izgledaju ovako:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // polja izostavljena
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Cijela hash karta generička je za tip ključa `K`.Budući da su ti ključevi pohranjeni s hash mapom, ova vrsta mora posjedovati podatke ključa.
/// Prilikom umetanja para ključ/vrijednost, karta dobiva takav `K` i treba pronaći ispravnu heš grupu i provjeriti je li ključ već prisutan na temelju tog `K`.Stoga mu je potreban `K: Hash + Eq`.
///
/// Međutim, prilikom traženja vrijednosti na karti, ako biste naveli referencu na `K` kao ključ za traženje, uvijek bi trebalo stvoriti takvu vrijednost u vlasništvu.
/// Za ključeve niza to bi značilo da treba stvoriti vrijednost `String` samo za traženje slučajeva u kojima je dostupan samo `str`.
///
/// Umjesto toga, metoda `get` generička je za tip osnovnih podataka ključa, koji se u gornjem potpisu metode naziva `Q`.U njemu se navodi da se `K` posuđuje kao `Q` zahtijevajući taj `K: Borrow<Q>`.
/// Dodatnim zahtjevom `Q: Hash + Eq` signalizira zahtjev da `K` i `Q` imaju implementacije `Hash` i `Eq` traits koje daju identične rezultate.
///
/// Provedba `get` posebno se oslanja na identične implementacije `Hash` određivanjem hash segmenta ključa pozivanjem `Hash::hash` na vrijednost `Q`, iako je ključ umetnuo na temelju hash vrijednosti izračunate iz vrijednosti `K`.
///
///
/// Kao posljedica toga, hash karta se lomi ako `K` koji umotava vrijednost `Q` proizvede drugačiji hash od `Q`.Na primjer, zamislite da imate tip koji obavija niz, ali uspoređuje ASCII slova zanemarujući njihov slučaj:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Budući da dvije jednake vrijednosti trebaju proizvesti istu hash vrijednost, implementacija `Hash` također mora zanemariti slučaj ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Može li `CaseInsensitiveString` implementirati `Borrow<str>`?Svakako može pružiti referencu na odsječak niza putem niza u njegovom vlasništvu.
/// Ali budući da se njegova implementacija `Hash` razlikuje, ponaša se drugačije od `str` i stoga zapravo ne smije implementirati `Borrow<str>`.
/// Ako želi dopustiti drugima pristup osnovnom `str`, to može učiniti putem `AsRef<str>` koji ne zahtijeva nikakve dodatne zahtjeve.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Neizmjerno posuđuje iz vrijednosti u vlasništvu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Portrait za mutabilno posuđivanje podataka.
///
/// Kao pratilac [`Borrow<T>`], ovaj Portrait omogućuje tipu da se posuđuje kao osnovni tip pružajući promjenjivu referencu.
/// Pogledajte [`Borrow<T>`] za više informacija o posuđivanju kao drugoj vrsti.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Promjenjivo se posuđuje iz vrijednosti u vlasništvu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}