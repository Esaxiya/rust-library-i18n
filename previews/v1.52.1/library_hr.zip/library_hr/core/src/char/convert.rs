//! Pretvorba znakova.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Pretvara `u32` u `char`.
///
/// Imajte na umu da su svi [`char`] s važeći [`u32`] s i mogu se prebaciti na jedan sa
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Međutim, obrnuto nije točno: nisu svi važeći [`u32`] s važeći [`char`] s.
/// `from_u32()` vratit će `None` ako ulaz nije valjana vrijednost za [`char`].
///
/// Za nesigurnu verziju ove funkcije koja zanemaruje ove provjere, pogledajte [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Vraća se `None` kada unos nije važeći [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Pretvara `u32` u `char`, zanemarujući valjanost.
///
/// Imajte na umu da su svi [`char`] s važeći [`u32`] s i mogu se prebaciti na jedan sa
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Međutim, obrnuto nije točno: nisu svi važeći [`u32`] s važeći [`char`] s.
/// `from_u32_unchecked()` će to zanemariti i slijepo prebaciti na [`char`], moguće stvarajući nevaljani.
///
///
/// # Safety
///
/// Ova funkcija nije sigurna jer može konstruirati nevaljane vrijednosti `char`.
///
/// Za sigurnu verziju ove funkcije pogledajte funkciju [`from_u32`].
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SIGURNOST: pozivatelj mora jamčiti da je `i` valjana vrijednost char.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Pretvara [`char`] u [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Pretvara [`char`] u [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char se lijeva na vrijednost kodne točke, a zatim se nula proširuje na 64 bita.
        // Pogledajte [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Pretvara [`char`] u [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char se lijeva na vrijednost kodne točke, a zatim se nula proširuje na 128 bita.
        // Pogledajte [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mapira bajt u 0x00 ..=0xFF u `char` čija kodna točka ima istu vrijednost, u U + 0000 ..=U + 00FF.
///
/// Unicode je dizajniran tako da učinkovito dekodira bajtove s kodiranjem znakova koje IANA naziva ISO-8859-1.
/// Ovo je kodiranje kompatibilno s ASCII.
///
/// Imajte na umu da se ovo razlikuje od ISO/IEC 8859-1 aka
/// ISO 8859-1 (s jednom crticom manje), koji ostavlja neke "blanks", vrijednosti bajtova koje nisu dodijeljene nijednom znaku.
/// ISO-8859-1 (onaj IANA) dodjeljuje ih kontrolnim kodovima C0 i C1.
///
/// Imajte na umu da se ovo *također* razlikuje od Windows-1252 aka
/// kodna stranica 1252, što je nadskup ISO/IEC 8859-1 koji interpunkcijskim znakovima i raznim latiničnim znakovima dodjeljuje neke (ne sve!) praznine.
///
/// Da bi se stvari dodatno zbunile, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` i `windows-1252` pseudonimi su za superset Windows-1252 koji preostale praznine ispunjava odgovarajućim kontrolnim kodovima C0 i C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Pretvara [`u8`] u [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Pogreška koja se može vratiti prilikom raščlanjivanja znaka.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SIGURNOST: provjereno je li to legalna unicode vrijednost
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Vrsta pogreške vraća se kada pretvorba iz u32 u char ne uspije.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Pretvara znamenku u danom radixu u `char`.
///
/// 'radix' se ovdje ponekad naziva i 'base'.
/// Polumjerak dva označava binarni broj, polumjer deset, decimalni i polumjer šesnaest, heksadecimalni, dajući neke zajedničke vrijednosti.
///
/// Podržani su proizvoljni radiksi.
///
/// `from_digit()` vratit će `None` ako ulaz nije znamenka u danom radixu.
///
/// # Panics
///
/// Panics ako mu je dan radiks veći od 36.
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimalni 11 je jednoznamenkasti u bazi 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Vraća se `None` kada unos nije znamenka:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Prolazeći veliki radiks uzrokujući panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}