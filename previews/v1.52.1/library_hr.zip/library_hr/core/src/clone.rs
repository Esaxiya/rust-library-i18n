//! `Clone` Portrait za vrste koje se ne mogu 'implicitno kopirati'.
//!
//! U Rust neki su jednostavni tipovi "implicitly copyable" i kada ih dodijelite ili proslijedite kao argumente, primatelj će dobiti kopiju, a izvorna vrijednost će ostati na mjestu.
//! Ove vrste ne zahtijevaju dodjelu za kopiranje i nemaju finalizatore (tj. Ne sadrže okvire u vlasništvu ili implementiraju [`Drop`]), pa ih prevodilac smatra jeftinima i sigurnima za kopiranje.
//!
//! Za ostale vrste kopije se moraju izričito izraditi, sporazumno implementirajući [`Clone`] Portrait i pozivajući [`clone`] metodu.
//!
//! [`clone`]: Clone::clone
//!
//! Primjer osnovne upotrebe:
//!
//! ```
//! let s = String::new(); // Tip niza implementira Clone
//! let copy = s.clone(); // tako da ga možemo klonirati
//! ```
//!
//! Da biste lako implementirali Clone Portrait, možete koristiti i `#[derive(Clone)]`.Primjer:
//!
//! ```
//! #[derive(Clone)] // dodamo Klon Portrait strukturi Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // i sada to možemo klonirati!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Uobičajeni Portrait za mogućnost eksplicitnog dupliciranja objekta.
///
/// Razlikuje se od [`Copy`] po tome što je [`Copy`] implicitno i krajnje jeftin, dok je `Clone` uvijek izričit i može biti skup, a ne mora.
/// Da bi se primijenile ove karakteristike, Rust vam ne dopušta ponovnu primjenu [`Copy`], ali možete ponovno primijeniti `Clone` i pokrenuti proizvoljan kôd.
///
/// Budući da je `Clone` općenitiji od [`Copy`], automatski možete učiniti sve što [`Copy`] bude i `Clone`.
///
/// ## Derivable
///
/// Ovaj se Portrait može koristiti s `#[derive]` ako su sva polja `Clone`.`Izvedena`d implementacija [`Clone`] poziva [`clone`] na svakom polju.
///
/// [`clone`]: Clone::clone
///
/// Za generičku strukturu, `#[derive]` implementira `Clone` uvjetno dodavanjem vezanog `Clone` na generičke parametre.
///
/// ```
/// // `derive` provodi Klon za čitanje<T>kada je T Klon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kako mogu implementirati `Clone`?
///
/// Tipovi koji su [`Copy`] trebali bi imati trivijalnu implementaciju `Clone`.Formalnije:
/// ako su `T: Copy`, `x: T` i `y: &T`, tada je `let x = y.clone();` ekvivalentan `let x = *y;`.
/// Ručne implementacije trebaju biti oprezne da bi se podržala ova invarijanta;međutim, nesigurni kod ne smije se oslanjati na njega kako bi osigurao sigurnost memorije.
///
/// Primjer je generička struktura koja drži pokazivač funkcije.U ovom slučaju, implementaciju `Clone` nije moguće `izvesti`, ali se može provesti kao:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Dodatni realizatori
///
/// Uz [implementors listed below][impls], sljedeće vrste također implementiraju `Clone`:
///
/// * Tipovi stavki funkcije (tj. Različiti tipovi definirani za svaku funkciju)
/// * Tipovi pokazivača funkcija (npr., `fn() -> i32`)
/// * Tipovi polja, za sve veličine, ako vrsta predmeta također implementira `Clone` (npr. `[i32; 123456]`)
/// * Vrste slogova, ako svaka komponenta također implementira `Clone` (npr. `()`, `(i32, bool)`)
/// * Vrste zatvaranja, ako ne bilježe nikakvu vrijednost iz okoline ili ako sve takve snimljene vrijednosti same implementiraju `Clone`.
///   Imajte na umu da varijable zabilježene zajedničkom referencom uvijek implementiraju `Clone` (čak i ako referent to ne čini), dok varijable zabilježene promjenjivom referencom nikad ne implementiraju `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Vraća kopiju vrijednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str provodi Klon
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Obavlja dodjeljivanje kopija iz `source`.
    ///
    /// `a.clone_from(&b)` po funkciji je ekvivalentan `a = b.clone()`, ali se može nadjačati da bi se resursi `a` ponovno iskoristili kako bi se izbjegle nepotrebne dodjele.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Izvedite makronaredbu koja generira impl Portrait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ove strukture koristi samo#[derive] kako bi tvrdio da svaka komponenta tipa implementira Clone ili Copy.
//
//
// Te se strukture nikada ne bi trebale pojavljivati u korisničkom kodu.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementacije `Clone` za primitivne tipove.
///
/// Implementacije koje se ne mogu opisati u Rust implementirane su u `traits::SelectionContext::copy_clone_conditions()` u `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Dijeljene reference mogu se klonirati, ali izmjenjive reference *ne mogu*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Dijeljene reference mogu se klonirati, ali izmjenjive reference *ne mogu*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}