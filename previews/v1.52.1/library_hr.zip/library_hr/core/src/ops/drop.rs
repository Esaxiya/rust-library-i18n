/// Prilagođeni kod unutar destruktora.
///
/// Kada vrijednost više nije potrebna, Rust će pokrenuti "destructor" na toj vrijednosti.
/// Najčešći način na koji vrijednost više nije potrebna jest kad izađe iz opsega.Destruktori mogu i dalje raditi u drugim okolnostima, ali usredotočit ćemo se na opseg za primjere ovdje.
/// Da biste saznali više o tim drugim slučajevima, pogledajte odjeljak [the reference] o destruktorima.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ovaj destruktor sastoji se od dvije komponente:
/// - Poziv na `Drop::drop` za tu vrijednost, ako je ovaj posebni `Drop` Portrait implementiran za svoj tip.
/// - Automatski generirani "drop glue" koji rekurzivno poziva destruktore svih polja ove vrijednosti.
///
/// Kako Rust automatski poziva destruktore svih sadržanih polja, u većini slučajeva ne morate implementirati `Drop`.
/// No, postoje neki slučajevi kada je to korisno, na primjer za vrste koje izravno upravljaju resursom.
/// Taj resurs može biti memorija, može biti deskriptor datoteke, može biti mrežna utičnica.
/// Jednom kada se vrijednost tog tipa više neće koristiti, trebala bi "clean up" svoj resurs osloboditi memoriju ili zatvoriti datoteku ili utičnicu.
/// Ovo je posao destruktora, a samim tim i posao `Drop::drop`.
///
/// ## Examples
///
/// Da bismo vidjeli destruktore na djelu, pogledajmo sljedeći program:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust prvo će pozvati `Drop::drop` za `_x`, a zatim i za `_x.one` i `_x.two`, što znači da će se njegovo pokretanje ispisati
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Čak i ako uklonimo implementaciju `Drop` za `HasTwoDrop`, i dalje se pozivaju destruktori njegovih polja.
/// To bi rezultiralo
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Ne možete sami nazvati `Drop::drop`
///
/// Budući da se `Drop::drop` koristi za čišćenje vrijednosti, moglo bi biti opasno koristiti ovu vrijednost nakon što je metoda pozvana.
/// Kako `Drop::drop` ne preuzima vlasništvo nad svojim ulazom, Rust sprječava zlouporabu ne dopuštajući vam izravno pozivanje `Drop::drop`.
///
/// Drugim riječima, ako ste pokušali eksplicitno pozvati `Drop::drop` u gornjem primjeru, dobit ćete pogrešku kompajlera.
///
/// Ako želite eksplicitno pozvati destruktor vrijednosti, umjesto njega se može koristiti [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Redoslijed ispuštanja
///
/// Koji od naša dva `HasDrop` ipak padne prvi?Za konstrukcije je isti redoslijed kao i deklariran: prvo `one`, a zatim `two`.
/// Ako ovo želite isprobati sami, možete izmijeniti `HasDrop` gore kako bi sadržavao neke podatke, poput cijelog broja, a zatim ga koristiti u `println!` unutar `Drop`.
/// Takvo ponašanje jamči jezik.
///
/// Za razliku od struktura, lokalne varijable ispuštaju se obrnutim redoslijedom:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Ovo će se ispisati
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Molimo pogledajte [the reference] za cjelovita pravila.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` i `Drop` su ekskluzivni
///
/// Ne možete implementirati [`Copy`] i `Drop` na isti tip.Vrste koje su `Copy` prevoditelj implicitno duplicira, što otežava predviđanje kada i koliko često će se izvršiti destruktori.
///
/// Kao takve, ove vrste ne mogu imati destruktore.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Izvršava destruktor za ovu vrstu.
    ///
    /// Ova se metoda naziva implicitno kada vrijednost izlazi iz opsega i ne može se eksplicitno pozvati (ovo je pogreška kompajlera [E0040]).
    /// Međutim, funkcija [`mem::drop`] u prelude može se koristiti za pozivanje `Drop` implementacije argumenta.
    ///
    /// Kada je pozvana ova metoda, `self` još nije uklonjen.
    /// To se događa tek nakon što metoda završi.
    /// Da to nije slučaj, `self` bi bio viseća referenca.
    ///
    /// # Panics
    ///
    /// S obzirom na to da će [`panic!`] nazvati `drop` dok se odmotava, svaki [`panic!`] u implementaciji `drop` vjerojatno će prekinuti.
    ///
    /// Imajte na umu da se čak i ako je ovaj panics, vrijednost smatra ispuštenom;
    /// ne smijete uzrokovati ponovno pozivanje `drop`.
    /// Prevodilac to obično obrađuje automatski, ali kada se koristi nesigurni kôd, ponekad se može dogoditi nenamjerno, osobito kada se koristi [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}