//! Operateri koji se mogu prenijeti.
//!
//! Implementacija ovih traits omogućuje vam preopterećenje određenih operatora.
//!
//! Neke od ovih traits uvozi prelude, tako da su dostupne u svakom programu Rust.Preopterećeni mogu biti samo operatori podržani traits.
//! Na primjer, operator sabiranja (`+`) može se preopteretiti kroz [`Add`] Portrait, ali budući da operator dodjele (`=`) nema potporu Portrait, ne postoji način da se preoptereti njegova semantika.
//! Uz to, ovaj modul ne pruža nikakav mehanizam za stvaranje novih operatora.
//! Ako su potrebna bezuvjetna preopterećenja ili prilagođeni operatori, trebali biste se okrenuti makronaredbama ili dodacima kompajlera kako biste proširili sintaksu Rust.
//!
//! Implementacije operatora traits ne bi trebale biti iznenađujuće u njihovim kontekstima, imajući na umu njihova uobičajena značenja i [operator precedence].
//! Na primjer, kada implementira [`Mul`], operacija bi trebala imati sličnost s množenjem (i dijeliti očekivana svojstva poput asocijativnosti).
//!
//! Imajte na umu da operateri `&&` i `||` imaju kratki spoj, tj. Oni svoj drugi operand procjenjuju samo ako on doprinosi rezultatu.Budući da traits ovo ponašanje ne mogu provesti, `&&` i `||` nisu podržani kao operateri koji se mogu prenijeti.
//!
//! Mnogi operatori uzimaju svoje operande prema vrijednosti.U generičkom kontekstu koji uključuje ugrađene tipove, to obično nije problem.
//! Međutim, upotreba ovih operatora u generičkom kodu zahtijeva određenu pažnju ako se vrijednosti moraju ponovno koristiti, za razliku od dopuštanja operatorima da ih troše.Jedna je mogućnost povremena upotreba [`clone`].
//! Druga mogućnost je oslanjanje na uključene tipove koji pružaju dodatne implementacije operatora za reference.
//! Na primjer, za korisnički definirani tip `T` koji bi trebao podržavati dodavanje, vjerojatno je dobra ideja da i `T` i `&T` implementiraju traits [`Add<T>`][`Add`] i [`Add<&T>`][`Add`] kako bi generički kôd mogao biti napisan bez nepotrebnog kloniranja.
//!
//!
//! # Examples
//!
//! Ovaj primjer stvara strukturu `Point` koja implementira [`Add`] i [`Sub`], a zatim demonstrira zbrajanje i oduzimanje dvije `Točke`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Primjer implementacije potražite u dokumentaciji za svaki Portrait.
//!
//! [`Fn`], [`FnMut`] i [`FnOnce`] traits implementirani su po tipovima koji se mogu pozivati poput funkcija.Imajte na umu da [`Fn`] uzima `&self`, [`FnMut`] `&mut self`, a [`FnOnce`] `self`.
//! Oni odgovaraju trima vrstama metoda koje se mogu pozvati na instanci: poziv-po-referenci, poziv-po-promjenjivoj-referenci i poziv-po-vrijednosti.
//! Najčešća upotreba ovih traits je djelovanje kao granica na funkcije više razine koje funkcije ili zatvaranja uzimaju kao argumente.
//!
//! Uzimanje [`Fn`] kao parametra:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Uzimanje [`FnMut`] kao parametra:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Uzimanje [`FnOnce`] kao parametra:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` troši svoje zarobljene varijable, pa se ne može pokrenuti više od jednom
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Pokušaj ponovnog poziva na `func()` izbacit će pogrešku `use of moved value` za `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` u ovom se trenutku više ne može pozivati
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;