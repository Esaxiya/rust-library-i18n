use crate::marker::Unpin;
use crate::pin::Pin;

/// Rezultat nastavka generatora.
///
/// Ovaj se nabrajanje vraća iz metode `Generator::resume` i ukazuje na moguće povratne vrijednosti generatora.
/// Trenutno to odgovara ili ovjesnoj točki (`Yielded`) ili završnoj točki (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generator je suspendiran s vrijednošću.
    ///
    /// Ovo stanje označava da je generator suspendiran i obično odgovara izjavi `yield`.
    /// Vrijednost navedena u ovoj varijanti odgovara izrazu proslijeđenom u `yield` i omogućuje generatorima da daju vrijednost svaki put kad daju.
    ///
    ///
    Yielded(Y),

    /// Generator je dovršen s povratnom vrijednošću.
    ///
    /// Ovo stanje znači da je generator završio izvršenje s navedenom vrijednošću.
    /// Jednom kada je generator vratio `Complete`, smatra se pogreškom programera da ponovno pozove `resume`.
    ///
    Complete(R),
}

/// Portrait implementiran od strane ugrađenih tipova generatora.
///
/// Generatori, koji se također nazivaju koroutine, trenutno su eksperimentalna jezična značajka u Rust.
/// Dodani u [RFC 2033] generatori trenutno su namijenjeni prvenstveno pružanju građevne jedinice za sintaksu async/await, ali će se vjerojatno proširiti i na pružanje ergonomske definicije za iteratore i ostale primitive.
///
///
/// Sintaksa i semantika generatora nestabilna je i bit će joj potreban daljnji RFC za stabilizaciju.U ovom je trenutku sintaksa slična zatvaranju:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Više dokumentacije o generatorima može se naći u nestabilnoj knjizi.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Vrsta vrijednosti koju daje ovaj generator.
    ///
    /// Ovaj pridruženi tip odgovara izrazu `yield` i vrijednostima koje se smiju vraćati svaki put kad generator generira.
    ///
    /// Na primjer, iterator-kao-generator može vjerojatno imati ovaj tip kao `T`, tip koji se ponavlja.
    ///
    type Yield;

    /// Tip vrijednosti koju ovaj generator vraća.
    ///
    /// To odgovara tipu vraćenom iz generatora ili s `return` izrazom ili implicitno kao posljednji izraz literarnog generatora.
    /// Na primjer, futures bi ovo koristio kao `Result<T, E>` jer predstavlja dovršeni future.
    ///
    ///
    type Return;

    /// Nastavlja izvršenje ovog generatora.
    ///
    /// Ova će funkcija nastaviti s izvršavanjem generatora ili će započeti izvršenje ako već nije.
    /// Ovaj će se poziv vratiti u zadnju točku ovjesa generatora, nastavljajući s izvršenjem od najnovijeg `yield`.
    /// Generator će nastaviti izvršavati sve dok ne popušta ili se ne vrati, a u tom trenutku će se ova funkcija vratiti.
    ///
    /// # Povratna vrijednost
    ///
    /// Nabrajanje `GeneratorState` vraćeno iz ove funkcije pokazuje u kakvom je stanju generator po povratku.
    /// Ako se vrati varijanta `Yielded`, generator je dosegnuo točku ovjesa i odala se vrijednost.
    /// Generatori u ovom stanju dostupni su za kasnije ponovno pokretanje.
    ///
    /// Ako se vrati `Complete`, generator je u potpunosti završio s navedenom vrijednošću.Nevaljano je da se generator ponovo pokreće.
    ///
    /// # Panics
    ///
    /// Ova funkcija može panic ako je pozvana nakon što je prethodno vraćena inačica `Complete`.
    /// Iako su generatorski literali u jeziku zajamčeni za panic nakon nastavka nakon `Complete`, to nije zajamčeno za sve implementacije `Generator` Portrait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}