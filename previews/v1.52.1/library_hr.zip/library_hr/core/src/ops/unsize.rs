use crate::marker::Unsize;

/// Trait koji označava da je ovo pokazivač ili omot za jedan, pri čemu se može odrediti veličina na pokazivaču.
///
/// Pogledajte [DST coercion RFC][dst-coerce] i [the nomicon entry on coercion][nomicon-coerce] za više detalja.
///
/// Za ugrađene tipove pokazivača, pokazivači na `T` prisilit će se na pokazivače na `U` ako `T: Unsize<U>` pretvaranjem iz tankog pokazivača u masni pokazivač.
///
/// Za prilagođene tipove, prisila ovdje djeluje prisiljavanjem `Foo<T>` na `Foo<U>` pod uvjetom da postoji impl `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Takav impl može se napisati samo ako `Foo<T>` ima samo jedno polje koje nije fantomdata koje uključuje `T`.
/// Ako je vrsta tog polja `Bar<T>`, mora postojati implementacija `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Prisila će djelovati prisiljavanjem polja `Bar<T>` u `Bar<U>` i popunjavanjem ostalih polja iz `Foo<T>` kako bi se stvorio `Foo<U>`.
/// To će se učinkovito razbiti na polje pokazivača i prisiliti na to.
///
/// Općenito, za pametne pokazivače implementirat ćete `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, s opcijskim `?Sized` vezanim na sam `T`.
/// Za tipove omota koji izravno ugrađuju `T` poput `Cell<T>` i `RefCell<T>`, možete izravno implementirati `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// To će pustiti prisile vrsta poput `Cell<Box<T>>` da rade.
///
/// [`Unsize`][unsize] koristi se za označavanje tipova koji se mogu prisiliti na DST ako su iza pokazivača.Kompajler ga automatski implementira.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// To se koristi za sigurnost predmeta kako bi se provjerilo može li se poslati vrsta prijemnika metode.
///
/// Primjer implementacije Portrait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}