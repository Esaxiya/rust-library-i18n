/// Koristi se za nepromjenjive operacije preusmjeravanja, poput `*v`.
///
/// Osim što se koristi za eksplicitne operacije preusmjeravanja s operatorom (unary) `*` u nepromjenjivim kontekstima, u mnogim okolnostima i prevoditelj implicitno koristi `Deref`.
/// Taj se mehanizam naziva ['`Deref` coercion'][more].
/// U promjenjivim kontekstima koristi se [`DerefMut`].
///
/// Primjena `Deref` za pametne pokazivače čini pristup podacima iza njih praktičnim, zbog čega implementiraju `Deref`.
/// S druge strane, pravila koja se odnose na `Deref` i [`DerefMut`] dizajnirana su posebno za smještaj pametnih pokazivača.
/// Zbog toga bi **`Deref` trebao biti implementiran samo za pametne pokazivače** kako bi se izbjegla zabuna.
///
/// Iz sličnih razloga **ovaj Portrait nikada ne bi smio zakazati**.Neuspjeh tijekom preusmjeravanja može biti krajnje zbunjujući kad se implicitno poziva na `Deref`.
///
/// # Više o prisili `Deref`
///
/// Ako `T` implementira `Deref<Target = U>`, a `x` je vrijednost tipa `T`, tada:
///
/// * U nepromjenjivom kontekstu, `*x` (gdje `T` nije ni referenca ni neobrađeni pokazivač) ekvivalentan je `* Deref::deref(&x)`.
/// * Vrijednosti tipa `&T` prisiljavaju se na vrijednosti tipa `&U`
/// * `T` implicitno implementira sve (immutable) metode tipa `U`.
///
/// Za više detalja posjetite [the chapter in *The Rust Programming Language*][book], kao i referentne odjeljke o [the dereference operator][ref-deref-op], [method resolution] i [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktura s jednim poljem kojemu se može pristupiti dereferenciranjem strukture.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Dobiveni tip nakon preusmjeravanja.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Preusmjerava vrijednost.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Koristi se za izmjenjive operacije preusmjeravanja, kao u `*v = 1;`.
///
/// Osim što se koristi za eksplicitne operacije preusmjeravanja s operatorom (unary) `*` u promjenjivim kontekstima, u mnogim okolnostima i prevoditelj implicitno koristi `DerefMut`.
/// Taj se mehanizam naziva ['`Deref` coercion'][more].
/// U nepromjenjivim kontekstima koristi se [`Deref`].
///
/// Implementacija `DerefMut` za pametne pokazivače čini mutiranje podataka iza njih praktičnim, zbog čega implementiraju `DerefMut`.
/// S druge strane, pravila koja se odnose na [`Deref`] i `DerefMut` dizajnirana su posebno za smještaj pametnih pokazivača.
/// Zbog toga bi **`DerefMut` trebao biti implementiran samo za pametne pokazivače** kako bi se izbjegla zabuna.
///
/// Iz sličnih razloga **ovaj Portrait nikada ne bi smio zakazati**.Neuspjeh tijekom preusmjeravanja može biti krajnje zbunjujući kad se implicitno poziva na `DerefMut`.
///
/// # Više o prisili `Deref`
///
/// Ako `T` implementira `DerefMut<Target = U>`, a `x` je vrijednost tipa `T`, tada:
///
/// * U promjenjivim kontekstima, `*x` (gdje `T` nije ni referenca ni neobrađeni pokazivač) ekvivalentan je `* DerefMut::deref_mut(&mut x)`.
/// * Vrijednosti tipa `&mut T` prisiljavaju se na vrijednosti tipa `&mut U`
/// * `T` implicitno implementira sve (mutable) metode tipa `U`.
///
/// Za više detalja posjetite [the chapter in *The Rust Programming Language*][book], kao i referentne odjeljke o [the dereference operator][ref-deref-op], [method resolution] i [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktura s jednim poljem koja se može mijenjati dereferenciranjem strukture.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Promjenjiva vrijednost preusmjerava.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Označava da se struktura može koristiti kao prijemnik metode, bez značajke `arbitrary_self_types`.
///
/// To implementiraju stdlib tipovi pokazivača poput `Box<T>`, `Rc<T>`, `&T` i `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}