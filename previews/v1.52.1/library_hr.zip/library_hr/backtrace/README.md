# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Biblioteka za pribavljanje povratnih tragova u vrijeme izvođenja za Rust.
Cilj ove knjižnice je poboljšati podršku standardne knjižnice pružanjem programskog sučelja za rad, ali također podržava jednostavno ispisivanje trenutne povratne trage poput libstd-ove panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Da biste jednostavno uhvatili povratnu tragu i odgodili suočavanje s njom do kasnijeg vremena, možete upotrijebiti tip `Backtrace` najviše razine.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ako pak želite više neobrađenog pristupa stvarnoj funkcionalnosti praćenja, možete izravno koristiti funkcije `trace` i `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Riješite ovaj pokazivač uputa na ime simbola
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // nastavite na sljedeći kadar
    });
}
```

# License

Ovaj je projekt licenciran pod bilo kojim od

 * Apache licenca, verzija 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ili http://www.apache.org/licenses/LICENSE-2.0)
 * MIT licenca ([LICENSE-MIT](LICENSE-MIT) ili http://opensource.org/licenses/MIT)

po vašoj želji.

### Contribution

Ako izričito ne navedete drugačije, svaki vaš doprinos koji namjerno pošaljete na uvrštavanje u backtrace-rs, kako je definirano u licenci Apache-2.0, bit će dvostruko licenciran kao gore, bez ikakvih dodatnih uvjeta ili odredbi.







