use core::ffi::c_void;
use core::fmt;

/// Pregledava trenutni skup poziva, prolazeći sve aktivne okvire u zatvarač predviđen za izračunavanje traga stoga.
///
/// Ova je funkcija radna snaga ove knjižnice u izračunavanju tragova stogova za program.U zadanom zatvaranju `cb` dobiveni su primjerci `Frame` koji predstavljaju informacije o tom okviru poziva na stogu.
/// Zatvaranje daje okvire na način odozgo prema dolje (nedavno nazvani prvo funkcije).
///
/// Povratna vrijednost zatvaranja pokazatelj je treba li povratno praćenje nastaviti.Povratna vrijednost `false` zaustavit će povratno praćenje i odmah se vratiti.
///
/// Jednom kada se nabavi `Frame`, vjerojatno ćete htjeti nazvati `backtrace::resolve` kako biste `ip` (pokazivač uputa) ili adresu simbola pretvorili u `Symbol` putem kojeg se može saznati ime i/ili naziv datoteke/broj retka.
///
///
/// Imajte na umu da je ovo funkcija relativno niske razine i ako želite, na primjer, uhvatiti backtrace koji će se kasnije pregledati, tada je možda prikladniji tip `Backtrace`.
///
/// # Potrebne značajke
///
/// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
///
/// # Panics
///
/// Ova funkcija teži nikada panic, ali ako je `cb` pružio panics, tada će neke platforme prisiliti dvostruki panic da prekine postupak.
/// Neke platforme koriste C biblioteku koja interno koristi povratne pozive koji se ne mogu odmotati, pa panika iz `cb` može pokrenuti prekid postupka.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // nastavite s povratnim tragom
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Isto kao i `trace`, samo nesigurno jer je nesinkronizirano.
///
/// Ova funkcija nema garancije za sinkronizaciju, ali je dostupna kada značajka `std` ovog crate nije kompajlirana.
/// Pogledajte funkciju `trace` za više dokumentacije i primjera.
///
/// # Panics
///
/// Pogledajte informacije o `trace` za upozorenja o paničnosti `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Portrait koji predstavlja jedan okvir povratnog traga, ustupio je funkciji `trace` ovog crate.
///
/// Zatvaranje funkcije praćenja dobit će okvire, a okvir se gotovo šalje, jer temeljna implementacija nije uvijek poznata do vremena izvođenja.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Vraća trenutni pokazivač uputa ovog okvira.
    ///
    /// To je obično sljedeća uputa za izvršavanje u okviru, ali ne navode je sve implementacije sa 100% točnošću (ali općenito je prilično blizu).
    ///
    ///
    /// Preporučuje se prosljeđivanje ove vrijednosti `backtrace::resolve` da bi se pretvorilo u ime simbola.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Vraća trenutni pokazivač stoga ovog okvira.
    ///
    /// U slučaju da pozadina ne može oporaviti pokazivač stoga za ovaj okvir, vraća se null pokazivač.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Vraća početnu adresu simbola okvira ove funkcije.
    ///
    /// Ovo će pokušati premotati pokazivač uputa koji je `ip` vratio na početak funkcije, vraćajući tu vrijednost.
    ///
    /// U nekim će slučajevima, međutim, backendovi samo vratiti `ip` s ove funkcije.
    ///
    /// Vraćena vrijednost ponekad se može koristiti ako `backtrace::resolve` nije uspio na gore navedenom `ip`.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Vraća osnovnu adresu modula kojem pripada okvir.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // To mora biti na prvom mjestu, kako bi se osiguralo da Miri preuzima prednost nad glavnom platformom
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // samo se koristi u dbghelp simboliziraju
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}