//! Strategija simboliziranja pomoću koda za raščlanjivanje DWARF-a u libbacktraceu.
//!
//! Biblioteka libbacktrace C, koja se obično distribuira sa gcc, podržava ne samo generiranje povratnog traga (koji zapravo ne koristimo), već i simboliziranje povratnog traga i rukovanje informacijama o otklanjanju pogrešaka patuljaka o stvarima poput ugrađenih okvira i čega već.
//!
//!
//! Ovo je relativno komplicirano zbog puno raznih problema ovdje, ali osnovna ideja je:
//!
//! * Prvo zovemo `backtrace_syminfo`.Ovo dobiva informacije o simbolima iz dinamičke tablice simbola, ako možemo.
//! * Dalje zovemo `backtrace_pcinfo`.Ovo će raščlaniti debuginfo tablice ako su dostupne i omogućiti nam oporavak podataka o ugrađenim okvirima, imenima datoteka, brojevima linija itd.
//!
//! Puno je varki oko uvođenja patuljastih tablica u libbacktrace, ali nadamo se da to nije kraj svijeta i dovoljno je jasno kada pročitate u nastavku.
//!
//! Ovo je zadana strategija simboliziranja za platforme koje nisu MSVC i ne-OSX.U libstd-u je ovo zadana strategija za OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ako je moguće, preferirajte ime `function` koje dolazi iz debuginfoa, a obično može biti točnije za, na primjer, ugrađene okvire.
                // Ako toga nema, vratite se na ime tablice simbola navedeno u `symname`.
                //
                // Imajte na umu da se ponekad `function` može osjećati nešto manje precizno, na primjer da je naveden kao `try<i32,closure>` umjesto `std::panicking::try::do_call`.
                //
                // Nije stvarno jasno zašto, ali sveukupno ime `function` izgleda točnije.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // za sada ne raditi ništa
}

/// Tip pokazivača `data` prešao je u `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Jednom kada se ovaj povratni poziv pozove iz `backtrace_syminfo` kada započnemo rješavanje, idemo dalje na poziv `backtrace_pcinfo`.
    // Funkcija `backtrace_pcinfo` konzultirat će informacije o otklanjanju pogrešaka i pokušati izvršiti neke stvari poput oporavka informacija o file/line, kao i ugrađenih okvira.
    // Ipak imajte na umu da `backtrace_pcinfo` može uspjeti ili ne učiniti puno ako nema podataka o otklanjanju pogrešaka, pa ako se to dogodi, sigurno ćemo nazvati povratni poziv s barem jednim simbolom iz `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tip pokazivača `data` prešao je u `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace podržava stvaranje stanja, ali ne podržava uništavanje stanja.
// Osobno shvatam da to znači da se država treba stvoriti, a zatim živjeti vječno.
//
// Volio bih registrirati at_exit() rukovatelj koji čisti ovo stanje, ali libbacktrace ne pruža nikakav način za to.
//
// Uz ova ograničenja, ova funkcija ima statički predmemorirano stanje koje se izračunava prvi put kada se to zatraži.
//
// Ne zaboravite da se povratno praćenje svih događa serijski (jedna globalna brava).
//
// Imajte na umu da je ovdje nedostatak sinkronizacije zbog zahtjeva da se `resolve` sinkronizira izvana.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ne vježbajte sigurne niti mogućnosti libbacktracea jer ga uvijek nazivamo sinkronizirano.
        //
        0,
        error_cb,
        ptr::null_mut(), // bez dodatnih podataka
    );

    return STATE;

    // Imajte na umu da da bi libbacktrace uopće mogao raditi, potrebno je pronaći informacije o otklanjanju pogrešaka DWARF-a za trenutnu izvršnu datoteku.To obično čini putem brojnih mehanizama, uključujući, ali ne ograničavajući se na:
    //
    // * /proc/self/exe na podržanim platformama
    // * Ime datoteke je eksplicitno proslijeđeno prilikom stvaranja stanja
    //
    // Biblioteka libbacktrace velika je gomila C koda.To prirodno znači da ima sigurnosne propuste u memoriji, posebno kada se radi s neispravnim debuginfo.
    // Libstd je u prošlosti nailazio na puno takvih.
    //
    // Ako se koristi /proc/self/exe, tada ih obično možemo zanemariti jer pretpostavljamo da je libbacktrace "mostly correct", a inače ne radi čudne stvari s informacijama o otklanjanju pogrešaka patuljaka "attempted to be correct".
    //
    //
    // No, ako dodamo naziv datoteke, tada je to moguće na nekim platformama (poput BSD-ova) gdje zlonamjerni glumac može uzrokovati postavljanje proizvoljne datoteke na to mjesto.
    // To znači da ako kažemo libbacktrace o imenu datoteke, on možda koristi proizvoljnu datoteku, što može uzrokovati segfaults.
    // Ako ništa ne kažemo libbacktraceu, tada neće učiniti ništa na platformama koje ne podržavaju putove poput /proc/self/exe!
    //
    // S obzirom na sve što se trudimo što je više moguće da *ne* prenesemo naziv datoteke, ali to moramo učiniti na platformama koje uopće ne podržavaju /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Imajte na umu da bismo u idealnom slučaju koristili `std::env::current_exe`, ali ovdje ne možemo zahtijevati `std`.
            //
            // Upotrijebite `_NSGetExecutablePath` za učitavanje trenutne izvršne staze u statično područje (koje ako je premalo jednostavno odustanite).
            //
            //
            // Imajte na umu da ovdje ozbiljno vjerujemo libbacktraceu da neće umrijeti na oštećenim izvršnim datotekama, ali sigurno jest ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ima način otvaranja datoteka gdje se nakon otvaranja ne može izbrisati.
            // To je općenito ono što ovdje želimo jer želimo osigurati da se naša izvršna datoteka ne mijenja ispod nas nakon što je predamo na libbacktrace, nadam se da umanjujemo mogućnost prosljeđivanja proizvoljnih podataka u libbacktrace (što može biti pogrešno obrađeno).
            //
            //
            // S obzirom na to da ovdje pomalo plešemo kako bismo pokušali dobiti neku vrstu zaključavanja vlastite slike:
            //
            // * Dohvatite trenutni postupak, učitajte njegovo ime datoteke.
            // * Otvorite datoteku tom imenu s pravim zastavicama.
            // * Ponovno učitajte naziv datoteke trenutnog procesa, provjeravajući je li isti
            //
            // Ako je sve to prošlo, u teoriji smo doista otvorili datoteku našeg procesa i zajamčeno nam je da se to neće promijeniti.FWIW gomila toga je povijesno kopirana iz libstd-a, pa je ovo moje najbolje tumačenje onoga što se događalo.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ovo živi u statičkoj memoriji da bismo je mogli vratiti ..
                static mut BUF: [i8; N] = [0; N];
                // ... i ovo živi na hrpi jer je privremeno
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // namjerno procuri ovdje `handle` jer bi njegovo otvaranje trebalo sačuvati zaključavanje ovog naziva datoteke.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Želimo vratiti presjek koji je nul-završen, pa ako je sve popunjeno i jednako je ukupnoj duljini, onda to izjednačite s neuspjehom.
                //
                //
                // Inače, prilikom vraćanja uspjeha osigurajte da je nul bajt uključen u rez.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // pogreške povratnog traga trenutno su pometene pod tepih
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Pozovite `backtrace_syminfo` API koji (nakon čitanja koda) treba nazvati `syminfo_cb` točno jednom (ili ne uspije s vjerojatno pogreškom).
    // Tada obrađujemo više unutar `syminfo_cb`.
    //
    // Imajte na umu da to radimo jer će `syminfo` konzultirati tablicu simbola, pronalazeći imena simbola čak i ako u binarnom programu nema podataka za otklanjanje pogrešaka.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}