//! Podrška za simbolizaciju pomoću `gimli` crate na crates.io
//!
//! Ovo je zadana implementacija simbolizacije za Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'statični životni vijek laž je za hakiranje nedostatka podrške samoreferencijalnim strukturama.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Pretvori u 'statički životni vijek jer bi simboli trebali posuđivati samo `map` i `stash`, a mi ih čuvamo u nastavku.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Za učitavanje izvornih knjižnica na Windows, pogledajte nekoliko rasprava o rust-lang/rust#71060 za razne strategije ovdje.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW knjižnice trenutno ne podržavaju ASLR (rust-lang/rust#16514), ali DLL-ovi se i dalje mogu premjestiti u adresni prostor.
            // Čini se da su adrese u informacijama o otklanjanju pogrešaka kao da je ova knjižnica učitana na svom "image base", što je polje u zaglavljima datoteke COFF.
            // Budući da je to ono što čini da debuginfo navodi, analiziramo tablicu simbola i pohranjujemo adrese kao da je knjižnica učitana i na "image base".
            //
            // Knjižnica se možda neće učitati na "image base".
            // (vjerojatno se tamo može učitati nešto drugo?) Tu ulazi polje `bias`, a ovdje moramo shvatiti vrijednost `bias`.Nažalost, iako nije jasno kako to nabaviti iz učitanog modula.
            // Međutim, mi imamo stvarnu adresu učitavanja (`modBaseAddr`).
            //
            // Za sada smo malo kopirali datoteku, mapiramo datoteku, čitamo informacije o zaglavlju datoteke, a zatim ispuštamo datoteku mmap.To je rastrošno jer ćemo vjerojatno ponovno otvoriti mmap kasnije, ali ovo bi zasad trebalo raditi dovoljno dobro.
            //
            // Nakon što imamo `image_base` (željeno mjesto učitavanja) i `base_addr` (stvarno mjesto učitavanja), možemo ispuniti `bias` (razlika između stvarnog i željenog), a tada je navedena adresa svakog segmenta `image_base`, jer to kaže datoteka.
            //
            //
            // Za sada se čini da se za razliku od ELF/MachO možemo snaći s jednim segmentom po knjižnici, koristeći `modBaseSize` kao cijelu veličinu.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS koristi format datoteke Mach-O i koristi API-je specifične za DYLD za učitavanje popisa izvornih knjižnica koje su dio aplikacije.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Dohvatite naziv ove biblioteke koji odgovara putu do mjesta na kojem se također učitava.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Učitajte zaglavlje slike ove knjižnice i delegirajte u `object` da raščlanite sve naredbe učitavanja kako bismo mogli shvatiti sve ovdje uključene segmente.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Prelistavajte segmente i registrirajte poznate regije za segmente koje pronađemo.
            // Dodatno zabilježite segmente teksta o tekstu radi kasnije obrade, pogledajte komentare u nastavku.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Odredite "slide" za ovu knjižnicu, što na kraju predstavlja pristranost koju koristimo da bismo shvatili gdje su u memoriji učitani objekti.
            // Ovo je ipak pomalo čudno računanje i rezultat je pokušaja nekoliko stvari u divljini i gledanja što se lijepi.
            //
            // Općenita je ideja da će `bias` plus segment `stated_virtual_memory_address` biti tamo gdje u stvarnom adresnom prostoru segment boravi.
            // Druga stvar na koju se ipak oslanjamo je da je stvarna adresa minus `bias` indeks koji treba potražiti u tablici simbola i debuginfo.
            //
            // Ispostavilo se, međutim, da za sistemski učitane knjižnice ti izračuni nisu točni.Međutim, za izvorne izvršne datoteke to se čini ispravnim.
            // Podignuvši logiku iz izvora LLDB-a, ima posebno kućište za prvi odjeljak `__TEXT` učitan iz odmaka datoteke 0 s nula-veličinom.
            // Iz bilo kojeg razloga kada je ovo prisutno, čini se da znači da je tablica simbola u odnosu na samo vmaddr slajd za knjižnicu.
            // Ako *nije* prisutan, tada je tablica simbola u odnosu na vmaddr klizač plus navedenu adresu segmenta.
            //
            // Da bismo riješili ovu situaciju ako *ne* pronađemo tekstualni odjeljak s pomakom datoteke nula, tada povećavamo pristranost za navedenu adresu prvih tekstualnih odjeljaka, a smanjujemo i sve navedene adrese za taj iznos.
            //
            // Na taj se način tablica simbola uvijek pojavljuje u odnosu na iznos pristranosti knjižnice.
            // Čini se da ovo ima prave rezultate za simboliziranje putem tablice simbola.
            //
            // Iskreno, nisam posve siguran je li to točno ili postoji još nešto što bi trebalo ukazivati na to.
            // Čini se da za sada ovo djeluje dovoljno dobro (?) i trebali bismo to uvijek moći prilagoditi s vremenom ako je potrebno.
            //
            // Za neke dodatne informacije pogledajte #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Ostali Unix (npr
        // Linux) platforme koriste ELF kao format objektne datoteke i obično implementiraju API pod nazivom `dl_iterate_phdr` za učitavanje izvornih knjižnica.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` trebaju biti valjani pokazivači.
        // `vec` treba biti valjani pokazivač na `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ne podržava informacije o otklanjanju pogrešaka, ali sustav gradnje će informacije o uklanjanju pogrešaka postaviti na stazu `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Sve ostalo trebalo bi koristiti ELF, ali ne zna kako učitati matične knjižnice.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Sve poznate zajedničke knjižnice koje su učitane.
    libraries: Vec<Library>,

    /// Predmemorija mapiranja u kojoj zadržavamo raščlanjene patuljaste informacije.
    ///
    /// Ovaj popis ima fiksni kapacitet za cijelo vrijeme trajanja, koji se nikada ne povećava.
    /// `usize` element svakog para indeks je gornjeg `libraries` gdje `usize::max_value()` predstavlja trenutnu izvršnu datoteku.
    ///
    /// `Mapping` je odgovarajuća raščlanjena informacija o patuljcima.
    ///
    /// Imajte na umu da je ovo u osnovi LRU predmemorija i mi ćemo ovdje stvari mijenjati dok simboliziramo adrese.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmenti ove knjižnice učitani su u memoriju i tamo gdje su učitani.
    segments: Vec<LibrarySegment>,
    /// "bias" ove knjižnice, obično tamo gdje je učitana u memoriju.
    /// Ta se vrijednost dodaje navedenoj adresi svakog segmenta da bi se dobila stvarna adresa virtualne memorije u koju je segment učitan.
    /// Uz to, ova se pristranost oduzima od stvarnih adresa virtualne memorije za indeksiranje u debuginfo i tablicu simbola.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Navedena adresa ovog segmenta u datoteci objekta.
    /// To zapravo nije mjesto gdje je segment učitan, već je ova adresa plus `bias` koji sadrži biblioteku gdje ga možete pronaći.
    ///
    stated_virtual_memory_address: usize,
    /// Veličina tog segmenta u memoriji.
    len: usize,
}

// nesigurno jer je ovo potrebno za vanjsku sinkronizaciju
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // nesigurno jer je ovo potrebno za vanjsku sinkronizaciju
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Vrlo mala, vrlo jednostavna LRU predmemorija za mapiranje informacija o otklanjanju pogrešaka.
        //
        // Stopa učitavanja trebala bi biti vrlo visoka, jer tipični stog ne prekriva mnoge zajedničke knjižnice.
        //
        // Strukture `addr2line::Context` prilično su skupe za stvaranje.
        // Očekuje se da će njegov trošak amortizirati sljedeći `locate` upiti, koji koriste strukture izgrađene prilikom konstrukcije `addr2line: : Context`s da bi se postigle lijepe brze pripreme.
        //
        // Da nemamo ovu predmemoriju, ta amortizacija se nikad ne bi dogodila, a simboliziranje povratnih tragova bilo bi ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Prvo testirajte ima li ovaj `lib` bilo koji segment koji sadrži `addr` (rukovanje premještanjem).Ako ova provjera prođe, možemo nastaviti dolje i zapravo prevesti adresu.
                //
                // Imajte na umu da ovdje koristimo `wrapping_add` kako bismo izbjegli provjere prekoračenja.U divljini je viđeno da izračunavanje SVMA + pristranosti preplavljuje.
                // Čini se pomalo čudno što bi se dogodilo, ali ne možemo učiniti puno toga osim da vjerojatno samo ignoriramo te segmente jer oni vjerojatno usmjeravaju u svemir.
                //
                // Ovo se prvobitno pojavilo u rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Sad kad znamo da `lib` sadrži `addr`, možemo nadoknaditi pristranost kako bismo pronašli navedenu adresu virutalne memorije.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Nepromjenjivo: nakon završetka ovog uvjetnog uvjeta bez ranog vraćanja
        // zbog pogreške, unos predmemorije za ovaj put nalazi se na indeksu 0.

        if let Some(idx) = idx {
            // Kad je mapiranje već u predmemoriji, pomaknite ga naprijed.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Kada mapiranje nije u predmemoriji, izradite novo preslikavanje, umetnite ga u prednji dio predmemorije i po potrebi izbacite najstariji unos predmemorije.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ne propuštajte `'static` vijek trajanja, pobrinite se da je on obuhvaćen samo nama samima
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Produljite vijek trajanja `sym` na `'static`, jer smo nažalost ovdje obavezni, ali on se uvijek izlazi kao referenca, tako da se ionako više ne bi trebalo spominjati na njega.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Napokon, nabavite predmemorirano mapiranje ili izradite novo mapiranje za ovu datoteku i procijenite informacije o PATOLIKU kako biste pronašli file/line/name za ovu adresu.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Uspjeli smo pronaći podatke o okviru za ovaj simbol, a okvir `addr2line` interno sadrži sve glatke detalje.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Nismo mogli pronaći informacije o otklanjanju pogrešaka, ali pronašli smo ih u tablici simbola izvršne datoteke elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}