use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Riješite adresu simbolu, prenoseći simbol na određeno zatvaranje.
///
/// Ova će funkcija tražiti zadanu adresu u područjima kao što su lokalna tablica simbola, dinamička tablica simbola ili informacije o otklanjanju pogrešaka DWARF-a (ovisno o aktiviranoj implementaciji) kako bi pronašla simbole koji daju.
///
///
/// Zatvaranje se ne može zatražiti ako se razlučivanje ne može izvršiti, a može se zatražiti i više puta u slučaju ugrađenih funkcija.
///
/// Dati simboli predstavljaju izvršenje na navedenom `addr`, vraćajući parove file/line za tu adresu (ako je dostupna).
///
/// Imajte na umu da ako imate `Frame`, tada se preporučuje uporaba funkcije `resolve_frame` umjesto ove.
///
/// # Potrebne značajke
///
/// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
///
/// # Panics
///
/// Ova funkcija teži nikada panic, ali ako je `cb` pružio panics, tada će neke platforme prisiliti dvostruki panic da prekine postupak.
/// Neke platforme koriste C biblioteku koja interno koristi povratne pozive koji se ne mogu odmotati, pa panika iz `cb` može pokrenuti prekid postupka.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // pogledajte samo gornji okvir
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Riješite prethodno uhvaćeni okvir u simbol, prenoseći simbol u određeno zatvaranje.
///
/// Ovaj funktin obavlja istu funkciju kao i `resolve`, osim što uzima `Frame` kao argument umjesto adrese.
/// To može dopustiti nekim implementacijama povratne tragice da pruže točnije informacije o simbolima ili informacije o ugrađenim okvirima, na primjer.
///
/// Preporučuje se da ovo koristite ako možete.
///
/// # Potrebne značajke
///
/// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
///
/// # Panics
///
/// Ova funkcija teži nikada panic, ali ako je `cb` pružio panics, tada će neke platforme prisiliti dvostruki panic da prekine postupak.
/// Neke platforme koriste C biblioteku koja interno koristi povratne pozive koji se ne mogu odmotati, pa panika iz `cb` može pokrenuti prekid postupka.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // pogledajte samo gornji okvir
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP vrijednosti iz okvira steka obično su (always?) uputa *nakon* poziva koja je stvarni trag steka.
// Ako to simbolizira, filename/line broj je jedan ispred i možda u prazninu ako je pri kraju funkcije.
//
// Čini se da je to u osnovi uvijek slučaj na svim platformama, pa uvijek oduzmemo jedan od razriješenog ip-a da bismo ga riješili u prethodnu uputu za poziv umjesto da se uputa vraća.
//
//
// U idealnom slučaju ne bismo to učinili.
// Idealno bi bilo da ovdje pozivamo API-je `resolve` da ručno rade -1 i računaju da žele podatke o lokaciji za *prethodnu* uputu, a ne trenutnu.
// U idealnom slučaju također bismo izložili `Frame` ako smo doista adresa sljedeće upute ili trenutne.
//
// Za sada je to prilično zabrinjavajuće pitanje, pa ga samo interno uvijek oduzimamo.
// Potrošači bi trebali nastaviti raditi i postizati prilično dobre rezultate, pa bismo trebali biti dovoljno dobri.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Isto kao i `resolve`, samo nesigurno jer je nesinkronizirano.
///
/// Ova funkcija nema garancije za sinkronizaciju, ali je dostupna kada značajka `std` ovog crate nije kompajlirana.
/// Pogledajte funkciju `resolve` za više dokumentacije i primjera.
///
/// # Panics
///
/// Pogledajte informacije o `resolve` za upozorenja o paničnosti `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Isto kao i `resolve_frame`, samo nesigurno jer je nesinkronizirano.
///
/// Ova funkcija nema garancije za sinkronizaciju, ali je dostupna kada značajka `std` ovog crate nije kompajlirana.
/// Pogledajte funkciju `resolve_frame` za više dokumentacije i primjera.
///
/// # Panics
///
/// Pogledajte informacije o `resolve_frame` za upozorenja o paničnosti `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Portrait koji predstavlja razlučivost simbola u datoteci.
///
/// Ovaj Portrait dobiva se kao Portrait objekt za zatvaranje datom funkciji `backtrace::resolve`, a praktički se šalje jer je nepoznato koja implementacija stoji iza njega.
///
///
/// Simbol može dati kontekstualne informacije o funkciji, na primjer ime, naziv datoteke, broj retka, precizna adresa itd.
/// Nisu sve informacije uvijek dostupne u simbolu, pa sve metode vraćaju `Option`.
///
///
pub struct Symbol {
    // TODO: ovu životnu granicu treba zadržati na kraju do `Symbol`,
    // ali to je trenutno prelomna promjena.
    // Za sada je ovo sigurno jer se `Symbol` dijeli samo referencama i ne može se klonirati.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Vraća naziv ove funkcije.
    ///
    /// Vraćena struktura može se koristiti za ispitivanje različitih svojstava o imenu simbola:
    ///
    ///
    /// * Implementacija `Display` ispisat će demontirani simbol.
    /// * Može se pristupiti neobrađenoj vrijednosti `str` simbola (ako je valjana utf-8).
    /// * Može se pristupiti neobrađenim bajtovima imena simbola.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Vraća početnu adresu ove funkcije.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Vraća sirovo ime datoteke kao presjek.
    /// Ovo je uglavnom korisno za `no_std` okruženja.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Vraća broj stupca za mjesto gdje se ovaj simbol trenutno izvršava.
    ///
    /// Samo gimli trenutno pruža vrijednost ovdje, čak i tada samo ako `filename` vrati `Some`, pa je stoga podložan sličnim upozorenjima.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Vraća broj retka za mjesto gdje se ovaj simbol trenutno izvršava.
    ///
    /// Ova povratna vrijednost obično je `Some` ako `filename` vrati `Some`, pa je prema tome podložna sličnim upozorenjima.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Vraća naziv datoteke gdje je definirana ova funkcija.
    ///
    /// Ovo je trenutno dostupno samo kada se koristi libbacktrace ili gimli (npr
    /// unix platforme ostalo) i kada se binarni fajl kompajlira s debuginfo.
    /// Ako nijedan od ovih uvjeta nije zadovoljen, ovo će vjerojatno vratiti `None`.
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Možda raščlanjeni simbol C++ , ako raščlamba izopačenog simbola kao Rust nije uspjela.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Obavezno zadržite ovu nulu, tako da značajka `cpp_demangle` nema troškova kad je onemogućena.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Omotač oko imena simbola koji pruža ergonomske pristupe izmijenjenom imenu, sirovim bajtovima, sirovom nizu itd.
///
// Dopusti mrtvi kôd kada značajka `cpp_demangle` nije omogućena.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Stvara novo ime simbola od sirovih temeljnih bajtova.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Vraća sirovo ime (mangled) simbola kao `str` ako je simbol valjan utf-8.
    ///
    /// Koristite implementaciju `Display` ako želite demontiranu verziju.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Vraća sirovo ime simbola kao popis bajtova
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ovo bi se moglo ispisati ako demantirani simbol zapravo nije valjan, zato graciozno riješite pogrešku ovdje ne šireći je prema van.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Pokušaj povratka te predmemorirane memorije koja se koristi za simboliziranje adresa.
///
/// Ovom će se metodom pokušati osloboditi sve globalne strukture podataka koje su inače predmemorirane globalno ili u niti, a koje obično predstavljaju raščlanjene podatke o DWARF-u ili slično.
///
///
/// # Caveats
///
/// Iako je ova funkcija uvijek dostupna, ona zapravo ne čini ništa na većini implementacija.
/// Knjižnice poput dbghelp ili libbacktrace ne pružaju mogućnosti za uklanjanje stanja i upravljanje dodijeljenom memorijom.
/// Za sada je značajka `gimli-symbolize` ovog crate jedina značajka kod koje ova funkcija ima učinka.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}