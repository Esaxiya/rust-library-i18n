use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Prikaz posjedovane i samostalne povratne sprege.
///
/// Ova se struktura može koristiti za hvatanje povratnog traga u različitim točkama programa, a kasnije se koristi za provjeru kakva je povratna traga bila u to vrijeme.
///
///
/// `Backtrace` podržava prilično ispis povratnih tragova kroz svoju implementaciju `Debug`.
///
/// # Potrebne značajke
///
/// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Ovdje su okviri navedeni od vrha do dna stoga
    frames: Vec<BacktraceFrame>,
    // Indeks za koji vjerujemo da je stvarni početak povratnog praćenja, izostavljajući okvire poput `Backtrace::new` i `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Snimljena verzija okvira u backtraceu.
///
/// Ova vrsta vraća se kao popis s `Backtrace::frames` i predstavlja jedan okvir steka u zabilježenom backtraceu.
///
/// # Potrebne značajke
///
/// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Snimljena verzija simbola u backtraceu.
///
/// Ova vrsta vraća se kao popis s `BacktraceFrame::symbols` i predstavlja metapodatke za simbol u povratnom tragu.
///
/// # Potrebne značajke
///
/// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Snima povratni trag na pozivnom mjestu ove funkcije, vraćajući vlasnički prikaz.
    ///
    /// Ova je funkcija korisna za predstavljanje povratnog traga kao objekta u Rust.Ova vraćena vrijednost može se poslati preko niti i ispisati negdje drugdje, a svrha ove vrijednosti je da bude potpuno samostalna.
    ///
    /// Imajte na umu da na nekim platformama stjecanje potpune povratne kopije i njegovo rješavanje može biti izuzetno skupo.
    /// Ako je trošak previše za vašu aplikaciju, preporučuje se da umjesto toga koristite `Backtrace::new_unresolved()` koji izbjegava korak razlučivanja simbola (koji obično traje najduži) i omogućuje odgodu toga na kasniji datum.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // želim provjeriti postoji li ovdje okvir za uklanjanje
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Slično kao kod `new`, osim što ovo ne rješava nikakve simbole, ovo jednostavno bilježi povratne tragove kao popis adresa.
    ///
    /// Kasnije se može pozvati funkcija `resolve` za razrješavanje simbola ovog traga u čitljiva imena.
    /// Ova funkcija postoji jer postupak razrješavanja ponekad može potrajati značajno vrijeme, dok se bilo koja povratna kopija može rijetko ispisati.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // bez imena simbola
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // sada prisutna imena simbola
    /// ```
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    ///
    ///
    #[inline(never)] // želim provjeriti postoji li ovdje okvir za uklanjanje
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Vraća okvire iz vremena kad je snimljen ovaj backtrace.
    ///
    /// Prvi unos ove kriške vjerojatno je funkcija `Backtrace::new`, a posljednji okvir vjerojatno nešto o tome kako je započela ova nit ili glavna funkcija.
    ///
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Ako je ovaj povratni pravac stvoren od `new_unresolved`, tada će ova funkcija riješiti sve adrese u povratnom praćenju na njihova simbolična imena.
    ///
    ///
    /// Ako je ovaj povratni signal prethodno riješen ili je stvoren putem `new`, ova funkcija ne čini ništa.
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Isto kao i `Frame::ip`
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Isto kao i `Frame::symbol_address`
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Isto kao i `Frame::module_base_address`
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Vraća popis simbola kojima odgovara ovaj okvir.
    ///
    /// Obično postoji samo jedan simbol po okviru, ali ponekad se, ako je određeni broj funkcija umetnut u jedan okvir, vrati višestruki simbol.
    /// Prvi navedeni simbol je "innermost function", dok je posljednji simbol najudaljeniji (zadnji pozivatelj).
    ///
    /// Imajte na umu da će ovaj okvir vratiti prazan popis ako je došao iz neriješenog backtracea.
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Isto kao i `Symbol::name`
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Isto kao i `Symbol::addr`
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Isto kao i `Symbol::filename`
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Isto kao i `Symbol::lineno`
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Isto kao i `Symbol::colno`
    ///
    /// # Potrebne značajke
    ///
    /// Ova funkcija zahtijeva omogućavanje značajke `std` `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Kada ispisujemo staze, pokušavamo ukloniti cwd ako postoji, u suprotnom samo ispisujemo putanju kakva jest.
        // Imajte na umu da to također radimo samo za kratki format, jer ako je pun, vjerojatno želimo sve ispisati.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}