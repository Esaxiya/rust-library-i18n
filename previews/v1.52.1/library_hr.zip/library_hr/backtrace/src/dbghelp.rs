//! Modul za pomoć u upravljanju dbghelp vezama na Windows
//!
//! Povratni tragovi na Windows (barem za MSVC) uglavnom se napajaju putem `dbghelp.dll` i različitih funkcija koje sadrži.
//! Te se funkcije trenutno učitavaju *dinamički*, umjesto da se statički povezuju s `dbghelp.dll`.
//! To trenutno radi standardna knjižnica (i tamo je u teoriji to potrebno), ali pokušaj je smanjiti statičke DLL ovisnosti knjižnice, jer su povratne oznake obično prilično neobavezne.
//!
//! Usprkos tome, `dbghelp.dll` se gotovo uvijek uspješno učitava na Windows.
//!
//! Ipak, imajte na umu da budući da svu ovu podršku dinamički učitavamo, zapravo ne možemo koristiti sirove definicije u `winapi`, već radije moramo sami definirati tipove pokazivača funkcija i to koristiti.
//! Zapravo se ne želimo baviti dupliciranjem winapija, tako da imamo značajku Cargo `verify-winapi` koja tvrdi da se sve veze podudaraju s onima u winapiju, a ova je značajka omogućena na CI.
//!
//! Konačno, ovdje ćete primijetiti da se dll za `dbghelp.dll` nikada ne rasterećuje, a to je trenutno namjerno.
//! Razmišlja se da ga možemo globalno predmemorirati i koristiti između poziva API-ju, izbjegavajući skupi loads/unloads.
//! Ako je ovo problem za detektore curenja ili nešto slično, možemo prijeći most kad stignemo tamo.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Radite oko `SymGetOptions` i `SymSetOptions` koji nisu prisutni u samim winapijima.
// Inače se ovo koristi samo kada dvostruko provjeravamo vrste protiv winapija.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Još nije definirano u winapiju
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ovo je definirano u winapiju, ali nije točno (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Još nije definirano u winapiju
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Ova se makronaredba koristi za definiranje `Dbghelp` strukture koja interno sadrži sve pokazivače na funkcije koje bismo mogli učitati.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Učitani DLL za `dbghelp.dll`
            dll: HMODULE,

            // Svaki pokazivač funkcije za svaku funkciju koju bismo mogli koristiti
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // U početku nismo učitali DLL
            dll: 0 as *mut _,
            // Inicijalno su sve funkcije postavljene na nulu kako bi se reklo da ih treba dinamički učitavati.
            //
            $($name: 0,)*
        };

        // Pogodnost typedef za svaku vrstu funkcije.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Pokušaji otvaranja `dbghelp.dll`.
            /// Vraća uspjeh ako radi ili pogreška ako `LoadLibraryW` ne uspije.
            ///
            /// Panics ako je knjižnica već učitana.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funkcija za svaku metodu koju bismo željeli koristiti.
            // Kada se pozove, ili će pročitati predmemorirani pokazivač funkcije ili će ga učitati i vratiti učitanu vrijednost.
            // Opterećenja se tvrde da uspijevaju.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Praktični proxy za korištenje brava za čišćenje za upućivanje na funkcije dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicijalizirajte svu podršku potrebnu za pristup `dbghelp` API funkcijama s ovog crate.
///
///
/// Imajte na umu da je ova funkcija **sigurna**, interno ima vlastitu sinkronizaciju.
/// Također imajte na umu da je sigurno ovu funkciju pozivati više puta rekurzivno.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Prvo što moramo učiniti je sinkronizirati ovu funkciju.To se može pozvati istodobno iz drugih niti ili rekurzivno unutar jedne niti.
        // Imajte na umu da je to ipak zamršenije jer ono što ovdje koristimo, `dbghelp`,*također* mora biti sinkronizirano sa svim ostalim pozivima u `dbghelp` u ovom procesu.
        //
        // Tipično nema toliko puno poziva na `dbghelp` unutar istog postupka i vjerojatno možemo sigurno pretpostaviti da mu pristupamo samo mi.
        // Međutim, postoji još jedan primarni korisnik o kojem se moramo brinuti, što je ironično i sami, ali u standardnoj knjižnici.
        // Rust standardna knjižnica ovisi o ovom crate za podršku povratnog praćenja, a ova crate postoji i na crates.io.
        // To znači da ako se u standardnoj knjižnici ispisuje panic backtrace, ona se može utrkivati s ovim crate koji dolazi iz crates.io, što uzrokuje segfaults.
        //
        // Da bismo pomogli u rješavanju ovog problema sinkronizacije, ovdje koristimo trik specifičan za Windows (uostalom, to je ograničenje u vezi sa sinkronizacijom specifično za Windows).
        // Stvorimo *lokalno za sesije* imenovani mutex kako bismo zaštitili ovaj poziv.
        // Namjera je ovdje da standardna knjižnica i ovaj crate ne moraju dijeliti API-je na razini Rust da bi se ovdje sinkronizirali, već mogu raditi iza kulisa kako bi bili sigurni da se međusobno sinkroniziraju.
        //
        // Na taj način kada se ova funkcija poziva putem standardne knjižnice ili putem crates.io, možemo biti sigurni da se isti mutex dobiva.
        //
        // Dakle, sve to znači reći da prvo što ovdje radimo je da atomski stvorimo `HANDLE` koji je imenovani mutex na Windows.
        // Nekoliko sinkroniziramo s drugim nitima koje dijele ovu funkciju i osiguravamo da se stvori samo jedna ručka po instanci ove funkcije.
        // Imajte na umu da se ručica nikad ne zatvara kad se pohrani u globalu.
        //
        // Nakon što zapravo zaključamo, jednostavno je nabavljamo i naša ručka `Init` koju podijelimo bit će odgovorna za njezino ispuštanje.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, fuj!Sad kad smo svi sigurno sinkronizirani, krenimo zapravo s obradom.
        // Prvo moramo osigurati da je `dbghelp.dll` zapravo učitan u ovom procesu.
        // To radimo dinamički kako bismo izbjegli statičku ovisnost.
        // To je kroz povijest bilo zaobiđeno čudnim problemima povezivanja i ima za cilj učiniti binarne datoteke malo prijenosnijima, jer je ovo uglavnom samo uslužni program za otklanjanje pogrešaka.
        //
        //
        // Nakon što otvorimo `dbghelp.dll`, u njemu moramo pozvati neke funkcije inicijalizacije, a to je detaljnije detaljnije u nastavku.
        // No to radimo samo jednom, tako da imamo globalnu logičku vrijednost koja pokazuje jesmo li već gotovi ili nismo.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Obavezno postavite zastavicu `SYMOPT_DEFERRED_LOADS`, jer prema MSVC-ovim vlastitim dokumentima o ovome: "This is the fastest, most efficient way to use the symbol handler.", učinimo to!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Zapravo inicijalizirajte simbole MSVC-om.Imajte na umu da ovo može zakazati, ali mi to zanemarujemo.
        // Za to ne postoji tona stanja tehnike, ali čini se da LLVM ovdje zanemaruje povratnu vrijednost, a jedna od knjižnica dezinficijensa u LLVM-u ispisuje zastrašujuće upozorenje ako to ne uspije, ali u osnovi ga dugoročno ignorira.
        //
        //
        // Jedan slučaj koji se puno pojavljuje za Rust jest da se standardna knjižnica i ovaj crate na crates.io žele natjecati za `SymInitializeW`.
        // Standardna je knjižnica u prošlosti većinu vremena željela inicijalizirati, a zatim očistiti, ali sada kada koristi ovaj crate znači da će netko prvo doći do inicijalizacije, a druga će pokrenuti tu inicijalizaciju.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}