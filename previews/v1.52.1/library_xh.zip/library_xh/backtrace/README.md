# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Ithala leencwadi lokufumana umva ngexesha lokubaleka le Rust.
Eli thala leencwadi lijolise ekuphuculeni inkxaso yelayibrari esemgangathweni ngokubonelela ngenkqubo yenkqubo yokusebenza nayo, kodwa ikwaxhasa ngokulula ukuprinta umva wangoku njenge-libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Ukubamba nje umva kunye nokuyeka ukujongana nayo kude kube lixesha elizayo, ungasebenzisa uhlobo olukumgangatho ophezulu we `Backtrace`.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ukuba, nangona kunjalo, ungathanda ukufikelela kokuluhlaza ngakumbi kulwenziwo lomsebenzi, ungasebenzisa imisebenzi ye `trace` kunye ne `resolve` ngokuthe ngqo.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Sombulula esi sikhombisi somyalelo kwigama lesimboli
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // qhubeka uye kwisakhelo esilandelayo
    });
}
```

# License

Le projekthi inelayisensi phantsi kwayo nayiphi na

 * I-Apache License, Inguqulelo 2.0, ([LICENSE-APACHE](LICENSE-APACHE) okanye http://www.apache.org/licenses/LICENSE-2.0)
 * MIT ilayisensi ([LICENSE-MIT](LICENSE-MIT) okanye http://opensource.org/licenses/MIT)

ngokhetho lwakho.

### Contribution

Ngaphandle kokuba uchaze ngenye indlela, nayiphi na igalelo elingeniswe ngabom ukuze lifakwe kwi-backtrace-rs nguwe, njengoko kuchaziwe kwilayisensi ye-Apache-2.0, iya kuba nelayisensi ezimbini njengasentla, ngaphandle kwemigaqo okanye iimeko ezongezelelweyo.







