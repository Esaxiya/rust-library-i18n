use core::ffi::c_void;
use core::fmt;

/// Ihlola ingqokelela yomnxeba wangoku, idlulisa zonke izakhelo ezisebenzayo kuvalo olunikiweyo ukubala umkhondo wesitaki.
///
/// Lo msebenzi ngumsebenzi wethala leencwadi ekubaleni umkhondo wenkqubo.Ukuvalwa okunikiweyo i `cb` kuvelise iimeko ze `Frame` ezimele ulwazi malunga nesakhelo somnxeba kwisitaki.
/// Ukuvalwa kuveliswa kwizakhelo kwifashoni esezantsi (esandula ukubizwa ngokuba yimisebenzi kuqala).
///
/// Ixabiso lokubuya lokuvalwa luphawu lokuba umva wasemva kufuneka uqhubeke.Ixabiso elibuyayo le `false` liza kuphelisa umva wokubuyela umva kwaye libuye kwangoko.
///
/// Nje ukuba ifunyenwe i `Frame` uyakufuna ukubiza i `backtrace::resolve` ukuguqula i `ip` (isikhombisi somyalelo) okanye idilesi yesimboli ibe yi `Symbol` apho igama kunye/okanye igama lefayile/inombolo yomgca inokufundwa khona.
///
///
/// Qaphela ukuba lo ngumsebenzi okwinqanaba elisezantsi kwaye ukuba ungathanda, umzekelo, ukufaka i-backtrace ukuze ihlolwe kamva, emva koko uhlobo lwe `Backtrace` lunokufaneleka ngakumbi.
///
/// # Iimpawu ezifunekayo
///
/// Lo msebenzi ufuna inqaku le `std` le `backtrace` crate ukuba yenziwe, kwaye inqaku le `std` linikwe amandla ngokungagqibekanga.
///
/// # Panics
///
/// Lo msebenzi uzama ukungaze ube yi-panic, kodwa ukuba i-`cb` ibonelele nge-panics ke amanye amaqonga aya kunyanzela i-panic ephindwe kabini ukuyikhupha inkqubo.
/// Amanye amaqonga asebenzisa ithala leencwadi le-C elisebenzisa ngaphakathi ukubuyela umva elingenakulungiswa, ngenxa yokoyikeka kwi `cb` kunokubangela inkqubo ikhuphe isisu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // qhubela phambili ngasemva
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Iyafana ne `trace`, kuphela ayikhuselekanga njengoko ingahambelani.
///
/// Lo msebenzi awunazo ii-guarantee zokungqamanisa kodwa uyafumaneka xa inqaku le `std` lale crate lingahlangananga ngaphakathi.
/// Jonga umsebenzi we `trace` ngamaxwebhu ngakumbi kunye nemizekelo.
///
/// # Panics
///
/// Jonga ulwazi kwi-`trace` yeepavela kwi-`cb` panicking.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// I-trait emele isakhelo esinye sasemva komva, ivelise umsebenzi we `trace` wale crate.
///
/// Ukuvalwa komsebenzi wokulandela umkhondo kuya kuba nezakhelo ezivelisiweyo, kwaye isakhelo siphantse sithunyelwe njengoko ukumiliselwa kwesiseko kungasoloko kusaziwa kude kube lixesha lokusebenza.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Ibuyisela isikhombisi somyalelo wangoku wale freyimu.
    ///
    /// Ngokwesiqhelo lo ngumyalelo olandelayo wokuphumeza kwisakhelo, kodwa ayizizo zonke iindlela zokuphunyezwa koku ngokuchaneka kwe-100% (kodwa ngokusondeleyo kufutshane).
    ///
    ///
    /// Kuyacetyiswa ukuba kudluliswe eli xabiso ukuya kwi `backtrace::resolve` ukuyiguqula ibe ligama lesimboli.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Ibuyisela isikhombisi sangoku sesakhelo.
    ///
    /// Kwimeko apho isiphelo esingasemva asinakho ukuphinda sifumane isikhombisi sesitayile, esi sikhombisi sibuyiselweyo.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Ibuyisela idilesi yesimboli yesakhelo salo msebenzi.
    ///
    /// Oku kuyakuzama ukubuyisela umva kwisikhombisi somyalelo esibuyiswe ngu `ip` ekuqaleni komsebenzi, sibuyisela elo xabiso.
    ///
    /// Ngamanye amaxesha, nangona kunjalo, ukubuyela umva kuya kubuyisa i `ip` kulo msebenzi.
    ///
    /// Ixabiso elibuyisiweyo ngamanye amaxesha linokusetyenziswa ukuba i `backtrace::resolve` isilele kwi `ip` enikwe apha ngasentla.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Ibuyisela idilesi yesiseko yemodyuli ekuyo isakhelo.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Oku kufuneka kufike kuqala, ukuqinisekisa ukuba uMiri uthatha indawo ephambili ngaphezulu kweqonga lomamkeli
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // isetyenziswa kuphela kwisimboli ye-dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}