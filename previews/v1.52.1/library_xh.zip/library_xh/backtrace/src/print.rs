#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Ifomathi yokubuyela umva.
///
/// Olu hlobo lungasetyenziselwa ukuprinta i-backtrace nokuba ujongisa phi umva ngokwawo.
/// Ukuba unohlobo lwe `Backtrace` emva koko ukumiliselwa kwe `Debug` sele isebenzisa le fomathi yokushicilela.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Iindlela zokuprinta esinokuziprinta
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Kuprintwa ukubuyela umva kweterser okuqulathe kuphela ulwazi olufanelekileyo
    Short,
    /// Kuprinta umva osezantsi oqulathe lonke ulwazi olunokwenzeka
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Yenza i `BacktraceFmt` entsha eya kuthi ibhale imveliso kwi `fmt` ebonelelweyo.
    ///
    /// Ingxoxo ye `format` iya kulawula isitayile apho i-backtrace iprintwe khona, kwaye ingxoxo ye-`print_path` iya kusetyenziselwa ukuprinta iimeko ze-`BytesOrWideString` zamagama efayile.
    /// Olu hlobo ngokwalo alwenzi naluphi na ushicilelo lwamagama efayile, kodwa oku kubuyela emva kuyadingeka ukwenza njalo.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Ishicilela intshayelelo yomqolo wangasemva malunga noshicilelo.
    ///
    /// Oku kuyadingeka kumaqonga athile okubuyela umva ukuze abonakaliswe ngokupheleleyo kamva, kwaye ngapha koko oku kunokuba yindlela yokuqala oyitsalelayo emva kokwenza i `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Yongeza isakhelo kwimveliso yokubuyela umva.
    ///
    /// Ukuzibophelela kubuyisela imeko ye-RAII ye `BacktraceFrameFmt` enokusetyenziselwa ukuprinta isakhelo, kwaye kwintshabalalo iya kunyusa isakhelo sokubala.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Kugqitywa imveliso engasemva.
    ///
    /// Okwangoku akukho-op kodwa yongezwa ngokuhambelana kwe future kunye neefomathi zendlela yokubuyela umva.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Okwangoku akukho-op-kubandakanya le hook ukuvumela ukongezwa kwe future.
        Ok(())
    }
}

/// Ifomathi yesakhelo esinye sokubuyela umva.
///
/// Olu hlobo lwenziwe ngumsebenzi we `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Shicilela i `BacktraceFrame` ngale fomathi yesakhelo.
    ///
    /// Oku kuyakuprinta kwakhona zonke iimeko ze `BacktraceSymbol` ngaphakathi kwe `BacktraceFrame`.
    ///
    /// # Iimpawu ezifunekayo
    ///
    /// Lo msebenzi ufuna inqaku le `std` le `backtrace` crate ukuba yenziwe, kwaye inqaku le `std` linikwe amandla ngokungagqibekanga.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Ishicilela i `BacktraceSymbol` ngaphakathi kwe `BacktraceFrame`.
    ///
    /// # Iimpawu ezifunekayo
    ///
    /// Lo msebenzi ufuna inqaku le `std` le `backtrace` crate ukuba yenziwe, kwaye inqaku le `std` linikwe amandla ngokungagqibekanga.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ayisiyonto intle ukuba asigqibi kuprinta nantoni na
            // ngamagama angenawo e-utf8.
            // Ngombulelo phantse yonke into iyi-utf8 ke oku akufuneki kube kubi kakhulu.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Kuprintwa i-`Frame` kunye ne-`Symbol` eluhlaza ekroliweyo, evela ngaphakathi kwi-callbacks eluhlaza zale crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Yongeza isakhelo esiluhlaza kwimveliso engasemva.
    ///
    /// Le ndlela, ngokungafaniyo neyangaphambili, ithatha iingxoxo eziluhlaza xa zinokuvela kwiindawo ezahlukeneyo.
    /// Qaphela ukuba oku kungabizwa amaxesha amaninzi kwisakhelo esinye.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Yongeza isakhelo esiluhlaza kwimveliso engasemva, kubandakanya ulwazi lwekholamu.
    ///
    /// Le ndlela, njengangaphambili, ithatha iimpikiswano ezingalunganga xa zisuka kwiindawo ezahlukeneyo.
    /// Qaphela ukuba oku kungabizwa amaxesha amaninzi kwisakhelo esinye.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // I-Fuchsia ayinakho ukufuzisela ngaphakathi kwenkqubo ke inefomathi ekhethekileyo enokusetyenziselwa ukufuzisela kamva.
        // Phrinta endaweni yokushicilela iidilesi kwifomathi yethu apha.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Akukho sidingo sokuprinta izakhelo ze-"null", ngokusisiseko kuthetha nje ukuba inkqubo yokubuyela umva ibinomdla wokufumana umva kakhulu.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Ukunciphisa ubungakanani be-TCB kwi-Sgx enclave, asifuni ukumilisela ukusebenza kwesisombululo.
        // Endaweni yoko, sinokuprinta iseti yedilesi apha, enokuthi kamva yenziwe imephu ukulungisa umsebenzi.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Phrinta isalathiso sesakhelo kunye nesikhombisi somyalelo wesakhelo.
        // Ukuba singaphaya kophawu lokuqala lwesakhelo nangona siprinta indawo emhlophe efanelekileyo.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Emva koko bhala igama lesimboli, usebenzisa enye indlela yokufomatha ngolwazi oluthe kratya ukuba sibuyela umva ngokupheleleyo.
        // Apha siphatha iisimboli ezingenamagama,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Kwaye okokugqibela, phrinta inombolo ye filename/line ukuba ziyafumaneka.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line zishicilelwe kwimigca phantsi kwegama lesimboli, ke phrinta indawo emhlophe efanelekileyo ukuhlela ulungelelwaniso lwasekunene.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Thumela kubizo lwethu lwangaphakathi ukuphinda uprinte igama lefayile kwaye uprinte inombolo yomgca.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Yongeza inombolo yekholamu, ukuba ikhona.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Sikhathalela kuphela uphawu lokuqala lwesakhelo
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}