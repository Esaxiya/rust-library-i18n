//! Imodyuli yokuncedisa ekulawuleni izibophelelo ze-dbghelp kwi Windows
//!
//! Imva yokubuyela emva kwi Windows (ubuncinci kwi-MSVC) ixhotyiswe kakhulu nge `dbghelp.dll` kunye nemisebenzi eyahlukeneyo equlathe kuyo.
//! Le misebenzi ngoku ilayishwe * ngamandla ngaphandle kokudibanisa kwi `dbghelp.dll` ngokwezibalo.
//! Okwangoku kwenziwa kwilayibrari esemgangathweni (kwaye ithiyori iyafuneka apho), kodwa ngumzamo wokunceda ukunciphisa ukuxhomekeka kwe-static dll kwilayibrari kuba umva wangasemva uhlala ulungile.
//!
//! Oko bekutshiwo, i-`dbghelp.dll` phantse ihlala ilayisha ngempumelelo kwi Windows.
//!
//! Qaphela nangona oko kuba silayisha yonke le nkxaso ngamandla asinakho ukusebenzisa iinkcazo eziluhlaza kwi `winapi`, kodwa endaweni yoko kufuneka sichaze iintlobo zesikhombisi somsebenzi ngokwethu kwaye sizisebenzise.
//! Asifuni ngokwenene ukuba sikwishishini lokuphinda-phinda i-winapi, ngenxa yoko sine-Cargo inqaku le-`verify-winapi` eliqinisekisa ukuba konke ukubopha kuyangqinelana ne-winapi kwaye eli nqaku linikwe amandla kwi-CI.
//!
//! Okokugqibela, uya kuqaphela apha ukuba i-dll ye `dbghelp.dll` ayikaze ikhutshelwe, kwaye kungoku nje oku kuyinjongo.
//! Ukucinga kukuba sinokuyigcina kwihlabathi liphela kwaye siyisebenzise phakathi kweefowuni ezikwi-API, kuthintela i loads/unloads ebizayo.
//! Ukuba le yingxaki kubavavanyi abavuzayo okanye into enjalo sinokuwela ibhulorho xa sifika apho.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Sebenza ujikeleze i `SymGetOptions` kunye ne `SymSetOptions` ungabikho kwi-winapi uqobo.
// Ngaphandle koko oku kusetyenziswa kuphela xa sijonga iintlobo ezimbini ngokuchasene ne-winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ayichazwanga kwi-winapi okwangoku
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Oku kuchaziwe kwi-winapi, kodwa ayilunganga (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ayichazwanga kwi-winapi okwangoku
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Le macro isetyenziselwa ukuchaza ubume be `Dbghelp` equlathe ngaphakathi zonke izikhombisi zomsebenzi esinokuzilayisha.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// I-DLL elayishiwe ye `dbghelp.dll`
            dll: HMODULE,

            // Isikhombisi somsebenzi ngasinye somsebenzi ngamnye esinokuwusebenzisa
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Ekuqaleni khange siyilayishe i-DLL
            dll: 0 as *mut _,
            // Qalisa yonke imisebenzi icwangciselwe u-zero ukuba ithi kufuneka ilayishwe ngamandla.
            //
            $($name: 0,)*
        };

        // I-typedef elula yohlobo ngalunye lomsebenzi.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Imizamo yokuvula i `dbghelp.dll`.
            /// Ibuyisa impumelelo ukuba iyasebenza okanye impazamo ukuba i `LoadLibraryW` iyasilela.
            ///
            /// Panics ukuba ilayibrari sele ilayishiwe.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Umsebenzi wendlela nganye esingathanda ukuyisebenzisa.
            // Xa ibizwa ngokuba iya kufunda isalathi somsebenzi esigciniweyo okanye siyilayishe kwaye sibuyise ixabiso elilayishiwe.
            // Imithwalo inyanzeliswa ukuba iphumelele.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Uncedo lokumela ukusebenzisa isitshixo sokucoca ukubhekisa kwimisebenzi ye-dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Qalisa yonke inkxaso eyimfuneko ukufikelela kwimisebenzi ye-`dbghelp` API kule crate.
///
///
/// Qaphela ukuba lo msebenzi ukhuselekile **, ngaphakathi ungqamaniso lwawo.
/// Qaphela ukuba kukhuselekile ukubiza lo msebenzi amaxesha ngamaxesha ukuphindaphinda.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Into yokuqala ekufuneka siyenzile kukudibanisa lo msebenzi.Oku kunokubizwa ngaxeshanye kweminye imisonto okanye ukuphinda-phinda ngaphakathi kumsonto omnye.
        // Qaphela ukuba kunzima kunokuba kunjalo kuba le nto siyisebenzisa apha, i `dbghelp`,*nayo* ifuna ukungqinelaniswa nabo bonke abanye abafowunela i `dbghelp` kule nkqubo.
        //
        // Ngokwesiqhelo azikho ngokwenene iifowuni ezininzi eziya kwi `dbghelp` ngaphakathi kwenkqubo enye kwaye sinokucinga ngokukhuselekileyo ukuba kuphela kwethu ukufikelela kuyo.
        // Kukho, nangona kunjalo, omnye umsebenzisi oyintloko kufuneka sizixhalabise ngokuba yeyiphi na eyindida, kodwa kwilayibrari esemgangathweni.
        // Ithala leencwadi eliqhelekileyo le-Rust lixhomekeke kule crate yenkxaso yokubuyela umva, kwaye le crate ikwakhona kwi crates.io.
        // Oku kuthetha ukuba ukuba ilayibrari esemgangathweni ishicilela umva we-panic inokubaleka nale crate ivela kwi crates.io, ibangele ukungafani.
        //
        // Ukunceda ukusombulula le ngxaki yokuvumelanisa sisebenzisa iqhinga elithile leWindows apha (emva kwayo yonke loo nto, sisithintelo esithile seWindows malunga nokuvumelanisa).
        // Senza *iseshoni-yendawo* ebizwa ngokuba yi-mutex ukukhusela le fowuni.
        // Injongo apha kukuba ithala leencwadi eliqhelekileyo kunye nale crate akufuneki babelane nge-Rust-level APIs ukuvumelanisa apha kodwa endaweni yoko banokusebenza emva kwezigcawu ukuqinisekisa ukuba bayangqinelana.
        //
        // Ngale ndlela xa lo msebenzi ubizwa kwilayibrari esemgangathweni okanye nge crates.io sinokuqiniseka ukuba i-mutex efanayo iyafunyanwa.
        //
        // Ke konke oko kukuthi into yokuqala esiyenzayo apha senza i-`HANDLE` ebizwa ngokuba yi-mutex kwi-Windows.
        // Singqamanisa kancinci kunye neminye imisonto ekwabelana ngalo msebenzi ngokukodwa kwaye siqinisekisa ukuba sinye kuphela isiphatho esenziweyo ngokomzekelo walo msebenzi.
        // Qaphela ukuba isiphatho asikaze sivalwe nje ukuba sigcinwe kwilizwe jikelele.
        //
        // Emva kokuba sihambe ngokwenyani siyifumana ngokulula, kwaye isiphatho sethu se `Init` esisinikileyo siya kuba noxanduva lokusiyeka ekugqibeleni.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Kulungile, phew!Ngoku sonke sihambelane ngokukhuselekileyo, masiqale ngokuqhubekeka yonke into.
        // Okokuqala kufuneka siqinisekise ukuba i `dbghelp.dll` ilayishiwe kule nkqubo.
        // Senza oku ngamandla ukuze sinqande ukuxhomekeka okumileyo.
        // Oku bekusenziwa ngokwembali ukuze kusetyenzwe malunga nemicimbi yokudibanisa engaqhelekanga kwaye ijolise ekwenzeni i-binaries ibe nokuphatheka ngakumbi kuba oku ikakhulu kuluncedo lokulungisa ingxaki.
        //
        //
        // Nje ukuba sivule i `dbghelp.dll` kufuneka sibize eminye imisebenzi yokuqalisa kuyo, kwaye loo nto ichazwe ngakumbi ngezantsi.
        // Senza oku kube kanye kuphela, nangona kunjalo, sinesiphelo sehlabathi esibonisa ukuba sigqibile okwangoku okanye hayi.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Qinisekisa ukuba iflegi ye `SYMOPT_DEFERRED_LOADS` imisiwe, kuba ngokwamaxwebhu e-MSVC malunga noku: "This is the fastest, most efficient way to use the symbol handler.", ke masiyenze loo nto!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Ngokwenyani qalisa iisimboli ngeMSVC.Qaphela ukuba oku kuyasilela, kodwa asihoyi.
        // Akukho toni yobugcisa bangaphambili kule nto nganye, kodwa i-LLVM ngaphakathi ibonakala ngathi ayihoyi ixabiso lokubuya apha kwaye elinye lamathala eencwadi acocekileyo kwi-LLVM lishicilela isilumkiso esoyikisayo ukuba oku kuyasilela kodwa kukungakuhoyi ekuhambeni kwexesha.
        //
        //
        // Ityala elinye oku kuza kakhulu kwi-Rust kukuba ilayibrari esemgangathweni kwaye le crate kwi crates.io bobabini bafuna ukukhuphisana nge `SymInitializeW`.
        // Ithala leencwadi eliqhelekileyo ngokwembali lalifuna ukuqalisa emva koko licoce ixesha elininzi, kodwa ngoku xa lisebenzisa i-crate oko kuthetha ukuba umntu uza kuqala kuqala kwaye enye iya kuthatha oko kuqaliswa.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}