// isetyenziswe kuphela kwi Linux ngoku, ke vumela ikhowudi efileyo kwenye indawo
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Indawo elula eyabelwe i-byte buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Yabela isikhululo sesilinganisi sobungakanani obuchaziweyo kwaye ibuyisele isalathiso esinokuguqulwa kuyo.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // UKHUSELEKO: lo kuphela komsebenzi owakha wakwazi ukutshintsha
        // isalathiso se `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // UKHUSELEKO: asisoze sisuse izinto kwi `self.buffers`, ke ireferensi
        // kwidatha engaphakathi kuyo nayiphi na i-buffer iya kuhlala ixesha elide njenge `self`.
        &mut buffers[i]
    }
}