use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Sombulula idilesi kwisimboli, udlulise isimboli kuvalo oluchaziweyo.
///
/// Lo msebenzi uza kujonga idilesi enikiweyo kwiindawo ezinje ngetheyibhile yesimboli yendawo, itafile yesimboli eshukumayo, okanye ulwazi lwe-DWARF lokulungisa ingxaki (kuxhomekeke kulwenziwo olusebenzayo) ukufumana iisimboli zokuvelisa.
///
///
/// Ukuvalwa akunakubizwa ukuba isisombululo asinakwenziwa, kwaye sinokubizwa ngaphezu kwesinye kwimeko yemisebenzi emiselweyo.
///
/// Iimpawu ezivelisiweyo zimele ukwenziwa kwi-`addr` echaziweyo, ibuyisa i-file/line ngazibini kuloo dilesi (ukuba iyafumaneka).
///
/// Qaphela ukuba une `Frame` kuyacetyiswa ukuba usebenzise umsebenzi we `resolve_frame` endaweni yale.
///
/// # Iimpawu ezifunekayo
///
/// Lo msebenzi ufuna inqaku le `std` le `backtrace` crate ukuba yenziwe, kwaye inqaku le `std` linikwe amandla ngokungagqibekanga.
///
/// # Panics
///
/// Lo msebenzi uzama ukungaze ube yi-panic, kodwa ukuba i-`cb` ibonelele nge-panics ke amanye amaqonga aya kunyanzela i-panic ephindwe kabini ukuyikhupha inkqubo.
/// Amanye amaqonga asebenzisa ithala leencwadi le-C elisebenzisa ngaphakathi ukubuyela umva elingenakulungiswa, ngenxa yokoyikeka kwi `cb` kunokubangela inkqubo ikhuphe isisu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // jonga kuphela kwisakhelo esiphezulu
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Sombulula isakhelo sokubamba sangaphambili kwisimboli, ugqithise isimboli kuvalo oluchaziweyo.
///
/// Le functin yenza umsebenzi ofanayo ne `resolve` ngaphandle kokuba ithatha i `Frame` njengengxoxo endaweni yedilesi.
/// Oku kunokuvumela ukumiliselwa kweqonga lokubuyela umva ukubonelela ngolwazi oluchanekileyo lweesimboli okanye ulwazi malunga nezakhelo ezisemgceni umzekelo.
///
/// Kuyacetyiswa ukuba usebenzise oku ukuba unako.
///
/// # Iimpawu ezifunekayo
///
/// Lo msebenzi ufuna inqaku le `std` le `backtrace` crate ukuba yenziwe, kwaye inqaku le `std` linikwe amandla ngokungagqibekanga.
///
/// # Panics
///
/// Lo msebenzi uzama ukungaze ube yi-panic, kodwa ukuba i-`cb` ibonelele nge-panics ke amanye amaqonga aya kunyanzela i-panic ephindwe kabini ukuyikhupha inkqubo.
/// Amanye amaqonga asebenzisa ithala leencwadi le-C elisebenzisa ngaphakathi ukubuyela umva elingenakulungiswa, ngenxa yokoyikeka kwi `cb` kunokubangela inkqubo ikhuphe isisu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // jonga kuphela kwisakhelo esiphezulu
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Amaxabiso e-IP avela kwizakhelo zesitaki ngesiqhelo yi-(always?) imiyalelo *emva* komnxeba ngowona kanye umkhondo wokugcina.
// Ukufuzisela oku kubangela ukuba inani le-filename/line libe linye ngaphambili kwaye mhlawumbi liye kungenanto ukuba lisondele esiphelweni somsebenzi.
//
// Oku kubonakala ngathi kuhlala kunjalo kwimeko kuwo onke amaqonga, ke sihlala sikhupha enye kwi-ip esonjululwe ukuyisombulula kumyalelo wangaphambili wefowuni endaweni yokuba umyalelo ubuyiselwe kuwo.
//
//
// Ngokufanelekileyo besingayi kuyenza le nto.
// Ngokufanelekileyo siya kufuna abafowunela ii-`resolve` APIs apha ukwenza ngesandla i--1 kunye neakhawunti abafuna ulwazi lwendawo ngomyalelo *wangaphambili*, hayi okwangoku.
// Ngokufanelekileyo sinokuveza kwi `Frame` ukuba ngokwenene siyidilesi yomyalelo olandelayo okanye okwangoku.
//
// Okwangoku nangona le nto iyinkxalabo entle ye-niche ke ngaphakathi ngaphakathi sisoloko sithatha enye.
// Abathengi kufuneka baqhubeke nokusebenza kwaye bafumane iziphumo ezintle, ke kufanelekile ukuba sonele.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Iyafana ne `resolve`, kuphela ayikhuselekanga njengoko ingahambelani.
///
/// Lo msebenzi awunazo ii-guarantee zokungqamanisa kodwa uyafumaneka xa inqaku le `std` lale crate lingahlangananga ngaphakathi.
/// Jonga umsebenzi we `resolve` ngamaxwebhu ngakumbi kunye nemizekelo.
///
/// # Panics
///
/// Jonga ulwazi kwi-`resolve` yeepavela kwi-`cb` panicking.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Iyafana ne `resolve_frame`, kuphela ayikhuselekanga njengoko ingahambelani.
///
/// Lo msebenzi awunazo ii-guarantee zokungqamanisa kodwa uyafumaneka xa inqaku le `std` lale crate lingahlangananga ngaphakathi.
/// Jonga umsebenzi we `resolve_frame` ngamaxwebhu ngakumbi kunye nemizekelo.
///
/// # Panics
///
/// Jonga ulwazi kwi-`resolve_frame` yeepaki kwi-`cb` panicking.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// I-trait emele isisombululo sesimboli kwifayile.
///
/// Le trait iveliswa njengezinto ze-trait kukuvalwa okunikwe umsebenzi we `backtrace::resolve`, kwaye ithunyelwe phantse njengoko kungaziwa ukuba loluphi uphumezo olungemva kwayo.
///
///
/// Isimboli inokunika ulwazi ngemeko yomsebenzi, umzekelo igama, igama lefayile, inombolo yomgca, idilesi echanekileyo, njl.
/// Ayizizo zonke iinkcukacha ezihlala zikhona kwisimboli, nangona kunjalo, zonke iindlela zibuyisa i `Option`.
///
///
pub struct Symbol {
    // TODO: oku kubotshwa kobomi bonke kufuneka kuphikelelwe ekugqibeleni kube yi-`Symbol`,
    // kodwa okwangoku lutshintsho oluqhekezayo.
    // Okwangoku oku kukhuselekile kuba i `Symbol` inikwa kuphela ireferensi kwaye ayinakwenziwa.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Ibuyisa igama lalo msebenzi.
    ///
    /// Isakhiwo esibuyiselweyo sinokusetyenziselwa ukubuza iipropathi ezahlukeneyo malunga negama lesimboli:
    ///
    ///
    /// * Ukuphunyezwa kwe `Display` kuya kuprinta isimboli edanyiselweyo.
    /// * Ixabiso le `str` eluhlaza yesimboli inokufikelelwa (ukuba iyasebenza utf-8).
    /// * I-byte eluhlaza zegama lesimboli zinokufikelelwa.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Ibuyisela idilesi yokuqala yalo msebenzi.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Ibuyisa igama lefayile eluhlaza njengesilayidi.
    /// Oku kuluncedo ikakhulu kwimimandla ye `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Ibuyisa inombolo yekholamu apho olu phawu lusebenza khona ngoku.
    ///
    /// Kuphela yi-gimli okwangoku ebonelela ngexabiso apha kwaye emva koko kuphela ukuba i-`filename` ibuyisa i-`Some`, kwaye ke ngenxa yoko iyaxhomekeka kwimiqolomba efanayo.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Ibuyisela inombolo yomgca apho isimboli sisebenza khona ngoku.
    ///
    /// Ixabiso lokubuyisa liqhelekile ukuba li-`Some` ukuba i-`filename` ibuyisa i-`Some`, kwaye ngenxa yoko ixhomekeke kwimiqolomba efanayo.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Ibuyisela igama lefayile apho lo msebenzi ubuchaziwe.
    ///
    /// Oku okwangoku kufumaneka kuphela xa i-libbacktrace okanye i-gimli isetyenziswa (umzekelo
    /// unix amaqonga ezinye) kwaye xa i-binary idityaniswa ne-debuginfo.
    /// Ukuba akukho nanye kwezi meko ifezekisiweyo kuya kuthi kubuye i `None`.
    ///
    /// # Iimpawu ezifunekayo
    ///
    /// Lo msebenzi ufuna inqaku le `std` le `backtrace` crate ukuba yenziwe, kwaye inqaku le `std` linikwe amandla ngokungagqibekanga.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Mhlawumbi isimboli yeC++ edityanisiweyo, ukuba ukwahlula isimboli emangxolwa njenge-Rust kusilele.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Qiniseka ukuba ugcina obu bukhulu bungu-zero, ukuze inqaku le-`cpp_demangle` lingabinazindleko xa likhubazekile.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Isisongeli esijikeleze igama lesimboli ukubonelela i-ergonomic accessors kwigama elixhonyiweyo, ii-byte eziluhlaza, umtya oluhlaza, njl.
///
// Vumela ikhowudi efileyo xa inqaku le `cpp_demangle` lingenziwanga.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Yenza igama elitsha lesimboli kwii-byte ezingasisiseko.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Ibuyisa i-(mangled) eluhlaza njengophawu lwegama njenge-`str` ukuba uphawu luvumelekile utf-8.
    ///
    /// Sebenzisa ukumiliselwa kwe `Display` ukuba ufuna uhlobo oludiliziweyo.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Ibuyisa igama lesimboli eluhlaza njengoluhlu lwee-byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Oku kunokwenzeka ukuba kuprintwe ukuba uphawu oludiliziweyo alusasebenzi ngokwenyani, sombulula impazamo apha kakuhle ngokuthi ungayisasazi ngaphandle.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Ukuzama ukubuyisa inkumbulo egciniweyo esetyenziselwa ukufuzisela iidilesi.
///
/// Le ndlela izakuzama ukukhupha naziphi na izakhiwo zedatha zehlabathi ezigcinwe ngenye indlela kwihlabathi liphela okanye kumsonto obonisa ulwazi lwe-DWARF okanye okufanayo.
///
///
/// # Caveats
///
/// Ngelixa lo msebenzi uhlala ufumaneka awenzi kwanto kulwenziwo oluninzi.
/// Amathala eencwadi afana ne-dbghelp okanye i-libbacktrace ayinikezeli ngezixhobo zokuhambisa urhulumente kunye nokulawula imemori eyabelweyo.
/// Okwangoku inqaku le `gimli-symbolize` lale crate kuphela kwento apho lo msebenzi unefuthe khona.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}