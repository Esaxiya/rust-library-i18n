use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ithatha umnxeba oya kufumana i-dl_phdr_info pointer kuyo yonke i-DSO edityaniswe kwinkqubo.
    // dl_iterate_phdr ikwaqinisekisa ukuba ikhonkco elinamandla litshixiwe ukusuka ekuqaleni ukuya esiphelweni.
    // Ukuba ukuphinda ubuyise umnxeba kubuyisa ixabiso elingezizo i-iteration iyekiswe kwangoko.
    // 'data' Iya kudluliselwa njengengxoxo yesithathu ekubuyiseleni umnxeba kwifowuni nganye.
    // 'size' Inika ubungakanani be-dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Kufuneka sivelise i-ID yokwakha kunye nedatha esisiseko yenkqubo yedatha oko kuthetha ukuba sifuna into ethile evela kwi-ELF spec nayo.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Ngoku kufuneka siphindaphinde, kancinci kancinci, ubume be-dl_phdr_info yohlobo olusetyenziswe sisinxibelelanisi samandla se-fuchsia.
// IChromium inayo nalo mda we-ABI kunye ne-crashpad.
// Ngelinye ixesha singathanda ukuhambisa la matyala sisebenzise ukukhangela i-elf kodwa kuya kufuneka sinikezele nge-SDK kwaye ayikenziwa.
//
// Yiyo loo nto thina (kwaye) sinamathele ekusebenziseni le ndlela eyenza ukudibana okuqinileyo kunye ne-fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Asinayo indlela yokwazi ukujonga ukuba ngaba i-e_phoff kunye ne-e_phnum ziyasebenza na.
    // I-libc kufuneka iqinisekise oku kuthi nangona kunjalo kukhuselekile ukwenza isilayidi apha.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// I-Elf_Phdr imele inkqubo yentloko ye-ELF engama-64 kwisiphelo soyilo loyilo.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// I-Phdr imele inkqubo yentloko ye-ELF esebenzayo kunye nemixholo yayo.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Asinayo indlela yokujonga ukuba ngaba i-p_addr okanye i-p_memsz iyasebenza na.
    // I-libc ye-Fuchsia icacisa amanqaku kuqala kodwa ke ngenxa yokuba zilapha ezi zihloko kufuneka zisemthethweni.
    //
    // QaphelaIter ayifuni ukuba idatha esisiseko isebenze kodwa ifuna ukuba imida isebenze.
    // Siyathemba ukuba i-libc iqinisekisile ukuba le yimeko yethu apha.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Uhlobo lwenqaku lokwakha ii-ID.
const NT_GNU_BUILD_ID: u32 = 3;

// I-Elf_Nhdr imele i-header ye-ELF kwinqaku ekujoliseni ekujoliswe kuko.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Inqaku limele inqaku le-ELF (imixholo + yokubhaliweyo).
// Igama lishiywe njengesiqwenga se u8 kuba akusoloko kuphelisiwe kwaye i rust yenza kube lula ngokwaneleyo ukujonga ukuba ii-byte ziyahambelana na.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// QaphelaIter ikuvumela ukuba ukhuseleke ngokukhuselekileyo kwicandelo lenqaku.
// Iphela ngokukhawuleza nje ukuba kwenzeke impazamo okanye akusekho manqaku.
// Ukuba uphakamisa idatha engasebenziyo iya kusebenza ngokungathi akukho manqaku afunyenweyo.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Kukungangenisi komsebenzi ukuba isikhombisi kunye nobungakanani obunikiweyo buchaza uluhlu olusebenzayo lweebte ezinokufundwa zonke.
    // Umxholo wezi bhayithi unokuba yiyo nantoni na kodwa uluhlu kufuneka lusebenze ukuze oku kukhuseleke.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' to 'to'-byte alignment assuming 'to' is a power of 2.
// Oku kulandela iphethini esemgangathweni kwi-C/C ++ ELF ikhowudi yokuhambisa apho (x + ukuya, 1) kunye ne -to isetyenzisiweyo.
// I-Rust ayikuvumeli ukuba usize usize ngenxa yoko ndiyisebenzisa
// 2's-complement uguquko ukuphinda uyenze loo nto.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 Idla ngamanani byte kwisilayidi (ukuba sikhona) kwaye ukongeza ukuqinisekisa ukuba isilayidi sokugqibela silungelelaniswe ngokufanelekileyo.
// Ukuba inani lee-byte eziceliweyo likhulu kakhulu okanye isilayidi asinakulungelelaniswa emva koko ngenxa yokungonelanga kwee-byte esele zikho, Akukho nto ibuyiswayo kwaye isilayidi asiguqulwanga.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Lo msebenzi awunabangeneleli bokwenyani abo bafowunayo kufuneka baxhase ngaphandle kokuba i 'bytes' kufuneka ilungelelaniswe nokusebenza (kunye nolunye ulungiso lwezakhiwo).
// Amaxabiso kumhlaba we-Elf_Nhdr angangabinangqondo kodwa lo msebenzi awuqinisekisi ngento enjalo.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Oku kukhuselekile ukuba nje kukho indawo eyoneleyo kwaye siqinisekisile nje ukuba kwisitatimende esingentla apha oku akufuneki kungakhuselekanga.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Qaphela ukuba sice_of: :<Elf_Nhdr>() ihlala ilungelelaniswe nge-4-byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Jonga ukuba sifikelele esiphelweni.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Sidlulisa i-nhdr kodwa sijonga ngononophelo ulwakhiwo olunokubakho.
        // Asiyithembi i-namesz okanye i-descsz kwaye asenzi zigqibo zingakhuselekanga ngokuxhomekeke kuhlobo.
        //
        // Ke nokuba sikhupha inkunkuma epheleleyo kufanelekile ukuba sikhuseleke.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Ibonisa ukuba icandelo liyaphunyezwa.
const PERM_X: u32 = 0b00000001;
/// Ibonisa ukuba icandelo liyabhalwa.
const PERM_W: u32 = 0b00000010;
/// Ibonisa ukuba icandelo lifundeka.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Imele icandelo le-ELF ngexesha lokubaleka.
struct Segment {
    /// Inika idilesi yokubonisa ixesha lokubaleka kwesi siqulatho secandelo.
    addr: usize,
    /// Inika ubungakanani bememori yesiqulatho seli candelo.
    size: usize,
    /// Inika imodyuli yedilesi ebonakalayo yeli candelo kunye nefayile ye-ELF.
    mod_rel_addr: usize,
    /// Inika iimvume ezifumaneka kwifayile ye-ELF.
    /// Ezi mvume ayizizo iimvume ezikhoyo ngexesha lokubaleka nangona kunjalo.
    flags: Perm,
}

/// Vumela enye iterate ngaphezulu kwamaCandelo avela kwi-DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Imele i-ELF DSO (into ekwabelwana ngayo ngeDynamic).
/// Olu hlobo lubonisa idatha egcinwe kwi-DSO yokwenyani endaweni yokwenza ikopi yayo.
struct Dso<'a> {
    /// Ikhonkco elinamandla lisoloko lisinika igama, nokuba igama alinalutho.
    /// Kwimeko yokuphunyezwa kwegama eliya kuba lilize.
    /// Kwimeko yento ekwabelwana ngayo iya kuba ngunyana (jonga DT_SONAME).
    name: &'a str,
    /// Kwi-Fuchsia phantse zonke i-binaries zakha ii-ID kodwa esi ayisiyomfuneko engqongqo.
    /// Akukho ndlela yokudibanisa ulwazi lwe-DSO kunye nefayile yokwenyani ye-ELF emva koko ukuba akukho build_id ke sifuna ukuba yonke i-DSO ibe nayo apha.
    ///
    /// Ii-DSO ngaphandle kwe-build_id azinakwa.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Ibuyisa iterator ngaphezulu kwamaCandelo kule DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ezi mpazamo zibandakanya imiba evela ngelixa kusasazwa ulwazi malunga ne-DSO nganye.
///
enum Error {
    /// IgamaError lithetha ukuba kwenzeke impazamo ngelixa kuguqulwa umtya wesitayile se-C ube ngumtya we-rust.
    ///
    NameError(core::str::Utf8Error),
    /// Iphutha lokwakha lithetha ukuba asifumananga isazisi sokwakha.
    /// Isenokuba kungenxa yokuba i-DSO yayingenaso isazisi sokwakha okanye ngenxa yokuba icandelo elinesazisi sokwakha sasingalunganga.
    ///
    BuildIDError,
}

/// Iifowuni nokuba ziyi-'dso' okanye i-'error' kwi-DSO nganye enxibelelaniswe nenkqubo ngumnxibelelanisi onamandla.
///
///
/// # Arguments
///
/// * `visitor` - I-DsoPrinter eya kuthi ibenenye yeendlela zokutya ezibizwa ngokuba yi-foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr iqinisekisa ukuba i info.name iya kwalatha kwindawo efanelekileyo.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Lo msebenzi uprinta uphawu lwe-Fuchsia uphawu lwalo lonke ulwazi oluqulethwe kwi-DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}