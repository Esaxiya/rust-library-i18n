//! Ilayibrari yenkxaso yababhali be-macro xa kuchazwa ii-macros ezintsha.
//!
//! Eli thala leencwadi libonelelwa ngosasazo oluqhelekileyo, libonelela ngeendlela ezisetyenzisiweyo kunxibelelwano lwenkcazo ezichaziweyo zenkqubo ezinje ngemisebenzi efana ne-macros `#[proc_macro]`, macro attributes `#[proc_macro_attribute]` and custom derive attributes`#[proc_macro_derive]`.
//!
//!
//! Bona i [the book] ngaphezulu.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Ichonga ukuba ngaba iproc_macro yenziwe yafumaneka kwinkqubo eqhubayo ngoku.
///
/// Inkqubo ye-proc_macro crate yenzelwe kuphela ukusetyenziswa ngaphakathi kokuphunyezwa kwenkqubo yemacros.Yonke imisebenzi ekule crate panic ukuba icelwe ngaphandle kwenkqubo yemacro, enje ngeskripthi sokwakha okanye kuvavanyo lweyunithi okanye i-Rust yesiqhelo.
///
/// Ngokuqwalaselwa kweelayibrari ze-Rust eziyilelwe ukuxhasa iimeko ezisetyenziswayo ezinkulu nezingasebenzisi macro, i `proc_macro::is_available()` ibonelela ngendlela engoyikisiyo yokufumanisa ukuba ngaba iziseko zophuhliso ezifunekayo ukusebenzisa i-API ye-proc_macro iyafumaneka ngoku.
/// Ibuyisa inyani ukuba icelwe ngaphakathi kwenkqubo yenkqubo enkulu, bubuxoki ukuba icelwe kuyo nayiphi na enye into yokubini.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Olona hlobo luphambili lubonelelwe yile crate, emele umlambo we-tokens, okanye, ngakumbi, ngokulandelelana kwemithi ye token.
/// Olu hlobo lubonelela ngendawo yokuhambisa ngaphezulu kwale mithi token kwaye, ngokuchaseneyo, ukuqokelela inani le token yemithi kumjelo omnye.
///
///
/// Oku kokufaka kunye nokuphuma kweenkcazo ze `#[proc_macro]`, `#[proc_macro_attribute]` kunye ne `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Impazamo ibuyisiwe kwi `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Ibuyisa i `TokenStream` engenanto ngaphandle kwemithi ye token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Jonga ukuba le `TokenStream` ayinanto.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Imizamo yokuqhekeza umtya ube yi-tokens kwaye uhlolisise ezo tokens zibe ngumjelo we-token.
/// Usenokungaphumeleli ngenxa yezizathu ezininzi, umzekelo, ukuba umtya uqulethe ii-delimiters ezingalinganiyo okanye abalinganiswa abakhoyo kulwimi.
///
/// Zonke i-tokens kumjelo odibeneyo zifumana i-`Span::call_site()` spans.
///
/// NOTE: Ezinye iimpazamo zinokubangela i-panics endaweni yokubuyisa i `LexError`.Sinelungelo lokutshintsha ezi mpazamo zibe kwi-LexError`s kamva.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// QAPHELA, ibhulorho ibonelela nge `to_string` kuphela, isebenzisa i `fmt::Display` ngokusekwe kuyo (umva wobudlelwane obuqhelekileyo phakathi kwezi zimbini).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Ishicilela umsinga we-token njengomtya ekufanele ukuba ungaguquguquki nelahleko ubuyele kumjelo ofanayo we-token (modulo spans), ngaphandle kwento ethi `TokenTree: : Group`s kunye ne-`Delimiter::None` delimiters kunye neeleta ezingezizo.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Kuprintwa i token ngohlobo olulungele ukulungisa ingxaki.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Yenza umjelo we-token oqukethe umthi omnye we-token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Ukuqokelela inani le-token yemithi kumjelo omnye.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Umsebenzi we "flattening" kwimilambo ye token, uqokelela imithi ye token kwimilanjana emininzi ye token ibe ngumjelo omnye.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Sebenzisa ukumiliselwa okuphezulu kwe if/when kunokwenzeka.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Iinkcukacha zokuphunyezwa koluntu zohlobo lwe `TokenStream`, ezinje ngeeeriters.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// I-iterator ngaphezulu kwe-TokenStream's's TokenTree`s.
    /// I-iteration yi-"shallow", umzekelo, i-iterator ayibuyeli kumaqela ahlukanisiweyo, kwaye ibuyisela amaqela onke njengemithi ye token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` yamkela i tokens ngokungenasizathu kwaye yanda kwi `TokenStream` ichaza igalelo.
/// Umzekelo, i-`quote!(a + b)` iya kuvelisa intetho, ethi, xa kuvavanywa, yakha i-`TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Ukungacaphuli kwenziwa nge `$`, kwaye kusebenza ngokuthatha isazisi esinye esilandelayo njengegama elingachazwanga.
/// Ukucaphula i `$` uqobo, sebenzisa i `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Ummandla wekhowudi yomthombo, kunye nolwazi lokwandisa olukhulu.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Yenza i `Diagnostic` entsha enikwe i `message` kwispan `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Isithuba esisombulula kwindawo yenkcazo yemacro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Isithuba sokucela inkqubo yangoku yenkqubo.
    /// Izinto ezichongiweyo ezenziweyo ngesi sithuba ziya kusonjululwa ngokungathi zibhalwe ngqo kwindawo yeminxeba emikhulu (ucoceko lwesiza somnxeba) kunye nenye ikhowudi kwindawo ekufowunelwa kuyo iya kuba nakho ukubhekisa kubo.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Isithuba esimele ucoceko lwe-`macro_rules`, kwaye ngamanye amaxesha sisombulula kwindawo yokucacisa enkulu (izinto eziguquguqukayo zalapha ekhaya, iilebheli, i-`$crate`) kwaye ngamanye amaxesha kwindawo yokufowuna enkulu (yonke enye into).
    ///
    /// Indawo ebanzi ithathwa kwindawo ekutsalelwa kuyo umnxeba.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Imvelaphi yefayile yomthombo ekujongwa kuyo esi sithuba.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// I `Span` ye tokens kulwandiso lwangaphambili olukhulu apho i `self` yaveliswa khona, ukuba ikho.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Ubungakanani besiseko sekhowudi yemvelaphi `self` eveliswe kuyo.
    /// Ukuba le `Span` ayiveliswanga kolunye ulwandiso macro ke ixabiso lokubuya liyafana ne `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Ifumana i-line/column yokuqala kwifayile yomthombo kwesi sithuba.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Ufumana isiphelo se line/column kwifayile yomthombo kwesi sithuba.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Yenza isithuba esitsha esiquka i `self` kunye ne `other`.
    ///
    /// Ibuyisa i `None` ukuba i `self` kunye ne `other` zivela kwiifayile ezahlukeneyo.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Yenza isithuba esitsha esinolwazi olufanayo lwe line/column njenge `self` kodwa esombulula iisimboli ngokungathi zikwi `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Yenza indawo entsha enesimo sokuziphatha esisombululo njenge `self` kodwa ngolwazi lwe line/column ye `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Ukuthelekisa ukuya kwizithuba zokujonga ukuba bayalingana na.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Ibuyisa imvelaphi yokubhaliweyo emva kwesithuba.
    /// Oku kugcina ikhowudi yemvelaphi, kubandakanya nezithuba kunye nezimvo.
    /// Ibuyisa kuphela iziphumo ukuba ubude buhambelana nekhowudi yemvelaphi yokwenyani.
    ///
    /// Note: Iziphumo ezibonakalayo ze-macro kufuneka zixhomekeke kuphela kwi-tokens hayi kulo mthombo wombhalo.
    ///
    /// Iziphumo zalo msebenzi yeyona migudu ilungileyo yokusetyenziselwa ukuxilonga kuphela.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Iprinta ispani kwifom efanelekileyo yokulungisa ingxaki.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Umtya wekholamu yomgca omele ukuqala okanye ukuphela kwe `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Umgca onesalathiso esi-1 kwifayile yomthombo apho isithuba siqala khona okanye siphela khona nge-(inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Ikholamu ene-0-indexed (ngo-UTF-8 abalinganiswa) kwifayile yomthombo apho isithuba siqala khona okanye siphela khona nge-(inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Imvelaphi yefayile ye `Span` enikiweyo.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Ufumana indlela eya kule fayile yomthombo.
    ///
    /// ### Note
    /// Ukuba ikhowudi span enxulunyaniswa nale `SourceFile` yenziwe yimacro yangaphandle, le macro, le isenokungabi yeyona ndlela eyiyo kwinkqubo yefayile.
    /// Sebenzisa i [`is_real`] ukujonga.
    ///
    /// Qaphela ukuba nokuba i-`is_real` ibuyisa i-`true`, ukuba i-`--remap-path-prefix` idlulisiwe kwilayini yomyalelo, indlela enikiweyo ayinakuba iyasebenza.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Ibuyisa i `true` ukuba le fayile yemvelaphi yifayile yokwenyani, kwaye ayivelwanga lulwandiso lwangaphandle olukhulu.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Oku kukuqhekeka kude kube kuphunyezwe ii-intercrate spans kwaye sinokuba neefayile zomthombo wokwenyani kwizithuba ezenziwe kwimacros zangaphandle.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// I-token enye okanye ulandelelwano olulinganisiweyo lwemithi ye token (umzekelo, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Umjelo we-token ujikelezwe ziibracket delimiters.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Isazisi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Uhlobo olunye lweziphumlisi (`+ +`, `,`, `$`, njl.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Umntu oqobo ongu-(`'a'`), umtya (`"hello"`), inombolo (`2.3`), njl.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Ibuyisa isithuba salo mthi, idlulisela indlela ye `span` ye-token okanye umjelo omiselweyo.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Qwalasela isithuba sayo kuphela esi token *.
    ///
    /// Qaphela ukuba le token iyi-`Group` emva koko le ndlela ayizukumisela ubude besithuba ngasinye se-tokens, oku kuya kugqithisela indlela ye-`set_span` yokwahluka ngalunye.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Kuprintwa umthi we-token ngendlela efanelekileyo yokulungisa ingxaki.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Nganye kwezi inegama kuhlobo lolwakhiwo kwisiphene esikhulelweyo, ke ungazikhathazi ngolungelelwaniso olungaphezulu lwesalathiso
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// QAPHELA, ibhulorho ibonelela nge `to_string` kuphela, isebenzisa i `fmt::Display` ngokusekwe kuyo (umva wobudlelwane obuqhelekileyo phakathi kwezi zimbini).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Kuprintwa umthi we-token njengomtya ekufanele ukuba ungaguquguquki nelahleko ubuyele kumthi ofanayo we-token (modulo spans), ngaphandle kwento ethi `TokenTree: : Group`s kunye ne-`Delimiter::None` delimiters kunye neeleta ezingezizo.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Umjelo omiselweyo we-token.
///
/// I-`Group` ngaphakathi iqulethe i-`TokenStream` ejikelezwe zii-Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Ichaza ukuba ulandelelaniswa njani umthi we token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// I-delimiter engacacanga, enokuthi, umzekelo, ivele ijikeleze i tokens ivela kwi "macro variable" `$var`.
    /// Kubalulekile ukugcina izinto eziphambili ngokubaluleka kumatyala anje nge `$var * 3` apho i `$var` ingu `1 + 2`.
    /// Abagxeki ngokungagungqiyo abanakuphila kumjikelo we-token ngomsonto.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Yenza i `Group` entsha enesixhobo esinikiweyo kunye nomsinga we token.
    ///
    /// Lo makhi uza kuseta isithuba seli qela ukuya kwi `Span::call_site()`.
    /// Ukutshintsha isithuba ungasebenzisa indlela ye `set_span` engezantsi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Ibuyisa i-delimiter yale `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Ibuyisa i `TokenStream` ye tokens ezinqunyelwe kule `Group`.
    ///
    /// Qaphela ukuba ukubuyiswa kwe-token akubandakanyi i-delimiter ebuyiselwe apha ngasentla.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Ibuyisela isithuba kubanqumli balo mlambo we-token, ojikeleza yonke i `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ibuyisa ubude besalatha kwisalathiso sokuvula seli qela.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Ibuyisa isithuba esalatha kwisiphelo sendlela yokuvala yeli qela.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Qwalasela isithuba sale `Qela` labanquli, kodwa hayi i tokens zangaphakathi.
    ///
    /// Le ndlela ayizukubeka ** ubungakanani bayo yonke i-tokens engaphakathi kweli qela, kodwa iya kuseta kuphela ubude be-delimiter tokens kwinqanaba le-`Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// QAPHELA, ibhulorho ibonelela nge `to_string` kuphela, isebenzisa i `fmt::Display` ngokusekwe kuyo (umva wobudlelwane obuqhelekileyo phakathi kwezi zimbini).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ishicilela iqela njengomtya ekufuneka uguqulwe ngokungalahleki ubuyele kwiqela elinye (modulo spans), ngaphandle kwento ethi `TokenTree: : Group`s kunye ne `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// I `Punct` luphawu olunye lweziphumlisi njenge `+`, `-` okanye `#`.
///
/// Abaqhubi beempawu ezininzi ezifana ne `+=` bamelwe njengeziganeko ezibini ze `Punct` ngeendlela ezahlukeneyo ze `Spacing` ezibuyisiweyo.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Nokuba i `Punct` ilandelwa kwangoko yenye i `Punct` okanye ilandelwe yenye i token okanye indawo emhlophe.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// Umzekelo, i `+` yi `Alone` kwi `+ =`, `+ident` okanye `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// Umzekelo, i `+` yi `Joint` kwi `+=` okanye kwi `'#`.
    /// Ukongeza, isicatshulwa esinye i `'` sinokujoyina izikhombisi ukwenza ixesha lokuphila le `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Yenza i `Punct` entsha ukusuka kumlinganiswa owunikiweyo kunye nesithuba.
    /// Ingxoxo ye `ch` kufuneka ibe sisiphumlisi esisemthethweni esivunyelwe lulwimi, kungenjalo umsebenzi uya kuba panic.
    ///
    /// I-`Punct` ebuyisiweyo iya kuba nesithuba esingagqibekanga se `Span::call_site()` esinokuphinda siqwalaselwe ngendlela ye `set_span` engezantsi.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Ibuyisela ixabiso lolu phawu lweziphumlisi njengo `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Ibuyisa isithuba sophawu lweziphumlisi, ibonisa ukuba ilandelwa kwangoko yenye i `Punct` kumjelo we token, ukuze inokudityaniswa ibe ngumsebenzi weempawu ezininzi u (`Joint`), okanye ilandelwe yenye ye token okanye indawo emhlophe (`Alone`) ukuze umqhubi ngokuqinisekileyo yaphela.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Ibuyisela isithuba kolu phawu lweziphumlisi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Qwalasela isithuba sophawu lweziphumlisi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// QAPHELA, ibhulorho ibonelela nge `to_string` kuphela, isebenzisa i `fmt::Display` ngokusekwe kuyo (umva wobudlelwane obuqhelekileyo phakathi kwezi zimbini).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Kuprintwa uphawu lweziphumlisi njengomtya ekufuneka uguqulwe ngaphandle kokulahleka ubuyele kumlinganiswa omnye.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Isichongi (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Yenza i `Ident` entsha nge `string` enikiweyo kunye ne `span` echaziweyo.
    /// Ingxoxo ye `string` kufuneka ibe sisazisi esisemthethweni esivunyelweyo lulwimi (kubandakanya amagama aphambili, umz. `self` okanye `fn`).Ngaphandle koko, umsebenzi uya kuba panic.
    ///
    /// Qaphela ukuba i `span`, okwangoku ikwi rustc, iqwalasela ulwazi lwezempilo kwesi sichazi.
    ///
    /// Ngeli xesha i `Span::call_site()` ingena ngokucacileyo ku-"call-site" yococeko ethetha ukuba izinto ezichongiweyo ezenziwe ngesi sithuba ziya kusonjululwa ngokungathi zibhalwe ngqo kwindawo ekufowunelwa kuyo, kwaye enye ikhowudi kwindawo enkulu yokufowuna iya kubhekisa kuyo. nabo ngokunjalo.
    ///
    ///
    /// Emva kwexesha izithuba ezinje nge `Span::def_site()` ziya kuvumela ukungena kwi-"definition-site" yococeko nto leyo ethetha ukuba izinto ezichongiweyo ezenziwe ngesi sithuba ziya kusonjululwa kwindawo yenkcazo yemacro kwaye enye ikhowudi kwindawo yokufowuna enkulu ayizukubhekisa kubo.
    ///
    /// Ngenxa yokubaluleka kokucoceka kwalo makhi, ngokungafaniyo nezinye i-tokens, kufuna ukuba kuchazwe i `Span` kulwakhiwo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Iyafana ne `Ident::new`, kodwa yenza isazisi eluhlaza (`r#ident`).
    /// Impikiswano ye `string` mayibe sisazisi esivumelekileyo solwimi (kubandakanya amagama aphambili, umz. `fn`).
    /// Amagama aphambili asetyenziswayo kumacandelo endlela (umz
    /// `self`, `super`) ayixhaswanga, kwaye iya kubangela i-panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Ibuyisa isithuba sale `Ident`, kubandakanya umtya uphela obuyiswe ngu [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Qwalasela isithuba sale `Ident`, ngokutshintsha imeko yezempilo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// QAPHELA, ibhulorho ibonelela nge `to_string` kuphela, isebenzisa i `fmt::Display` ngokusekwe kuyo (umva wobudlelwane obuqhelekileyo phakathi kwezi zimbini).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Shicilela isazisi njengomtya ekufuneka uguqulwe ngaphandle kokulahleka ubuyele kwisazisi esinye.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Umtya wokoqobo (`"hello"`), byte umtya (`b"hello"`), uphawu (`'a'`), byte umlinganiswa (`b'a'`), inani elipheleleyo okanye inani lencopho yokudada kunye okanye ngaphandle kwesimamva (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Iincwadi ze-Boolean ezinje nge-`true` kunye ne-`false` azikho apha, zii-Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Yenza inani elipheleleyo elineziqulatho zenani elipheleleyo elinexabiso elichaziweyo.
        ///
        /// Lo msebenzi uza kudala inani elipheleleyo njenge-`1u32` apho ixabiso elipheleleyo elichaziweyo liyinxalenye yokuqala ye-token kwaye ukudityaniswa kukwanele ekugqibeleni.
        /// Izinto ezibhaliweyo ezenziwe ngamanani amabi azinakuphila kuhambo olujikelezayo nge `TokenStream` okanye imitya kwaye zingaqhekeka zibe zimbini ze tokens (`-` kunye neyona nto ilungileyo).
        ///
        ///
        /// Amanqaku ayilwe ngale ndlela ane-`Span::call_site()` span ngokungagqibekanga, enokuqwalaselwa ngendlela ye-`set_span` engezantsi.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Yenza inani elitsha elipheleleyo elingasuswanga kunye nexabiso elichaziweyo.
        ///
        /// Lo msebenzi uza kudala inani elipheleleyo njenge-`1` apho ixabiso elipheleleyo elichaziweyo liyinxalenye yokuqala ye-token.
        /// Akukho sisombululo sichaziweyo kule token, oko kuthetha ukuba izibongozo ezinje nge `Literal::i8_unsuffixed(1)` zilingana ne `Literal::u32_unsuffixed(1)`.
        /// Izinto ezibhaliweyo ezenziwe ngamanani amabi azinakuphila kwimithambeka nge `TokenStream` okanye imitya kwaye zingaqhekeka zibe zimbini ze tokens (`-` kunye neyona nto ilungileyo).
        ///
        ///
        /// Amanqaku ayilwe ngale ndlela ane-`Span::call_site()` span ngokungagqibekanga, enokuqwalaselwa ngendlela ye-`set_span` engezantsi.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Yenza indawo entsha engafakwanga ingancanyathiselwanga ngokwenyani.
    ///
    /// Lo makhi uyafana nezo zifana ne `Literal::i8_unsuffixed` apho ixabiso le-float likhutshwa ngqo kwi-token kodwa akukho sisimamva sisetyenzisiweyo, kungathiwa kungenziwa i-`f64` kamva kumhlanganisi.
    ///
    /// Izinto ezibhaliweyo ezenziwe ngamanani amabi azinakuphila kwimithambeka nge `TokenStream` okanye imitya kwaye zingaqhekeka zibe zimbini ze tokens (`-` kunye neyona nto ilungileyo).
    ///
    /// # Panics
    ///
    /// Lo msebenzi ufuna ukuba ukudada okuchaziweyo kugqityiwe, umzekelo ukuba yinto engapheliyo okanye uNaN lo msebenzi uya kuba panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Yenza indawo entsha enesimamva ngokwenyani.
    ///
    /// Lo makhi uza kudala uqobo njenge `1.0f32` apho ixabiso elichaziweyo liyinxalenye engaphambili ye token kunye ne `f32` sisimamva se token.
    /// Le token iya kuhlala ichazwa njenge-`f32` kumhlanganisi.
    /// Izinto ezibhaliweyo ezenziwe ngamanani amabi azinakuphila kwimithambeka nge `TokenStream` okanye imitya kwaye zingaqhekeka zibe zimbini ze tokens (`-` kunye neyona nto ilungileyo).
    ///
    ///
    /// # Panics
    ///
    /// Lo msebenzi ufuna ukuba ukudada okuchaziweyo kugqityiwe, umzekelo ukuba yinto engapheliyo okanye uNaN lo msebenzi uya kuba panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Yenza indawo entsha engafakwanga ingancanyathiselwanga ngokwenyani.
    ///
    /// Lo makhi uyafana nezo zifana ne `Literal::i8_unsuffixed` apho ixabiso le-float likhutshwa ngqo kwi-token kodwa akukho sisimamva sisetyenzisiweyo, kungathiwa kungenziwa i-`f64` kamva kumhlanganisi.
    ///
    /// Izinto ezibhaliweyo ezenziwe ngamanani amabi azinakuphila kwimithambeka nge `TokenStream` okanye imitya kwaye zingaqhekeka zibe zimbini ze tokens (`-` kunye neyona nto ilungileyo).
    ///
    /// # Panics
    ///
    /// Lo msebenzi ufuna ukuba ukudada okuchaziweyo kugqityiwe, umzekelo ukuba yinto engapheliyo okanye uNaN lo msebenzi uya kuba panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Yenza indawo entsha enesimamva ngokwenyani.
    ///
    /// Lo makhi uza kudala uqobo njenge `1.0f64` apho ixabiso elichaziweyo liyinxalenye engaphambili ye token kunye ne `f64` sisimamva se token.
    /// Le token iya kuhlala ichazwa njenge-`f64` kumhlanganisi.
    /// Izinto ezibhaliweyo ezenziwe ngamanani amabi azinakuphila kwimithambeka nge `TokenStream` okanye imitya kwaye zingaqhekeka zibe zimbini ze tokens (`-` kunye neyona nto ilungileyo).
    ///
    ///
    /// # Panics
    ///
    /// Lo msebenzi ufuna ukuba ukudada okuchaziweyo kugqityiwe, umzekelo ukuba yinto engapheliyo okanye uNaN lo msebenzi uya kuba panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Umtya ngokwenyani.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Umntu oqobo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Umtya we-Byte uqobo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Ibuyisa isithuba esibandakanya oku kokoqobo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Qwalasela ispan sokudibanisa esi sokwenene.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Ibuyisa i `Span` eseti esecaleni kwe `self.span()` equlathe kuphela ii-byte zemithombo kuluhlu lwe `range`.
    /// Ibuyisa i `None` ukuba into enqunqiweyo ingaphandle kwemida ye `self`.
    ///
    // FIXME(SergioBenitez): jonga ukuba uluhlu lwe-byte luqala kwaye luphele kumda we-UTF-8 yomthombo.
    // Ngaphandle koko, kunokwenzeka ukuba i-panic iya kwenzeka kwenye indawo xa kuprintwa isicatshulwa esisekuqaleni.
    // FIXME(SergioBenitez): akukho ndlela yokuba umsebenzisi azi ukuba zeziphi iimephu ze `self.span()`, ngenxa yoko le ndlela inokubizwa ngokungaboni.
    // Umzekelo, i-`to_string()` yomlinganiswa u-'c' ubuyisa i-"'\u{63}'";akukho ndlela yokuba umsebenzisi azi ukuba isicatshulwa esivela kuyo yayiyi-'c' okanye yayiyi-'\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) into efana ne `Option::cloned`, kodwa ye `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// QAPHELA, ibhulorho ibonelela nge `to_string` kuphela, isebenzisa i `fmt::Display` ngokusekwe kuyo (umva wobudlelwane obuqhelekileyo phakathi kwezi zimbini).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Kuprinta okwenyani njengomtya ekufuneka uguqulwe ngokungalahleki ubuyele kwinto efanayo (ngaphandle kokujikeleza okunokubakho kwinqanaba lencwadi yokudada).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ukulandelelwa kokufikelela kwindalo esingqongileyo.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Buyisa umahluko wemekobume kwaye uyongeze kulwazi lokuxhomekeka.
    /// Inkqubo yokwakha eyenza umhlanganisi iya kwazi ukuba okwahlukileyo kuye kwafikelelwa ngexesha lokudityaniswa, kwaye uya kuba nakho ukuphinda ulwakhiwo kwakhona xa ixabiso lolo tshintsho luguqukayo.
    ///
    /// Ngaphandle kokulandela umkhondo wokuxhomekeka kulo msebenzi kufuneka ulingane ne-`env::var` ukusuka kwilayibrari esemgangathweni, ngaphandle kokuba impikiswano kufuneka ibe yi-UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}