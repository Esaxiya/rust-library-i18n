//! Ukuphuma kwe panics kaMiri.
use alloc::boxed::Box;
use core::any::Any;

// Uhlobo lwentlawulo ehlawulwa yinjineli yeMiri ngokusasaza kuthi.
// Kufuneka ubungakanani besikhombisi.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Umsebenzi wangaphandle owenziwe nguMiri ukuqala ukukhulula.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Umrhumo esiwudlulisayo kwi-`miri_start_panic` uya kuba yimpikiswano esiyifumana kwi `cleanup` apha ngezantsi.
    // Ke siyibhokisi nje kube kanye, ukufumana into enobungakanani besikhombisi.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Ukufumana kwakhona isiseko se `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}