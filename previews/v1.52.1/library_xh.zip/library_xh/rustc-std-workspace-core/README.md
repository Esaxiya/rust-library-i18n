# I `rustc-std-workspace-core` crate

Le crate yi-shim kwaye ayinanto i-crate exhomekeke kwi-`libcore` kwaye iphinde iphinde ithumele yonke imixholo yayo.
I-crate yi-crux yokuxhobisa ilayibrari esemgangathweni yokuxhomekeka kwi-crates ukusuka kwi-crates.io

Crates kwi crates.io ukuba ithala leencwadi eliqhelekileyo lixhomekeke kwisidingo sokuxhomekeka kwi `rustc-std-workspace-core` crate ukusuka kwi crates.io, engenanto.

Sisebenzisa i `[patch]` ukuyigqithisela kule crate kule ndawo yokugcina izinto.
Ngenxa yoko, i-crates kwi-crates.io iya kutsala ukuxhomekeka kwe-edge ukuya kwi-`libcore`, ingxelo echazwe kule ndawo yokugcina izinto.
Oko kuya kuzobeka yonke imiphetho yokuxhomekeka ukuqinisekisa ukuba i Cargo yakha i crates ngempumelelo!

Qaphela ukuba i-crates kwi-crates.io kufuneka ixhomekeke kule crate enegama elithi `core` kuyo yonke into ukuze isebenze ngokuchanekileyo.Ukwenza oko abanokukusebenzisa:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Ngokusetyenziswa kweqhosha le-`package` i-crate iphinde yathiywa igama kwathiwa yi `core`, oko kuthetha ukuba iya kujongeka

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

xa i-Cargo ibiza umhlanganisi, yanelisa isikhombisi se-`extern crate core` esine-injokishi.




