#![feature(no_core)]
#![no_core]

// Jonga i-rustc-std-indawo yokusebenza-esisiseko sokuba kutheni le crate ifuneka.

// Qamba igama i crate ukunqanda ukungqubana nemodyuli eyabelweyo kwi-liballoc.
extern crate alloc as foo;

pub use foo::*;