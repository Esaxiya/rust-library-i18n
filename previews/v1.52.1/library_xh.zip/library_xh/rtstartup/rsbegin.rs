// rsbegin.o kunye ne rsend.o zibizwa njalo ngokuba yi "compiler runtime startup objects".
// Zineekhowudi ezifunekayo ukulungiselela ngokufanelekileyo ixesha lokuhlanganisa.
//
// Xa umfanekiso osebenzayo okanye we-dylib unxulunyaniswa, yonke ikhowudi yomsebenzisi kunye neelayibrari zi-"sandwiched" phakathi kwezi fayile zimbini, ke ikhowudi okanye idatha evela kwi-rsbegin.o iba yeyokuqala kumacandelo omfanekiso, ngelixa ikhowudi kunye nedatha evela kwi-rsend.o iba yeyokugqibela.
// Esi siphumo sinokusetyenziselwa ukubeka iisimboli ekuqaleni okanye ekupheleni kwecandelo, kunye nokufaka naziphi na ii-headers okanye ii-footers ezifunekayo.
//
// Qaphela ukuba eyona ndawo yokungena kwimodyuli ikwi-C into yokuqalisa ixesha lokuqalisa (ihlala ibizwa ngokuba yi-`crtX.o`), ethi ke ibize ukuqalwa kweefowuni zamanye amaxesha okubaleka (abhaliswe kwelinye icandelo lomfanekiso okhethekileyo).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Amanqaku okuqala kwesakhelo sesitaki sokuphumla kwinqanaba lolwazi
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Isithuba sokugcina incwadi ngaphakathi.
    // Oku kuchazwa njenge `struct object` kwi $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Ungabuyisi ulwazi kwi-registration/deregistration yeendlela.
    // Jonga amaxwebhu e-libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // bhalisa ulwazi lokungaphumli kwisiqalo semodyuli
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ubhalise ekucimeni
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Ubhaliso oluqhelekileyo lwe-MinGW init/uninit
    pub mod mingw_init {
        // Izinto zokuqalisa zeMinGW (crt0.o/dllcrt0.o) ziya kubiza abakhi behlabathi kumacandelo e .ctors kunye ne .dtors kuqaliso kunye nokuphuma.
        // Kwimeko ye-DLL, oku kwenziwa xa i-DLL ilayishwa kwaye ikhutshiwe.
        //
        // Umnxibelelanisi uya kuhlela amacandelo, aqinisekisa ukuba ukufowunelwa kwethu kubekwe esiphelweni koluhlu.
        // Kuba abakhi baqhutywa ngokulandelelana, oku kuqinisekisa ukuba ukubuyela umva kwethu yeyokuqala neyokugqibela ukwenziwa.
        //
        //

        #[link_section = ".ctors.65535"] // oogqirha. *: C yokuqalisa ukubuyisa umva
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C ukuphelisa ukubuyela umva
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}