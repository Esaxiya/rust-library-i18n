#![stable(feature = "rust1", since = "1.0.0")]

//! Izalathiso zokubala ezikhuselekileyo zokhuselo.
//!
//! Jonga amaxwebhu e [`Arc<T>`][Arc] ngeenkcukacha ezithe kratya.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Umda othambileyo kwisixa seereferensi ezinokwenziwa kwi `Arc`.
///
/// Ukuya ngaphezulu kwalo mda kuya kuyiphelisa inkqubo yakho (nangona kungenjalo) kwizalathiso ze _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// I-ThreadSanitizer ayixhasi imemori yocingo.
// Ukuthintela iingxelo ezingezizo kwi-Arc/Ebuthathaka ekusebenziseni imithwalo yeathom kulungelelwaniso endaweni yoko.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Isalathiso sokubala esikhuselekileyo sokhuseleko.I 'Arc' imele 'ukubalwa kokubhekiswa kweatom'.
///
/// Uhlobo lwe `Arc<T>` lubonelela ngobunini ekwabelwana ngabo bexabiso lohlobo `T`, elabiwe kwimfumba.Ukungenisa i-[`clone`][clone] kwi-`Arc` kuvelisa umzekelo omtsha we-`Arc`, okhomba kulwabiwo olufanayo kwimfumba njengomthombo `Arc`, ngelixa usonyusa inani lesalathiso.
/// Xa isikhombisi sokugqibela se `Arc` kulwabiwo olunikiweyo lutshatyalalisiwe, ixabiso eligcinwe kolo lwabiwo (ihlala ibizwa ngokuba yi "inner value") nalo liyehla.
///
/// Iireferensi ekwabelwana ngazo kwi-Rust ayivumeli utshintsho ngokwendalo, kwaye i-`Arc` ayisiyonto ikhethiweyo: ngekhe ufumane isalathiso esinokutshintshwa kwinto ethile ngaphakathi kwe `Arc`.Ukuba ufuna ukuguquka nge `Arc`, sebenzisa i [`Mutex`][mutex], [`RwLock`][rwlock], okanye enye yeendidi ze [`Atomic`][atomic].
///
/// ## Ukhuseleko lomtya
///
/// Ngokungafaniyo ne [`Rc<T>`], i `Arc<T>` isebenzisa imisebenzi yeatom ukubala kwayo.Oku kuthetha ukuba ikhuselekile ngentambo.Ukungancedi kukuba ukusebenza kweathom kubiza kakhulu kunokufikelela kwimemori kwesiqhelo.Ukuba awabelani ngesabelo-esabelwe ulwabiwo phakathi kwemisonto, cinga ukusebenzisa i [`Rc<T>`] ngaphezulu kwentloko.
/// [`Rc<T>`] kukusilela okukhuselekileyo, kuba umhlanganisi uya kubamba nayiphi na inzame yokuthumela i [`Rc<T>`] phakathi kwemisonto.
/// Nangona kunjalo, ithala leencwadi linokukhetha i `Arc<T>` ukwenzela ukunika abathengi bethala leencwadi ubhetyebhetye ngakumbi.
///
/// `Arc<T>` izakuphumeza i [`Send`] kunye ne [`Sync`] okoko i `T` isebenzisa i [`Send`] kunye ne [`Sync`].
/// Kutheni le nto ungalubeki uhlobo olungakhuselekanga ngomsonto `T` kwi `Arc<T>` ukuyenza ikhuseleke ngentambo?Oku kunokuba yinto ephikisayo ekuqaleni: emva kwayo yonke loo nto, ayisiyiyo inqaku lokhuseleko lwe-`Arc<T>`?Isitshixo yile: `Arc<T>` iyenza ukuba intambo ikhuseleke ekubeni nobunini beedatha ezifanayo, kodwa ayongezi ukhuseleko kumsonto kwidatha yayo.
///
/// Cinga `iArc <` [`Ref Refell<T>`]>>.
/// [`RefCell<T>`] ayisiyi [`Sync`], kwaye ukuba i `Arc<T>` yayihlala iyi [`Send`], `Arc <` [`RefCell<T>`]`> iya kuba njalo.
/// Kodwa emva koko siza kuba nengxaki:
/// [`RefCell<T>`] ayikhuselekanga ngentambo;Igcina umkhondo wenani lokuboleka usebenzisa imisebenzi engeyiyo eye-atom.
///
/// Ekugqibeleni, oku kuthetha ukuba unokufuna ukubhangqa i-`Arc<T>` kunye nohlobo oluthile lwe-[`std::sync`], ihlala i-[`Mutex<T>`][mutex].
///
/// ## Ukophula imijikelezo nge `Weak`
///
/// Indlela ye [`downgrade`][downgrade] inokusetyenziselwa ukwenza isikhombisi esingesiso esakhe [`Weak`].Isikhombisi se [`Weak`] sinokuba [`uphuculo`][hlaziya] d ukuya kwi `Arc`, kodwa oku kuyakubuyisa i [`None`] ukuba ixabiso eligcinwe kulwabiwo sele lilahliwe.
/// Ngamanye amagama, izikhombisi ze `Weak` azigcini ixabiso ngaphakathi kolwabiwo liphila;Nangona kunjalo, * bayalugcina ulwabiwo (ivenkile exhasa ixabiso) iphila.
///
/// Umjikelo phakathi kwezikhombisi ze `Arc` awusoze uhanjiswe.
/// Ngesi sizathu, i [`Weak`] isetyenziselwa ukwaphula imijikelezo.Umzekelo, umthi unokuba nezikhombisi ezomeleleyo ze `Arc` ukusuka kwiindawo zomzali ukuya kubantwana, kunye nezikhombisi ze [`Weak`] ezisuka kubantwana ezibuyela kubazali babo.
///
/// # Izikhombisi zekonon
///
/// Ukwenza ireferensi entsha evela kwisalathiso esele sibaliwe senziwe kusetyenziswa i `Clone` trait ephunyezwe nge [`Arc<T>`][Arc] kunye ne [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ezi syntax zimbini zingezantsi ziyalingana.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, kunye no-foo zonke iiArcs ezalatha kwindawo efanayo yenkumbulo
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` Dereferensi ngokuzenzekelayo kwi `T` (nge [`Deref`][deref] trait), ukuze ubize iindlela zika-T kwixabiso lohlobo `Arc<T>`.Ukuthintela ukungqubana kwamagama ngeendlela ze-T`, iindlela ze-`Arc<T>` uqobo zinxulumene nemisebenzi, ebizwa ngokuba yi-[fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// IArc<T>Ukuphunyezwa kwe traits ezinje nge `Clone` kunokubizwa kusetyenziswa is syntax efanelekileyo.
/// Abanye abantu bakhetha ukusebenzisa isichazi esifanelekileyo, ngelixa abanye bekhetha ukusebenzisa indlela yokubiza umnxeba.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Indlela yokubiza i-syntax
/// let arc2 = arc.clone();
/// // Is syntax efanelekileyo ngokupheleleyo
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ayisiyisi-auto-dereferensi kwi `T`, kuba ixabiso langaphakathi lisenokuba sele lilahliwe.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Ukwabelana ngedatha engaguqukiyo phakathi kwemisonto:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Qaphela ukuba **asizenzi** ezi mvavanyo apha.
// Abakhi be windows abafumani lonwabo lukhulu ukuba intambo ingaphezulu komsonto ophambili ize iphume ngaxeshanye (into evaliweyo) ke siyiphepha le nto ngokungazenzi ezi mvavanyo.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Ukwabelana nge [`AtomicUsize`] enokutshintsha:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Bona i [`rc` documentation][rc_examples] yeminye imizekelo yokubalwa kwesalathiso ngokubanzi.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` Inguqulelo ye [`Arc`] ebambe isalathiso esingeyiso esakho kulwabiwo olulawulwayo.
/// Ulwabiwo lufikeleleke ngokubiza i [`upgrade`] kwisikhombisi se `Weak`, esibuyisela [`Option`]`<<[`Arc`]` `<T>>`.
///
/// Kuba ireferensi ye `Weak` ayibali kubunini, ayizukuthintela ixabiso eligcinwe kulwabiwo ekuyekisweni, kwaye i `Weak` ngokwayo ayenzi siqinisekiso malunga nexabiso elisekho.
///
/// Yiyo ke loo nto inokubuyisa i [`None`] xa [`hlaziya`] d.
/// Qaphela nangona kunjalo ukuba isalathiso se `Weak` * siyaluthintela ulwabiwo ngokwalo (ivenkile exhasa) ekuhanjisweni.
///
/// Isikhombisi se `Weak` siluncedo ekugcineni ireferensi yethutyana kulwabiwo olulawulwa yi [`Arc`] ngaphandle kokuthintela ixabiso langaphakathi ekuhlisweni.
/// Isetyenziselwa ukuthintela izingqinisiso ezijikelezayo phakathi kwezikhombisi ze [`Arc`], kuba ukubangumnini wokubambisana akunakuvumela nokuba i [`Arc`] ilahlwe.
/// Umzekelo, umthi unokuba nezikhombisi ezomeleleyo ze [`Arc`] ukusuka kwiindawo zomzali ukuya kubantwana, kunye nezikhombisi ze `Weak` ezisuka kubantwana ababuyela kubazali babo.
///
/// Indlela eqhelekileyo yokufumana isikhombisi se `Weak` kukufowuna i [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Le yi `NonNull` yokuvumela ukwandiswa kobungakanani bolu hlobo kwii-enum, kodwa ayisiyiyo isikhombisi esisemthethweni.
    //
    // `Weak::new` icwangcisa oku ku-`usize::MAX` ukuze ingafuneki yabele indawo kwimfumba.
    // Eli ayiloxabiso lesikhombisi sokwenyani esiya kuba nalo kuba i-RcBox ilungelelanise ubuncinci i-2.
    // Oku kunokwenzeka kuphela xa i `T: Sized`;i-`T` engafakwanga khange iphazamise.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Le yi-repr(C) ukuya kwi-future-ubungqina ngokuchasene nokuhlengahlengiswa kwentsimi okunokuthi kuphazamise enye i-[into|from]_raw() ekhuselekileyo yeentlobo zangaphakathi ezinokudluliselwa.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // Ixabiso le usize::MAX lisebenza njengomthumeli okwethutyana i "locking" amandla okuphucula izikhombisi ezibuthathaka okanye ukuthoba ezomeleleyo;oku kusetyenziselwa ukunqanda umdyarho kwi-`make_mut` kunye ne-`get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Yakha i `Arc<T>` entsha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Qalisa ukubala kwesikhombisi esibuthathaka njengo-1 sisikhombisi esibuthathaka esigcinwe zizikhombisi ezomeleleyo (kinda), bona i std/rc.rs ngolwazi oluthe kratya
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Yakha i `Arc<T>` entsha isebenzisa ireferensi ebuthathaka kuyo.
    /// Ukuzama ukuphucula isalathiso esibuthathaka ngaphambi kokuba lo msebenzi ubuye kuya kukhokelela kwixabiso le `None`.
    /// Nangona kunjalo, ireferensi ebuthathaka inokudityaniswa ngokukhululekileyo kwaye igcinelwe ukusetyenziswa kamva.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Yakha ngaphakathi kwimo ye "uninitialized" ngesalathiso esinye esibuthathaka.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Kubalulekile ukuba singabuncami ubunini besikhombisi esibuthathaka, kungenjalo imemori inokukhululwa ngexesha lokubuya kwe `data_fn`.
        // Ukuba ngenene sifuna ukugqithisa ubunini, sinokuzenzela isikhombisi esibuthathaka, kodwa oku kungakhokelela kuhlaziyo olongezelelekileyo kubalo lwesalathiso esibuthathaka esinokungafuneki ngenye indlela.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ngoku sinokuqalisa ngokufanelekileyo ixabiso langaphakathi kwaye siguqule ireferensi yethu ebuthathaka ibe sisalathiso esomeleleyo.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Oku kungasentla kubhala kwicandelo ledatha kufuneka kubonakale nakweyiphi na imisonto ejonga ukubala okungashukumiyo.
            // Ke ngoko sifuna ubuncinci boku-odola i "Release" ukuze sikwazi ukungqamanisa ne `compare_exchange_weak` kwi `Weak::upgrade`.
            //
            // "Acquire" uku-odola akufuneki.
            // Xa ujonga indlela yokuziphatha enokwenzeka ye `data_fn` kufuneka sijonge kuphela into enokuyenza ngokubhekisa kwi `Weak` engaphuculiyo:
            //
            // - Inokuthi *idibanise* i `Weak`, inyuse inani elibuthathaka lesalathiso.
            // - Inokuwisa ezo zinto zingaphezulu, kunciphise ukubalwa kokubhekiswa kubuthathaka (kodwa ungaze uye zero).
            //
            // Ezi ziphumo zingasichaphazeli nangayiphi na indlela, kwaye akukho ziphumo zimbi zinokwenzeka ngekhowudi ekhuselekileyo iyodwa.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Izalathiso ezomeleleyo kufuneka zihlanganiselwe ukuba zibe nezalathiso ezibuthathaka ekwabelwana ngazo, ke musa ukuqhuba umonakalisi wesalathiso sethu esidala esibuthathaka.
        //
        mem::forget(weak);
        strong
    }

    /// Yakha i `Arc` entsha enemixholo engachazwanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yakha i `Arc` entsha enemixholo engachazwanga, inkumbulo izaliswe zii-`0` byte.
    ///
    ///
    /// Jonga i [`MaybeUninit::zeroed`][zeroed] ngemizekelo yokusetyenziswa ngokuchanekileyo nangokungachanekanga kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yakha i `Pin<Arc<T>>` entsha.
    /// Ukuba i-`T` ayizalisekisi i-`Unpin`, emva koko i-`data` iya kuphawulwa kwimemori kwaye ayikwazi kushenxiswa.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Yakha i `Arc<T>` entsha, ibuyisa impazamo ukuba ulwabiwo aluphumeleli.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Qalisa ukubala kwesikhombisi esibuthathaka njengo-1 sisikhombisi esibuthathaka esigcinwe zizikhombisi ezomeleleyo (kinda), bona i std/rc.rs ngolwazi oluthe kratya
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Yakha i `Arc` entsha enemixholo engachazwanga, ibuyisa impazamo ukuba ulwabiwo aluphumelelanga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Yakha i `Arc` entsha enemixholo engachazwanga, inkumbulo izaliswe zii-`0` byte, ibuyisa impazamo ukuba ulwabiwo aluphumelelanga.
    ///
    ///
    /// Jonga i [`MaybeUninit::zeroed`][zeroed] ngemizekelo yokusetyenziswa ngokuchanekileyo nangokungachanekanga kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ibuyisa ixabiso langaphakathi, ukuba i `Arc` inesalathiso esinye esomeleleyo.
    ///
    /// Ngaphandle koko, i [`Err`] ibuyiselwa i-`Arc` efanayo eyadlulisiweyo.
    ///
    ///
    /// Oku kuyakuphumelela nokuba kukho izingqinisiso ezibuthathaka ezibalaseleyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Yenza isikhombisi esibuthathaka ukucoca ireferensi eyomeleleyo-ebuthathaka
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Yakha isilayidi esitsha esine-atomically-counted with imixholo engachazwanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Yakha isilayidi esine-atomic esine-atomiki esineziqulatho ezingafakwanga, imemori izaliswa zii-`0` byte.
    ///
    ///
    /// Jonga i [`MaybeUninit::zeroed`][zeroed] ngemizekelo yokusetyenziswa ngokuchanekileyo nangokungachanekanga kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Uguqula abe ngu-`Arc<T>`.
    ///
    /// # Safety
    ///
    /// Njengakwi [`MaybeUninit::assume_init`], kuxhomekeke kulowo ufowunayo ukuqinisekisa ukuba ixabiso langaphakathi ngokwenyani likwisimo sokuqala.
    ///
    /// Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela indlela yokuziphatha engachazwanga kwangoko.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Uguqula abe ngu-`Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Njengakwi [`MaybeUninit::assume_init`], kuxhomekeke kulowo ufowunayo ukuqinisekisa ukuba ixabiso langaphakathi ngokwenyani likwisimo sokuqala.
    ///
    /// Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela indlela yokuziphatha engachazwanga kwangoko.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Isebenzisa i `Arc`, ibuyisa isalathiso esisongelweyo.
    ///
    /// Ukuthintela ukuvuza kwenkumbulo, isikhombisi kufuneka siguqulwe sibuyele kwi `Arc` kusetyenziswa i [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ukubonelela ngesikhombisi esiluhlaza kwidatha.
    ///
    /// Ubalo aluchaphazeleki nangayiphi na indlela kwaye i `Arc` ayisetyenziswanga.
    /// Isikhombisi sisebenza ixesha elide ukuba kukho ukubalwa okunamandla kwi `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // UKHUSELEKO: Oku akunakudlula kwi Deref::deref okanye kwi RcBoxPtr::inner kuba
        // oku kuyadingeka ukugcina i-raw/mut yemvelaphi enje umz
        // `get_mut` Ungabhala ngesikhombisi emva kokuba i-Rc ifunyenwe kwi `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Yakha i `Arc<T>` kwisikhombisi esiluhlaza.
    ///
    /// Isalathiso esiluhlaza kufuneka ukuba sasibuyiselwe umnxeba kwi-[`Arc<U>::into_raw`][into_raw] apho i-`U` kufuneka ibenobungakanani obulinganayo kunye nolungelelwaniso njenge-`T`.
    /// Kuyinyani ngokuqinisekileyo ukuba i `U` yi `T`.
    /// Qaphela ukuba i `U` ayisiyi-`T` kodwa inobungakanani obulinganayo kunye nolungelelwaniso, oku ngokusisiseko kufana nokuhambisa izingqinisiso zeentlobo ezahlukeneyo.
    /// Bona i [`mem::transmute`][transmute] ngolwazi oluthe kratya malunga nokuba zeziphi izithintelo ezisebenza kule meko.
    ///
    /// Umsebenzisi we `from_raw` kufuneka aqinisekise ukuba ixabiso elithile le `T` liyehliswe kube kanye.
    ///
    /// Lo msebenzi awukhuselekanga kuba ukusetyenziswa gwenxa kungakhokelela kwimemori engakhuselekanga, nokuba i `Arc<T>` ebuyisiweyo ayinakufikelelwa.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Guqula ubuyele kwi `Arc` ukunqanda ukuvuza.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ukufowuna ngakumbi kwi `Arc::from_raw(x_ptr)` kuya kuba kukungakhuseleki kwimemori.
    /// }
    ///
    /// // Imemori yakhululwa xa i `x` yaphuma kumda ongentla, ke i `x_ptr` ngoku ilenga!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Revenue offset ukufumana iArcInner yoqobo.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Yenza isikhombisi esitsha se [`Weak`] kolu lwabiwo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Oku kuphumla kulungile kuba sijonga ixabiso kwi-CAS engezantsi.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // jonga ukuba ngaba ikhawuntari ebuthathaka kungoku nje yi "locked";ukuba kunjalo, jikeleza.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: le khowudi ngoku iyabutyeshela ubukho bokugcwala
            // kwi usize::MAX;Ngokubanzi zombini i-Rc kunye neArc kufuneka zilungelelaniswe ukuze zijongane nokuphuphuma.
            //

            // Ngokungafaniyo ne Clone(), sidinga ukuba oku kube kukuFumana ukufundwa ukuze kungqamane nokubhala okuvela kwi `is_unique`, ukuze iziganeko zaphambi kokubhala zenzeke ngaphambi kokufundwa.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Qinisekisa ukuba asenzi into ebuthathaka ebuthathaka
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Ufumana inani lezikhombisi ze [`Weak`] kolu lwabiwo.
    ///
    /// # Safety
    ///
    /// Le ndlela ngokwayo ikhuselekile, kodwa ukuyisebenzisa ngokuchanekileyo kufuna ukhathalelo olongezelelekileyo.
    /// Olunye umsonto unokutshintsha ukubala okubuthathaka nangaliphi na ixesha, kubandakanya phakathi kokubiza le ndlela kunye nokwenza iziphumo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Eli bango limiselwe ngenxa yokuba singabelananga nge `Arc` okanye i `Weak` phakathi kwemisonto.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ukuba ubalo olubuthathaka lutshixiwe okwangoku, ixabiso lobalo belingu-0 ngaphambi nje kokuthatha isitshixo.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Ifumana inani lezikhombisi ezomeleleyo ze (`Arc`) kolu lwabiwo.
    ///
    /// # Safety
    ///
    /// Le ndlela ngokwayo ikhuselekile, kodwa ukuyisebenzisa ngokuchanekileyo kufuna ukhathalelo olongezelelekileyo.
    /// Olunye umsonto unokutshintsha ukubala okuqinileyo nangaliphi na ixesha, kubandakanya nokubakho phakathi kwale ndlela kunye nokwenza iziphumo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Eli bango limiselwe ngenxa yokuba singabelananga nge `Arc` phakathi kwemisonto.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Ukonyusa isibalo esomeleleyo sereferensi kwi `Arc<T>` enxulunyaniswa nesikhombisi esibonelelweyo nganye
    ///
    /// # Safety
    ///
    /// Isikhombisi kufuneka sifunyenwe nge `Arc::into_raw`, kwaye imeko enxulumene ne `Arc` kufuneka isebenze (okt
    /// ubalo olomeleleyo kufuneka okungenani lube li-1 ngalo lonke ixesha lokusebenzisa le ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Eli bango limiselwe ngenxa yokuba singabelananga nge `Arc` phakathi kwemisonto.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Gcina iArc, kodwa ungachukumisi ukubala kwakhona ngokusonga kwi-ManualDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Ngoku yonyusa ukubala kwakhona, kodwa musa ukulahla ukubala kwakhona
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Ukuncipha kwesalathiso esomeleleyo sokubala kwi `Arc<T>` enxulunyaniswa nesikhombisi esinikiweyo esinye.
    ///
    /// # Safety
    ///
    /// Isikhombisi kufuneka sifunyenwe nge `Arc::into_raw`, kwaye imeko enxulumene ne `Arc` kufuneka isebenze (okt
    /// ubalo olomeleleyo kufuneka okungenani lube yi-1) xa ucela le ndlela.
    /// Le ndlela inokusetyenziselwa ukukhupha i-`Arc` yokugqibela kunye nokugcina inkxaso, kodwa **akufuneki** kubizwe emva kokuba i `Arc` yokugqibela ikhutshiwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ezo zibhengezo zichongiwe kuba khange sabelane nge `Arc` phakathi kwemisonto.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Oku kungakhuselekanga kulungile kuba ngelixa le arc isaphila siqinisekisiwe ukuba isalathiso sangaphakathi siyasebenza.
        // Ngapha koko, siyazi ukuba ulwakhiwo lwe `ArcInner` ngokwalo luyi `Sync` kuba idatha engaphakathi yi `Sync` ngokunjalo, ke sikulungele ukuboleka isikhombisi esingaguqukiyo kwezi ziqulatho.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Icandelo elingamiselwanga le `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Tshabalalisa idatha ngeli xesha, nangona singenakho ukukhulula ulwabiwo ngokwalo (kusenokubakho izikhombisi ezibuthathaka ezilele ngapha nangapha).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Yilahle into ebuthathaka egcinwe ngokudibeneyo kuzo zonke izingqinisiso eziqinileyo
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ibuyisa i `true` ukuba zombini `iArc` zikhomba kulwabiwo olufanayo (kumthambo ofana no [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Yabela i `ArcInner<T>` ngendawo eyoneleyo yexabiso langaphakathi elingenakulinganiswa apho ixabiso linobume obunikezelweyo.
    ///
    /// Umsebenzi u-`mem_to_arcinner` ubizwa ngesikhombisi sedatha kwaye kufuneka abuyisele i (pointer ye-fat) ye-`ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Bala ubeko usebenzisa ubeko lwexabiso elinikiweyo.
        // Ngaphambili, ubeko lwalubalwa kwisivakalisi `&*(ptr as* const ArcInner<T>)`, kodwa oku kwenza ireferensi engachanekanga (jonga i #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Yabela i `ArcInner<T>` ngendawo eyoneleyo yexabiso langaphakathi elingasetyenziswanga apho ixabiso linobume obubonelelweyo, ukubuyisa impazamo ukuba ulwabiwo lusilele.
    ///
    ///
    /// Umsebenzi u-`mem_to_arcinner` ubizwa ngesikhombisi sedatha kwaye kufuneka abuyisele i (pointer ye-fat) ye-`ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Bala ubeko usebenzisa ubeko lwexabiso elinikiweyo.
        // Ngaphambili, ubeko lwalubalwa kwisivakalisi `&*(ptr as* const ArcInner<T>)`, kodwa oku kwenza ireferensi engachanekanga (jonga i #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Qalisa iArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Yabela i `ArcInner<T>` ngesithuba esaneleyo sexabiso langaphakathi elingalinganiswanga.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Yabela `ArcInner<T>` usebenzisa ixabiso elinikiweyo.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Khuphela ixabiso njengee-byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Simahla ulwabiwo ngaphandle kokulahla imixholo yalo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Yabela i `ArcInner<[T]>` ngobude obunikiweyo.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Khuphela izinto kwisilayidi usiya kwi-Arc <\[T\]>
    ///
    /// Ayikhuselekanga ngenxa yokuba umntu ekutsalele umnxeba kufuneka athathe ubunini okanye abophe i `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Yakha i `Arc<[T]>` esuka kwiterator eyaziwayo ukuba inobungakanani obuthile.
    ///
    /// Ukuziphatha akuchazwanga ukuba ubungakanani bungalunganga.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic unogada ngelixa ubumbela izinto zeT.
        // Kwimeko ye panic, izinto ezibhalwe kwiArcInner entsha ziya kulahlwa, emva koko imemori iya kukhululwa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Isalathiso kwinto yokuqala
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Zonke zicacile.Ulibale unogada ukuze ingamkhululi iArcInner entsha.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Ubungcali be trait isetyenziselwe i `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Yenza ikhonkco lesikhombisi se `Arc`.
    ///
    /// Oku kudala esinye isikhombisi kulwabiwo olufanayo, ukwandisa ukubalwa kwesalathiso esomeleleyo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Sebenzisa iodolo ekhululekile kulungile apha, njengoko ulwazi lwesalathiso sentsusa luthintela eminye imisonto ekususeni ngempazamo into.
        //
        // Njengoko kucacisiwe kwi [Boost documentation][1], ukonyusa ireferensi kunokuhlala kwenziwa nge-memory_order_relaxed: Izalathiso ezitsha zento zinokwenziwa kuphela kwisalathiso esele sikhona, kwaye ukugqithisa ireferensi esele ikho ukusuka kumsonto omnye ukuya kolunye kufuneka sele ikwenzile ukungqinelanisa okufunekayo.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Nangona kunjalo kufuneka sikulumkele ukubalwa kwakhona okukhulu xa umntu esithi 'mem: : alibale iiArcs.
        // Ukuba asikwenzi oku ukubala kungaphuphuma kwaye abasebenzisi baya kusebenzisa-emva simahla.
        // Sihlutha ngokobuhlanga ukuya kwi-`isize::MAX` kwinto yokuba akukho misonto ye-~2 yezigidigidi eyonyusa inani lesalathiso kwangoko.
        //
        // Le branch ayinakuze ithathwe nakweyiphi na inkqubo eyiyo.
        //
        // Sikhupha isisu kuba inkqubo enjalo iya isiba mandundu, kwaye asikhathali ukuyixhasa.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Yenza ireferensi enokuguquguquka kwi `Arc` enikiweyo.
    ///
    /// Ukuba kukho ezinye izikhokelo ze `Arc` okanye i [`Weak`] kulwabiwo olufanayo, i `make_mut` iyakwenza ulwabiwo olutsha kwaye ibize i [`clone`][clone] kwixabiso langaphakathi ukuqinisekisa ubunini obukhethekileyo.
    /// Oku kukwabhekiswa kuko njenge-clone-on-write.
    ///
    /// Qaphela ukuba oku kwahlukile kwindlela yokuziphatha ye [`Rc::make_mut`] eyahlulahlula naziphi na izikhombisi ze `Weak`.
    ///
    /// Jonga kwakhona i [`get_mut`][get_mut], eya kuthi isilele endaweni yokwenza ikhonkrithi.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Awuyi kwenza nantoni na
    /// let mut other_data = Arc::clone(&data); // Awuyi kulungelelanisa idatha yangaphakathi
    /// *Arc::make_mut(&mut data) += 1;         // Clones idatha yangaphakathi
    /// *Arc::make_mut(&mut data) += 1;         // Awuyi kwenza nantoni na
    /// *Arc::make_mut(&mut other_data) *= 2;   // Awuyi kwenza nantoni na
    ///
    /// // Ngoku i `data` kunye ne `other_data` yalatha kulwabiwo olwahlukileyo.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Qaphela ukuba sibambe zombini isalathiso esomeleleyo kunye nesalathiso esibuthathaka.
        // Ke, ukukhupha ireferensi yethu eyomeleleyo kuphela, ngekodwa, kunokubangela ukuba imemori ihanjiswe.
        //
        // Sebenzisa Fumana ukuze uqinisekise ukuba sibona nayiphi na into ebhalelwa i `weak` eyenzeka ngaphambi kokukhutshwa kubhala (okt ukwehla) ukuya kwi `strong`.
        // Kuba sibambe ubuthathaka, akukho thuba lokuba iArcInner ngokwayo ihanjiswe.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Esinye isikhombisi esomeleleyo sikhona, ke kufuneka sisebenzisane.
            // Nika imemori kwangaphambili ukuvumela ukuba kubhalwe ixabiso elenziwe ngokuthe ngqo.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ukuphumla kwanele koku kungasentla kuba oku sisiseko sokwakha: sihlala sibaleka ngezikhombisi ezibuthathaka ezilahlwayo.
            // Eyona meko imbi, sigqiba ekubeni sabelwe iArc entsha ngokungeyomfuneko.
            //

            // Sisusile i-Ref yokugqibela eyomeleleyo, kodwa kukho ezinye izinto ezibuthathaka ezishiyekileyo.
            // Siza kuhambisa imixholo siye kwiArc entsha, kwaye sizenze zingasebenzi ezinye izinto ezibuthathaka.
            //

            // Qaphela ukuba akunakwenzeka ukuba ifundwe i-`weak` ivelise i-usize::MAX (okt, itshixiwe), kuba isibalo esibuthathaka sinokutshixwa kuphela ngentambo ngesalathiso esomeleleyo.
            //
            //

            // Isiphatho sesikhombisi esibuthathaka esibonakalayo, ukuze icoce iArcInner njengoko kufuneka.
            //
            let _weak = Weak { ptr: this.ptr };

            // Ngaba unokuba idatha, konke okushiyekileyo bubuthathaka
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Sasiyiyo kuphela isalathiso salo naluphi na uhlobo;yibuyisele umva ubalo olomeleleyo lwe-Ref
            //
            this.inner().strong.store(1, Release);
        }

        // Njengakwi `get_mut()`, ukungakhuseleki kulungile kuba ireferensi yethu yayiyeyokuqala ukuqala, okanye yaba yinto enye xa kusenziwa umxholo.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Ibuyisela ireferensi enokutshintsha kwi-`Arc` enikiweyo, ukuba azikho ezinye i-`Arc` okanye i-[`Weak`] izikhombisi kulwabiwo olufanayo.
    ///
    ///
    /// Ibuyisa i [`None`] ngenye indlela, kuba akukhuselekanga ukutshintsha ixabiso ekwabelwana ngalo.
    ///
    /// Jonga kwakhona i [`make_mut`][make_mut], eya kuthi i [`clone`][clone] ixabiso langaphakathi xa kukho ezinye izikhombisi.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Oku kungakhuselekanga kulungile kuba siqinisekisiwe ukuba isikhombisi sibuyisiwe sisikhombisi *kuphela* esiya kubuyiselwa ku-T.
            // Inani lethu lesalathiso liqinisekisiwe ukuba li-1 kweli nqanaba, kwaye sifuna iArc ngokwayo ibe ngu-`mut`, ke sibuyisela ekuphela kwereferensi enokubakho kwidatha yangaphakathi.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Ibuyisela ireferensi enokutshintsha kwi `Arc`, ngaphandle kwetshekhi.
    ///
    /// Jonga kwakhona i [`get_mut`], ekhuselekileyo kwaye ihlola ngokufanelekileyo.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Nayiphi na enye i-`Arc` okanye i-[`Weak`] yesikhombisi kulwabiwo olufanayo akufuneki iphinde ichazwe ixesha elibuyisiweyo.
    ///
    /// Oku kuyinto encinci ukuba akukho zikhombisi zikhoyo, umzekelo kwangoko emva kwe `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Silumkile ukuba *singenzi* ireferensi egubungela imihlaba ye "count", njengoko oku kungafana nokufikelela ngokufanayo kubalo lwesalathiso (umz.
        // nge `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Chonga ukuba ngaba le ireferensi eyahlukileyo (kubandakanywa ii-Refs ezibuthathaka) kwidatha engaphantsi.
    ///
    ///
    /// Qaphela ukuba oku kufuna ukutshixwa ukubala okungafunekiyo.
    fn is_unique(&mut self) -> bool {
        // Tshixa ukubala kwesikhombisi esibuthathaka ukuba sibonakala ngathi sesona siphathi sibuthathaka.
        //
        // Ukufumana ilebheli apha kuqinisekisa ukuba kwenzeka ngaphambili-kobudlelwane kunye nokubhala kuye kwi-`strong` (ngakumbi kwi-`Weak::upgrade`) ngaphambi kokuhla kwenani le-`weak` (nge-`Weak::drop`, esebenzisa ukukhutshwa).
        // Ukuba i-Ref ebuthathaka ephuculweyo ayizange yehliswe, i-CAS apha iya kusilela ngenxa yoko asikhathali ukungqamanisa.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Oku kufuna ukuba yi `Acquire` ukungqamanisa nokuncitshiswa kwekhawuntara ye `strong` kwi `drop`-ukuphela kofikelelo olwenzekayo xa nayiphi na enye kodwa ireferensi yokugqibela iyehla.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Ukukhutshwa bhala apha kungqamana nokufundwa kwi `downgrade`, kuthintela ngokufanelekileyo ukufundwa okungasentla kwe `strong` ekubeni kwenzeke emva kokubhala.
            //
            //
            self.inner().weak.store(1, Release); // khulula isitshixo
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Uwisa i `Arc`.
    ///
    /// Oku kuya kunciphisa ukubalwa kwesalathiso esomeleleyo.
    /// Ukuba isibalo esomeleleyo sesalathiso sifikelela kwi-zero ke ezinye izingqinisiso (ukuba zikhona) zi-[`Weak`], ke thina si-`drop` ixabiso langaphakathi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ayiprinti nantoni na
    /// drop(foo2);   // Ishicilela "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Kuba i `fetch_sub` sele i-athomu, akufuneki sidibanise neminye imisonto ngaphandle kokuba siza kuyicima into.
        // Kwale ingcinga inye isebenza kwi-`fetch_sub` engezantsi kwinani le-`weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Olu cingo luyafuneka ukunqanda ukuhlela kwakhona ukusetyenziswa kwedatha kunye nokucinywa kwedatha.
        // Kuba iphawulwe i `Release`, ukuhla kokubalwa kwesalathiso kungqamana nale `Acquire` yocingo.
        // Oku kuthetha ukuba ukusetyenziswa kwedatha kwenzeka ngaphambi kokunciphisa ukubalwa kwesalathiso, okwenzeka phambi kocingo, olwenzeka ngaphambi kokucinywa kwedatha.
        //
        // Njengoko kuchaziwe kwi [Boost documentation][1],
        //
        // > Kubalulekile ukunyanzelisa nakuphi na ukufikelela kwinto enye
        // > umsonto (ngesalathiso esele sikhona) ukuba kwenzeke ngaphambi kokucima
        // > into ngentambo eyahlukileyo.Oku kufezekiswa nge "release"
        // > ukusebenza emva kokulahla ireferensi (nakuphi na ukufikelela kwinto
        // > ngale ngxelo kufuneka ukuba yenzeke ngaphambili), kunye ne
        // > "acquire" ukusebenza ngaphambi kokucima into.
        //
        // Ngokukodwa, ngelixa imixholo yeArc ihlala ingaguquki, kunokwenzeka ukuba ngaphakathi kubhalelwe into efana neMutex<T>.
        // Kuba iMutex ayifunyanwanga xa icinyiwe, asinakuthembela kulungelelwaniso lwayo logic ukwenza ukubhala kumsonto A kubonakale kumonakalisi osebenza kumsonto B.
        //
        //
        // Qaphela ukuba Fumanisa ucingo apha lungatshintshwa lufumane umthwalo, onokuthi uphucule ukusebenza kwiimeko eziphikisanayo.Jonga i [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Ukuzama ukwehlisa i `Arc<dyn Any + Send + Sync>` kuhlobo lwekhonkrithi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Yakha i `Weak<T>` entsha, ngaphandle kokwaba nayiphi na inkumbulo.
    /// Ukutsalela umnxeba i [`upgrade`] kwixabiso lokubuya kuhlala kunika i [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Uhlobo lomncedisi ukuvumela ukufikelela kubalo lwesalathiso ngaphandle kokwenza naziphi na izibhengezo malunga nomhlaba wedatha.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Ibuyisela isikhombisi esiluhlaza kwinto engu-`T` esalatha kule `Weak<T>`.
    ///
    /// Isikhombisi sisebenza kuphela ukuba kukho izingqinisiso ezithile ezomeleleyo.
    /// Isikhombisi sinokuxhonywa, singatyunjeliswanga okanye i [`null`] ngenye indlela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Zombini zikhomba kwinto enye
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ukomelela apha kuyigcina iphila, kungoko sinokwazi ukufikelela kwinto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Kodwa hayi ngaphezulu.
    /// // Singayenza i weak.as_ptr(), kodwa ukufikelela kwisikhombisi kungakhokelela kwindlela yokuziphatha engachazwanga.
    /// // assert_eq! ("molo", ayikhuselekanga {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ukuba isikhombisi sixhonyiwe, sibuyisela umthumeli ngqo.
            // Le ayinakuba yidilesi yokuhlawula esemthethweni, njengoko umthwalo ohlawulwayo ubuncinci ulungelelaniswe neArcInner (usize).
            ptr as *const T
        } else {
            // UKHUSELEKO: ukuba_ukulengisa kubuya kubuxoki, isikhombisi asinakuphinda senziwe.
            // Umrhumo wokuhlawulwa ungaphoswa kweli nqanaba, kwaye kuya kufuneka sigcine imvelaphi, ke sebenzisa ubuqhetseba besikhombisi eluhlaza.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Isebenzisa i `Weak<T>` kwaye iyijike ibe sisikhombisi esiluhlaza.
    ///
    /// Oku kuguqula isikhombisi esibuthathaka sisikhombisi esiluhlaza, ngelixa sigcina ubunini besalathiso esinye esibuthathaka (inani elibuthathaka alilungiswanga ngulo msebenzi).
    /// Inokubuyiselwa umva kwi `Weak<T>` nge [`from_raw`].
    ///
    /// Izithintelo ezifanayo zokufikelela ekujoliseni kwesikhombisi njenge [`as_ptr`] ziyasebenza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Guqula isikhombisi esiluhlaza esenziwe ngaphambili ngu-[`into_raw`] sibuyele kwi `Weak<T>`.
    ///
    /// Oku kunokusetyenziselwa ukufumana ngokukhuselekileyo ireferensi eyomeleleyo (ngokubiza i [`upgrade`] kamva) okanye ukuhambisa inani elibuthathaka ngokuwisa i `Weak<T>`.
    ///
    /// Kuthatha ubunini besalathiso esinye esibuthathaka (ngaphandle kwezikhombisi ezenziwe yi [`new`], njengoko ezi zingenanto; indlela isasebenza kubo).
    ///
    /// # Safety
    ///
    /// Isikhombisi kufuneka ukuba sivela kwi-[`into_raw`] kwaye kufuneka sisaqhubeka nokuba sinesalathiso esibuthathaka.
    ///
    /// Kuvumelekile ukuba ubalo olomeleleyo lube ngu-0 ngexesha lokufowuna oku.
    /// Nangona kunjalo, oku kuthatha ubunini besalathiso esinye esibuthathaka ngoku simelwe njengesikhombisi esiluhlaza (inani elibuthathaka alilungiswanga ngulo msebenzi) kwaye ke kufuneka libhangqiwe kunye nomnxeba wangaphambili oya kwi [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Linciphise inani lokugqibela elibuthathaka.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Jonga i Weak::as_ptr ngomxholo wendlela isalathiso segalelo esivela ngayo.

        let ptr = if is_dangling(ptr as *mut T) {
            // Oku kujingile Obuthathaka.
            ptr as *mut ArcInner<T>
        } else {
            // Ngaphandle koko, siqinisekisiwe ukuba isikhombisi sivela kubuthathaka obungathandekiyo.
            // UKHUSELEKO: i-data_offset ikhuselekile ukubiza, njengoko i-ptr ireferensi yokwenyani (enokuthi yehliswe) T.
            let offset = unsafe { data_offset(ptr) };
            // Ke, siyibuyisela umva iseti yokufumana iRcBox iphela.
            // UKHUSELEKO: Isikhombisi sivela kwi-Weak, ke oku kulungelelaniswa kukhuselekile.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // UKHUSELEKO: ngoku siyifumene isalathi esibuthathaka santlandlolo, ke sinako ukudala ababuthathaka.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Imizamo yokuphucula isikhombisi se `Weak` ukuya kwi [`Arc`], ukulibazisa ukwehla kwexabiso langaphakathi ukuba liphumelele.
    ///
    ///
    /// Ibuyisa i [`None`] ukuba ixabiso langaphakathi sele lihlile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Tshabalalisa zonke izikhombisi ezomeleleyo.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Sisebenzisa i-CAS loop ukunyusa isibalo esomeleleyo endaweni ye-fetch_add njengoko lo msebenzi ungaze uthathe ubalo lwesalathiso ukusuka kwi-zero ukuya kwenye.
        //
        //
        let inner = self.inner()?;

        // Umthwalo okhululekileyo kuba nakuphi na ukubhala okungu-0 esinokuthi sikuqaphele kushiya intsimi ikwisimo esisisigxina (ke ukufundwa kwe "stale" ngo-0 kulungile), kwaye naliphi na elinye ixabiso liqinisekisiwe nge-CAS engezantsi.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Jonga amagqabantshintshi kwi `Arc::clone` ngokuba kutheni sisenza oku (nge `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Ukuphumla kuyilungele imeko yokungaphumeleli kuba asinakulindela ngakwimeko entsha.
            // Ukufumana kuyimfuneko kwityala lempumelelo lokudibanisa ne `Arc::new_cyclic`, xa ixabiso langaphakathi linokuqaliswa emva kokubekwa kwe `Weak`.
            // Kwimeko apho, silindele ukujonga ixabiso eliqaliswe ngokupheleleyo.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null ihlolwe ngaphezulu
                Err(old) => n = old,
            }
        }
    }

    /// Ifumana inani lezikhombisi ezomeleleyo ze (`Arc`) ezalatha kolu lwabiwo.
    ///
    /// Ukuba i `self` yenziwe kusetyenziswa i [`Weak::new`], oku kuyakubuyela ku-0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Ifumana usondelelo kwinani lezikhombisi ze `Weak` ezikhomba kolu lwabiwo.
    ///
    /// Ukuba i `self` yenziwe kusetyenziswa i [`Weak::new`], okanye ukuba akukho zikhombisi zomeleleyo ziseleyo, oku kuyakubuya 0.
    ///
    /// # Accuracy
    ///
    /// Ngenxa yeenkcukacha zokuphunyezwa, ixabiso elibuyiselweyo linokucinywa ngo-1 kwicala ngalinye xa eminye imisonto ilawula nayiphi na i-Arc`s okanye`Weak`s ekhomba kulwabiwo olunye.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Kuba siqaphele ukuba ubuncinci isikhombisi esomeleleyo emva kokufunda ubalo olubuthathaka, siyazi ukuba ireferensi ebuthathaka engagungqiyo (ikho nanini na xa kukho izikhombisi ezomeleleyo zisaphila) yayisekhona xa sijonga ubalo olubuthathaka, kwaye ke sinokuyikhupha ngokukhuselekileyo.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Ibuyisa i `None` xa isalathi sijinga kwaye akukho `ArcInner` yabelweyo, (okt, xa le `Weak` yenziwe yi-`Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Silumkile ukuba *singenzi* ireferensi egubungela intsimi ye "data", njengoko intsimi inokutshintshwa ngaxeshanye (umzekelo, ukuba i `Arc` yokugqibela ilahliwe, indawo yedatha iya kuphoswa endaweni).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ibuyisa i-`true` ukuba ezi zibini zibuthathaka kulwabiwo olufanayo (olufana ne [`ptr::eq`]), okanye ukuba zombini azikhombisi kulo naluphi na ulwabiwo (kuba zenziwe nge `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kuba oku kuthelekisa izikhombisi kuthetha ukuba i `Weak::new()` iya kulingana, nangona ingakhombisi kulo naluphi na ulwabiwo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Thelekisa i `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Yenza indawo yesikhombisi se `Weak` esalatha kulwabiwo olufanayo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Jonga amagqabantshintshi kwi Arc::clone() ngokuba kutheni le nto ikhululekile.
        // Oku kunokusebenzisa i-fetch_add (ukungahoyi iqhaga) kuba amanani abuthathaka atshixiwe kuphela apho * kungekho ezinye izikhombisi ezibuthathaka ezikhoyo.
        //
        // (Ke asinakho ukuqhuba le khowudi kwimeko enjalo).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Jonga amagqabantshintshi kwi Arc::clone() ngokuba kutheni sisenza oku (nge mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Yakha i `Weak<T>` entsha, ngaphandle kokwabiwa kwememori.
    /// Ukutsalela umnxeba i [`upgrade`] kwixabiso lokubuya kuhlala kunika i [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Uwisa isikhombisi se `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ayiprinti nantoni na
    /// drop(foo);        // Ishicilela "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ukuba sifumanisa ukuba besisisikhombisi sokugqibela esibuthathaka, iya kuba lixesha layo lokuhambisa idatha ngokupheleleyo.Jonga ingxoxo kwi Arc::drop() malunga noku-odolwa kwememori
        //
        // Akunyanzelekanga ukuba ujonge imeko etshixiweyo apha, kuba isibalo esibuthathaka sinokutshixwa kuphela ukuba bekukho into enye ebuthathaka, oko kuthetha ukuba ukwehla kunokuqhubeka kuphela koko kubuthathaka okushiyekileyo, okunokwenzeka kuphela emva kokuba ukhiye ukhutshiwe.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Senza ubuchwephesha apha, kwaye hayi njengokusebenza ngokubanzi kwi `&T`, kuba ngeyongeze indleko kuzo zonke iitshekhi zokulingana kwii-Refs.
/// Sicinga ukuba ii-Arc`s zisetyenziselwa ukugcina amaxabiso amakhulu, acothayo ukudibanisa, kodwa ayasinda ukujonga ukulingana, ebangela ukuba le ndleko ihlawule ngokulula.
///
/// Kukwanamathuba okuba ne-`Arc` clones ezimbini, ezalatha kwixabiso elifanayo, kunee`&T`s ezimbini.
///
/// Singakwenza oku kuphela xa i-`T: Eq` njenge-`PartialEq` isenokungangqinelani ngabom.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Ukulingana kwee-`Arc`s ezimbini.
    ///
    /// Ii-Arc ezimbini ziyalingana ukuba amaxabiso abo angaphakathi ayalingana, nokuba agcinwe kulwabiwo olwahlukileyo.
    ///
    /// Ukuba i `T` ikwasebenzisa i `Eq` (okuthetha ukubonakalisa ukulingana), ii`Arcs ezimbini ezalatha kulwabiwo olufanayo zihlala zilingana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ukungalingani kwii-Arc ezimbini.
    ///
    /// Ii-Arc ezimbini azilingani ukuba amaxabiso abo angaphakathi awalingani.
    ///
    /// Ukuba i `T` ikwasebenzisa i `Eq` (ebonisa ukungalingani), ii`Arcs ezimbini ezalatha kwixabiso elifanayo azikaze zilingane.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Ukuthelekiswa okungafaniyo kwee-`Arc`s ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `partial_cmp()` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ngaphantsi kokuthelekisa ii-Arc`s ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `<` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Ngaphantsi okanye kulingana nokuba 'nothelekiso lweeArc`s ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `<=` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Kukhulu kunokuthelekisa ii-Arc`s ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `>` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Mkhulu kuno okanye ulingana' nothelekiso lwee-Arc ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `>=` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Thelekisa ezimbini `zeArc`s.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `cmp()` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Yenza i `Arc<T>` entsha, enexabiso le `Default` le `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Nikezela isilayidi esinexabiso lesalathiso kwaye usigcwalise ngokwenza izinto ze-v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Yahlula i-`str` yokubala kunye ne-`v` kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Yahlula i-`str` yokubala kunye ne-`v` kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Hambisa into ebhokisiweyo kulwabiwo-mali olutsha, olubaliweyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Nikezela isilayidi esinexabiso lesalathiso kwaye ususe izinto ze-v kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vumela iVec ukuba ikhulule imemori yayo, kodwa ingatshabalalisi imixholo yayo
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Ithatha into nganye kwi-`Iterator` kwaye uyiqokelele kwi-`Arc<[T]>`.
    ///
    /// # Iimpawu zomsebenzi
    ///
    /// ## Ityala eliqhelekileyo
    ///
    /// Kwimeko eqhelekileyo, ukuqokelela kwi `Arc<[T]>` kwenziwa ngokuqokelela okokuqala kwi `Vec<T>`.Oko kukuthi, xa ubhala oku kulandelayo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// oku kuziphatha ngokungathi sibhale:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Iseti yokuqala yolwabiwo yenzeka apha.
    ///     .into(); // Ulwabiwo lwesibini lwe `Arc<[T]>` lwenzeka apha.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Oku kuyakwabiwa amaxesha ngamaxesha njengoko kufuneka ekwakheni i `Vec<T>` kwaye iya kwabela kube kanye xa kuguqulwa i `Vec<T>` ibe yi `Arc<[T]>`.
    ///
    ///
    /// ## Iterators zobude obaziwayo
    ///
    /// Xa i `Iterator` yakho isebenzisa i `TrustedLen` kwaye inobungakanani obuchanekileyo, ulwabiwo olunye luya kwenziwa kwi `Arc<[T]>`.Umzekelo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Ulwabiwo olunye lwenzeka apha.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Ubungcali be trait esetyenziselwa ukuqokelela kwi `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Le yimeko ye-`TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // UKHUSELEKO: Kufuneka siqinisekise ukuba iterator inobude obuchanekileyo kwaye sinazo.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Buyela umva kuphumezo oluqhelekileyo.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Fumana isaphulelo ngaphakathi kwe `ArcInner` yokuhlawula emva kwesikhombisi.
///
/// # Safety
///
/// Isikhombisi kufuneka sikhombe (kwaye sibe nemethadatha esebenzayo) kwimeko yangaphambili ye-T, kodwa i-T iyavunyelwa ukuba ilahlwe.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ukulungelelanisa ixabiso elingasetyenziswanga kwisiphelo seArcInner.
    // Ngenxa yokuba i-RcBox iyi-repr(C), iya kuhlala iyintsimi yokugqibela kwimemori.
    // UKHUSELEKO: kuba ekuphela kweentlobo ezingasetyenziswanga ezinokubakho zizilayi, izinto ze-trait,
    // kunye neentlobo zangaphandle, imfuneko yokhuseleko okhoyo okwangoku ukwanelisa iimfuno ze align_of_val_raw;le yinkcukacha zokuphunyezwa kolwimi ekungenakuthenjelwa kuzo ngaphandle kwe std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}