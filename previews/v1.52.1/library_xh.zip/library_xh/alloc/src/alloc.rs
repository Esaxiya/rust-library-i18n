//! Ulwabiwo lwenkumbulo APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Ezi ziimpawu zomlingo ukubiza umnikezeli wehlabathi.I-rustc ibenza ukuba babize i `__rg_alloc` njl.
    // ukuba kukho uphawu lwe `#[global_allocator]` (ikhowudi eyandisayo uphawu olukhulu luvelisa loo misebenzi), okanye ukubiza ukumiliselwa okungagqibekanga kwi-libstd (`__rdl_alloc` njl.
    //
    // kwi `library/std/src/alloc.rs`) ngenye indlela.
    // I-rustc fork ye-LLVM ikwakhona-iimeko ezikhethekileyo la magama asebenzayo ukuze akwazi ukuzisebenzisa njenge-`malloc`, `realloc`, kunye ne-`free` ngokwahlukeneyo.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Ulwabiwo lwenkumbulo lwehlabathi.
///
/// Olu hlobo lusebenzisa i [`Allocator`] trait ngokudlulisa iminxeba kumnikezeli obhalise kwi `#[global_allocator]` uphawu ukuba kukho enye, okanye i `std` crate emiselweyo.
///
///
/// Note: Ngelixa olu hlobo lungazinzanga, ukusebenza okunikezelayo kunokufikelelwa nge [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Yabela inkumbulo kunye nolwabiwo lwehlabathi.
///
/// Lo msebenzi ubhekisa phambili ubiza indlela ye [`GlobalAlloc::alloc`] yomnikezeli obhalise kwi `#[global_allocator]` uphawu ukuba kukho enye, okanye i `std` crate emiselweyo.
///
///
/// Lo msebenzi kulindeleke ukuba wehliswe ngenxa yendlela ye `alloc` yohlobo lwe [`Global`] xa yona kunye ne [`Allocator`] trait zizinzile.
///
/// # Safety
///
/// Jonga i [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Yabela inkumbulo kulwabiwo lwehlabathi.
///
/// Lo msebenzi ubhekisa phambili ubiza indlela ye [`GlobalAlloc::dealloc`] yomnikezeli obhalise kwi `#[global_allocator]` uphawu ukuba kukho enye, okanye i `std` crate emiselweyo.
///
///
/// Lo msebenzi kulindeleke ukuba wehliswe ngenxa yendlela ye `dealloc` yohlobo lwe [`Global`] xa yona kunye ne [`Allocator`] trait zizinzile.
///
/// # Safety
///
/// Jonga i [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Yisa kwakhona inkumbulo kunye nolwabiwo lwehlabathi.
///
/// Lo msebenzi ubhekisa phambili ubiza indlela ye [`GlobalAlloc::realloc`] yomnikezeli obhalise kwi `#[global_allocator]` uphawu ukuba kukho enye, okanye i `std` crate emiselweyo.
///
///
/// Lo msebenzi kulindeleke ukuba wehliswe ngenxa yendlela ye `realloc` yohlobo lwe [`Global`] xa yona kunye ne [`Allocator`] trait zizinzile.
///
/// # Safety
///
/// Jonga i [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Nika inkumbulo eqalwe ngo-zero kunye nolwabiwo lwehlabathi.
///
/// Lo msebenzi ubhekisa phambili ubiza indlela ye [`GlobalAlloc::alloc_zeroed`] yomnikezeli obhalisiweyo ne `#[global_allocator]` uphawu ukuba kukho enye, okanye i `std` crate emiselweyo.
///
///
/// Lo msebenzi kulindeleke ukuba wehliswe ngenxa yendlela ye `alloc_zeroed` yohlobo lwe [`Global`] xa yona kunye ne [`Allocator`] trait zizinzile.
///
/// # Safety
///
/// Jonga i [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // UKHUSELEKO: `layout` ayiyiyo-zero ngobukhulu,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // UKHUSELEKO: Kuyafana ne `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // UKHUSELEKO: I-`new_size` ayisiyo-zero njengoko i-`old_size` ingaphezulu okanye ilingana ne-`new_size`
            // njengoko kufunwa yimeko zokhuseleko.Eminye imiqathango kufuneka igcinwe ngulowo ufowunayo
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` mhlawumbi ujonga i `new_size >= old_layout.size()` okanye enye into efanayo.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // UKHUSELEKO: kuba i `new_layout.size()` kufuneka ibengaphezulu okanye ilingane ne `old_size`,
            // zombini ulwabiwo oludala kunye nolutsha lusemthethweni ngokufundwa kwaye lubhalela ii-`old_size` byte.
            // Kwakhona, ngenxa yokuba ulwabiwo oludala lwalungekasuswa, alunakudlula i `new_ptr`.
            // Ke, umnxeba oya kwi `copy_nonoverlapping` ukhuselekile.
            // Ikhontrakthi yokhuseleko ye `dealloc` kufuneka igcinwe ngulowo ufowunayo.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // UKHUSELEKO: `layout` ayiyiyo-zero ngobukhulu,
            // Eminye imiqathango kufuneka igcinwe ngulowo ufowunayo
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // UKHUSELEKO: yonke imiqathango kufuneka igcinwe ngulowo ufowunayo
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // UKHUSELEKO: yonke imiqathango kufuneka igcinwe ngulowo ufowunayo
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // UKHUSELEKO: iimeko kufuneka zigcinwe ngulowo ufowunayo
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // UKHUSELEKO: `new_size` ayisiyo-zero.Eminye imiqathango kufuneka igcinwe ngulowo ufowunayo
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` mhlawumbi ujonga i `new_size <= old_layout.size()` okanye enye into efanayo.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // UKHUSELEKO: kuba i `new_size` kufuneka ibe ncinane okanye ilingane ne `old_layout.size()`,
            // zombini ulwabiwo oludala kunye nolutsha lusemthethweni ngokufundwa kwaye lubhalela ii-`new_size` byte.
            // Kwakhona, ngenxa yokuba ulwabiwo oludala lwalungekasuswa, alunakudlula i `new_ptr`.
            // Ke, umnxeba oya kwi `copy_nonoverlapping` ukhuselekile.
            // Ikhontrakthi yokhuseleko ye `dealloc` kufuneka igcinwe ngulowo ufowunayo.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Ulwabiwo lwezikhombisi ezizodwa.
// Lo msebenzi akufuneki ukhulule.Ukuba iyayenza, iMIR codegen iya kusilela.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Olu tyikityo kufuneka lufane ne `Box`, kungenjalo i-ICE iya kwenzeka.
// Xa iparameter eyongezelelweyo kwi-`Box` yongezwa (njenge-`A: Allocator`), oku kufuneka kongezwe apha ngokunjalo.
// Umzekelo ukuba i-`Box` itshintshelwe kwi-`struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, lo msebenzi kufuneka utshintshelwe kwi-`fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ngokunjalo.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Ulwabiwo lwempazamo

extern "Rust" {
    // Olu luphawu lomlingo ukubiza isiphatho sempazamo kulwabiwo lwehlabathi.
    // I-rustc iyivelisa ukuba ibize i-`__rg_oom` ukuba kukho i-`#[alloc_error_handler]`, okanye ukubiza ukwenziwa okungagqibekanga ngezantsi kwe-(`__rdl_oom`) ngenye indlela.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Ukulahla ngempazamo kulwabiwo lwenkumbulo okanye ukusilela.
///
/// Abafowunelwa ulwabiwo lwenkumbulo APIs abanqwenela ukuphelisa ubalo ngokwempendulo yolwabiwo lwempazamo bayakhuthazwa ukuba bawubize lo msebenzi, kunokuba babize ngokuthe ngqo i `panic!` okanye efanayo.
///
///
/// Ukuziphatha okungagqibekanga kwalo msebenzi kukuprinta umyalezo kwimpazamo esemgangathweni kunye nokulahla inkqubo.
/// Inokutshintsha endaweni ye [`set_alloc_error_hook`] kunye ne [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Kuvavanyo lokwabela i `std::alloc::handle_alloc_error` inokusetyenziswa ngokuthe ngqo.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // kubizwa nge `__rust_alloc_error_handler` evelisiweyo

    // ukuba akukho `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ukuba kukho i `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Ngobuchule beeklones kwimemori esele yabelwe, kwimemori engafakwanga.
/// Isetyenziswe yi `Box::clone` kunye ne `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ukwabela *kuqala* kunokuvumela i-optimizer ukuba yenze ixabiso lendawo endaweni yayo, utsibe indawo kwaye uhambe.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Singahlala sikopa endaweni, ngaphandle kokubandakanya ixabiso lendawo.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}