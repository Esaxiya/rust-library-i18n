//! Umtya obhaliweyo we-UTF-8, onokukhula.
//!
//! Le modyuli iqulethe uhlobo lwe [`String`], i [`ToString`] trait yokuguqula ibe yimitya, kunye neentlobo ezininzi zempazamo ezinokubangelwa kukusebenza ne [`String`] s.
//!
//!
//! # Examples
//!
//! Zininzi iindlela zokwenza i [`String`] entsha kumtya wokoqobo:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Unokwenza i [`String`] entsha kule ikhoyo ngokudibana nayo
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ukuba une-vector yee-UTF-8 byte, ungayenza i [`String`] ngayo.Unokwenza umva kwakhona.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Siyazi ukuba ezi bhayithi zivumelekile, ke siza kusebenzisa i `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Umtya obhaliweyo we-UTF-8, onokukhula.
///
/// Uhlobo lwe `String` lolona hlobo luqhelekileyo lomtya olunobunini ngaphezulu komxholo womtya.Inobudlelwane obusondeleyo nomlingane wayo obolekwe, i [`str`] yamandulo.
///
/// # Examples
///
/// Unokwenza i `String` ukusuka kwi [a literal string][`str`] nge [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Ungafaka i [`char`] kwi `String` ngendlela ye [`push`], kwaye ufake i [`&str`] ngendlela ye [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ukuba une-vector ye-UTF-8 byte, unokwenza i-`String` kuyo usebenzisa indlela ye-[`from_utf8`]:
///
/// ```
/// // ezinye i-byte, kwi-vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Siyazi ukuba ezi bhayithi zivumelekile, ke siza kusebenzisa i `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// I-String`s ihlala isebenza i-UTF-8.Oku kuneempembelelo ezimbalwa, eyokuqala kukuba ukuba ufuna umtya ongewona we-UTF-8, jonga i [`OsString`].Iyafana, kodwa ngaphandle kwesithintelo se UTF-8.Intsingiselo yesibini kukuba awukwazi ukukhomba kwi-`String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Isalathiso senzelwe ukuba sisebenze rhoqo, kodwa i-UTF-8 encoding ayisivumeli ukuba sikwenze oku.Ngapha koko, akucaci ukuba loluphi uhlobo lwesalathiso ekufuneka sibuya: i-byte, ikhowudi, okanye isihlanganisi segrapheme.
/// Iindlela ze [`bytes`] kunye ne [`chars`] zibuyisela iiterators ngaphezulu kokubini kokuqala, ngokwahlukeneyo.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Umtya`s ukuphumeza [`Deref`]`<Target=str>`, kwaye ke nizidle ilifa zonke iindlela zika (` `str`].Ukongeza, oku kuthetha ukuba ungadlula i `String` ukuya kumsebenzi othatha i [`&str`] ngokusebenzisa i-ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Oku kuyakwenza i [`&str`] ukusuka kwi `String` kwaye kuyigqithise. Olu tshintsho alubizi mali ininzi, kwaye ngokubanzi, imisebenzi iyakwamkela [`&str`] s njengeengxoxo ngaphandle kokuba bafuna i `String` ngesizathu esithile.
///
/// Kwiimeko ezithile i-Rust ayinalo ulwazi olwaneleyo lokwenza olu tshintsho, lwaziwa ngokuba kukunyanzelwa kwe [`Deref`].Kulo mzekelo ulandelayo umtya wesilayidi [`&'a str`][`&str`] usebenzisa i trait `TraitExample`, kwaye umsebenzi `example_func` uthatha nantoni na ephumeza i trait.
/// Kule meko i-Rust iya kufuna ukwenza uguquko olungagungqiyo, i-Rust engenandlela yakwenza.
/// Ngeso sizathu, lo mzekelo ulandelayo awuyi kuqulunqwa.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Zimbini iindlela onokukhetha ukusebenza ngazo endaweni yoko.Eyokuqala iya kuba kukutshintsha umgca `example_func(&example_string);` ukuya kwi `example_func(example_string.as_str());`, usebenzisa indlela [`as_str()`] ukukhupha ngokucacileyo isilayidi somtya onomtya.
/// Indlela yesibini etshintsha i `example_func(&example_string);` iye kwi `example_func(&*example_string);`.
/// Kule meko sisahlula-hlula i `String` ukuya kwi [`str`][`&str`], emva koko singqinisisa i [`str`][`&str`] sibuyele kwi [`&str`].
/// Indlela yesibini ye-idiomatic, nangona kunjalo bobabini basebenzela ukwenza uguquko ngokucacileyo kunokuba baxhomekeke kuguquko olungafakwanga.
///
/// # Representation
///
/// I `String` yenziwe ngezinto ezintathu: isikhombisi kwezinye ii-byte, ubude, kunye nomthamo.Isalathiso sikhomba kwisikhuseli sangaphakathi se `String` esisetyenziselwa ukugcina idatha.Ubude linani lee-byte ezigcinwe ngoku kwi-buffer, kwaye ubungakanani bubungakanani be-buffer kwii-byte.
///
/// Kananjalo, ubude buya kuhlala buncinci okanye bulingana nomthamo.
///
/// Le buffer ihlala igcinwe kwimfumba.
///
/// Ungazijonga ngezi ndlela ze [`as_ptr`], [`len`], kunye ne [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Hlaziya oku xa i-vec_into_raw_parts izinzisiwe.
/// // Thintela ngokuzenzekelayo ukulahla idatha yomtya
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // Ibali linee-byte ezilishumi elinesithoba
/// assert_eq!(19, len);
///
/// // Singaphinde sakhe umtya ngaphandle kwe-ptr, len, kunye nomthamo.
/// // Konke oku akukhuselekanga kuba sinoxanduva lokuqinisekisa ukuba izinto ziyasebenza:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ukuba i `String` inesakhono esaneleyo, ukongeza izinto kuyo ayizukuphinda yabele.Umzekelo, jonga le nkqubo:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Oku kuya kukhupha oku kulandelayo:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Ekuqaleni, asinayo inkumbulo eyabelwe konke konke, kodwa njengoko sifakela umtya, yonyusa amandla ayo ngokufanelekileyo.Ukuba endaweni yoko sisebenzisa indlela ye [`with_capacity`] ukwaba amandla afanelekileyo ekuqaleni:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Siphela nemveliso eyahlukileyo:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Apha, akukho sidingo sokwaba imemori engaphezulu ngaphakathi kwilog.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Ixabiso elinokubakho xa kuguqulwa i `String` ukusuka kwi UTF-8 byte vector.
///
/// Olu hlobo luhlobo lwempazamo kwindlela ye [`from_utf8`] kwi [`String`].
/// Yenzelwe ngendlela yokuphepha ngononophelo ukuhanjiswa kwakhona: indlela ye [`into_bytes`] iya kubuyisa i-Byte vector ebisetyenziswa kumzamo wokuguqula.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Uhlobo lwe [`Utf8Error`] olunikezwe yi [`std::str`] lumele impazamo enokuthi yenzeke xa kuguqulwa isilayidi se-[`u8`] s sibe yi [`&str`].
/// Ngale ndlela, yi-analogue eya kwi-`FromUtf8Error`, kwaye ungayifumana kwi-`FromUtf8Error` ngokusebenzisa indlela ye-[`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// // ezinye ii-byte ezingasebenziyo, kwi-vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Ixabiso elinokubakho xa kuguqulwa i `String` ukusuka kwisilayidi se-UTF-16 byte.
///
/// Olu hlobo luhlobo lwempazamo kwindlela ye [`from_utf16`] kwi [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Yenza i-`String` entsha engenanto.
    ///
    /// Ngenxa yokuba i `String` ayinanto, oku akuyi kwabela nayiphi na into yokuqala.Ngelixa oko kuthetha ukuba lo msebenzi wokuqala awubizi kakhulu, unokubangela ulwabiwo olugqithisileyo kamva xa usongeza idatha.
    ///
    /// Ukuba unoluvo lokuba ingakanani i-`String` eya kuthi ibambe, jonga indlela ye [`with_capacity`] yokuthintela ukwabiwa kwakhona okugqithisileyo.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Yenza i-`String` entsha engenanto ngomthamo othile.
    ///
    /// I-String`s ine-buffer yangaphakathi yokubamba idatha.
    /// Ubungakanani bubude beso buffer, kwaye bunokubuzwa ngendlela ye [`capacity`].
    /// Le ndlela yenza i-`String` engenanto, kodwa enye ine-buffer yokuqala enokubamba i-`capacity` byte.
    /// Oku kuluncedo xa unokufaka iqela ledatha kwi `String`, ukunciphisa inani lokwabiwa kwakhona ekufuneka likwenzile.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ukuba umthamo owunikiweyo ngu-`0`, akukho lwabiwo luya kubakho, kwaye le ndlela iyafana nale ye [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Umtya awunazo i-chars, nangona unawo amandla okungaphezulu
    /// assert_eq!(s.len(), 0);
    ///
    /// // Zonke ezi zinto zenziwa ngaphandle kokunikezelwa kwakhona ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... kodwa oku kunokwenza umtya uphinde ubuye
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): nge cfg(test) indlela ye `[T]::to_vec`, efunekayo kule nkcazo yendlela, ayifumaneki.
    // Kuba asiyifuni le ndlela ukulungiselela iinjongo zokuvavanya, ndiza kuyibamba NB ubone imodyuli ye slice::hack kwi slice.rs ngolwazi oluthe kratya.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Guqula i-vector yee-byte ukuya kwi-`String`.
    ///
    /// Umtya ([`String`]) wenziwe ngee-byte ([`u8`]), kunye ne-vector yee-byte ([`Vec<u8>`]) yenziwe ngee-byte, ke lo msebenzi uyaguquka phakathi kwezi zimbini.
    /// Ayizizo zonke izilayi ze-byte ezisemthethweni `String`s, nangona kunjalo: i-`String` ifuna ukuba isebenze i-UTF-8.
    /// `from_utf8()` kutshekishwa ukuqinisekisa ukuba ii-byte zisemthethweni UTF-8, emva koko yenza uguquko.
    ///
    /// Ukuba uqinisekile ukuba isilayidi se-byte sisemthethweni UTF-8, kwaye awufuni kungena kwintloko yokujonga ubunyani, kukho ingxelo engakhuselekanga yalo msebenzi, i-[`from_utf8_unchecked`], enendlela yokuziphatha efanayo kodwa yeqa itsheki.
    ///
    ///
    /// Le ndlela iya kukukhathalela ukungakhupheli i vector, ukuze isebenze ngokufanelekileyo.
    ///
    /// Ukuba ufuna i [`&str`] endaweni ye `String`, jonga i [`str::from_utf8`].
    ///
    /// Uguquko lwale ndlela yi-[`into_bytes`].
    ///
    /// # Errors
    ///
    /// Ibuyisa i [`Err`] ukuba isilayi ayisiyi-UTF-8 nenkcazo yokuba kutheni ii-byte ezinikezelweyo zingezizo i UTF-8.I-vector ongene kuyo nayo ifakiwe.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // ezinye i-byte, kwi-vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Siyazi ukuba ezi bhayithi zivumelekile, ke siza kusebenzisa i `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Ii-byte ezingachanekanga:
    ///
    /// ```
    /// // ezinye ii-byte ezingasebenziyo, kwi-vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Bona amaxwebhu e [`FromUtf8Error`] ngeenkcukacha ezithe kratya malunga nento onokuyenza ngale mpazamo.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Guqula isilayidi see-byte sibe ngumtya, kubandakanya oonobumba abangavumelekanga.
    ///
    /// Imitya yenziwe ngee-byte ([`u8`]), kwaye isilayidi se-byte ([`&[u8]`][byteslice]) senziwe ngee-byte, ke lo msebenzi uyaguquka phakathi kwezi zimbini.Ayizizo zonke izilayi ze-byte eziyintambo esebenzayo, nangona kunjalo: imitya iyafuneka ukuba isebenze i UTF-8.
    /// Ngexesha lolu tshintsho, i `from_utf8_lossy()` iya kuthatha indawo yayo nayiphi na into engavumelekanga ye UTF-8 nge [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], ejongeka ngoluhlobo:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ukuba uqinisekile ukuba isilayidi se-byte sisemthethweni UTF-8, kwaye awufuni kungena ngaphezulu kwenguqulelo, kukho ingxelo engakhuselekanga yalo msebenzi, i-[`from_utf8_unchecked`], enendlela yokuziphatha efanayo kodwa yeqa ukukhangela.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Lo msebenzi ubuyisela i-[`Cow<'a, str>`].Ukuba i-slice yethu ye-byte ayisebenzi UTF-8, emva koko kufuneka sifake oonobumba abaza kutshintsha, obuya kutshintsha ubungakanani bomtya, yiyo loo nto, kufuneka i `String`.
    /// Kodwa ukuba sele isebenza i UTF-8, asidingi sabelo sitsha.
    /// Olu hlobo lokubuya lusivumela ukuba siwaphathe omabini la matyala.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // ezinye i-byte, kwi-vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Ii-byte ezingachanekanga:
    ///
    /// ```
    /// // ezinye ii-byte ezingasebenziyo
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Cazulula i-UTF-16-encoded vector `v` kwi-`String`, ibuyise i-[`Err`] ukuba i-`v` inedatha engavumelekanga.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Oku akwenziwa ngokuqokelela: : <Result<_, _>> () ngezizathu zokusebenza.
        // FIXME: umsebenzi unokwenziwa lula kwakhona xa i #48994 ivaliwe.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Cacisa i-UTF-16-encoded slice `v` kwi `String`, endaweni yedatha engavumelekanga nge [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Ngokungafaniyo ne-[`from_utf8_lossy`] ebuyisa i-[`Cow<'a, str>`], i-`from_utf16_lossy` ibuyisa i-`String` okoko i-UTF-16 ukuya kwi-UTF-8 ifuna ukwabiwa kwememori.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Iqokelela i `String` kwizinto zayo eziluhlaza.
    ///
    /// Buyisela isikhombisi esiluhlaza kwidatha engaphantsi, ubude bomtya (kwii-byte), kunye nomthamo owabelweyo wedatha (kwii-byte).
    /// Ezi ziimpikiswano ezifanayo ngokulandelelana njengeempikiswano eziya kwi [`from_raw_parts`].
    ///
    /// Emva kokubiza lo msebenzi, lowo ufowunayo unoxanduva kwimemori eyayilawulwa ngaphambili yi `String`.
    /// Olona hlobo kuphela lokwenza oku kukuguqula isalathi esingavuthiweyo, ubude, kunye nomthamo ubuyisele kwi `String` ngomsebenzi we [`from_raw_parts`], uvumela umonakalisi ukuba enze ucoceko.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Yenza i `String` entsha kubude, amandla, kunye nesikhombisi.
    ///
    /// # Safety
    ///
    /// Oku akukhuselekanga kakhulu, ngenxa yenani labahlaseli abangakhange bajongwe:
    ///
    /// * Imemori ekwi `buf` ifuna ukuba ibikade yabiwa kwangulo mlawuli mnye usebenzisa ilayibrari esemgangathweni, kunye nolungelelwaniso olufunekayo lwesi-1 ngqo.
    /// * `length` Ifuna ukuba ngaphantsi okanye ilingane ne `capacity`.
    /// * `capacity` kufuneka ibe lixabiso elichanekileyo.
    /// * I-byte zokuqala ze-`length` kwi-`buf` kufuneka zisebenze njenge-UTF-8.
    ///
    /// Ukophula oku kunokubangela iingxaki njengokumosha ukwabiwa kwedatha yangaphakathi yomnikezeli.
    ///
    /// Ubunini be `buf` bugqithiselwe ngokufanelekileyo kwi `String` enokuthi emva koko ihlangane, iphinde ibeke kwakhona okanye itshintshe imixholo yememori ekhonjwe sisikhombisi ngentando.
    /// Qinisekisa ukuba akukho enye into esebenzisa isikhombisi emva kokubiza lo msebenzi.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Hlaziya oku xa i-vec_into_raw_parts izinzisiwe.
    ///     // Thintela ngokuzenzekelayo ukulahla idatha yomtya
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Guqula i-vector yee-byte iye kwi-`String` ngaphandle kokujonga ukuba umtya uqulethe i-UTF-8 esebenzayo.
    ///
    /// Bona ingxelo ekhuselekileyo, [`from_utf8`], ukufumana iinkcukacha ezithe kratya.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga kuba awukhangeli ukuba ii-byte ezidluliselwe kuwo ziyinyani eyi-UTF-8.
    /// Ukuba esi sithintelo sinyhashiwe, sinokubangela imemori ukungakhuselekanga kwemiba ngabasebenzisi be-future ye `String`, njengoko amanye amathala eencwadi asemgangathweni ethatha ukuba ii-String`s ziyinyani UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // ezinye i-byte, kwi-vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Guqula i `String` ibe yi-Byte vector.
    ///
    /// Oku kudla i `String`, ke akufuneki ukuba sikope imixholo yayo.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Ikhupha umtya wesilayidi oqukethe i `String` iphela.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Guqula i `String` ibe sisiqwenga somtya esinokutshintsha.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Faka umtya osikiweyo kwisiphelo sale `String`.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Ibuyisa esi sithuba se `String`, kwi-byte.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Iqinisekisa ukuba le `String`` yomthamo ubuncinci i-`additional` byte inkulu kunobude bayo.
    ///
    /// Umthamo unokunyuswa ngaphezulu kwe-`additional` byte ukuba ukhetha njalo, ukuthintela ukwenziwa kwakhona.
    ///
    ///
    /// Ukuba awuyifuni le ndlela yokuziphatha ye "at least", bona indlela ye [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics ukuba umthamo omtsha uphuphuma kwi [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Oku akunakwenyusa amandla:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ngoku inobude obungu-2 kunye nomthamo we-10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Kuba sele sinesikhundla esongezelelekileyo esi-8, sibiza oku ...
    /// s.reserve(8);
    ///
    /// // ... ayonyuki ngokwenyani.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Iqinisekisa ukuba le `String`` yomthamo zii-`additional` byte ezinkulu kunobude bayo.
    ///
    /// Cinga ukusebenzisa indlela ye [`reserve`] ngaphandle kokuba wazi ngcono kunokwabiwa.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics ukuba umthamo omtsha uphuphuma kwi `usize`.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Oku akunakwenyusa amandla:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ngoku inobude obungu-2 kunye nomthamo we-10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Kuba sele sinesikhundla esongezelelekileyo esi-8, sibiza oku ...
    /// s.reserve_exact(8);
    ///
    /// // ... ayonyuki ngokwenyani.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Izama ukugcina amandla ubuncinci be-`additional` ngaphezulu kwezinto eziza kufakwa kwi-`String` enikiweyo.
    /// Ingqokelela inokugcina indawo ngakumbi ukunqanda ulwabiwo rhoqo.
    /// Emva kokubiza i `reserve`, umthamo uya kuba mkhulu okanye ulingane no `self.len() + additional`.
    /// Ngaba akukho nto ukuba amandla sele onele.
    ///
    /// # Errors
    ///
    /// Ukuba umthamo uyaphuphuma, okanye ulwabiwo uxela ukusilela, emva koko impazamo iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Gcina imemori kwangaphambili, uphume ukuba asikwazi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ngoku siyazi ukuba le ayikwazi i-OOM embindini womsebenzi wethu onzima
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Izama ukugcina ubuncinci besikhundla se-`additional` ngakumbi izinto ezingaphezulu eziza kufakwa kwi-`String` enikiweyo.
    ///
    /// Emva kokubiza i `reserve_exact`, umthamo uya kuba mkhulu okanye ulingane no `self.len() + additional`.
    /// Ayenzi nto ukuba umthamo sele uwanele.
    ///
    /// Qaphela ukuba umthengisi unokunika ingqokelela indawo engaphezulu kunaleyo ayifunayo.
    /// Ke ngoko, umthamo awunakuthenjwa ekubeni ubuncinci ngokuchanekileyo.
    /// Khetha i `reserve` ukuba kulindelwe ukufakwa kwe future.
    ///
    /// # Errors
    ///
    /// Ukuba umthamo uyaphuphuma, okanye ulwabiwo uxela ukusilela, emva koko impazamo iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Gcina imemori kwangaphambili, uphume ukuba asikwazi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ngoku siyazi ukuba le ayikwazi i-OOM embindini womsebenzi wethu onzima
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Shwabanisa umthamo wale `String` ukuthelekisa ubude bayo.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Shwabanisa umthamo wale `String` ngentambo esezantsi.
    ///
    /// Umthamo uya kuhlala ubuncinci ubuncinci njengobude kunye nexabiso elibonelelweyo.
    ///
    ///
    /// Ukuba umthamo wangoku ungaphantsi komda ongezantsi, le yi-no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Faka isicelo se-[`char`] ukuya esiphelweni sale `String`.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Ukubuyisa isilayidi seb Byte kwesi siqulatho se-`String`.
    ///
    /// Uguquko lwale ndlela yi-[`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Kufutshane le `String` kubude obuchaziweyo.
    ///
    /// Ukuba i `new_len` ingaphezulu kobude bomtya wangoku, oku akunampembelelo.
    ///
    ///
    /// Qaphela ukuba le ndlela ayinasiphumo kubungakanani obabelwe umtya
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `new_len` ayilali kumda we [`char`].
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Isusa umlinganiswa wokugqibela kwi-buffer yomtya kwaye uyibuyisele.
    ///
    /// Ibuyisa i [`None`] ukuba le `String` ayinanto.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Isusa i [`char`] kule `String` kwindawo ye-Byte kwaye iyibuyisele.
    ///
    /// Lo ngumsebenzi we *O*(*n*), njengoko ufuna ukukopa yonke into kwitephu.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i-`idx` inkulu okanye ilingana nobude be-String, okanye ukuba ayilalanga kumda we-[`char`].
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Susa konke ukungqinelana kwepateni `pat` kwi `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Ukutshatiswa kuya kufunyanwa kwaye kususwe ngokungathandabuzekiyo, ke kwimeko apho iipateni zingena khona, yipateni yokuqala kuphela eya kususwa:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // UKHUSELEKO: ukuqala nokuphela kuya kuba kwimida ye-utf8 byte nganye
        // Amaxwebhu okuKhangela
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Kugcinwa kuphela oonobumba abachazwe sisivisa.
    ///
    /// Ngamanye amagama, susa bonke oonobumba `c` ngendlela yokuba i `f(c)` ibuyise i `false`.
    /// Le ndlela isebenza endaweni, undwendwela umlinganiswa ngamnye kanye kube kanye kulungelelwaniso lwantlandlolo, kwaye igcina iodolo yabalinganiswa abagciniweyo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Ukulandelelana ngqo kunokuba luncedo ekulandeleleni imeko yangaphandle, njengesalathiso.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Khomba i-idx kwitshati elandelayo
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Ukufaka umlinganiswa kule `String` kwindawo ye-byte.
    ///
    /// Lo ngumsebenzi we *O*(*n*) njengoko ufuna ukukopa yonke into kwitephu.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i-`idx` inkulu kunobude be-String``, okanye ukuba ayilalanga kumda we-[`char`].
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Ukufaka umtya wesilayidi kule `String` kwindawo ye-byte.
    ///
    /// Lo ngumsebenzi we *O*(*n*) njengoko ufuna ukukopa yonke into kwitephu.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i-`idx` inkulu kunobude be-String``, okanye ukuba ayilalanga kumda we-[`char`].
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Ibuyisa ireferensi enokutshintsha kwimixholo yale `String`.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga kuba awukhangeli ukuba ii-byte ezidluliselwe kuwo ziyinyani eyi-UTF-8.
    /// Ukuba esi sithintelo sinyhashiwe, sinokubangela imemori ukungakhuselekanga kwemiba ngabasebenzisi be-future ye `String`, njengoko amanye amathala eencwadi asemgangathweni ethatha ukuba ii-String`s ziyinyani UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Ibuyisa ubude bale `String`, kwii-byte, hayi [`char`] s okanye kwiigraphhemes.
    /// Ngamanye amagama, isenokungabi yile nto ibonwa ngumntu ubude bomtya.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Ibuyisa i `true` ukuba le `String` inobude be-zero, kunye ne-`false` ngenye indlela.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ukwahlulahlula umtya kubini kwisalathiso se-byte esinikiweyo.
    ///
    /// Ibuyisa i `String` esandula ukwabiwa.
    /// `self` iqulethe ii-byte `[0, at)`, kwaye i-`String` ebuyisiweyo iqulethe ii-byte `[at, len)`.
    /// `at` Kuya kufuneka ube kumda we UTF-8 yekhowudi yenqaku.
    ///
    /// Qaphela ukuba umthamo we `self` awutshintshi.
    ///
    /// # Panics
    ///
    /// Panics ukuba i `at` ayikho kumda wekhowudi ye `UTF-8`, okanye ukuba ingaphaya kwenqaku lokugqibela lomtya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Iyinciphisa le `String`, isusa yonke imixholo.
    ///
    /// Ngelixa oku kuthetha ukuba i `String` iya kuba nobude be-zero, ayichukumisi umthamo wayo.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Yenza i-iterator yokutsala esusa uluhlu oluchaziweyo kwi-`String` kwaye ivelise i-`chars` esusiweyo.
    ///
    ///
    /// Note: Uluhlu lwento luyasuswa nokuba iterator ayityiwa kude kube sekupheleni.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba indawo yokuqala okanye indawo yokuphela ayilali kumda we [`char`], okanye ukuba aphumile kwimida.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Susa uluhlu kude kube ngu-β kumtya
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Uluhlu olupheleleyo lususa umtya
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Ukhuseleko lwenkumbulo
        //
        // Inguqulelo yomtya we Drain ayinayo imicimbi yokhuseleko kwimemori yenguqulo ye vector.
        // Idatha zii-byte ezicacileyo.
        // Kungenxa yokuba ukususwa koluhlu kwenzeka kwiDrop, ukuba iterator ye Drain ivuzisiwe, ukususwa akuyi kwenzeka.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Thatha iimboleko ezimbini ngaxeshanye.
        // Umtya we &mut awuyi kufikelelwa de kugqitywe ukwenziwa, kwiDrop.
        let self_ptr = self as *mut _;
        // UKHUSELEKO: I `slice::range` kunye ne `is_char_boundary` yenza imida efanelekileyo yokujonga.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Isusa uluhlu oluchaziweyo kumtya, kwaye ithathe indawo yomtya onikiweyo.
    /// Umtya onikiweyo awudingi ukuba ubude obulinganayo noluhlu.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba indawo yokuqala okanye indawo yokuphela ayilali kumda we [`char`], okanye ukuba aphumile kwimida.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Guqula uluhlu kude kube ngu the kumtya
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Ukhuseleko lwenkumbulo
        //
        // Faka endaweni_range ayinayo imicimbi yokhuseleko kwimemori ye-vector Splice.
        // yenguqulo ye vector.Idatha zii-byte ezicacileyo.

        // ISILUMKISO: Ukuchwetheza oku kungafaniyo akuyi kuba yi (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ISILUMKISO: Ukuchwetheza oku kungafaniyo akuyi kuba yi (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Sebenzisa i `range` kwakhona ayizukubonakala (#81138) Sicinga ukuba imida exelwe yi `range` ihlala injalo, kodwa ukuphunyezwa kwentshaba kunokutshintsha phakathi kweefowuni
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Iguqula le `String` ibe [`Box`]`<`[`str`] `>`.
    ///
    /// Oku kuya kulahla nawuphi na umthamo ogqithisileyo.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Ibuyisa isilayidi se [`u8`] s bytes ezizame ukuguqulela kwi `String`.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // ezinye ii-byte ezingasebenziyo, kwi-vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Ibuyisa ii-byte ezizame ukuguqulela kwi-`String`.
    ///
    /// Le ndlela yakhiwe ngononophelo ukuthintela ulwabiwo.
    /// Iya kudla impazamo, isuse ii-byte, ukuze ikopi yee-byte ingafuneki yenziwe.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // ezinye ii-byte ezingasebenziyo, kwi-vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Landa i `Utf8Error` ukufumana iinkcukacha ezithe kratya malunga nokusilela kokuguqula.
    ///
    /// Uhlobo lwe [`Utf8Error`] olunikezwe yi [`std::str`] lumele impazamo enokuthi yenzeke xa kuguqulwa isilayidi se-[`u8`] s sibe yi [`&str`].
    /// Ngale ndlela, yi-analogue eya kwi-`FromUtf8Error`.
    /// Bona amaxwebhu alo ngeenkcukacha ezithe kratya zokuyisebenzisa.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // ezinye ii-byte ezingasebenziyo, kwi-vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ibhayithi yokuqala ayisebenzi apha
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Kuba sihamba ngaphezulu kwe-String`s, sinokuthintela ubuncinci isabelo esinye ngokufumana umtya wokuqala kwi-iterator kwaye songeze kuyo yonke imitya elandelayo.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Kungenxa yokuba sisebenza ngaphezulu kwe-CoWs, singakwazi ukuthintela u-(potentially) ubuncinci kwisabelo esinye ngokufumana into yokuqala kunye nokufaka kuyo zonke izinto ezilandelayo.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Uncedo olulula lokuthumela abathunywa kwi-impl ye `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Yenza i `String` engenanto.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Sebenzisa umqhubi we `+` ukwenza concatenating imitya emibini.
///
/// Oku kudla i `String` kwicala lasekhohlo kwaye iphinde isebenzise i-buffer yayo (ukuyikhulisa xa kukho imfuneko).
/// Oku kwenzelwa ukunqanda ukwabiwa kwe `String` entsha kunye nokukopa konke okuqulathiweyo kuwo wonke umsebenzi, oya kuthi ukhokele *O*(*n*^ 2) ixesha lokubaleka xa usakha umtya *n*-byte ngokudibana okuphindiweyo.
///
///
/// Umtya kwicala lasekunene ubolekwe kuphela;imixholo yayo ikhutshelwe kwi `String` ebuyisiweyo.
///
/// # Examples
///
/// Ukudibanisa ezimbini `String`s kuthatha eyokuqala ngexabiso kwaye iboleke eyesibini:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ishukunyisiwe kwaye ayisenakusetyenziswa apha.
/// ```
///
/// Ukuba ufuna ukuqhubeka usebenzisa i `String` yokuqala, ungayifaka kwaye uyongeze endaweni yayo:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` isasebenza apha.
/// ```
///
/// Ukudibanisa izilayi ze `&str` kunokwenziwa ngokuguqula eyokuqala ibe yi `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Sebenzisa umqhubi we `+=` ukufaka isicelo kwi `String`.
///
/// Oku kuziphatha ngendlela efanayo ne [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Uhlobo lwe-alias ze [`Infallible`].
///
/// Eli gama alias likhona ngokuhambelana ngasemva, kwaye linokuncitshiswa ekugqibeleni.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// I-trait yokuguqula ixabiso libe yi `String`.
///
/// Le trait iphunyezwa ngokuzenzekelayo kulo naluphi na uhlobo olusebenzisa i [`Display`] trait.
/// Kananjalo, i `ToString` akufuneki yenziwe ngokuthe ngqo:
/// [`Display`] kufuneka yenziwe endaweni yoko, kwaye ufumane ukumiliselwa kwe `ToString` simahla.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Guqula ixabiso elinikiweyo libe yi `String`.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Kulwenziwo, indlela ye `to_string` panics ukuba umiliselo lwe `Display` lubuyisa impazamo.
/// Oku kubonisa umiliselo olungachanekanga lwe `Display` okoko i `fmt::Write for String` ingaze ibuyise impazamo ngokwayo.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Isikhokelo esiqhelekileyo kukungabeki emgceni imisebenzi yesiqhelo.
    // Nangona kunjalo, ukususa i-`#[inline]` kule ndlela kubangela ukuhlehla okungafakwanga nto.
    // Bona i <https://github.com/rust-lang/rust/pull/74852>, ukuzama kokugqibela ukuzama ukuyisusa.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Guqula i `&mut str` ibe yi `String`.
    ///
    /// Iziphumo zabelwe imfumba.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test utsala kwi-libstd, ebangela iimpazamo apha
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Guqula isilayidi esibhokisiweyo se `str` sibe yi `String`.
    /// Kuyaphawuleka ukuba isilayi se `str` sesabanini.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Guqula i-`String` oyinikiweyo kwisilayidi sebhokisi ye-`str` esisesakhe.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Guqula isilayidi somtya sibe ngumahluko obolekiweyo.
    /// Akukho lwabiwo lwenziweyo lwenziweyo, kwaye umtya awukhutshelwa.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Guqula umtya ube yinto eyahlukileyo.
    /// Akukho lwabiwo lwenziweyo lwenziweyo, kwaye umtya awukhutshelwa.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Guqula ireferensi yomtya ibe yinto ebolekiweyo.
    /// Akukho lwabiwo lwenziweyo lwenziweyo, kwaye umtya awukhutshelwa.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Iguqula i-`String` ibe yi-vector `Vec` ephethe amaxabiso ohlobo `u8`.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Iterator yokukhupha i `String`.
///
/// Olu lwakhiwo lwenziwe yindlela ye [`drain`] kwi [`String`].
/// Bona amaxwebhu ayo ngaphezulu.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Iya kusetyenziswa njenge&'a Mut String kumonakalisi
    string: *mut String,
    /// Ukuqala kwenxalenye ukususa
    start: usize,
    /// Ukuphela kwenxalenye ukususa
    end: usize,
    /// Uluhlu olushiyekileyo ngoku lokususa
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Sebenzisa i Vec::drain.
            // "Reaffirm" Imida itshekisha ukuthintela ikhowudi ye-panic yokufakwa kwakhona.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Ibuyisa umtya oseleyo (sub) wale iterator njengesilayi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef impls engezantsi xa uzinzisa.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Uncomment xa uzinzisa i `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> I-AsRef<str>ye Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> ye Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}