//! Izalathiso zokubala ezinomsonto omnye.I 'Rc' imele 'Isalathiso
//! Counted'.
//!
//! Uhlobo lwe-[`Rc<T>`][`Rc`] lubonelela ngobunini ekwabelwana ngabo ngexabiso lohlobo `T`, elabiwe kwimfumba.
//! Ukungenisa i [`clone`][clone] kwi [`Rc`] kuvelisa isikhombisi esitsha kulwabiwo olufanayo kwimfumba.
//! Xa isikhombisi sokugqibela se [`Rc`] kulwabiwo olunikiweyo lutshatyalalisiwe, ixabiso eligcinwe kolo lwabiwo (ihlala ibizwa ngokuba yi "inner value") nalo liyehla.
//!
//! Iireferensi ekwabelwana ngazo kwi-Rust ayivumeli utshintsho ngokwendalo, kwaye i-[`Rc`] ayisiyonto ikhethiweyo: ngekhe ufumane isalathiso esinokutshintshwa kwinto ethile ngaphakathi kwe [`Rc`].
//! Ukuba ufuna ukuguquka, faka i [`Cell`] okanye i [`RefCell`] ngaphakathi kwe [`Rc`];bona i [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] isebenzisa ukubala kwesalathiso esingeyo-atom.
//! Oku kuthetha ukuba ngaphezulu kuphantsi kakhulu, kodwa i-[`Rc`] ayinakuthunyelwa phakathi kwemisonto, kwaye ngenxa yoko i-[`Rc`] ayiphumezi i [`Send`][send].
//! Ngenxa yoko, umhlanganisi we-Rust uya kujonga *ngexesha lokudibanisa* ongazithumeliyo [`Rc`] phakathi kwemisonto.
//! Ukuba ufuna imisonto emininzi, ukubalwa kwesalathiso seatom, sebenzisa i [`sync::Arc`][arc].
//!
//! Indlela ye [`downgrade`][downgrade] inokusetyenziselwa ukwenza isikhombisi esingesiso esakhe [`Weak`].
//! Isikhombisi se [`Weak`] sinokuba [`uphuculo`][hlaziya] d ukuya kwi [`Rc`], kodwa oku kuyakubuyisa i [`None`] ukuba ixabiso eligcinwe kulwabiwo sele lilahliwe.
//! Ngamanye amagama, izikhombisi ze `Weak` azigcini ixabiso ngaphakathi kolwabiwo liphila;nangona kunjalo, * bayalugcina ulwabiwo (ivenkile exhasa ixabiso langaphakathi) liphila.
//!
//! Umjikelo phakathi kwezikhombisi ze [`Rc`] awusoze uhanjiswe.
//! Ngesi sizathu, i [`Weak`] isetyenziselwa ukwaphula imijikelezo.
//! Umzekelo, umthi unokuba nezikhombisi ezomeleleyo ze [`Rc`] ukusuka kwiindawo zomzali ukuya kubantwana, kunye nezikhombisi ze [`Weak`] ezisuka kubantwana ababuyela kubazali babo.
//!
//! `Rc<T>` Dereferensi ngokuzenzekelayo kwi `T` (nge [`Deref`] trait), ukuze ubize iindlela zika-T kwixabiso lohlobo [`Rc<T>`][`Rc`].
//! Ukuthintela ukungqubana kwamagama ngeendlela ze-T`, iindlela ze-[`Rc<T>`][`Rc`] uqobo zinxulumene nemisebenzi, ebizwa ngokuba yi-[fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! Rc<T>Ukuphunyezwa kwe traits ezinje nge `Clone` kunokubizwa kusetyenziswa is syntax efanelekileyo.
//! Abanye abantu bakhetha ukusebenzisa isichazi esifanelekileyo, ngelixa abanye bekhetha ukusebenzisa indlela yokubiza umnxeba.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Indlela yokubiza i-syntax
//! let rc2 = rc.clone();
//! // Is syntax efanelekileyo ngokupheleleyo
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ayisiyisi-auto-dereferensi kwi `T`, kuba ixabiso langaphakathi lisenokuba sele lilahliwe.
//!
//! # Izikhombisi zekonon
//!
//! Ukwenza ireferensi entsha kulwabiwo olufanayo njengesalathiso esele sibaliwe senziwe kusetyenziswa i `Clone` trait ephunyezwe nge [`Rc<T>`][`Rc`] kunye ne [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ezi syntax zimbini zingezantsi ziyalingana.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // kwaye b zombini zikhomba kwindawo efanayo yenkumbulo njenge-foo.
//! ```
//!
//! I-syntax ye-`Rc::clone(&from)` yeyona idiomatic kuba ihambisa ngokucacileyo intsingiselo yekhowudi.
//! Kumzekelo ongentla, le syntax yenza ukuba kube lula ukubona ukuba le khowudi yenza ireferensi entsha kunokukhuphela yonke imixholo ye-foo.
//!
//! # Examples
//!
//! Cinga ngemeko apho iiseti zeGajethi ziphantsi kwe `Owner`.
//! Sifuna ukuba nesalathi sethu seGajethi siye kwi-`Owner` yabo.Asinakukwenza oku ngobunini obukhethekileyo, kuba igajethi engaphezulu kwesinye inokuba yeyo `Owner` efanayo.
//! [`Rc`] Isivumela ukuba sabelane nge `Owner` phakathi kwe`Gajethi` ezininzi, kwaye i `Owner` ihlale yabelwe ixesha elide njengazo naziphi na iingongoma ze `Gadget` kuyo.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... ezinye iinkalo
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ezinye iinkalo
//! }
//!
//! fn main() {
//!     // Yenza ireferensi ebaliweyo ye `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Yenza igajethi ye `gadget_owner`.
//!     // Ukwenza ikhonkco kwi `Rc<Owner>` kusinika isikhombisi esitsha kulwabiwo lwe `Owner`, sonyusa ukubalwa kwesalathiso kwinkqubo.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Lahla imeko yethu yendawo eyahlukileyo i `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Ngaphandle kokulahla i `gadget_owner`, sisakwazi ukuprinta igama le `Owner` yee`Gadget`s.
//!     // Kungenxa yokuba sishiye i `Rc<Owner>` enye, hayi i-`Owner` eyalatha kuyo.
//!     // Logama zikhona ezinye i `Rc<Owner>` ezikhomba kulwabiwo lwe `Owner`, iya kuhlala iphila.
//!     // Uqikelelo lwentsimi `gadget1.owner.name` lusebenza kuba i `Rc<Owner>` ngokuzenzekelayo isalathisa kwi `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Ekupheleni komsebenzi, i-`gadget1` kunye ne-`gadget2` zitshatyalalisiwe, kwaye kunye nezingqinisiso zokugqibela ezibalwe kwi-`Owner` yethu.
//!     // Indoda yeGadget ngoku iyatshatyalaliswa nayo.
//!     //
//! }
//! ```
//!
//! Ukuba iimfuno zethu ziyatshintsha, kwaye sikwafuna ukukwazi ukuhamba ukusuka kwi-`Owner` ukuya kwi-`Gadget`, siya kuba neengxaki.
//! Isalathiso se [`Rc`] esisuka kwi `Owner` ukuya kwi `Gadget` sazisa umjikelo.
//! Oku kuthetha ukuba ukubalwa kwesalathiso kwabo akunakufikelela ku-0, kwaye ulwabiwo alunakuze litshatyalaliswe:
//! imemori evuzayo.Ukujikeleza oku, singasebenzisa izikhombisi ze [`Weak`].
//!
//! I-Rust yenza ukuba kube nzima ukuvelisa lo loop kwindawo yokuqala.Ukuze ugqibezele amaxabiso amabini akhombisana, enye yazo kufuneka iguquke.
//! Oku kunzima kuba i [`Rc`] inyanzelisa ukhuseleko kwimemori ngokunika kuphela izingqinisiso ekwabelwana ngazo kwixabiso elisongelayo, kwaye oku akuvumeli kuguquko oluthe ngqo.
//! Kufuneka sisongele isahlulo sexabiso esinqwenela ukutshintsha kwi [`RefCell`], ebonelela *ngokuguquguquka kwangaphakathi*: indlela yokufezekisa ukungaguquguquki kusetyenziswa ireferensi ekwabelwana ngayo.
//! [`RefCell`] inyanzelisa imigaqo-mboleko ye-Rust ngexesha lokubaleka.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... ezinye iinkalo
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ezinye iinkalo
//! }
//!
//! fn main() {
//!     // Yenza ireferensi ebaliweyo ye `Owner`.
//!     // Qaphela ukuba sibeke i-vector yomnini `weGadget`s ngaphakathi kwe `RefCell` ukuze siyitshintshe ngokubhekisele kwinto ekwabelwana ngayo.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Yenza`Igajethi` ye `gadget_owner`, njengangaphambili.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Yongeza`Igajethi` kwi `Owner` yabo.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ukuboleka okunamandla kuphelela apha.
//!     }
//!
//!     // Iterate ngaphezulu kwee `Gadget`s zethu, siprinta iinkcukacha zazo.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` Ngu `Weak<Gadget>`.
//!         // Kuba izikhombisi ze `Weak` azinakuqinisekisa ukuba ulwabiwo lusekhona, kufuneka sibize i `upgrade`, ebuyisa i `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Kule meko siyazi ukuba ulwabiwo lusekhona, ke ngoku simane sixelisa u `unwrap` i `Option`.
//!         // Kwinkqubo enzima ngakumbi, unokufuna ukuphatha impazamo entle ngesiphumo se `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Ekupheleni komsebenzi, i `gadget_owner`, `gadget1`, kunye ne `gadget2` ziyatshatyalaliswa.
//!     // Akukho zikhombisi zomeleleyo ze (`Rc`) kwizixhobo, ke ziyatshatyalaliswa.
//!     // Ezi zeroes ukubalwa kwesalathiso kwiGadget Man, ke naye uyatshatyalaliswa.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Le yi-repr(C) ukuya kwi-future-ubungqina ngokuchasene nokuhlengahlengiswa kwentsimi okunokuthi kuphazamise enye i-[into|from]_raw() ekhuselekileyo yeentlobo zangaphakathi ezinokudluliselwa.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Isalathiso sokubala esisisi-ntambo esinye.I 'Rc' imele 'Isalathiso
/// Counted'.
///
/// Bona i [module-level documentation](./index.html) ngeenkcukacha ezithe kratya.
///
/// Iindlela zendalo ze `Rc` yiyo yonke imisebenzi enxulumene noko, oko kuthetha ukuba kuya kufuneka ubabize njengomzekelo, [`Rc::get_mut(&mut value)`][get_mut] endaweni ye `value.get_mut()`.
/// Oku kuthintela ukungqubana neendlela zohlobo lwangaphakathi `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Oku kungakhuselekanga kulungile kuba ngelixa le Rc isaphila siqinisekisiwe ukuba isalathiso sangaphakathi siyasebenza.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Yakha i `Rc<T>` entsha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Kukho isikhombisi esibuthathaka esingagunyaziswanga esinezikhombisi ezomeleleyo, eziqinisekisa ukuba umbhuqi ongekho mandla akalukhululi ulwabiwo ngelixa umonakalisi onamandla ebaleka, nokuba isikhombisi esibuthathaka sigcinwe ngaphakathi komeleleyo.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Yakha i `Rc<T>` entsha isebenzisa ireferensi ebuthathaka kuyo.
    /// Ukuzama ukuphucula isalathiso esibuthathaka ngaphambi kokuba lo msebenzi ubuye kuya kukhokelela kwixabiso le `None`.
    ///
    /// Nangona kunjalo, ireferensi ebuthathaka inokudityaniswa ngokukhululekileyo kwaye igcinelwe ukusetyenziswa kamva.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... amanye amasimi
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Yakha ngaphakathi kwimo ye "uninitialized" ngesalathiso esinye esibuthathaka.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Kubalulekile ukuba singabuncami ubunini besikhombisi esibuthathaka, kungenjalo imemori inokukhululwa ngexesha lokubuya kwe `data_fn`.
        // Ukuba ngenene sifuna ukugqithisa ubunini, sinokuzenzela isikhombisi esibuthathaka, kodwa oku kungakhokelela kuhlaziyo olongezelelekileyo kubalo lwesalathiso esibuthathaka esinokungafuneki ngenye indlela.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Izalathiso ezomeleleyo kufuneka zihlanganiselwe ukuba zibe nezalathiso ezibuthathaka ekwabelwana ngazo, ke musa ukuqhuba umonakalisi wesalathiso sethu esidala esibuthathaka.
        //
        mem::forget(weak);
        strong
    }

    /// Yakha i `Rc` entsha enemixholo engachazwanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yakha i `Rc` entsha enemixholo engachazwanga, inkumbulo izaliswe zii-`0` byte.
    ///
    ///
    /// Jonga i [`MaybeUninit::zeroed`][zeroed] ngemizekelo yokusetyenziswa ngokuchanekileyo nangokungachanekanga kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yakha i `Rc<T>` entsha, ibuyisa impazamo ukuba ulwabiwo aluphumelelanga
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Kukho isikhombisi esibuthathaka esingagunyaziswanga esinezikhombisi ezomeleleyo, eziqinisekisa ukuba umbhuqi ongekho mandla akalukhululi ulwabiwo ngelixa umonakalisi onamandla ebaleka, nokuba isikhombisi esibuthathaka sigcinwe ngaphakathi komeleleyo.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Yakha i `Rc` entsha enemixholo engachazwanga, ibuyisa impazamo ukuba ulwabiwo aluphumelelanga
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Yakha i `Rc` entsha enemixholo engachazwanga, inkumbulo izaliswe zii-`0` byte, ibuyisa impazamo ukuba ulwabiwo aluphumeleli
    ///
    ///
    /// Jonga i [`MaybeUninit::zeroed`][zeroed] ngemizekelo yokusetyenziswa ngokuchanekileyo nangokungachanekanga kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Yakha i `Pin<Rc<T>>` entsha.
    /// Ukuba i-`T` ayizalisekisi i-`Unpin`, emva koko i-`value` iya kuphawulwa kwimemori kwaye ayikwazi kushenxiswa.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Ibuyisa ixabiso langaphakathi, ukuba i `Rc` inesalathiso esinye esomeleleyo.
    ///
    /// Ngaphandle koko, i [`Err`] ibuyiselwa i-`Rc` efanayo eyadlulisiweyo.
    ///
    ///
    /// Oku kuyakuphumelela nokuba kukho izingqinisiso ezibuthathaka ezibalaseleyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // khuphela into equlethweyo

                // Bonisa kuTeaks ukuba abanakuphakanyiswa ngokunciphisa ukubala okuqinileyo, kwaye emva koko basuse isikhombisi se "strong weak" ngelixa bejongana nethontsi ngokwenza into engeyiyo.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Yakha isilayidi esitsha esibalwayo esineziqulatho ezingachazwanga.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Yakha isilayidi esitsha esibalwayo esinemixholo engachazwanga, inkumbulo izaliswa zii-`0` byte.
    ///
    ///
    /// Jonga i [`MaybeUninit::zeroed`][zeroed] ngemizekelo yokusetyenziswa ngokuchanekileyo nangokungachanekanga kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Uguqula abe ngu-`Rc<T>`.
    ///
    /// # Safety
    ///
    /// Njengakwi [`MaybeUninit::assume_init`], kuxhomekeke kulowo ufowunayo ukuqinisekisa ukuba ixabiso langaphakathi ngokwenyani likwisimo sokuqala.
    ///
    /// Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela indlela yokuziphatha engachazwanga kwangoko.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Uguqula abe ngu-`Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Njengakwi [`MaybeUninit::assume_init`], kuxhomekeke kulowo ufowunayo ukuqinisekisa ukuba ixabiso langaphakathi ngokwenyani likwisimo sokuqala.
    ///
    /// Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela indlela yokuziphatha engachazwanga kwangoko.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqaliswa kokumiselwa:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Isebenzisa i `Rc`, ibuyisa isalathiso esisongelweyo.
    ///
    /// Ukuthintela ukuvuza kwenkumbulo, isikhombisi kufuneka siguqulwe sibuyele kwi `Rc` kusetyenziswa i [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ukubonelela ngesikhombisi esiluhlaza kwidatha.
    ///
    /// Ubalo aluchaphazeleki nangayiphi na indlela kwaye i `Rc` ayisetyenziswanga.
    /// Isikhombisi sisebenza ixesha elide kukho ukubala okunamandla kwi `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // UKHUSELEKO: Oku akunakudlula kwi Deref::deref okanye kwi Rc::inner kuba
        // oku kuyadingeka ukugcina i-raw/mut yemvelaphi enje umz
        // `get_mut` Ungabhala ngesikhombisi emva kokuba i-Rc ifunyenwe kwi `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Yakha i `Rc<T>` kwisikhombisi esiluhlaza.
    ///
    /// Isalathiso esiluhlaza kufuneka ukuba sasibuyiselwe umnxeba kwi-[`Rc<U>::into_raw`][into_raw] apho i-`U` kufuneka ibenobungakanani obulinganayo kunye nolungelelwaniso njenge-`T`.
    /// Kuyinyani ngokuqinisekileyo ukuba i `U` yi `T`.
    /// Qaphela ukuba i `U` ayisiyi-`T` kodwa inobungakanani obulinganayo kunye nolungelelwaniso, oku ngokusisiseko kufana nokuhambisa izingqinisiso zeentlobo ezahlukeneyo.
    /// Bona i [`mem::transmute`][transmute] ngolwazi oluthe kratya malunga nokuba zeziphi izithintelo ezisebenza kule meko.
    ///
    /// Umsebenzisi we `from_raw` kufuneka aqinisekise ukuba ixabiso elithile le `T` liyehliswe kube kanye.
    ///
    /// Lo msebenzi awukhuselekanga kuba ukusetyenziswa gwenxa kungakhokelela kwimemori engakhuselekanga, nokuba i `Rc<T>` ebuyisiweyo ayinakufikelelwa.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Guqula ubuyele kwi `Rc` ukunqanda ukuvuza.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ukufowuna ngakumbi kwi `Rc::from_raw(x_ptr)` kuya kuba kukungakhuseleki kwimemori.
    /// }
    ///
    /// // Imemori yakhululwa xa i `x` yaphuma kumda ongentla, ke i `x_ptr` ngoku ilenga!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Revers offset ukufumana iRcBox yoqobo.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Yenza isikhombisi esitsha se [`Weak`] kolu lwabiwo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Qinisekisa ukuba asenzi into ebuthathaka ebuthathaka
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Ufumana inani lezikhombisi ze [`Weak`] kolu lwabiwo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ifumana inani lezikhombisi ezomeleleyo ze (`Rc`) kolu lwabiwo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Ibuyisa i `true` ukuba azikho ezinye i-`Rc` okanye i-[`Weak`] izikhombisi kolu lwabiwo.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Ibuyisela ireferensi enokutshintsha kwi-`Rc` enikiweyo, ukuba azikho ezinye i-`Rc` okanye i-[`Weak`] izikhombisi kulwabiwo olufanayo.
    ///
    ///
    /// Ibuyisa i [`None`] ngenye indlela, kuba akukhuselekanga ukutshintsha ixabiso ekwabelwana ngalo.
    ///
    /// Jonga kwakhona i [`make_mut`][make_mut], eya kuthi i [`clone`][clone] ixabiso langaphakathi xa kukho ezinye izikhombisi.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Ibuyisela ireferensi enokutshintsha kwi `Rc`, ngaphandle kwetshekhi.
    ///
    /// Jonga kwakhona i [`get_mut`], ekhuselekileyo kwaye ihlola ngokufanelekileyo.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Nayiphi na enye i-`Rc` okanye i-[`Weak`] yesikhombisi kulwabiwo olufanayo akufuneki iphinde ichazwe ixesha elibuyisiweyo.
    ///
    /// Oku kuyinto encinci ukuba akukho zikhombisi zikhoyo, umzekelo kwangoko emva kwe `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Silumkile ukuba *singenzi* ireferensi egubungela imihlaba ye "count", njengoko oku kungangqubana nokufikelela kubalo lwesalathiso (umz.
        // nge `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ibuyisa i `true` ukuba ezi zimbini `Rc zikhomba kulwabiwo olufanayo (kumthambo ofana no [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Yenza ireferensi enokuguquguquka kwi `Rc` enikiweyo.
    ///
    /// Ukuba kukho ezinye izikhombisi ze `Rc` kulwabiwo olufanayo, i `make_mut` iya kuthi [`clone`] ibe lixabiso langaphakathi kulwabiwo olutsha ukuqinisekisa ubunini obukhethekileyo.
    /// Oku kukwabhekiswa kuko njenge-clone-on-write.
    ///
    /// Ukuba azikho ezinye izikhombisi ze `Rc` kolu lwabiwo, ke izikhombisi ze [`Weak`] kolu lwabiwo ziya kwahlulwa.
    ///
    /// Jonga kwakhona i [`get_mut`], eya kuthi isilele endaweni yokwenza ikhonkrithi.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Awuyi kwenza nantoni na
    /// let mut other_data = Rc::clone(&data);    // Awuyi kulungelelanisa idatha yangaphakathi
    /// *Rc::make_mut(&mut data) += 1;        // Clones idatha yangaphakathi
    /// *Rc::make_mut(&mut data) += 1;        // Awuyi kwenza nantoni na
    /// *Rc::make_mut(&mut other_data) *= 2;  // Awuyi kwenza nantoni na
    ///
    /// // Ngoku i `data` kunye ne `other_data` yalatha kulwabiwo olwahlukileyo.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] izikhombisi ziya kwahlulwa:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Ufumene idatha, zikhona ezinye iiRcs.
            // Nika imemori kwangaphambili ukuvumela ukuba kubhalwe ixabiso elenziwe ngokuthe ngqo.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Ngaba unokuba idatha, konke okushiyekileyo bubuthathaka
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Susa i-Ref eqinileyo-ethe-ethe (akukho sidingo sokwenza into ebuthathaka apha-siyazi ukuba amanye amaTyhefu angasicoca)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Oku kungakhuselekanga kulungile kuba siqinisekisiwe ukuba isikhombisi sibuyisiwe sisikhombisi *kuphela* esiya kubuyiselwa ku-T.
        // Ubalo lwethu lwesalathiso luqinisekisiwe ukuba luyi-1 okwangoku, kwaye sifuna i-`Rc<T>` ngokwayo ibe yi-`mut`, ke sibuyisela ekuphela kwereferensi enokubakho kulwabiwo.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Ukuzama ukwehlisa i `Rc<dyn Any>` kuhlobo lwekhonkrithi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Yabela i `RcBox<T>` ngendawo eyoneleyo yexabiso langaphakathi elingenakulinganiswa apho ixabiso linobume obunikezelweyo.
    ///
    /// Umsebenzi u-`mem_to_rcbox` ubizwa ngesikhombisi sedatha kwaye kufuneka abuyisele i (pointer ye-fat) ye-`RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Bala ubeko usebenzisa ubeko lwexabiso elinikiweyo.
        // Ngaphambili, ubeko lwalubalwa kwisivakalisi `&*(ptr as* const RcBox<T>)`, kodwa oku kwenza ireferensi engachanekanga (jonga i #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Yabela i `RcBox<T>` ngendawo eyoneleyo yexabiso langaphakathi elingasetyenziswanga apho ixabiso linobume obubonelelweyo, ukubuyisa impazamo ukuba ulwabiwo lusilele.
    ///
    ///
    /// Umsebenzi u-`mem_to_rcbox` ubizwa ngesikhombisi sedatha kwaye kufuneka abuyisele i (pointer ye-fat) ye-`RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Bala ubeko usebenzisa ubeko lwexabiso elinikiweyo.
        // Ngaphambili, ubeko lwalubalwa kwisivakalisi `&*(ptr as* const RcBox<T>)`, kodwa oku kwenza ireferensi engachanekanga (jonga i #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Yabela uyilo.
        let ptr = allocate(layout)?;

        // Qalisa iRcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Yabela i `RcBox<T>` ngesithuba esaneleyo sexabiso langaphakathi elingalinganiswanga
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Yabela `RcBox<T>` usebenzisa ixabiso elinikiweyo.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Khuphela ixabiso njengee-byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Simahla ulwabiwo ngaphandle kokulahla imixholo yalo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Yabela i `RcBox<[T]>` ngobude obunikiweyo.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Khuphela izinto kwisilayidi usiya kwi-Rc <\[T\]>
    ///
    /// Ayikhuselekanga ngenxa yokuba umntu ekutsalele umnxeba kufuneka athathe ubunini okanye abophe i `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Yakha i `Rc<[T]>` esuka kwiterator eyaziwayo ukuba inobungakanani obuthile.
    ///
    /// Ukuziphatha akuchazwanga ukuba ubungakanani bungalunganga.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic unogada ngelixa ubumbela izinto zeT.
        // Kwimeko ye panic, izinto ezibhalwe kwi-RcBox entsha ziya kulahlwa, emva koko imemori ikhululwe.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Isalathiso kwinto yokuqala
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Zonke zicacile.Libala unogada ukuze angayikhululi iRcBox entsha.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Ubungcali be trait isetyenziselwe i `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Uwisa i `Rc`.
    ///
    /// Oku kuya kunciphisa ukubalwa kwesalathiso esomeleleyo.
    /// Ukuba isibalo esomeleleyo sesalathiso sifikelela kwi-zero ke ezinye izingqinisiso (ukuba zikhona) zi-[`Weak`], ke thina si-`drop` ixabiso langaphakathi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ayiprinti nantoni na
    /// drop(foo2);   // Ishicilela "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ukutshabalalisa into equlethwe
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // susa isikhombisi se "strong weak" ngoku ngoku siyichithile imixholo.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Yenza ikhonkco lesikhombisi se `Rc`.
    ///
    /// Oku kudala esinye isikhombisi kulwabiwo olufanayo, ukwandisa ukubalwa kwesalathiso esomeleleyo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Yenza i `Rc<T>` entsha, enexabiso le `Default` le `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// I-hack yokuvumela ukugxila kwi-`Eq` nangona i-`Eq` inendlela.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Senza ubuchwephesha apha, kwaye hayi njengokusebenza ngokubanzi kwi `&T`, kuba ngeyongeze indleko kuzo zonke iitshekhi zokulingana kwii-Refs.
/// Sicinga ukuba `ii-Rc`s zisetyenziselwa ukugcina amaxabiso amakhulu, acothayo ukudibanisa, kodwa ayasinda ukujonga ukulingana, ebangela ukuba le ndleko ihlawule ngokulula.
///
/// Kukwanamathuba okuba ne-`Rc` clones ezimbini, ezalatha kwixabiso elifanayo, kunee`&T`s ezimbini.
///
/// Singakwenza oku kuphela xa i-`T: Eq` njenge-`PartialEq` isenokungangqinelani ngabom.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Ukulingana kwee-Rc`s ezimbini.
    ///
    /// Ii-Rc`s zimbini ziyalingana ukuba amaxabiso abo angaphakathi ayalingana, nokuba agcinwe kulwabiwo olwahlukileyo.
    ///
    /// Ukuba i `T` ikwasebenzisa i `Eq` (okuthetha ukubonakalisa ukulingana), zimbini `Rc` ezalatha kulwabiwo olufanayo zihlala zilingana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ukungalingani ezimbini `Rc`s.
    ///
    /// Ii-Rc`s ezimbini azilingani ukuba amaxabiso abo angaphakathi awalingani.
    ///
    /// Ukuba i `T` ikwasebenzisa i `Eq` (okuthetha ukubuyela kwimeko yokulingana), ii`Rc`s ezimbini ezalatha kulwabiwo olunye azikaze zingalingani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Ukuthelekiswa okungafaniyo kwee-Rc`s ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `partial_cmp()` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ngaphantsi kokuthelekisa ii-Rc`s ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `<` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Ngaphantsi okanye kulingana nokuthelekisa 'Rc`s ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `<=` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Kukhulu kunokuthelekisa ii-Rc`s ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `>` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Mkhulu kuno okanye ulingana' nothelekiso lwee-Rc`s ezimbini.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `>=` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Thelekisa ezimbini `Rc`s.
    ///
    /// Ezi zimbini zithelekiswa ngokubiza i `cmp()` kumaxabiso abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Nikezela isilayidi esinexabiso lesalathiso kwaye usigcwalise ngokwenza izinto ze-v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Nikezela isalathiso somtya osikiweyo kunye nekopi ye `v` kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Nikezela isalathiso somtya osikiweyo kunye nekopi ye `v` kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Hambisa into ebhokisiweyo kwindawo entsha, ukubalwa kwesalathiso, ulwabiwo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Nikezela isilayidi esinexabiso lesalathiso kwaye ususe izinto ze-v kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vumela iVec ukuba ikhulule imemori yayo, kodwa ingatshabalalisi imixholo yayo
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Ithatha into nganye kwi-`Iterator` kwaye uyiqokelele kwi-`Rc<[T]>`.
    ///
    /// # Iimpawu zomsebenzi
    ///
    /// ## Ityala eliqhelekileyo
    ///
    /// Kwimeko eqhelekileyo, ukuqokelela kwi `Rc<[T]>` kwenziwa ngokuqokelela okokuqala kwi `Vec<T>`.Oko kukuthi, xa ubhala oku kulandelayo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// oku kuziphatha ngokungathi sibhale:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Iseti yokuqala yolwabiwo yenzeka apha.
    ///     .into(); // Ulwabiwo lwesibini lwe `Rc<[T]>` lwenzeka apha.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Oku kuyakwabiwa amaxesha ngamaxesha njengoko kufuneka ekwakheni i `Vec<T>` kwaye iya kwabela kube kanye xa kuguqulwa i `Vec<T>` ibe yi `Rc<[T]>`.
    ///
    ///
    /// ## Iterators zobude obaziwayo
    ///
    /// Xa i `Iterator` yakho isebenzisa i `TrustedLen` kwaye inobungakanani obuchanekileyo, ulwabiwo olunye luya kwenziwa kwi `Rc<[T]>`.Umzekelo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Ulwabiwo olunye lwenzeka apha.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Ubungcali be trait esetyenziselwa ukuqokelela kwi `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Le yimeko ye-`TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // UKHUSELEKO: Kufuneka siqinisekise ukuba iterator inobude obuchanekileyo kwaye sinazo.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Buyela umva kuphumezo oluqhelekileyo.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` Inguqulelo ye [`Rc`] ebambe isalathiso esingeyiso esakho kulwabiwo olulawulwayo.Ulwabiwo lufikeleleke ngokubiza i [`upgrade`] kwisikhombisi se `Weak`, esibuyisela [`Option`]`<<[`Rc`]` `<T>>`.
///
/// Kuba ireferensi ye `Weak` ayibali kubunini, ayizukuthintela ixabiso eligcinwe kulwabiwo ekuyekisweni, kwaye i `Weak` ngokwayo ayenzi siqinisekiso malunga nexabiso elisekho.
/// Yiyo ke loo nto inokubuyisa i [`None`] xa [`hlaziya`] d.
/// Qaphela nangona kunjalo ukuba isalathiso se `Weak` * siyaluthintela ulwabiwo ngokwalo (ivenkile exhasa) ekuhanjisweni.
///
/// Isikhombisi se `Weak` siluncedo ekugcineni ireferensi yethutyana kulwabiwo olulawulwa yi [`Rc`] ngaphandle kokuthintela ixabiso langaphakathi ekuhlisweni.
/// Isetyenziselwa ukuthintela izingqinisiso ezijikelezayo phakathi kwezikhombisi ze [`Rc`], kuba ukubangumnini wokubambisana akunakuvumela nokuba i [`Rc`] ilahlwe.
/// Umzekelo, umthi unokuba nezikhombisi ezomeleleyo ze [`Rc`] ukusuka kwiindawo zomzali ukuya kubantwana, kunye nezikhombisi ze `Weak` ezisuka kubantwana ababuyela kubazali babo.
///
/// Indlela eqhelekileyo yokufumana isikhombisi se `Weak` kukufowuna i [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Le yi `NonNull` yokuvumela ukwandiswa kobungakanani bolu hlobo kwii-enum, kodwa ayisiyiyo isikhombisi esisemthethweni.
    //
    // `Weak::new` icwangcisa oku ku-`usize::MAX` ukuze ingafuneki yabele indawo kwimfumba.
    // Eli ayiloxabiso lesikhombisi sokwenyani esiya kuba nalo kuba i-RcBox ilungelelanise ubuncinci i-2.
    // Oku kunokwenzeka kuphela xa i `T: Sized`;i-`T` engafakwanga khange iphazamise.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Yakha i `Weak<T>` entsha, ngaphandle kokwaba nayiphi na inkumbulo.
    /// Ukutsalela umnxeba i [`upgrade`] kwixabiso lokubuya kuhlala kunika i [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Uhlobo lomncedisi ukuvumela ukufikelela kubalo lwesalathiso ngaphandle kokwenza naziphi na izibhengezo malunga nomhlaba wedatha.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Ibuyisela isikhombisi esiluhlaza kwinto engu-`T` esalatha kule `Weak<T>`.
    ///
    /// Isikhombisi sisebenza kuphela ukuba kukho izingqinisiso ezithile ezomeleleyo.
    /// Isikhombisi sinokuxhonywa, singatyunjeliswanga okanye i [`null`] ngenye indlela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Zombini zikhomba kwinto enye
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ukomelela apha kuyigcina iphila, kungoko sinokwazi ukufikelela kwinto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Kodwa hayi ngaphezulu.
    /// // Singayenza i weak.as_ptr(), kodwa ukufikelela kwisikhombisi kungakhokelela kwindlela yokuziphatha engachazwanga.
    /// // assert_eq! ("molo", ayikhuselekanga {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ukuba isikhombisi sixhonyiwe, sibuyisela umthumeli ngqo.
            // Le ayinakuba yidilesi yokuhlawula esemthethweni, njengoko umthwalo ohlawulwayo ubuncinci ulungelelaniswe njenge-RcBox (usize).
            ptr as *const T
        } else {
            // UKHUSELEKO: ukuba_ukulengisa kubuya kubuxoki, isikhombisi asinakuphinda senziwe.
            // Umrhumo wokuhlawulwa ungaphoswa kweli nqanaba, kwaye kuya kufuneka sigcine imvelaphi, ke sebenzisa ubuqhetseba besikhombisi eluhlaza.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Isebenzisa i `Weak<T>` kwaye iyijike ibe sisikhombisi esiluhlaza.
    ///
    /// Oku kuguqula isikhombisi esibuthathaka sisikhombisi esiluhlaza, ngelixa sigcina ubunini besalathiso esinye esibuthathaka (inani elibuthathaka alilungiswanga ngulo msebenzi).
    /// Inokubuyiselwa umva kwi `Weak<T>` nge [`from_raw`].
    ///
    /// Izithintelo ezifanayo zokufikelela ekujoliseni kwesikhombisi njenge [`as_ptr`] ziyasebenza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Guqula isikhombisi esiluhlaza esenziwe ngaphambili ngu-[`into_raw`] sibuyele kwi `Weak<T>`.
    ///
    /// Oku kunokusetyenziselwa ukufumana ngokukhuselekileyo ireferensi eyomeleleyo (ngokubiza i [`upgrade`] kamva) okanye ukuhambisa inani elibuthathaka ngokuwisa i `Weak<T>`.
    ///
    /// Kuthatha ubunini besalathiso esinye esibuthathaka (ngaphandle kwezikhombisi ezenziwe yi [`new`], njengoko ezi zingenanto; indlela isasebenza kubo).
    ///
    /// # Safety
    ///
    /// Isikhombisi kufuneka ukuba sivela kwi-[`into_raw`] kwaye kufuneka sisaqhubeka nokuba sinesalathiso esibuthathaka.
    ///
    /// Kuvumelekile ukuba ubalo olomeleleyo lube ngu-0 ngexesha lokufowuna oku.
    /// Nangona kunjalo, oku kuthatha ubunini besalathiso esinye esibuthathaka ngoku simelwe njengesikhombisi esiluhlaza (inani elibuthathaka alilungiswanga ngulo msebenzi) kwaye ke kufuneka libhangqiwe kunye nomnxeba wangaphambili oya kwi [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Linciphise inani lokugqibela elibuthathaka.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Jonga i Weak::as_ptr ngomxholo wendlela isalathiso segalelo esivela ngayo.

        let ptr = if is_dangling(ptr as *mut T) {
            // Oku kujingile Obuthathaka.
            ptr as *mut RcBox<T>
        } else {
            // Ngaphandle koko, siqinisekisiwe ukuba isikhombisi sivela kubuthathaka obungathandekiyo.
            // UKHUSELEKO: i-data_offset ikhuselekile ukubiza, njengoko i-ptr ireferensi yokwenyani (enokuthi yehliswe) T.
            let offset = unsafe { data_offset(ptr) };
            // Ke, siyibuyisela umva iseti yokufumana iRcBox iphela.
            // UKHUSELEKO: Isikhombisi sivela kwi-Weak, ke oku kulungelelaniswa kukhuselekile.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // UKHUSELEKO: ngoku siyifumene isalathi esibuthathaka santlandlolo, ke sinako ukudala ababuthathaka.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Imizamo yokuphucula isikhombisi se `Weak` ukuya kwi [`Rc`], ukulibazisa ukwehla kwexabiso langaphakathi ukuba liphumelele.
    ///
    ///
    /// Ibuyisa i [`None`] ukuba ixabiso langaphakathi sele lihlile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Tshabalalisa zonke izikhombisi ezomeleleyo.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ifumana inani lezikhombisi ezomeleleyo ze (`Rc`) ezalatha kolu lwabiwo.
    ///
    /// Ukuba i `self` yenziwe kusetyenziswa i [`Weak::new`], oku kuyakubuyela ku-0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Ufumana inani lezikhombisi ze `Weak` ezalatha kolu lwabiwo.
    ///
    /// Ukuba akukho zikhombisi zomeleleyo zihlala zikhona, oku kuyakubuyisa zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // thabatha i-ptr engenamandla
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Ibuyisa i `None` xa isalathi sijinga kwaye akukho `RcBox` yabelweyo, (okt, xa le `Weak` yenziwe yi-`Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Silumkile ukuba *singenzi* ireferensi egubungela intsimi ye "data", njengoko intsimi inokutshintshwa ngaxeshanye (umzekelo, ukuba i `Rc` yokugqibela ilahliwe, indawo yedatha iya kuphoswa endaweni).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ibuyisa i-`true` ukuba ezi zibini zibuthathaka kulwabiwo olufanayo (olufana ne [`ptr::eq`]), okanye ukuba zombini azikhombisi kulo naluphi na ulwabiwo (kuba zenziwe nge `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kuba oku kuthelekisa izikhombisi kuthetha ukuba i `Weak::new()` iya kulingana, nangona ingakhombisi kulo naluphi na ulwabiwo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Thelekisa i `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Uwisa isikhombisi se `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ayiprinti nantoni na
    /// drop(foo);        // Ishicilela "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ukubala okubuthathaka kuqala nge-1, kwaye kuya kuya kwi-zero kuphela ukuba zonke izikhombisi ezomeleleyo zithe shwaka.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Yenza indawo yesikhombisi se `Weak` esalatha kulwabiwo olufanayo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Yakha i `Weak<T>` entsha, yabela imemori ye `T` ngaphandle kokuyiqala.
    /// Ukutsalela umnxeba i [`upgrade`] kwixabiso lokubuya kuhlala kunika i [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Sijonge_dibanisa apha ukujongana ne mem::forget ngokukhuselekileyo.Ukuthi ngqo
// ukuba une-mem::forget Rcs (okanye i-Weaks), ukubala kwakhona kunokuphuphuma, emva koko ungalukhulula ulwabiwo ngelixa i-Rcs (okanye ii-Weaks) ezikhoyo.
//
// Siyaphuma isisu kuba le yimeko ewohlokayo kangangokuba asikhathali nokuba kwenzeka ntoni-akukho nkqubo yokwenyani ekufuneka ikhe yakuva oku.
//
// Oku kuya kufuneka kunganakwa ngaphezulu kwentloko kuba awunyanzelekanga ukuba uzilinganise kakhulu kwi-Rust enkosi kubunini kunye nokuhambisa-iisemantiki.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Sifuna ukukhupha ngokugcwala endaweni yokulahla ixabiso.
        // Ubalo lwereferensi alunakuze lube yinto xa oku kubizwa;
        // Nangona kunjalo, sifaka isisu apha ukuze sibonise i-LLVM kulungelelwaniso oluphosiweyo.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Sifuna ukukhupha ngokugcwala endaweni yokulahla ixabiso.
        // Ubalo lwereferensi alunakuze lube yinto xa oku kubizwa;
        // Nangona kunjalo, sifaka isisu apha ukuze sibonise i-LLVM kulungelelwaniso oluphosiweyo.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Fumana isaphulelo ngaphakathi kwe `RcBox` yokuhlawula emva kwesikhombisi.
///
/// # Safety
///
/// Isikhombisi kufuneka sikhombe (kwaye sibe nemethadatha esebenzayo) kwimeko yangaphambili ye-T, kodwa i-T iyavunyelwa ukuba ilahlwe.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ukulungelelanisa ixabiso elingafakwanga kwisiphelo seRcBox.
    // Ngenxa yokuba i-RcBox iyi-repr(C), iya kuhlala iyintsimi yokugqibela kwimemori.
    // UKHUSELEKO: kuba ekuphela kweentlobo ezingasetyenziswanga ezinokubakho zizilayi, izinto ze-trait,
    // kunye neentlobo zangaphandle, imfuneko yokhuseleko okhoyo okwangoku ukwanelisa iimfuno ze align_of_val_raw;le yinkcukacha zokuphunyezwa kolwimi ekungenakuthenjelwa kuzo ngaphandle kwe std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}