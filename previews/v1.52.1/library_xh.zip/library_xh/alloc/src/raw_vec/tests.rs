use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Ukubhala uvavanyo lokudibanisa phakathi kwabanikezeli benkampani yesithathu kunye ne `RawVec` kuyinkohliso encinci kuba i `RawVec` API ayivezi iindlela zokwabiwa, ngenxa yoko asinakujonga ukuba kwenzeka ntoni xa umthengisi ephelile (ngaphaya kokufumana i panic).
    //
    //
    // Endaweni yoko, oku kujonga nje ukuba iindlela ze `RawVec` zenza okungenani iAllocator API xa igcina indawo yokugcina.
    //
    //
    //
    //
    //

    // Ulwabiwo olusisidenge olisebenzisa isixa esimiselweyo sepetroli ngaphambi kokuba iinzame zolwabiwo ziqale ukusilela.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ibangela ukuhanjiswa kwakhona, kusetyenziswa 50 + 150=iiyunithi ezingama-200 zepetroli)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Kuqala, i `reserve` yabela njenge `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // I-97 ingaphezulu kokuphindwa kabini kwesi-7, ke i `reserve` kufuneka isebenze njenge `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // I-3 ingaphantsi kwesiqingatha se-12, ke i `reserve` kufuneka ikhule ngokucacileyo.
        // Ngexesha lokubhala le test ikhula yinto yesi-2, ke amandla amatsha angama-24, nangona kunjalo, ukukhula kwe 1.5 kulungile kunjalo.
        //
        // Kungoko i `>= 18` ibango.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}