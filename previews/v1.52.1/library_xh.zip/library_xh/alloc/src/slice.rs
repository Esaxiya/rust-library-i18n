//! Umbono wobungakanani obunamandla ngokulandelelana, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Izilayi ziimbono kwibhloko yememori emelwe njengesikhombisi kunye nobude.
//!
//! ```
//! // Ukucoca i-Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // Ukunyanzela uluhlu kuluhlu
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Izilayi zinokutshintshwa okanye kwabelwane ngazo.
//! Uhlobo lwesilayidi ekwabelwana ngalo ngu-`&[T]`, ngelixa uhlobo lwesilayidi olunokutshintshwa luyi-`&mut [T]`, apho i-`T` imele uhlobo lwento.
//! Umzekelo, unokuguqula ibhloko yememori ukuba isilayidi esiguqukayo sikhombe:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Nazi ezinye zezinto ezikhoyo kule modyuli:
//!
//! ## Structs
//!
//! Kukho iindlela ezininzi eziluncedo kwizilayi, ezinje nge [`Iter`], emele ukuphindaphindwa kwesilayidi.
//!
//! ## Ukuphunyezwa kwe Trait
//!
//! Kukho iindlela ezininzi zokuphunyezwa kwe traits eziqhelekileyo kwizilayi.Eminye imizekelo ibandakanya:
//!
//! * [`Clone`]
//! * [`Eq`], I-[`Ord`], kwizilayi ezinohlobo lwe-[`Eq`] okanye i [`Ord`].
//! * [`Hash`] - kwizilayi ezinohlobo lwento eyi-[`Hash`].
//!
//! ## Iteration
//!
//! Izilayi zisebenzisa i `IntoIterator`.Iterator ivelisa izingqinisiso kwizinto zesilayidi.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Isilayidi esiguqukayo sivelisa izingqinisiso eziguqukayo kwizinto:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Le iterator ivelisa izingqinisiso ezinokuguquguquka kwizinto zesilayidi, ke ngelixa uhlobo lwesilayidi luyi-`i32`, uhlobo lwento eyenziwayo ye-iterator yi-`&mut i32`.
//!
//!
//! * [`.iter`] kunye ne [`.iter_mut`] ziindlela ezicacileyo zokubuyisa iiterators ezingagqibekanga.
//! * Ezinye iindlela ezibuyisa iiterator zi [`.split`], [`.splitn`], [`.chunks`], [`.windows`] kunye nokunye.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Uninzi losetyenziso kule modyuli lusetyenziswa kuphela kuqwalaselo lovavanyo.
// Kucocekile ukucima nje isilumkiso esingasetyenziswanga_ukungenisa ngaphandle kokuzilungisa.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Iindlela ezisisiseko zolwandiso lwesilayidi
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) iyafuneka ekuphumezeni i `vec!` macro ngexesha lokuvavanya i-NB, jonga imodyuli ye `hack` kule fayile ngeenkcukacha ezithe kratya.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) iyafuneka ekuphumezeni i `Vec::clone` ngexesha lokuvavanya i-NB, jonga imodyuli ye `hack` kule fayile ngeenkcukacha ezithe kratya.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Nge-cfg(test) `impl [T]` ayifumaneki, le misebenzi mithathu ngokwenene ikwi-`impl [T]` kodwa ingekho kwi-`core::slice::SliceExt`, kufuneka sibonelele ngale misebenzi kuvavanyo lwe-`test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Akufuneki songeze uphawu lwangaphakathi kule nto kuba isetyenziswa kakhulu kwi-`vec!` macro ikakhulu kwaye ibangela ukuhlengahlengiswa kweperf.
    // Jonga i #71204 yengxoxo kunye neziphumo zeperf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // izinto zaphawulwa ziqaliswe kwiluphu engezantsi
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) Kuyimfuneko ukuba i-LLVM isuse imida yokutshekishwa kwaye ine-codegen engcono kune-zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // i-vec yabiwa kwaye yaqaliswa ngentla apha ubuncinci obu bude.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // eyabelwe ngentla ngomthamo we `s`, kwaye uqalise ukuya kwi `s.len()` kwi ptr::copy_to_non_overlapping apha ngezantsi.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Uhlobo lwesilayidi.
    ///
    /// Olu hlobo luzinzile (okt, alulungelelanisi izinto ezilinganayo) kunye *O*(*n*\log(*n*)) elibi kakhulu.
    ///
    /// Xa kufanelekile, ukukhetha okungazinzanga kukhethwa kuba kukhawuleza ngokubanzi kunokuhlelwa okuzinzileyo kwaye akubonisi inkumbulo encedisayo.
    /// Jonga i [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// Ialgorithm yangoku yinto eguqukayo, edibanisa uhlobo oluphefumlelweyo ngu [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Yenzelwe ukuba ikhawuleze kakhulu kwimeko apho isilayi siphantse sahlelwa, okanye siqulathe ulandelelwano olubini okanye nangaphezulu olulungelelaniswe ngokulandelelana ngokulandelelana.
    ///
    ///
    /// Kwakhona, yabela ukugcinwa okwethutyana isiqingatha sobungakanani be `self`, kodwa kwizilayidi ezimfutshane uhlobo lokufaka olungabelwanga lusetyenziswa endaweni yoko.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Ihlela isilayi ngomsebenzi wokuthelekisa.
    ///
    /// Olu hlobo luzinzile (okt, alulungelelanisi izinto ezilinganayo) kunye *O*(*n*\log(*n*)) elibi kakhulu.
    ///
    /// Umsebenzi wokuthelekisa kufuneka uchaze uku-odolwa ngokupheleleyo kwezinto ezikwisilayidi.Ukuba uku-odola akuphelelanga, iodolo yezinto ayichazwanga.
    /// I-odolo iyonke iodolo ukuba iyiyo (yazo zonke i `a`, `b` kunye ne `c`):
    ///
    /// * iyonke kunye ne-antisymmetric: ngokuchanekileyo enye ye `a < b`, `a == b` okanye `a > b` yinyani, kwaye
    /// * Ukutshintsha, i `a < b` kunye ne `b < c` kuthetha i `a < c`.Kuyafana ukubambelela kuzo zombini i `==` kunye ne `>`.
    ///
    /// Umzekelo, ngelixa i-[`f64`] ingasebenzisi i-[`Ord`] kuba i-`NaN != NaN`, singasebenzisa i-`partial_cmp` njengoluhlobo lomsebenzi wethu xa sisazi ukuba isilayidi asinayo i-`NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Xa kufanelekile, ukukhetha okungazinzanga kukhethwa kuba kukhawuleza ngokubanzi kunokuhlelwa okuzinzileyo kwaye akubonisi inkumbulo encedisayo.
    /// Jonga i [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// Ialgorithm yangoku yinto eguqukayo, edibanisa uhlobo oluphefumlelweyo ngu [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Yenzelwe ukuba ikhawuleze kakhulu kwimeko apho isilayi siphantse sahlelwa, okanye siqulathe ulandelelwano olubini okanye nangaphezulu olulungelelaniswe ngokulandelelana ngokulandelelana.
    ///
    /// Kwakhona, yabela ukugcinwa okwethutyana isiqingatha sobungakanani be `self`, kodwa kwizilayidi ezimfutshane uhlobo lokufaka olungabelwanga lusetyenziswa endaweni yoko.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ukuhlengahlengisa umva
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Ihlela isilayi ngomsebenzi ophambili wokukhupha.
    ///
    /// Olu hlobo luzinzile (okt, alulungelelanisi izinto ezilinganayo) kunye *O*(*m*\*n*\log(*n*)) yeyona meko imbi kakhulu, apho umsebenzi ophambili uyi *O*(*m*).
    ///
    /// Kwimisebenzi ephambili ebizayo (umz
    /// imisebenzi engafikeleli lula kwipropathi okanye imisebenzi esisiseko), i [`sort_by_cached_key`](slice::sort_by_cached_key) inokwenzeka ukuba ikhawuleze kakhulu, njengoko ingabuyisi izitshixo zezinto.
    ///
    ///
    /// Xa kufanelekile, ukukhetha okungazinzanga kukhethwa kuba kukhawuleza ngokubanzi kunokuhlelwa okuzinzileyo kwaye akubonisi inkumbulo encedisayo.
    /// Jonga i [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// Ialgorithm yangoku yinto eguqukayo, edibanisa uhlobo oluphefumlelweyo ngu [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Yenzelwe ukuba ikhawuleze kakhulu kwimeko apho isilayi siphantse sahlelwa, okanye siqulathe ulandelelwano olubini okanye nangaphezulu olulungelelaniswe ngokulandelelana ngokulandelelana.
    ///
    /// Kwakhona, yabela ukugcinwa okwethutyana isiqingatha sobungakanani be `self`, kodwa kwizilayidi ezimfutshane uhlobo lokufaka olungabelwanga lusetyenziswa endaweni yoko.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ihlela isilayi ngomsebenzi ophambili wokukhupha.
    ///
    /// Ngexesha lokuhlela, umsebenzi ophambili ubizwa kube kanye kuphela kwinto nganye.
    ///
    /// Olu hlobo luzinzile (okt, alulungelelanisi izinto ezilinganayo) kunye *O*(*m*\*n* + *n* log(*n*)) eyona meko imbi, apho umsebenzi ophambili uyi *O*(*m*) .
    ///
    /// Kwimisebenzi ephambili elula (umzekelo, imisebenzi efikelela kwipropathi okanye imisebenzi esisiseko), i [`sort_by_key`](slice::sort_by_key) inokwenzeka ukuba ikhawuleze.
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// I-algorithm yangoku isekwe kwi-[pattern-defeating quicksort][pdqsort] ngu-Orson Peters, edibanisa imeko ye-avareji ekhawulezileyo ye-randomsort kunye neyona meko ikhawulezileyo ye-heapsort, ngelixa kufezekiswa ixesha lomgama kwizilayi ezineepateni ezithile.
    /// Isebenzisa ulwahlulo oluthile ukuthintela iimeko eziwohlokayo, kodwa nge-seed emiselweyo ukusoloko inika isimilo sokuziphatha.
    ///
    /// Kwimeko embi, ialgorithm yabela ukugcinwa okwethutyana kwi `Vec<(K, usize)>` ubude besilayidi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // I-macro encedisayo yokwenza isalathiso se-vector ngolona hlobo luncinci kunokwenzeka, ukunciphisa ulwabiwo.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Izinto ze `indices` zahlukile, njengoko zinesalathiso, ke naluphi na uhlobo luya kuzinza ngokubhekisele kwisilayidi santlandlolo.
                // Sisebenzisa i `sort_unstable` apha kuba ifuna ukwabiwa kwememori encinci.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Iikopi ze-`self` kwi-`Vec` entsha.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Apha, i `s` kunye ne `x` zinokuguqulwa ngokuzimeleyo.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Iikopi ze-`self` kwi-`Vec` entsha kunye nomnikezeli.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Apha, i `s` kunye ne `x` zinokuguqulwa ngokuzimeleyo.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // QAPHELA, jonga imodyuli ye `hack` kule fayile ngeenkcukacha ezithe kratya.
        hack::to_vec(self, alloc)
    }

    /// Guqula i `self` ibe yi-vector ngaphandle kwamatye okanye ulwabiwo.
    ///
    /// Isiphumo se vector sinokuguqulwa sibuyele kwibhokisi nge `Vec<T>Indlela ye `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ayinakusetyenziswa kwakhona kuba iguqulwe yenziwa i `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // QAPHELA, jonga imodyuli ye `hack` kule fayile ngeenkcukacha ezithe kratya.
        hack::into_vec(self)
    }

    /// Yenza i-vector ngokuphinda isilayi amaxesha angama-`n`.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uya panic ukuba umthamo uya kuphuphuma.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// I-panic xa iphuphuma:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ukuba i-`n` inkulu kune-zero, inokwahlulwa njenge-`n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` linani elimelwe lincinci elingu-'1' elingu-`n`, kwaye i-`rem` yinxalenye eseleyo ye `n`.
        //
        //

        // Sebenzisa i `Vec` ukufikelela kwi `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` Ukuphindaphinda kwenziwa ngokuphinda-phinda ama `buf` `expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ukuba i-`m > 0`, kusele iibits ukuya kuthi ga kwi-'1' yasekhohlo.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` inesakhono se `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) Uphinda-phindo lwenziwa ngokukhuphela u `rem` wokuqala ku `buf` uqobo.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Oku ayigqithisi ukusukela nge `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` ilingana ne `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens isilayi se `T` kwixabiso elinye le `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens isilayi se `T` kwixabiso elinye le `Self::Output`, ubeke isahluli esinikiweyo phakathi kwento nganye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens isilayi se `T` kwixabiso elinye le `Self::Output`, ubeke isahluli esinikiweyo phakathi kwento nganye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Ibuyisa i-vector equlathe ikopi yesi silayi apho i-byte nganye imephu yayo ilingana ne-ASCII.
    ///
    ///
    /// Iileta ze-ASCII 'a' ukuya kwi 'z' zimiselwe imephu ukuya kwi 'A' ukuya kwi 'Z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukunyusa ixabiso endaweni, sebenzisa i [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Ibuyisa i-vector equlathe ikopi yesi silayi apho i-byte nganye imephu yayo ye-ASCII yamatyala alinganayo.
    ///
    ///
    /// Iileta ze-ASCII 'A' ukuya kwi 'Z' zimiselwe imephu ukuya kwi 'a' ukuya kwi 'z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukuthoba ixabiso lendawo, sebenzisa i [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ulwandiso traits kwizilayi ngaphezulu kweentlobo ezithile zedatha
////////////////////////////////////////////////////////////////////////////////

/// Umncedisi u trait we [`[T]: : concat`](slice::concat).
///
/// Note: Uhlobo lwe `Item` yiparameter ayisetyenziswanga kule trait, kodwa ivumela i-impls ukuba zenze generic.
/// Ngaphandle kwayo, sifumana le mpazamo:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Kungenxa yokuba kunokubakho iintlobo ze-`V` ezine-`Borrow<[_]>` impls, ezinokuthi iintlobo ezininzi ze `T` zisebenze:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Uhlobo olusiphumo emva kokuhlangana
    type Output;

    /// Ukuphunyezwa kwe [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Umncedisi u trait we [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Uhlobo olusiphumo emva kokuhlangana
    type Output;

    /// Ukuphunyezwa kwe [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ukuphunyezwa komgangatho we trait kwizilayi
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // lahla nantoni na ekujoliswe kuyo engayi kubhalwa ngaphezulu
        target.truncate(self.len());

        // target.len <= self.len ngenxa ye-truncate engentla, ke izilayi apha zihlala zihlala zikumda.
        //
        let (init, tail) = self.split_at(target.len());

        // phinda usebenzise amaxabiso aqulathiweyo allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Faka i `v[0]` kulungelelwaniso olungaphambi kokuhlelwa `v[1..]` ukuze i `v[..]` iphela ihlelwe.
///
/// Le yinkqutyana yokudityaniswa yohlobo lokufakwa.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Zintathu iindlela zokuphumeza ukufakwa apha:
            //
            // 1. Guqula izinto ezikufutshane de kube eyokuqala ifike kwindawo yayo yokugqibela.
            //    Nangona kunjalo, ngale ndlela sikopa idatha ejikeleze ngaphezulu kokufuneka.
            //    Ukuba izinto zizakhiwo ezinkulu (zibiza imali ukukopa), le ndlela izakucotha.
            //
            // 2. Iterate de kufumaneke indawo elungileyo yento yokuqala.
            // Emva koko tshintsha izinto eziyiphumeleleyo ukuyenzela indawo kwaye ekugqibeleni uyibeke kumngxunya oshiyekileyo.
            // Le yindlela elungileyo.
            //
            // 3. Khuphela into yokuqala kuguquguquko lwexeshana.Iterate de ifumaneke kwindawo efanelekileyo.
            // Njengoko siqhubeka, khuphela yonke into enqamlezayo kwislot engaphambi kwayo.
            // Okokugqibela, khuphela idatha ukusuka kuguquguquko lwexeshana uye kumngxunya oshiyekileyo.
            // Le ndlela intle kakhulu.
            // Iibhentshi zibonise ukusebenza okungcono kancinci kunendlela yesi-2.
            //
            // Zonke iindlela zazimisiwe, kwaye owesithathu wabonisa iziphumo ezilungileyo.Ke siyikhethile.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Imeko ephakathi yenkqubo yokufaka ihlala ilandelwa yi `hole`, esebenza ngeenjongo ezimbini:
            // 1. Ikhusela ingqibelelo ye `v` kwi panics kwi `is_less`.
            // 2. Ugcwalisa umngxuma oseleyo kwi `v` ekugqibeleni.
            //
            // Ukhuseleko lwe Panic:
            //
            // Ukuba i-`is_less` panics nanini na ngexesha lenkqubo, i-`hole` iya kulahla ize igcwalise umngxunya kwi-`v` nge-`tmp`, ngaloo ndlela iqinisekise ukuba i-`v` isabambe yonke into eyayibanjelwe yona kanye.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` iyehla kwaye ke ikopi i `tmp` iye kumngxuma oseleyo kwi `v`.
        }
    }

    // Xa ilahliwe, iikopi ukusuka kwi `src` ukuya kwi `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Ukudibanisa ukunganganciphisi ii-`v[..mid]` kunye ne-`v[mid..]` zisebenzisa i-`buf` njengokugcina okwethutyana, kwaye zigcina iziphumo kwi-`v[..]`.
///
/// # Safety
///
/// Amacwecwe amabini kufuneka angabinanto kwaye i `mid` kufuneka ibe kwimida.
/// IBuffer `buf` kufuneka inde ngokwaneleyo ukuba ingabamba ikopi yesilayidi esifutshane.
/// Kwakhona, i `T` akufuneki ibe luhlobo lobungakanani beqanda.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Inkqubo yokudibanisa kuqala ikopi ezimfutshane zibaleke ziye kwi `buf`.
    // Emva koko ilanda umqhubi osanda kukhutshelwa kunye nokubaleka okude ukuya phambili (okanye ngasemva), ngokuthelekisa izinto zabo ezingathathwanga ngokulandelayo kunye nokukopa encinci (okanye enkulu) enye kwi `v`.
    //
    // Ngokukhawuleza ukubaleka okufutshane kugqitywe ngokupheleleyo, inkqubo yenziwe.Ukuba ixesha elide liyagqitywa, kuya kufuneka sikhuphele nantoni na eseleyo yokuhamba okufutshane kumngxunya oseleyo kwi `v`.
    //
    // Isimo esiphakathi senkqubo sihlala silandelwa yi `hole`, esebenza ngeenjongo ezimbini:
    // 1. Ikhusela ingqibelelo ye `v` kwi panics kwi `is_less`.
    // 2. Ugcwalisa umngxuma oshiyekileyo kwi `v` ukuba ixesha elide liyagqitywa.
    //
    // Ukhuseleko lwe Panic:
    //
    // Ukuba i-`is_less` panics nanini na ngexesha lenkqubo, i-`hole` iya kulahla ize igcwalise umngxunya kwi-`v` ngoluhlu olungathathwanga kwi-`buf`, ngaloo ndlela iqinisekisa ukuba i-`v` isabambe yonke into eyayibanjelwe kanye kanye.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Ukubaleka ngasekhohlo kufutshane.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Ekuqaleni, ezi zikhombisi zalatha ekuqalekeni koluhlu lwabo.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Sebenzisa icala elincinci.
            // Ukuba ulingana, khetha indlela yasekhohlo ukuze ugcine uzinzo.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Ukubaleka ekunene kufutshane.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Ekuqaleni, ezi zikhombisi zikhomba ngaphaya kweziphelo zoluhlu lwazo.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Sebenzisa icala elikhulu.
            // Ukuba ulingana, khetha indlela eyiyo yokubaleka ukugcina uzinzo.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Okokugqibela, i `hole` iyehla.
    // Ukuba uhambo olufutshane aluzange lusetyenziswe ngokupheleleyo, nantoni na eseleyo iya kuthi ikhutshelwe emngxunyeni kwi `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Xa ilahliwe, ikhuphela uluhlu lwe-`start..end` kwi-`dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ayilodidi olungu-zero, ke kulungile ukuba yahlulahlulwe ngokobungakanani bayo.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Olu hlobo lokudibanisa luboleka ezinye (kodwa ayizizo zonke) izimvo ezivela kwiTimSort, echazwe ngokweenkcukacha i [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Ialgorithm ichonga ngokungxamisekileyo ukwehla nokungahambi emva, okubizwa ngokuba kukubaleka kwendalo.Kukho isitaki sokulinda esisalindelwe ukudityaniswa.
/// Ubaleko ngalunye olusandula ukufunyanwa lutyhalelwe kwisitaki, emva koko ezinye izibini zembaleki ezikufutshane zidityanisiwe de aba bangeneleli bobabini banelisekile:
///
/// 1. nge `i` nganye kwi `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. Yonke i `i` kwi `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Abahlaseli baqinisekisa ukuba ixesha lokubaleka lilonke li *O*(*n*\log(*n*)) elona tyala libi.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Iziqwenga ukuya kuthi ga kobu bude ziyacwangciswa kusetyenziswa uhlobo lokufaka.
    const MAX_INSERTION: usize = 20;
    // Imbaleki emfutshane kakhulu iyandiswa kusetyenziswa uhlobo lokufaka ukuze kuthathwe ubuncinci kwezi zinto zininzi.
    const MIN_RUN: usize = 10;

    // Ukuhlela akukho ndlela yokuziphatha inentsingiselo kuhlobo lwe-zero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Uluhlu olufutshane luhlelwa endaweni ngokufakwa kohlobo lokuthintela ulwabiwo.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Yabela i-buffer ukuze uyisebenzise njengememori yokuqala.Sigcina ubude be-0 ukuze sikwazi ukugcina kuyo iikopi ezingekho nzulu zemixholo ye `v` ngaphandle kokubeka emngciphekweni iidtors ezisebenza kwiikopi ukuba `is_less` panics.
    //
    // Xa udibanisa imisebenzi emibini ehleliweyo, le buffer ibambe ikopi yendlela emfutshane yokubaleka, eya kuhlala inobude ngeyona `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Ukuchonga ukubaleka kwendalo kwi `v`, sihamba sibuyele umva.
    // Oko kunokubonakala ngathi sisigqibo esingaqhelekanga, kodwa qaphela inyani yokuba ukudityaniswa rhoqo kuhlala kwelinye icala le-(forwards).
    // Ngokweebhentshi, ukudibanisa ukubheka phambili kukhawuleza kancinci kunokudibanisa ngasemva.
    // Ukuqukumbela, ukufumanisa ukubaleka ngokuhamba umva kuphucula ukusebenza.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Fumana imeko elandelayo yendalo, kwaye uyibuyise umva ukuba ihle ngokungqongqo.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Faka ezinye izinto ukubaleka ukuba zimfutshane kakhulu.
        // Uhlobo lokufaka lufakwa ngokukhawuleza kunokudityaniswa kohlobo ngokulandelelana okufutshane, ke oku kuphucula kakhulu ukusebenza.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Tyhala oku ubaleka kwisitaki.
        runs.push(Run { start, len: end - start });
        end = start;

        // Dibanisa ezinye zeembambo zokubaleka ezikufutshane ukwanelisa abahlaseli.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Okokugqibela, uhambo olunye ngokuchanekileyo kufuneka luhlale kwisitaki.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Ivavanya ingqokelela yemitsi kwaye ichonge isibini sokubaleka ukudibanisa.
    // Ngokukodwa, ukuba i `Some(r)` ibuyisiwe, oko kuthetha ukuba i `runs[r]` kunye ne `runs[r + 1]` kufuneka zidityaniswe ngokulandelayo.
    // Ukuba ialgorithm kufuneka iqhubeke nokwakha indlela entsha endaweni yoko, i `None` iyabuyiselwa.
    //
    // I-TimSort idume kakubi ngokuphunyezwa kwayo, njengoko kuchaziwe apha:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Umongo webali yile: kufuneka sinyanzelise izinto ezingenayo kwimbaleki ephezulu kwi-stack.
    // Ukunyanzeliswa kwabo phezulu ezintathu nje akonelanga ukuqinisekisa ukuba abahlaseli baya kubamba yonke * ibaleka kwisitaki.
    //
    // Lo msebenzi ujonga ngokuchanekileyo izihambeli zokubaleka ezine eziphezulu.
    // Ukongeza, ukubabaleka okuphezulu kuqala kwisalathiso se-0, iya kuhlala ifuna umsebenzi wokudibanisa de isitaki siwe ngokupheleleyo, ukuze kugqitywe uhlobo.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}