#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Imixholo yememori entsha ayichazwanga.
    Uninitialized,
    /// Imemori entsha iqinisekisiwe ukuba ayifakwanga.
    Zeroed,
}

/// Isixhobo esikwinqanaba elisezantsi lokwabiwa kwe-ergonomic, ukwabiwa kwakhona, kunye nokuhambisa indawo yokugcina inkumbulo kwimfumba ngaphandle kokukhathazeka ngawo onke amatyala ekona abandakanyekileyo.
///
/// Olu hlobo lubalasele ekwakheni olwakho ulwazi lweedatha ezinjengeVec kunye neVecDeque.
/// Ukuthi ngqo:
///
/// * Ivelisa i-`Unique::dangling()` kwiindidi ezilinganayo.
/// * Ivelisa i-`Unique::dangling()` kulwabiwo lobude obunguziro.
/// * Iphepha ukukhulula i `Unique::dangling()`.
/// * Ukubamba konke ukuphuphuma kokudityaniswa kwamandla (kuyabakhuthaza ukuya kwi "capacity overflow" panics).
/// * Abalindi ngokuchasene neenkqubo ezingama-32 ezinikezela ngaphezulu kwee-isize::MAX byte.
/// * Abalindi ngokuchasene nokuphuphuma ubude bakho.
/// * Iifowuni `handle_alloc_error` zolwabiwo olungenakuphosakala.
/// * Inayo i-`ptr::Unique` kwaye ke inika umsebenzisi zonke izibonelelo ezinxulumene noko.
/// * Sebenzisa ukugqitha okubuyiselwe kumniki sabelo ukusebenzisa owona mthamo mkhulu ufumanekayo.
///
/// Olu hlobo aluhlolisisi imemori elawulayo.Xa uyilahlile *iya kuyikhulula imemori yayo, kodwa* ayizukuzama ukulahla imixholo yayo.
/// Kuxhomekeke kumsebenzisi we `RawVec` ukuphatha ezona zinto *zigcinwe* ngaphakathi kwi `RawVec`.
///
/// Qaphela ukuba ukugqitha kweentlobo ezinobungakanani be-zero kuhlala kungenasiphelo, ke i `capacity()` ihlala ibuyisa i `usize::MAX`.
/// Oku kuthetha ukuba kuya kufuneka ulumke xa ujikeleza olu hlobo nge-`Box<[T]>`, kuba i `capacity()` ayizukuvelisa ubude.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Oku kubangelwe kukuba i `#[unstable]` const fn`s akufuneki ihambisane ne `min_const_fn` kwaye ke abanakubizwa kwi`min_const_fn`s nokuba.
    ///
    /// Ukuba utshintsha i `RawVec<T>::new` okanye ukuxhomekeka, nceda unonophele ungazisi nantoni na enokwaphula i `min_const_fn`.
    ///
    /// NOTE: Singayiphepha le nto yokuqhekeza kwaye siqwalasele ukungqinelani kunye ne-`#[rustc_force_min_const_fn]` ethile efuna ukuhambelana ne `min_const_fn` kodwa ayivumeli ukuyibiza kwi `stable(...) const fn`/ikhowudi yomsebenzisi engavumeli i `foo` xa i `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ikho.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Yenza eyona i `RawVec` inkulu (kwimfumba yenkqubo) ngaphandle kokunikezela.
    /// Ukuba i `T` inobungakanani obuqinisekileyo, ke le yenza i `RawVec` ngomthamo `0`.
    /// Ukuba i `T` ubukhulu bayo bunguziro, emva koko yenza i `RawVec` ngomthamo `usize::MAX`.
    /// Iluncedo ekuphumezeni ulwabiwo olulibazisekileyo.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Yenza i `RawVec` (kwimfumba yenkqubo) kunye nomthamo kunye nokulungelelanisa iimfuno ze `[T; capacity]`.
    /// Oku kulingana nokubiza i-`RawVec::new` xa i-`capacity` ingu-`0` okanye i-`T` ilingana no-zero.
    /// Qaphela ukuba i-`T` ilingana no-zero oku kuthetha ukuba awuyi kufumana `RawVec` ngomthamo oceliweyo.
    ///
    /// # Panics
    ///
    /// Panics ukuba umthamo oceliweyo ungaphezulu kwe-`isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Ukuphuma kwi-OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Njengo `with_capacity`, kodwa uqinisekisa ukuba i-buffer ayifakwanga.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Yenza kwakhona i `RawVec` kwisikhombisi kunye nomthamo.
    ///
    /// # Safety
    ///
    /// I `ptr` kufuneka yabelwe (kwimfumba yenkqubo), kunye ne `capacity` enikiweyo.
    /// I `capacity` ayinakugqitha i-`isize::MAX` yeentlobo ezinobungakanani.(kuphela inkxalabo kwiinkqubo ezingama-32).
    /// I-ZST vectors inokuba nomthamo ukuya kuthi ga kwi `usize::MAX`.
    /// Ukuba i `ptr` kunye ne `capacity` zivela kwi `RawVec`, ke oku kuqinisekisiwe.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // IiVecs ezincinci azizidenge.Tsiba ku:
    // - 8 ukuba ubungakanani bento ngu-1, kuba nayiphi na imfumba eyabelweyo inokujikeleza isicelo esingaphantsi kwe-8 nge-byte ukuya kwi-8 ye-byte.
    //
    // - 4 ukuba izinto ziphakathi ngokomlinganiso (<=1 KiB).
    // - 1 ngenye indlela, ukunqanda ukuchitha indawo eninzi kwiiVecs ezimfutshane kakhulu.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Njengo `new`, kodwa yenziwa iparameter kukhetho lomnikezeli we `RawVec` ebuyisiweyo.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` kuthetha i "unallocated".Iindidi ezilingana no-zero azihoywa.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Njengo `with_capacity`, kodwa yenziwa iparameter kukhetho lomnikezeli we `RawVec` ebuyisiweyo.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Njengo `with_capacity_zeroed`, kodwa yenziwa iparameter kukhetho lomnikezeli we `RawVec` ebuyisiweyo.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Guqula i `Box<[T]>` ibe yi `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Iguqula i-buffer iphelele ibe yi-`Box<[MaybeUninit<T>]>` nge-`len` echaziweyo.
    ///
    /// Qaphela ukuba oku kuyakulungisa ngokufanelekileyo naluphi na utshintsho lwe `cap` olunokuthi lwenziwe.(Jonga inkcazo yohlobo lweenkcukacha.)
    ///
    /// # Safety
    ///
    /// * `len` kufuneka ibengaphezulu okanye ilingane nomthamo osandula ukucelwa, kwaye
    /// * `len` kufuneka ibe ngaphantsi okanye ilingane ne `self.capacity()`.
    ///
    /// Qaphela, ukuba umthamo oceliweyo kunye ne `self.capacity()` zinokwahluka, njengoko umabi wabelo anokunikezela ngaphezulu kwaye abuyisele inkumbulo enkulu kunokuba bekuceliwe.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Ucoceko-khangela isiqingatha semfuneko yokhuseleko (asinakujonga esinye isiqingatha).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Siyayiphepha i-`unwrap_or_else` apha kuba ibhloko yeLLVM IR evelisiweyo.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Yakha kwakhona i `RawVec` kwisikhombisi, umthamo, kunye nolwabiwo.
    ///
    /// # Safety
    ///
    /// I `ptr` mayabelwe (kusetyenziswa owabelweyo u `alloc`), kunye ne `capacity` enikiweyo.
    /// I `capacity` ayinakugqitha i-`isize::MAX` yeentlobo ezinobungakanani.
    /// (kuphela inkxalabo kwiinkqubo ezingama-32).
    /// I-ZST vectors inokuba nomthamo ukuya kuthi ga kwi `usize::MAX`.
    /// Ukuba i `ptr` kunye ne `capacity` zivela kwi `RawVec` eyenziwe nge `alloc`, ke oku kuqinisekisiwe.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ifumana isikhombisi esiluhlaza ukuqala kolwabiwo.
    /// Qaphela ukuba le yi-`Unique::dangling()` ukuba i-`capacity == 0` okanye i-`T` ubukhulu bayo bungu-zero.
    /// Kwimeko yangaphambili, kufuneka uqaphele.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Ifumana ubungakanani bolwabiwo.
    ///
    /// Oku kuyakuhlala kungu-`usize::MAX` ukuba i-`T` ilingana no-zero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Ibuyisa ireferensi ekwabelwana ngayo kumnikezeli exhasa le `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Sine-chunk yememori eyabelweyo, ukuze sikwazi ukugqitha ekujongeni ixesha lokubaleka ukuze sifumane ubeko lwangoku.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Iqinisekisa ukuba i-buffer inesithuba esaneleyo sokubamba izinto ze-`len + additional`.
    /// Ukuba ayinamandla ngokwaneleyo, iya kwabela kwakhona indawo eyoneleyo kunye nendawo ethe tyaba ukuze ufumane isimilo *O*(1) isimilo.
    ///
    /// Iya kunciphisa le ndlela yokuziphatha ukuba inokuzibangela iye kwi-panic.
    ///
    /// Ukuba i `len` idlula i `self.capacity()`, oku kusenokungaphumeleli ekwabeni indawo oyicelileyo.
    /// Oku akukhuselekanga ngenene, kodwa ikhowudi engakhuselekanga oyibhalayo exhomekeke kukuziphatha kwalo msebenzi inokuqhekeka.
    ///
    /// Oku kufanelekile ekuphumezeni ukusebenza kwe-bulk-push njenge-`extend`.
    ///
    /// # Panics
    ///
    /// Panics ukuba amandla amatsha angaphaya kwe-`isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Ukuphuma kwi-OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // Ugcino ngesele luphumile okanye lwothuka ukuba ilensi igqithile kwi `isize::MAX` ke oku kukhuselekile ukuba kungakhangelwa ngoku.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Iyafana ne `reserve`, kodwa ibuyisa iimpazamo endaweni yokoyika okanye ukukhupha isisu.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Iqinisekisa ukuba i-buffer inesithuba esaneleyo sokubamba izinto ze-`len + additional`.
    /// Ukuba ayikabikho, iya kubuyisela ubuncinci bememori enokwenzeka.
    /// Ngokubanzi oku kuya kuba lixabiso lememori eliyimfuneko, kodwa kumgaqo-siseko umabeli ukhululekile ukubuyisa ngaphezulu kunokuba besikucelile.
    ///
    ///
    /// Ukuba i `len` idlula i `self.capacity()`, oku kusenokungaphumeleli ekwabeni indawo oyicelileyo.
    /// Oku akukhuselekanga ngenene, kodwa ikhowudi engakhuselekanga oyibhalayo exhomekeke kukuziphatha kwalo msebenzi inokuqhekeka.
    ///
    /// # Panics
    ///
    /// Panics ukuba amandla amatsha angaphaya kwe-`isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Ukuphuma kwi-OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Iyafana ne `reserve_exact`, kodwa ibuyisa iimpazamo endaweni yokoyika okanye ukukhupha isisu.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Lunciphisa ulwabiwo luye kwixabiso elichaziweyo.
    /// Ukuba inani elinikiweyo ngu-0, ngenene lihambisa ngokupheleleyo.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba inani elinikiweyo likhulu * ngaphezu komthamo wangoku.
    ///
    /// # Aborts
    ///
    /// Ukuphuma kwi-OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Ibuyisa ukuba i-buffer kufuneka ikhule ukuzalisekisa amandla ongezelelweyo afunekayo.
    /// Isetyenziswa ikakhulu ukwenza i-inlining reserve-calls kunokwenzeka ngaphandle kokufaka i-`grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Le ndlela ihlala iqinisekiswa amaxesha amaninzi.Ke sifuna ukuba ibe ncinane kangangoko kunokwenzeka, ukuphucula amaxesha okudibanisa.
    // Kodwa sifuna umxholo wayo ukuba ubalwe ngokwezibalo ngangokunokwenzeka, ukwenza ikhowudi evelisiweyo ibaleke ngokukhawuleza.
    // Ke ngoko, le ndlela ibhalwe ngocoselelo ukuze yonke ikhowudi exhomekeke kwi `T` ingaphakathi kuyo, ngelixa uninzi lwekhowudi engaxhomekekanga kwi `T` ngokusemandleni kwimisebenzi engeyoyesiqhelo ngaphezulu kwe `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Oku kuqinisekiswa yimixholo yokufowuna.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Ukusukela ukubuyisa umthamo we `usize::MAX` xa u `elem_size` eyi
            // 0, ukufika apha kuthetha ukuba i `RawVec` igcwele.
            return Err(CapacityOverflow);
        }

        // Akukho nto sinokuyenza malunga nolu hlolo, ngelishwa.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Oku kuqinisekisa ukukhula okubonakalayo.
        // Ukuphindaphinda akunakuphuphuma kuba i `cap <= isize::MAX` kunye nohlobo lwe `cap` ngu `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ayisiyo generic ngaphezulu kwe `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Izithintelo kule ndlela ziyafana nezo zikwi `grow_amortized`, kodwa le ndlela ihlala iqiniswa rhoqo kwaye ayibalulekanga kangako.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Ukusukela ukubuyisa umthamo we `usize::MAX` xa uhlobo lobungakanani bungu
            // 0, ukufika apha kuthetha ukuba i `RawVec` igcwele.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ayisiyo generic ngaphezulu kwe `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Lo msebenzi ungaphandle kwe `RawVec` ukunciphisa amaxesha okudibanisa.Jonga la magqabantla angentla kwe `RawVec::grow_amortized` ngeenkcukacha.
// (Ipharamitha ye `A` ayibalulekanga, kuba inani leentlobo ezahlukeneyo ze `A` ezibonwayo xa zisebenza lincinci kakhulu kunenani leentlobo ze `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Jonga impazamo apha ukunciphisa ubungakanani be `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Umnikezeli ukhangela ulungelelwaniso lokulingana
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Ihlawula imemori ye `RawVec` * ngaphandle kokuzama ukulahla imixholo yayo.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Umsebenzi ophambili wokugcina impazamo.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Kufuneka siqinisekise oku kulandelayo:
// * Asikhe sabela izinto ezinobungakanani be-`> isize::MAX`.
// * Asiphuphethi i `usize::MAX` kwaye sabela into encinci kakhulu.
//
// Kwi-64-bit sifuna nje ukujonga ukuphuphuma kuba ukuzama ukwaba ii-`> isize::MAX` byte ngokuqinisekileyo kuyasilela.
// Kwi-32-bit kunye ne-16-bit kufuneka songeze unogada ongaphezulu koku ukuba sibaleka kwiqonga elinokusebenzisa yonke i-4GB kwisithuba somsebenzisi, umzekelo, i-PAE okanye i x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Umsebenzi omnye ophambili onoxanduva lokunika ingxelo uphuphuma.
// Oku kuyakuqinisekisa ukuba ikhowudi yokuvelisa enxulumene nale panics incinci njengoko inye kuphela indawo eyi panics endaweni yeqela kuyo yonke imodyuli.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}