//! Izixhobo zokufomatha kunye nokuprinta i-String`s.
//!
//! Le modyuli iqulethe inkxaso yexesha lokubaleka lokongezwa kwe [`format!`] X syntax.
//! Le macro iphunyezwe kumhlanganisi ukukhupha iifowuni kule modyuli ukuze ifomathile iimpikiswano ngexesha lokubaleka libe yimitya.
//!
//! # Usage
//!
//! I-[`format!`] macro yenzelwe ukuba yaziwe kwabo bavela kwimisebenzi ye-C's `printf`/`fprintf` okanye Python's `str.format`.
//!
//! Eminye imizekelo yolwandiso lwe [`format!`] yile:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" kunye noziro abakhokelayo
//! ```
//!
//! Ukusuka kwezi, uyabona ukuba impikiswano yokuqala ngumtya wefomathi.Ifunwa ngumhlanganisi ukuze oku kube ngumtya wokoqobo;ayinakuba ngumahluko odlulisiweyo (ukuze kwenziwe ukukhangela okuqinisekileyo).
//! Umhlanganisi uya kuthi emva koko ahambise umtya wefomathi kwaye amisele ukuba uluhlu lweempikiswano olunikiweyo lulungele ukudlula kule fomathi yomtya.
//!
//! Ukuguqula ixabiso elinye libe ngumtya, sebenzisa indlela ye [`to_string`].Oku kuyakusebenzisa ifomathi ye [`Display`] trait.
//!
//! ## Iiparameter zemo
//!
//! Impikiswano nganye yokufomatha ivumelekile ukuba ichaze ukuba yeyiphi na impikiswano yexabiso ebhekisa kuyo, kwaye ukuba ishiywe ithathwa njenge-"the next argument".
//! Umzekelo, umtya wefomathi `{} {} {}` ungathatha iiparameter ezintathu, kwaye ziya kufomathwa ngendlela efanayo njengoko zinikiweyo.
//! Umtya wefomathi `{2} {1} {0}`, nangona kunjalo, unokufomatha iingxoxo ngokulandelelana.
//!
//! Izinto zinokukhohlisa kancinci xa uqala ukudibanisa ezi ndidi zimbini zokukhankanywa kwemeko.Isichazi se "next argument" sinokucingwa njenge-iterator ngaphezulu kwengxoxo.
//! Rhoqo xa kubonwa isikhombisi se "next argument", iterator iyaqhubela phambili.Oku kukhokelela ekuziphatheni ngolu hlobo:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! I-iterator yangaphakathi kwimpikiswano ayikhange ihambele phambili ngelixa i-`{}` yokuqala ibonwa, ke iprinta impikiswano yokuqala.Ke emva kokufikelela kwi-`{}` yesibini, i-iterator iqhubele phambili kwimpikiswano yesibini.
//! Ngokufanelekileyo, iiparameter ezibiza ngokucacileyo impikiswano yazo azichaphazeli iiparameter ezingakhankanyi mpikiswano ngokokucaciswa kwemeko ezithile.
//!
//! Umtya wefomathi uyafuneka ukusebenzisa zonke iimpikiswano, kungenjalo yimpazamo yexesha lokudityaniswa.Ungabhekisa kwimpikiswano enye ngaphezulu kwesinye kwifomathi yefomathi.
//!
//! ## Iiparameter ezinamagama
//!
//! I-Rust ngokwayo ayinayo i-Python-efana neeparameter ezinamagama ekusebenzeni, kodwa i-[`format!`] macro sisongezo se-syntax esivumela ukuba sisebenzise iiparameter ezinamagama.
//! Iiparameter ezinamagama zidwelisiwe ekupheleni koluhlu lwempikiswano kwaye ine-syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Umzekelo, la mabinzana alandelayo e [`format!`] onke asebenzise impikiswano enegama:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Akuvumelekile ukubeka iiparameter zendawo (ezo zingenamagama) emva kweempikiswano ezinamagama.Njengokuma kweparameter, akuvumelekanga ukubonelela ngeeparameter ezingasetyenziswanga ngumtya wefomathi.
//!
//! # Iifomathi zokufomatha
//!
//! Impikiswano nganye efomathiweyo inokuguqulwa ngenani leefomathi zokufomatha (ezingqinelana ne `format_spec` kwi [the syntax](#syntax)). Ezi paramitha zichaphazela ukumelwa komtya wento efomathiweyo.
//!
//! ## Width
//!
//! ```
//! // Zonke ezi shicilelo "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Le yiparameter ye "minimum width" ekufuneka ifomathiwe.
//! Ukuba umtya wexabiso awugcwalisi oonobumba abaninzi, ukuxhonywa okuchazwe ngu fill/alignment kuya kusetyenziselwa ukuthatha indawo efunekayo (jonga ngezantsi).
//!
//! Ixabiso lobubanzi linokubonelelwa njenge-[`usize`] kuluhlu lweeparameter ngokongeza i-postfix `$`, ebonisa ukuba impikiswano yesibini yi-[`usize`] echaza ububanzi.
//!
//! Ukubhekisa kwimpikiswano nedola syntax ayichaphazeli ikhawuntari ye-"next argument", ke ihlala iluvo olulungileyo ukubhekisa kwiimpikiswano ngesikhundla, okanye ukusebenzisa iimpikiswano ezinamagama.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Uhlobo lokuzalisa ngokuzikhethela kunye nolungelelwaniso lubonelelwa ngesiqhelo ngokudibeneyo ne [`width`](#width) ipharamitha.Kuya kufuneka ichazwe ngaphambi kwe `width`, kanye emva kwe `:`.
//! Oku kubonisa ukuba ixabiso elifomathiweyo lincinci kune-`width` abanye oonobumba abongezelelweyo baya kuprintwa ngeenxa zonke.
//! Ukuzaliswa kuza kwezi zinto zilandelayo kulungelelwaniso ezahlukeneyo:
//!
//! * `[fill]<` - impikiswano ilungelelaniswe ngasekhohlo kwiikholamu ze `width`
//! * `[fill]^` - impikiswano ilungelelaniswe phakathi kwiikholamu ze `width`
//! * `[fill]>` - impikiswano ilungelelaniswe ngokufanelekileyo kwiikholamu ze `width`
//!
//! I-[fill/alignment](#fillalignment) emiselweyo yee-non-numerics yindawo kwaye ilungelelaniswe ngasekhohlo.Ukungagqibeki kweefomathi zamanani kukwangumlinganiswa wendawo kodwa ngolungelelwaniso lwasekunene.
//! Ukuba iflegi ye `0` (jonga ngezantsi) icacisiwe kumanani, emva koko uphawu oluzalisiweyo ngu `0`.
//!
//! Qaphela ukuba ulungelelwaniso alunakuphunyezwa ziindidi ezithile.Ngokukodwa, ayenziwa ngokubanzi kwi `Debug` trait.
//! Indlela elungileyo yokuqinisekisa ukufakelwa padding kukufomatha ungeniso lwakho, emva koko ubeke umtya osisiphumo ekufumaneni iziphumo:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Molo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Zonke ezi ziiflegi ziguqula indlela yokuziphatha yefomathi.
//!
//! * `+` - Oku kwenzelwe iintlobo zamanani kwaye kubonisa ukuba uphawu kufuneka luhlale luprintwa.Iimpawu ezintle azikaze zishicilelwe ngokungagqibekanga, kwaye uphawu olubi lushicilelwa kuphela ngokungagqibekanga kwi `Signed` trait.
//! Le flegi ibonisa ukuba uphawu oluchanekileyo (i `+` okanye i `-`) kufuneka luhlale luprintwa.
//! * `-` - Okwangoku ayisetyenziswanga
//! * `#` - Le flegi ibonisa ukuba ifom ye "alternate" yokushicilela kufuneka isetyenziswe.Ezinye iifom zezi:
//!     * `#?` - phrinta kakuhle ifomathi ye [`Debug`]
//!     * `#x` - yandulela ingxabano nge `0x`
//!     * `#X` - yandulela ingxabano nge `0x`
//!     * `#b` - yandulela ingxabano nge `0b`
//!     * `#o` - yandulela ingxabano nge `0o`
//! * `0` - Oku kusetyenziselwa ukubonisa iifomathi ezipheleleyo ukuba ukupeyinta ukuya kwi-`width` kufanele ukuba kwenziwe ngohlobo lwe-`0` kunye nokwazi uphawu.
//! Ifomathi enje nge-`{:08}` iya kuvelisa i-`00000001` kwinani elipheleleyo le-`1`, ngelixa ifomathi efanayo iya kuvelisa i-`-0000001` kwinani elipheleleyo le-`-1`.
//! Qaphela ukuba uguqulelo olubi lune zero ezimbalwa kunohlobo oluqinisekileyo.
//!         Qaphela ukuba i-padding zeros zihlala zibekwa emva komqondiso (ukuba zikhona) naphambi kwamanani.Xa isetyenziswa kunye neflegi ye `#`, kusebenza umgaqo ofanayo: izero zokufaka zifakwa emva kwesimaphambili kodwa ngaphambi kwamanani.
//!         Isimaphambili sibandakanyiwe kububanzi bebonke.
//!
//! ## Precision
//!
//! Kwiindidi ezingezizo ezamanani, oku kunokuqwalaselwa njenge-"maximum width".
//! Ukuba umtya osisiphumo ungaphezulu kolu bubanzi, emva koko uncitshisiwe ukuya koonobumba abaninzi kwaye ixabiso elincitshisiweyo likhutshwa nge `fill` efanelekileyo, `alignment` kunye ne `width` ukuba ezo paramitha zisetiwe.
//!
//! Kwiindidi zokudibanisa, oku akuhoywa.
//!
//! Kwiintlobo zeendawo zokudada, oku kubonisa ukuba mangaphi amanani emva kwenqaku lokugqibela ekufuneka liprintiwe.
//!
//! Zintathu iindlela ezinokwenzeka zokuchaza i `precision` oyifunayo:
//!
//! 1. Inani elipheleleyo le `.N`:
//!
//!    amanani apheleleyo `N` ngokwawo achanekile.
//!
//! 2. Inani elipheleleyo okanye igama elilandelwa luphawu lwedola `.N$`:
//!
//!    Sebenzisa ifomathi *impikiswano*`N` (ekufuneka ibe iyi-`usize`) njengokuchaneka.
//!
//! 3. I-asterisk `.*`:
//!
//!    `.*` kuthetha ukuba le `{...}` inxulunyaniswa nokufakwa kwefomathi * ezimbini kunenye: igalelo lokuqala libambe ukuchaneka kwe `usize`, kwaye okwesibini kubambe ixabiso lokuprinta.
//!    Qaphela ukuba kule meko, ukuba umntu usebenzisa umtya wefomathi `{<arg>:<spec>.*}`, icandelo le `<arg>` libhekisa kwi* xabiso * lokuprinta, kwaye i `precision` kufuneka ize kwigalelo elandulela i `<arg>`.
//!
//! Umzekelo, oku kulandelayo kubiza konke ukuprinta into enye `Hello x is 0.01000`:
//!
//! ```
//! // Molo {arg 0 ("x")} ngu {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Molo {arg 1 ("x")} ngu {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Molo {arg 0 ("x")} ngu {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Molo {next arg ("x")} ngu {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Molo {next arg ("x")} ngu {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Molo {next arg ("x")} ngu {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Ngelixa oku:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! phrinta izinto ezintathu ezahlukeneyo:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Kwezinye iilwimi zokuprinta, indlela yokuziphatha kwemisebenzi yokufomatha umtya ixhomekeke kwinkqubo yokuseta yendawo yokusebenza.
//! Imisebenzi yefomathi ebonelelwe lilayibrari esemgangathweni ye-Rust ayinangqondo yendawo kwaye iya kuvelisa iziphumo ezifanayo kuzo zonke iinkqubo ngaphandle kokuqwalaselwa komsebenzisi.
//!
//! Umzekelo, le khowudi ilandelayo iya kuhlala iprinta i-`1.5` nokuba indawo yenkqubo isebenzisa umahluli wokugqibela ngaphandle kw ichaphaza.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Oonobumba bokwenyani i-`{` kunye ne-`}` banokubandakanywa kumtya ngokubandulela ngohlobo olufanayo.Umzekelo, umlinganiswa `{` ubalekile nge `{{` kunye nomlinganiswa u `}` ubalekile nge `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Ukushwankathela, apha unokufumana igrama epheleleyo yemitya yefomathi.
//! Isintaksi yolwimi lokufomatha olusetyenzisiweyo lutsalwe kwezinye iilwimi, ke akufuneki ukuba lubengaphandle kakhulu.Iingxoxo zifomathiwe nge-Python-efana nes syntax, okuthetha ukuba iimpikiswano zingqongwe yi `{}` endaweni ye-C-efana `%`.
//! Owona mgaqo-ntetho wefomathi yokufomatha yile:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Kule grama ingasentla, i-`text` ayinakuqulatha naziphi na i-`'{'` okanye i-`'}'`.
//!
//! # Ukufomatha i traits
//!
//! Xa ucela ukuba impikiswano ifomathiwe ngohlobo oluthile, ucela ukuba impikiswano ichaze i trait ethile.
//! Oku kuvumela iintlobo ezininzi zokwenyani ukuba zifomathiwe nge `{:x}` (njenge [`i8`] kunye ne [`isize`]).Imephu yangoku yeentlobo ukuya kwi-traits yile:
//!
//! * *akukho nto* 00 [`Display`]
//! * `?` [`Debug`]
//! * `x?` ⇒ [`Debug`] enamanani amancinanana apheleleyo enani elipheleleyo
//! * `X?` ⇒ [`Debug`] enamanani aphezulu koonobumba abali-hexadecimal
//! * `o` [`Octal`]
//! * `x` [`LowerHex`]
//! * `X` [`UpperHex`]
//! * `p` [`Pointer`]
//! * `b` [`Binary`]
//! * `e` [`LowerExp`]
//! * `E` [`UpperExp`]
//!
//! Oku kuthetha ntoni kukuba naluphi na uhlobo lwempikiswano olusebenzisa i [`fmt::Binary`][`Binary`] trait lunokufomathiwa nge `{:b}`.Ukuphunyezwa kubonelelwe kwezi traits ngenani leentlobo zamandulo kwilayibrari esemgangathweni ngokunjalo.
//!
//! Ukuba akukho fomathi ichaziweyo (njengakwi `{}` okanye kwi `{:6}`), emva koko ifomathi ye trait esetyenzisiweyo yi [`Display`] trait.
//!
//! Xa usenza ifomathi ye trait yohlobo lwakho, kuya kufuneka usebenzise indlela yokutyikitya:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // uhlobo lwethu lwesiko
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Uhlobo lwakho luya kugqitywa njenge-`self` ngereferensi, kwaye umsebenzi mawukhuphe kwimveliso ye-`f.buf`.Ixhomekeke kwifomathi nganye yokufezekiswa kwe-trait ukuhambelana ngokuchanekileyo neefomathi zokufomatha eziceliweyo.
//! Ixabiso lale paramitha liya kudweliswa kumacandelo e [`Formatter`].Ukunceda oku, i-[`Formatter`] struct ikwabonelela ngeendlela zoncedo.
//!
//! Ukongeza, ixabiso elibuyayo lalo msebenzi li-[`fmt::Result`] eluhlobo oluthile lwe-[`Result`]`<(),`[`std: : fmt::Error`] `>>.
//! Ukuphunyezwa kokufomatha kufuneka kuqinisekiswe ukuba basasaza iimpazamo kwi [`Formatter`] (umzekelo, xa ubiza i [`write!`]).
//! Nangona kunjalo, akufuneki baphinde babuyise iimpazamo ngokungakhathali.
//! Oko kukuthi, ukumiliselwa kokufomatha kufuneka kwaye kunokubuyisa impazamo kuphela xa kungeniswe kwi [`Formatter`] ibuyisa impazamo.
//! Kungenxa yokuba, ngokuchaseneyo nomsebenzi wesiginitsha onokuthi ucebise, ukufomatha umtya kukusebenza okungenakuphosisa.
//! Lo msebenzi ubuyisela kuphela iziphumo kuba ukubhala kumjelo ophantsi kunokungaphumeleli kwaye kufuneka kubonelele ngendlela yokuhambisa inyani yokuba kukho impazamo eyenzekileyo ukubuyisela isitaki.
//!
//! Umzekelo wokuphumeza ukufomatha i traits kuya kujongeka njengoku:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Ixabiso le `f` liphumeza i `Write` trait, yiyo le nto ubhalayo!Imacro ilindelwe.
//!         // Qaphela ukuba oku kufomatha kuyazityeshela iiflegi ezahlukeneyo ezinikezelweyo kwimitya yokufomatha.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // I-traits ezahlukeneyo zivumela iintlobo ezahlukeneyo zokukhutshwa kohlobo.
//! // Intsingiselo yale fomathi kukuprinta ubukhulu be-vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Hlonipha iifomathi zokufomatha ngokusebenzisa umncedisi indlela `pad_integral` kwinto yeFomathi.
//!         // Jonga uxwebhu lwendlela lweenkcukacha, kunye nomsebenzi `pad` ungasetyenziselwa ukwenza umtya.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Ezi fomathi zimbini ze traits zineenjongo ezahlukileyo:
//!
//! - [`fmt::Display`][`Display`] Ukuphunyezwa kubethelela ukuba uhlobo lunokumelwa ngokuthembekileyo njengomtya we UTF-8 ngawo onke amaxesha.Akulindelwe ** ukuba zonke iintlobo zisebenzise i [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] ukumiliselwa kufuneka kwenziwe kuzo zonke ** iintlobo zoluntu.
//!   Iziphumo ziya kuthi ngokwazo zimele imeko yangaphakathi ngokuthembeka ngangokunokwenzeka.
//!   Injongo ye [`Debug`] trait kukulungiselela ukulungisa ikhowudi ye Rust.Kwiimeko ezininzi, ukusebenzisa i `#[derive(Debug)]` kwanele kwaye kuyacetyiswa.
//!
//! Eminye imizekelo yemveliso evela kuzo zombini i traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # IiMacros ezinxulumene noko
//!
//! Kukho inani leemacros ezinxulumene nosapho lwe [`format!`].Ezi zisetyenziswayo ngoku zezi:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Oku kunye ne [`writeln!`] ziimacros ezimbini ezisetyenziselwa ukukhupha umtya wefomathi kumsinga ochaziweyo.Oku kusetyenziswa ukuthintela ulwabiwo oluphakathi lweentambo zeefomathi kwaye endaweni yoko kubhale ngokuthe ngqo iziphumo.
//! Ngaphantsi kwe-hood, lo msebenzi ngenene ubiza umsebenzi we-[`write_fmt`] ochazwe kwi-[`std::io::Write`] trait.
//! Ukusetyenziswa komzekelo ngu:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Oku kunye ne [`println!`] kukhupha imveliso yabo kwi stdout.Ngokufanayo kwi-[`write!`] macro, injongo yezi macros kukuthintela ulwabiwo oluphakathi xa uprinta imveliso.Ukusetyenziswa komzekelo ngu:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! I [`eprint!`] kunye ne [`eprintln!`] macros ziyafana kwi [`print!`] kunye ne [`println!`], ngokwahlukeneyo, ngaphandle kokuba zikhupha iziphumo zazo kwi stderr.
//!
//! ### `format_args!`
//!
//! Le yimacro enomdla esetyenziselwa ukudlula ngokukhuselekileyo kwindawo ejikeleze into echaza umtya wefomathi.Le nto ayifuni naluphi na ulwabiwo lwemfumba, kwaye ibhekisa kuphela kulwazi kwisitaki.
//! Ngaphantsi kwe-hood, zonke ii-macros ezinxulumene noko ziyenziwa ngokwale nto.
//! Okokuqala, umzekelo wokusetyenziswa ngu:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Iziphumo ze [`format_args!`] macro lixabiso lohlobo [`fmt::Arguments`].
//! Olu lwakhiwo lunokudluliselwa kwimisebenzi ye-[`write`] kunye ne-[`format`] ngaphakathi kule modyuli ukuze kuqhubekeke umtya wefomathi.
//! Injongo yale macro kukuthintela ulwabiwo oluphakathi xa ujongene nemitya yokufomatha.
//!
//! Umzekelo, ilayibrari yokungena inokusebenzisa ifomathi yokufomatha esemgangathweni, kodwa iya kugqitha ngaphakathi ngaphakathi kwesi sakhiwo de kube kumiselwe ukuba imveliso kufuneka iye phi.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Umsebenzi we `format` uthatha i [`Arguments`] kwaye ubuyisele umtya ofomathiweyo osiphumo.
///
///
/// Umzekelo we [`Arguments`] unokwenziwa nge-[`format_args!`] macro.
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Nceda uqaphele ukuba ukusebenzisa i [`format!`] kunokukhetha.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}