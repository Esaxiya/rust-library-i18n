use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Olunye ugcino lwe trait lwe Vec::from_iter oluyimfuneko ekubekeni phambili ngokubaluleka kokugqwesa okhethekileyo kubona i [`SpecFromIter`](super::SpecFromIter) ngeenkcukacha.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Bhalisa iteration yokuqala, njengoko i-vector izokwandiswa kule iteration kwimeko nganye xa i-iterable ingenanto, kodwa iluphu kwi-extend_desugared() ayizukubona i-vector igcwele kuthungelwano olulandelayo olulandelayo.
        //
        // Ke siba ngcono kuqikelelo lwe branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // Kufuneka udlulisele kwi-spec_extend() ukusukela nge-extend() ngokwabo abathunywa kwi-spec_from yee-Vec ezingenanto
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // Kufuneka udlulisele kwi-spec_extend() ukusukela nge-extend() ngokwabo abathunywa kwi-spec_from yee-Vec ezingenanto
        //
        vector.spec_extend(iterator);
        vector
    }
}