//! Uhlobo oluxhaphakileyo olunokukhula kunye nemixholo eyabelwe imfumba, ebhalwe i `Vec<T>`.
//!
//! I-Vectors ine-`O(1)` indexing, i-amortized `O(1)` Push (ukuya esiphelweni) kunye ne-`O(1)` pop (ukusuka esiphelweni).
//!
//!
//! I-Vectors iqinisekisa ukuba azange zabele ngaphezulu kwe-`isize::MAX` byte.
//!
//! # Examples
//!
//! Ungayenza ngokucacileyo i [`Vec`] nge [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... okanye ngokusebenzisa i [`vec!`] macro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // iiqanda ezilishumi
//! ```
//!
//! Unga [`push`] amaxabiso esiphelweni se-vector (eya kuthi ikhule i-vector njengoko kufuneka):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Ukuvela kwamaxabiso kusebenza ngendlela efanayo:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! I-Vectors ikwaxhasa isalathiso (nge [`Index`] kunye ne [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Uhlobo oluhluthayo olunokukhula, olubhalwe njenge-`Vec<T>` kunye ne-'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// I [`vec!`] macro ibonelelwe ukwenza ukuqala kube lula ngakumbi:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Inokuphinda iqalise into nganye ye `Vec<T>` ngexabiso elinikiweyo.
/// Oku kunokuba nokusebenza ngakumbi kunokwabiwa kunye nokuqaliswa kumanyathelo ahlukeneyo, ngakumbi xa kuqalwa i-vector ye-zeros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Oku kulandelayo kuyalingana, kodwa kunokuba kucothe:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Ngolwazi oluthe kratya, bona i [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Sebenzisa i `Vec<T>` njengestaki esisebenzayo:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Ushicilelo 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Uhlobo lwe `Vec` luvumela ukufikelela kumaxabiso ngesalathiso, kuba sisebenzisa i [`Index`] trait.Umzekelo uya kucaca ngakumbi:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // iya kubonisa i '2'
/// ```
///
/// Nangona kunjalo lumka: ukuba uzama ukufikelela kwisalathiso esingekho kwi `Vec`, isoftware yakho iya kuba panic!Awunakwenza oku:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Sebenzisa i [`get`] kunye ne [`get_mut`] ukuba ufuna ukukhangela ukuba isalathiso sikwi `Vec`.
///
/// # Slicing
///
/// I `Vec` inokutshintsha.Kwelinye icala, izilayi zizinto ezifundwayo kuphela.
/// Ukufumana i [slice][prim@slice], sebenzisa i [`&`].Umzekelo:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... kwaye kuphela!
/// // ungayenza ngoluhlobo:
/// let u: &[usize] = &v;
/// // okanye ngolu hlobo:
/// let u: &[_] = &v;
/// ```
///
/// Kwi-Rust, kuqhelekile ukugqithisa izilayi njengeempikiswano kunokuba i vectors xa ufuna ukubonelela ngokufikelela kufundo.Kuyafana ne [`String`] kunye ne [`&str`].
///
/// # Amandla kunye nolwabiwo ngokutsha
///
/// Umthamo we-vector sisixa sendawo esabelwe naziphi na izinto ze-future eziza kongezwa kwi-vector.Ayizukubhidaniswa nobude * be vector, echaza inani lezinto ezikhoyo ngaphakathi kwe vector.
/// Ukuba ubude be-vector budlula kumthamo, ubungakanani bayo buya kwandiswa ngokuzenzekelayo, kodwa izinto zayo kuya kufuneka zabiwe kwakhona.
///
/// Umzekelo, i-vector enomthamo we-10 kunye nobude be-0 iya kuba yi-vector engenanto kunye nesithuba sezinto ezili-10 ezingaphezulu.Ukutyhala izinto ezili-10 okanye ezimbalwa kwi vector akuyi kuwutshintsha amandla ayo okanye kubangele ukuba ukwabiwa kwakhona kwenzeke.
/// Nangona kunjalo, ukuba ubude be-vector bunyuswe baya kwi-11, kuya kufuneka iphinde iphinde iphinde iphinde iphinde iphinde icothe.Ngesi sizathu kuyacetyiswa ukuba kusetyenziswe i [`Vec::with_capacity`] xa kunokwenzeka ukucacisa ukuba ingakanani i vector ekulindeleke ukuba ifumane.
///
/// # Guarantees
///
/// Ngenxa yendalo yayo esisiseko, i `Vec` yenza iziqinisekiso ezininzi zoyilo lwayo.Oku kuqinisekisa ukuba iphantsi kwentloko kangangoko kunokwenzeka kwimeko ngokubanzi, kwaye inokusetyenziswa ngokuchanekileyo ngeendlela zokuqala ngekhowudi engakhuselekanga.Qaphela ukuba ezi ziqinisekiso zibhekisa kwi-`Vec<T>` engafanelekanga.
/// Ukuba ezinye iiparameter zongezwa (umz., Ukuxhasa ukwabiwa kwesiko), ngaphezulu kokungagqibeki kwabo kunokutshintsha isimilo.
///
/// Eyona nto isisiseko, i `Vec` kwaye iya kuhlala iyisikhombisi (isikhombisi, umthamo, ubude).Akusekho, akukho ngaphantsi.Uku-odolwa kwezi nkalo akuchazwanga ngokupheleleyo, kwaye kuya kufuneka usebenzise iindlela ezifanelekileyo ukuziguqula ezi.
/// Isikhombisi asisayi kuze sibe lilize, ke olu hlobo alunalusini.
///
/// Nangona kunjalo, isikhombisi asinakukhomba kwimemori eyabelweyo.
/// Ngokukodwa, ukuba wenza i `Vec` ngomthamo 0 nge [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], okanye ngokutsalela umnxeba u [`shrink_to_fit`] kwiVec engenanto, ayizukubeka memori.Ngokufanayo, ukuba ugcina iintlobo ezinobungakanani obungaphakathi kwe-`Vec`, ayizukubanika sithuba.
/// *Qaphela ukuba kule meko i `Vec` ayinakuxela i [`capacity`] ye-0*.
/// `Vec` iya kwabela ukuba kwaye kuphela ukuba [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Ngokubanzi, iinkcukacha zolwabiwo lwe-`Vec` zicace gca-ukuba unenjongo yokwaba inkumbulo usebenzisa i `Vec` kwaye uyisebenzisele enye into (nokuba kukudlula kwikhowudi engakhuselekanga, okanye ukwakha ingqokelela yakho exhaswa yimemori), qiniseka ukuhambisa le nkumbulo usebenzisa i `from_raw_parts` ukubuyisa i `Vec` emva koko uyiyeke.
///
/// Ukuba i `Vec`*ikhuphe* inkumbulo, imemori ekhomba kuyo ikwimfumba (njengoko kuchaziwe ngumnikezeli we Rust iqwalaselwe ukuba isetyenziswe ngokungagqibekanga), kunye nezikhombisi zayo kwi [`len`] eqalisiweyo, izinto ezinokulandelelana ngokulandelelana (into obuya kuyenza jonga ukuba uyinyanzelise kwisiqwengana), kulandele [`amandla`]`,`[`len`] ngokungachazwanga okungachazwanga, izinto ezinokuthanani.
///
///
/// I-vector enezinto ze-`'a'` kunye ne-`'b'` enomthamo wesi-4 inokuboniswa apha ngezantsi.Icandelo eliphezulu liyi-`Vec`, iqulethe isikhombisi kwintloko yolwabiwo kwimfumba, ubude kunye nomthamo.
/// Icandelo elingezantsi lolwabiwo kwimfumba, ibhloko yememori ehambelanayo.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** Imele inkumbulo engakhange iqaliswe, bona i [`MaybeUninit`].
/// - Note: iABI ayizinzanga kwaye i `Vec` ayenzi siqinisekiso malunga nobume bayo bememori (kubandakanya iodolo yamabala).
///
/// `Vec` Ayisoze yenze i "small optimization" apho izinto zigcinwa kwisitaki ngenxa yezizathu ezibini:
///
/// * Ingayenza ibe nzima ngakumbi ikhowudi engakhuselekanga ukusebenzisa ngokuchanekileyo i `Vec`.Imixholo ye `Vec` ayinakuba nedilesi ezinzileyo ukuba ibishukunyiswa kuphela, kwaye kuya kuba nzima ngakumbi ukufumanisa ukuba ngaba i `Vec` iyabelwe inkumbulo ngokwenene.
///
/// * Iya kohlwaya ityala ngokubanzi, ifake i-branch eyongezelelweyo kulo lonke ukufikelela.
///
/// `Vec` ayinakuze izinciphise ngokuzenzekelayo, nokuba ayinanto kwaphela.Oku kuqinisekisa ukuba akukho lwabiwo-mali okanye ukuhanjiswa kungadingeki.Ukuphelisa i-`Vec` kwaye uyigcwalise kwakhona kwi-[`len`] efanayo akufuneki ungene kumnikezeli.Ukuba unqwenela ukukhulula imemori engasetyenziswanga, sebenzisa i [`shrink_to_fit`] okanye i [`shrink_to`].
///
/// [`push`] kwaye i [`insert`] ayinakuze (re) yabele ukuba amandla axeliweyo anele.I-[`push`] kunye ne-[`insert`]*ziya*(re) zabela ukuba [`len`]``==` [`capacity`].Oko kukuthi, amandla axeliweyo achanekile ngokupheleleyo, kwaye kunokuthenjelwa kuwo.Ingasetyenziselwa ukukhulula imemori eyabelwe i `Vec` ukuba unqwenela njalo.
/// Iindlela zokufaka ngobuninzi * zinokuhambisa kwakhona indawo, nokuba akukho mfuneko.
///
/// `Vec` ayiqinisekisi nasiphi na isicwangciso-qhinga sokukhula xa usabiwa kwakhona ngokupheleleyo, okanye xa kubizwa i [`reserve`].Isicwangciso esikhoyo ngoku sisisiseko kwaye sinokubonisa ukuba sinqweneleka ukusebenzisa into engakhuliyo rhoqo.Nasiphi na isicwangciso esisetyenzisiweyo siya kuthi ngokuqinisekileyo siqinisekise *O*(1) i-[`push`] yeamortised.
///
/// `vec![x; n]`, I-`vec![a, b, c, d]`, kunye ne-[`Vec::with_capacity(n)`][`Vec::with_capacity`], zonke ziya kuvelisa i-`Vec` kunye nomthamo ofunwayo kanye.
/// Ukuba [`len`]`==`[`umthamo`], (njengoko kunjalo nge-[`vec!`] macro), emva koko i `Vec<T>` inokuguqulwa iye kwi-[`Box<[T]>`][owned slice] ngaphandle kokuphinda uhambise okanye uhambise izinto.
///
/// `Vec` ngekhe ibhale ngaphezulu kwayo nayiphi na idatha esuswe kuyo, kodwa ayizukuyigcina ngokuthe ngqo.Imemori yayo engagqitywanga yindawo yokukhangela enokuthi isebenzise nangona ifuna.Ngokwesiqhelo iya kwenza nantoni na efanelekileyo okanye kungenjalo kube lula ukuyiphumeza.Sukuxhomekeka kwidatha esusiweyo ukuba icinywe ngeenjongo zokhuseleko.
/// Nokuba ulahla i-`Vec`, i-buffer yayo inokuphinda isetyenziswe kwakhona yenye i-`Vec`.
/// Nokuba awuzukukhumbula inkumbulo ka-Vec kuqala, oko ngekhe kwenzeke kuba isilungisi asiyithathi njengempembelelo esecaleni ekufuneka igcinwe.
/// Kukho imeko enye esingayi kuyaphula, nangona kunjalo: ukusebenzisa ikhowudi ye-`unsafe` ukubhala kumthamo ogqithisileyo, kwaye sandise ubude bokutshatisa, kuhlala kusebenza.
///
/// Okwangoku, i `Vec` ayiqinisekisi ngokulandelelana kwezinto ezilahliweyo.
/// I-odolo itshintshile kwixa elidlulileyo kwaye isenokutshintsha kwakhona.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Iindlela zendalo
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Yakha i-`Vec<T>` entsha, engenanto.
    ///
    /// I-vector ayizukunikezela kude kube izinto zityhalelwe kuyo.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Yakha i-`Vec<T>` entsha, engenanto ngomthamo ochaziweyo.
    ///
    /// I-vector iya kuba nakho ukubamba ngokuchanekileyo izinto ze-`capacity` ngaphandle kokuhambisa kwakhona.
    /// Ukuba i `capacity` ingu-0, i vector ayizokwaba.
    ///
    /// Kubalulekile ukuba uqaphele ukuba nangona i-vector ebuyisiweyo ine-*umthamo* ochaziweyo, i-vector iya kuba ne-zero *ubude*.
    ///
    /// Ukufumana inkcazo ngomahluko phakathi kobude namandla, jonga * [Amandla kunye nokwabiwa kwakhona].
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // I-vector ayiqulathanga zinto, nangona inezinto ezingaphezulu
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Zonke ezi zinto zenziwa ngaphandle kokunikezelwa kwakhona ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... kodwa oku kungenza ukuba i-vector iphinde ibuye
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Yenza i `Vec<T>` ngokuthe ngqo kumacandelo aluhlaza enye i vector.
    ///
    /// # Safety
    ///
    /// Oku akukhuselekanga kakhulu, ngenxa yenani labahlaseli abangakhange bajongwe:
    ///
    /// * `ptr` Ifuneka ukuba ibikade yabiwa nge-[`String`]/` Vec<T>(ubuncinci, kunokwenzeka ukuba ayichanekanga ukuba bekungekho).
    /// * `T` kufuneka ibenobungakanani obulinganayo kunye nolungelelwaniso njengoko i `ptr` yabelwe yona.
    ///   (I-`T` enolungelelwaniso olungqongqo ayonelanga, ulungelelwaniso ngenene kufuneka lilingane ukwanelisa imfuno ye [`dealloc`] yokuba inkumbulo kufuneka yabelwe kwaye idluliselwe ngolwakhiwo olufanayo.)
    ///
    /// * `length` Ifuna ukuba ngaphantsi okanye ilingane ne `capacity`.
    /// * `capacity` Kufuneka ibe sisikhundla esabiweyo nesikhombisi.
    ///
    /// Ukophula oku kunokubangela iingxaki njengokumosha ukwabiwa kwedatha yangaphakathi yomnikezeli.Umzekelo ayi ** ayikhuselekanga ukwakha i `Vec<u8>` ukusuka kwisikhombisi ukuya kuluhlu lwe-X `char` ngobude `size_t`.
    /// Akukhuselekanga ukwakha enye ukusuka kwi-`Vec<u16>` kunye nobude bayo, kuba isabelo sikhathalele ulungelelwaniso, kwaye ezi ntlobo zimbini zinolungelelwaniso olwahlukileyo.
    /// I-buffer yabiwa ngolungelelwaniso 2 (lwe-`u16`), kodwa emva kokuyiguqula ibe yi-`Vec<u8>` iya kuhanjiswa ngolungelelwaniso 1.
    ///
    /// Ubunini be `ptr` bugqithiselwe ngokufanelekileyo kwi `Vec<T>` enokuthi emva koko ihlangane, iphinde ibeke kwakhona okanye itshintshe imixholo yememori ekhonjwe sisikhombisi ngentando.
    /// Qinisekisa ukuba akukho enye into esebenzisa isikhombisi emva kokubiza lo msebenzi.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Hlaziya oku xa i-vec_into_raw_parts izinzisiwe.
    ///     // Thintela ukusebenza komtshabalalisi ngoko silawula ngokupheleleyo ulwabiwo.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Khupha iziqwenga ezahlukeneyo zolwazi malunga ne `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Bhala imemori nge-4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Beka yonke into kwakhona kwi-Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Yakha i-`Vec<T, A>` entsha, engenanto.
    ///
    /// I-vector ayizukunikezela kude kube izinto zityhalelwe kuyo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Yakha i-`Vec<T, A>` entsha, engenanto kunye nomthamo ochaziweyo kunye nomnikezeli obonelelweyo.
    ///
    /// I-vector iya kuba nakho ukubamba ngokuchanekileyo izinto ze-`capacity` ngaphandle kokuhambisa kwakhona.
    /// Ukuba i `capacity` ingu-0, i vector ayizokwaba.
    ///
    /// Kubalulekile ukuba uqaphele ukuba nangona i-vector ebuyisiweyo ine-*umthamo* ochaziweyo, i-vector iya kuba ne-zero *ubude*.
    ///
    /// Ukufumana inkcazo ngomahluko phakathi kobude namandla, jonga * [Amandla kunye nokwabiwa kwakhona].
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // I-vector ayiqulathanga zinto, nangona inezinto ezingaphezulu
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Zonke ezi zinto zenziwa ngaphandle kokunikezelwa kwakhona ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... kodwa oku kungenza ukuba i-vector iphinde ibuye
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Yenza i `Vec<T, A>` ngokuthe ngqo kumacandelo aluhlaza enye i vector.
    ///
    /// # Safety
    ///
    /// Oku akukhuselekanga kakhulu, ngenxa yenani labahlaseli abangakhange bajongwe:
    ///
    /// * `ptr` Ifuneka ukuba ibikade yabiwa nge-[`String`]/` Vec<T>(ubuncinci, kunokwenzeka ukuba ayichanekanga ukuba bekungekho).
    /// * `T` kufuneka ibenobungakanani obulinganayo kunye nolungelelwaniso njengoko i `ptr` yabelwe yona.
    ///   (I-`T` enolungelelwaniso olungqongqo ayonelanga, ulungelelwaniso ngenene kufuneka lilingane ukwanelisa imfuno ye [`dealloc`] yokuba inkumbulo kufuneka yabelwe kwaye idluliselwe ngolwakhiwo olufanayo.)
    ///
    /// * `length` Ifuna ukuba ngaphantsi okanye ilingane ne `capacity`.
    /// * `capacity` Kufuneka ibe sisikhundla esabiweyo nesikhombisi.
    ///
    /// Ukophula oku kunokubangela iingxaki njengokumosha ukwabiwa kwedatha yangaphakathi yomnikezeli.Umzekelo ayi ** ayikhuselekanga ukwakha i `Vec<u8>` ukusuka kwisikhombisi ukuya kuluhlu lwe-X `char` ngobude `size_t`.
    /// Akukhuselekanga ukwakha enye ukusuka kwi-`Vec<u16>` kunye nobude bayo, kuba isabelo sikhathalele ulungelelwaniso, kwaye ezi ntlobo zimbini zinolungelelwaniso olwahlukileyo.
    /// I-buffer yabiwa ngolungelelwaniso 2 (lwe-`u16`), kodwa emva kokuyiguqula ibe yi-`Vec<u8>` iya kuhanjiswa ngolungelelwaniso 1.
    ///
    /// Ubunini be `ptr` bugqithiselwe ngokufanelekileyo kwi `Vec<T>` enokuthi emva koko ihlangane, iphinde ibeke kwakhona okanye itshintshe imixholo yememori ekhonjwe sisikhombisi ngentando.
    /// Qinisekisa ukuba akukho enye into esebenzisa isikhombisi emva kokubiza lo msebenzi.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Hlaziya oku xa i-vec_into_raw_parts izinzisiwe.
    ///     // Thintela ukusebenza komtshabalalisi ngoko silawula ngokupheleleyo ulwabiwo.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Khupha iziqwenga ezahlukeneyo zolwazi malunga ne `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Bhala imemori nge-4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Beka yonke into kwakhona kwi-Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Iqokelela i `Vec<T>` kwizinto zayo eziluhlaza.
    ///
    /// Ibuyisela isikhombisi esiluhlaza kwidatha engaphantsi, ubude be vector (kwizinto), kunye nomthamo owabelweyo wedatha (kwizinto).
    /// Ezi ziimpikiswano ezifanayo ngokulandelelana njengeempikiswano eziya kwi [`from_raw_parts`].
    ///
    /// Emva kokubiza lo msebenzi, lowo ufowunayo unoxanduva kwimemori eyayilawulwa ngaphambili yi `Vec`.
    /// Olona hlobo kuphela lokwenza oku kukuguqula isalathi esingavuthiweyo, ubude, kunye nomthamo ubuyisele kwi `Vec` ngomsebenzi we [`from_raw_parts`], uvumela umonakalisi ukuba enze ucoceko.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Ngoku sinokwenza utshintsho kumacandelo, njengokuhambisa isalathi eluhlaza kuhlobo oluhambelanayo.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Iqokelela i `Vec<T>` kwizinto zayo eziluhlaza.
    ///
    /// Ibuyisela isikhombisi esiluhlaza kwidatha engaphantsi, ubude be-vector (kwizinto), umthamo owabelweyo wedatha (kwizinto), kunye nomnikezeli.
    /// Ezi ziimpikiswano ezifanayo ngokulandelelana njengeempikiswano eziya kwi [`from_raw_parts_in`].
    ///
    /// Emva kokubiza lo msebenzi, lowo ufowunayo unoxanduva kwimemori eyayilawulwa ngaphambili yi `Vec`.
    /// Olona hlobo kuphela lokwenza oku kukuguqula isalathi esingavuthiweyo, ubude, kunye nomthamo ubuyisele kwi `Vec` ngomsebenzi we [`from_raw_parts_in`], uvumela umonakalisi ukuba enze ucoceko.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Ngoku sinokwenza utshintsho kumacandelo, njengokuhambisa isalathi eluhlaza kuhlobo oluhambelanayo.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Ibuyisa inani lezinto ezinokubanjwa yi vector ngaphandle kokuphinda ungene kwakhona.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Ogcina amandla ubuncinci i-`additional` yezinto ezingaphezulu eziza kufakwa kwi-`Vec<T>` enikiweyo.
    /// Ingqokelela inokugcina indawo ngakumbi ukunqanda ulwabiwo rhoqo.
    /// Emva kokubiza i `reserve`, umthamo uya kuba mkhulu okanye ulingane no `self.len() + additional`.
    /// Ngaba akukho nto ukuba amandla sele onele.
    ///
    /// # Panics
    ///
    /// Panics ukuba amandla amatsha angaphaya kwe-`isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Kugcinwa ubuncinci bomthamo we-`additional` ngakumbi izinto eziza kufakwa kwi-`Vec<T>` enikiweyo.
    ///
    /// Emva kokubiza i `reserve_exact`, umthamo uya kuba mkhulu okanye ulingane no `self.len() + additional`.
    /// Ayenzi nto ukuba umthamo sele uwanele.
    ///
    /// Qaphela ukuba umthengisi unokunika ingqokelela indawo engaphezulu kunaleyo ayifunayo.
    /// Ke ngoko, umthamo awunakuthenjwa ekubeni ubuncinci ngokuchanekileyo.
    /// Khetha i `reserve` ukuba kulindelwe ukufakwa kwe future.
    ///
    /// # Panics
    ///
    /// Panics ukuba umthamo omtsha uphuphuma kwi `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Izama ukugcina amandla ubuncinci be-`additional` ngaphezulu kwezinto eziza kufakwa kwi-`Vec<T>` enikiweyo.
    /// Ingqokelela inokugcina indawo ngakumbi ukunqanda ulwabiwo rhoqo.
    /// Emva kokubiza i `try_reserve`, umthamo uya kuba mkhulu okanye ulingane no `self.len() + additional`.
    /// Ngaba akukho nto ukuba amandla sele onele.
    ///
    /// # Errors
    ///
    /// Ukuba umthamo uyaphuphuma, okanye ulwabiwo uxela ukusilela, emva koko impazamo iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Gcina imemori kwangaphambili, uphume ukuba asikwazi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ngoku siyazi ukuba le ayikwazi i-OOM embindini womsebenzi wethu onzima
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // inzima kakhulu
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Izama ukugcina ubuncinci bobungakanani bezinto ze `additional` eziza kufakwa kwi `Vec<T>` enikiweyo.
    /// Emva kokubiza i-`try_reserve_exact`, umthamo uya kuba mkhulu okanye ulingane no-`self.len() + additional` ukuba ubuyisa i-`Ok(())`.
    ///
    /// Ayenzi nto ukuba umthamo sele uwanele.
    ///
    /// Qaphela ukuba umthengisi unokunika ingqokelela indawo engaphezulu kunaleyo ayifunayo.
    /// Ke ngoko, umthamo awunakuthenjwa ekubeni ubuncinci ngokuchanekileyo.
    /// Khetha i `reserve` ukuba kulindelwe ukufakwa kwe future.
    ///
    /// # Errors
    ///
    /// Ukuba umthamo uyaphuphuma, okanye ulwabiwo uxela ukusilela, emva koko impazamo iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Gcina imemori kwangaphambili, uphume ukuba asikwazi
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Ngoku siyazi ukuba le ayikwazi i-OOM embindini womsebenzi wethu onzima
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // inzima kakhulu
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Shwabanisa ubungakanani be vector kangangoko kunokwenzeka.
    ///
    /// Izakuhla ezantsi kufutshane kangangoko kubude kodwa isabelo sinokwazisa i vector ukuba kukho indawo yezinto ezimbalwa ezingaphezulu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Ubungakanani abusoze bube ngaphantsi kobude, kwaye akukho nto yokwenza xa belingana, ke sinokuphepha imeko ye-panic kwi `RawVec::shrink_to_fit` ngokuyibiza ngomthamo omkhulu.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Shwabanisa ubungakanani be vector ngentambo esezantsi.
    ///
    /// Umthamo uya kuhlala ubuncinci ubuncinci njengobude kunye nexabiso elibonelelweyo.
    ///
    ///
    /// Ukuba umthamo wangoku ungaphantsi komda ongezantsi, le yi-no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Guqula i-vector kwi-[`Box<[T]>`][owned slice].
    ///
    /// Qaphela ukuba oku kuya kulahla nawuphi na umthamo ogqithisileyo.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Nawuphi na umthamo ogqithisileyo uyasuswa:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Imfutshane kwi-vector, igcina izinto zokuqala ze-`len` kwaye ilahle ezinye.
    ///
    /// Ukuba i `len` ingaphezulu kobude be vector yangoku, oku akunampembelelo.
    ///
    /// Indlela ye [`drain`] inokulinganisa i `truncate`, kodwa ibangela ukuba izinto ezigqithisileyo zibuyiselwe endaweni yokuba ziyekwe.
    ///
    ///
    /// Qaphela ukuba le ndlela ayinasiphumo kubungakanani obabelwe i vector.
    ///
    /// # Examples
    ///
    /// Ukuncipha into ezintlanu vector kwizinto ezimbini:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Akukho kuncitshiswa kwenzeka xa i `len` ingaphezulu kobude be vector yangoku:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Ukurhola xa i `len == 0` ilingana nokubiza indlela ye [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Oku kukhuselekile kuba:
        //
        // * Isilayidi esidluliselwe kwi-`drop_in_place` sisebenza;Ityala le `len > self.len` liphepha ukwenza isilayidi esingavumelekanga, kunye
        // * i `len` ye-vector iyancipha ngaphambi kokubiza i-`drop_in_place`, ukuze kungabikho xabiso liza kulahlwa kabini xa i-`drop_in_place` ibiyi-panic kube kanye (ukuba yi-panics kabini, inkqubo iyaphuma).
        //
        //
        //
        unsafe {
            // Note: Kuyinjongo ukuba le yi `>` hayi i `>=`.
            //       Ukuyitshintsha ibe yi-`>=` kunefuthe lokungasebenzi kakuhle kwezinye iimeko.
            //       Bona i #78884 ngaphezulu.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Ikhupha isilayidi esine-vector iphela.
    ///
    /// Ilingana ne `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Ikhupha isilayidi esiguquguqukayo sayo yonke i vector.
    ///
    /// Ilingana ne `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Ibuyisa isikhombisi esiluhlaza kwisikhuseli se vector.
    ///
    /// Umntu ofowunayo kufuneka aqinisekise ukuba i-vector iphila ngesikhombisi kulo msebenzi ubuyayo, kungenjalo iya kugqibela ngokukhomba inkunkuma.
    /// Ukuguqula i-vector kunokubangela ukuba i-buffer yayo iphinde yabekwa kwakhona, enokuthi yenze naziphi na izikhombisi kuyo zingasebenzi.
    ///
    /// Umntu ofowunayo kufuneka aqinisekise ukuba inqaku lesalathiso i-(non-transitively) yalatha kuyo ayibhalelwanga (ngaphandle ngaphakathi kwe-`UnsafeCell`) usebenzisa esi sikhombisi okanye nasiphi na isikhombisi esivela kuso.
    /// Ukuba ufuna ukutshintsha imixholo yesilayidi, sebenzisa i [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Sifihla indlela yesilayidi esinegama elifanayo ukunqanda ukudlula kwi `deref`, eyenza ireferensi ephakathi.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Ibuyisa isikhombisi esingakhuselekanga esinokutshintsha kwisikhuseli se vector.
    ///
    /// Umntu ofowunayo kufuneka aqinisekise ukuba i-vector iphila ngesikhombisi kulo msebenzi ubuyayo, kungenjalo iya kugqibela ngokukhomba inkunkuma.
    ///
    /// Ukuguqula i-vector kunokubangela ukuba i-buffer yayo iphinde yabekwa kwakhona, enokuthi yenze naziphi na izikhombisi kuyo zingasebenzi.
    ///
    /// # Examples
    ///
    /// ```
    /// // Nikezela i-vector enkulu ngokwaneleyo kwizinto ezi-4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Qalisa izinto nge-pointer eluhlaza ubhala, emva koko usete ubude.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Sifihla indlela yesilayidi esinegama elifanayo ukunqanda ukudlula kwi `deref_mut`, eyenza ireferensi ephakathi.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Ibuyisela ireferensi kulwabiwo olusisiseko.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Ukunyanzela ubude be vector ukuya kwi `new_len`.
    ///
    /// Lo ngumsebenzi okwinqanaba elisezantsi ongagcini namnye kwabahlaseli abaqhelekileyo bohlobo.
    /// Ngokwesiqhelo ukutshintsha ubude be-vector kwenziwa kusetyenziswa enye yezinto ezikhuselekileyo endaweni yoko, ezinje nge [`truncate`], [`resize`], [`extend`], okanye [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` kufuneka ibe ngaphantsi okanye ilingane ne [`capacity()`].
    /// - Izinto ezikwi `old_len..new_len` kufuneka ziqaliswe.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Le ndlela inokuba luncedo kwiimeko apho i vector isebenza njenge-buffer yenye ikhowudi, ngakumbi ngaphezulu kwe-FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Esi skeleton esincinci kumzekelo we-doc;
    /// # // Sukuyisebenzisa njengesiqalo selayibrari yokwenyani.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Ngamaxwebhu endlela ye-FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // UKHUSELEKO: Xa i `deflateGetDictionary` ibuyisa i `Z_OK`, ibamba ukuba:
    ///     // 1. `dict_length` Izinto zaqaliswa.
    ///     // 2.
    ///     // `dict_length` <=umthamo (32_768) owenza ukuba i `set_len` ikhuseleke ukubiza.
    ///     unsafe {
    ///         // Yenza umnxeba we-FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... kwaye uhlaziye ubude kwinto eyaqaliswayo.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Ngelixa lo mzekelo ulandelayo usisandi, kukho ukuvuza kwenkumbulo okoko i-vectors yangaphakathi yayingakhululwanga ngaphambi komnxeba we `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ayinanto ngoko akukho zinto kufuneka zenziwe.
    /// // 2. `0 <= capacity` ihlala ibambe nantoni na eyi `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Ngokwesiqhelo, apha, umntu uya kusebenzisa i [`clear`] endaweni yokulahla ngokuchanekileyo imixholo kwaye kungavuzi imemori.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Isusa into kwi-vector kwaye iyibuyisele.
    ///
    /// Into esusiweyo ithathelwe indawo yinto yokugqibela ye vector.
    ///
    /// Oku akugcini uku-odola, kodwa yi-O(1).
    ///
    /// # Panics
    ///
    /// Panics ukuba i `index` ingaphandle kwemida.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Sitshintsha isiqu sakho [isalathiso] ngento yokugqibela.
            // Qaphela ukuba ukuba umda ujonge ngaphezulu uyaphumelela kufuneka kubekhona into yokugqibela (enokuthi izenzele yona [isalathiso] uqobo).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Ukufaka into kwindawo ye `index` ngaphakathi kwe vector, ukuhambisa zonke izinto emva kwayo ukuya ngasekunene.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // indawo yento entsha
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // Ayinakuphosakala Indawo yokubeka ixabiso elitsha
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Shift yonke into yenze indawo.
                // (Ukuphinda into ye-index`th kwiindawo ezimbini ezilandelelanayo.)
                ptr::copy(p, p.offset(1), len - index);
                // Yibhale, ubhale ngaphezulu ikopi yokuqala yento ye-index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Isusa kwaye ibuyisele into kwindawo eyi-`index` ngaphakathi kwe-vector, ishenxise zonke izinto emva kwayo ziye ekhohlo.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `index` ingaphandle kwemida.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // indawo esithatha kuyo.
                let ptr = self.as_mut_ptr().add(index);
                // ikope ngaphandle, ngokungakhuselekanga ube nekopi yexabiso kwisitaki nakwi vector ngaxeshanye.
                //
                ret = ptr::read(ptr);

                // Shift yonke into ezantsi ukuze ugcwalise loo ndawo.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Igcina kuphela izinto ezichazwe kwisivisa.
    ///
    /// Ngamanye amagama, susa zonke izinto `e` kangangokuba i `f(&e)` ibuyise i `false`.
    /// Le ndlela isebenza endaweni, undwendwela into nganye kanye kanye kulungelelwaniso lwantlandlolo, kwaye igcina ucwangco lwezinto ezigciniweyo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Ngenxa yokuba izinto zindwendwelwe kanye kube kanye kulungelelwaniso lwantlandlolo, imeko yangaphandle inokusetyenziselwa ukuthatha isigqibo sokuba zeziphi izinto ekufuneka zigcinwe.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Thintela ukuwa kabini ukuba i-drop guard ayenziwa, kuba sinokwenza imingxunya ngexesha lenkqubo.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-kusetyenzwe len-> |^-ukulandelayo ukujonga
        //                  | <-icinyiwe cnt-> |
        //      | <-yoqobo_len-> |Ukugcinwa: Izinto ezibonisa kwangaphambili ukuba ziyabuya ziyinyani.
        //
        // Umngxunya: Ishukunyisiwe okanye yehlisiwe into yokubekwa
        // Akukhange kuhlolwe: Izinto ezingakhange ziqwalaselwe ezisemthethweni.
        //
        // Lo mlindi wokulahla uya kubizwa xa isimaphambili okanye i `drop` yento yothukile.
        // Ishenxisa izinto ezingakhange ziqwalaselwe ukugubungela imingxunya kunye ne `set_len` kubude obuchanekileyo.
        // Kwiimeko xa isindululo kunye ne `drop` zingoyiki, iya kuphuculwa.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // UKHUSELEKO: Ukulandela umkhondo kwezinto ezingakhange zihlolwe kufuneka kusebenze kuba asikaze siziphathe.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // UKHUSELEKO: Emva kokugcwalisa imingxunya, zonke izinto zikwimemori yokuhlangana.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // UKHUSELEKO: Into engakhange ihlolwe kufuneka isebenze.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Phambi kwangethuba ukuthintela ukuhla kabini ukuba i `drop_in_place` yothukile.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // UKHUSELEKO: Asinakuphinda siyichukumise le nto emva kokuwa.
                unsafe { ptr::drop_in_place(cur) };
                // Sele siqhubele phambili kwikhawuntara.
                continue;
            }
            if g.deleted_cnt > 0 {
                // UKHUSELEKO: `deleted_cnt`> 0, Ke umngxunya womngxunya akufuneki udibane nezinto ezikhoyo.
                // Sisebenzisa ikopi ukuhamba, kwaye ungaze uphinde uyichukumise le nto kwakhona.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Yonke into iyenziwa.Oku kunokuba kulungiselelwe kwi `set_len` yi-LLVM.
        drop(g);
    }

    /// Isusa konke ngaphandle kokuqala kokulandelelana kwezinto kwi-vector ezisombulula kwisitshixo esinye.
    ///
    ///
    /// Ukuba i-vector ihleliwe, oku kususa zonke izinto eziphindiweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Isusa konke kodwa eyokuqala yezinto ezilandelelanayo kwi-vector eyanelisa ulwalamano olunikiweyo.
    ///
    /// Umsebenzi we `same_bucket` udlulise izingqinisiso kwizinto ezimbini ezivela kwi-vector kwaye kufuneka uchonge ukuba ngaba izinto zithelekisa ngokulinganayo.
    /// Izinto zidluliswa ngokulandelelana ngokuchaseneyo ngokulandelelana kwazo kwisilayidi, ke ukuba i `same_bucket(a, b)` ibuyisa i `true`, i `a` iyasuswa.
    ///
    ///
    /// Ukuba i-vector ihleliwe, oku kususa zonke izinto eziphindiweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Faka into ngasemva kwengqokelela.
    ///
    /// # Panics
    ///
    /// Panics ukuba amandla amatsha angaphaya kwe-`isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Oku kuyakuba yi-panic okanye sikhuphe isisu ukuba siza kwabela ii-isize::MAX byte okanye ukuba ubude bobude buya kuphuphuma kwiindidi ezinobungakanani be-zero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Isusa into yokugqibela kwi-vector kwaye iyibuyise, okanye i-[`None`] ukuba ayinanto.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Ihambisa onke amanqaku e-`other` ukuya kwi-`Self`, ishiya i-`other` ingenanto.
    ///
    /// # Panics
    ///
    /// Panics ukuba inani lezinto kwi-vector liphuphuma i `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Faka isicelo sezinto kwi `Self` kwezinye izinto.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Yenza i-iterator yokutsala esusa uluhlu oluchaziweyo kwi-vector kwaye ivelise izinto ezisusiweyo.
    ///
    /// Xa iterator ** yehlisiwe, zonke izinto ezikoluhlu zisuswe kwi-vector, nokuba ngaba iterator khange isetyenziswe ngokupheleleyo.
    /// Ukuba i-iterator **ayi** yehlisiwe (kunye ne-[`mem::forget`] umzekelo), ayichazwanga ukuba zingaphi izinto ezisusiweyo.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba indawo yokuqala inkulu kunendawo yokuphela okanye ukuba indawo yokuphela inkulu kunobude be vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Uluhlu olupheleleyo luyayicoca i vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Ukhuseleko lwenkumbulo
        //
        // Xa i-Drain iqala ukwenziwa, iyabufutshane ubude bomthombo u vector ukuqinisekisa ukuba akukho zinto zingaqaliswanga okanye ezisuswayo-ziyafikeleleka konke konke ukuba umbhuqi we Drain akaze asebenze.
        //
        //
        // I-Drain iya kuthi ptr::read ikhuphe amaxabiso okususa.
        // Xa ugqibile, umsila oshiyekileyo wevec ukhutshelwa umva ukugubungela umngxunya, kwaye ubude be vector bubuyiselwe kubude obutsha.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // setha ubude be self.vec ukuqala, ukuze ukhuseleke kwimeko ye Drain
            self.set_len(start);
            // Sebenzisa okubolekwe kwi-IterMut ukubonisa indlela obolekayo ngayo yonke iterator ye Drain (njenge &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Icoca i-vector, isuse onke amaxabiso.
    ///
    /// Qaphela ukuba le ndlela ayinasiphumo kubungakanani obabelwe i vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Ibuyisa inani lezinto kwi vector, ekwabizwa ngokuba yi 'length' yayo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Ibuyisa i `true` ukuba i vector ayinazinto.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ukwahlula ingqokelela kubini kwisalathiso esinikiweyo.
    ///
    /// Ibuyisa i-vector esandula ukwabiwa enezinto ezikuluhlu lwe `[at, len)`.
    /// Emva komnxeba, i-vector yoqobo iya kushiyeka iqulethe izinto `[0, at)` kunye namandla ayo angatshintshanga.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // i-vector entsha inokuthatha i-buffer yoqobo kwaye iphephe ikopi
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // I-`set_len` engakhuselekanga kwaye ukope izinto kwi `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Yenza ubungakanani kwakhona be `Vec` endaweni ukuze i `len` ilingane ne `new_len`.
    ///
    /// Ukuba i-`new_len` ingaphezulu kwe-`len`, i-`Vec` yandiswa ngumahluko, indawo nganye eyongeziweyo ezaliswe ziziphumo zokubiza ukuvalwa kwe `f`.
    ///
    /// Ixabiso lokubuya kwi `f` liyakuphelela kwi `Vec` ngokulandelelana kwayo.
    ///
    /// Ukuba i `new_len` ingaphantsi kwe `len`, i `Vec` incitshisiwe.
    ///
    /// Le ndlela isebenzisa ukuvala ukwenza amaxabiso amatsha kuko konke ukutyhala.Ukuba ukhetha i [`Clone`] ngexabiso elinikiweyo, sebenzisa i [`Vec::resize`].
    /// Ukuba ufuna ukusebenzisa i [`Default`] trait ukwenza amaxabiso, ungapasa i [`Default::default`] njengengxoxo yesibini.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Isebenzisa kwaye ivuze i `Vec`, ibuyise ireferensi enokuguquguquka kwimixholo, `&'a mut [T]`.
    /// Qaphela ukuba uhlobo `T` kufuneka luphile ixesha lokuphila elikhethiweyo i `'a`.
    /// Ukuba udidi luneembekiselo ezimileyo kuphela, okanye akukho nanye, kunokukhethwa ukuba kube yi `'static`.
    ///
    /// Lo msebenzi uyafana nomsebenzi we [`leak`][Box::leak] kwi [`Box`] ngaphandle kokuba akukho ndlela yokubuyisa imemori evuzayo.
    ///
    ///
    /// Lo msebenzi uluncedo ikakhulu kwidatha ephilayo kwintsalela yobomi benkqubo.
    /// Ukulahla ireferensi ebuyisiweyo kuya kubangela ukuvuza kwenkumbulo.
    ///
    /// # Examples
    ///
    /// Ukusetyenziswa ngokulula:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Ibuyisa ubungakanani obushiyekileyo be vector njengesilayi se `MaybeUninit<T>`.
    ///
    /// Isilayidi esibuyiselweyo sinokusetyenziselwa ukugcwalisa i vector ngedatha (umz
    /// ngokufunda kwifayile) ngaphambi kokumakisha idatha njengoko iqalisiwe kusetyenziswa indlela ye [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Nikezela i-vector enkulu ngokwaneleyo kwizinto ezili-10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Gcwalisa izinto zokuqala ezi-3.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Phawula izinto zokuqala ezi-3 ze-vector njengokuqaliswa.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Le ndlela ayiphunyezwanga ngokwe-`split_at_spare_mut`, ukunqanda ukungasebenzi kwezikhombisi kwi-buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Ibuyisa umxholo we-vector njengesilayi se-`T`, kunye nomthamo oshiyekileyo we-vector njengesilayi se `MaybeUninit<T>`.
    ///
    /// Isilayidi somthamo esibuyiselweyo sinokusetyenziselwa ukugcwalisa i vector ngedatha (umz. Ngokufunda kwifayile) ngaphambi kokumakisha idatha njengoko iqalisiwe kusetyenziswa indlela ye [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Qaphela ukuba le yi-API ekumgangatho osezantsi, ekufuneka isetyenziswe ngenkathalo ngeenjongo zokusebenzisa.
    /// Ukuba ufuna ukufaka idatha kwi `Vec` ungasebenzisa i [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] okanye [`resize_with`], kuxhomekeke kwiimfuno zakho ngqo.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Gcina indawo eyongezelelweyo enkulu ngokwaneleyo kwizinto ezili-10.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Gcwalisa izinto ezi-4 ezilandelayo.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Phawula izinto ezi-4 ze-vector njengokuqaliswa.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len ayihoywanga kwaye ke ayitshintshi
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Ukhuseleko: ukutshintsha ukubuyisa .2 (&mut usize) kuthathwa njengokufana nokubiza i `.set_len(_)`.
    ///
    /// Le ndlela isetyenziselwa ukufikelela okhethekileyo kuwo onke amalungu e-vec ngaxeshanye kwi `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` Iqinisekisiwe ukuba iyasebenza kwizinto ze `len`
        // - `spare_ptr` ikhomba into enye edlulileyo, ngoko ke ayihambelani ne `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Yenza ubungakanani kwakhona be `Vec` endaweni ukuze i `len` ilingane ne `new_len`.
    ///
    /// Ukuba i `new_len` ingaphezulu kwe `len`, i `Vec` yandiswa ngumahluko, indawo nganye eyongeziweyo egcwele i `value`.
    ///
    /// Ukuba i `new_len` ingaphantsi kwe `len`, i `Vec` incitshisiwe.
    ///
    /// Le ndlela ifuna i `T` yokuphumeza i [`Clone`], ukuze ikwazi ukudibanisa ixabiso elidlulisiweyo.
    /// Ukuba ufuna ubhetyebhetye ngakumbi (okanye ufuna ukuxhomekeka kwi [`Default`] endaweni ye [`Clone`]), sebenzisa i [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones kwaye yongeza zonke izinto kwisilayidi kwi `Vec`.
    ///
    /// Iterates ngaphezulu kwesilayidi `other`, clones into nganye, kwaye emva koko siyifake kule `Vec`.
    /// I `other` vector inqumle ngolungelelwano.
    ///
    /// Qaphela ukuba lo msebenzi uyafana ne [`extend`] ngaphandle kokuba ikhethekile ukusebenza ngezilayi endaweni yoko.
    ///
    /// Ukuba kwaye nini i-Rust ifumana ubuchwephesha kulo msebenzi unokuncitshiswa (kodwa isekhona).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Ikopa izinto ukusuka ku `src` ukuya esiphelweni se vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` iqinisekisa ukuba uluhlu olunikiweyo lusemthethweni kwisalathiso sakho
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Le khowudi yenza ngokubanzi i `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Yandisa i-vector ngamaxabiso e `n`, usebenzisa umvelisi onikiweyo.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Sebenzisa i-SetLenOnDrop ukusebenza malunga ne-bug apho i-compiler isenokungayiboni ivenkile nge-`ptr` ukuya kwi-self.set_len() musa i-alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Bhala zonke izinto ngaphandle kokugqibela
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Yongeza ubude kuwo onke amanqanaba kwimeko ye next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Singabhala into yokugqibela ngokuthe ngqo ngaphandle kokwenza ngokungafunekiyo
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len ibekwe ngumgcini wokujonga
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Isusa izinto eziphindaphindayo zilandelelana kwi-vector ngokokumiliselwa kwe [`PartialEq`] trait.
    ///
    ///
    /// Ukuba i-vector ihleliwe, oku kususa zonke izinto eziphindiweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Iindlela zangaphakathi kunye nemisebenzi
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` kufuneka ibe sisalathiso esisemthethweni
    /// - `self.capacity() - self.len()` kufuneka ibengu-`>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len inyuswe kuphela emva kokuqalisa izinto
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - abafowunelwa abafowunela ukuba i src sisalathiso esisemthethweni
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - I-elementi yaqaliswa nge-`MaybeUninit::write`, ke kulungile ukunyusa i-len
            // - len inyuswe emva kwento nganye ukuthintela ukuvuza (jonga umba #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - Iifowuni zefowuni ukuba i `src` sisalathiso esisemthethweni
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Zombini izikhombisi zenziwe kwizalathiso zesilayi esahlukileyo (`&mut [_]`) ke ziyasebenza kwaye azigqibi.
            //
            // - Izinto zezi: Khuphela ke kulungile ukuzikopa, ngaphandle kokwenza nantoni na enexabiso lokuqala
            // - `count` ilingana nelen ye `source`, ke umthombo usebenza ngokufundwa kwe `count`
            // - `.reserve(count)` iqinisekisa ukuba i-`spare.len() >= count` ngenxa yoko i-spare iyasebenza kwi-`count` ibhala
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Izinto zazisandula ukwenziwa nge `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ukuphunyezwa okuqhelekileyo kwe trait yeVec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): nge cfg(test) indlela ye `[T]::to_vec`, efunekayo kule nkcazo yendlela, ayifumaneki.
    // Endaweni yokusebenzisa umsebenzi we `slice::to_vec` ofumaneka kuphela nge cfg(test) NB jonga imodyuli ye slice::hack kwi slice.rs ngolwazi oluthe kratya
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // lahla nantoni na engayi kubhalwa ngaphezulu
        self.truncate(other.len());

        // self.len <= other.len ngenxa ye-truncate engentla, ke izilayi apha zihlala zihlala zikumda.
        //
        let (init, tail) = other.split_at(self.len());

        // phinda usebenzise amaxabiso aqulathiweyo allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Yenza iterator edlayo, oko kukuthi, leyo ihambisa ixabiso ngalinye kwi-vector (ukusuka ekuqaleni ukuya ekupheleni).
    /// I-vector ayinakusetyenziswa emva kokubiza oku.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s inohlobo String, hayi i &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // Leaf indlela eya kuthi i-SpecFrom/SpecExtend iphumeze ukuphunyezwa kwayo xa ingenakuphinda isebenze
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Le yimeko ye-iterator ngokubanzi.
        //
        // Lo msebenzi kufuneka ulingane ngokuziphatha:
        //
        //      yento kwi-iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // I-NB ayinakuphuphuma kuba bekuza kufuneka sabele indawo yedilesi
                self.set_len(len + 1);
            }
        }
    }

    /// Yenza i-splicing iterator ethatha indawo yoluhlu oluchaziweyo kwi-vector kunye ne-`replace_with` iterator kwaye ivelise izinto ezisusiweyo.
    ///
    /// `replace_with` Akudingeki ukuba ibude obufanayo ne `range`.
    ///
    /// `range` iyasuswa nokuba iterator ayityiwa kude kube sekupheleni.
    ///
    /// Akuchazwanga ukuba zingaphi izinto ezisuswe kwi-vector ukuba ixabiso le-`Splice` livuziwe.
    ///
    /// Igalelo iterator `replace_with` ityiwa kuphela xa ixabiso le `Splice` liyehla.
    ///
    /// Oku kufanelekile ukuba:
    ///
    /// * Umsila (izinto kwi-vector emva kwe `range`) awunanto,
    /// * okanye i `replace_with` ivelisa izinto ezimbalwa okanye ezilinganayo kubude`bomqolo` ubude
    /// * okanye umda ongezantsi we `size_hint()` yayo ichanekile.
    ///
    /// Ngaphandle koko, i vector yexeshana yabelwe kwaye umsila uhanjiswe kabini.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba indawo yokuqala inkulu kunendawo yokuphela okanye ukuba indawo yokuphela inkulu kunobude be vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Yenza i-iterator esebenzisa ukuvalwa ukumisela ukuba ngaba into ethile kufuneka isuswe.
    ///
    /// Ukuba ukuvalwa kubuya kuyinyani, emva koko into iyasuswa kwaye iveliswe.
    /// Ukuba ukuvalwa kubuya kububuxoki, into leyo iya kuhlala kwi-vector kwaye ayizukuveliswa ngumhambisi wayo.
    ///
    /// Sebenzisa le ndlela ilingana nale khowudi ilandelayo:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // ikhowudi yakho apha
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Kodwa i `drain_filter` kulula ukuyisebenzisa.
    /// `drain_filter` ikwasebenza ngokukuko, kuba inokubuyisela umva izinto zoluhlu ngobuninzi.
    ///
    /// Qaphela ukuba i `drain_filter` ikwenza ukuba uguqule yonke into ekuvaliwe kwesihluzo, nokuba ukhetha ukugcina okanye ukuyisusa.
    ///
    ///
    /// # Examples
    ///
    /// Ukwahlulahlulahlula uluhlu ngokulingana kunye nokungangqinelani, ukusebenzisa ulwabiwo lwantlandlolo:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Lumkela kuthi ungavuzi (ukukhulisa ukuvuza)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Yandisa ukumiliselwa okukopa izinto ngaphandle kwezalathiso ngaphambi kokuba uzityhalele kwiVec.
///
/// Oku kuzalisekiswa kulungiselelwe ii-slice iterators, apho zisebenzisa i-[`copy_from_slice`] ukufaka isilayidi sonke ngaxeshanye.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Izixhobo zokuthelekisa i-vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Ukuphumeza uku-odolwa kwe vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // sebenzisa i-drop ye [T] sebenzisa isilayidi esiluhlaza ukubhekisa kwizinto ze-vector njengohlobo olubuthathaka kakhulu;
            //
            // inokuthintela imibuzo yokunyaniseka kwiimeko ezithile
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // I-RawVec ilawula ukuhanjiswa
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Yenza i `Vec<T>` engenanto.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test utsala kwi-libstd, ebangela iimpazamo apha
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test utsala kwi-libstd, ebangela iimpazamo apha
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Ifumana yonke imixholo ye `Vec<T>` njengoluhlu, ukuba ubungakanani bayo buhambelana ncam noluhlu oluceliweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Ukuba ubude abuhambelani, okokufaka kuyabuya kwi `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ukuba ulungile ngokufumana isimaphambili se `Vec<T>`, ungatsalela umnxeba u [`.truncate(N)`](Vec::truncate) kuqala.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // UKHUSELEKO: `.set_len(0)` isoloko isandi.
        unsafe { vec.set_len(0) };

        // UKHUSELEKO: Isikhombisi se-`Vec` sihlala silungelelaniswe ngokufanelekileyo, kwaye
        // ulungelelwaniso loludwe lwezinto ezifanayo luyafana nezinto.
        // Sijonge kwangoko ukuba sinezinto ezaneleyo.
        // Izinto aziyi kuphonsa kabini njengoko i `set_len` ixelela i `Vec` ukuba nayo ingazilahli.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}