use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Umakishi wobuchwephesha wokuqokelela iterator yombhobho kwiVec ngelixa usebenzisa ulwabiwo lomthombo, okt
/// ukwenza umbhobho endaweni.
///
/// Umzali weSourceIter u trait uyimfuneko ekusebenzeni ngokukodwa ukufikelela kulwabiwo oluza kuphinda lusetyenziswe.
/// Kodwa akonelanga ukuba ubuchwephesha bube semthethweni.
/// Jonga imida eyongezelelweyo kwi-impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// I-std-yangaphakathi SourceIter/InPlaceIterable traits iphunyezwa kuphela ngamatyathanga eAdapter <Adapter<Adapter<IntoIter>>> (zonke ziphethwe yi core/std).
// Imida eyongezelelweyo kulwenziwo lweadaptha (ngaphaya kwe `impl<I: Trait> Trait for Adapter<I>`) ixhomekeke kuphela kwezinye i traits esele ziphawulwe njengobuchwephesha be traits (Ikopi, iTrustedRandomAccess, iFusedIterator).
//
// I.e. isiphawuli asixhomekekanga kubomi beentlobo ezinikezelwe ngumsebenzisi.Modulo umngxunya wokukopa, osele uxhomekeke kwezinye izinto ezizodwa.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Izidingo ezongezelelweyo ezingenakubonakalisa nge trait bounds.Sithembele kwi-eval endaweni yoko:
        // a) akukho ZSTs njengoko kungasayi kubakho sabelo sokuphinda sisebenzise kunye nesikhombisi sezibalo esiya kuthi panic b) ubungakanani bomdlalo njengoko kufunwa sisivumelwano seAlloc c) ulungelelwaniso lomdlalo njengoko kufunwa sisivumelwano seAlloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ukubuyela umva kuphumezo oluqhelekileyo
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // Sebenzisa ukuzama ukusukela
        // - ivekisha ngokungcono ezinye iadaptha zokwenza iiterator
        // - Ngokungafaniyo neendlela ezininzi zangaphakathi, ithatha kuphela i-&mut uqobo
        // - Isivumela ukuba sifake isalathiso sokubhala ngaphakathi kwayo kwaye siyibuyise ekugqibeleni
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // Ukulungiswa kuphumelele, musa ukulahla intloko
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // jonga ukuba ngaba ikhontrakthi ye-SourceIter ibigcinelwe i-caveat: ukuba ibingekho, ngekhe size kude kube ngoku
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // jonga InPlaceIterable contract.Oku kunokwenzeka kuphela ukuba i-iterator iqhubele phambili kwisikhombisi somthombo konke konke.
        // Ukuba isebenzisa ukufikelela okungakhange kuhlolwe ngeTrustedRandomAccess emva koko isikhombisi somthombo siya kuhlala kwindawo yaso yokuqala kwaye asinakusisebenzisa njengesalathiso
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // lahla nawaphi na amaxabiso ashiyekileyo emsileni womthombo kodwa uthintele ukuhla kolwabiwo ngokwalo nje ukuba i-IntoIter iphume kwinqanaba ukuba i-panics yehle kwaye emva koko sivuza nayiphi na into eqokelelwe kwi-dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ikhontrakthi ye-InPlaceIterable ayinakuqinisekiswa ngokuchanekileyo kuba try_fold inereferensi ekhethekileyo kwisikhombisi somthombo konke esinokukwenza kukujonga ukuba isekhona na kuluhlu
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}