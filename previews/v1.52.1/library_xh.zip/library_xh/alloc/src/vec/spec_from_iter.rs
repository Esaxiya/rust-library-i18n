use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Ubungcali be trait isetyenziselwe i Vec::from_iter
///
/// ## Igrafu yokuhambisa:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ityala eliqhelekileyo lokudlula kwi-vector iye emsebenzini ize iphinde iqokelele kwi-vector.
        // Singayifutshane isekethe le ukuba i-IntoIter khange ihambele phambili konke konke.
        // Xa sele iqhubekile singaphinda sisebenzise imemori kwaye sihambise idatha ngaphambili.
        // Kodwa sikwenza oko kuphela xa iziphumo ze-Vec zingayi kuba namandla angasetyenziswanga kunokuba ziyile ngokusebenzisa i-generic FromIterator yokuphunyezwa.
        //
        // Oso sithintelo asiyomfuneko ngokungqongqo njengoko indlela yokuziphatha kolwabiwo lwe-Vec ingachazwanga ngabom.
        // Kodwa lukhetho olulondolozayo.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // Kufuneka udlulisele kwi-spec_extend() ukusukela nge-extend() ngokwabo abathunywa kwi-spec_from yee-Vec ezingenanto
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Oku kusebenzisa i-`iterator.as_slice().to_vec()` kuba i-spec_extend kufuneka ithathe amanyathelo ngakumbi ukuqiqa malunga nobungakanani bokugqibela + ubude kwaye ngaloo ndlela wenze umsebenzi omninzi.
// `to_vec()` wabela ngokuthe ngqo isixa esichanekileyo kwaye usizalisa ngokuchanekileyo.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): nge cfg(test) indlela ye `[T]::to_vec`, efunekayo kule nkcazo yendlela, ayifumaneki.
    // Endaweni yokusebenzisa umsebenzi we `slice::to_vec` ofumaneka kuphela nge cfg(test) NB jonga imodyuli ye slice::hack kwi slice.rs ngolwazi oluthe kratya
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}