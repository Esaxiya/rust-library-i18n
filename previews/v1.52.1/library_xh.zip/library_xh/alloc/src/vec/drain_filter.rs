use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Iterator esebenzisa ukuvalwa ukumisela ukuba into ethile kufuneka isuswe na.
///
/// Olu lwakhiwo lwenziwe yi [`Vec::drain_filter`].
/// Bona amaxwebhu ayo ngaphezulu.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Isalathiso sento eya kuthi ihlolwe ngumnxeba olandelayo oya kwi `next`.
    pub(super) idx: usize,
    /// Inani lezinto ezikhutshiweyo (removed) ukuza kuthi ga ngoku.
    pub(super) del: usize,
    /// Ubude boqobo be `vec` ngaphambi kokutsalwa.
    pub(super) old_len: usize,
    /// Isilingo sovavanyo lokucoca ulwelo.
    pub(super) pred: F,
    /// Iflegi ebonisa ukuba i-panic yenzekile kwisilumkiso sovavanyo lokucoca ulwelo.
    /// Oku kusetyenziswa njengecebisa ekuphunyezweni kwethontsi ukuthintela ukusetyenziswa kwentsalela ye `DrainFilter`.
    /// Naziphi na izinto ezingasetyenziswanga ziya kubuyiselwa umva kwi `vec`, kodwa akukho zinto zimbi ziya kulahlwa okanye kuvavanywe isimaphambili sesihluzo.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Ibuyisela ireferensi kulwabiwo olusisiseko.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Hlaziya isalathiso *emva* kwesivisa esibiziweyo.
                // Ukuba isalathiso sihlaziywa kwangaphambili kunye nesalathiso se-panics, into ekule khowudi iya kuvuza.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Eli lizwe lihle kakhulu, kwaye akukho nto ilungileyo ukuyenza.
                        // Asifuni ukuqhubeka sizama ukwenza i-`pred`, ke sibuyela umva zonke izinto ezingasetyenziswanga kwaye sixelele i-vec ukuba zisekhona.
                        //
                        // I-backshift iyafuneka ukuthintela ukuhla kabini kwento yokugqibela ekhutshwe ngempumelelo ngaphambi kwe-panic kwisivisa.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Ukuzama ukusebenzisa naziphi na izinto ezishiyekileyo ukuba isimaphambili sesihluzo asikothuki.
        // Siza kubuyisela umva naziphi na izinto ezishiyekileyo nokuba sele sisoyika okanye ukuba ukusetyenziswa apha kwi-panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}