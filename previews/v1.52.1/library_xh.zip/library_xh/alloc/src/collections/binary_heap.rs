//! Umgca ophambili ophunyezwe ngemfumba yokubini.
//!
//! Ukufakwa kunye nokuphuma kweyona nto inkulu kune *O*(log(*n*)) yexesha lokuntsokotha.
//! Ukujonga eyona nto inkulu *O*(1).Ukuguqula i-vector uyenze kwimfumba yokubini inokwenziwa endaweni, kwaye ine-*O*(*n*) ubunzima.
//! Imfumba yokubini inokuguqulwa ibe yi-vector ehleliweyo-endaweni, ivumele ukuba isetyenziselwe i *O*(*n*\log(*n*)) kwindawo eyi-heapsort.
//!
//! # Examples
//!
//! Lo ngumzekelo omkhulu osebenzisa i [Dijkstra's algorithm][dijkstra] ukusombulula i [shortest path problem][sssp] kwi [directed graph][dir_graph].
//!
//! Ibonisa indlela yokusebenzisa i [`BinaryHeap`] ngeentlobo zesiko.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Ulayini ophambili uxhomekeke kwi `Ord`.
//! // Sebenzisa ngokucacileyo i-trait ukuze umgca ube yimfumba endaweni yemfumba enkulu.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Qaphela ukuba si-flip uku-odola kwiindleko.
//!         // Kwimeko yethayi sithelekisa indawo, eli nyathelo liyimfuneko ukwenza ukuphunyezwa kwe `PartialEq` kunye ne `Ord` ngokungqinelanayo.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` ifuna ukwenziwa nayo.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // I-node nganye imelwe njenge-`usize`, yokuphunyezwa okufutshane.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Eyona ndlela imfutshane ye-algorithm yendlela.
//!
//! // Qala kwi-`start` kwaye usebenzise i-`dist` ukulandela umkhondo omfutshane ngoku kwi-node nganye.Olu setyenziso alusebenzi kwimemori njengoko lunokushiya iindawo eziphindiweyo kulayini.
//! //
//! // Ikwasebenzisa i `usize::MAX` njengexabiso le-sentinel, ukumiliselwa okulula.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=umgama omfutshane ngoku ukusuka kwi `start` ukuya kwi `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Siku `start`, ngendleko zero
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Vavanya umda kunye nexabiso eliphantsi lendawo yokuqala i (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Ngaphandle koko besinokuqhubeka nokufumana zonke iindlela ezimfutshane
//!         if position == goal { return Some(cost); }
//!
//!         // Kubalulekile njengoko kunokuba sele sifumene indlela ebhetele
//!         if cost > dist[position] { continue; }
//!
//!         // Kwindlela nganye esinokufikelela kuyo, jonga ukuba singayifumana indlela ngeendleko ezisezantsi zokuhamba ngale ndlela
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Ukuba kunjalo, yongeza kumda kwaye uqhubeke
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Ukuphumla, ngoku sifumene indlela ebhetele
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Injongo ayifikeleleki
//!     None
//! }
//!
//! fn main() {
//!     // Le yigrafu esiya kuyisebenzisa.
//!     // Amanani e-node ahambelana namazwe ahlukeneyo, kwaye ubunzima be-edge bubonisa iindleko zokuhamba ukusuka kwelinye node ukuya kwelinye.
//!     //
//!     // Qaphela ukuba imiphetho iyindlela enye.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Igrafu imelwe njengoluhlu olusondeleyo apho isalathiso ngasinye, esihambelana nexabiso le-node, sinoluhlu lwemiphetho ephumayo.
//!     // Ikhethwe ngokusebenza kwayo.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Indlela 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Indlela 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Indlela 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Indlela 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Indlela 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Umgca ophambili ophunyezwe ngemfumba yokubini.
///
/// Le iya kuba yimfumba enkulu.
///
/// Yimpazamo enengqondo ukuba into iguqulwe ngohlobo lokuba uku-odolwa kwento kuthelekiswa nayo nayiphi na enye into, njengoko kumiselwe yi `Ord` trait, utshintsho ngelixa lusemfumba.
///
/// Oku kuhlala kunokwenzeka kuphela nge `Cell`, `RefCell`, kwilizwe jikelele, I/O, okanye ikhowudi engakhuselekanga.
/// Ukuziphatha okubangelwa yimpazamo enjalo ayichazwanga, kodwa ayizukukhokelela kwisimilo esingachazwanga.
/// Oku kunokubandakanya i-panics, iziphumo ezingachanekanga, ukurhoxa, ukuvuza kwenkumbulo, kunye nokupheliswa.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Uhlobo lokuthotyelwa lusivumela ukuba sishiye uhlobo olucacileyo lokusayina (olunokuba yi `BinaryHeap<i32>` kulo mzekelo).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Singasebenzisa ukukhangela ukujonga into elandelayo kwimfumba.
/// // Kule meko, akukho zinto ziphakathi okwangoku ukuze singafumani nanye.
/// assert_eq!(heap.peek(), None);
///
/// // Masongeze amanqaku ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Ngoku kroba kubonisa eyona nto ibalulekileyo kwimfumba.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Singajonga ubude bemfumba.
/// assert_eq!(heap.len(), 3);
///
/// // Sinokulinganisa ngaphezulu kwezinto ezikwimfumba, nangona zibuyiswe ngolandelelwano olungacwangciswanga.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Ukuba endaweni yoko sivelisa la manqaku, kufuneka abuye ngokulandelelana.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Singasusa imfumba yazo naziphi na izinto eziseleyo.
/// heap.clear();
///
/// // Imfumba ngoku kufuneka ingenanto.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Nokuba i `std::cmp::Reverse` okanye ukumiliselwa kwe `Ord` kunokusetyenziselwa ukwenza i `BinaryHeap` njengemfumba encinci.
/// Oku kwenza i `heap.pop()` ibuyise elona xabiso lincinci endaweni yelona likhulu.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Songa amaxabiso kwi `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Ukuba siyawafaka la manqaku ngoku, kuya kufuneka abuye ngokulandelelana.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Ubunzima bexesha
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Ixabiso le `push` lixabiso elilindelweyo;Amaxwebhu endlela anika uhlalutyo oluneenkcukacha ngakumbi.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Ulwakhiwo lusonga isalathiso esinokutshintshwa sesona sihloko sikhulu kwi `BinaryHeap`.
///
///
/// Le `struct` yenziwe yindlela ye [`peek_mut`] kwi [`BinaryHeap`].
/// Bona amaxwebhu ayo ngaphezulu.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // UKHUSELEKO: I-PeekMut iqiniselwe kuphela kwiimfumba ezingenanto.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // UKHUSELEKILE: I-PeekMut yenziwe kuphela kwiimfumba ezingenanto
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // UKHUSELEKILE: I-PeekMut yenziwe kuphela kwiimfumba ezingenanto
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Isusa ixabiso elixeliweyo kwimfumba kwaye iyibuyise.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Yenza i `BinaryHeap<T>` engenanto.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Yenza i-`BinaryHeap` engenanto njenge-max-heap.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Yenza i-`BinaryHeap` engenanto ngomthamo othile.
    /// Oku kubeka inkumbulo eyoneleyo yezinto ze `capacity`, ukuze i `BinaryHeap` kungafuneki iphinde iboniswe de iqulethe ubuncinci amaxabiso amaninzi.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Ibuyisa ireferensi enokuguquguquka kweyona nto inkulu kwimfumba yokubini, okanye i `None` ukuba ayinanto.
    ///
    /// Note: Ukuba ixabiso le `PeekMut` livuza, imfumba inokuba kwimeko engahambelaniyo.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Ubunzima bexesha
    ///
    /// Ukuba into iguqulwe emva koko elona xesha lobunzima li *O*(log(*n*)), kungenjalo *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Isusa eyona nto iphambili kwimfumba yokubini kwaye iyibuyise, okanye i `None` ukuba ayinanto.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Ubunzima bexesha
    ///
    /// Ixabiso elibi kakhulu le `pop` kwimfumba enezinto ze *n* yi *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // UKHUSELEKO: !self.is_empty() kuthetha ukuba i self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Ukutyhala into kwimfumba yokubini.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Ubunzima bexesha
    ///
    /// Ixabiso elilindelweyo le `push`, elinganisiweyo ngaphezulu kwayo yonke into enokwenzeka yoku-odolwa kwezinto ezityhalelweyo, nangaphezulu kwenani elikhulu lokutyhala, ngu-O * (1).
    ///
    /// Eli lelona xabiso libiza kakhulu xa kutyhalwa izinto ezingekhoyo * nakweyiphi na indlela ehleliweyo.
    ///
    /// Ubunzima bexesha buthoba isidima ukuba izinto zityhalelwe ikakhulu kulonyuko.
    /// Kwimeko embi, izinto zityhalelwa ukunyuka ngokulandelelana okuhlelweyo kwaye indleko ezihlawulweyo ngePush *O*(log(*n*)) ngokuchasene nemfumba enezinto ze *n*.
    ///
    /// Ixabiso elibi kakhulu lokufowuna *kwi-`push` ngu* O *(* n *).Ityala elibi kakhulu lenzeka xa amandla ephelile kwaye ufuna ubungakanani kwakhona.
    /// Iindleko zokuhlaziya ziye zahlulwa kumanani angaphambili.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // UKHUSELEKO: Ukusukela ukuba sityhale into entsha kuthetha ukuba
        //  endala_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Isebenzisa i `BinaryHeap` kwaye ibuyisele i-vector kulungelelwaniso lwe-(ascending).
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // UKHUSELEKO: I-`end` isuka kwi-`self.len() - 1` iye kwi-1 (zombini zibandakanyiwe),
            //  ihlala ihleli isalathiso esisemthethweni sokufikelela.
            //  Kukhuselekile ukufikelela kwisalathiso 0 (okt `ptr`), kuba
            //  1 <=end <self.len(), Oko kukuthi self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // UKHUSELEKO: I `end` isuka kwi `self.len() - 1` iye kwi-1 (zombini zibandakanyiwe):
            //  0 <1 <=end <= self.len(), 1 <self.len() Oko kuthetha ukuba 0 <end and end <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Ukuphunyezwa kwe-sift_up kunye nokusefa_ukusebenzisa iibhloko ezingakhuselekanga ukuze ususe into ngaphandle kwe vector (ushiya ngasemva umngxuma), shenxisa kunye nezinye kwaye ususe into esusiweyo ubuyisele kwi vector kwindawo yokugqibela yomngxunya.
    //
    // Uhlobo lwe `Hole` lusetyenziselwa ukumela oku, kwaye uqiniseke ukuba umngxunya ugcwalisiwe kwakhona ekupheleni kobubanzi bawo, nkqu nakwi panic.
    // Sebenzisa umngxunya kunciphisa into engapheliyo xa kuthelekiswa nokusebenzisa ukutshintshana, okubandakanya intshukumo ephindwe kabini kunaleyo.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Umntu ofowunayo uyaqinisekisa ukuba i `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Thatha ixabiso kwi `pos` kwaye wenze umngxuma.
        // UKHUSELEKO: Umntu ofowunayo uqinisekisa ukuba pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // UKHUSELEKO: hole.pos()> qala>=0, oko kuthetha ukuba i-hole.pos()> 0
            //  kwaye ke i hole.pos(), 1 ayinakudlula.
            //  Oku kuqinisekisa ukuba umzali <hole.pos() ke sisalathiso esisemthethweni kwaye!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // UKHUSELEKO: Kuyafana njengasentla
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Thatha into nge `pos` uyihambise phantsi kwimfumba, ngelixa abantwana bayo bebaninzi.
    ///
    ///
    /// # Safety
    ///
    /// Umntu ofowunayo uyaqinisekisa ukuba i `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // UKHUSELEKO: Umntu ofowunayo uqinisekisa ukuba pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Ukujikeleza okungapheliyo: umntwana==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // thelekisa nomkhulu waba bantwana babini UKHUSELEKO: umntwana <end, 1 <self.len() kunye nomntwana + 1 <end <= self.len(), ke zizalathiso ezifanelekileyo.
            //
            //  umntwana==2 *hole.pos() + 1!= hole.pos() kunye nomntwana + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 okanye 2* hole.pos() + 2 inokuphuphuma ukuba yi-ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ukuba sele silungile, yima.
            // UKHUSELEKO: umntwana ngoku ingumntwana omdala okanye umntwana omdala + 1
            //  Sele siqinisekisile ukuba zombini ziyi-<self.len() kunye!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // UKHUSELEKO: ngokufanayo ngasentla.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // UKHUSELEKO: &&isekethe emfutshane, oko kuthetha ukuba kwifayile ye-
        //  imeko yesibini sele iyinyani ukuba umntwana==end, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // UKHUSELEKO: umntwana sele ebonakalisiwe ukuba sisalathiso esisemthethweni kwaye
            //  umntwana==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Umntu ofowunayo uyaqinisekisa ukuba i `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // UKHUSELEKO: pos <len iqinisekisiwe ngulowo ufowunayo kwaye
        //  ngokucacileyo len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Thatha into kwi `pos` kwaye uyihambise yonke indlela ezantsi kwimfumba, emva koko uyihluzele kwindawo yayo.
    ///
    ///
    /// Note: Oku kuyakhawuleza xa into yaziwa ngokuba nkulu/kufuneka ibe kufutshane nasezantsi.
    ///
    /// # Safety
    ///
    /// Umntu ofowunayo uyaqinisekisa ukuba i `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // UKHUSELEKO: Umntu ofowunayo uqinisekisa ukuba pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Ukujikeleza okungapheliyo: umntwana==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // UKHUSELEKO: umntwana <ukuphela, 1 <self.len() kunye
            //  child + 1 <end <= self.len(), Ke zizalathiso ezifanelekileyo.
            //  umntwana==2 *hole.pos() + 1!= hole.pos() kunye nomntwana + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 okanye 2* hole.pos() + 2 inokuphuphuma ukuba yi-ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // UKHUSELEKO: Kuyafana njengasentla
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // UKHUSELEKO: ukuphela komntwana=1, 1 <self.len(), ke sisalathiso esisemthethweni
            //  kunye nomntwana==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // UKHUSELEKO: I-pos yindawo emi emngxunyeni kwaye sele ibonakalisiwe
        //  ukuba sisalathiso esisemthethweni.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // UKHUSELEKO: n iqala ukusuka kwi self.len()/2 kwaye yehle iye kwi-0.
            //  Ityala ekuphela kwalo xa! (N <self.len()) Ngu self.len() ==0, Kodwa ikhutshiwe yimeko yeluphu.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Ihambisa onke amanqaku e-`other` ukuya kwi-`self`, ishiya i-`other` ingenanto.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` ithatha imisebenzi ye-O(len1 + len2) kwaye malunga ne-2 *(len1 + len2) uthelekiso lweyona meko imbi ngelixa i-`extend` ithatha imisebenzi ye-O(len2* log(len1)) kwaye malunga ne-1 *len2* log_2(len1) uthelekiso lweyona meko imbi, uthatha i len1>= len2.
        // Kwiimfumba ezinkulu, inqaku le-crossover alisalandeli le ndlela yokuqiqa kwaye lazimisela ngamandla.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Ibuyisa iterator efumana kwakhona izinto ngokulandelelana kwemfumba.
    /// Izinto ezifunyenweyo ziyasuswa kwimfumba yoqobo.
    /// Izinto ezishiyekileyo ziya kususwa ngokwehla kulandelelwano lweemfumba.
    ///
    /// Note:
    /// * `.drain_sorted()` ngu *O*(*n*\log(*n*)); kancinci kancinci kune `.drain()`.
    ///   Kuya kufuneka usebenzise le yokugqibela kwimeko ezininzi.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // isusa zonke izinto ngokulandelelana kwemfumba
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Igcina kuphela izinto ezichazwe kwisivisa.
    ///
    /// Ngamanye amagama, susa zonke izinto `e` kangangokuba i `f(&e)` ibuyise i `false`.
    /// Izinto ziyatyelelwa ngokulandelelana (kunye nokungaxelwanga) ngokulandelelana.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // gcina kuphela amanani
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Ibuyisa iterator ityelele onke amaxabiso asisiseko se vector, ngolandelelwano olungqongqo.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Phrinta 1, 2, 3, 4 ngokulandelelana
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Ibuyisa iterator efumana kwakhona izinto ngokulandelelana kwemfumba.
    /// Le ndlela isebenzisa imfumba yentsusa.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Ibuyisa eyona nto inkulu kwimfumba yokubini, okanye i `None` ukuba ayinanto.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Ubunzima bexesha
    ///
    /// Iindleko *O*(1) kweyona meko imbi.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Ibuyisa inani lezinto ezinokubanjelwa yimfumba ngaphandle kokubekwa kwakhona.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Kugcinwa ubuncinci bomthamo we-`additional` ngakumbi izinto eziza kufakwa kwi-`BinaryHeap` enikiweyo.
    /// Ayenzi nto ukuba umthamo sele uwanele.
    ///
    /// Qaphela ukuba umthengisi unokunika ingqokelela indawo engaphezulu kunaleyo ayifunayo.
    /// Ke ngoko umthamo awunakuthenjwa ekubeni ubuncinci ngokuchanekileyo.
    /// Khetha i [`reserve`] ukuba kulindelwe ukufakwa kwe future.
    ///
    /// # Panics
    ///
    /// Panics ukuba umthamo omtsha uphuphuma kwi `usize`.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Ogcina amandla ubuncinci i-`additional` yezinto ezingaphezulu eziza kufakwa kwi `BinaryHeap`.
    /// Ingqokelela inokugcina indawo ngakumbi ukunqanda ulwabiwo rhoqo.
    ///
    /// # Panics
    ///
    /// Panics ukuba umthamo omtsha uphuphuma kwi `usize`.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Ukulahla amandla ongezelelweyo kangangoko kunokwenzeka.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Lahla umthamo onomda osezantsi.
    ///
    /// Umthamo uya kuhlala ubuncinci ubuncinci njengobude kunye nexabiso elibonelelweyo.
    ///
    ///
    /// Ukuba umthamo wangoku ungaphantsi komda ongezantsi, le yi-no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Isebenzisa i `BinaryHeap` kwaye ibuyise isiseko se vector ngolandelelwano olungqongqo.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Siza kuprinta ngolunye uhlobo
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Ibuyisa ubude bemfumba yokubini.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Jonga ukuba imfumba yokubini ayinanto.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Isusa imfumba yokubini, ibuyise iterator ngaphezulu kwezinto ezisusiweyo.
    ///
    /// Izinto zisuswe ngokulandelelana ngokungangqinelaniyo.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Uwisa zonke izinto kwimfumba yokubini.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Umngxunya umele umngxunya kwisilayidi okt, isalathiso ngaphandle kwexabiso elifanelekileyo (kuba sisusiwe okanye saphindwa).
///
/// Kwi-drop, i-`Hole` iya kubuyisela isilayidi ngokugcwalisa indawo emngxunyeni ngexabiso elalisuswe ekuqaleni.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Yenza i `Hole` entsha kwisalathiso `pos`.
    ///
    /// Akukhuselekanga kuba iposi kufuneka ibe phakathi kwesilayidi sedatha.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // UKHUSELEKILE: iposi kufuneka ibe ngaphakathi kwesilayidi
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Ibuyisela ireferensi kwinto esusiweyo.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Ibuyisa ireferensi yento kwi `index`.
    ///
    /// Akukhuselekanga kuba isalathiso kufuneka sibe ngaphakathi kwesilayidi sedatha kwaye singalingani neposi.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Hambisa umngxunya kwindawo entsha
    ///
    /// Akukhuselekanga kuba isalathiso kufuneka sibe ngaphakathi kwesilayidi sedatha kwaye singalingani neposi.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // gcwalisa umngxunya kwakhona
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Iterator ngaphezulu kwezinto ze `BinaryHeap`.
///
/// Le `struct` yenziwe yi [`BinaryHeap::iter()`].
/// Bona amaxwebhu ayo ngaphezulu.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Susa ngokuxhasa i `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Iserter esingumnini ngaphezulu kwezinto ze `BinaryHeap`.
///
/// Le `struct` yenziwe yi-[`BinaryHeap::into_iter()`] (ebonelelwe yi `IntoIterator` trait).
/// Bona amaxwebhu ayo ngaphezulu.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Isitshisi esitsala ngaphezulu kwezinto ze `BinaryHeap`.
///
/// Le `struct` yenziwe yi [`BinaryHeap::drain()`].
/// Bona amaxwebhu ayo ngaphezulu.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Isitshisi esitsala ngaphezulu kwezinto ze `BinaryHeap`.
///
/// Le `struct` yenziwe yi [`BinaryHeap::drain_sorted()`].
/// Bona amaxwebhu ayo ngaphezulu.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Isusa imfumba ngokulandelelana kwemfumba.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Guqula i `Vec<T>` ibe yi `BinaryHeap<T>`.
    ///
    /// Olu tshintsho lwenzeka endaweni, kwaye inexesha le-O *(* n *).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Guqula i `BinaryHeap<T>` ibe yi `Vec<T>`.
    ///
    /// Olu tshintsho aludingi ntshukumo yedatha okanye ulwabiwo, kwaye lunexesha elinobunzima.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Yenza i-iterator edlayo, oko kukuthi, leyo ihambisa ixabiso ngalinye ngaphandle kwemfumba ebambekayo ngokulandelelana okungahambelaniyo.
    /// Imfumba yokubini ayinakusetyenziswa emva kokubiza oku.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Phrinta 1, 2, 3, 4 ngokulandelelana
    /// for x in heap.into_iter() {
    ///     // x ine-i32, hayi i-&i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}