use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Okwexeshana kukhupha enye, engalinganiyo engalinganiyo kuluhlu olufanayo.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Fumana imiphetho yamagqabi eyahlukileyo edibanisa uluhlu oluchaziweyo emthini.
    /// Ibuyisa nokuba zizibini zokubamba ezahlukeneyo kumthi omnye okanye isibini sokhetho olungenanto.
    ///
    /// # Safety
    ///
    /// Ngaphandle kokuba i `BorrowType` ingu `Immut`, sukusebenzisa izibambo eziphindiweyo ukutyelela i-KV efanayo kabini.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ilingana ne `(root1.first_leaf_edge(), root2.last_leaf_edge())` kodwa isebenze ngakumbi.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Fumana isibini samaphepha amagqabi omisela uluhlu oluthile emthini.
    ///
    /// Iziphumo zinentsingiselo kuphela ukuba umthi u-odolwe sisitshixo, njengomthi okwi-`BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // UKHUSELEKO: uhlobo lwethu lokuboleka alunakuchaphazeleka.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Fumana isibini samaphepha amagqabi omisela umthi wonke.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Ukwahlula ireferensi eyahlukileyo kumagqabi emagqabantshintshi anciphisa uluhlu oluchaziweyo.
    /// Iziphumo zizalathiso ezingafaniyo ezivumela utshintsho lwe (some), ekufuneka isetyenziswe ngononophelo.
    ///
    /// Iziphumo zinentsingiselo kuphela ukuba umthi u-odolwe sisitshixo, njengomthi okwi-`BTreeMap`.
    ///
    ///
    /// # Safety
    /// Sukusebenzisa iikopi eziphindiweyo zokundwendwela i-KV enye kabini.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Ukwahlula ireferensi eyahlukileyo kumagqabi emagqabi anciphisa uluhlu olupheleleyo lomthi.
    /// Iziphumo zizalathiso ezingafaniyo ezivumela utshintsho (lwamaxabiso kuphela), ke kufuneka isetyenziswe ngononophelo.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Siphinda ingcambu yeNodeRef apha-asisokuze sityelele i-KV enye kabini, kwaye asinakuphela sineengxelo ezixabanayo.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Ukwahlula ireferensi eyahlukileyo kumagqabi emagqabi anciphisa uluhlu olupheleleyo lomthi.
    /// Iziphumo zizalathiso ezingafaniyo ezivumela utshintsho olunamandla, ngenxa yoko kufuneka zisetyenziswe ngononophelo olukhulu.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Siphinda ingcambu yeNodeRef apha-asinakuze siyifumane ngendlela egqitha kwizalathiso ezifunyenwe kwingcambu.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Ukunikwa isiphatho segqabi i-edge, ibuyisa i-[`Result::Ok`] ngesiphatho kwi-KV engummelwane kwicala lasekunene, nokuba ikwindawo enye yegqabi okanye kwindawo yookhokho.
    ///
    /// Ukuba igqabi u edge lelokugqibela emthini, libuyisa i [`Result::Err`] ngengcambu yendlela.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Ukunikwa isiphatho segqabi i-edge, ibuyisa i-[`Result::Ok`] ngesiphatho kwi-KV engummelwane kwicala lasekhohlo, elikwindawo enye yamagqabi okanye kwindawo yookhokho.
    ///
    /// Ukuba igqabi u edge lelokuqala emthini, libuyisa i [`Result::Err`] ngengcambu yendlela.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Ngokunikwa isibambo sangaphakathi se-edge, ibuyisa i-[`Result::Ok`] ngesiphatho kwi-KV engummelwane kwicala lasekunene, elikwindawo enye yangaphakathi okanye kwindawo yookhokho.
    ///
    /// Ukuba i-edge yangaphakathi yeyokugqibela emthini, ibuyisa i [`Result::Err`] ngengcambu yendlela.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Unikwe isiphatho segqabi i-edge kumthi ofayo, ubuyisela igqabi elilandelayo u edge kwicala lasekunene, kunye nexabiso lesitshixo eliphakathi, elikwindawo enye yamagqabi, kwindawo yezinyanya, okanye engekhoyo.
    ///
    ///
    /// Le ndlela ikwahambisa nayiphi na i node(s) ifikelela esiphelweni.
    /// Oku kuthetha ukuba ukuba akusekho zibini zexabiso eliphambili, yonke intsalela yomthi iya kube isihanjisiwe kwaye akukho nto iseleyo ukubuya.
    ///
    /// # Safety
    /// I-edge enikiweyo akufuneki ukuba ibibuyiselwe ngaphambili liqabane `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Unikwe isiphatho segqabi i-edge kumthi ofayo, ubuyisela igqabi elilandelayo u edge kwicala lasekhohlo, kunye nexabiso lesitshixo eliphakathi, elikwindawo enye yamagqabi, kwindawo yezinyanya, okanye engekhoyo.
    ///
    ///
    /// Le ndlela ikwahambisa nayiphi na i node(s) ifikelela esiphelweni.
    /// Oku kuthetha ukuba ukuba akusekho zibini zexabiso eliphambili, yonke intsalela yomthi iya kube isihanjisiwe kwaye akukho nto iseleyo ukubuya.
    ///
    /// # Safety
    /// I-edge enikiweyo akufuneki ukuba ibibuyiselwe ngaphambili liqabane `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Isusa inqwaba yeendawo ukusuka kwiqabunga ukuya kwingcambu.
    /// Le kuphela kwendlela yokuhambisa intsalela yomthi emva kokuba i `deallocating_next` kunye ne `deallocating_next_back` zibambe kumacala omabini omthi, kwaye babetha i edge efanayo.
    /// Njengoko kuhloselwe ukubizwa kuphela xa zonke izitshixo kunye namaxabiso abuyisiwe, akukho kucocwa kwenziwa nakweyiphi na yezitshixo okanye amaxabiso.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ihambisa isiphatho segqabi u edge liye kwigqabi elilandelayo le-edge kwaye ibuyisele izingqinisiso kwisitshixo kunye nexabiso phakathi.
    ///
    ///
    /// # Safety
    /// Kufuneka kubekho enye i-KV kwicala elihanjisiweyo.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Ihambisa isiphatho segqabi i-edge kwigqabi langaphambili le-edge kwaye ibuyisele izingqinisiso kwisitshixo kunye nexabiso phakathi.
    ///
    ///
    /// # Safety
    /// Kufuneka kubekho enye i-KV kwicala elihanjisiweyo.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ihambisa isiphatho segqabi u edge liye kwigqabi elilandelayo le-edge kwaye ibuyisele izingqinisiso kwisitshixo kunye nexabiso phakathi.
    ///
    ///
    /// # Safety
    /// Kufuneka kubekho enye i-KV kwicala elihanjisiweyo.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Ukwenza oku kokugqibela kuyakhawuleza, ngokweebhentshi.
        kv.into_kv_valmut()
    }

    /// Ihambisa isiphatho segqabi u edge kwigqabi elingaphambili kwaye ibuyisele izingqinisiso kwisitshixo kunye nexabiso phakathi.
    ///
    ///
    /// # Safety
    /// Kufuneka kubekho enye i-KV kwicala elihanjisiweyo.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Ukwenza oku kokugqibela kuyakhawuleza, ngokweebhentshi.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Ihambisa isiphatho segqabi i-edge kwigqabi elilandelayo le-edge kwaye ibuyisele isitshixo kunye nexabiso phakathi, ukuhambisa nayiphi na indawo eshiye ngasemva ngelixa ishiya i-edge ehambelanayo kwindawo yayo yomzali ejingayo.
    ///
    /// # Safety
    /// - Kufuneka kubekho enye i-KV kwicala elihanjisiweyo.
    /// - Leyo KV ibingabuyiswanga ngaphambili ngumlingani `next_back_unchecked` kuyo nayiphi na ikopi yeziphatho ezisetyenziselwa ukunqumla emthini.
    ///
    /// Ekuphela kwendlela ekhuselekileyo yokuqhubeka nesiphatho esihlaziyiweyo kukuthelekisa, ukulahla, fowunela le ndlela kwakhona ngokuxhomekeke kwimeko yokhuseleko, okanye utsalele umnxeba kwi `next_back_unchecked` ngokuxhomekeke kwimeko yokhuseleko.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Ihambisa isiphatho segqabi i-edge kwigqabi langaphambili le-edge kwaye ibuyisele isitshixo kunye nexabiso phakathi, ukuhambisa nayiphi na indawo eshiye ngasemva ngelixa ishiya i-edge ehambelanayo kwindawo yayo ejingayo yomzali.
    ///
    /// # Safety
    /// - Kufuneka kubekho enye i-KV kwicala elihanjisiweyo.
    /// - Eli gqabi edge belingabuyiswanga ngaphambili liqabane `next_unchecked` kuyo nayiphi na ikopi yeziphatho ezisetyenziselwa ukunqumla emthini.
    ///
    /// Ekuphela kwendlela ekhuselekileyo yokuqhubeka nesiphatho esihlaziyiweyo kukuthelekisa, ukulahla, fowunela le ndlela kwakhona ngokuxhomekeke kwimeko yokhuseleko, okanye utsalele umnxeba kwi `next_unchecked` ngokuxhomekeke kwimeko yokhuseleko.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ibuyisa igqabi lasekhohlo i-edge ngaphakathi okanye ngaphantsi kwendlela, ngamanye amagama, i-edge oyifunayo kuqala xa usinga phambili (okanye okokugqibela xa ubuyela umva).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Ibuyisela elona qhinga lasekunene le-edge ngaphakathi okanye ngaphantsi kwendlela, ngamanye amagama, i-edge oyifunayo ekugqibeleni xa uzulazulela phambili (okanye okokuqala xa ubuyela umva).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Undwendwela iindawo ezinamagqabi kunye nee-KVs zangaphakathi ngokulandelelana kwamaqhosha enyukayo, kwaye undwendwela iindawo zangaphakathi zizonke ngokobunzulu bokuqala, oko kuthetha ukuba iindawo zangaphakathi zandulela ii-KVs zabo kunye neendawo zabo zabantwana.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Ibala inani lezinto kumthi (sub).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Ibuyisela igqabi u edge elikufutshane ne-KV yokuqhubela phambili.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Ibuyisela igqabi u edge elikufutshane kwi-KV yokubuyela umva.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}