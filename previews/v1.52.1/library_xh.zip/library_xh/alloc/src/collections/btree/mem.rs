use core::intrinsics;
use core::mem;
use core::ptr;

/// Oku kufaka endaweni yexabiso elingasemva kwesalathiso esikhethekileyo se `v` ngokubiza umsebenzi ofanelekileyo.
///
///
/// Ukuba i-panic yenzeka xa kuvalwa i `change`, yonke inkqubo iya kukhutshwa.
#[allow(dead_code)] // gcina njengomzekeliso kunye nokusetyenziswa kwe future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Oku kufaka endaweni yexabiso elingasemva kwesalathiso esikhethekileyo se `v` ngokubiza umsebenzi ofanelekileyo, kwaye kubuyise iziphumo ezifunyenwe apha endleleni.
///
///
/// Ukuba i-panic yenzeka xa kuvalwa i `change`, yonke inkqubo iya kukhutshwa.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}