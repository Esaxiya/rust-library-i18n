use core::marker::PhantomData;
use core::ptr::NonNull;

/// Iimodeli zokuphinda zibuyiswe kwisalathiso esithile, xa usazi ukuba ukubuyisa kunye nayo yonke inzala yayo (okt., Zonke izikhombisi kunye nezalathiso ezivela kuzo) azisayi kuphinda zisetyenziswe ngelinye ixesha, emva koko ufuna ukusebenzisa ireferensi eyodwa eyodwa kwakhona .
///
///
/// Isitsheki sokuboleka sihlala siphatha oku kubekwa kwemali ebolekiweyo kuwe, kodwa ezinye iindlela zokuhamba eziphumeza oku kugcina zinzima kakhulu ukuba zilandelwe ngumhlanganisi.
/// I-`DormantMutRef` ikuvumela ukuba ujonge ukuboleka ngokwakho, ngelixa uchaza ubunjani bayo, kwaye usongele ikhowudi eluhlaza yesikhombisi efunekayo ukwenza oku ngaphandle kokuziphatha okungachazwanga.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Faka imboleko ekhethekileyo, kwaye uyibuyise kwangoko.
    /// Kwisihlanganisi, ixesha lesalathiso esitsha lixesha elifanayo nobomi besalathiso sentsusa, kodwa wena ukuthembisa ukusisebenzisa ixesha elifutshane.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // UKHUSELEKO: sibambe ukuboleka kuyo yonke i 'a nge `_marker`, kwaye siyabhengeza
        // esi sisalathiso kuphela, ke sikhethekile.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Buyela kwimali mboleko eyahlukileyo ebanjiwe ekuqaleni.
    ///
    /// # Safety
    ///
    /// Ukuhlawulwa kwakhona kufanele ukuba kuphelile, okt., Ireferensi ebuyiswe ngu `new` kwaye zonke izikhombisi kunye nezalathiso ezivela kuyo, mazingaphindi zisetyenziswe.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // UKHUSELEKO: iimeko zethu zokhuseleko zithetha ukuba esi sikhombisi siphinde sahlukile.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;