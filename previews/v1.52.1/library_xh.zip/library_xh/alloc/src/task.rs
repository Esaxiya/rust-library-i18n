#![stable(feature = "wake_trait", since = "1.51.0")]
//! Iindidi kunye ne Traits ekusebenzeni kunye nemisebenzi ye-asynchronous.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Ukuphunyezwa kokuvuka komsebenzi kumnini welifa.
///
/// Le trait inokusetyenziselwa ukwenza i [`Waker`].
/// Umgwebi unokuchaza ukuphunyezwa kwale trait, kwaye ayisebenzise ukwakha i-Waker ukuze igqithele kwimisebenzi eyenziwayo kulowo uphumezo.
///
/// Le trait yindlela ekhuselekileyo yokukhumbula kunye ne-ergonomic ekwakheni i [`RawWaker`].
/// Ixhasa uyilo lomsetyenzisi oqhelekileyo apho idatha esetyenziselwa ukuvusa umsebenzi igcinwe kwi [`Arc`].
/// Abanye abaphathi (ngakumbi abo beenkqubo ezifakiwe) abanakho ukusebenzisa le API, yiyo loo nto i [`RawWaker`] ikhona njengenye yezo nkqubo.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Umsebenzi osisiseko we `block_on` othatha i-future kwaye uyiqhube ukugqibezela kumsonto wangoku.
///
/// **Note:** Lo mzekelo urhweba ngokuchanekileyo ukuze kube lula.
/// Ukuthintela ukungavisisani, ukumiliselwa kwebanga lokuvelisa kuya kufuneka kwakhona ukuba liphathe iifowuni eziphakathi eziya kwi `thread::unpark` kunye nokucela izidlo.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Umvusi ovusa umsonto wangoku xa ubizwa.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Sebenzisa i-future ukugqibezela kumsonto wangoku.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Phina i-future ukuze ipolishwe.
///     let mut fut = Box::pin(fut);
///
///     // Yenza umxholo omtsha oza kudluliselwa kwi-future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Sebenzisa i-future ukugqiba.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Vusa lo msebenzi.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Vusa lo msebenzi ngaphandle kokuchitha ixesha lokuvuka.
    ///
    /// Ukuba umgwebi uxhasa indlela engabizi kakhulu yokuvuka ngaphandle kokusebenzisa i-waker, kufanelekile ukuba igqithe kule ndlela.
    /// Ngokuzenzekelayo, idibanisa i [`Arc`] kwaye ibize i-[`wake`] kwi-clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // UKHUSELEKO: Oku kukhuselekile kuba eluhlaza_waker yakha ngokukhuselekileyo
        // I-RawWaker evela kwiArc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Lo msebenzi wabucala wokwakha iRawWaker uyasetyenziswa, kunokuba
// Ukubeka oku kwi-`From<Arc<W>> for RawWaker` impl, ukuqinisekisa ukuba ukhuseleko lwe-`From<Arc<W>> for Waker` aluxhomekekanga kwi-trait echanekileyo yokuhambisa, endaweni yoko zombini ii-impls zibiza lo msebenzi ngokuthe ngqo nangokucacileyo.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Ukonyusa inani lesalathiso se-arc ukuyidibanisa.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Vuka ngexabiso, uhambisa iArc iye kwi-Wake::wake function
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Vuka ngesalathiso, songa i-waker kwi-ManuallyDrop ukunqanda ukuyilahla
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Ukunciphisa ukubalwa kwesalathiso seArc kwithontsi
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}