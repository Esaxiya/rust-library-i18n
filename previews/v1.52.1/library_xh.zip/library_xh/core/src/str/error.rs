//! Chaza uhlobo lwempazamo lwe utf8.

use crate::fmt;

/// Iimpazamo ezinokwenzeka xa uzama ukutolika ulandelelwano lwe [`u8`] njengomtya.
///
/// Kananjalo, usapho lwemisebenzi ye `from_utf8` kunye neendlela zazo zombini [`String`] s kunye [`&str`] s zisebenzisa lempazamo, umzekelo.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Iindlela zolu hlobo lwempazamo zinokusetyenziselwa ukwenza ukusebenza ngokufana ne `String::from_utf8_lossy` ngaphandle kokwaba inqwaba yememori:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Ibuyisa isalathiso kumtya onikiweyo ukuya kuthi ga kwi UTF-8 esebenzayo iqinisekiswe.
    ///
    /// Sisalathiso esiphezulu sokuba i `from_utf8(&input[..index])` ibuyise i `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::str;
    ///
    /// // ezinye ii-byte ezingasebenziyo, kwi-vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Ibuyisela i-Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // i-byte yesibini ayisebenzi apha
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Inika ulwazi oluthe kratya malunga nokusilela:
    ///
    /// * `None`: ukuphela kwegalelo kufikelelwe ngokungalindelekanga.
    ///   `self.valid_up_to()` zi-1 ukuya kwezi-3 nge-byte ukusuka esiphelweni segalelo.
    ///   Ukuba umjelo we-byte (njengefayile okanye isokethi yenethiwekhi) ichongwa ngokungaphezulu, oku kunokuba yi-`char` esebenzayo elandelelwano lwayo lwe-UTF-8 luthatha ii-chunks ezininzi.
    ///
    ///
    /// * `Some(len)`: i-byte engalindelekanga yahlangatyezwa.
    ///   Ubude obunikiweyo bobulandelelwano lwe-byte olungavumelekanga oluqala kwisalathiso esinikezwe yi `valid_up_to()`.
    ///   Ukuchongwa kwakhona kufuneka kuqhubeke emva kolo lungelelwaniso (emva kokufaka i [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) kwimeko yelahleko yokuhlaziya.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Impazamo ibuyisiwe xa kusikwa i `bool` kusetyenziswa i [`from_str`] iyasilela
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}