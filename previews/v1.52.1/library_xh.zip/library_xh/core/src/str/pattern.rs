//! Umtya wePatheni API.
//!
//! I-API yePateni ibonelela ngesixhobo sokwenza generic sokusebenzisa iintlobo ezahlukeneyo zepateni xa ukhangela umtya.
//!
//! Ngolwazi oluthe kratya, jonga i traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], kunye ne [`DoubleEndedSearcher`].
//!
//! Nangona le API ingazinzanga, iyavezwa nge-API ezinzileyo kuhlobo lwe [`str`].
//!
//! # Examples
//!
//! [`Pattern`] yi [implemented][pattern-impls] kwi-API ezinzileyo ye [`&str`][`str`], [`char`], izilayi ze [`char`], kunye nemisebenzi kunye nokuvalwa kokumiliselwa kwe `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // char ipateni
//! assert_eq!(s.find('n'), Some(2));
//! // isilayidi sephatheni yeetshathi
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // iphethini yokuvalwa
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Ipateni yomtya.
///
/// I `Pattern<'a>` ichaza ukuba uhlobo lokuphumeza lunokusetyenziswa njengepatheni yomtya yokukhangela kwi [`&'a str`][str].
///
/// Umzekelo, zombini i `'a'` kunye ne `"aa"` ziipateni ezinokuthi zihambelane nesalathiso `1` kumtya `"baaaab"`.
///
/// I-trait ngokwayo isebenza njengomakhi wohlobo oluhambelana ne [`Searcher`], owenza owona msebenzi wokufumana izehlo zepateni kumtya.
///
///
/// Kuxhomekeke kudidi lwepateni, indlela yokuziphatha ezinje nge [`str::find`] kunye ne [`str::contains`] inokutshintsha.
/// Itheyibhile engezantsi ichaza ezinye zeendlela zokuziphatha.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Umkhangeli odibeneyo wale patheni
    type Searcher: Searcher<'a>;

    /// Yakha isetsheki esidibeneyo kwi `self` kunye ne `haystack` yokukhangela.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Ijonga ukuba ngaba ipateni iyangqinelana na naphina kwitrust
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Ijonga ukuba ngaba ipateni iyangqinelana na phambi kwefula
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Ijonga ukuba ngaba ipateni iyangqinelana na emva kwefula
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Isusa iphethini ngaphambili kwefula, ukuba iyahambelana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // UKHUSELEKO: `Searcher` yaziwa ngokubuyisa ii-indices ezifanelekileyo.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Isusa iphethini ngasemva kwe-haystack, ukuba iyahambelana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // UKHUSELEKO: `Searcher` yaziwa ngokubuyisa ii-indices ezifanelekileyo.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Iziphumo zokubiza i [`Searcher::next()`] okanye i [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Ichaza ukuba umdlalo wepateni ufunyenwe kwi `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Ichaza ukuba i `haystack[a..b]` inqatshelwe njengomdlalo onokwenzeka kwipateni.
    ///
    /// Qaphela ukuba kunokubakho ngaphezulu kwe-`Reject` phakathi kwe-`Match`es ezimbini, akukho mfuneko yokuba zidityaniswe zibe nye.
    ///
    ///
    Reject(usize, usize),
    /// Ichaza ukuba yonke i-byte ye-haystack ityelelwe, iphelisa ukuphindaphindwa kwayo.
    ///
    Done,
}

/// Umkhangeli wepateni yomtya.
///
/// Le trait ibonelela ngeendlela zokukhangela ukungangqinelani komdlalo kwipateni eqala ngaphambili (left) yomtya.
///
/// Iya kuphunyezwa ziindidi ze `Searcher` ezinxulumene ne [`Pattern`] trait.
///
/// I-trait iphawulwe ukuba ayikhuselekanga kuba ii-indices ezibuyiswe ziindlela ze [`next()`][Searcher::next] ziyacelwa ukuba zilele kwimida eyi-utf8 kwindawo yehashe.
/// Oku kwenza ukuba abathengi bale trait batyumle ifula ngaphandle kokutshekishwa kwexesha lokubaleka.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// I-Getter yomtya ophantsi oza kukhangelwa kuyo
    ///
    /// Iya kuhlala ibuyisa i [`&str`][str] efanayo.
    fn haystack(&self) -> &'a str;

    /// Yenza inyathelo elilandelayo lokukhangela ukuqala ngaphambili.
    ///
    /// - Ibuyisa i [`Match(a, b)`][SearchStep::Match] ukuba i `haystack[a..b]` ifana nephethini.
    /// - Ibuyisa i [`Reject(a, b)`][SearchStep::Reject] ukuba i `haystack[a..b]` ayinakuthelekiswa nephethini, nokuba inxenye.
    /// - Ibuyisa i [`Done`][SearchStep::Done] ukuba yonke i-byte yefestile ityelelwe.
    ///
    /// Umjelo we [`Match`][SearchStep::Match] kunye ne [`Reject`][SearchStep::Reject] ukuya kuthi ga kwi [`Done`][SearchStep::Done] uya kuba nezalathiso ezikufutshane, ezingagqumelelaniyo, ezigubungela yonke ifula, kwaye zibeke kwimida ye utf8.
    ///
    ///
    /// Iziphumo ze [`Match`][SearchStep::Match] kufuneka ziqulathe ipateni yonke ehambelana nayo, nangona kunjalo iziphumo ze [`Reject`][SearchStep::Reject] zinokwahlulwa zibe ngamacandelo amaninzi asondeleyo.Zombini ezi zigaba zinokuba nobude obunguziro.
    ///
    /// Umzekelo, iphethini `"aaa"` kunye ne-haystack `"cbaaaaab"` inokuvelisa umlambo
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Fumana iziphumo ezilandelayo ze [`Match`][SearchStep::Match].Jonga i [`next()`][Searcher::next].
    ///
    /// Ngokungafaniyo ne [`next()`][Searcher::next], akukho siqinisekiso sokuba uluhlu olubuyisiweyo loku kunye ne [`next_reject`][Searcher::next_reject] luya kugqitha.
    /// Oku kuyakubuyisa i `(start_match, end_match)`, apho start_match sisalathiso apho umdlalo uqala khona, kwaye end_match sisalathiso emva kokuphela komdlalo.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Fumana iziphumo ezilandelayo ze [`Reject`][SearchStep::Reject].Bona i [`next()`][Searcher::next] kunye ne [`next_match()`][Searcher::next_match].
    ///
    /// Ngokungafaniyo ne [`next()`][Searcher::next], akukho siqinisekiso sokuba uluhlu olubuyisiweyo loku kunye ne [`next_match`][Searcher::next_match] luya kugqitha.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Umkhangeli ophindayo wendlela yomtya.
///
/// Le trait ibonelela ngeendlela zokukhangela ukungangqinelani komdlalo kwipateni eqala ngasemva kwi (right) yomtya.
///
/// Iya kuphunyezwa ziindidi ze [`Searcher`] ezinxulumene ne [`Pattern`] trait ukuba ipateni ixhasa ukuyikhangela ngasemva.
///
///
/// Uluhlu lwesalathiso olubuyiswe yile trait aludingeki ukuba lungqamane ngqo nolo lophendlo lwangaphambili lubuyela umva.
///
/// Isizathu sokuba le trait iphawulwe njengengakhuselekanga, yabona njengomzali trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Yenza inyathelo elilandelayo lokukhangela ukuqala ngasemva.
    ///
    /// - Ibuyisa i [`Match(a, b)`][SearchStep::Match] ukuba i `haystack[a..b]` ifana nephethini.
    /// - Ibuyisa i [`Reject(a, b)`][SearchStep::Reject] ukuba i `haystack[a..b]` ayinakuthelekiswa nephethini, nokuba inxenye.
    /// - Ibuyisa i [`Done`][SearchStep::Done] ukuba yonke i-byte yefestile ityelelwe
    ///
    /// Umjelo we [`Match`][SearchStep::Match] kunye ne [`Reject`][SearchStep::Reject] ukuya kuthi ga kwi [`Done`][SearchStep::Done] uya kuba nezalathiso ezikufutshane, ezingagqumelelaniyo, ezigubungela yonke ifula, kwaye zibeke kwimida ye utf8.
    ///
    ///
    /// Iziphumo ze [`Match`][SearchStep::Match] kufuneka ziqulathe ipateni yonke ehambelana nayo, nangona kunjalo iziphumo ze [`Reject`][SearchStep::Reject] zinokwahlulwa zibe ngamacandelo amaninzi asondeleyo.Zombini ezi zigaba zinokuba nobude obunguziro.
    ///
    /// Umzekelo, iphethini `"aaa"` kunye ne-haystack `"cbaaaaab"` inokuvelisa umjelo `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Fumana isiphumo se [`Match`][SearchStep::Match] esilandelayo.
    /// Jonga i [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Fumana isiphumo se [`Reject`][SearchStep::Reject] esilandelayo.
    /// Jonga i [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Isiphawuli trait Ukuchaza ukuba i [`ReverseSearcher`] inokusetyenziselwa ukumiliselwa kwe [`DoubleEndedIterator`].
///
/// Ngale nto, impl ye [`Searcher`] kunye ne [`ReverseSearcher`] kufuneka ilandele le miqathango:
///
/// - Zonke iziphumo ze `next()` kufuneka zifane kwiziphumo ze `next_back()` ngokulandelelana.
/// - `next()` kwaye i-`next_back()` kufuneka iziphathe njengeziphelo ezibini zoluhlu lwamaxabiso, yiyo loo nto abanakukwazi i "walk past each other".
///
/// # Examples
///
/// `char::Searcher` yi `DoubleEndedSearcher` kuba ukukhangela i [`char`] kufuna kuphela ukujonga enye ngexesha, ethi iziphathe ngokufanayo kuzo zombini iziphelo.
///
/// `(&str)::Searcher` ayisiyi-`DoubleEndedSearcher` kuba iphethini `"aa"` kwindawo ye-haystack `"aaa"` ifana ne `"[aa]a"` okanye i `"a[aa]"`, kuxhomekeka kweliphi icala ekhangelwe kuyo.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl ngetshathi
/////////////////////////////////////////////////////////////////////////////

/// Uhlobo oluhlanganisiweyo lwe `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // Umngeneleli okhuselekileyo: `finger`/`finger_back` kufuneka ibe sisalathiso se-utf8 byte esisebenzayo se-`haystack` Esi singenayo singaphuka *ngaphakathi* kwele_match elandelayo nakwilandelayo_match_mva, nangona kunjalo kufuneka baphume ngeminwe kwimida yekhowudi esebenzayo.
    //
    //
    /// `finger` isalathiso sangoku se-byte yokukhangela phambili.
    /// Khawufane ucinge ukuba ibikhona ngaphambi kwe-byte kwisalathiso sayo, okt
    /// `haystack[finger]` yi-byte yokuqala yesilayidi ekufuneka siyijongile xa sikhangela phambili
    ///
    finger: usize,
    /// `finger_back` isalathiso sangoku se-byte yokukhangela okungasemva.
    /// Khawufane ucinge ukuba ikhona emva kwe-byte kwisalathiso sayo, okt
    /// haystack [ngomnwe_mva, 1] yi-byte yokugqibela yesilayidi ekufuneka siyijongile xa sikhangela phambili (kwaye ke yi-byte yokuqala eya kuhlolwa xa kubizwa i-next_back()).
    ///
    finger_back: usize,
    /// Umlinganiswa okhangelwe
    needle: char,

    // Umngeneleli okhuselekileyo: `utf8_size` kufuneka ibe ngaphantsi kwe-5
    /// Inani lee-byte `needle` linyuka xa lifakwe kwi utf8.
    utf8_size: usize,
    /// Ikopi ye-utf8 ekhowudiweyo ye `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // UKHUSELEKO: 1-4 isiqinisekiso sokhuseleko lwe `get_unchecked`
        // 1. `self.finger` kwaye i `self.finger_back` igcinwe kwimida ye-unicode (oku kungenzeki)
        // 2. `self.finger >= 0` kuba iqala ngo-0 kwaye inyuka kuphela
        // 3. `self.finger < self.finger_back` kuba ngapha koko i-char `iter` ibuya ne `SearchStep::Done`
        // 4.
        // `self.finger` iza ngaphambi kokuphela kwe-haystack kuba i-`self.finger_back` iqala esiphelweni kwaye iyancipha kuphela
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // yongeza i-byte offset yempawu yangoku ngaphandle kokufaka kwakhona i-utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // fumana i-haystack emva komlinganiswa wokugqibela ofunyenweyo
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // I-byte yokugqibela ye-utf8 ekhowudiweyo yenaliti UKHUSELEKO: singenayo i-`utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Umnwe omtsha sisalathiso se-byte esiyifumeneyo, kunye nesinye, kuba simemile kwi-byte yokugqibela yomlinganiswa.
                //
                // Qaphela ukuba oku akusoloko kusinika umnwe kumda we UTF8.
                // Ukuba * asilufumenanga uphawu lwethu sinokuba sikhombise kwi-byte engeyiyo yokugqibela ye-3-byte okanye ye-4-byte.
                // Asinakho ukutsiba siye kwi-byte elandelayo esebenzayo ngenxa yokuba umlinganiswa onje ngo-ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` uya kusoloko sifumana i-byte yesibini xa sikhangela isithathu.
                //
                //
                // Nangona kunjalo, oku kulungile.
                // Ngelixa sinokubangela ukuba i self.finger ikumda we UTF8, le nto ingenzeki ayixhomekekanga kule ndlela (ixhomekeke kwi CharSearcher::next()).
                //
                // Siphuma kuphela kule ndlela xa sifikelela esiphelweni somtya, okanye ukuba sifumana into.Xa sifumana into i `finger` iya kusetwa kumda we UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // akafumananga nto, phuma
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // vumela elandelayo_yala ukusebenzisa ukumiselwa okungagqibekanga kwi-Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // UKHUSELEKO: jonga ingxelo ye next() apha ngasentla
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // thabatha i-byte ye-offset yohlobo lwangoku ngaphandle kokufaka iikhowudi kwakhona njenge-utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // fumana i-haystack ukuya kodwa ungabandakanyi umlingisi wokugqibela okhangekileyo
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // I-byte yokugqibela ye-utf8 ekhowudiweyo yenaliti UKHUSELEKO: singenayo i-`utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // Sikhangele isilayiti esasicinywe yi self.finger, yongeza i self.finger ukuphinda ufumane isalathiso sokuqala
                //
                let index = self.finger + index;
                // memrchr iya kubuyisa isalathiso se-byte esinqwenela ukuyifumana.
                // Kwimeko yomlinganiswa we-ASCII, oku ngenene sinqwenela ukuba umnwe wethu ube ("after" itshati efunyenweyo kwiparadigm yokubuyisa umva).
                //
                // Kwiikhowudi ze-multibyte kufuneka sitsibe phantsi ngenani lee-byte abanazo kune-ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // hambisa umnwe ngaphambi kokuba umlinganiswa afunyenwe (okt, kwisalathiso sokuqala)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Asinakho ukusebenzisa i-finger_back=isalathiso, ubungakanani + 1 apha.
                // Ukuba sifumene itshathi yokugqibela yomlinganiswa owahlukileyo (okanye i-byte ephakathi yomlinganiswa owahlukileyo) kufuneka sibambe umunwe_ubuyele ezantsi uye kwi `index`.
                // Oku ngokufanayo kwenza i `finger_back` ibe nokungabinakho ukuba semngceleni, kodwa oku kulungile kuba sishiya lo msebenzi kuphela emdeni okanye xa ifula yokukhangela ikhangelwe ngokupheleleyo.
                //
                //
                // Ngokungafaniyo next_match le ayinangxaki yeebte eziphindaphindwayo kwi utf-8 kuba sikhangela i-byte yokugqibela, kwaye sinokufumana kuphela i-byte yokugqibela xa sikhangela umva.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // akafumananga nto, phuma
                return None;
            }
        }
    }

    // vumela next_reject_back basebenzise ukumiselwa okungagqibekanga kuMkhangeli we trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Uphendlo lweetshathi ezilingana ne [`char`] enikiweyo.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl yesisongeli seMultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Thelekisa ubude be-byte slice iterator yangaphakathi ukufumana ubude itshathi yangoku
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Thelekisa ubude be-byte slice iterator yangaphakathi ukufumana ubude itshathi yangoku
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Guqula/Susa ngenxa yokungaqondakali kwentsingiselo.

/// Uhlobo oluhlanganisiweyo lwe `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Ukukhangelwa kweetshathi ezilingana nayo nayiphi na i (`char`] kwisilayidi.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Uhlobo oluhlanganisiweyo lwe `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Ukukhangela [`char`] okuhambelana nesivisa esinikiweyo.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye&&str
/////////////////////////////////////////////////////////////////////////////

/// Abathunywa kwi `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye &str
/////////////////////////////////////////////////////////////////////////////

/// Ulwabiwo olungaphantsi kolwabiwo.
///
/// Iya kuphatha iphethini `""` njengokubuyisa umdlalo ongenanto kumda ngamnye womlinganiswa.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Ijonga ukuba ngaba ipateni iyangqinelana na phambi kwefula.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Isusa iphethini ngaphambili kwefula, ukuba iyahambelana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // UKHUSELEKO: isimaphambili siqinisekisiwe nje ukuba sikhona.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Ijonga ukuba ngaba ipateni iyangqinelana na emva kwefula.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Isusa iphethini ngasemva kwe-haystack, ukuba iyahambelana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // UKHUSELEKO: isimamva siqinisekisiwe nje ukuba sikhona.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Indlela ezimbini zomkhangeli osendleleni
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Uhlobo oluhlanganisiweyo lwe `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // inaliti engenanto iyala yonke itshati kwaye itshatisa yonke intambo engenanto phakathi kwabo
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // I-TwoWaySearcher ivelisa ii-indices ezifanelekileyo *zoMdlalo* ezahlulahlula kwimida yetshathi okoko ilinganayo ichanekileyo kwaye ifula kunye nenaliti zisemthethweni UTF-8 *Izinto ezilahliweyo* kwi-algorithm zinokuwa nakweyiphi na indices, kodwa siya kuhamba ngazo ngesandla ukuya kumda womlinganiswa olandelayo, ukuze babe yi-utf-8 bekhuselekile.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // tsiba uye kumda wecala elilandelayo
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // bhala iimeko ze-`true` kunye ne-`false` ukukhuthaza umhlanganisi ukuba enze ngokukodwa la matyala mabini ngokwahlukeneyo.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // tsiba uye kumda wecala elilandelayo
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // bhala i `true` kunye ne `false`, njenge `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Imeko yangaphakathi yeendlela ezimbini zendlela yokukhangela yealgorithm.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// Isalathiso esibalulekileyo sokujonga izinto
    crit_pos: usize,
    /// Isalathiso esibalulekileyo sokubonisa inaliti eguqulweyo
    crit_pos_back: usize,
    period: usize,
    /// `byteset` lulwandiso (olungeyonxalenye yeendlela ezimbini zealgorithm);
    /// ngu-64-bit "fingerprint" apho iseti nganye `j` ingqinelana (byte&63)==j ekhoyo enaliti.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// isalathiso kwinaliti ngaphambili esele sithelekisile
    memory: usize,
    /// isalathiso kwinaliti emva koko sele sithelekisile
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Inkcazo efundeka ngakumbi malunga nokuqhubeka apha inokufumaneka kwiCrocochemore kunye nencwadi kaRytter "Text Algorithms", isahluko 13.
        // Ngokukodwa jonga ikhowudi ye "Algorithm CP" kwiphepha.
        // 323.
        //
        // Kuqhubeka ntoni sinesibakala esibalulekileyo (u, v) senaliti, kwaye sifuna ukufumanisa ukuba ingaba sisimamva se&v [.. ixesha].
        // Ukuba kunjalo, sisebenzisa i "Algorithm CP1".
        // Ngaphandle koko sisebenzisa i-"Algorithm CP2", eyenzelwe ukuba ixesha lenaliti likhulu.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // Ithuba elifutshane-ixesha elichanekileyo libala into ebaluleke kakhulu yenaliti eguqulweyo x=u 'v' apho | v '|<period(x).
            //
            // Oku kukhawuleziswa lixesha lokwaziwa sele.
            // Qaphela ukuba ityala elifana no-x= "acba" linokufakwa ngqo phambili (crit_pos=1, period=3) Ngelixa kufakwa ixesha elimalunga nokubuyela umva (crit_pos=2, period=2).
            // Sisebenzisa ukubuyela umva okunikezelweyo kodwa sigcine ixesha elichanekileyo.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // Ithuba lexesha elide-sinokulinganiswa kwelona xesha, kwaye musa ukusebenzisa ukukhumbula.
            //
            //
            // Uqikelelo lwexesha ngokubopha okungaphantsi kwe max(|u|, |v|) + 1.
            // Izinto ezibaluleke kakhulu ziyasebenza ukuze zisetyenziselwe ukukhangela phambili nangokubuyela umva.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Ixabiso ledummy ukubonisa ukuba ixesha lide
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Olunye uluvo oluphambili kwiNdlela-mbini kukuba siyifaka inaliti ibe ziziqingatha ezibini, (u, v), kwaye siqale ukuzama ukufumana i-v kwishesti ngokuskena ngasekhohlo ukuya ngasekunene.
    // Ukuba ii-v match, sizama ukukutshatisa ngokuskena ngasekunene ukuya ekhohlo.
    // Ukude kangakanani ukuba singatsiba xa sidibana nokungafani konke konke kusekwe kwinto yokuba (u, v) yinto ebalulekileyo yenaliti.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` isebenzisa i `self.position` njengesikhombisi sayo
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Jonga ukuba sinegumbi lokukhangela kwindawo + yenaliti_okugqibela akunakuphuphuma ukuba sithatha izilayi eziboshwe luhlu lwe-isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Tsiba ngokukhawuleza ngamacandelo amakhulu angadibananga nomtya wethu ongaphantsi
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Jonga ukuba icandelo elifanelekileyo lenaliti liyangqinelana
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Jonga ukuba icandelo lasekhohlo lenaliti liyangqinelana
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Sifumene umdlalo!
            let match_pos = self.position;

            // Note: yongeza i-self.period endaweni ye-needle.len() ukuze ube nemidlalo egqagqeneyo
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // setha kwi needle.len(), self.period kwimidlalo edlulayo
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Ulandela izimvo kwi `next()`.
    //
    // Iinkcazo ziyalingana, kunye ne period(x) = period(reverse(x)) kunye ne local_period(u, v) = local_period(reverse(v), reverse(u)), ke ukuba (u, v) yinto ebaluleke kakhulu, kunjalo naku (reverse(v), reverse(u)).
    //
    //
    // Kwimeko yokubuyela umva siye sabala into ebalulekileyo x=u 'v' (intsimi `crit_pos_back`).Sifuna | u |<period(x) yecala lokuya phambili kwaye ngenxa yoko | v '|<period(x) yokubuyela umva.
    //
    // Ukukhangela umva nge-haystack, sikhangela phambili kwisitishi esitshintshileyo senaliti eguqulweyo, ukuthelekisa kuqala u 'kunye v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` isebenzisa i `self.end` njengesikhombisi sayo-ukuze i `next()` kunye ne `next_back()` zizimele.
        //
        let old_end = self.end;
        'search: loop {
            // Jonga ukuba sinegumbi lokukhangela ekugqibeleni, i needle.len() iya kusonga xa kungasekho gumbi, kodwa ngenxa yemida yesilayidi ayinakuze isongele yonke indlela ebuyela kubude be-haystack.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Tsiba ngokukhawuleza ngamacandelo amakhulu angadibananga nomtya wethu ongaphantsi
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Jonga ukuba icandelo lasekhohlo lenaliti liyangqinelana
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Jonga ukuba icandelo elifanelekileyo lenaliti liyangqinelana
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Sifumene umdlalo!
            let match_pos = self.end - needle.len();
            // Note: sub self.period endaweni ye needle.len() yokuba nemidlalo egqagqeneyo
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Yenza isimamva esikhulu se `arr`.
    //
    // Isimamva sobuninzi sisinto esinokubaluleka kakhulu (u, v) se `arr`.
    //
    // Returns (`i`, `p`) apho i `i` sisalathiso sokuqala se-v kunye ne-`p` lixesha le-v.
    //
    // `order_greater` igqiba ukuba i-lexical order ngu-`<` okanye i-`>`.
    // Zombini iiodolo kufuneka zibalwe-uku-odolwa kweyona `i` inkulu kunika into ebalulekileyo.
    //
    //
    // Kumatyala exesha elide, ixesha elibangelwayo alichanekanga (lifutshane kakhulu).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Iyahambelana ne-i ephepheni
        let mut right = 1; // Iyahambelana ne-j ephepheni
        let mut offset = 0; // Iyahambelana k kwiphepha, kodwa ukuqala ngo-0
        // ukutshatisa isalathiso esisekwe ku-0.
        let mut period = 1; // Iyahambelana nep kwiphepha

        while let Some(&a) = arr.get(right + offset) {
            // `left` iya kuba yimida engenayo xa i `right` ikho.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Isimamva sincinci, ixesha sisiphelo sonke ukuza kuthi ga ngoku.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ukuqhubela phambili ngokuphindaphinda kwexesha langoku.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Isimamva sikhulu, qala ngaphezulu ukusuka kule ndawo ukuyo ngoku.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Yenza isimamva esiphezulu se-`arr`.
    //
    // Isimamva sobuninzi sisinto esinokubaluleka kakhulu (u ', v') se `arr`.
    //
    // Ibuyisa i `i` apho i `i` sisalathiso sokuqala se-v ', ngasemva;
    // ibuya kwangoko xa kufikwa kwixesha le `known_period`.
    //
    // `order_greater` igqiba ukuba i-lexical order ngu-`<` okanye i-`>`.
    // Zombini iiodolo kufuneka zibalwe-uku-odolwa kweyona `i` inkulu kunika into ebalulekileyo.
    //
    //
    // Kumatyala exesha elide, ixesha elibangelwayo alichanekanga (lifutshane kakhulu).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Iyahambelana ne-i ephepheni
        let mut right = 1; // Iyahambelana ne-j ephepheni
        let mut offset = 0; // Iyahambelana k kwiphepha, kodwa ukuqala ngo-0
        // ukutshatisa isalathiso esisekwe ku-0.
        let mut period = 1; // Iyahambelana nep kwiphepha
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Isimamva sincinci, ixesha sisiphelo sonke ukuza kuthi ga ngoku.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ukuqhubela phambili ngokuphindaphinda kwexesha langoku.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Isimamva sikhulu, qala ngaphezulu ukusuka kule ndawo ukuyo ngoku.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// I-TwoWayStr Strategy ivumela ialgorithm ukuba itsibe ukungangqinelani ngokukhawuleza okukhulu, okanye isebenze kwimowudi apho ikhupha khona iiRejects ngokukhawuleza.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Tsiba ukutshatisa izithuba ngokukhawuleza okukhulu
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Ukukhutshwa kuyala rhoqo
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}