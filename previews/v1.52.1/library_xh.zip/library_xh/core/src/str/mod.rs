//! Ukukhohlisa umtya.
//!
//! Ngolwazi oluthe kratya, bona imodyuli ye [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ngaphandle kwemida
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. qala <=ukuphela
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. Umda weempawu
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // fumana umlinganiswa
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` kufuneka ubengaphantsi kwelen kunye nomda wetshathi
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Ibuyisa ubude be `self`.
    ///
    /// Obu bude bukue-byte, hayi [`char`] s okanye graphemes.
    /// Ngamanye amagama, isenokungabi yile nto ibonwa ngumntu ubude bomtya.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // f f f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Ibuyisa i `true` ukuba i `self` inobude be-zero byte.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Jonga ukuba `index`-th byte yi-byte yokuqala kulandelelwano lwekhowudi ye UTF-8 okanye ukuphela komtya.
    ///
    ///
    /// Ukuqala nokuphela komtya (xa 'index== self.len()`) ithathwa njengemida.
    ///
    /// Ibuyisa i `false` ukuba i `index` inkulu kune `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // ukuqala kwe `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // Byte yesibini ye `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // I-byte yesithathu ye `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 kunye nelen zihlala zilungile.
        // Vavanya i-0 ngokucacileyo ukuze ikwazi ukwenza itsheki ngokulula kwaye yeqe idatha yokufunda yomtya kwelo tyala.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Lo ngumlingo omncinci olingana no: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Guqula umtya wesilayidi usenze isilayidi seb Byte.
    /// Ukuguqula isilayte sebhetye sibuyele kwisiqwenga somtya, sebenzisa umsebenzi we [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // UKHUSELEKO: isandi se-const kuba sihambisa iintlobo ezimbini ngobeko olufanayo
        unsafe { mem::transmute(self) }
    }

    /// Guqula isilayidi somtya esinokutshintsha siye kwisilayidi se-byte esiguquguqukayo.
    ///
    /// # Safety
    ///
    /// Umntu ofowunayo kufuneka aqinisekise ukuba umxholo wesilayidi uvumelekile nge UTF-8 ngaphambi kokuphela kokuboleka kwaye kusetyenziswa i `str`.
    ///
    ///
    /// Ukusetyenziswa kwe `str` enemixholo yayo ayisebenzi UTF-8 kukungazichazi isimilo.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // UKHUSELEKO: isamente ukusuka kwi `&str` ukuya kwi `&[u8]` ikhuselekile ukusukela nge `str`
        // Ubeko olufanayo ne `&[u8]` (yi-libstd kuphela enokwenza esi siqinisekiso).
        // Isalathiso sesalathiso sikhuselekile kuba sivela kwisalathiso esinokuguquguquka esiqinisekiswe ukuba siyasebenza ukubhala.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Guqula umtya wesilayidi uye kwisikhombisi esiluhlaza.
    ///
    /// Njengamaqhosha omtya sisilayi see-byte, isikhombisi esiluhlaza sikhomba kwi [`u8`].
    /// Esi sikhombisi siya kwalatha kwi-byte yokuqala yesilayidi somtya.
    ///
    /// Umntu ofowunayo makaqinisekise ukuba isikhombisi esibuyisiweyo asibhalelwanga.
    /// Ukuba ufuna ukutshintsha imixholo yesilayidi somtya, sebenzisa i [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Guqula umtya oshukumayo wesilayidi uye kwisikhombisi esiluhlaza.
    ///
    /// Njengamaqhosha omtya sisilayi see-byte, isikhombisi esiluhlaza sikhomba kwi [`u8`].
    /// Esi sikhombisi siya kwalatha kwi-byte yokuqala yesilayidi somtya.
    ///
    /// Luxanduva lwakho ukuqinisekisa ukuba isilayidi somtya silungiswa kuphela ngendlela yokuba sihlale sisebenza i UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Ibuyisa umrhumo we `str`.
    ///
    /// Le yeyona ndlela ingoyikiyo yokwenza isalathiso se `str`.
    /// Ibuyisa i [`None`] nanini na xa kusenziwa isalathiso esilinganayo ku panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ii-indices ezingekho kwimida yokulandelelana kwe UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ngaphandle kwemida
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Ibuyisa i-subslice enokuguquguquka ye `str`.
    ///
    /// Le yeyona ndlela ingoyikiyo yokwenza isalathiso se `str`.
    /// Ibuyisa i [`None`] nanini na xa kusenziwa isalathiso esilinganayo ku panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ubude obuchanekileyo
    /// assert!(v.get_mut(0..5).is_some());
    /// // ngaphandle kwemida
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Ibuyisa i-subsplice engakhange ihlolwe ye `str`.
    ///
    /// Le yindlela engakhange ihlolwe yokwenza isalathiso se `str`.
    ///
    /// # Safety
    ///
    /// Abafowuneli balo msebenzi banoxanduva lokuba le miqathango ibonisiweyo:
    ///
    /// * Isalathiso sokuqala masingagqithi kwisalathiso sokuphela;
    /// * Izalathiso mazibe ngaphakathi kwemida yesilayidi santlandlolo;
    /// * Izalathiso kufuneka zilele kwimida yokulandelelana kwe UTF-8.
    ///
    /// Ukusilela oko, umtya wesilayidi esibuyiselweyo usenokubhekisa kwimemori engasebenziyo okanye wophule izinto ezingenayo ezinikezelwe ngohlobo lwe `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `get_unchecked`;
        // Isilayidi asinakuphinda senziwe kuba i `self` sisalathiso esikhuselekileyo.
        // Isikhombisi esibuyisiweyo sikhuselekile kuba ii-impls ze `SliceIndex` kufuneka ziqinisekise ukuba kunjalo.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Ibuyisa into engahlawulwayo, engakhange ihlolwe ye `str`.
    ///
    /// Le yindlela engakhange ihlolwe yokwenza isalathiso se `str`.
    ///
    /// # Safety
    ///
    /// Abafowuneli balo msebenzi banoxanduva lokuba le miqathango ibonisiweyo:
    ///
    /// * Isalathiso sokuqala masingagqithi kwisalathiso sokuphela;
    /// * Izalathiso mazibe ngaphakathi kwemida yesilayidi santlandlolo;
    /// * Izalathiso kufuneka zilele kwimida yokulandelelana kwe UTF-8.
    ///
    /// Ukusilela oko, umtya wesilayidi esibuyiselweyo usenokubhekisa kwimemori engasebenziyo okanye wophule izinto ezingenayo ezinikezelwe ngohlobo lwe `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `get_unchecked_mut`;
        // Isilayidi asinakuphinda senziwe kuba i `self` sisalathiso esikhuselekileyo.
        // Isikhombisi esibuyisiweyo sikhuselekile kuba ii-impls ze `SliceIndex` kufuneka ziqinisekise ukuba kunjalo.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Yenza umtya wesilayidi ukusuka kolunye ucezu lomtya, ngokudlula kuhlolo lokhuseleko.
    ///
    /// Oku akukhuthazwa ngokubanzi, sebenzisa ngononophelo!Ukhetho olukhuselekileyo jonga i [`str`] kunye ne [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Esi silayi sitsha sisuka kwi `begin` siye kwi `end`, kubandakanya i `begin` kodwa ngaphandle kwe `end`.
    ///
    /// Ukufumana isilayidi somtya onokutshintsha endaweni yoko, bona indlela ye [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Abafowuneli balo msebenzi banoxanduva lokuba imiqathango emithathu yanelisekile:
    ///
    /// * `begin` akufuneki idlule kwi `end`.
    /// * `begin` kwaye i `end` kufuneka ibe zizikhundla ze-byte ngaphakathi kwesilayidi somtya.
    /// * `begin` kwaye i `end` kufuneka ilele kwimida yokulandelelana kwe UTF-8.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `get_unchecked`;
        // Isilayidi asinakuphinda senziwe kuba i `self` sisalathiso esikhuselekileyo.
        // Isikhombisi esibuyisiweyo sikhuselekile kuba ii-impls ze `SliceIndex` kufuneka ziqinisekise ukuba kunjalo.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Yenza umtya wesilayidi ukusuka kolunye ucezu lomtya, ngokudlula kuhlolo lokhuseleko.
    /// Oku akukhuthazwa ngokubanzi, sebenzisa ngononophelo!Ukhetho olukhuselekileyo jonga i [`str`] kunye ne [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Esi silayi sitsha sisuka kwi `begin` siye kwi `end`, kubandakanya i `begin` kodwa ngaphandle kwe `end`.
    ///
    /// Ukufumana umtya ongashukumiyo endaweni yoko, bona indlela ye [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Abafowuneli balo msebenzi banoxanduva lokuba imiqathango emithathu yanelisekile:
    ///
    /// * `begin` akufuneki idlule kwi `end`.
    /// * `begin` kwaye i `end` kufuneka ibe zizikhundla ze-byte ngaphakathi kwesilayidi somtya.
    /// * `begin` kwaye i `end` kufuneka ilele kwimida yokulandelelana kwe UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `get_unchecked_mut`;
        // Isilayidi asinakuphinda senziwe kuba i `self` sisalathiso esikhuselekileyo.
        // Isikhombisi esibuyisiweyo sikhuselekile kuba ii-impls ze `SliceIndex` kufuneka ziqinisekise ukuba kunjalo.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Yahlulahlula umtya omnye kwisilayidi kwisalathiso.
    ///
    /// Impikiswano, i `mid`, kufanele ukuba ibe yinto eshiyekileyo ukusuka ekuqaleni komtya.
    /// Kuya kufuneka ibe kumda we UTF-8 ikhowudi yenqaku.
    ///
    /// Amacwecwe amabini abuyile aqala ekuqaleni kwesilayidi somtya ukuya kwi `mid`, kwaye ukusuka kwi `mid` ukuya esiphelweni sesilayidi somtya.
    ///
    /// Ukufumana izilayi zomtya ezinokutshintsha endaweni yoko, bona indlela ye [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `mid` ayikho kumda wekhowudi ye UTF-8, okanye ukuba idlulile esiphelweni senqaku lokugqibela lekhowudi yesilayidi somtya.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // ngu_char_boundary ujonga ukuba isalathiso sikwi [0, .len()]
        if self.is_char_boundary(mid) {
            // UKHUSELEKO: ujonge nje ukuba i `mid` ikumda weetshathi.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Yahlula-hlula isilayi esinye somtya onokuguqulelwa kubini kwisalathiso.
    ///
    /// Impikiswano, i `mid`, kufanele ukuba ibe yinto eshiyekileyo ukusuka ekuqaleni komtya.
    /// Kuya kufuneka ibe kumda we UTF-8 ikhowudi yenqaku.
    ///
    /// Amacwecwe amabini abuyile aqala ekuqaleni kwesilayidi somtya ukuya kwi `mid`, kwaye ukusuka kwi `mid` ukuya esiphelweni sesilayidi somtya.
    ///
    /// Ukufumana izilayi zomtya ezingashukumiyo endaweni yoko, bona indlela ye [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `mid` ayikho kumda wekhowudi ye UTF-8, okanye ukuba idlulile esiphelweni senqaku lokugqibela lekhowudi yesilayidi somtya.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // ngu_char_boundary ujonga ukuba isalathiso sikwi [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // UKHUSELEKO: ujonge nje ukuba i `mid` ikumda weetshathi.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Ibuyisa iterator ngaphezulu kwe [`char`] s yomtya wesilayidi.
    ///
    /// Njengoko isilayidi somtya sine-UTF-8 esemthethweni, sinokulinganisa ngentambo yesilayidi nge [`char`].
    /// Le ndlela ibuyisela i-iterator enjalo.
    ///
    /// Kubalulekile ukuba ukhumbule ukuba i-[`char`] imele ixabiso le-Unicode Scalar, kwaye isenokungafani nombono wakho wokuba yintoni i-'character'.
    ///
    /// Ukuphindaphindwa kwamaqela e-grapheme kunokuba yile nto uyifunayo.
    /// Oku kusebenza akubonelelwa lilayibrari esemgangathweni ye Rust, jonga i crates.io endaweni yoko.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Khumbula, [`char`] ayinakuthelekisa inkuku yakho malunga nabalinganiswa:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // hayi i 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Ibuyisa iterator ngaphezulu kwe (`char`] s yomtya wesilayidi, kunye nezikhundla zazo.
    ///
    /// Njengoko isilayidi somtya sine-UTF-8 esemthethweni, sinokulinganisa ngentambo yesilayidi nge [`char`].
    /// Le ndlela ibuyisela i-iterator yazo zombini ezi zinto (`char`], kunye nezikhundla zazo.
    ///
    /// Iterator ivelisa iziqwengana.Indawo yokuqala, i [`char`] yesibini.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Khumbula, [`char`] ayinakuthelekisa inkuku yakho malunga nabalinganiswa:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // hayi (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // Qaphela u-3 apha, umlinganiswa wokugqibela uthathe ii-byte ezimbini
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Iterator ngaphezulu kwee-byte zomtya wesilayidi.
    ///
    /// Njengomtya wesilayidi uqulethe ulandelelwano lwee-byte, sinokulinganisa ngentambo yesilayidi nge-byte.
    /// Le ndlela ibuyisela i-iterator enjalo.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Ukwahlula isilayidi somtya nge-whitespace.
    ///
    /// Iserator esibuyisiweyo siya kubuyisa izilayi zomtya eziziisilayi somtya wokuqala, ohlukaniswe naliphi na inani lemhlophe.
    ///
    ///
    /// 'Whitespace' ichazwa ngokwemiqathango ye-Unicode yeDrop Propert `White_Space`.
    /// Ukuba ufuna ukwahlulahlula indawo emhlophe ye-ASCII endaweni yoko, sebenzisa i [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Zonke iintlobo zobumhlophe ziqwalaselwe:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Ukwahlula isilayidi somtya nge-ASCII whitespace.
    ///
    /// Iserator esibuyisiweyo siya kubuyisa izilayi zomtya eziziisilayi somtya wokuqala, ohlukaniswe naliphi na inani lendawo emhlophe ye-ASCII.
    ///
    ///
    /// Ukwahlulahlula nge-Unicode `Whitespace` endaweni yoko, sebenzisa i [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Zonke iintlobo ze-ASCII whitespace ziqwalaselwe:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// I-iterator ngaphezulu kwemigca yomtya, njengezilayi zomtya.
    ///
    /// Imigca igqityiwe nokuba kungomnxeba omtsha u (`\n`) okanye ukubuya kwenqwelomoya ngomxhesho we-(`\r\n`).
    ///
    /// Ukuphela komgca wokugqibela kukukhetha.
    /// Umtya ophela ngomgca wokugqibela oya kuthi ubuyise imigca efanayo nomtya ofanayo ngaphandle komgca wokugqibela ophela.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Ukuphela komgca wokugqibela akufuneki:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Iterator ngaphezulu kwemigca yomtya.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Ibuyisa i-iterator ye-`u16` ngaphezulu komtya ofakwe kwi-UTF-16.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Ibuyisa i `true` ukuba ipateni enikiweyo ithelekisa isilayidi salolu chungechunge lomtya.
    ///
    /// Ibuyisa i `false` ukuba ayenzi njalo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Ibuyisa i `true` ukuba ipateni enikiweyo ithelekisa isimaphambili sesi silayi somtya.
    ///
    /// Ibuyisa i `false` ukuba ayenzi njalo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Ibuyisa i `true` ukuba ipateni enikiweyo ithelekisa isimamva sesi silayi somtya.
    ///
    /// Ibuyisa i `false` ukuba ayenzi njalo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Ibuyisa i-byte index yesimilo sokuqala salomtya wesilayi ohambelana nepateni.
    ///
    /// Ibuyisa i [`None`] ukuba ipateni ayihambelani.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Iipateni ezilula:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Iipateni ezinzima ngakumbi zisebenzisa isitayile esingena-point kunye nokuvalwa:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Ayifumani patheni:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Ibuyisa isalathiso se-byte yomlinganiswa wokuqala kumdlalo ofanelekileyo wepatheni kulayini wesilayidi.
    ///
    /// Ibuyisa i [`None`] ukuba ipateni ayihambelani.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Iipateni ezilula:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Iipateni ezintsonkothileyo ngokuvalwa:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Ayifumani patheni:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Iserator ngaphezulu kwemitya esecaleni yomtya, ohlukaniswe ngoonobumba abahambelana nepateni.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// I-iterator ebuyisiweyo iya kuba yi-[`DoubleEndedIterator`] ukuba iphethini ivumela ukukhangela okungaphaya kwaye i-forward/reverse yokukhangela ivelisa izinto ezifanayo.
    /// Kuyinyani oku, umzekelo, [`char`], kodwa hayi i `&str`.
    ///
    /// Ukuba iphethini ivumela ukukhangela okungafaniyo kodwa iziphumo zayo zinokwahluka kuphando lwangaphambili, indlela ye [`rsplit`] inokusetyenziswa.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Iipateni ezilula:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Ukuba ipateni sisilayi seemoto, yahlulahlula imeko nganye yabalinganiswa:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Iphethini entsonkothileyo, usebenzisa ukuvalwa:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ukuba umtya uqulethe izinto ezininzi ezahlulayo, uya kuphelela ngentambo engenanto kwimveliso:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Umahluli odibeneyo wahlulwe ngumtya ongenanto.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Izahluli ekuqaleni okanye esiphelweni somtya zingqonge imitya engenanto.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Xa umtya ongenanto usetyenziswa njengomahluli, wahlula zonke izinto ezikumtya, kunye nesiqalo nesiphelo somtya.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Umahluli odibeneyo unokukhokelela kwindlela yokuziphatha engamangalisiyo xa isithuba esimhlophe sisetyenziswa njengomahluli.Le khowudi ichanekile:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Ngaba i _not_ ikunika:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Sebenzisa i [`split_whitespace`] kule ndlela yokuziphatha.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Iserator ngaphezulu kwemitya esecaleni yomtya, ohlukaniswe ngoonobumba abahambelana nepateni.
    /// Umahluko kwi-iterator eveliswe yi-`split` kuloo `split_inclusive` ishiya indawo ehambelana nayo njengesiphelo sesiseko.
    ///
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ukuba into yokugqibela yomtya iyahambelana, loo nto iya kuqwalaselwa njengesiphelo sendlela engaphambili.
    /// Oo-substring baya kuba yinto yokugqibela ebuyiswe ngumsetyenzisi.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Iserator ngaphezulu kwemitya esezantsi yomtya osikiweyo, ohlukaniswe ngoonobumba abahambelana nephethini kwaye yaveliswa ngokulandelelana.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// I-iterator ebuyisiweyo ifuna ukuba ipateni ixhase ukukhangela okuguqukayo, kwaye iya kuba yi-[`DoubleEndedIterator`] ukuba ukukhangela kwe-forward/reverse kuvelisa izinto ezifanayo.
    ///
    ///
    /// Ukulungiselela ngaphambili, indlela ye [`split`] inokusetyenziswa.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Iipateni ezilula:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Iphethini entsonkothileyo, usebenzisa ukuvalwa:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Iserator ngaphezulu kwemitya esezantsi yomtya osikiweyo, ohlukaniswe ngoonobumba abahambelana nepateni.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ilingana ne-[`split`], ngaphandle kokuba i-trailing substring itsiwe ukuba ayinanto.
    ///
    /// [`split`]: str::split
    ///
    /// Le ndlela inokusetyenziselwa idatha yomtya eyi-_terminated_, endaweni ye _separated_ yipateni.
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// I-iterator ebuyisiweyo iya kuba yi-[`DoubleEndedIterator`] ukuba iphethini ivumela ukukhangela okungaphaya kwaye i-forward/reverse yokukhangela ivelisa izinto ezifanayo.
    /// Kuyinyani oku, umzekelo, [`char`], kodwa hayi i `&str`.
    ///
    /// Ukuba iphethini ivumela ukukhangela okungafaniyo kodwa iziphumo zayo zinokwahluka kuphando lwangaphambili, indlela ye [`rsplit_terminator`] inokusetyenziswa.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Iserator ngaphezulu kwemitya esezantsi ye `self`, eyahlulwe ngoonobumba abafaniswe nephethini kwaye yaveliswa ngokulandelelana.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ilingana ne-[`split`], ngaphandle kokuba i-trailing substring itsiwe ukuba ayinanto.
    ///
    /// [`split`]: str::split
    ///
    /// Le ndlela inokusetyenziselwa idatha yomtya eyi-_terminated_, endaweni ye _separated_ yipateni.
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// I-iterator ebuyisiweyo ifuna ukuba ipateni ixhase ukukhangela okuguqukayo, kwaye iya kupheliswa kabini ukuba ukukhangela kwe forward/reverse kuvelisa izinto ezifanayo.
    ///
    ///
    /// Ukulungiselela ngaphambili, indlela ye [`split_terminator`] inokusetyenziswa.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Iserator ngaphezulu kwemitya esezantsi yomtya osikiweyo, eyahlulwe yipateni, ithintelwe ekubuyiseni izinto ezininzi ze `n`.
    ///
    /// Ukuba i-`n` substrings ibuyisiwe, i-substring yokugqibela (i-n`th substring) iya kuba nentsalela yomtya.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// Iterator ebuyisiweyo ayinakupheliswa kabini, kuba ayisebenzi ukuxhasa.
    ///
    /// Ukuba iphethini ivumela ukukhangela okubuyela umva, indlela ye [`rsplitn`] inokusetyenziswa.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Iipateni ezilula:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Iphethini entsonkothileyo, usebenzisa ukuvalwa:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// I-iterator ngaphezulu kwemitya esezantsi yoluhlu lwesilayidi, eyahlulwe yipateni, ukuqala esiphelweni somtya, kuthintelwe ekubuyiseni izinto ezininzi ze `n`.
    ///
    ///
    /// Ukuba i-`n` substrings ibuyisiwe, i-substring yokugqibela (i-n`th substring) iya kuba nentsalela yomtya.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// Iterator ebuyisiweyo ayinakupheliswa kabini, kuba ayisebenzi ukuxhasa.
    ///
    /// Ukwahlulahlula phambili, indlela ye [`splitn`] inokusetyenziswa.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Iipateni ezilula:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Iphethini entsonkothileyo, usebenzisa ukuvalwa:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Ukwahlula umtya kwimeko yokuqala yedelimitha echaziweyo kwaye ubuyisele isimaphambili ngaphambi kwedelimitha kunye nesimamva emva kwedelimitha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Ukwahlula umtya kwisehlo sokugqibela sedelimitha echaziweyo kwaye ubuyisele isimaphambili ngaphambi kwedelimitha kunye nesimamva emva kwedelimitha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Iterator ngaphezulu komdlalo ongadibananga wepateni ngaphakathi kwesilayidi somtya osinikiweyo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// I-iterator ebuyisiweyo iya kuba yi-[`DoubleEndedIterator`] ukuba iphethini ivumela ukukhangela okungaphaya kwaye i-forward/reverse yokukhangela ivelisa izinto ezifanayo.
    /// Kuyinyani oku, umzekelo, [`char`], kodwa hayi i `&str`.
    ///
    /// Ukuba iphethini ivumela ukukhangela okungafaniyo kodwa iziphumo zayo zinokwahluka kuphando lwangaphambili, indlela ye [`rmatches`] inokusetyenziswa.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Iserator ngaphezulu komdlalo ongadibananga wepateni ngaphakathi kwesi silayi somtya, siveliswe ngokulandelelana.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// I-iterator ebuyisiweyo ifuna ukuba ipateni ixhase ukukhangela okuguqukayo, kwaye iya kuba yi-[`DoubleEndedIterator`] ukuba ukukhangela kwe-forward/reverse kuvelisa izinto ezifanayo.
    ///
    ///
    /// Ukulungiselela ngaphambili, indlela ye [`matches`] inokusetyenziswa.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Iterator ngaphezulu komdlalo ongadibananga wepateni ngaphakathi kwesi silayi somtya kunye nesalathiso esiqala kulo mdlalo.
    ///
    /// Kwimidlalo ye `pat` ngaphakathi kwe `self` edlulayo, zii-indices kuphela ezihambelana nomdlalo wokuqala ezibuyisiweyo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// I-iterator ebuyisiweyo iya kuba yi-[`DoubleEndedIterator`] ukuba iphethini ivumela ukukhangela okungaphaya kwaye i-forward/reverse yokukhangela ivelisa izinto ezifanayo.
    /// Kuyinyani oku, umzekelo, [`char`], kodwa hayi i `&str`.
    ///
    /// Ukuba iphethini ivumela ukukhangela okungafaniyo kodwa iziphumo zayo zinokwahluka kuphando lwangaphambili, indlela ye [`rmatch_indices`] inokusetyenziswa.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // kuphela i `aba` yokuqala
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Iserator ngaphezulu komdlalo ongadibananga wepateni ngaphakathi kwe `self`, eveliswe ngokulandelelana kunye nesalathiso somdlalo.
    ///
    /// Kwimidlalo ye `pat` ngaphakathi kwe `self` edlulayo, kuphela zii-indices ezihambelana nomdlalo wokugqibela ezibuyiswayo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuziphatha kwe-Iterator
    ///
    /// I-iterator ebuyisiweyo ifuna ukuba ipateni ixhase ukukhangela okuguqukayo, kwaye iya kuba yi-[`DoubleEndedIterator`] ukuba ukukhangela kwe-forward/reverse kuvelisa izinto ezifanayo.
    ///
    ///
    /// Ukulungiselela ngaphambili, indlela ye [`match_indices`] inokusetyenziswa.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // kuphela yi `aba` yokugqibela
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Buyisela umtya wesilayidi ngokukhokelela kunye nokuhamba mhlophe kususwe.
    ///
    /// 'Whitespace' ichazwa ngokwemiqathango ye-Unicode yeDrop Propert `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Buyisela umtya wesilayidi kunye nendawo emhlophe ekhokelayo isusiwe.
    ///
    /// 'Whitespace' ichazwa ngokwemiqathango ye-Unicode yeDrop Propert `White_Space`.
    ///
    /// # Ukuyalela isicatshulwa
    ///
    /// Umtya lulandelelwano lwee-byte.
    /// `start` kule meko kuthetha indawo yokuqala yala ntambo ye-byte;kulwimi lwasekhohlo ukuya ekunene njengesiNgesi okanye isiRashiya, oku kuya kuba kwicala lasekhohlo, kwaye kwiilwimi zasekunene ukuya ngasekhohlo njengeArabhu okanye isiHebhere, eli iya kuba licala lasekunene.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Buyisela umtya wesilayidi kususwe indawo emhlophe.
    ///
    /// 'Whitespace' ichazwa ngokwemiqathango ye-Unicode yeDrop Propert `White_Space`.
    ///
    /// # Ukuyalela isicatshulwa
    ///
    /// Umtya lulandelelwano lwee-byte.
    /// `end` kule meko kuthetha indawo yokugqibela yaloo ntambo ye-byte;kulwimi lwasekhohlo ukuya ekunene njengesiNgesi okanye isiRashiya, oku kuya kuba kwicala lasekunene, kwaye kwiilwimi zasekunene ukuya ngasekhohlo njengeArabhu okanye isiHebhere, eli iya kuba licala lasekhohlo.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Buyisela umtya wesilayidi kunye nendawo emhlophe ekhokelayo isusiwe.
    ///
    /// 'Whitespace' ichazwa ngokwemiqathango ye-Unicode yeDrop Propert `White_Space`.
    ///
    /// # Ukuyalela isicatshulwa
    ///
    /// Umtya lulandelelwano lwee-byte.
    /// 'Left' kule meko kuthetha indawo yokuqala yala ntambo ye-byte;kulwimi olufana nesiArabhu okanye isiHebhere 'ekunene ukuya ekhohlo' endaweni yokuba 'ushiye ekunene', eli iya kuba licala le _right_, hayi ekhohlo.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Buyisela umtya wesilayidi kususwe indawo emhlophe.
    ///
    /// 'Whitespace' ichazwa ngokwemiqathango ye-Unicode yeDrop Propert `White_Space`.
    ///
    /// # Ukuyalela isicatshulwa
    ///
    /// Umtya lulandelelwano lwee-byte.
    /// 'Right' kule meko kuthetha indawo yokugqibela yaloo ntambo ye-byte;kulwimi olufana nesiArabhu okanye isiHebhere 'ekunene ukuya ekhohlo' endaweni yokuba 'ushiye ekunene', eli iya kuba licala le _left_, hayi ilungelo.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Ibuyisa umtya wesilayidi kunye nazo zonke izimaphambili kunye nezimamva ezihambelana nephethini zisuswe ngokuphindaphindiweyo.
    ///
    /// I [pattern] inokuba yi [`char`], isilayidi se [`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Iipateni ezilula:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Iphethini entsonkothileyo, usebenzisa ukuvalwa:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Khumbula umdlalo wokuqala owaziwayo, ulungise apha ngezantsi ukuba
            // Umdlalo wokugqibela wahlukile
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // UKHUSELEKO: `Searcher` yaziwa ngokubuyisa ii-indices ezifanelekileyo.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Ibuyisa umtya wesilayidi kunye nazo zonke izimaphambili ezihambelana nephethini isuswe rhoqo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuyalela isicatshulwa
    ///
    /// Umtya lulandelelwano lwee-byte.
    /// `start` kule meko kuthetha indawo yokuqala yala ntambo ye-byte;kulwimi lwasekhohlo ukuya ekunene njengesiNgesi okanye isiRashiya, oku kuya kuba kwicala lasekhohlo, kwaye kwiilwimi zasekunene ukuya ngasekhohlo njengeArabhu okanye isiHebhere, eli iya kuba licala lasekunene.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // UKHUSELEKO: `Searcher` yaziwa ngokubuyisa ii-indices ezifanelekileyo.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Buyisela umtya isilayi kunye isimaphambili sisuswe.
    ///
    /// Ukuba umtya uqala ngephethini `prefix`, ubuyisela umtya emva kwesimaphambili, esongelwe kwi `Some`.
    /// Ngokungafaniyo ne `trim_start_matches`, le ndlela isusa isimaphambili kanye kube kanye.
    ///
    /// Ukuba umtya awuqali nge-`prefix`, ubuyisela i-`None`.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Buyisela umtya wesilayidi kunye nesimamva sisuswe.
    ///
    /// Ukuba umtya uphela ngephethini `suffix`, ubuyisela umtya ngaphambi kwesimamva, esongelwe ngo `Some`.
    /// Ngokungafaniyo ne `trim_end_matches`, le ndlela isusa isimamva ngokuchanekileyo kanye.
    ///
    /// Ukuba umtya awupheli ngo-`suffix`, ubuyisela i-`None`.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Ibuyisa umtya wesilayidi kunye nazo zonke izimamva ezihambelana nephethini isuswe ngokuphindaphindiweyo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuyalela isicatshulwa
    ///
    /// Umtya lulandelelwano lwee-byte.
    /// `end` kule meko kuthetha indawo yokugqibela yaloo ntambo ye-byte;kulwimi lwasekhohlo ukuya ekunene njengesiNgesi okanye isiRashiya, oku kuya kuba kwicala lasekunene, kwaye kwiilwimi zasekunene ukuya ngasekhohlo njengeArabhu okanye isiHebhere, eli iya kuba licala lasekhohlo.
    ///
    ///
    /// # Examples
    ///
    /// Iipateni ezilula:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Iphethini entsonkothileyo, usebenzisa ukuvalwa:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // UKHUSELEKO: `Searcher` yaziwa ngokubuyisa ii-indices ezifanelekileyo.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Ibuyisa umtya wesilayidi kunye nazo zonke izimaphambili ezihambelana nephethini isuswe rhoqo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuyalela isicatshulwa
    ///
    /// Umtya lulandelelwano lwee-byte.
    /// 'Left' kule meko kuthetha indawo yokuqala yala ntambo ye-byte;kulwimi olufana nesiArabhu okanye isiHebhere 'ekunene ukuya ekhohlo' endaweni yokuba 'ushiye ekunene', eli iya kuba licala le _right_, hayi ekhohlo.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Ibuyisa umtya wesilayidi kunye nazo zonke izimamva ezihambelana nephethini isuswe ngokuphindaphindiweyo.
    ///
    /// I [pattern] inokuba yi `&str`, [`char`], isilayidi se (`char`] s, okanye umsebenzi okanye ukuvalwa okumisela ukuba umlinganiswa uyalingana.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ukuyalela isicatshulwa
    ///
    /// Umtya lulandelelwano lwee-byte.
    /// 'Right' kule meko kuthetha indawo yokugqibela yaloo ntambo ye-byte;kulwimi olufana nesiArabhu okanye isiHebhere 'ekunene ukuya ekhohlo' endaweni yokuba 'ushiye ekunene', eli iya kuba licala le _left_, hayi ilungelo.
    ///
    ///
    /// # Examples
    ///
    /// Iipateni ezilula:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Iphethini entsonkothileyo, usebenzisa ukuvalwa:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Ukwahlulahlula lo mtya kolunye uhlobo.
    ///
    /// Kuba i `parse` ixhaphake kakhulu, inokubangela iingxaki kuhlobo lokuthotyelwa.
    /// Kananjalo, i `parse` lelinye lamaxesha ambalwa oza kuyibona is syntax eyaziwa ngokuba yi 'turbofish': `::<>`.
    ///
    /// Oku kunceda i-inference algorithm ukuqonda ngokuthe ngqo ukuba loluphi uhlobo ozama ukungena kulo.
    ///
    /// `parse` unokudlula kulo naluphi na uhlobo olusebenzisa i [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Ndiza kubuyisa i [`Err`] ukuba akunakwenzeka ukubonakalisa olu luhlu lomtya kuhlobo olufunwayo.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Ukusetyenziswa okusisiseko
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Sebenzisa i 'turbofish' endaweni yokuchaza i `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Ukusilela ukwahlula:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Jonga ukuba bonke oonobumba abakulo mtya bakuluhlu lwe-ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Singaphatha i-byte nganye njengophawu apha: bonke oonobumba be-multibyte baqala nge-byte engekho kuluhlu lwe-ascii, ke siza kuma apho sele.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Jonga ukuba imitya emibini ngumdlalo we-ASCII ongakhathaliyo.
    ///
    /// Iyafana ne `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, kodwa ngaphandle kokwaba kunye nokukopa okwethutyana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Guqula lo mtya uye kwi-ASCII ephezulu yamatyala alinganayo endaweni.
    ///
    /// Iileta ze-ASCII 'a' ukuya kwi 'z' zimiselwe imephu ukuya kwi 'A' ukuya kwi 'Z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukubuyisa ixabiso elitsha elingasetyenziswanga ngaphandle kokuguqula esele ikho, sebenzisa i [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // UKHUSELEKO: kukhuselekile kuba sihambisa iintlobo ezimbini ngobeko olufanayo.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Guqula lo mtya uye kwi-ASCII esezantsi kwimeko yokulingana endaweni.
    ///
    /// Iileta ze-ASCII 'A' ukuya kwi 'Z' zimiselwe imephu ukuya kwi 'a' ukuya kwi 'z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukubuyisa ixabiso elitsha elisezantsi ngaphandle kokuguqula esele ikho, sebenzisa i [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // UKHUSELEKO: kukhuselekile kuba sihambisa iintlobo ezimbini ngobeko olufanayo.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Buyisela iterator ebaleka itshathi nganye kwi `self` nge [`char::escape_debug`].
    ///
    ///
    /// Note: Kuphela ziikhowudi zegrafim ezandisiweyo eziqala umtya eziya kusinda.
    ///
    /// # Examples
    ///
    /// Njenge iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Zombini ziyalingana:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Sebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Buyisela iterator ebaleka itshathi nganye kwi `self` nge [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Njenge iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Zombini ziyalingana:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Sebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Buyisela iterator ebaleka itshathi nganye kwi `self` nge [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Njenge iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Zombini ziyalingana:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Sebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Yenza umtya ongenanto
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Yenza umtya ongenanto ongenakuguqulwa
    #[inline]
    fn default() -> Self {
        // UKHUSELEKO: Umtya ongenanto uvumelekile UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Uhlobo lwe-fn olunamagama, olunokubakho
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // UKHUSELEKO: ayikhuselekanga
        unsafe { from_utf8_unchecked(bytes) }
    };
}