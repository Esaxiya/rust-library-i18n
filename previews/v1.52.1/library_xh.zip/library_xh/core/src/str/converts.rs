//! Iindlela zokwenza i `str` kwii-byte slice.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Guqula isilayidi see-byte siye kwisilayidi somtya.
///
/// Uluhlu lwesilayidi i-([`&str`]) lwenziwe ngee-byte ([`u8`]), kwaye isilayidi se-byte ([`&[u8]`][byteslice]) senziwe ngee-byte, ke lo msebenzi uguqula phakathi kwezi zimbini.
/// Ayizizo zonke izilayi ze-byte ezizilayini zomtya ezifanelekileyo, nangona kunjalo: i-[`&str`] ifuna ukuba isebenze i-UTF-8.
/// `from_utf8()` kutshekishwa ukuqinisekisa ukuba ii-byte zisemthethweni UTF-8, emva koko yenza uguquko.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ukuba uqinisekile ukuba isilayidi se-byte sisemthethweni UTF-8, kwaye awufuni kungena kwintloko yokujonga ubunyani, kukho ingxelo engakhuselekanga yalo msebenzi, i-[`from_utf8_unchecked`], enendlela yokuziphatha efanayo kodwa yeqa itsheki.
///
///
/// Ukuba ufuna i `String` endaweni ye `&str`, jonga i [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Kuba ungabeka isitaki kwi-`[u8; N]`, kwaye ungathatha i-[`&[u8]`][byteslice] yayo, lo msebenzi yenye yeendlela ezinokubekwa ngumtya.Kukho umzekelo woku kwicandelo lemizekelo elingezantsi.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Ibuyisa i `Err` ukuba isilayi ayisiyi-UTF-8 nenkcazo yokuba kutheni isilayidi esibonelelweyo singesiso i UTF-8.
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::str;
///
/// // ezinye i-byte, kwi-vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Siyazi ukuba ezi bhayithi zivumelekile, ke sebenzisa i `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Ii-byte ezingachanekanga:
///
/// ```
/// use std::str;
///
/// // ezinye ii-byte ezingasebenziyo, kwi-vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Bona amaxwebhu e [`Utf8Error`] ngeenkcukacha ezithe kratya kwiindidi zeempazamo ezinokubuyiselwa.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // Ezinye ii-byte, kuluhlu olunikiweyo
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Siyazi ukuba ezi bhayithi zivumelekile, ke sebenzisa i `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // UKHUSELEKO: Sebenzisa nje ukungqinisisa.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Guqula isilayidi esinokuguquguquka sebayithi kwisilayidi somtya esinokuguquguquka.
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" njengokuguquguquka kwe vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Njengoko sisazi ezi bhayithi zisemthethweni, singasebenzisa i `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Ii-byte ezingachanekanga:
///
/// ```
/// use std::str;
///
/// // Ezinye ii-byte ezingasebenziyo kwi vector enokutshintsha
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Bona amaxwebhu e [`Utf8Error`] ngeenkcukacha ezithe kratya kwiindidi zeempazamo ezinokubuyiselwa.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // UKHUSELEKO: Sebenzisa nje ukungqinisisa.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Guqula isilayidi see-byte siye kwisilayidi somtya ngaphandle kokujonga ukuba umtya uqulethe i-UTF-8 esebenzayo.
///
/// Bona ingxelo ekhuselekileyo, [`from_utf8`], ngolwazi oluthe kratya.
///
/// # Safety
///
/// Lo msebenzi awukhuselekanga kuba awukhangeli ukuba ii-byte ezidluliselwe kuwo ziyinyani eyi-UTF-8.
/// Ukuba esi sithintelo saphulwe, iziphumo zokuziphatha ezingachazwanga, njengoko yonke i Rust ithatha ukuba [`&str`] s ziyinyani UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::str;
///
/// // ezinye i-byte, kwi-vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba ii-byte `v` zisemthethweni UTF-8.
    // Ikwaxhomekeka kwi `&str` nakwi `&[u8]` enobeko olufanayo.
    unsafe { mem::transmute(v) }
}

/// Guqula isilayidi see-byte siye kwisilayidi somtya ngaphandle kokujonga ukuba umtya uqulethe i-UTF-8 esebenzayo;Inguqulelo eguqukayo.
///
///
/// Bona ingxelo engaguqukiyo, i [`from_utf8_unchecked()`] ngolwazi oluthe kratya.
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // UKHUSELEKO: umntu ofowunayo uyaqinisekisa ukuba ii-byte `v`
    // Zisemthethweni UTF-8, yiyo loo nto isamente eya kwi `*mut str` ikhuselekile.
    // Kwakhona, isikhombisi esingasetyenziswanga sikhuselekile kuba isikhombisi sivela kwisalathiso esiqinisekisiweyo sokuba sisemthethweni ukubhala.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}