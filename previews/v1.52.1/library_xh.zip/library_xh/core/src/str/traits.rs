//! Ukuphunyezwa kwe-Trait ye `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Sebenzisa uku-odolwa kwentambo.
///
/// Imitya iyalelwe i-[lexicographically](Ord#lexicographical-comparison) ngamaxabiso abo e-byte.
/// Oku kuyalela amanqaku ekhowudi ye-Unicode ngokusekwe kwizikhundla zabo kwiitshathi zekhowudi.
/// Oku akufani ngokufanayo ne-"alphabetical" yeodolo, eyahluka ngolwimi nakwindawo.
/// Ukuhlela imitya ngokwemigangatho eyamkelweyo ngokwenkcubeko kufuna idatha ekhethekileyo yendawo ethile engaphandle komda wohlobo lwe `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Sebenzisa imisebenzi yokuthelekisa kwiintambo.
///
/// Imitya ithelekiswa ne [lexicographically](Ord#lexicographical-comparison) ngamaxabiso abo e-byte.
/// Oku kuthelekisa amanqaku ekhowudi ye-Unicode ngokusekwe kwizikhundla zabo kwiitshathi zekhowudi.
/// Oku akufani ngokufanayo ne-"alphabetical" yeodolo, eyahluka ngolwimi nakwindawo.
/// Ukuthelekisa imitya ngokwemigangatho eyamkelweyo ngokwenkcubeko kufuna idatha ekhethekileyo yendawo ethile engaphandle komda wohlobo lwe `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Sebenzisa izixhobo zokucoca ulwelo nge-syntax `&self[..]` okanye i `&mut self[..]`.
///
/// Ibuyisa isilayidi somtya uphela, okt ubuyisela i `&self` okanye i `&mut self`.Ilingana ne `&self [0 ..
/// len] `okanye`&mut mut [0 ..
/// len]`.
/// Ngokungafaniyo neminye imisebenzi yesalathiso, oku akunakuze kube panic.
///
/// Lo msebenzi yi *O*(1).
///
/// Phambi kwe 1.20.0, le misebenzi yesalathiso yayixhaswa ngokusetyenziswa ngokuthe ngqo kwe `Index` kunye ne `IndexMut`.
///
/// Ilingana ne `&self[0 .. len]` okanye i `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Sebenzisa izixhobo zokucoca ulwelo nge-syntax `&self[begin .. end]` okanye i `&mut self[begin .. end]`.
///
/// Ibuyisa isilayi somtya onikiweyo ukusuka kuluhlu lwe byte [`start`, `end`).
///
/// Lo msebenzi yi *O*(1).
///
/// Phambi kwe 1.20.0, le misebenzi yesalathiso yayixhaswa ngokusetyenziswa ngokuthe ngqo kwe `Index` kunye ne `IndexMut`.
///
/// # Panics
///
/// I-Panics ukuba i-`begin` okanye i-`end` ayikhombisi ukuqala kwe-byte yomlingisi (njengoko kuchaziwe ngu-`is_char_boundary`), ukuba i-`begin > end`, okanye i-`end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ezi ziya kuba panic:
/// // Byte 2 ilele ngaphakathi kwe `ö`:
/// // &s [2 ..3];
///
/// // byte 8 ilele ngaphakathi kwe `老`&s [1 ..
/// // 8];
///
/// // i-byte 100 ingaphandle komtya kunye nee-[3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // UKHUSELEKO: jonga nje ukuba i `start` kunye ne `end` zikumda wetshathi,
            // kwaye sidlulisa ireferensi ekhuselekileyo, ke ixabiso lokubuya liya kuba linye.
            // Sijonge imida yetshathi, ke le yinto eyi UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // UKHUSELEKO: ujonge nje ukuba i `start` kunye ne `end` zikumda wetshathi.
            // Siyazi ukuba isikhombisi sahlukile kuba sasifumana kwi `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // UKHUSELEKO: umntu ofowunayo uqinisekisa ukuba i `self` ikumda we `slice`
        // eyanelisa yonke imiqathango ye `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // UKHUSELEKO: jonga amagqabantshintshi e `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary itshekisha ukuba isalathiso sikwi [0, .len()] ayinakuphinda isebenzise i `get` njengasentla, ngenxa yengxaki ye-NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // UKHUSELEKO: jonga nje ukuba i `start` kunye ne `end` zikumda wetshathi,
            // kwaye sidlulisa ireferensi ekhuselekileyo, ke ixabiso lokubuya liya kuba linye.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Sebenzisa izixhobo zokucoca ulwelo nge-syntax `&self[.. end]` okanye i `&mut self[.. end]`.
///
/// Ibuyisa isilayi somtya onikiweyo kuluhlu lwe byte [`0`, `end`).
/// Ilingana ne `&self[0 .. end]` okanye i `&mut self[0 .. end]`.
///
/// Lo msebenzi yi *O*(1).
///
/// Phambi kwe 1.20.0, le misebenzi yesalathiso yayixhaswa ngokusetyenziswa ngokuthe ngqo kwe `Index` kunye ne `IndexMut`.
///
/// # Panics
///
/// I-Panics ukuba i-`end` ayibonisi ukuqala kwe-byte yomlingisi (njengoko kuchaziwe ngu-`is_char_boundary`), okanye ukuba yi-`end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // UKHUSELEKO: ujonge nje ukuba i `end` ikumda wetshathi,
            // kwaye sidlulisa ireferensi ekhuselekileyo, ke ixabiso lokubuya liya kuba linye.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // UKHUSELEKO: ujonge nje ukuba i `end` ikumda wetshathi,
            // kwaye sidlulisa ireferensi ekhuselekileyo, ke ixabiso lokubuya liya kuba linye.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // UKHUSELEKO: ujonge nje ukuba i `end` ikumda wetshathi,
            // kwaye sidlulisa ireferensi ekhuselekileyo, ke ixabiso lokubuya liya kuba linye.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Sebenzisa izixhobo zokucoca ulwelo nge-syntax `&self[begin ..]` okanye i `&mut self[begin ..]`.
///
/// Ibuyisa isilayi somtya onikiweyo ukusuka kuluhlu lwe byte [`start`, `len`).Ilingana ne `&self [qala ..
/// len] `okanye`&mut mut [qala ..
/// len]`.
///
/// Lo msebenzi yi *O*(1).
///
/// Phambi kwe 1.20.0, le misebenzi yesalathiso yayixhaswa ngokusetyenziswa ngokuthe ngqo kwe `Index` kunye ne `IndexMut`.
///
/// # Panics
///
/// I-Panics ukuba i-`begin` ayibonisi ukuqala kwe-byte yomlingisi (njengoko kuchaziwe ngu-`is_char_boundary`), okanye ukuba yi-`begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // UKHUSELEKO: ujonge nje ukuba i `start` ikumda wetshathi,
            // kwaye sidlulisa ireferensi ekhuselekileyo, ke ixabiso lokubuya liya kuba linye.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // UKHUSELEKO: ujonge nje ukuba i `start` ikumda wetshathi,
            // kwaye sidlulisa ireferensi ekhuselekileyo, ke ixabiso lokubuya liya kuba linye.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // UKHUSELEKO: umntu ofowunayo uqinisekisa ukuba i `self` ikumda we `slice`
        // eyanelisa yonke imiqathango ye `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // UKHUSELEKO: kufana ne `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // UKHUSELEKO: ujonge nje ukuba i `start` ikumda wetshathi,
            // kwaye sidlulisa ireferensi ekhuselekileyo, ke ixabiso lokubuya liya kuba linye.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Sebenzisa izixhobo zokucoca ulwelo nge-syntax `&self[begin ..= end]` okanye i `&mut self[begin ..= end]`.
///
/// Ibuyisa isilayi somtya onikiweyo kuluhlu lwe-Byte [`begin`, `end`].Ilingana ne-`&self [begin .. end + 1]` okanye i-`&mut self[begin .. end + 1]`, ngaphandle kokuba i-`end` inexabiso eliphezulu le-`usize`.
///
/// Lo msebenzi yi *O*(1).
///
/// # Panics
///
/// I-Panics ukuba i-`begin` ayikhombisi ukuqala kwe-byte yomlingisi (njengoko kuchaziwe ngu-`is_char_boundary`), ukuba i-`end` ayikhombisi ukuphela komlingisi (`end + 1` isisiqalo se-byte okanye ilingana ne-`len`), ukuba i-`begin > end`, okanye ukuba `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Sebenzisa izixhobo zokucoca ulwelo nge-syntax `&self[..= end]` okanye i `&mut self[..= end]`.
///
/// Ibuyisa isilayi somtya onikiweyo kuluhlu lwe-Byte [0, `end`].
/// Ilingana ne-`&self [0 .. end + 1]`, ngaphandle kokuba i-`end` inexabiso eliphezulu le-`usize`.
///
/// Lo msebenzi yi *O*(1).
///
/// # Panics
///
/// I-Panics ukuba i-`end` ayikhombisi kwi-offset ye-offset yomlingiswa (i-`end + 1` isisiqalo se-byte sokuqala njengoko kuchaziwe ngu-`is_char_boundary`, okanye ilingana no-`len`), okanye ukuba yi-`end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Thelekisa ixabiso kumtya
///
/// Ukusuka kuStr's indlela ye [`from_str`] ihlala isetyenziswa ngokungagungqiyo, ngokusebenzisa [`str`] 's indlela ye [`parse`].
/// Jonga [`parse`] amaxwebhu emizekelo.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ayinayo ipharamitha yobomi bonke, kwaye ke unokwazi ukwahlula kuphela iintlobo ezingenayo ipharamitha yobomi ngokwazo.
///
/// Ngamanye amagama, unokubonisa i `i32` nge `FromStr`, kodwa hayi i `&i32`.
/// Unako ukucazulula ulwakhiwo oluqukethe i `i32`, kodwa ingeyiyo iqulethe i `&i32`.
///
/// # Examples
///
/// Umiliselo olusisiseko lwe `FromStr` kumzekelo `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Impazamo enxulumene nayo enokubuyiselwa ekuhlubeni.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Ukucoca umtya `s` ukubuyisela ixabiso lolu hlobo.
    ///
    /// Ukuba ukwahlula kuyaphumelela, buyisela ixabiso ngaphakathi kwe [`Ok`], ngaphandle koko xa umtya ungakhekanga kakuhle ubuyisela impazamo ethile ngaphakathi kwe [`Err`].
    /// Uhlobo lwempazamo luthe ngqo ekuphunyezweni kwe trait.
    ///
    /// # Examples
    ///
    /// Ukusetyenziswa ngokusisiseko nge [`i32`], uhlobo olusebenzisa i `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Cacisa i `bool` kumtya.
    ///
    /// Inika i `Result<bool, ParseBoolError>`, kuba i `s` inokuthi okanye ingabonakali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Qaphela, kwiimeko ezininzi, indlela ye `.parse()` kwi `str` ichaneke ngakumbi.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}