use crate::iter::FromIterator;

/// Idibanisa zonke izinto zeyunithi ukusuka kwi-iterator ukuya kwenye.
///
/// Oku kuluncedo ngakumbi xa kudityaniswe nenqanaba eliphezulu lokukhupha, njengokuqokelela kwi-`Result<(), E>` apho ukhathalela kuphela iimpazamo:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}