#![stable(feature = "core_hint", since = "1.27.0")]

//! Amacebo okuqokelela achaphazela indlela ekufuneka ikhutshiwe ngayo ikhowudi okanye yenziwe ngcono.
//! Amacebo anokuqulatha ixesha okanye ixesha lokusebenza.

use crate::intrinsics;

/// Yazisa umqokeleli ukuba eli nqanaba lekhowudi alinakufikeleleka, lenza ukuba kube nakho ukwandiswa ngakumbi.
///
/// # Safety
///
/// Ukufikelela kulo msebenzi ngokupheleleyo *kukungachazwa kokuziphatha*(UB).Ngokukodwa, umhlanganisi uthatha ukuba yonke i-UB mayingaze yenzeke, kwaye ke iya kususa onke amasebe afikelela kumnxeba oya kwi-`unreachable_unchecked()`.
///
/// Njengawo onke amatyala e-UB, ukuba le ngcinga iyajika ibe yephosakeleyo, okt umnxeba we `unreachable_unchecked()` uyafikeleleka phakathi kwako konke ukuhamba kolawulo olunokwenzeka, umhlanganisi uya kusebenzisa isicwangciso esiliqili sokusebenza, kwaye ngamanye amaxesha anokubonakalisa ikhowudi ebonakala ingahambelani, ebangela ubunzima-iingxaki zokulungisa ingxaki.
///
///
/// Sebenzisa lo msebenzi kuphela xa unokuba nobungqina bokuba ikhowudi ayinakuze iyibize.
/// Ngaphandle koko, cinga ukusebenzisa i-[`unreachable!`] macro, engakuvumeliyo ukwenziwa kodwa ibe yi-panic xa isenziwa.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` ihlala iqinisekile (hayi zero), yiyo loo nto i `checked_div` ingaze iphinde ibuye i `None`.
/////
///     // Ke ngoko, enye i branch ayinakufikeleleka.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // UKHUSELEKO: ikhontrakthi yokhuseleko ye `intrinsics::unreachable` kufuneka
    // igcinwe ngulowo ufowunayo.
    unsafe { intrinsics::unreachable() }
}

/// Ikhupha umatshini wokuyalela ukubonisa iprosesa ukuba iyasebenza kwindawo yokulinda okuxineneyo ("spin lock").
///
/// Emva kokufumana umqondiso we-spin-loop umqhubekekisi angayiphucula indlela aziphethe ngayo, umzekelo, okonga amandla okanye ngokutshintsha imisonto ye-hyper.
///
/// Lo msebenzi wahlukile kwi [`thread::yield_now`] ethi ivelise ngokuthe ngqo ishedyuli yenkqubo, ngelixa i `spin_loop` ingadibaniyo nenkqubo yokusebenza.
///
/// Ityala eliqhelekileyo lokusetyenziswa kwe `spin_loop` liphumeza ukujikeleza okuthembekileyo kwi-CAS loop kulungelelwaniso lwangaphambili.
/// Ukuthintela iingxaki ezinje ngokubhengeza okuphambili, kuyacetyiswa ngamandla ukuba ispin loop ipheliswe emva kokuba isixa esigqibeleleyo sokwenziwa kwayo kunye nokwenza i-syscall efanelekileyo.
///
///
/// **Qaphela**: Kumaqonga angaxhasi ukufumana iingcebiso ze-spin-loop lo msebenzi awenzi kwanto kwaphela.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Ixabiso elabelwe i-atom eliza kusetyenziswa yimisonto ukulungelelanisa
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Ngomsonto ongasemva siza kuthi ekugqibeleni sibeke ixabiso
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Yenza umsebenzi othile, emva koko wenze ixabiso liphile
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Buyela kwintambo yethu yangoku, silinde ukuba ixabiso lisetelwe
/// while !live.load(Ordering::Acquire) {
///     // Umjikelo wokujikeleza sisilumkiso kwi-CPU esiyilindileyo, kodwa mhlawumbi hayi ixesha elide
/////
///     hint::spin_loop();
/// }
///
/// // Ixabiso lisetelwe ngoku
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // UKHUSELEKO: umtsalane we `cfg` uqinisekisa ukuba oku sikwenza kuphela kwiithagethi ze x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // UKHUSELEKO: umtsalane we `cfg` uqinisekisa ukuba oku sikwenza kuphela kwiithagethi ze x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // UKHUSELEKO: umtsalane we `cfg` uqinisekisa ukuba oku sikwenza kuphela kwiithagethi ze aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // UKHUSELEKO: umtsalane we `cfg` uqinisekisa ukuba oku sikwenza kuphela kwiithagethi zengalo
            // ngenkxaso yenqaku le v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Umsebenzi wesazisi othi __ hints __ * kumqokeleli ukuze abe nethemba lokuba yintoni i-`black_box` enokuyenza.
///
/// Ngokungafaniyo ne-[`std::convert::identity`], umhlanganisi we-Rust uyakhuthazwa ukuba acinge ukuba i-`black_box` inokusebenzisa i-`dummy` nangayiphi na indlela esebenzayo yokuba ikhowudi ye-Rust ivunyelwe ngaphandle kokungenisa isimilo esingachazwanga kwikhowudi yokufowuna.
///
/// Le propati yenza i `black_box` iluncedo ekubhaleni ikhowudi apho kungafuneki ukulungiswa okuthile, njengeebenchmark.
///
/// Qaphela ke, ukuba i `black_box` kuphela (kwaye inokubakho kuphela) ebonelelwe kwisiseko se "best-effort".Ubungakanani obunokuthintela ukulungiswa kunokwahluka ngokuxhomekeke kwiqonga kunye nekhowudi ye-gen-backend esetyenzisiweyo.
/// Iinkqubo azinakuxhomekeka kwi `black_box` ngokuchaneka * nangayiphi na indlela.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Sidinga i "use" ingxoxo ngandlela thile i-LLVM ayinakho ukungena ngaphakathi, kwaye kwiithagethi eziyixhasayo sinokufumana amandla kwi-inline Assembly ukwenza oku.
    // Ukutolikwa kwe-LLVM kwindibano emgceni kukuba, kulungile, ibhokisi emnyama.
    // Olu ayilulo lolona phumezo lubalaseleyo kuba kusenokwenzeka ukuba lukhethe ngaphezulu kunokuba sifuna, kodwa kude kube ngoku kulungile.
    //
    //

    #[cfg(not(miri))] // Olu luphawu nje, ke kulungile ukutsiba eMiri.
    // UKHUSELEKO: Indibano esemgceni yinto engekhoyo.
    unsafe {
        // FIXME: Ayikwazi ukusebenzisa i `asm!` kuba ayixhasi i MIPS kunye nolunye uyilo.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}