Panics umsonto wangoku.

Oku kuvumela inkqubo ukuba iphelise ngokukhawuleza kwaye inike ingxelo kulowo ufowunela inkqubo.
`panic!` kufuneka isetyenziswe xa inkqubo ifikelela kwimeko engafumanekiyo.

Le macro yeyona ndlela ifanelekileyo yokuqinisekisa iimeko kwikhowudi yomzekelo nakwiimvavanyo.
`panic!` iboshwe ngokusondeleyo kwindlela ye `unwrap` yazo zombini i-[`Option`][ounwrap] kunye ne-[`Result`][runwrap] enum.
Omabini la manyathelo omiliselo abiza i `panic!` xa isetelwe kwi [`None`] okanye kwi [`Err`] eyahlukileyo.

Xa usebenzisa i `panic!()` ungakhankanya umtya ohlawulelwayo, owakhelwe kusetyenziswa is syntax se [`format!`].
Oko kuhlawulwa kusetyenziswa xa kusitofwa i-panic kwifowuni Rust, ebangela ukuba umsonto uye kwi-panic ngokupheleleyo.

Ukuziphatha kwe `std` hook emiselweyo, okt
ikhowudi eqhuba ngokuthe ngqo emva kokuba i panic iceliwe, kukuprinta umyalezo ohlawulelwa u-`stderr` kunye nolwazi lwe-file/line/column lomnxeba we-`panic!()`.

Ungabhala ngaphezulu kwe panic hook usebenzisa i [`std::panic::set_hook()`].
Ngaphakathi kwi-hook i-panic inokufikelelwa njenge-`&dyn Any + Send`, equlathe i-`&str` okanye i-`String` yokucela rhoqo i-`panic!()`.
Ku-panic ngexabiso lolunye uhlobo, i [`panic_any`] inokusetyenziswa.

[`Result`] I-enum ihlala isisombululo esingcono sokufumana kwakhona kwiimpazamo kunokusebenzisa i-`panic!` macro.
Le macro kufuneka isetyenziselwe ukunqanda ukuqhubekeka usebenzisa amaxabiso angachanekanga, njengakwimithombo yangaphandle.
Ulwazi olunenkcukacha malunga nokusingathwa kwempazamo lufumaneka kwi [book].

Jonga kwakhona i-macro [`compile_error!`], yokuphakamisa iimpazamo ngexesha lokudityaniswa.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Ukuphunyezwa kwangoku

Ukuba umtya ophambili we-panics uya kuyiphelisa yonke imisonto yakho kwaye ugqibe inkqubo yakho ngekhowudi `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





