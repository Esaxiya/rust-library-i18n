#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Yandisa i `$crate::panic::panic_2015` okanye i `$crate::panic::panic_2021` ngokuxhomekeke kuhlobo lomntu ofowunayo.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Yongeza ukuba amabinzana amabini ayalingana (usebenzisa i [`PartialEq`]).
///
/// Kwi-panic, le macro iya kuprinta amaxabiso amabinzana kunye nokuzimela kwawo.
///
///
/// Njengo-[`assert!`], le macro inefom yesibini, apho umyalezo we-panic wesiko unokubonelelwa khona.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ezi zibuyiso zingezantsi zenziwe ngenjongo.
                    // Ngaphandle kwabo, indawo yokubekwa kwemali ebolekiweyo iqaliswa kwangaphambi kokuba amaxabiso athelekiswe, kukhokelela ekucothiseni okubonakalayo.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ezi zibuyiso zingezantsi zenziwe ngenjongo.
                    // Ngaphandle kwabo, indawo yokubekwa kwemali ebolekiweyo iqaliswa kwangaphambi kokuba amaxabiso athelekiswe, kukhokelela ekucothiseni okubonakalayo.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Yongeza ukuba amabinzana amabini alingani omnye nomnye (kusetyenziswa i [`PartialEq`]).
///
/// Kwi-panic, le macro iya kuprinta amaxabiso amabinzana kunye nokuzimela kwawo.
///
///
/// Njengo-[`assert!`], le macro inefom yesibini, apho umyalezo we-panic wesiko unokubonelelwa khona.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ezi zibuyiso zingezantsi zenziwe ngenjongo.
                    // Ngaphandle kwabo, indawo yokubekwa kwemali ebolekiweyo iqaliswa kwangaphambi kokuba amaxabiso athelekiswe, kukhokelela ekucothiseni okubonakalayo.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ezi zibuyiso zingezantsi zenziwe ngenjongo.
                    // Ngaphandle kwabo, indawo yokubekwa kwemali ebolekiweyo iqaliswa kwangaphambi kokuba amaxabiso athelekiswe, kukhokelela ekucothiseni okubonakalayo.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Yongeza into yokuba intetho ye-boolean yi `true` ngexesha lokubaleka.
///
/// Oku kuyakubiza i-[`panic!`] macro ukuba intetho ebonelelweyo ayinakuvavanywa kwi `true` ngexesha lokubaleka.
///
/// Njengo [`assert!`], le macro ikwanayo nohlobo lwesibini, apho umyalezo wesiko we-panic unokubonelelwa khona.
///
/// # Uses
///
/// Ngokungafaniyo ne [`assert!`], ingxelo ye `debug_assert!` inikwe amandla kuphela kulwakhiwo olungalungiswanga ngokwendalo.
/// Ulwakhiwo oluphuculweyo aluyi kuqhuba izitetimenti ze-`debug_assert!` ngaphandle kokuba i-`-C debug-assertions` idluliselwe kumhlanganisi.
/// Oku kwenza ukuba i `debug_assert!` ibe luncedo ekutshekeni okubiza kakhulu ukubakho xa kusakhiwa kodwa kunokuba luncedo ngexesha lophuhliso.
/// Iziphumo zokwandisa i `debug_assert!` zihlala zihlolwe kuhlobo.
///
/// Ukuqinisekiswa okungakhange kuhlolwe kuvumela inkqubo kwimeko engahambelaniyo ukuba iqhubeke isebenza, enokuba neziphumo ezingalindelekanga kodwa ingazisi ukungakhuseleki lo gama oko kusenzeka kuphela kwikhowudi ekhuselekileyo.
///
/// Ixabiso lokusebenza kwamabango, nangona kunjalo, alinakulinganiswa ngokubanzi.
/// Ukutshintsha i-[`assert!`] nge-`debug_assert!` kuyakhuthazeka kuphela emva kokucacisa ngokucokisekileyo, kwaye okona kubaluleke kakhulu, kuphela kwikhowudi ekhuselekileyo!
///
/// # Examples
///
/// ```
/// // Umyalezo we-panic wezi zibhengezo lixabiso elidityanisiweyo lebinzana elinikiweyo.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // umsebenzi olula kakhulu
/// debug_assert!(some_expensive_computation());
///
/// // Qinisekisa ngomyalezo wesiko
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Yongeza ukuba amabinzana amabini ayalingana.
///
/// Kwi-panic, le macro iya kuprinta amaxabiso amabinzana kunye nokuzimela kwawo.
///
/// Ngokungafaniyo ne [`assert_eq!`], ingxelo ye `debug_assert_eq!` inikwe amandla kuphela kulwakhiwo olungalungiswanga ngokwendalo.
/// Ulwakhiwo oluphuculweyo aluyi kuqhuba izitetimenti ze-`debug_assert_eq!` ngaphandle kokuba i-`-C debug-assertions` idluliselwe kumhlanganisi.
/// Oku kwenza ukuba i `debug_assert_eq!` ibe luncedo ekutshekeni okubiza kakhulu ukubakho xa kusakhiwa kodwa kunokuba luncedo ngexesha lophuhliso.
///
/// Iziphumo zokwandisa i `debug_assert_eq!` zihlala zihlolwe kuhlobo.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Yongeza ukuba amabinzana amabini awalingani.
///
/// Kwi-panic, le macro iya kuprinta amaxabiso amabinzana kunye nokuzimela kwawo.
///
/// Ngokungafaniyo ne [`assert_ne!`], ingxelo ye `debug_assert_ne!` inikwe amandla kuphela kulwakhiwo olungalungiswanga ngokwendalo.
/// Ulwakhiwo oluphuculweyo aluyi kuqhuba izitetimenti ze-`debug_assert_ne!` ngaphandle kokuba i-`-C debug-assertions` idluliselwe kumhlanganisi.
/// Oku kwenza ukuba i `debug_assert_ne!` ibe luncedo ekutshekeni okubiza kakhulu ukubakho xa kusakhiwa kodwa kunokuba luncedo ngexesha lophuhliso.
///
/// Iziphumo zokwandiswa kwe `debug_assert_ne!` zihlala zihlolwe kuhlobo.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Ibuyisa ukuba ngaba intetho enikiweyo iyangqinelana nayo nayiphi na iipateni ezinikiweyo.
///
/// Njengakwingcaciso ye `match`, iphethini inokulandelwa ngokhetho ngu-`if` kunye nembonakalo yokulinda enokufikelela kumagama aboshwe yipateni.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Isonga iziphumo okanye isasaze impazamo.
///
/// Umsebenzi we `?` wongezwa endaweni ye `try!` kwaye kufuneka isetyenziswe endaweni yoko.
/// Ngaphaya koko, i `try` ligama eligciniweyo kwi Rust 2018, ke ukuba uyayisebenzisa, kuya kufuneka usebenzise i [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ihambelana ne [`Result`] enikiweyo.Kwimeko yokwahluka kwe `Ok`, intetho inexabiso lexabiso elisongelweyo.
///
/// Kwimeko yokwahluka kwe `Err`, iphinda ifumane impazamo yangaphakathi.I-`try!` emva koko yenza uguquko kusetyenziswa i `From`.
/// Oku kubonelela ngoguqulelo oluzenzekelayo phakathi kweempazamo ezikhethekileyo kunye nezinye ngokubanzi.
/// Impazamo evelisiweyo emva koko ibuyiselwe kwangoko.
///
/// Ngenxa yokubuya kwangoko, i `try!` inokusetyenziswa kuphela kwimisebenzi ebuyisa i [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Indlela ekhethiweyo yokubuyisa iimpazamo ngokukhawuleza
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Indlela yangaphambili yokubuyisa iimpazamo
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Oku kulingana ne:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Ubhala idatha efomathiweyo kwisikhuseli.
///
/// Le macro yamkela i-'writer', umtya wefomathi, kunye noluhlu lweempikiswano.
/// Iingxoxo ziya kufomatwa ngokomgaqo wefomathi echaziweyo kwaye iziphumo ziya kugqithiselwa kumbhali.
/// Umbhali unokuba naliphi na ixabiso ngendlela ye `write_fmt`;ngokubanzi oku kuvela ekuphunyezweni kwe [`fmt::Write`] okanye i [`io::Write`] trait.
/// Imacro ibuyisa nantoni na ebuyayo i `write_fmt`;Ngokwesiqhelo i [`fmt::Result`], okanye i [`io::Result`].
///
/// Bona i [`std::fmt`] ngolwazi oluthe kratya kwifomathi yomtya we-syntax.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Imodyuli inokungenisa zombini i `std::fmt::Write` kunye ne `std::io::Write` kwaye ibize i `write!` kwizinto eziphumeza nokuba yeyiphi na, njengoko izinto zingazisebenzisi zombini.
///
/// Nangona kunjalo, imodyuli kufuneka ingenise i traits efanelekileyo ukuze amagama abo angangqubani:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // isebenzisa i fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // isebenzisa i io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Le macro inokusetyenziswa kwiiseti ze `no_std` ngokunjalo.
/// Kwiseti ye `no_std` unoxanduva lokumiliselwa kweenkcukacha zamacandelo.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Bhala idatha efomathiweyo kwi-buffer, kunye nelineline eyongeziweyo.
///
/// Kuwo onke amaqonga, umgca omtsha ngumgca we-LINE FEED (`\n`/`U+000A`) kuphela (akukho CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Ngolwazi oluthe kratya, jonga i [`write!`].Ngolwazi kwi-syntax yomtya wefomathi, bona i [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Imodyuli inokungenisa zombini i `std::fmt::Write` kunye ne `std::io::Write` kwaye ibize i `write!` kwizinto eziphumeza nokuba yeyiphi na, njengoko izinto zingazisebenzisi zombini.
/// Nangona kunjalo, imodyuli kufuneka ingenise i traits efanelekileyo ukuze amagama abo angangqubani:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // isebenzisa i fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // isebenzisa i io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Ibonisa ikhowudi engafikelelekiyo.
///
/// Oku kuluncedo nangaliphi na ixesha apho umhlanganisi engenakugqiba ukuba ikhowudi ayinakufikeleleka.Umzekelo:
///
/// * Tshatisa iingalo neemeko zokugada.
/// * Imiphetho ephelisa ngamandla.
/// * Iterterter ezipheliswa ngamandla.
///
/// Ukuba ukuzimisela ukuba ikhowudi ayinakufikeleleka kungqina ukuba ayichanekanga, inkqubo iphela kwangoko nge [`panic!`].
///
/// Umlingane ongakhuselekanga wale macro ngumsebenzi we [`unreachable_unchecked`], oya kuthi ubangele isimilo esingachazwanga ukuba ikhowudi ifikelelwe.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Oku kuya kuhlala kungu-[`panic!`].
///
/// # Examples
///
/// Tshatisa iingalo:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // qulunqa impazamo xa kuphawuliwe
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // Olunye lolona phunyezo luhlwempuzekileyo lwe x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Ibonisa ikhowudi engasetyenziswanga ngokuxhalaba ngomyalezo we "not implemented".
///
/// Oku kuvumela ikhowudi yakho ukuba ichwetheze-itshekishe, eluncedo ukuba wenza iprototyping okanye usebenzisa i trait efuna iindlela ezininzi ongacwangcisanga kuzisebenzisa zonke.
///
/// Umahluko phakathi kwe `unimplemented!` kunye ne [`todo!`] kukuba ngelixa i `todo!` ihambisa injongo yokuphumeza ukusebenza kamva kwaye umyalezo ngu "not yet implemented", `unimplemented!` ayenzi mabango anjalo.
/// Umyalezo wayo ngu "not implemented".
/// Kwakhona ezinye ii-IDE ziya kuphawula `into!` S.
///
/// # Panics
///
/// Oku kuyakuhlala i-[`panic!`] kuba i-`unimplemented!` sisishwankathelo nje se-`panic!` ngomyalezo ochanekileyo, othile.
///
/// Njengo `panic!`, le macro inefom yesibini yokubonisa amaxabiso esiko.
///
/// # Examples
///
/// Yithi sine-trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Sifuna ukumilisela i `Foo` ye 'MyStruct', kodwa ngenxa yesizathu esithile inengqiqo kuphela yokuphumeza umsebenzi we `bar()`.
/// `baz()` kwaye i `qux()` isaza kufuna ukuchazwa ekuphumezeni kwethu i `Foo`, kodwa singasebenzisa i `unimplemented!` kwiingcaciso zabo ukuvumela ikhowudi yethu ukuba iqokelele.
///
/// Sisafuna ukuba inkqubo yethu iyeke ukusebenza ukuba iindlela ezingasetyenziswanga ziyafikelelwa.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Akunangqondo ukuba i-`baz` ibe yi-`MyStruct`, ngenxa yoko asinangqondo apha kwaphela.
/////
///         // Oku kuyakubonisa i "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Sinengqondo apha, singongeza umyalezo kwi-unimplemented!ukubonisa ukushiya kwethu.
///         // Oku kuyakubonisa: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Ibonisa ikhowudi engagqitywanga.
///
/// Oku kunokuba luncedo ukuba wenza iprototyping kwaye ujonge nje ukuba nekhowudi yakho typecheck.
///
/// Umahluko phakathi kwe [`unimplemented!`] kunye ne `todo!` kukuba ngelixa i `todo!` ihambisa injongo yokuphumeza ukusebenza kamva kwaye umyalezo ngu "not yet implemented", `unimplemented!` ayenzi mabango anjalo.
/// Umyalezo wayo ngu "not implemented".
/// Kwakhona ezinye ii-IDE ziya kuphawula `into!` S.
///
/// # Panics
///
/// Oku kuya kuhlala kungu-[`panic!`].
///
/// # Examples
///
/// Nanku umzekelo wekhowudi yenkqubela phambili.Sine-trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Sifuna ukusebenzisa i-`Foo` kwenye yeentlobo zethu, kodwa sifuna ukusebenza kwi-`bar()` kuqala.Ukuze ikhowudi yethu idibane, kufuneka sisebenzise i-`baz()`, ukuze sikwazi ukusebenzisa i `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ukuphunyezwa kuya apha
///     }
///
///     fn baz(&self) {
///         // masingakhathazeki ngokuphumeza i baz() okwangoku
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // Asikhe sisebenzise i baz(), ke oku kulungile.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Iinkcazo zemacros ezakhelweyo.
///
/// Uninzi lweepropathi ezinkulu (uzinzo, ukubonakala, njl.njl.) Zithathiwe kwikhowudi yemithombo yolwazi apha, ngaphandle kwemisebenzi yokwandisa eguqula igalelo elikhulu ukuba libe ziziphumo, loo misebenzi ibonelelwa ngumhlanganisi.
///
///
pub(crate) mod builtin {

    /// Ibangela ukudityaniswa kusilele ngomyalezo wempazamo onikiweyo xa udibana.
    ///
    /// Le macro kufuneka isetyenziswe xa i-crate isebenzisa isicwangciso sokudibanisa esinemiqathango ukubonelela ngemiyalezo yeemposiso ezingcono kwiimeko eziphosakeleyo.
    ///
    /// Yifomathi yenqanaba lomhlanganisi we [`panic!`], kodwa ikhupha impazamo ngexesha *lokudityaniswa* endaweni yexesha * lokusebenza.
    ///
    /// # Examples
    ///
    /// Imizekelo emibini enjalo ziimacros kunye neemeko ze `#[cfg]`.
    ///
    /// Khupha imposiso yomhlanganisi ongcono ukuba makro kudluliswe amaxabiso angasebenziyo.
    /// Ngaphandle kwe-branch yokugqibela, umhlanganisi uya kuhlala ekhupha impazamo, kodwa umyalezo wempazamo awunakukhankanya amaxabiso amabini asebenzayo.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Ukukhupha impazamo yomhlanganisi ukuba inani leempawu alifumaneki.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yakha iiparameter zolunye uluvo lokufomatha umacros.
    ///
    /// Le misebenzi inkulu ngokuthatha ifomathi yokufomatha uqobo ene-`{}` kwingxoxo nganye eyongezelelweyo edlulisiweyo.
    /// `format_args!` ilungisa iiparameter ezongezelelweyo ukuqinisekisa ukuba imveliso inokuchazwa njengomtya kwaye icacisa iimpikiswano kuhlobo olunye.
    /// Naliphi na ixabiso elisebenzisa i-[`Display`] trait linokudluliselwa kwi-`format_args!`, njengoko kunjalo nakuyiphi na i-[`Debug`] yokuphunyezwa ingadluliselwa kwi-`{:?}` ngaphakathi komtya wokufomatha.
    ///
    ///
    /// Le macro ivelisa ixabiso lohlobo [`fmt::Arguments`].Eli xabiso linokudluliselwa kwii-macros ngaphakathi kwe-[`std::fmt`] ngokwenza ulungelelwaniso oluluncedo.
    /// Zonke ezinye ii-macros zokufomatha ([`format!`], [`write!`], [`println!`], njl. Njl.) Zimelwe ngale ndlela.
    /// `format_args!`, ngokungafaniyo nee-macros zayo, ithintela ulwabiwo lweemfumba.
    ///
    /// Ungasebenzisa ixabiso le [`fmt::Arguments`] elibuyiswa yi `format_args!` kwi `Debug` nakwi `Display` imeko njengoko kubonisiwe ngezantsi.
    /// Umzekelo ukwabonisa ukuba ifomathi ye `Debug` kunye ne `Display` kwinto enye: umtya wefomathi edibeneyo kwi `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Ngolwazi oluthe kratya, bona amaxwebhu kwi [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Iyafana ne `format_args`, kodwa yongeza umgca omtsha ekugqibeleni.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ihlola imeko-bume eyahlukileyo ngexesha lokudityaniswa.
    ///
    /// Le macro iya kwanda iye kwixabiso lokwahluka kwendalo okusingqongileyo ngexesha lokudityaniswa, inike ingxelo yohlobo `&'static str`.
    ///
    ///
    /// Ukuba umahluko wemeko-bume awuchazwanga, kuya kubakho impazamo yokudityaniswa.
    /// Ukungakhuphi impazamo yokudibanisa, sebenzisa i [`option_env!`] macro endaweni yoko.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Unokwenza umyalezo wemposiso ngokokudlulisa umtya njengeparitha yesibini:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Ukuba umahluko we `documentation` wendalo awuchazwanga, uya kufumana le mpazamo ilandelayo:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ngokukhetha ukhetho lokungafaniyo kokusingqongileyo ngexesha lokudityaniswa.
    ///
    /// Ukuba umahluko wemo engqongileyo ukho ngexesha lokudityaniswa, oku kuyakwandiswa ukuya kwintetho yohlobo `Option<&'static str>` enexabiso elili-`Some` yexabiso lokwahluka kwendalo.
    /// Ukuba umahluko wemeko bume awukho, ke oku kuyakwandiswa kuye kwi `None`.
    /// Bona i [`Option<T>`][Option] ngolwazi oluthe kratya kolu hlobo.
    ///
    /// Impazamo yexesha lokudityaniswa ayikaze ikhutshwe xa usebenzisa le macro nokuba ujongano lwendalo lukhona okanye hayi.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Idibanisa izinto ezichongiweyo kwisazisi esinye.
    ///
    /// Le macro ithatha naliphi na inani lezichongi ezahlulwe ngekoma, kwaye iyazidibanisa zonke zibe nye, ivelise intetho eyisihlonzi esitsha.
    /// Qaphela ukuba ucoceko lwenza ukuba le macro ingabinakho ukubamba izinto eziguquguqukayo zasekhaya.
    /// Kwakhona, njengomgaqo ngokubanzi, ii-macros zivunyelwe kuphela kwinto, kwingxelo okanye kwindawo yokubonisa.
    /// Oko kuthetha ukuba ngelixa ungayisebenzisa le macro ukubhekisa kwizinto ezikhoyo, imisebenzi okanye iimodyuli njl.njl, ngekhe uchaze entsha ngayo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (entsha, emnandi, igama) { }//ayisebenzi ngale ndlela!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ukudibanisa okubhaliweyo kulungelelwaniso lomtya ongashukumiyo.
    ///
    /// Le macro ithatha naliphi na inani loncwadi olwahlulwe ngokhefana, iveza intetho yohlobo `&'static str` emele lonke uncwadi oludityaniswe ngasekhohlo ukuya ekunene.
    ///
    ///
    /// Inani elipheleleyo kunye neencwadana zokudada zinamakhonkco ukuze zilungelelaniswe.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ukwandisa kwinani lomgca apho lifakwe khona.
    ///
    /// Nge-[`column!`] kunye ne-[`file!`], ezi macros zibonelela ngolwazi lokulungisa ingxaki kubaphuhlisi malunga nendawo ekuyo ngaphakathi komthombo.
    ///
    /// Inkcazo eyandisiweyo inohlobo `u32` kwaye isekwe ku-1, ke umgca wokuqala kwifayile nganye uvavanya ukuya ku-1, owesibini ukuya ku-2, njl.
    /// Oku kuyahambelana nemiyalezo yempazamo ngabahlanganisi abaqhelekileyo okanye abahleli abadumileyo.
    /// Umgca obuyiselweyo * awunyanzelekanga ukuba ube ngumgca wesicelo se `line!` uqobo, kodwa endaweni yoko sisicelo sokuqala semacro esikhokelela ekubongozeni i-`line!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ukwandisa kwinombolo yekholamu apho yangeniswa khona.
    ///
    /// Nge-[`line!`] kunye ne-[`file!`], ezi macros zibonelela ngolwazi lokulungisa ingxaki kubaphuhlisi malunga nendawo ekuyo ngaphakathi komthombo.
    ///
    /// Inkcazo eyandisiweyo inohlobo `u32` kwaye isekwe ku-1, ke ikholamu yokuqala kumgca ngamnye ivavanya ukuya ku-1, eyesibini kuye kweyesi-2, njl.
    /// Oku kuyahambelana nemiyalezo yempazamo ngabahlanganisi abaqhelekileyo okanye abahleli abadumileyo.
    /// Ikholamu ebuyisiweyo *ayisiyiyo* umgca wokucela u-`column!` ngokwawo, kodwa endaweni yoko yeyokuqala ukubongoza okukhulu okukhokelela ekubongozeni i-`column!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Yandisa kwigama lefayile apho lalifakwe khona.
    ///
    /// Nge-[`line!`] kunye ne-[`column!`], ezi macros zibonelela ngolwazi lokulungisa ingxaki kubaphuhlisi malunga nendawo ekuyo ngaphakathi komthombo.
    ///
    /// Inkcazo eyandisiweyo inohlobo `&'static str`, kwaye ifayile ebuyisiweyo ayingombongo we-`file!` macro uqobo, kodwa endaweni yoko yeyokuqala ukubongoza okukhulu kukhokelela ekubongozeni i-`file!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Ukuqinisa iingxoxo zayo.
    ///
    /// Le macro iya kuvelisa intetho yohlobo `&'static str` engumtya wazo zonke i tokens ezidluliselwe kwimacro.
    /// Akukho zithintelo zibekiweyo kwis syntax yoncenge olukhulu ngokwalo.
    ///
    /// Qaphela ukuba iziphumo ezandisiweyo zegalelo tokens zinokutshintsha kwi future.Kuya kufuneka ulumke ukuba uthembele kwimveliso.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Kubandakanya ifayile ebhaliweyo ye UTF-8 njengomtya.
    ///
    /// Ifayile ibekwe ngokuhambelana nefayile yangoku (ngokufanayo nendlela iimodyuli ezifumaneka ngayo).
    /// Indlela ebonelelweyo itolikwa ngendlela ethile yeqonga ngexesha lokudityaniswa.
    /// Umzekelo, isibongozo esine-Windows sendlela equlathe umva u-`\` ngekhe siqokelele ngokuchanekileyo kwi Unix.
    ///
    ///
    /// Le macro iya kuvelisa intetho yohlobo `&'static str` eyisiqulatho sefayile.
    ///
    /// # Examples
    ///
    /// Thatha ukuba zimbini iifayile kwisikhombisi esinye neziqulatho zilandelayo:
    ///
    /// Ifayile 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ifayile 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Ukuqulunqa i-'main.rs' kunye nokusebenzisa isiphumo sokubhina kuya kuprinta i "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kubandakanya ifayile ekubhekiswa kuyo kuluhlu lwee-byte.
    ///
    /// Ifayile ibekwe ngokuhambelana nefayile yangoku (ngokufanayo nendlela iimodyuli ezifumaneka ngayo).
    /// Indlela ebonelelweyo itolikwa ngendlela ethile yeqonga ngexesha lokudityaniswa.
    /// Umzekelo, isibongozo esine-Windows sendlela equlathe umva u-`\` ngekhe siqokelele ngokuchanekileyo kwi Unix.
    ///
    ///
    /// Le macro iya kuvelisa intetho yohlobo `&'static [u8; N]` eyisiqulatho sefayile.
    ///
    /// # Examples
    ///
    /// Thatha ukuba zimbini iifayile kwisikhombisi esinye neziqulatho zilandelayo:
    ///
    /// Ifayile 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ifayile 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Ukuqulunqa i-'main.rs' kunye nokusebenzisa isiphumo sokubhina kuya kuprinta i "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yandisa kwintambo emele indlela yangoku yemodyuli.
    ///
    /// Indlela yemodyuli yangoku inokucingwa njengolawulo oluphezulu lweemodyuli ezikhokelela emva kwi-crate root.
    /// Icandelo lokuqala lendlela ebuyiselweyo ligama le crate okwangoku ehlanganisiweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Vavanya indibaniselwano ye-boolean yeeflegi zoqwalaselo ngexesha lokudityaniswa.
    ///
    /// Ukongeza kwi-`#[cfg]` uphawu, le macro ibonelelwe ukuvumela uvavanyo lwe-boolean expression of flags zoqwalaselo.
    /// Oku kuhlala kukhokelela kwikhowudi ephindiweyo encinci.
    ///
    /// Is syntax esinikwe le macro sis syntax efanayo nesimpawu se [`cfg`].
    ///
    /// `cfg!`, ngokungafaniyo ne `#[cfg]`, ayisusi nayiphi na ikhowudi kwaye ivavanye kuphela kwinyani okanye kubuxoki.
    /// Umzekelo, zonke iibhloko kwimbonakalo ye if/else kufuneka zisebenze xa i `cfg!` isetyenziselwa imeko, nokuba ivavanywa yintoni i `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ukucoca ifayile njengebinzana okanye into ngokomxholo.
    ///
    /// Ifayile ibekwe ngokuhambelana nefayile yangoku (ngokufanayo nendlela iimodyuli ezifumaneka ngayo).Indlela ebonelelweyo itolikwa ngendlela ethile yeqonga ngexesha lokudityaniswa.
    /// Umzekelo, isibongozo esine-Windows sendlela equlathe umva u-`\` ngekhe siqokelele ngokuchanekileyo kwi Unix.
    ///
    /// Sebenzisa le macro kuhlala kungumbono ombi, kuba ukuba ifayile icacisiwe njengengcaciso, iya kubekwa kwikhowudi engqongileyo ngokungacocekanga.
    /// Oku kungakhokelela ekubeni izinto eziguquguqukayo okanye imisebenzi yahluke koko kulindelwe kwifayile ukuba kukho izinto eziguquguqukayo okanye imisebenzi enegama elifanayo kwifayile yangoku.
    ///
    ///
    /// # Examples
    ///
    /// Thatha ukuba zimbini iifayile kwisikhombisi esinye neziqulatho zilandelayo:
    ///
    /// Ifayile 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Ifayile 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Ukuqulunqa i-'main.rs' kunye nokusebenzisa isiphumo sokubhina kuya kuprinta i "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yongeza into yokuba intetho ye-boolean yi `true` ngexesha lokubaleka.
    ///
    /// Oku kuyakubiza i-[`panic!`] macro ukuba intetho ebonelelweyo ayinakuvavanywa kwi `true` ngexesha lokubaleka.
    ///
    /// # Uses
    ///
    /// Amabango ahlala ekhangelwe kuzo zombini ukulungisa ingxaki kunye nokukhupha ukwakha, kwaye akunakukhubazeka.
    /// Bona i [`debug_assert!`] yamabango angavumelekanga ekukhuliseni kwakha ngokwakhona.
    ///
    /// Ikhowudi engakhuselekanga inokuxhomekeka kwi `assert!` yokunyanzelisa ixesha lokubaleka elinokuthi, ukuba laphulwe kungakhokelela kukungazithembi.
    ///
    /// Amanye amatyala okusetyenziswa kwe `assert!` kubandakanya ukuvavanywa nokunyanzeliswa kwexesha lokubaleka kwikhowudi ekhuselekileyo (okophula akunakukhokelela kukhuseleko).
    ///
    ///
    /// # Imiyalezo yesiNtu
    ///
    /// Le macro inefom yesibini, apho umyalezo wesiko we-panic unokubonelelwa kunye okanye ngaphandle kweempikiswano zokufomatha.
    /// Jonga i [`std::fmt`] yes syntax yale fomu.
    /// Amagqabantshintshi asetyenziswe njengempikiswano yefomathi aya kuvavanywa kuphela ukuba ibango liyasilela.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // Umyalezo we-panic wezi zibhengezo lixabiso elidityanisiweyo lebinzana elinikiweyo.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // umsebenzi olula kakhulu
    ///
    /// assert!(some_computation());
    ///
    /// // Qinisekisa ngomyalezo wesiko
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Umhlangano osecaleni.
    ///
    /// Funda i [unstable book] ngokusetyenziswa kwayo.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// I-LLVM-style inline Assembly.
    ///
    /// Funda i [unstable book] ngokusetyenziswa kwayo.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Imodyuli esemgceni wenqanaba lemodyuli.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Ukuprintwa kudlulise i-tokens kwimveliso esemgangathweni.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Yenza okanye ikhubaze ukulandelela ukusebenza okusetyenziselwa ukulungisa ezinye ii-macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Nika imacro esetyenziselwa ukufaka ii-macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Nika imacro esetyenzisiweyo kumsebenzi ukuyiguqula kuvavanyo lweyunithi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Nika imacro esetyenzisiweyo kumsebenzi ukuyiguqula kuvavanyo lomgangatho.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Iinkcukacha zokuphunyezwa kwe `#[test]` kunye ne `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Faka imacro esetyenziswe kwi-static ukuyibhalisa njengolwabelo lwehlabathi.
    ///
    /// Jonga kwakhona i [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Igcina into esetyenziselwa kuyo ukuba indlela edlulisiweyo iyafikeleleka, kwaye iyisuse ngenye indlela.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Yandisa zonke iimpawu ze `#[cfg]` kunye ne `#[cfg_attr]` kwisiqwenga sekhowudi esisetyenziswe kuso.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Iinkcukacha ezingazinzanga zokuphunyezwa komhlanganisi we `rustc`, sukusebenzisa.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Iinkcukacha ezingazinzanga zokuphunyezwa komhlanganisi we `rustc`, sukusebenzisa.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}