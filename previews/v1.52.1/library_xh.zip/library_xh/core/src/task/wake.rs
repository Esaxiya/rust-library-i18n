#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// I `RawWaker` ivumela umilisekisi womsebenzi oza kwenza i [`Waker`] ebonelela ngokuziphatha okuvuselelweyo.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Inesikhombisi sedatha kunye ne [virtual function pointer table (vtable)][vtable] eyenza isimilo sokuziphatha kwe `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Isikhombisi sedatha, esinokusetyenziselwa ukugcina idatha engenakuphikiswa njengoko kufunwa ngumenzi welifa.
    /// Oku kunokuba ngumzekelo
    /// isalathi esicinywe ngohlobo oluya kwi `Arc` enxulunyaniswa nomsebenzi.
    /// Ixabiso lale ndawo liyadluliselwa kuyo yonke imisebenzi eyinxalenye ye-vtable njenge parameter yokuqala.
    ///
    data: *const (),
    /// Itafile yesalathiso somsebenzi esifanelekileyo esenza isimilo sokuziphatha kwaba bavusi.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Yenza i `RawWaker` entsha ukusuka kwisalathiso se `data` kunye ne `vtable`.
    ///
    /// Isikhombisi se `data` singasetyenziselwa ukugcina idatha engenakuphikiswa njengoko kufunwa ngumenzi welifa.Oku kunokuba ngumzekelo
    /// isalathi esicinywe ngohlobo oluya kwi `Arc` enxulunyaniswa nomsebenzi.
    /// Ixabiso lesikhombisi liya kudlula kuyo yonke imisebenzi eyinxalenye ye `vtable` njengeparameter yokuqala.
    ///
    /// I `vtable` yenza ngokwezifiso indlela yokuziphatha ye `Waker` ethi yenziwe kwi `RawWaker`.
    /// Kwintsebenzo nganye kwi-`Waker`, umsebenzi onxulumene noko kwi-`vtable` ye-`RawWaker` esezantsi iya kubizwa.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Itafile yesalathiso somsebenzi ebonakalayo (vtable) ecacisa isimilo se [`RawWaker`].
///
/// Isikhombisi sidluliselwe kuyo yonke imisebenzi ngaphakathi kwento enokubakho sisikhombisi se `data` ukusuka kwinto evaliweyo ye [`RawWaker`].
///
/// Imisebenzi engaphakathi kolu lwakhiwo yenzelwe kuphela ukubizwa kwisikhombisi se `data` sento eyakhiwe ngokufanelekileyo ye [`RawWaker`] evela ngaphakathi kumiliselo lwe [`RawWaker`].
/// Ukubiza omnye wemisebenzi equlethwe usebenzisa nayiphi na enye i-`data` yesikhombisi kuya kubangela ukungachazeki.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Lo msebenzi uya kubizwa xa i-[`RawWaker`] idityaniswa, umz. Xa i-[`Waker`] apho i-[`RawWaker`] igcinwe khona.
    ///
    /// Ukuphunyezwa kwalo msebenzi kufuneka kugcine yonke imithombo yolwazi eyimfuneko kulo mzekelo ungezelelweyo we [`RawWaker`] kunye nomsebenzi onxulumene noko.
    /// Ukutsalela umnxeba i `wake` kwisiphumo se [`RawWaker`] kufuneka kukhokelele ekuvukeni komsebenzi ofanayo obuya kuvuswa yi [`RawWaker`] yoqobo.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Lo msebenzi uya kubizwa xa i `wake` ibizwa kwi [`Waker`].
    /// Kuya kufuneka ivuse umsebenzi onxulumene nale [`RawWaker`].
    ///
    /// Ukuphunyezwa kwalo msebenzi kufuneka kuqinisekiswe ukukhupha naziphi na izixhobo ezinxulunyaniswa nalo mzekelo we [`RawWaker`] kunye nomsebenzi onxulumene noko.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Lo msebenzi uya kubizwa xa i `wake_by_ref` ibizwa kwi [`Waker`].
    /// Kuya kufuneka ivuse umsebenzi onxulumene nale [`RawWaker`].
    ///
    /// Lo msebenzi uyafana ne `wake`, kodwa akufuneki usebenzise isikhombisi sedatha esibonelelweyo.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Lo msebenzi ubizwa xa i [`RawWaker`] iyehla.
    ///
    /// Ukuphunyezwa kwalo msebenzi kufuneka kuqinisekiswe ukukhupha naziphi na izixhobo ezinxulunyaniswa nalo mzekelo we [`RawWaker`] kunye nomsebenzi onxulumene noko.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Yenza i `RawWakerVTable` entsha kwimisebenzi ebonelelweyo ye `clone`, `wake`, `wake_by_ref`, kunye ne `drop`.
    ///
    /// # `clone`
    ///
    /// Lo msebenzi uya kubizwa xa i-[`RawWaker`] idityaniswa, umz. Xa i-[`Waker`] apho i-[`RawWaker`] igcinwe khona.
    ///
    /// Ukuphunyezwa kwalo msebenzi kufuneka kugcine yonke imithombo yolwazi eyimfuneko kulo mzekelo ungezelelweyo we [`RawWaker`] kunye nomsebenzi onxulumene noko.
    /// Ukutsalela umnxeba i `wake` kwisiphumo se [`RawWaker`] kufuneka kukhokelele ekuvukeni komsebenzi ofanayo obuya kuvuswa yi [`RawWaker`] yoqobo.
    ///
    /// # `wake`
    ///
    /// Lo msebenzi uya kubizwa xa i `wake` ibizwa kwi [`Waker`].
    /// Kuya kufuneka ivuse umsebenzi onxulumene nale [`RawWaker`].
    ///
    /// Ukuphunyezwa kwalo msebenzi kufuneka kuqinisekiswe ukukhupha naziphi na izixhobo ezinxulunyaniswa nalo mzekelo we [`RawWaker`] kunye nomsebenzi onxulumene noko.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Lo msebenzi uya kubizwa xa i `wake_by_ref` ibizwa kwi [`Waker`].
    /// Kuya kufuneka ivuse umsebenzi onxulumene nale [`RawWaker`].
    ///
    /// Lo msebenzi uyafana ne `wake`, kodwa akufuneki usebenzise isikhombisi sedatha esibonelelweyo.
    ///
    /// # `drop`
    ///
    /// Lo msebenzi ubizwa xa i [`RawWaker`] iyehla.
    ///
    /// Ukuphunyezwa kwalo msebenzi kufuneka kuqinisekiswe ukukhupha naziphi na izixhobo ezinxulunyaniswa nalo mzekelo we [`RawWaker`] kunye nomsebenzi onxulumene noko.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// I `Context` yomsebenzi we-asynchronous.
///
/// Okwangoku, i `Context` isebenza kuphela ukubonelela ngokufikelela kwi `&Waker` enokusetyenziselwa ukuvusa umsebenzi wangoku.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Qinisekisa ukuba thina si-future-ubungqina ngokuchasene notshintsho olwenziweyo ngokunyanzela ixesha lokuphila ukuba lingasuki (ixesha lokuphila lengxoxo liyaphikisana ngelixa indawo yokubuyela ebomini ikho ngokungafaniyo).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Yenza i `Context` entsha kwi `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Ibuyisela ireferensi kwi `Waker` ngomsebenzi wangoku.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// I `Waker` sisiphatho sokuvusa umsebenzi ngokwazisa umgwebi wayo ukuba ukulungele ukuqhutywa.
///
/// Esi sibambo sibonisa imeko ye [`RawWaker`], echaza indlela yokuziphatha evuselelayo.
///
///
/// Izixhobo [`Clone`], [`Send`], kunye ne [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Vusa umsebenzi odibene nale `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Owona mnxeba wokuvuka udluliselwe ngomnxeba osebenzayo osetyenziswayo ochazwe ngumenzi welifa.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Sukubiza i `drop`-i-waker iya kudliwa yi-`wake`.
        crate::mem::forget(self);

        // UKHUSELEKO: Oku kukhuselekile kuba i `Waker::from_raw` kuphela kwendlela
        // ukuqalisa i `wake` kunye ne `data` efuna ukuba umsebenzisi avume ukuba ikhontrakthi ye `RawWaker` igciniwe.
        //
        unsafe { (wake)(data) };
    }

    /// Vusa umsebenzi odibene nale `Waker` ngaphandle kokusebenzisa i `Waker`.
    ///
    /// Oku kuyafana ne `wake`, kodwa kunokuba nokusebenza kancinci kancinci kwimeko apho i-`Waker` eyeyakho ifumaneka.
    /// Le ndlela kufuneka ikhethwe ekubizeni i `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Owona mnxeba wokuvuka udluliselwe ngomnxeba osebenzayo osetyenziswayo ochazwe ngumenzi welifa.
        //

        // UKHUSELEKO: yabona i `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Ibuyisa i `true` ukuba le `Waker` kunye nenye i `Waker` zivuse kwa umsebenzi ofanayo.
    ///
    /// Lo msebenzi usebenza ngokuzama kakhulu, kwaye unokubuya ubuxoki naxa ii-Waker`s zingavusa loo msebenzi.
    /// Nangona kunjalo, ukuba lo msebenzi ubuyisa i-`true`, kuqinisekisiwe ukuba ii-Waker`s ziya kuvusa kwangalo msebenzi.
    ///
    /// Lo msebenzi usetyenziselwa ikakhulu iinjongo zokufezekisa.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Yenza i `Waker` entsha kwi [`RawWaker`].
    ///
    /// Ukuziphatha kwe `Waker` ebuyiselweyo akuchazwanga ukuba ikhontrakthi ichazwe kumaxwebhu ka-["RawWaker"] kwaye [`RawWakerVTable`] 'ayigcinwanga.
    ///
    /// Ke ngoko le ndlela ayikhuselekanga.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // UKHUSELEKO: Oku kukhuselekile kuba i `Waker::from_raw` kuphela kwendlela
            // ukuqalisa i `clone` kunye ne `data` efuna ukuba umsebenzisi avume ukuba ikhontrakthi ye [`RawWaker`] igciniwe.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // UKHUSELEKO: Oku kukhuselekile kuba i `Waker::from_raw` kuphela kwendlela
        // ukuqalisa i `drop` kunye ne `data` efuna ukuba umsebenzisi avume ukuba ikhontrakthi ye `RawWaker` igciniwe.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}