//! Le yimodyuli yangaphakathi esetyenziswa yi-ifmt!ixesha lokubaleka.Olu lwakhiwo lukhutshelwe kulungelelwaniso olungashukumiyo ukulungiselela imitya yefomathi ngaphambi kwexesha.
//!
//! Ezi nkcazo ziyafana nee-`ct` ezilinganayo, kodwa zahlukile kuba ezi zinokwabiwa ngokwezibalo kwaye zilungiselelwe kancinci ixesha lokubaleka
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Ulungelelwaniso olunokwenzeka olunokucelwa njengenxalenye yomyalelo wokufomatha.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Khombisa ukuba imixholo kufuneka ilungelelaniswe ngasekhohlo.
    Left,
    /// Khombisa ukuba imixholo kufuneka ilungelelaniswe ngokuchanekileyo.
    Right,
    /// Khombisa ukuba imixholo kufuneka ilungelelaniswe embindini.
    Center,
    /// Akukho lungelelwaniso luceliweyo.
    Unknown,
}

/// Isetyenziswe yi-[width](https://doc.rust-lang.org/std/fmt/#width) kunye ne-[precision](https://doc.rust-lang.org/std/fmt/#precision) ecacisa.
#[derive(Copy, Clone)]
pub enum Count {
    /// Icacisiwe ngenani lokoqobo, igcina ixabiso
    Is(usize),
    /// Icacisiwe kusetyenziswa i-`$` kunye ne-`*` syntaxes, igcina isalathiso kwi `args`
    Param(usize),
    /// Ayichazwanga ngqo
    Implied,
}