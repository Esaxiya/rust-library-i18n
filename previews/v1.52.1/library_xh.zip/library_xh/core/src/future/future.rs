#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// I-future ibonisa ikhomputha ye-asynchronous.
///
/// I-future lixabiso ekusenokwenzeka ukuba alikayigqibi ikhompyutha okwangoku.
/// Olu hlobo lwe "asynchronous value" lwenza ukuba kube lula ukuba umsonto uqhubeke nokwenza umsebenzi oluncedo ngelixa ulinde ukuba ixabiso lifumaneke.
///
///
/// # Indlela ye `poll`
///
/// Indlela engundoqo ye-future, `poll`,*ukuzama* ukusombulula i-future kwixabiso lokugqibela.
/// Le ndlela ayithinteli ukuba ixabiso alilungile.
/// Endaweni yoko, umsebenzi wangoku ucwangciselwe ukuvuswa xa kunokwenzeka ukuba wenze inkqubela phambili ngokuthi `uphinde uphinde uphinde uphinde uphinde uphinde uphinde kwakhona.
/// I `context` edluliselwe kwindlela ye `poll` inokubonelela nge [`Waker`], esisiphatho sokuvusa umsebenzi wangoku.
///
/// Xa usebenzisa i-future, awuyi kubiza i-`poll` ngokuthe ngqo, kodwa endaweni yoko i-`.await` ixabiso.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Uhlobo lwexabiso oluvelisiweyo ukugqitywa.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Ukuzama ukusombulula i-future kwixabiso lokugqibela, ukubhalisa umsebenzi wangoku wokuvuka ukuba ixabiso alikafumaneki.
    ///
    /// # Ixabiso lokubuyisa
    ///
    /// Lo msebenzi ubuya:
    ///
    /// - [`Poll::Pending`] ukuba i-future ayikakulungeli okwangoku
    /// - [`Poll::Ready(val)`] ngeziphumo `val` zale future ukuba igqityiwe ngempumelelo.
    ///
    /// Nje ukuba i future igqibe, abathengi akufuneki baphinde bayenze i `poll`.
    ///
    /// Xa i-future ingakalungeli okwangoku, i-`poll` ibuyisa i-`Poll::Pending` kwaye igcine i-clone ye-[`Waker`] ekhutshelwe kwi-[`Context`] yangoku.
    /// Le [`Waker`] iya kuvuswa xa i-future inokwenza inkqubela phambili.
    /// Umzekelo, i-future elinde isokethi ukuze ifundeke iya kubiza i-`.clone()` kwi-[`Waker`] kwaye iyigcine.
    /// Xa umqondiso ufika kwenye indawo ebonisa ukuba isokhethi iyafundeka, i [`Waker::wake`] iyabizwa kwaye umsebenzi wesokethi future uyavuswa.
    /// Nje ukuba umsebenzi uvuswe, kuya kufuneka izame i `poll` i future kwakhona, enokuthi okanye ingenakho ukuvelisa ixabiso lokugqibela.
    ///
    /// Qaphela ukuba kwiifowuni ezininzi ukuya kwi-`poll`, kuphela yi-[`Waker`] ukusuka kwi-[`Context`] edluliselwe kweyona fowuni yamva nje ekufuneka icwangciselwe ukufumana ukuvuka.
    ///
    /// # Iimpawu zexesha lokubaleka
    ///
    /// I-Futures iyodwa zi *inert*;Kuya kufuneka *bavotelwe* ukuze benze inkqubela phambili, oko kuthetha ukuba ngalo lonke ixesha kuvuswa umsebenzi okhoyo ngoku, kufanele ukuba uphinde uphinde uphinde uphinde uphinde uphinde uphinde uphinde uphinde uphinde uqhubeke ``uvoto`salinde i futures ukuba isenomdla kuyo.
    ///
    /// Umsebenzi we `poll` awubizwa ngokuphindaphindiweyo kwi-loop eqinileyo-endaweni yoko, kufuneka ubizwe kuphela xa i-future ibonisa ukuba ikulungele ukwenza inkqubela phambili (ngokubiza i-`wake()`).
    /// Ukuba uqhelene ne-`poll(2)` okanye i-`select(2)` syscalls kwi-Unix kufanelekile ukuba uqaphele ukuba i-futures ngokwesiqhelo ayenzi *ngxaki* ye "all wakeups must poll all events";zifana ne `epoll(4)`.
    ///
    /// Ukuphunyezwa kwe `poll` kufuneka izame ukubuyela ngokukhawuleza, kwaye akufuneki ibhloke.Ukubuya ngokukhawuleza kuthintela ngokungeyomfuneko ukuvala imisonto okanye imixholo yomnyhadala.
    /// Ukuba kuyaziwa ngaphambi kwexesha lokuba umnxeba oya kwi `poll` unokugqibela ngokuthatha ixeshana, umsebenzi kufuneka ukhutshelwe echibini lomsonto (okanye into efanayo) ukuqinisekisa ukuba i `poll` ingabuya ngokukhawuleza.
    ///
    /// # Panics
    ///
    /// Nje ukuba i future igqibe (ukubuyisa i `Ready` ukusuka kwi `poll`), ukubiza indlela yayo ye `poll` kwakhona inokuba yi panic, ibhloke ngonaphakade, okanye ibangele ezinye iintlobo zeengxaki;i `Future` trait ayibeki zidingo kwifowuni enjalo.
    /// Nangona kunjalo, njengoko indlela ye `poll` ingaphawulwanga i `unsafe`, imigaqo yesiqhelo ye Rust iyasebenza: iifowuni mazingaze zibangele isimilo esingachazwanga (inkohliso yenkumbulo, ukusetyenziswa gwenxa kwemisebenzi ye `unsafe`, okanye izinto ezinje), nokuba injani imeko ka future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}