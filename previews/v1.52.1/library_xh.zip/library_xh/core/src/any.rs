//! Le modyuli inyanzelisa i `Any` trait, eyenza ukuba uchwethezo olunamandla lwalo naluphi na uhlobo lwe `'static` lubonakalise ixesha lokubaleka.
//!
//! `Any` ngokwayo inokusetyenziselwa ukufumana i `TypeId`, kwaye inezinto ezininzi xa isetyenziswa njenge trait.
//! Njenge-`&dyn Any` (into ebolekiweyo ye trait), ineendlela ze-`is` kunye ne-`downcast_ref`, ukuvavanya ukuba ixabiso eliqulathiweyo lolohlobo olunikiweyo, kunye nokufumana isalathiso kwixabiso langaphakathi njengohlobo.
//! Njenge `&mut dyn Any`, kukwakhona indlela ye `downcast_mut` yokufumana ireferensi enokuguquguquka kwixabiso langaphakathi.
//! `Box<dyn Any>` yongeza indlela ye `downcast`, ethi izame ukuguqula ibe yi `Box<T>`.
//! Jonga amaxwebhu e [`Box`] ngeenkcukacha ezipheleleyo.
//!
//! Qaphela ukuba i `&dyn Any` inikwe umda kuvavanyo nokuba ixabiso lolohlobo lwekhonkrithi oluchaziweyo, kwaye alunakusetyenziselwa ukuvavanya ukuba ingaba uhlobo lusebenzisa i trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Izikhokelo ze-Smart kunye ne `dyn Any`
//!
//! Inxalenye yokuziphatha ekufuneka uyikhumbule xa usebenzisa i-`Any` njenge-trait into, ngakumbi ngeendlela ezinje nge-`Box<dyn Any>` okanye i-`Arc<dyn Any>`, kukuba ukubiza nje i-`.type_id()` kwixabiso kuya kuvelisa i-`TypeId` yesikhongozeli *, hayi into esezantsi ye trait.
//!
//! Oku kunokuthintelwa ngokuguqula i-smart pointer ibe yi-`&dyn Any` endaweni yoko, eya kuthi ibuyisele i-`TypeId` yento leyo.
//! Umzekelo:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Kusenokwenzeka ukuba ufuna oku:
//! let actual_id = (&*boxed).type_id();
//! // ... kunale:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Cinga ngemeko apho sifuna ukuphuma nexabiso elidluliselwe emsebenzini.
//! Siyalazi ixabiso esisebenza kulo lokulungisa izixhobo, kodwa asilwazi uhlobo lwalo lwekhonkrithi.Sifuna ukunika unyango olukhethekileyo kwiindidi ezithile: kule meko siprinta ubude bexabiso lomtya ngaphambi kwexabiso lazo.
//! Asilwazi uhlobo lwekhonkrithi lwexabiso lethu ngexesha lokudibanisa, ke kufuneka sisebenzise ixesha lokubaleka endaweni yoko.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Umsebenzi weLogger kulo naluphi na uhlobo olusebenzisa i-Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Zama ukuguqula ixabiso lethu libe yi `String`.
//!     // Ukuba siphumelele, sifuna ukukhupha ubude beString`` kunye nexabiso laso.
//!     // Ukuba akunjalo, luhlobo olwahlukileyo: lushicilele ngaphandle kokuhombisa.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Lo msebenzi ufuna ukuphuma kwiparameter ngaphambi kokuba wenze umsebenzi nawo.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... wenze omnye umsebenzi
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Nayiphi na i-trait
///////////////////////////////////////////////////////////////////////////////

/// I-trait yokulinganisa ukuthayipha okunamandla.
///
/// Uninzi lweentlobo luphumeza i `Any`.Nangona kunjalo, naluphi na uhlobo oluqulathe isalathiso esingeyiyo ``static` alwenzi.
/// Bona i [module-level documentation][mod] ngeenkcukacha ezithe kratya.
///
/// [mod]: crate::any
// Le trait ayikhuselekanga, nangona sixhomekeke kwimisebenzi yayo kuphela ye-`type_id` yokusebenza kwikhowudi engakhuselekanga (umz., `downcast`).Ngokwesiqhelo, iya kuba yingxaki, kodwa kuba ekuphela kwe-`Any` kukuphunyezwa kwengubo, ayikho enye ikhowudi enokusebenzisa i `Any`.
//
// Sinokwenza ukuba le trait ingakhuselekanga-ayizukubangela uqhekeko, kuba silawula konke ukuphunyezwa-kodwa sikhetha ukungazenzi njengoko oko kunganyanzelekanga kwaye kunokubadida abasebenzisi malunga nokwahlula okungakhuselekanga kwe traits kunye neendlela ezingakhuselekanga (okt, I `type_id` isaza kukhuseleka ukuyitsalela umnxeba, kodwa singafuna ukubonisa njalo kumaxwebhu).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Ifumana i `TypeId` ye `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Iindlela zokwandiswa kwazo naziphi na izinto ze-trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Qinisekisa ukuba iziphumo zomzekelo, ukujoyina umsonto kunokuprintwa kwaye ke kusetyenziswa i `unwrap`.
// Ngamana ekugqibeleni akusayi kubakho mfuneko yokuba ukuthunyelwa kusebenza kunye nokusasaza.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Ibuyisa i-`true` ukuba uhlobo lwebhokisi edibeneyo iyafana ne `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Fumana i `TypeId` yolu hlobo lomsebenzi uqinisekisiwe ngayo.
        let t = TypeId::of::<T>();

        // Fumana i-`TypeId` yohlobo lwento kwi-trait object (`self`).
        let concrete = self.type_id();

        // Thelekisa zombini `TypeId`s ngokulingana.
        t == concrete
    }

    /// Ibuyisa isalathiso esithile kwixabiso lebhokisi ukuba loludidi `T`, okanye i `None` ukuba akunjalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // UKHUSELEKO: jonga nje ukuba sikhombe kuhlobo oluchanekileyo, kwaye sinokuxhomekeka
            // Ukujonga ukhuseleko kwimemori kuba siphumeze naziphi na iintlobo;azikho ezinye i-impls ezinokubakho njengoko zinokuphikisana ne-impl yethu.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Ibuyisa ireferensi enokuguquguquka kwixabiso lebhokisi ukuba ikuluhlobo `T`, okanye i `None` ukuba ayisiyiyo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // UKHUSELEKO: jonga nje ukuba sikhombe kuhlobo oluchanekileyo, kwaye sinokuxhomekeka
            // Ukujonga ukhuseleko kwimemori kuba siphumeze naziphi na iintlobo;azikho ezinye i-impls ezinokubakho njengoko zinokuphikisana ne-impl yethu.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Phambili ngendlela echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Phambili ngendlela echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Phambili ngendlela echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Phambili ngendlela echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Phambili ngendlela echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Phambili ngendlela echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// Uhlobo lwe-ID kunye neendlela zalo
///////////////////////////////////////////////////////////////////////////////

/// I `TypeId` imele isazisi esikhethekileyo sodidi.
///
/// I-`TypeId` nganye yinto e-opaque engakuvumeli ukujongwa okungaphakathi kodwa ivumela imisebenzi esisiseko enjengokwakha, ukuthelekisa, ukushicilela, kunye nokubonisa.
///
///
/// I `TypeId` okwangoku ifumaneka kuphela kwiindidi ezinikezela kwi `'static`, kodwa olu thintelo lungasuswa kwi future.
///
/// Ngelixa i `TypeId` isebenzisa i `Hash`, `PartialOrd`, kunye ne `Ord`, kubalulekile ukuba uqaphele ukuba i-hashes kunye noku-odola kuya kwahluka phakathi kokukhutshwa kwe Rust.
/// Lumkela ukuthembela kubo ngaphakathi kwekhowudi yakho!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Ibuyisa i `TypeId` yohlobo lomsebenzi ongaqhelekanga oqinisekisiweyo ngawo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Ibuyisa igama lodidi njengesilayidi somtya.
///
/// # Note
///
/// Oku kwenzelwe ukusetyenziswa kwesifo.
/// Imixholo ngqo kunye nefomathi yomtya obuyisiweyo ayichazwanga, ngaphandle kokuba yinkcazo yomzamo wohlobo.
/// Umzekelo, phakathi komtya onokubuyisa i `type_name::<Option<String>>()` zii `"Option<String>"` kunye ne `"std::option::Option<std::string::String>"`.
///
///
/// Umtya obuyisiweyo akufuneki uthathelwe ingqalelo njengolona hlobo luchazayo lodidi njengoko iintlobo ezininzi zinokwenza imephu kwigama lohlobo olunye.
/// Ngokufanayo, akukho siqinisekiso sokuba onke amalungu ohlobo luya kuvela kumtya obuyiselweyo: umzekelo, izikhombisi zobomi ngoku azifakwanga.
/// Ukongeza, iziphumo zinokutshintsha phakathi kweenguqulelo zomhlanganisi.
///
/// Ukuphunyezwa kwangoku kusetyenziswa isiseko esifanayo njengesihlanganisi sokuchonga kunye ne-debuginfo, kodwa oku akuqinisekiswanga.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Ibuyisa igama lohlobo lwexabiso elalathekileyo njengesiqwenga somtya.
/// Oku kuyafana ne `type_name::<T>()`, kodwa kunokusetyenziswa apho uhlobo lokwahluka lungafumaneki ngokulula.
///
/// # Note
///
/// Oku kwenzelwe ukusetyenziswa kwesifo.Imixholo ngqo kunye nefomathi yomtya ayichazwanga, ngaphandle kokuba yinkcazo yomzamo wohlobo.
/// Umzekelo, i `type_name_of_val::<Option<String>>(None)` inokubuyisa i `"Option<String>"` okanye i `"std::option::Option<std::string::String>"`, kodwa hayi i `"foobar"`.
///
/// Ukongeza, iziphumo zinokutshintsha phakathi kweenguqulelo zomhlanganisi.
///
/// Lo msebenzi awusombululi izinto ze-trait, oko kuthetha ukuba i-`type_name_of_val(&7u32 as &dyn Debug)` inokubuyisa i-`"dyn Debug"`, kodwa hayi i-`"u32"`.
///
/// Igama lodidi akufuneki ukuba lithathelwe ingqalelo njengesichongi esikhethekileyo sohlobo;
/// Iindidi ezininzi zinokwabelana ngegama elifanayo.
///
/// Ukuphunyezwa kwangoku kusetyenziswa isiseko esifanayo njengesihlanganisi sokuchonga kunye ne-debuginfo, kodwa oku akuqinisekiswanga.
///
/// # Examples
///
/// Kuprintwa ukungagqibeki okupheleleyo kunye neendidi zokudada.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}