//! Ukusebenza kwi-ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Jonga ukuba zonke i-byte ezikule slice zingaphakathi kuluhlu lwe-ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Jonga ukuba izilayi ezibini zi-ASCII kwimeko yokungakhathali.
    ///
    /// Iyafana ne `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, kodwa ngaphandle kokwaba kunye nokukopa okwethutyana.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Guqula esi silayi siye kwi-ASCII ephezulu yecala elilinganayo endaweni.
    ///
    /// Iileta ze-ASCII 'a' ukuya kwi 'z' zimiselwe imephu ukuya kwi 'A' ukuya kwi 'Z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukubuyisa ixabiso elitsha elingasetyenziswanga ngaphandle kokuguqula esele ikho, sebenzisa i [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Guqula esi silayi siye kwi-ASCII yamatyala asezantsi alinganayo endaweni.
    ///
    /// Iileta ze-ASCII 'A' ukuya kwi 'Z' zimiselwe imephu ukuya kwi 'a' ukuya kwi 'z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukubuyisa ixabiso elitsha elisezantsi ngaphandle kokuguqula esele ikho, sebenzisa i [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Ibuyisa i `true` ukuba ikhona i-byte kwigama `v` elingu-nonascii (>=128).
/// Snarfed ukusuka kwi `../str/mod.rs`, eyenza into efanayo yokuqinisekiswa kwe utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Lungiselelwe uvavanyo lwe-ASCII oluya kusebenzisa imisebenzi ye-at-a-a-time endaweni ye-byte-at-a-time imisebenzi (xa kunokwenzeka).
///
/// Ialgorithm esiyisebenzisayo apha ilula kakhulu.Ukuba i `s` imfutshane kakhulu, sijonga nje i-byte nganye kwaye siyenze ngayo.Ngaphandle koko:
///
/// - Funda igama lokuqala elinomthwalo ongalungelelaniswanga.
/// - Ukulungelelanisa isikhombisi, funda amagama alandelayo kude kube sekupheleni ngemithwalo engqinelanayo.
/// - Funda i `usize` yokugqibela ukusuka kwi `s` ngomthwalo ongalungelelaniswanga.
///
/// Ukuba nayiphi na le mithwalo ivelisa into i `contains_nonascii` (above) ebuyisela inyani kuyo, siyazi ukuba impendulo ayiyonyani.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ukuba asizukufumana nto kwi-word-at-a-time implementation, buyela kwi-scalar loop.
    //
    // Sikwenza oku kulwakhiwo apho i `size_of::<usize>()` ingalungelelananga ngokwaneleyo ne `usize`, kuba ityala le-edge elingaqhelekanga.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Sisoloko silifunda igama lokuqala elingatyalwanga, oko kuthetha ukuba i `align_offset` yiyo
    // 0, singaphinda sifunde ixabiso elifanayo kulungelelwaniso olufundwayo.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // UKHUSELEKO: Siqinisekisa i `len < USIZE_SIZE` apha ngasentla.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Sikukhangele oku ngasentla, ngokuthe ngqo.
    // Qaphela ukuba i `offset_to_aligned` nokuba yi `align_offset` okanye i `USIZE_SIZE`, zombini ezi zikhangelwe ngokucacileyo apha ngasentla.
    //
    debug_assert!(offset_to_aligned <= len);

    // UKHUSELEKO: i-word_ptr (ilungelelaniswe ngokufanelekileyo) usize ptr esiyisebenzisayo ukufunda
    // Isiqwenga esiphakathi sesilayidi.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` sisalathiso se-byte se-`word_ptr`, esisetyenziselwa ukukhangela ukuphela kokujikeleza.
    let mut byte_pos = offset_to_aligned;

    // Iparanoia jonga malunga nokulungelelaniswa, kuba siza kwenza imithwalo engalinganiyo.
    // Ukuziqhelanisa oku kufanelekile ukuba kungathintelwa i-bug kwi `align_offset` nangona.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Funda amagama alandelayo kude kube lilizwi lokugqibela elilungelelanisiweyo, ngaphandle kwelizwi lokugqibela elilungelelanisiweyo ngokwalo ukuba lenziwe ngomsila emva kwexesha, ukuqinisekisa ukuba umsila uhlala uyi-`usize` ubukhulu ukuya kwi-branch `byte_pos == len` eyongezelelweyo.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Jonga ubunyani bokuba ukufundwa kuyimida
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Kwaye ukuba uqikelelo lwethu malunga ne `byte_pos` lubambe.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // UKHUSELEKO: Siyazi ukuba i `word_ptr` ilungelelaniswe ngokufanelekileyo (ngenxa ye-
        // align_offset`), kwaye siyazi ukuba sinee-byte ezaneleyo phakathi kwe `word_ptr` kunye nesiphelo
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // UKHUSELEKO: Siyayazi loo `byte_pos <= len - USIZE_SIZE`, nto leyo ethetha ukuba
        // emva kwale `add`, i `word_ptr` iya kuba yeyokugqibela-isiphelo.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Ukutshekishwa kokucoceka ukuqinisekisa ukuba inye kuphela i `usize` eseleyo.
    // Oku kufanele kuqinisekiswe yimeko yethu yeluphu.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // UKHUSELEKO: Oku kuxhomekeke kwi `len >= USIZE_SIZE`, esiyijonga ekuqaleni.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}