//! Imisebenzi yasimahla yokwenza i `&[T]` kunye ne `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Yenza isilayi kwisikhombisi kunye nobude.
///
/// Impikiswano ye `len` linani lezinto eziyi **, hayi inani lee-byte.
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `data` kufuneka ibe yi [valid] xa ifundelwa i-`len * mem::size_of::<T>()` ii-byte ezininzi, kwaye kufuneka zilungelelaniswe ngokufanelekileyo.Oku kuthetha ngokukodwa:
///
///     * Uluhlu lonke lwenkumbulo yesi silayi kufuneka siqulathwe kwinto enye eyabelweyo!
///       Iziqwenga azinakuze zijikeleze izinto ezininzi ezabiweyo.Jonga i [below](#incorrect-usage) umzekelo ngokungachanekanga ungayithathi le nto.
///     * `data` kufuneka zingangqinelani kwaye zilungelelaniswe nkqu nakwizilayi zobude obunguziro.
///     Isizathu esinye soku kukuba ulungelelwaniso lwe-enum lunokuxhomekeka kwizalathiso (kubandakanya izilayi zobuphi na ubude) zilungelelaniswe kwaye zingabinanto ukwahlulahlula kwezinye idatha.
///     Unokufumana isikhombisi esinokusetyenziswa njenge-`data` kwizilayi ezide zobude usebenzisa i [`NonNull::dangling()`].
///
/// * `data` Kuya kufuneka ukhombe kwi `len` ngokulandelelana ngokufanelekileyo amaxabiso aqaliswe ngohlobo `T`.
///
/// * Imemori ekubhekiselwe kuyo kwisilayidi esibuyisiweyo akufuneki iguqulwe ngalo lonke ixesha lokuphila le `'a`, ngaphandle kwangaphakathi kwe `UnsafeCell`.
///
/// * Ubungakanani bebonke be-`len * mem::size_of::<T>()` yesilayidi kufuneka kungabikho ngaphezulu kwe `isize::MAX`.
///   Jonga amaxwebhu okhuseleko e [`pointer::offset`].
///
/// # Caveat
///
/// Ubomi besilayidi esibuyisiweyo kuthathelwa ingqalelo ekusebenziseni kwayo.
/// Ukuthintela ukusetyenziswa gwenxa ngengozi, kuyacetyiswa ukuba ubophele ixesha lobomi nakowuphi na umthombo wobomi obukhuselekileyo kwimeko, njengokubonelela ngomsebenzi wokuncedisa uthatha ixesha lokudla kwexabiso lesilayidi, okanye isichazi esicacileyo.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // bonisa isilayi kwinto enye
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Ukusetyenziswa ngokungachanekanga
///
/// Lo msebenzi ulandelayo we `join_slices` ngu **ongacacanga** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Isimangalo esingentla siqinisekisa ukuba i-`fst` kunye ne-`snd` ziyahambelana, kodwa zisenokuqulatha ngaphakathi kwe _different allocated objects_, kwimeko apho ukwenza esi silayi kukuziphatha okungachazwanga.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` kunye ne `b` zizinto ezahlukileyo ezabiweyo ...
///     let a = 42;
///     let b = 27;
///     // ... enokuthi nangona kunjalo ibekwe ngokungafaniyo kwimemori: || |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Yenza ukusebenza okufanayo ne [`from_raw_parts`], ngaphandle kokuba isilayidi esiguqukayo sibuyisiwe.
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `data` kufuneka ibe yi-[valid] kuzo zombini ezifundwayo kwaye ubhalele i-`len * mem::size_of::<T>()` ii-byte ezininzi, kwaye kufuneka zilungelelaniswe ngokufanelekileyo.Oku kuthetha ngokukodwa:
///
///     * Uluhlu lonke lwenkumbulo yesi silayi kufuneka siqulathwe kwinto enye eyabelweyo!
///       Iziqwenga azinakuze zijikeleze izinto ezininzi ezabiweyo.
///     * `data` kufuneka zingangqinelani kwaye zilungelelaniswe nkqu nakwizilayi zobude obunguziro.
///     Isizathu esinye soku kukuba ulungelelwaniso lwe-enum lunokuxhomekeka kwizalathiso (kubandakanya izilayi zobuphi na ubude) zilungelelaniswe kwaye zingabinanto ukwahlulahlula kwezinye idatha.
///
///     Unokufumana isikhombisi esinokusetyenziswa njenge-`data` kwizilayi ezide zobude usebenzisa i [`NonNull::dangling()`].
///
/// * `data` Kuya kufuneka ukhombe kwi `len` ngokulandelelana ngokufanelekileyo amaxabiso aqaliswe ngohlobo `T`.
///
/// * Imemori ekubhekiselwe kuyo kwisilayidi esibuyisiweyo akufuneki ukuba ifumaneke ngayo nayiphi na enye isikhombisi (esingafakwanga kwixabiso lokubuyisa) ngexesha lokuphila kwe `'a`.
///   Zombini iindlela zokufunda nokubhala azivumelekanga.
///
/// * Ubungakanani bebonke be-`len * mem::size_of::<T>()` yesilayidi kufuneka kungabikho ngaphezulu kwe `isize::MAX`.
///   Jonga amaxwebhu okhuseleko e [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Guqula ireferensi ibe ngu-T kwisilayidi sobude 1 (ngaphandle kokukopa).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Guqula ireferensi ibe ngu-T kwisilayidi sobude 1 (ngaphandle kokukopa).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}