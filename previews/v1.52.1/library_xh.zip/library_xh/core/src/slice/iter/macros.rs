//! IiMacros ezisetyenziswa ngabavavanyi besilayidi.

// Uluhlu lwe-is_empty kunye nelen lenza umahluko omkhulu wentsebenzo
macro_rules! is_empty {
    // Indlela esibusebenzisa ngayo ubude be-iterator yeZST, oku kusebenza zombini kwi-ZST kunye nakwi-non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Ukuphelisa ukujongwa kwemida ethile (jonga i `position`), sibala ubude ngendlela engalindelekanga.
// (Kuvavanywa `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ngamanye amaxesha sisetyenziswa ngaphakathi kwebhloko engakhuselekanga

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Le _cannot_ isebenzisa i `unchecked_sub` kuba sixhomekeke ekusongeleni ukumela ubude beZerice iterators.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Siyazi ukuba i `start <= end`, inokwenza ngcono kune `offset_from`, efuna ukujongana nesayini.
            // Ngokumisela iiflegi ezifanelekileyo apha sinokuxelela i-LLVM le, eyincedayo isuse ukujonga imida.
            // UKHUSELEKO: Ngohlobo olungangenisiyo, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ngokuxelela i-LLVM ukuba izikhombisi zahlulwe ngohlobo lobungakanani bohlobo, inokulungiselela i `len() == 0` ukuya kwi `start == end` endaweni ye `(end - start) < size`.
            //
            // UKHUSELEKO: Ngohlobo olungangenisiyo, izikhombisi zilungelelaniswe ukuze
            //         Umgama phakathi kwabo kufuneka ubephindaphindwe ngobungakanani bepeeee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Inkcazo ekwabelwana ngayo ye `Iter` kunye ne `IterMut` iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Ibuyisa into yokuqala kwaye ihambise ukuqala kwe-iterator phambili nge-1.
        // Iphucula kakhulu ukusebenza xa kuthelekiswa nomsebenzi odwelisiweyo.
        // Iterator mayingabinanto.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Ibuyisa into yokugqibela kwaye ihambise isiphelo se-iterator ngasemva nge-1.
        // Iphucula kakhulu ukusebenza xa kuthelekiswa nomsebenzi odwelisiweyo.
        // Iterator mayingabinanto.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Shwabanisa iterator xa i-T yi-ZST, ngokuhambisa isiphelo se-iterator ngasemva nge-`n`.
        // `n` akufuneki idlule kwi `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Umsebenzi woMncedisi ekwenzeni isilayidi esivela kwi-iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // UKHUSELEKO: iterator yenziwa kwisilayidi esine-pointer
                // `self.ptr` kunye nobude `len!(self)`.
                // Oku kuqinisekisa ukuba zonke izinto ezifunekayo ze-`from_raw_parts` ziyazaliseka.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Umsebenzi woMncedisi wokuhambisa ukuqala kwe-iterator phambili ngezinto ze-`offset`, ukubuyisa isiqalo esidala.
            //
            // Ayikhuselekanga ngenxa yokuba iseti engafanelekanga mayingagqithi kwi `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // UKHUSELEKO: umntu ofowunayo uqinisekisa ukuba i `offset` ayidluli kwi `self.len()`,
                    // ke esi sikhombisi sitsha singaphakathi kwe `self` kwaye ngenxa yoko iqinisekisiwe ukuba ayisiyiyo.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Umsebenzi wokunceda ukuhambisa isiphelo se-iterator ngasemva ngezinto ze `offset`, ukubuyisa isiphelo esitsha.
            //
            // Ayikhuselekanga ngenxa yokuba iseti engafanelekanga mayingagqithi kwi `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // UKHUSELEKO: umntu ofowunayo uqinisekisa ukuba i `offset` ayidluli kwi `self.len()`,
                    // eqinisekisiweyo ukuba ingagqithisi i `isize`.
                    // Kwakhona, isikhombisi esikhokelela kwimida ye `slice`, esizalisekisa ezinye iimfuno ze `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // inokuphunyezwa ngezilayi, kodwa oku kuthintela ukujongwa kwemida

                // UKHUSELEKO: Iifowuni ze `assume` zikhuselekile okoko isikhombisi sokuqala
                // kufuneka zingasebenzi, kwaye izilayi ngaphezulu kwee-non-ZSTs kufuneka kwakhona zibe nesikhombisi esingapheliyo.
                // Umnxeba oya kwi `next_unchecked!` ukhuselekile kuba sijonga ukuba ngaba iterator ayinanto kuqala.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Le iterator ngoku ayinanto.
                    if mem::size_of::<T>() == 0 {
                        // Kuya kufuneka siyenze ngale ndlela njengoko i `ptr` isenokungaze ibe ngu-0, kodwa i-`end` inokuba (ngenxa yokusonga).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // UKHUSELEKO: isiphelo asinakuba ngu-0 ukuba T asiyiyo i-ZST kuba i-ptr ayi-0 kunye nesiphelo>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // UKHUSELEKO: Sikumda.I `post_inc_start` yenza into elungileyo nakwiZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Sigqithisela kulwenziwo olungagqibekanga, olusebenzisa i `try_fold`, kuba oku kuphumeza ngokulula kuvelisa i-LLVM IR encinci kwaye iyakhawuleza ukuqokelela.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Sigqithisela kulwenziwo olungagqibekanga, olusebenzisa i `try_fold`, kuba oku kuphumeza ngokulula kuvelisa i-LLVM IR encinci kwaye iyakhawuleza ukuqokelela.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Sigqithisela kulwenziwo olungagqibekanga, olusebenzisa i `try_fold`, kuba oku kuphumeza ngokulula kuvelisa i-LLVM IR encinci kwaye iyakhawuleza ukuqokelela.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Sigqithisela kulwenziwo olungagqibekanga, olusebenzisa i `try_fold`, kuba oku kuphumeza ngokulula kuvelisa i-LLVM IR encinci kwaye iyakhawuleza ukuqokelela.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Sigqithisela kulwenziwo olungagqibekanga, olusebenzisa i `try_fold`, kuba oku kuphumeza ngokulula kuvelisa i-LLVM IR encinci kwaye iyakhawuleza ukuqokelela.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Sigqithisela kulwenziwo olungagqibekanga, olusebenzisa i `try_fold`, kuba oku kuphumeza ngokulula kuvelisa i-LLVM IR encinci kwaye iyakhawuleza ukuqokelela.
            // Kwakhona, i `assume` ithintela ukujongwa kwemida.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // UKHUSELEKO: siqinisekisiwe ukuba semideni yi-loop invariant:
                        // xa i `i >= n`, i `self.next()` ibuyisa i `None` kunye nekhefu lokuvula.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Sigqithisela kulwenziwo olungagqibekanga, olusebenzisa i `try_fold`, kuba oku kuphumeza ngokulula kuvelisa i-LLVM IR encinci kwaye iyakhawuleza ukuqokelela.
            // Kwakhona, i `assume` ithintela ukujongwa kwemida.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // UKHUSELEKO: I-`i` kufuneka ibe ngaphantsi kwe-`n` kuba iqala nge-`n`
                        // kwaye iyancipha kuphela.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `i` ikumda we
                // Isilayidi esisisiseko, ke i `i` ayinakugqithisa i `isize`, kwaye izingqinisiso ezibuyisiweyo ziqinisekisiwe ukuba ziya kubhekisa kwinto yesilayidi kwaye ke ngokuqinisekileyo ziqinisekisiwe.
                //
                // Qaphela ukuba lowo ufowunayo uqinisekisa ukuba asizukuphinda sibizwe ngesalathiso esinye kwakhona, kwaye nokuba azikho ezinye iindlela ezinokufikelela kule nkxaso-mali ibizwa, ke kufanelekile ukuba ireferensi ebuyiselweyo iguquke kwimeko ye
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // inokuphunyezwa ngezilayi, kodwa oku kuthintela ukujongwa kwemida

                // UKHUSELEKO: Iifowuni ze `assume` zikhuselekile kuba isikhombisi sesilayidi kufuneka singabinanto,
                // kunye nezilayi ngaphezulu kwee-non-ZSTs kufuneka kwakhona zibe nesikhombisi esingapheliyo.
                // Umnxeba oya kwi `next_back_unchecked!` ukhuselekile kuba sijonga ukuba ngaba iterator ayinanto kuqala.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Le iterator ngoku ayinanto.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // UKHUSELEKO: Sikumda.I-`pre_dec_end` yenza into elungileyo nakwii-ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}