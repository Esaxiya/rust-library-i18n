//! Ukuhlelwa kwesilayidi
//!
//! Le modyuli iqulethe ialgorithm yokuhlela esekwe ku-Orson Peters 'oyisa ipateni ekhawulezayo, epapashwe kwi: <https://github.com/orlp/pdqsort>
//!
//!
//! Ukuhlelwa okungazinzanga kuyahambelana ne-libcore kuba ayinikezi imemori, ngokungafaniyo nokuphunyezwa okuzinzileyo kokumiliselwa.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Xa ilahliwe, iikopi ukusuka kwi `src` ukuya kwi `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // UKHUSELEKO: Olu luhlobo lwabancedisi.
        //          Nceda ujonge ekusebenziseni kwayo ngokuchanekileyo.
        //          Ngokufanelekileyo, umntu kufuneka aqiniseke ukuba i-`src` kunye ne-`dst` azidluli njengoko kufunwa yi-`ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Ishenxisa into yokuqala iye ngasekunene ide ifumane into enkulu okanye elinganayo.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // UKHUSELEKO: Imisebenzi engakhuselekanga engezantsi ibandakanya isalathiso ngaphandle kwetsheki ebotshiweyo (`get_unchecked` kunye `get_unchecked_mut`)
    // kunye nokukopa inkumbulo (`ptr::copy_nonoverlapping`).
    //
    // a.Isalathiso:
    //  1. Sijonge ubungakanani boludwe ku>=2.
    //  2. Zonke izalathiso esiza kuzenza zihlala ziphakathi kwe {0 <= index < len} ubukhulu becala.
    //
    // b.Ukukopa kwimemori
    //  1. Sifumana izikhombisi kwizalathiso eziqinisekisiweyo ukuba zisemthethweni.
    //  2. Azinakugqitha kuba sifumana izikhombisi kwiiyantlukwano zesilayidi.
    //     Ngokufanelekileyo, i `i` kunye ne `i-1`.
    //  3. Ukuba isilayi silungelelaniswe ngokufanelekileyo, izinto zilungelelaniswe ngokufanelekileyo.
    //     Luxanduva lomntu ofowunayo ukuqinisekisa ukuba isilayi silungelelaniswe ngokufanelekileyo.
    //
    // Jonga iikhomenti ezingezantsi ngolwazi oluthe kratya.
    unsafe {
        // Ukuba izinto zokuqala ezimbini zingaphandle komyalelo ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Funda into yokuqala kukwahlulahlula okwabelweyo.
            // Ukuba umsebenzi olandelayo wokuthelekisa i-panics, i-`hole` iya kulahla kwaye ibhale ngokuzenzekelayo into leyo kwisilayidi.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Hambisa`i`-th indawo enye ukuya ekhohlo, ngaloo ndlela ushenxisela umngxunya ngasekunene.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` iyehla kwaye ke ikopi i `tmp` iye kumngxuma oseleyo kwi `v`.
        }
    }
}

/// Shenxisela into yokugqibela ekhohlo ide idibane nento encinci okanye elinganayo.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // UKHUSELEKO: Imisebenzi engakhuselekanga engezantsi ibandakanya isalathiso ngaphandle kwetsheki ebotshiweyo (`get_unchecked` kunye `get_unchecked_mut`)
    // kunye nokukopa inkumbulo (`ptr::copy_nonoverlapping`).
    //
    // a.Isalathiso:
    //  1. Sijonge ubungakanani boludwe ku>=2.
    //  2. Konke ukwenza isalathiso esiza kukwenza kuhlala kuphakathi kwe `0 <= index < len-1` ubukhulu becala.
    //
    // b.Ukukopa kwimemori
    //  1. Sifumana izikhombisi kwizalathiso eziqinisekisiweyo ukuba zisemthethweni.
    //  2. Azinakugqitha kuba sifumana izikhombisi kwiiyantlukwano zesilayidi.
    //     Ngokufanelekileyo, i `i` kunye ne `i+1`.
    //  3. Ukuba isilayi silungelelaniswe ngokufanelekileyo, izinto zilungelelaniswe ngokufanelekileyo.
    //     Luxanduva lomntu ofowunayo ukuqinisekisa ukuba isilayi silungelelaniswe ngokufanelekileyo.
    //
    // Jonga iikhomenti ezingezantsi ngolwazi oluthe kratya.
    unsafe {
        // Ukuba izinto ezimbini zokugqibela ziphelelwe lixesha ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Funda into yokugqibela kulungelelwaniso olwabiwe kwisitaki.
            // Ukuba umsebenzi olandelayo wokuthelekisa i-panics, i-`hole` iya kulahla kwaye ibhale ngokuzenzekelayo into leyo kwisilayidi.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Hambisa`i`-th indawo enye uye ngasekunene, ngaloo ndlela ushenxisela umngxunya ngasekhohlo.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` iyehla kwaye ke ikopi i `tmp` iye kumngxuma oseleyo kwi `v`.
        }
    }
}

/// Inxalenye yoluhlu lwesilayidi ngokutshintsha izinto ezingaphandle komyalelo zijikeleze.
///
/// Ibuyisa i `true` ukuba isilayidi sihleliwe ekugqibeleni.Lo msebenzi ngu-O O (*n*) elona tyala libi.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Elona nani liphezulu leeparati ezingaphandle kwe-odolo eziza kutshintshwa.
    const MAX_STEPS: usize = 5;
    // Ukuba isilayi sifutshane kunale, sukutshintsha naziphi na izinto.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // UKHUSELEKO: Sele sikwenze ngokucacileyo ukukhangela okubotshiweyo nge `i < len`.
        // Zonke izikhombisi zethu ezilandelayo zikuluhlu lwe `0 <= index < len` kuphela
        unsafe {
            // Fumana isibini esilandelayo sezinto ezingaphandle komyalelo.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Sigqibile?
        if i == len {
            return true;
        }

        // Musa ukutshintsha izinto kuluhlu olufutshane, ezinexabiso lokusebenza.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Ukutshintsha izinto ezifumanekayo.Oku kubabeka ngokulandelelana.
        v.swap(i - 1, i);

        // Shift into encinci iye ekhohlo.
        shift_tail(&mut v[..i], is_less);
        // Shift eyona nto inkulu ngasekunene.
        shift_head(&mut v[i..], is_less);
    }

    // Khange ndikwazi ukuhlela isilayidi kwinani eliqingqiweyo lamanyathelo.
    false
}

/// Ihlela isilayi usebenzisa uhlobo lokufakwa, eyi *O*(*n*^ 2) elona tyala libi.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ihlela i `v` isebenzisa i-heapsort, eqinisekisa *O*(*n*\log(*n*)) elibi kakhulu.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Le mfumba yokubini ihlonipha i `parent >= child` engenayo.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Abantwana be `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Khetha umntwana omkhulu.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Yeka ukuba umntu ongenayo ubambe i `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Guqula i `node` ngomntwana omkhulu, nyathela inyathelo elinye, kwaye uqhubeke nokuhluza.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Yakha imfumba ngexesha lomgama.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Izinto eziphezulu zePop ezivela kwimfumba.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Izahlulo `v` zibe zizinto ezincinci kune-`pivot`, zilandelwe zizinto ezingaphezulu okanye ezilinganayo kwi `pivot`.
///
///
/// Ibuyisa inani lezinto ezincinci kune `pivot`.
///
/// Ukwahlulahlula kwenziwa nge-block-by-block ukwenzela ukunciphisa indleko zokusebenza kwamasebe.
/// Olu luvo lubonakaliswe kwiphepha le [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Inani lezinto kwibloko yesiqhelo.
    const BLOCK: usize = 128;

    // Ukwahlulahlula i-algorithm kuphinda la manyathelo alandelayo kude kube kugqityiwe:
    //
    // 1. Landela ibhloko ukusuka kwicala lasekhohlo ukuze uchonge izinto ezinkulu okanye ezilinganayo kwi-pivot.
    // 2. Landela ibhloko ukusuka kwicala lasekunene lokuchonga izinto ezincinci kuneepivot.
    // 3. Shintsha izinto ezichongiweyo phakathi kwecala lasekhohlo nelasekunene.
    //
    // Sigcina ezi zinto zixabisekileyo kwibhloko yezinto:
    //
    // 1. `block` - Inani lezinto kwibhloko.
    // 2. `start` - Qalisa isikhombisi kuludwe lwe-`offsets`.
    // 3. `end` - Isiphelo sokugqibela kuluhlu lwe `offsets`.
    // 4. `iseti, ii-Indices zezinto ezingaphandle komyalelo ngaphakathi kwebhloko.

    // Ibhloko yangoku kwicala lasekhohlo (ukusuka kwi-`l` ukuya kwi-`l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Ibhloko yangoku kwicala lasekunene (ukusuka kwi `r.sub(block_r)` to `r`).
    // UKHUSELEKO: Amaxwebhu e .add() akhankanya ngokuthe ngqo ukuba i `vec.as_ptr().add(vec.len())` ihlala ikhuselekile`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Xa sifumana ii-VLAs, zama ukudala uluhlu olunye lobude `min(v.len(), 2 * BLOCK) `endaweni yoko
    // kunobungakanani obuhleliweyo bobungakanani be-`BLOCK`.Ii-VLAs zinokusebenza ngokukuko ngakumbi kwi-cache.

    // Ibuyisa inani lezinto phakathi kwezikhombisi `l` (inclusive) kunye ne `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Sigqibile ukwahlula ibhloko-nge-block xa i `l` kunye ne `r` zisondele kakhulu.
        // Emva koko senza umsebenzi wokudibanisa ukuze sahlule izinto eziseleyo phakathi.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Inani lezinto eziseleyo (azikathelekiswa nepivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Lungisa ubungakanani beebhloko ukwenzela ukuba ibhloko yasekhohlo nasekunene ingadluli, kodwa zilungelelaniswe ngokugqibeleleyo ukukhusela isithuba esishiyekileyo.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Landa izinto ze `block_l` ukusuka kwicala lasekhohlo.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // UKHUSELEKO: Imisebenzi engakhuselekanga engezantsi ibandakanya ukusetyenziswa kwe `offset`.
                //         Ngokwemeko efunwa ngumsebenzi, siyabanelisa kuba:
                //         1. `offsets_l` yabelwe isitaki, kwaye ke yathathelwa ingqalelo into eyahlukileyo yabelwe into.
                //         2. Umsebenzi `is_less` ubuyisela i `bool`.
                //            Ukuphosa i `bool` ngekhe kuphuphume kwi `isize`.
                //         3. Siqinisekisile ukuba iX01 iya kuba yi `<= BLOCK`.
                //            Kwaye i `end_l` ekuqaleni yayisetelwe kwisikhombisi sokuqala se `offsets_` esabhengezwa kwisitaki.
                //            Ke siyazi ukuba nakwimeko embi (zonke izicelo ze `is_less` zibuya zibubuxoki) siyakuba kuphela nge-1 byte sidlula esiphelweni.
                //        Omnye umsebenzi ongakhuselekanga apha kukususa uxwebhu `elem`.
                //        Nangona kunjalo, i `elem` ekuqaleni yayisikhombisi sokuqala kwisilayidi esisoloko sisebenza.
                unsafe {
                    // Uthelekiso olungenamasebe.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Landa izinto ze `block_r` ukusuka kwicala lasekunene.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // UKHUSELEKO: Imisebenzi engakhuselekanga engezantsi ibandakanya ukusetyenziswa kwe `offset`.
                //         Ngokwemeko efunwa ngumsebenzi, siyabanelisa kuba:
                //         1. `offsets_r` yabelwe isitaki, kwaye ke yathathelwa ingqalelo into eyahlukileyo yabelwe into.
                //         2. Umsebenzi `is_less` ubuyisela i `bool`.
                //            Ukuphosa i `bool` ngekhe kuphuphume kwi `isize`.
                //         3. Siqinisekisile ukuba iX01 iya kuba yi `<= BLOCK`.
                //            Kwaye i `end_r` ekuqaleni yayisetelwe kwisikhombisi sokuqala se `offsets_` esabhengezwa kwisitaki.
                //            Ke siyazi ukuba nakwimeko embi (zonke izicelo ze `is_less` zibuya ziyinyani) siyakuba kuphela nge-1 byte sidlula esiphelweni.
                //        Omnye umsebenzi ongakhuselekanga apha kukususa uxwebhu `elem`.
                //        Nangona kunjalo, i `elem` ekuqaleni yayiyi-`1 *sizeof(T)` idlulileyo kwaye siyinciphisa nge-`1* sizeof(T)` ngaphambi kokuyifumana.
                //        Kwaye i-`block_r` yaqinisekiswa ukuba ingaphantsi kwe-`BLOCK` kwaye i-`elem` iya kuthi ke ikhombe ekuqaleni kwesilayidi.
                unsafe {
                    // Uthelekiso olungenamasebe.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Inani lezinto ezingaphandle kwe-odolo zokutshintsha phakathi kwecala lasekhohlo nelasekunene.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Endaweni yokutshintsha isibini esinye ngexesha, kusebenza ngakumbi ukwenza imvume ejikelezayo.
            // Oku akulingani ngokungqongqo nokutshintsha, kodwa kuvelisa iziphumo ezifanayo zisebenzisa imisebenzi embalwa yenkumbulo.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Zonke izinto ezingaphandle kwe-odolo kwibloko yasekhohlo zihanjisiwe.Hambisa kwibhloko elandelayo.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Zonke izinto ezingaphandle kwe-odolo kwibhloko yasekunene zihanjisiwe.Hambisa kwibhloko yangaphambili.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Konke okuseleyo ngoku kuninzi ibhloko enye (nokuba ekhohlo okanye ekunene) ngezinto ezingaphandle komyalelo ezifuna ukususwa.
    // Izinto ezishiyekileyo zinokutshintshelwa ngokulula ziye esiphelweni ngaphakathi kwebhloko yazo.
    //

    if start_l < end_l {
        // Ibloko lasekhohlo lihleli.
        // Hambisa izinto ezishiyekileyo ze-odolo esekunene.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Ibhloko lasekunene lihlala.
        // Hambisa izinto ezishiyekileyo zangaphandle kwe-odolo ngasekhohlo.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Akukho enye into yokwenza, sigqibile.
        width(v.as_mut_ptr(), l)
    }
}

/// Izahlulo `v` zibe zizinto ezincinci kune-`v[pivot]`, zilandelwe zizinto ezingaphezulu okanye ezilinganayo kwi `v[pivot]`.
///
///
/// Ibuyisa iTuple ye:
///
/// 1. Inani lezinto ezincinci kune-`v[pivot]`.
/// 2. Kuyinyani ukuba i `v` yayisele yahluliwe.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Beka ipivot ekuqaleni kwesilayidi.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Funda i-pivot kulungelelwaniso olwabiwe kwisitaki ukuze usebenze ngokukuko.
        // Ukuba umsebenzi olandelayo wokuthelekisa i panics, ipivot iya kubhalwa ngokuzenzekelayo kwisilayidi.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Fumana isibini sokuqala sezinto ezingaphandle komyalelo.
        let mut l = 0;
        let mut r = v.len();

        // UKHUSELEKO: Ukungaqiniseki apha ngezantsi kubandakanya isalathiso soluhlu.
        // Eyokuqala: Sele siyenzile imida yokujonga apha nge `l < r`.
        // Eyesibini: Ekuqaleni sine-`l == 0` kunye ne-`r == v.len()` kwaye siqwalasele i-`l < r` kuyo yonke imisebenzi yokwenza isalathiso.
        //                     Ukusuka apha siyazi ukuba i `r` kufuneka okungenani ibe yi-`r == l` ebonakaliswe ukuba iyasebenza ukusuka kowokuqala.
        unsafe {
            // Fumana into yokuqala engaphezulu okanye elinganayo nepivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Fumana into yokugqibela encinci ukuba ipivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` iphuma esikalini kwaye ibhale i-pivot (eyahlula-hlulelwe kwisitaki) ibuyele kwisilayidi apho ibikhona ngaphambili.
        // Eli nyathelo libaluleke kakhulu ekuqinisekiseni ukhuseleko!
        //
    };

    // Beka i-pivot phakathi kwezi zahlulo zimbini.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Izahlulelo `v` zibe zizinto ezilingana ne `v[pivot]` zilandelwe zizinto ezinkulu kune `v[pivot]`.
///
/// Ibuyisa inani lezinto ezilingana nepivot.
/// Kucingelwa ukuba i `v` ayiqulathanga izinto ezincinci kuneepivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Beka ipivot ekuqaleni kwesilayidi.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Funda i-pivot kulungelelwaniso olwabiwe kwisitaki ukuze usebenze ngokukuko.
    // Ukuba umsebenzi olandelayo wokuthelekisa i panics, ipivot iya kubhalwa ngokuzenzekelayo kwisilayidi.
    // UKHUSELEKO: Isikhombisi apha siyasebenza kuba sifunyenwe kwisalathiso sesilayidi.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Ngoku hlula isilayi.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // UKHUSELEKO: Ukungaqiniseki apha ngezantsi kubandakanya isalathiso soluhlu.
        // Eyokuqala: Sele siyenzile imida yokujonga apha nge `l < r`.
        // Eyesibini: Ekuqaleni sine-`l == 0` kunye ne-`r == v.len()` kwaye siqwalasele i-`l < r` kuyo yonke imisebenzi yokwenza isalathiso.
        //                     Ukusuka apha siyazi ukuba i `r` kufuneka okungenani ibe yi-`r == l` ebonakaliswe ukuba iyasebenza ukusuka kowokuqala.
        unsafe {
            // Fumana into yokuqala enkulu kuneepivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Fumana into yokugqibela elingana nepivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Sigqibile?
            if l >= r {
                break;
            }

            // Ukutshintsha izinto ezi-odolwe ngaphandle.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Sifumene izinto ze `l` ezilingana nepivot.Yongeza i-1 kwiakhawunti yepivot uqobo.
    l + 1

    // `_pivot_guard` iphuma esikalini kwaye ibhale i-pivot (eyahlula-hlulelwe kwisitaki) ibuyele kwisilayidi apho ibikhona ngaphambili.
    // Eli nyathelo libaluleke kakhulu ekuqinisekiseni ukhuseleko!
}

/// Ukusasaza ezinye izinto ezijikeleze iinzame zokuphula iipateni ezinokubangela izahlulelo ezingalinganiyo kwi-quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Inkunkuma yenombolo yePseudorandom evela kwiphepha le "Xorshift RNGs" nguGeorge Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Thatha amanani akhethiweyo emodulo eli nani.
        // Inani lingena kwi `usize` kuba i `len` ayinkulu kune `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Abanye abaviwa be-pivot baya kuba kufutshane nesi salathisi.Makhe sizenze ngokulandelelana kwazo.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Yenza inombolo ye-modulo `len` engahleliwe.
            // Nangona kunjalo, ukuthintela ukusebenza kweendleko kuqala sithatha imodulo ngamandla amabini, emva koko sehle nge-`len` ide ilingane kuluhlu lwe `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` Iqinisekisiwe ukuba ingaphantsi kwe `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Khetha i-pivot kwi-`v` kwaye ubuyise isalathiso kunye ne-`true` ukuba isilayidi sele silungisiwe.
///
/// Izinto ezikwi `v` zinokuhlengahlengiswa kwakhona kwinkqubo.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ubuncinci ubude bokukhetha indlela ephakathi.
    // Izilayi ezimfutshane zisebenzisa indlela elula ephakathi kwemithathu.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Elona nani liphezulu lokutshintsha okunokwenziwa kulo msebenzi.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Iimpawu ezintathu ezikufuphi apho siza kukhetha khona ipivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Ibala inani lilonke lotshintsho esele siza kulwenza ngelixa sihlela ii-indices.
    let mut swaps = 0;

    if len >= 8 {
        // Ukutshintsha ii-indices ukuze i `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Ukutshintsha ii-indices ukuze i `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Fumana imedian ye `v[a - 1], v[a], v[a + 1]` kwaye igcine isalathiso kwi `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Fumana abalamli kwimimandla ye `a`, `b`, kunye ne `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Fumana iMedian phakathi kwe `a`, `b`, kunye ne `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Elona nani liphezulu lokutshintsha kwenzekile.
        // Amathuba isilayi siyehla okanye ubukhulu becala sehla, ke ukubuyela umva kuya kunceda ukukulungisa ngokukhawuleza.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Iintlobo ze `v` eziphindayo.
///
/// Ukuba isilayi besinomanduleli kuluhlu lwantlandlolo, ichazwa njenge `pred`.
///
/// `limit` linani lezizahlulelo ezingalinganiyo ezivunyelweyo ngaphambi kokutshintshela kwi `heapsort`.
/// Ukuba ngu-zero, lo msebenzi uza kutshintshela ngokukhawuleza kwi-heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Iziqwenga ukuya kuthi ga kobu bude ziyacwangciswa kusetyenziswa uhlobo lokufaka.
    const MAX_INSERTION: usize = 20;

    // Kuyinyani ukuba ulwahlulelo lokugqibela lwalulinganisiwe ngokufanelekileyo.
    let mut was_balanced = true;
    // Kuyinyani ukuba ulwahlulelo lokugqibela aluzange lutshintshe izinto (isilayi besele sihlule).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Izilayi ezimfutshane kakhulu ziyahlelwa kusetyenziswa uhlobo lokufakwa.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ukuba uninzi lweepivot olubi lwenziwe, vele ubuyele kwi-heapsort ukuze uqiniseke nge `O(n * log(n))` yecala elibi.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ukuba ukwahlulahlulahlula kokugqibela bekungalingani, zama ukwaphula iipateni kwisilayidi ngokushukuma ezinye izinto zijikeleze.
        // Ndiyathemba ukuba siza kukhetha ipivot engcono ngeli xesha.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Khetha i-pivot kwaye uzame ukuthelekelela ukuba isilayi sele silungisiwe.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ukuba ulwahlulelo lokugqibela lwalulinganisiwe kwaye aluzange lutshintshe izinto, kwaye ukuba ukhetho lwepivot luqikelela ukuba isilayidi sele silungisiwe ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Zama ukuchonga izinto ezingaphandle komyalelo kunye nokuzitshintshela kwizikhundla ezifanelekileyo.
            // Ukuba isilayi siphela sihlelwe ngokupheleleyo, sigqibile.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ukuba ipivot ekhethiweyo ilingana neyandulelayo, yeyona nto incinci kwisilayidi.
        // Ukwahlula isilayi kwizinto ezilinganayo kunye nezinto ezinkulu kuneepivot.
        // Eli tyala lihlala libethwa xa isilayidi sinezinto ezininzi eziphindiweyo.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Qhubeka uhlela izinto ezinkulu kuneepivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Ukwahlula isilayi.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Yahlula isilayi kwi `left`, `pivot`, kunye ne `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Phinda ubuye kwicala elifutshane kuphela ukuze unciphise inani elipheleleyo leefowuni eziphindaphindayo kwaye usebenzise indawo encinci yokubeka.
        // Emva koko qhubeka kunye necala elide (oku kuyafana nokuphinda umsila).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ihlela i `v` isebenzisa ipateni-yoyisa i-quicksort, eyi-*O*(*n*\*log(* n*)) yeyona meko imbi.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ukuhlela akukho ndlela yokuziphatha inentsingiselo kuhlobo lwe-zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Nciphisa inani lezahlulo ezingalinganiyo ukuya kwi `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Kwizilayi ezifikelela kobu bude kunokwenzeka ukuba zikhawuleze ukuzihlela.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Khetha ipivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Ukuba ipivot ekhethiweyo ilingana neyandulelayo, yeyona nto incinci kwisilayidi.
        // Ukwahlula isilayi kwizinto ezilinganayo kunye nezinto ezinkulu kuneepivot.
        // Eli tyala lihlala libethwa xa isilayidi sinezinto ezininzi eziphindiweyo.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ukuba sidlulile kwisalathiso sethu, ke silungile.
                if mid > index {
                    return;
                }

                // Ngaphandle koko, qhubeka uhlela izinto ezinkulu kuneepivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Yahlula isilayi kwi `left`, `pivot`, kunye ne `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ukuba phakathi==isalathiso, emva koko sigqibile, kuba i partition() iqinisekisile ukuba zonke izinto emva komhla zinkulu okanye zilingana naphakathi.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Ukuhlela akukho ndlela yokuziphatha inentsingiselo kuhlobo lwe-zero.Sukwenzanto.
    } else if index == v.len() - 1 {
        // Fumana into enkulu kwaye uyibeke kwindawo yokugqibela kuluhlu.
        // Sikhululekile ukusebenzisa i-`unwrap()` apha kuba siyazi ukuba i-v mayingabinanto.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Fumana imin element kwaye uyibeke kwindawo yokuqala yoluhlu.
        // Sikhululekile ukusebenzisa i-`unwrap()` apha kuba siyazi ukuba i-v mayingabinanto.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}