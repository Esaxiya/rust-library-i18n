// Ukuphunyezwa koqobo kuthathwe kwi-rust-memchr.
// Ilungelo lokushicilela ngo-2015 Andrew Gallant, bluss noNicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Sebenzisa unciphiso.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Ibuyisa i `true` ukuba i `x` iqulethe nayiphi na i-byte.
///
/// Ukusuka kwi-* Imicimbi yeComputerational, uJ. Arndt:
///
/// "Umbono kukususa inye kwii-byte nganye emva koko ujonge ii-byte apho imali ebolekiweyo isasazeke ngayo yonke indlela iye kweyona ibalulekileyo
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Ibuyisa isalathiso sokuqala esidibanisa i-byte `x` kwi `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Indlela ekhawulezayo yezilayi ezincinci
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Skena ixabiso elilodwa ngokufunda amagama amabini e `usize` ngexesha.
    //
    // Yahlula i `text` kwiindawo ezintathu
    // - indawo yokuqala engacwangciswanga, phambi kwedilesi yokuqala ehambelana nedilesi kwisicatshulwa
    // - umzimba, skena ngamagama ama-2 ngexesha
    // - icandelo lokugqibela eliseleyo, <2 ubungakanani begama

    // khangela kumda olungelelanisiweyo
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // Khangela umzimba wetekisi
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // UKHUSELEKO: isimiselo sexesha liqinisekisa umgama ubuncinci 2 * usize_bytes
        // phakathi kokuseta kunye nokuphela kwesilayidi.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // phula ukuba kukho i-byte efanayo
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Fumana i-byte emva kwenqaku lokuma komzimba.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Ibuyisa isalathiso sokugqibela esidibanisa i-byte `x` kwi `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Skena ixabiso elilodwa ngokufunda amagama amabini e `usize` ngexesha.
    //
    // Yahlula i `text` kwiindawo ezintathu:
    // - umsila ongalungelelaniswanga, emva kwedilesi yokugqibela ehambelana nedilesi,
    // - umzimba, uskenwe ngamagama ama-2 ngexesha,
    // - ii-byte zokuqala ezisele, <2 ubungakanani begama.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Oku sikubiza nje ukufumana ubude besimaphambili kunye nesimamva.
        // Embindini sihlala siqhubekeka ii-chunks ezimbini ngaxeshanye.
        // UKHUSELEKO: ukuhambisa i-`[u8]` ukuya kwi-`[usize]` kukhuselekile ngaphandle komehluko wobungakanani ophathwa yi-`align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Khangela umzimba wesicatshulwa, qiniseka ukuba asiweleli min_aligned_offset.
    // i-offset ihlala ihambelana, ke ukuvavanya nje i `>` kwanele kwaye kuthintela ukuphuphuma okunokwenzeka.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // UKHUSELEKO: iseti eqala ngelensi, suffix.len(), ukuba nje inkulu kune
        // min_aligned_offset (prefix.len()) umgama oshiyekileyo ubuncinci yi-2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Yaphula ukuba kukho i-byte efanayo.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Fumana i-byte ngaphambi kokuba inqaku lomzimba liyeke.
    text[..offset].iter().rposition(|elt| *elt == x)
}