// ignore-tidy-filelength

//! Ulawulo lwesilayidi kunye nokukhohlisa.
//!
//! Ngolwazi oluthe kratya jonga i [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Ukuphunyezwa kwememchr okuchanekileyo kwe rust, kuthathwe kwi rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Lo msebenzi ungowasesidlangalaleni kuphela kuba ayikho enye indlela eya kuvavanyo lweyunithi.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Ibuyisa inani lezinto kwisilayidi.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // UKHUSELEKO: isandi se-const kuba sikhupha umhlaba ubude njenge-usize (ekufuneka ibenjalo)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // UKHUSELEKO: oku kukhuselekile kuba i `&[T]` kunye ne `FatPtr<T>` zinobeko olufanayo.
            // Yi-`std` kuphela enokwenza esi siqinisekiso.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Faka endaweni ye `crate::ptr::metadata(self)` xa oko kuzinzile.
            // Ngokubhala oku kubangela impazamo ye "Const-stable functions can only call other const-stable functions".
            //

            // UKHUSELEKO: Ukufikelela kwixabiso kumanyano we `PtrRepr` kukhuselekile ukusukela * const T
            // kunye nePtrComponents<T>ubeko lwenkumbulo olufanayo.
            // std kuphela enokwenza esi siqinisekiso.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Ibuyisa i `true` ukuba isilayidi sinobude be-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ibuyisa into yokuqala yesilayidi, okanye i `None` ukuba ayinanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Ibuyisa isikhombisi esinokuguquguquka kwinto yokuqala yesilayidi, okanye i `None` ukuba ayinanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Ibuyisa eyokuqala kunye nazo zonke ezinye izinto zesilayidi, okanye i `None` ukuba ayinanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ibuyisa eyokuqala kunye nazo zonke ezinye izinto zesilayidi, okanye i `None` ukuba ayinanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ibuyisa eyokugqibela kunye nazo zonke ezinye izinto zesilayidi, okanye i `None` ukuba ayinanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ibuyisa eyokugqibela kunye nazo zonke ezinye izinto zesilayidi, okanye i `None` ukuba ayinanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ibuyisa into yokugqibela yesilayidi, okanye i `None` ukuba ayinanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Ibuyisa isikhombisi esinokutshintshwa kwinto yokugqibela kwisilayidi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Ibuyisa ireferensi yento okanye i-subslice ngokuxhomekeke kuhlobo lwesalathiso.
    ///
    /// - Ukuba unikwe isikhundla, ubuyisela ireferensi kwinto leyo ikwi-`None` ukuba ngaphandle kwemida.
    ///
    /// - Ukuba unikwe uluhlu, ubuyisela i-subslice ehambelana nolo luhlu, okanye i-`None` ukuba ingaphandle kwemida.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Ibuyisa ireferensi enokuguquguquka kwinto ethile okanye kwintlawulo exhomekeke kuhlobo lwesalathiso (jonga i-[`get`]) okanye i-`None` ukuba isalathiso asikho kwimida.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Ibuyisa ireferensi yento okanye i-subslice, ngaphandle kokujonga imida.
    ///
    /// Olunye uhlobo olukhuselekileyo jonga i [`get`].
    ///
    /// # Safety
    ///
    /// Ukubiza le ndlela ngesalathiso esingaphandle kwemida yi *[undefined behaviour]* Nokuba isalathiso esisiphumo asisetyenziswanga.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase uninzi lweemfuno zokhuseleko ze `get_unchecked`;
        // Isilayidi asinakuphinda senziwe kuba i `self` sisalathiso esikhuselekileyo.
        // Isikhombisi esibuyisiweyo sikhuselekile kuba ii-impls ze `SliceIndex` kufuneka ziqinisekise ukuba kunjalo.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Ibuyisa ireferensi enokuguquguquka kwinto ethile okanye kwinkqutyana, ngaphandle kokujonga imida.
    ///
    /// Ngenye indlela ekhuselekileyo jonga i [`get_mut`].
    ///
    /// # Safety
    ///
    /// Ukubiza le ndlela ngesalathiso esingaphandle kwemida yi *[undefined behaviour]* Nokuba isalathiso esisiphumo asisetyenziswanga.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase iimfuno zokhuseleko ze `get_unchecked_mut`;
        // Isilayidi asinakuphinda senziwe kuba i `self` sisalathiso esikhuselekileyo.
        // Isikhombisi esibuyisiweyo sikhuselekile kuba ii-impls ze `SliceIndex` kufuneka ziqinisekise ukuba kunjalo.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Ibuyisa isikhombisi esiluhlaza kwisikhuseli sesilayi.
    ///
    /// Umntu ofowunayo kufuneka aqinisekise ukuba isilayidi sidlula ngesikhombisi kulo msebenzi ubuyayo, kungenjalo siya kugqibela ngokukhomba inkunkuma.
    ///
    /// Umntu ofowunayo kufuneka aqinisekise ukuba inqaku lesalathiso i-(non-transitively) yalatha kuyo ayibhalelwanga (ngaphandle ngaphakathi kwe-`UnsafeCell`) usebenzisa esi sikhombisi okanye nasiphi na isikhombisi esivela kuso.
    /// Ukuba ufuna ukutshintsha imixholo yesilayidi, sebenzisa i [`as_mut_ptr`].
    ///
    /// Ukuguqula isikhongozeli ekubhekiswe kuso kwesi silayi kunokubangela ukuba isikhuseli saso siphinde sabekwa kwakhona, esinokuthi senze naziphi na izikhombisi kuso ukuba singasebenzi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Ibuyisa isikhombisi esingakhuselekanga esinokutshintsha kwisikhuseli sesilayidi.
    ///
    /// Umntu ofowunayo kufuneka aqinisekise ukuba isilayidi sidlula ngesikhombisi kulo msebenzi ubuyayo, kungenjalo siya kugqibela ngokukhomba inkunkuma.
    ///
    /// Ukuguqula isikhongozeli ekubhekiswe kuso kwesi silayi kunokubangela ukuba isikhuseli saso siphinde sabekwa kwakhona, esinokuthi senze naziphi na izikhombisi kuso ukuba singasebenzi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Ibuyisa izikhombisi ezibini eziluhlaza ezihamba kwisilayidi.
    ///
    /// Uluhlu olubuyisiweyo luvulekile, oko kuthetha ukuba isalathiso sokugqibela sikhomba *enye edlulileyo* into yokugqibela yesilayidi.
    /// Ngale ndlela, isilayidi esingenanto simele izalathiso ezibini ezilinganayo, kwaye umahluko phakathi kwezikhombisi ezibini umele ubungakanani besilayidi.
    ///
    /// Jonga i [`as_ptr`] ngezilumkiso ekusebenziseni ezi zikhombisi.Isiphelo sesiphelo sifuna ulumkiso olongezelelekileyo, kuba asikhombisi kwinto esebenzayo kwisilayidi.
    ///
    /// Lo msebenzi uluncedo ekunxibelelaneni nonxibelelwano lwangaphandle olusebenzisa izikhombisi ezibini ukubhekisa kuluhlu lwezinto kwimemori, njengoko kuqhelekileyo kwi-C++ .
    ///
    ///
    /// Inokuba luncedo ukukhangela ukuba isikhombisi kwinto ethile sibhekisa kwinto yesi silayi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // UKHUSELEKO: I `add` apha ikhuselekile, kuba:
        //
        //   - Zombini izikhombisi ziyinxalenye yento enye, njengokukhomba ngqo ngaphaya kwento nayo ikwabalulekile.
        //
        //   - Ubungakanani besilayidi abusoze bube bukhulu kunee-isize::MAX byte, njengoko kuphawuliwe apha:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Akukho kusongelwa macala onke kubandakanyekayo, njengoko izilayi zingasongeli ngaphaya kwesiphelo sedilesi.
        //
        // Jonga amaxwebhu e pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ibuyisa izikhombisi ezimbini ezingakhuselekanga ezinokuguquguquka ezisebenzisa isilayidi.
    ///
    /// Uluhlu olubuyisiweyo luvulekile, oko kuthetha ukuba isalathiso sokugqibela sikhomba *enye edlulileyo* into yokugqibela yesilayidi.
    /// Ngale ndlela, isilayidi esingenanto simele izalathiso ezibini ezilinganayo, kwaye umahluko phakathi kwezikhombisi ezibini umele ubungakanani besilayidi.
    ///
    /// Jonga i [`as_mut_ptr`] ngezilumkiso ekusebenziseni ezi zikhombisi.
    /// Isiphelo sesiphelo sifuna ulumkiso olongezelelekileyo, kuba asikhombisi kwinto esebenzayo kwisilayidi.
    ///
    /// Lo msebenzi uluncedo ekunxibelelaneni nonxibelelwano lwangaphandle olusebenzisa izikhombisi ezibini ukubhekisa kuluhlu lwezinto kwimemori, njengoko kuqhelekileyo kwi-C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // UKHUSELEKO: Jonga i as_ptr_range() apha ngasentla ukuba kutheni i `add` ilapha ikhuselekile.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Utshintsha izinto ezimbini kwisilayidi.
    ///
    /// # Arguments
    ///
    /// * a, Isalathiso sezinto zokuqala
    /// * b, Isalathiso sento yesibini
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `a` okanye i `b` ingaphandle kwemida.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Awunakho ukuthatha iimali mboleko ezimbini ezinokutshintsha ukusuka kwi-vector enye, endaweni yoko sebenzisa izikhombisi eziluhlaza.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // UKHUSELEKO: I `pa` kunye ne `pb` zenziwe ukusuka kwizalathiso ezikhuselekileyo ezinokuhanjiswa kwaye zibhekise kuzo
        // kwizinto ezikwisilayidi kwaye ke ngoko ziqinisekisiwe ukuba zisemthethweni kwaye zilungelelaniswe.
        // Qaphela ukuba ukufikelela kwizinto ezisemva kwe `a` kunye ne `b` kujongiwe kwaye kuya kuba yi panic xa ungaphandle kwemida.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Ukuguqula ukulandelelana kwezinto kwisilayidi, endaweni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Kwiindidi ezincinci kakhulu, wonke umntu ofundwayo kwindlela eqhelekileyo wenza kakubi.
        // Sinokwenza ngcono, xa sinikwe i load/store efanelekileyo engafakwanga, ngokulayisha i-chunk enkulu kunye nokuguqula irejista.
        //

        // Ngokufanelekileyo i-LLVM iyakwenza oku kuthi, njengoko isazi ngcono kunokuba sisazi ukuba ukungafundiswanga okungafakwanga kakuhle kuyasebenza (kuba olo tshintsho phakathi kweenguqu ezahlukeneyo ze-ARM, umzekelo) kunye nobungakanani be-chunk size.
        // Ngelishwa, ukusukela nge-LLVM 4.0 (2017-05) ikhupha kuphela iluphu, ke kufuneka sikwenze oku ngokwethu.
        // (I-Hypothesis: ukubuyela umva kuyasokolisa kuba amacala anokulungelelaniswa ngokwahlukileyo-iya kuba, xa ubude bungaqhelekanga-ke akukho ndlela yakukhupha ngaphambili kunye nasemva kokusebenzisa i-SIMD elungelelaniswe ngokupheleleyo embindini.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Sebenzisa i-llvm.bswap yangaphakathi ukubuyisela umva u8s kusetyenziso
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // UKHUSELEKO: Kukho izinto ezininzi zokujonga apha:
                //
                // - Qaphela ukuba i `chunk` inokuba ngu-4 okanye u-8 ngenxa yokujongwa kwe-cfg apha ngasentla.Ke i-`chunk - 1` ilungile.
                // - Ukwenza isalathiso ngesalathiso `i` kulungile njengoko itsheki yeluphu iqinisekisa
                //   `i + chunk - 1 < ln / 2`
                //   `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Ukwenza isalathiso ngesalathiso `ln - i - chunk = ln - (i + chunk)` kulungile:
                //   - `i + chunk > 0` yinyaniso encinci.
                //   - Ukutshekishwa kwelogu kuqinisekisa:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, kungoko ukuthabatha kungahambi.
                // - Iifowuni ze `read_unaligned` kunye ne `write_unaligned` zilungile:
                //   - `pa` yalatha kwisalathiso `i` apho i-`i < ln / 2 - (chunk - 1)` (jonga ngasentla) kunye ne-`pb` yamanqaku kwisalathiso `ln - i - chunk`, ke bobabini ubuncinci ubuncinci yi-`chunk` ii-byte ezininzi kude nasekupheleni kwe `self`.
                //
                //   - Nayiphi na imemori eqalisiweyo i-`usize` esebenzayo.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Sebenzisa ujikeleze-nge-16 ukubuyisela umva u16s kwi u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // UKHUSELEKO: I-u32 engacwangciswanga inokufundwa kwi-`i` ukuba i-`i + 1 < ln`
                // (kwaye ngokucacileyo i-`i < ln`), kuba into nganye zii-byte ezi-2 kwaye sifunda ezi-4.
                //
                // `i + chunk - 1 < ln / 2` # ngelixa imeko
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Kuba ingaphantsi kobude obuhlulwe ngo-2, ke kuya kufuneka ibe yimida.
                //
                // Oku kuthetha ukuba imeko i `0 < i + chunk <= ln` ihlala ihlonitshwa, iqinisekisa ukuba isikhombisi se `pb` singasetyenziswa ngokukhuselekileyo.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // UKHUSELEKO: `i` ingaphantsi kwesiqingatha sobude besilayi ke
            // ukufikelela kwi-`i` kunye ne-`ln - i - 1` kukhuselekile (i-`i` iqala ngo-0 kwaye ayizukuhamba ngaphezulu kwe-`ln / 2 - 1`).
            // Izikhombisi ezibangelwayo `pa` kunye ne `pb` ke ziyasebenza kwaye zilungelelaniswe, kwaye zinokufundwa zisuka kwaye zibhalelwe.
            //
            //
            unsafe {
                // Ukutshintsha okungakhuselekanga ukunqanda imida yokujonga kutshintsho olukhuselekileyo.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Ibuyisa iterator ngaphezulu kwesilayidi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Ibuyisa iterator evumela ukuguqula ixabiso ngalinye.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Ibuyisa i-iterator ngaphezulu kwayo yonke i-windows yobude be-`size`.
    /// Ukudibana kwe windows.
    /// Ukuba isilayi sifutshane kune `size`, iterator ayibuyisi amaxabiso.
    ///
    /// # Panics
    ///
    /// Panics ukuba i `size` ngu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ukuba isilayi sifutshane kune `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngaxeshanye, ukuqala ekuqaleni kwesilayidi.
    ///
    /// Ii-chunks zizilayi kwaye azihambelani.Ukuba i-`chunk_size` ayibuhluli ubude besilayidi, emva koko i-chunk yokugqibela ayiyi kuba ne-`chunk_size` ubude.
    ///
    /// Jonga i [`chunks_exact`] yokwahluka kwale iterator ibuyisa iziqwengana ezihlala zihleli ngokuchanekileyo ze-`chunk_size`, kunye ne-[`rchunks`] ye-iterator efanayo kodwa ukuqala kwisilayidi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `chunk_size` ngu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngaxeshanye, ukuqala ekuqaleni kwesilayidi.
    ///
    /// Ii-chunks zizilayi eziguqukayo, kwaye musa ukugqagqana.Ukuba i-`chunk_size` ayibuhluli ubude besilayidi, emva koko i-chunk yokugqibela ayiyi kuba ne-`chunk_size` ubude.
    ///
    /// Jonga i [`chunks_exact_mut`] yokwahluka kwale iterator ibuyisa iziqwengana ezihlala zihleli ngokuchanekileyo ze-`chunk_size`, kunye ne-[`rchunks_mut`] ye-iterator efanayo kodwa ukuqala kwisilayidi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `chunk_size` ngu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngaxeshanye, ukuqala ekuqaleni kwesilayidi.
    ///
    /// Ii-chunks zizilayi kwaye azihambelani.
    /// Ukuba i `chunk_size` ayibuhluli ubude besilayidi, emva koko izinto eziya kuthi xhaxhe kwi `chunk_size-1` ziya kushiywa kwaye zinokufunyanwa kwakhona kwi-`remainder` function ye-iterator.
    ///
    ///
    /// Ngenxa yechunk nganye enezinto ze-`chunk_size` ngokuchanekileyo, umhlanganisi unokuhlala elungisa ikhowudi ephume bhetele kunakwimeko ye [`chunks`].
    ///
    /// Jonga i [`chunks`] yokwahluka kwale iterator ikwabuyisela intsalela njengechunk encinci, kunye ne [`rchunks_exact`] kwiterator efanayo kodwa ukuqala esiphelweni sesilayidi.
    ///
    /// # Panics
    ///
    /// Panics ukuba i `chunk_size` ngu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngaxeshanye, ukuqala ekuqaleni kwesilayidi.
    ///
    /// Ii-chunks zizilayi eziguqukayo, kwaye musa ukugqagqana.
    /// Ukuba i `chunk_size` ayibuhluli ubude besilayidi, emva koko izinto eziya kuthi xhaxhe kwi `chunk_size-1` ziya kushiywa kwaye zinokufunyanwa kwakhona kwi-`into_remainder` function ye-iterator.
    ///
    ///
    /// Ngenxa yechunk nganye enezinto ze-`chunk_size` ngokuchanekileyo, umhlanganisi unokuhlala elungisa ikhowudi ephume bhetele kunakwimeko ye [`chunks_mut`].
    ///
    /// Jonga i [`chunks_mut`] yokwahluka kwale iterator ikwabuyisela intsalela njengechunk encinci, kunye ne [`rchunks_exact_mut`] kwiterator efanayo kodwa ukuqala esiphelweni sesilayidi.
    ///
    /// # Panics
    ///
    /// Panics ukuba i `chunk_size` ngu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Ukwahlula isilayi kwisilayidi se-N`-element arrays, ucinga ukuba akukho ntsalela.
    ///
    ///
    /// # Safety
    ///
    /// Oku kunokubizwa kuphela xa
    /// - Isilayidi sahlula-hlula ngqo kwi-N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // UKHUSELEKO: Izinto ezi-1 ze-chunks azikaze zisele
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // UKHUSELEKO: Ubude besilayidi i (6) iphindaphindwe ngo-3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Oku akunakulunga:
    /// // vumela iziqendu: &[[_ _;5]]= slice.as_chunks_unchecked()//Ubude besilayidi abuphindi kwi-5 let chunks:&[[_ _;0]]= slice.as_chunks_unchecked()//Chunks-chunks ubude azivunyelwanga
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // UKHUSELEKO: Imimiselo yethu kanye yile nto ifunekayo ukubiza oku
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // UKHUSELEKO: Siphosa isilayidi sezinto ze `new_len * N` kwi
        // isilayi se `new_len` ezininzi izinto ze `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Ukwahlula isilayi kwisilayidi se-N`-element arrays, ukuqala ekuqaleni kwesilayidi, kunye nentsalela yesilayidi enobude obungaphantsi kwe `N`.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `N` ingu-0. Olu luqwalaselo luya kuthi ngokuqinisekileyo lutshintshelwe kwimpazamo yexesha lokudibanisa ngaphambi kokuba le ndlela izinziswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // UKHUSELEKO: Sele sitatazelwe zero, kwaye siqinisekisiwe ngokwakhiwa
        // ukuba ubude benkxaso-mali iphindaphindwe ngo-N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Ukwahlula isilayi kwisilayidi se-N`-element arrays, ukuqala esiphelweni sesilayidi, kunye nentsalela yesilayidi enobude obungaphantsi kwe `N`.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `N` ingu-0. Olu luqwalaselo luya kuthi ngokuqinisekileyo lutshintshelwe kwimpazamo yexesha lokudibanisa ngaphambi kokuba le ndlela izinziswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // UKHUSELEKO: Sele sitatazelwe zero, kwaye siqinisekisiwe ngokwakhiwa
        // ukuba ubude benkxaso-mali iphindaphindwe ngo-N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`N` zesilayidi ngaxeshanye, ukuqala ekuqaleni kwesilayidi.
    ///
    /// Ii-chunks zizalathiso eziludweliso kwaye azihambelani.
    /// Ukuba i `N` ayibuhluli ubude besilayidi, emva koko izinto eziya kuthi xhaxhe kwi `N-1` ziya kushiywa kwaye zinokufunyanwa kwakhona kwi-`remainder` function ye-iterator.
    ///
    ///
    /// Le ndlela yinto yesiqhelo elingana no [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `N` ingu-0. Olu luqwalaselo luya kuthi ngokuqinisekileyo lutshintshelwe kwimpazamo yexesha lokudibanisa ngaphambi kokuba le ndlela izinziswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Ukwahlula isilayi kwisilayidi se-N`-element arrays, ucinga ukuba akukho ntsalela.
    ///
    ///
    /// # Safety
    ///
    /// Oku kunokubizwa kuphela xa
    /// - Isilayidi sahlula-hlula ngqo kwi-N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // UKHUSELEKO: Izinto ezi-1 ze-chunks azikaze zisele
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // UKHUSELEKO: Ubude besilayidi i (6) iphindaphindwe ngo-3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Oku akunakulunga:
    /// // vumela iziqendu: &[[_ _;5]]= slice.as_chunks_unchecked_mut()//Ubude besilayidi abuphindi kwi-5 let chunks:&[[_ _;0]]= slice.as_chunks_unchecked_mut()//Chunks-chunks ubude azivunyelwanga
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // UKHUSELEKO: Imimiselo yethu kanye yile nto ifunekayo ukubiza oku
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // UKHUSELEKO: Siphosa isilayidi sezinto ze `new_len * N` kwi
        // isilayi se `new_len` ezininzi izinto ze `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Ukwahlula isilayi kwisilayidi se-N`-element arrays, ukuqala ekuqaleni kwesilayidi, kunye nentsalela yesilayidi enobude obungaphantsi kwe `N`.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `N` ingu-0. Olu luqwalaselo luya kuthi ngokuqinisekileyo lutshintshelwe kwimpazamo yexesha lokudibanisa ngaphambi kokuba le ndlela izinziswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // UKHUSELEKO: Sele sitatazelwe zero, kwaye siqinisekisiwe ngokwakhiwa
        // ukuba ubude benkxaso-mali iphindaphindwe ngo-N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Ukwahlula isilayi kwisilayidi se-N`-element arrays, ukuqala esiphelweni sesilayidi, kunye nentsalela yesilayidi enobude obungaphantsi kwe `N`.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `N` ingu-0. Olu luqwalaselo luya kuthi ngokuqinisekileyo lutshintshelwe kwimpazamo yexesha lokudibanisa ngaphambi kokuba le ndlela izinziswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // UKHUSELEKO: Sele sitatazelwe zero, kwaye siqinisekisiwe ngokwakhiwa
        // ukuba ubude benkxaso-mali iphindaphindwe ngo-N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`N` zesilayidi ngaxeshanye, ukuqala ekuqaleni kwesilayidi.
    ///
    /// Ii-chunks zizinto ezinokuguquguquka ekubhekiswa kuzo kwaye azihambelani.
    /// Ukuba i `N` ayibuhluli ubude besilayidi, emva koko izinto eziya kuthi xhaxhe kwi `N-1` ziya kushiywa kwaye zinokufunyanwa kwakhona kwi-`into_remainder` function ye-iterator.
    ///
    ///
    /// Le ndlela yinto yesiqhelo elingana no [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i `N` ingu-0. Olu luqwalaselo luya kuthi ngokuqinisekileyo lutshintshelwe kwimpazamo yexesha lokudibanisa ngaphambi kokuba le ndlela izinziswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Ibuyisa i-iterator ngaphezulu kwe-windows engaphezulu kwe-`N` yezinto zesilayidi, ukuqala ekuqaleni kwesilayidi.
    ///
    ///
    /// Le yile const generic ilingana ne [`windows`].
    ///
    /// Ukuba i `N` ingaphezulu kobungakanani besilayidi, ayiyi kubuya nge windows.
    ///
    /// # Panics
    ///
    /// Panics ukuba i `N` ngu-0.
    /// Olu luqwalaselo luya kuthi ngokuqinisekileyo lutshintshelwe kwimpazamo yexesha elidityanisiweyo ngaphambi kokuba le ndlela izinziswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngaxeshanye, ukuqala esiphelweni sesilayidi.
    ///
    /// Ii-chunks zizilayi kwaye azihambelani.Ukuba i-`chunk_size` ayibuhluli ubude besilayidi, emva koko i-chunk yokugqibela ayiyi kuba ne-`chunk_size` ubude.
    ///
    /// Jonga i [`rchunks_exact`] yokwahluka kwale iterator ibuyisa iziqwengana ezihlala zihleli ngokuchanekileyo ze-`chunk_size`, kunye ne-[`chunks`] ye-iterator efanayo kodwa ukuqala ekuqaleni kwesilayidi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `chunk_size` ngu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngaxeshanye, ukuqala esiphelweni sesilayidi.
    ///
    /// Ii-chunks zizilayi eziguqukayo, kwaye musa ukugqagqana.Ukuba i-`chunk_size` ayibuhluli ubude besilayidi, emva koko i-chunk yokugqibela ayiyi kuba ne-`chunk_size` ubude.
    ///
    /// Jonga i [`rchunks_exact_mut`] yokwahluka kwale iterator ibuyisa iziqwengana ezihlala zihleli ngokuchanekileyo ze-`chunk_size`, kunye ne-[`chunks_mut`] ye-iterator efanayo kodwa ukuqala ekuqaleni kwesilayidi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `chunk_size` ngu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngaxeshanye, ukuqala esiphelweni sesilayidi.
    ///
    /// Ii-chunks zizilayi kwaye azihambelani.
    /// Ukuba i `chunk_size` ayibuhluli ubude besilayidi, emva koko izinto eziya kuthi xhaxhe kwi `chunk_size-1` ziya kushiywa kwaye zinokufunyanwa kwakhona kwi-`remainder` function ye-iterator.
    ///
    /// Ngenxa yechunk nganye enezinto ze-`chunk_size` ngokuchanekileyo, umhlanganisi unokuhlala elungisa ikhowudi ephume bhetele kunakwimeko ye [`chunks`].
    ///
    /// Jonga i [`rchunks`] yokwahluka kwale iterator ikwabuyisela intsalela njengechunk encinci, kunye ne [`chunks_exact`] kwiterator efanayo kodwa ukuqala ekuqaleni kwesilayidi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `chunk_size` ngu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngaxeshanye, ukuqala esiphelweni sesilayidi.
    ///
    /// Ii-chunks zizilayi eziguqukayo, kwaye musa ukugqagqana.
    /// Ukuba i `chunk_size` ayibuhluli ubude besilayidi, emva koko izinto eziya kuthi xhaxhe kwi `chunk_size-1` ziya kushiywa kwaye zinokufunyanwa kwakhona kwi-`into_remainder` function ye-iterator.
    ///
    /// Ngenxa yechunk nganye enezinto ze-`chunk_size` ngokuchanekileyo, umhlanganisi unokuhlala elungisa ikhowudi ephume bhetele kunakwimeko ye [`chunks_mut`].
    ///
    /// Jonga i [`rchunks_mut`] yokwahluka kwale iterator ikwabuyisela intsalela njengechunk encinci, kunye ne [`chunks_exact_mut`] kwiterator efanayo kodwa ukuqala ekuqaleni kwesilayidi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `chunk_size` ngu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwesilayidi evelisa ukungagqagqana kwezinto ezibalekayo usebenzisa isilandiso ukwahlulahlula.
    ///
    /// Isivisa sibizwa ngezinto ezimbini ezilandela zona, oko kuthetha ukuba isivisa sibizwa ngo-`slice[0]` no-`slice[1]` emva koko ku-`slice[1]` kunye no-`slice[2]` njalo njalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Le ndlela inokusetyenziselwa ukukhupha iifomathi ezihleliweyo:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kwesilayidi evelisa okungagqagqananga kokubaleka kwezinto usebenzisa isilandiso ukwahlulahlula.
    ///
    /// Isivisa sibizwa ngezinto ezimbini ezilandela zona, oko kuthetha ukuba isivisa sibizwa ngo-`slice[0]` no-`slice[1]` emva koko ku-`slice[1]` kunye no-`slice[2]` njalo njalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Le ndlela inokusetyenziselwa ukukhupha iifomathi ezihleliweyo:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Yahlulahlula isilayi esinye kubini kwisalathiso.
    ///
    /// Eyokuqala iya kuba nazo zonke ii-indices ezivela kwi-`[0, mid)` (ngaphandle kwesalathiso se-`mid` uqobo) kwaye eyesibini iya kuba nazo zonke ii-indices ezivela kwi-`[mid, len)` (ngaphandle kwesalathiso se-`len` uqobo).
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // UKHUSELEKO: `[ptr; mid]` kunye ne `[mid; len]` zingaphakathi kwe `self`, yona
        // izalisekisa iimfuno ze `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Yahlulahlula isilayi esinye esinokuguquguquka kubini kwisalathiso.
    ///
    /// Eyokuqala iya kuba nazo zonke ii-indices ezivela kwi-`[0, mid)` (ngaphandle kwesalathiso se-`mid` uqobo) kwaye eyesibini iya kuba nazo zonke ii-indices ezivela kwi-`[mid, len)` (ngaphandle kwesalathiso se-`len` uqobo).
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba i `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // UKHUSELEKO: `[ptr; mid]` kunye ne `[mid; len]` zingaphakathi kwe `self`, yona
        // izalisekisa iimfuno ze `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Yahlulahlula isilayi esinye kubini kwisalathiso, ngaphandle kokujonga imida.
    ///
    /// Eyokuqala iya kuba nazo zonke ii-indices ezivela kwi-`[0, mid)` (ngaphandle kwesalathiso se-`mid` uqobo) kwaye eyesibini iya kuba nazo zonke ii-indices ezivela kwi-`[mid, len)` (ngaphandle kwesalathiso se-`len` uqobo).
    ///
    ///
    /// Ngenye indlela ekhuselekileyo jonga i [`split_at`].
    ///
    /// # Safety
    ///
    /// Ukubiza le ndlela ngesalathiso esingaphandle kwemida yi *[undefined behaviour]* Nokuba isalathiso esisiphumo asisetyenziswanga.Umntu ofowunayo kufuneka aqinisekise ukuba i `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // UKHUSELEKO: Umntu ofowunayo kufuneka ajonge i `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Yahlulahlula isilayi esinye esiguqukayo sibe sisibini kwisalathiso, ngaphandle kokujonga imida.
    ///
    /// Eyokuqala iya kuba nazo zonke ii-indices ezivela kwi-`[0, mid)` (ngaphandle kwesalathiso se-`mid` uqobo) kwaye eyesibini iya kuba nazo zonke ii-indices ezivela kwi-`[mid, len)` (ngaphandle kwesalathiso se-`len` uqobo).
    ///
    ///
    /// Ngenye indlela ekhuselekileyo jonga i [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Ukubiza le ndlela ngesalathiso esingaphandle kwemida yi *[undefined behaviour]* Nokuba isalathiso esisiphumo asisetyenziswanga.Umntu ofowunayo kufuneka aqinisekise ukuba i `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // UKHUSELEKO: Umntu ofowunayo kufuneka ajonge i `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` kwaye i `[mid; len]` ayigqithisi, ke ukubuyisela ireferensi enokutshintsha kulungile.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Ibuyisa iterator ngaphezulu kwemirhumo eyahlulwe ngezinto ezihambelana ne `pred`.
    /// Into ehambelana nayo ayiqulathwanga kwimirhumo.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ukuba into yokuqala ifanisiwe, isilayidi esingenanto iya kuba yinto yokuqala ebuyiswayo ngulowo uyisebenzisayo.
    /// Ngokufanayo, ukuba into yokugqibela kwisilayidi iyahambelana, isilayidi esingenanto iya kuba yinto yokugqibela ebuyiswe ngumhambisi:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ukuba izinto ezimbini ezihambelanayo zisondele ngokuthe ngqo, isilayidi esingenanto siya kubakho phakathi kwabo:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto eziguqukayo ezahlulwe zizinto ezihambelana ne `pred`.
    /// Into ehambelana nayo ayiqulathwanga kwimirhumo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Ibuyisa iterator ngaphezulu kwemirhumo eyahlulwe ngezinto ezihambelana ne `pred`.
    /// Into ehambelana nayo iqulethwe kwisiphelo senkxaso yangaphambili njengesiphelo.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ukuba into yokugqibela yesilayidi iyahambelana, loo nto iya kuqwalaselwa njengesiphelo sesilayidi esandulelayo.
    ///
    /// Esi silayi iya kuba yinto yokugqibela ebuyiswe ngumsetyenzisi wayo.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto eziguqukayo ezahlulwe zizinto ezihambelana ne `pred`.
    /// Into ehambelana nayo iqulethwe kwi-subslice yangaphambili njengesiphelo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Ibuyisa iterator ngaphezulu kwemirhumo eyahlulwe ngezinto ezihambelana ne `pred`, ukuqala esiphelweni sesilayi kunye nokusebenza ngasemva.
    /// Into ehambelana nayo ayiqulathwanga kwimirhumo.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Njengakwi `split()`, ukuba into yokuqala okanye eyokugqibela ifanisiwe, isilayidi esingenanto siya kuba yinto yokuqala (okanye yokugqibela) ebuyiswe ngumhambisi.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ezinokutshintshwa ezahlulwe zizinto ezihambelana ne-`pred`, ukuqala esiphelweni sesilayi kunye nokusebenza ngasemva.
    /// Into ehambelana nayo ayiqulathwanga kwimirhumo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Ibuyisa iterator ngaphezulu kwemirhumo eyahlulwe ngezinto ezihambelana ne `pred`, inikwe umda ekubuyiseni izinto ezininzi ze `n`.
    /// Into ehambelana nayo ayiqulathwanga kwimirhumo.
    ///
    /// Izinto zokugqibela ezibuyisiweyo, ukuba zikhona, ziya kuthi ziqulathe intsalela yesilayi.
    ///
    /// # Examples
    ///
    /// Phrinta isilayi esahlulwe kanye ngamanani ahlulekayo ngo-3 (okt, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Ibuyisa iterator ngaphezulu kwemirhumo eyahlulwe ngezinto ezihambelana ne `pred`, inikwe umda ekubuyiseni izinto ezininzi ze `n`.
    /// Into ehambelana nayo ayiqulathwanga kwimirhumo.
    ///
    /// Izinto zokugqibela ezibuyisiweyo, ukuba zikhona, ziya kuthi ziqulathe intsalela yesilayi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Ibuyisa iterator ngaphezulu kwemirhumo eyahlulwe ngezinto ezihambelana ne `pred` enqunyelwe ekubuyiseni izinto ezininzi ze `n`.
    /// Oku kuqala esiphelweni sesilayidi kwaye kusebenze ngasemva.
    /// Into ehambelana nayo ayiqulathwanga kwimirhumo.
    ///
    /// Izinto zokugqibela ezibuyisiweyo, ukuba zikhona, ziya kuthi ziqulathe intsalela yesilayi.
    ///
    /// # Examples
    ///
    /// Phrinta isilayi esahlulwe kube kanye, ukuqala esiphelweni, ngamanani ahlukaniswe ngo-3 (okt, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Ibuyisa iterator ngaphezulu kwemirhumo eyahlulwe ngezinto ezihambelana ne `pred` enqunyelwe ekubuyiseni izinto ezininzi ze `n`.
    /// Oku kuqala esiphelweni sesilayidi kwaye kusebenze ngasemva.
    /// Into ehambelana nayo ayiqulathwanga kwimirhumo.
    ///
    /// Izinto zokugqibela ezibuyisiweyo, ukuba zikhona, ziya kuthi ziqulathe intsalela yesilayi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Ibuyisa i `true` ukuba isilayidi sinento enexabiso elinikiweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Ukuba awunayo i `&T`, kodwa u `&U` ufana no `T: Borrow<U>` (umz
    /// Umtya: Boleka<str>Ungasebenzisa i `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // isilayi se `String`
    /// assert!(v.iter().any(|e| e == "hello")); // khangela nge `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Ibuyisa i `true` ukuba i `needle` sisimaphambili sesilayi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Ihlala ibuyisa i `true` ukuba i `needle` sisilayi esingenanto:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Ibuyisa i `true` ukuba i `needle` sisimamva sesilayidi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Ihlala ibuyisa i `true` ukuba i `needle` sisilayi esingenanto:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Ibuyisa umrhumo othotyelwayo isuswe isimaphambili.
    ///
    /// Ukuba isilayidi siqala nge-`prefix`, sibuyisela isijungqu emva kwesimaphambili, sisongelwe kwi `Some`.
    /// Ukuba i `prefix` ayinanto, vele ubuyisele isilayi sokuqala.
    ///
    /// Ukuba isilayi asiqali nge-`prefix`, sibuyisa i `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Lo msebenzi uya kufuna ukuphinda ubhale ukuba iSlicePattern iya kuba nobugocigoci ngakumbi.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Ibuyisa i-subslice isimamva sisuswe.
    ///
    /// Ukuba isilayidi siphela nge-`suffix`, sibuyisela islice ngaphambi kwesimamva, sisongelwe kwi `Some`.
    /// Ukuba i `suffix` ayinanto, vele ubuyisele isilayi sokuqala.
    ///
    /// Ukuba isilayi asipheli ngo-`suffix`, sibuyisa i `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Lo msebenzi uya kufuna ukuphinda ubhale ukuba iSlicePattern iya kuba nobugocigoci ngakumbi.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Ukukhangela okubini kwesi silayi sihlelisiweyo ngento enikiweyo.
    ///
    /// Ukuba ixabiso lifunyenwe emva koko i [`Result::Ok`] ibuyisiwe, iqulethe isalathiso sento yokudibanisa.
    /// Ukuba kukho ukungqinelana okuninzi, kuya kubuyiselwa nakuphi na umdlalo.
    /// Ukuba ixabiso alifumaneki emva koko i [`Result::Err`] ibuyisiwe, iqulethe isalathiso apho into efanayo inokufakwa khona ngelixa kugcinwa ucwangco oluhleliweyo.
    ///
    ///
    /// Jonga kwakhona i [`binary_search_by`], [`binary_search_by_key`], kunye ne [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ijonga uthotho lwezinto ezine.
    /// Eyokuqala ifunyenwe, inendawo ekhethekileyo yokuma;eyesibini neyesithathu azifunyanwa;owesine angadibanisa nasiphi na isikhundla kwi `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ukuba ufuna ukufaka into kwi-vector ehleliweyo, ngelixa ugcina iodolo yohlobo:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Ukuphendla okubini kwesi silayi sihlelweyo ngomsebenzi wokuthelekisa.
    ///
    /// Umsebenzi wokuthelekisa kuya kufuneka uphumeze iodolo ehambelana nolungelelwaniso lwesilayidi esisisiseko, ibuyisa ikhowudi yoku-odola ebonisa ukuba ingxoxo yayo ngu-`Less`, `Equal` okanye `Greater` kwithagethi oyifunayo.
    ///
    ///
    /// Ukuba ixabiso lifunyenwe emva koko i [`Result::Ok`] ibuyisiwe, iqulethe isalathiso sento yokudibanisa.Ukuba kukho ukungqinelana okuninzi, kuya kubuyiselwa nakuphi na umdlalo.
    /// Ukuba ixabiso alifumaneki emva koko i [`Result::Err`] ibuyisiwe, iqulethe isalathiso apho into efanayo inokufakwa khona ngelixa kugcinwa ucwangco oluhleliweyo.
    ///
    /// Jonga kwakhona i [`binary_search`], [`binary_search_by_key`], kunye ne [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ijonga uthotho lwezinto ezine.Eyokuqala ifunyenwe, inendawo ekhethekileyo yokuma;eyesibini neyesithathu azifunyanwa;owesine angadibanisa nasiphi na isikhundla kwi `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // UKHUSELEKO: umnxeba wenziwa ukhuselekile ngaba bahlaseli balandelayo:
            // - `mid >= 0`
            // - `mid < size`: I `mid` inikwe umda nge `[left; right)` ebotshiwe.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Isizathu sokuba sisebenzise ukuhamba kolawulo lwe if/else endaweni yomdlalo kukuba ulungelelwaniso lomdlalo luthelekisa imisebenzi, ebuthathaka ngefrf.
            //
            // Le yi x86 asm ye u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Ukukhangela okubini kwesi silayidi sihlelweyo ngomsebenzi ophambili wokukhupha.
    ///
    /// Thatha ukuba isilayidi sihlelwe ngendlela yesitshixo, umzekelo nge [`sort_by_key`] kusetyenziswa umsebenzi ofanayo wokukhupha.
    ///
    /// Ukuba ixabiso lifunyenwe emva koko i [`Result::Ok`] ibuyisiwe, iqulethe isalathiso sento yokudibanisa.
    /// Ukuba kukho ukungqinelana okuninzi, kuya kubuyiselwa nakuphi na umdlalo.
    /// Ukuba ixabiso alifumaneki emva koko i [`Result::Err`] ibuyisiwe, iqulethe isalathiso apho into efanayo inokufakwa khona ngelixa kugcinwa ucwangco oluhleliweyo.
    ///
    ///
    /// Jonga kwakhona i [`binary_search`], [`binary_search_by`], kunye ne [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ujonge uthotho lwezinto ezine kwisilayidi sezibini ezilungelelaniswe zizinto zazo zesibini.
    /// Eyokuqala ifunyenwe, inendawo ekhethekileyo yokuma;eyesibini neyesithathu azifunyanwa;owesine angadibanisa nasiphi na isikhundla kwi `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // I-Lint rustdoc::broken_intra_doc_links ivumelekile njengoko i-`slice::sort_by_key` ikwi-crate `alloc`, kwaye ayinjalo okwangoku xa kusakhiwa i `core`.
    //
    // Amakhonkco kumzantsi we crate: #74481.Kuba ii-primitives zibhalwe kuphela kwi-libstd (#73423), oku akunakuze kukhokelele kumakhonkco aqhekekileyo ekusebenzeni.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ihlela isilayi, kodwa ayinakugcina ucwangco lwezinto ezilinganayo.
    ///
    /// Olu hlobo aluzinzanga (okt, inokuphinda ilungelelanise izinto ezilinganayo), endaweni (okt, ayabi), kunye *O*(*n*\log(*n*)) elona tyala libi.
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// I-algorithm yangoku isekwe kwi-[pattern-defeating quicksort][pdqsort] ngu-Orson Peters, edibanisa imeko ye-avareji ekhawulezileyo ye-randomsort kunye neyona meko ikhawulezileyo ye-heapsort, ngelixa kufezekiswa ixesha lomgama kwizilayi ezineepateni ezithile.
    /// Isebenzisa ulwahlulo oluthile ukuthintela iimeko eziwohlokayo, kodwa nge-seed emiselweyo ukusoloko inika isimilo sokuziphatha.
    ///
    /// Kukhawuleza ngokukhawuleza kunokuhlelwa okuzinzileyo, ngaphandle kwamatyala ambalwa akhethekileyo, umzekelo, xa isilayidi siqulathe ulandelelwano oluhleliweyo oluhleliweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ihlela isilayi ngomsebenzi wokuthelekisa, kodwa ayinakugcina ucwangco lwezinto ezilinganayo.
    ///
    /// Olu hlobo aluzinzanga (okt, inokuphinda ilungelelanise izinto ezilinganayo), endaweni (okt, ayabi), kunye *O*(*n*\log(*n*)) elona tyala libi.
    ///
    /// Umsebenzi wokuthelekisa kufuneka uchaze uku-odolwa ngokupheleleyo kwezinto ezikwisilayidi.Ukuba uku-odola akuphelelanga, iodolo yezinto ayichazwanga.I-odolo iyonke iodolo ukuba iyiyo (yazo zonke i `a`, `b` kunye ne `c`):
    ///
    /// * iyonke kunye ne-antisymmetric: ngokuchanekileyo enye ye `a < b`, `a == b` okanye `a > b` yinyani, kwaye
    /// * Ukutshintsha, i `a < b` kunye ne `b < c` kuthetha i `a < c`.Kuyafana ukubambelela kuzo zombini i `==` kunye ne `>`.
    ///
    /// Umzekelo, ngelixa i-[`f64`] ingasebenzisi i-[`Ord`] kuba i-`NaN != NaN`, singasebenzisa i-`partial_cmp` njengoluhlobo lomsebenzi wethu xa sisazi ukuba isilayidi asinayo i-`NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// I-algorithm yangoku isekwe kwi-[pattern-defeating quicksort][pdqsort] ngu-Orson Peters, edibanisa imeko ye-avareji ekhawulezileyo ye-randomsort kunye neyona meko ikhawulezileyo ye-heapsort, ngelixa kufezekiswa ixesha lomgama kwizilayi ezineepateni ezithile.
    /// Isebenzisa ulwahlulo oluthile ukuthintela iimeko eziwohlokayo, kodwa nge-seed emiselweyo ukusoloko inika isimilo sokuziphatha.
    ///
    /// Kukhawuleza ngokukhawuleza kunokuhlelwa okuzinzileyo, ngaphandle kwamatyala ambalwa akhethekileyo, umzekelo, xa isilayidi siqulathe ulandelelwano oluhleliweyo oluhleliweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ukuhlengahlengisa umva
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ihlela isilayi ngomsebenzi ophambili wokukhupha, kodwa ayinakugcina ucwangco lwezinto ezilinganayo.
    ///
    /// Olu hlobo aluzinzanga (okt, inokuphinda ilungelelanise izinto ezilinganayo), endaweni (okt, ayabi), kunye *O*(m\*n*\*log(* n *)) eyona meko imbi, apho umsebenzi ophambili uyi* O *(* m *).
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// I-algorithm yangoku isekwe kwi-[pattern-defeating quicksort][pdqsort] ngu-Orson Peters, edibanisa imeko ye-avareji ekhawulezileyo ye-randomsort kunye neyona meko ikhawulezileyo ye-heapsort, ngelixa kufezekiswa ixesha lomgama kwizilayi ezineepateni ezithile.
    /// Isebenzisa ulwahlulo oluthile ukuthintela iimeko eziwohlokayo, kodwa nge-seed emiselweyo ukusoloko inika isimilo sokuziphatha.
    ///
    /// Ngenxa yesicwangciso sayo esiphambili sokufowuna, i [`sort_unstable_by_key`](#method.sort_unstable_by_key) inokuthi icothe kune [`sort_by_cached_key`](#method.sort_by_cached_key) kwimeko apho umsebenzi ophambili ubiza.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Phinda uhlengahlengise isilayidi ukuze i-`index` ikwindawo yayo yokugqibela ehleliweyo.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Phinda ulungelelanise isilayidi ngomsebenzi wokuthelekisa onokuthi into eku-`index` ikwindawo yayo yokugqibela ehleliweyo.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Phinda uhlengahlengise isilayidi ngomsebenzi ophambili wokukhupha into yokuba i-`index` ikwindawo yayo yokugqibela ehleliweyo.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Phinda uhlengahlengise isilayidi ukuze i-`index` ikwindawo yayo yokugqibela ehleliweyo.
    ///
    /// Oku kulungelelaniswa kwakhona kunepropathi eyongezelelweyo ukuba naliphi na ixabiso elikwisikhundla `i < index` liya kuba ngaphantsi okanye lilingane nalo naliphi na ixabiso kwisikhundla `j > index`.
    /// Ukongeza, oku kulungelelaniswa kwakhona akuzinzanga (okt
    /// naliphi na inani lezinto ezilinganayo zinokuphelela kwindawo `index`), endaweni-okt
    /// ayabisi), kwaye *O*(*n*) yeyona meko imbi kakhulu.
    /// Lo msebenzi ukwaziwa njenge "kth element" kwezinye iilayibrari.
    /// Ibuyisa i-triplet yala maxabiso alandelayo: zonke izinto zingaphantsi kwenye kwisalathiso esinikiweyo, ixabiso kwisalathiso esinikiweyo, kunye nazo zonke izinto ezinkulu kunale ikwisalathiso esinikiweyo.
    ///
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// Ialgorithm yangoku isekwe kwicandelo elikhawulezayo lokhetho olufanayo lwe-algorithm ekhawulezayo esetyenziselwa i [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics xa i `index >= len()`, oko kuthetha ukuba ihlala iyi panics kwizilayi ezingenanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Fumana imedian
    /// v.select_nth_unstable(2);
    ///
    /// // Siqinisekiswe kuphela ukuba isilayidi siya kuba sesinye sezi zinto zilandelayo, ngokusekwe kwindlela esihlela ngayo malunga nesalathiso esichaziweyo.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Phinda ulungelelanise isilayidi ngomsebenzi wokuthelekisa onokuthi into eku-`index` ikwindawo yayo yokugqibela ehleliweyo.
    ///
    /// Oku kulungelelaniswa kwakhona kunepropathi eyongezelelweyo ukuba naliphi na ixabiso elikwisikhundla `i < index` liya kuba ngaphantsi okanye lilingane nalo naliphi na ixabiso kwisikhundla `j > index` usebenzisa umsebenzi othelekisa.
    /// Ukongeza, oku kulungelelaniswa kwakhona akuzinzanga (okt naliphi na inani lezinto ezilinganayo zinokuphela zikwisikhundla `index`), endaweni (okt ayabisi), kunye *O*(*n*) elona tyala libi.
    /// Lo msebenzi ukwaziwa ngokuba yi "kth element" kwezinye iilayibrari.
    /// Ibuyisa i-triplet yala maxabiso alandelayo: zonke izinto ezingaphantsi kwesinye kwisalathiso esinikiweyo, ixabiso kwisalathiso esinikiweyo, kunye nazo zonke izinto ezinkulu kunale ikwisalathiso esinikiweyo, kusetyenziswa umsebenzi othelekisiweyo onikiweyo.
    ///
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// Ialgorithm yangoku isekwe kwicandelo elikhawulezayo lokhetho olufanayo lwe-algorithm ekhawulezayo esetyenziselwa i [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics xa i `index >= len()`, oko kuthetha ukuba ihlala iyi panics kwizilayi ezingenanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Fumana iMedian ngokungathi isilayidi sahlelwa ngendlela esehla.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Siqinisekiswe kuphela ukuba isilayidi siya kuba sesinye sezi zinto zilandelayo, ngokusekwe kwindlela esihlela ngayo malunga nesalathiso esichaziweyo.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Phinda uhlengahlengise isilayidi ngomsebenzi ophambili wokukhupha into yokuba i-`index` ikwindawo yayo yokugqibela ehleliweyo.
    ///
    /// Oku kulungelelaniswa kwakhona kunepropathi eyongezelelweyo ukuba naliphi na ixabiso elikwisikhundla `i < index` liya kuba ngaphantsi okanye lilingane naliphi na ixabiso kwisikhundla `j > index` kusetyenziswa umsebenzi ongundoqo wokukhupha.
    /// Ukongeza, oku kulungelelaniswa kwakhona akuzinzanga (okt naliphi na inani lezinto ezilinganayo zinokuphela zikwisikhundla `index`), endaweni (okt ayabisi), kunye *O*(*n*) elona tyala libi.
    /// Lo msebenzi ukwaziwa ngokuba yi "kth element" kwezinye iilayibrari.
    /// Ibuyisa i-triplet yala maxabiso alandelayo: zonke izinto zingaphantsi kwenye kwisalathiso esinikiweyo, ixabiso kwisalathiso esinikiweyo, kunye nazo zonke izinto ezinkulu kunale ikwisalathiso esinikiweyo, kusetyenziswa umsebenzi okhutshiweyo ongundoqo.
    ///
    ///
    /// # Ukuphunyezwa kwangoku
    ///
    /// Ialgorithm yangoku isekwe kwicandelo elikhawulezayo lokhetho olufanayo lwe-algorithm ekhawulezayo esetyenziselwa i [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics xa i `index >= len()`, oko kuthetha ukuba ihlala iyi panics kwizilayi ezingenanto.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Buyisela imedian ngokungathi uluhlu luhlelwe ngokwexabiso elipheleleyo.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Siqinisekiswe kuphela ukuba isilayidi siya kuba sesinye sezi zinto zilandelayo, ngokusekwe kwindlela esihlela ngayo malunga nesalathiso esichaziweyo.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Ihambisa zonke izinto ezilandelelanayo eziphindaphindiweyo ukuya esiphelweni sesilayidi ngokokuphunyezwa kwe [`PartialEq`] trait.
    ///
    ///
    /// Ibuyisa izilayi ezibini.Eyokuqala ayiqulathanga zinto ziphindaphindekayo zilandelelanayo.
    /// Eyesibini iqulethe zonke iikopi ezingalandelelananga.
    ///
    /// Ukuba isilayidi sihleliwe, isilayidi sokuqala esibuyiselweyo asinazo iikopi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Ihambisa konke kodwa eyokuqala yezinto ezilandelelanayo ukuya esiphelweni sesilayidi esanelisa ulwalamano olunikiweyo.
    ///
    /// Ibuyisa izilayi ezibini.Eyokuqala ayiqulathanga zinto ziphindaphindekayo zilandelelanayo.
    /// Eyesibini iqulethe zonke iikopi ezingalandelelananga.
    ///
    /// Umsebenzi we `same_bucket` udlulise izingqinisiso kwizinto ezimbini ezivela kwisilayidi kwaye kufuneka sigqibe ukuba izinto zithelekisa ngokulinganayo.
    /// Izinto zidluliswa ngokulandelelana ngokuchasene nokulandelelana kwazo kwisilayidi, ke ukuba i `same_bucket(a, b)` ibuyisa i `true`, i `a` ishukunyisiwe ekupheleni kwesilayidi.
    ///
    ///
    /// Ukuba isilayidi sihleliwe, isilayidi sokuqala esibuyiselweyo asinazo iikopi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Nangona sinesalathiso esinokuguquguquka kwi `self`, asinakho ukwenza utshintsho olungenangqondo *.Iifowuni ze `same_bucket` zinokuthi panic, ke kufuneka siqinisekise ukuba isilayidi sikwisimo esifanelekileyo ngawo onke amaxesha.
        //
        // Indlela esiphatha ngayo oku kukusebenzisa ukutshintshana;sisebenza ngaphezulu kwawo onke amanqaku, sitshintsha njengoko sihamba ukuze ekugqibeleni izinto esinqwenela ukuzigcina ziphambili, kwaye abo sinqwenela ukubala ngasemva.
        // Singahlulahlula isilayi.
        // Lo msebenzi useyi-`O(n)`.
        //
        // Umzekelo: Siqala kweli lizwe, apho i `r` imele "ngokulandelayo
        // funda "kwaye i `w` imele" okulandelayo_kubhala`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ukuthelekisa i self[r] ngokuchasene nesiqu sakho [w-1], ayisiyimpinda, ke sitshintsha i self[r] kunye ne self[w] (akukho siphumo njenge r==w) kwaye emva koko sonyuse zombini r kunye w, usishiya no:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Xa kuthelekiswa i self[r] ngokuchasene nesiqu sakho [w-1], eli xabiso liyimpinda, ke siyanyusa i `r` kodwa sishiya yonke enye into ingatshintshanga:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ukuthelekisa i self[r] ngokuchasene nesiqu sakho [w-1], ayisiyimpinda, ke tshintsha i self[r] kunye ne self[w] kwaye uqhubele phambili r kunye w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ayisiyimpinda, phinda:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Phinda kabini, i advance r. End yesilayidi.Yahlulahlula kwi-w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // UKHUSELEKO: imeko ye `while` iqinisekisa i `next_read` kunye ne `next_write`
        // zingaphantsi kwe `len`, kungoko zingaphakathi kwe `self`.
        // `prev_ptr_write` akhomba kwinto enye ngaphambi kwe `ptr_write`, kodwa i `next_write` iqala ngo-1, ke i `prev_ptr_write` ayinakuze ibe ngaphantsi kwe-0 kwaye ingaphakathi kwesilayidi.
        // Oku kuzalisekisa iimfuno zokungasusi kwi-`ptr_read`, `prev_ptr_write` kunye ne-`ptr_write`, kunye nokusebenzisa i-`ptr.add(next_read)`, `ptr.add(next_write - 1)` kunye ne-`prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` ikonyuselwa kube kanye kube kanye kwilog nganye ngentsingiselo yokuba akukho nto itsiwayo xa ifuna ukutshintshwa.
        //
        // `ptr_read` kwaye i-`prev_ptr_write` ayizange yalathe kwinto enye.Oku kuyimfuneko kwi `&mut *ptr_read`, `&mut* prev_ptr_write` ukuze ikhuseleke.
        // Inkcazo ngokulula kukuba i `next_read >= next_write` ihlala iyinyani, yiyo loo nto i `next_read > next_write - 1` nayo.
        //
        //
        //
        //
        //
        unsafe {
            // Kuphephe ukujongwa kwemida ngokusebenzisa izikhombisi eziluhlaza.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Ihambisa konke kodwa eyokuqala yezinto ezilandelelanayo ukuya esiphelweni sesilayidi esisombulula kwiqhosha elifanayo.
    ///
    ///
    /// Ibuyisa izilayi ezibini.Eyokuqala ayiqulathanga zinto ziphindaphindekayo zilandelelanayo.
    /// Eyesibini iqulethe zonke iikopi ezingalandelelananga.
    ///
    /// Ukuba isilayidi sihleliwe, isilayidi sokuqala esibuyiselweyo asinazo iikopi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Ujikelezisa isilayidi endaweni yokuba izinto zokuqala zesilayidi zihambe ziye esiphelweni ngelixa izinto zokugqibela ze `self.len() - mid` zihamba ziye ngaphambili.
    /// Emva kokubiza i `rotate_left`, into ngaphambili kwisalathiso `mid` iya kuba yinto yokuqala kwisilayidi.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uya kuba panic ukuba i `mid` ingaphezulu kobude besilayidi.Qaphela ukuba i `mid == self.len()` yenza i _not_ panic kwaye ayisijiki.
    ///
    /// # Complexity
    ///
    /// Ithatha umgca (kwi `self.len()`) ixesha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Ukujikeleza irhafu:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // UKHUSELEKO: Uluhlu lwe-`[p.add(mid) - mid, p.add(mid) + k)` luncinci
        // isemthethweni ekufundeni nasekubhaleni, njengoko kufunwa yi-`ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Ujikelezisa isilayidi endaweni yokuba izinto zokuqala zesilayidi zihambe ziye esiphelweni ngelixa izinto zokugqibela ze `k` zihamba ziye ngaphambili.
    /// Emva kokubiza i `rotate_right`, into ngaphambili kwisalathiso `self.len() - k` iya kuba yinto yokuqala kwisilayidi.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uya kuba panic ukuba i `k` ingaphezulu kobude besilayidi.Qaphela ukuba i `k == self.len()` yenza i _not_ panic kwaye ayisijiki.
    ///
    /// # Complexity
    ///
    /// Ithatha umgca (kwi `self.len()`) ixesha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Jikelezisa umrhumo:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // UKHUSELEKO: Uluhlu lwe-`[p.add(mid) - mid, p.add(mid) + k)` luncinci
        // isemthethweni ekufundeni nasekubhaleni, njengoko kufunwa yi-`ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Ugcwalisa i-`self` ngezinto ngokudibanisa i `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Ugcwalisa i `self` ngezinto ezibuyisiweyo ngokubiza ukuvalwa okuphindaphindiweyo.
    ///
    /// Le ndlela isebenzisa ukuvala ukwenza amaxabiso amatsha.Ukuba ukhetha i [`Clone`] ngexabiso elinikiweyo, sebenzisa i [`fill`].
    /// Ukuba ufuna ukusebenzisa i [`Default`] trait ukwenza amaxabiso, ungapasa i [`Default::default`] njengengxoxo.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Ikopa izinto ukusuka kwi `src` ukuya kwi `self`.
    ///
    /// Ubude be `src` kufuneka bulingane ne `self`.
    ///
    /// Ukuba i `T` inyanzelisa i `Copy`, inokuthi isebenze ngakumbi ukusebenzisa i [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Lo msebenzi uya kuba panic ukuba izilayi ezibini zinobude obahlukeneyo.
    ///
    /// # Examples
    ///
    /// Ukwenza izinto ezimbini kwisilayidi ukuya kwesinye:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Kuba izilayi kufuneka zilingane, silamba isilayidi somthombo ukusuka kwizinto ezine ukuya kwezimbini.
    /// // Iya kuba panic ukuba asiyenzi le nto.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// I-Rust inyanzelisa ukuba kubekho ireferensi enye enokutshintshwa ngaphandle kwesalathiso sedatha ethile kubungakanani obuthile.
    /// Ngenxa yoku, ukuzama ukusebenzisa i-`clone_from_slice` kwisilayidi esinye kuya kubangela ukungaphumeleli:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ukusebenza kule nto, sinokusebenzisa i [`split_at_mut`] ukwenza iziqwenga ezibini ezahlukileyo kwisilayidi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Ikopa zonke izinto ukusuka kwi-`src` ukuya kwi-`self`, usebenzisa i-memcpy.
    ///
    /// Ubude be `src` kufuneka bulingane ne `self`.
    ///
    /// Ukuba i `T` ayizalisekisi i `Copy`, sebenzisa i [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Lo msebenzi uya kuba panic ukuba izilayi ezibini zinobude obahlukeneyo.
    ///
    /// # Examples
    ///
    /// Ukukopa izinto ezimbini kwisilayidi kungena kwenye:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Kuba izilayi kufuneka zilingane, silamba isilayidi somthombo ukusuka kwizinto ezine ukuya kwezimbini.
    /// // Iya kuba panic ukuba asiyenzi le nto.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// I-Rust inyanzelisa ukuba kubekho ireferensi enye enokutshintshwa ngaphandle kwesalathiso sedatha ethile kubungakanani obuthile.
    /// Ngenxa yoku, ukuzama ukusebenzisa i-`copy_from_slice` kwisilayidi esinye kuya kubangela ukungaphumeleli:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ukusebenza kule nto, sinokusebenzisa i [`split_at_mut`] ukwenza iziqwenga ezibini ezahlukileyo kwisilayidi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Indlela yekhowudi ye-panic yafakwa kwindawo ebandayo ukuze ingabhloki indawo yokufowuna.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // UKHUSELEKO: `self` iyasebenza `self.len()` yezinto ngokwenkcazo, kwaye i `src` yayi
        // itshekishwe ukuba inobude obulinganayo.
        // Izilayi azinakugqithana kuba izingqinisiso eziguqukayo zizodwa.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Ikopa izinto ukusuka kwelinye icala lesilayidi ziye kwelinye icandelo lazo, usebenzisa i-memmove.
    ///
    /// `src` Uluhlu oluphakathi kwe `self` ukukopa kuyo.
    /// `dest` sisalathiso sokuqala kuluhlu oluphakathi kwe `self` ukukhuphela kuyo, eya kuthi ibe nobude obulinganayo ne `src`.
    /// Amanqanaba amabini anokugqagqana.
    /// Iziphelo zala manqanaba mabini zingaphantsi okanye zilingane ne-`self.len()`.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uya kuba panic ukuba ngaba naluphi na uluhlu lungaphezulu kokuphela kwesilayidi, okanye ukuba isiphelo se `src` siphambi kokuqala.
    ///
    ///
    /// # Examples
    ///
    /// Ukukopa ii-byte ezine kwisilayidi:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // UKHUSELEKO: iimeko ze `ptr::copy` zonke zijongwe ngasentla,
        // Njengazo ze `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Utshintsha zonke izinto kwi `self` kunye nezo zikwi `other`.
    ///
    /// Ubude be `other` kufuneka bulingane ne `self`.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uya kuba panic ukuba izilayi ezibini zinobude obahlukeneyo.
    ///
    /// # Example
    ///
    /// Ukutshintshela izinto ezimbini kwizilayi:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// I-Rust inyanzelisa ukuba kunokubakho isalathiso esinye esinokutshintshwa kwisiqwengana sedatha kwindawo ethile.
    ///
    /// Ngenxa yoku, ukuzama ukusebenzisa i-`swap_with_slice` kwisilayidi esinye kuya kubangela ukungaphumeleli:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Ukusebenza kule nto, singasebenzisa i-[`split_at_mut`] ukwenza amacwecwe amabini ahlukeneyo anokuguquguquka kwisilayidi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // UKHUSELEKO: `self` iyasebenza `self.len()` yezinto ngokwenkcazo, kwaye i `src` yayi
        // itshekishwe ukuba inobude obulinganayo.
        // Izilayi azinakugqithana kuba izingqinisiso eziguqukayo zizodwa.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Umsebenzi ukubala ubude besilayidi esiphakathi kunye nesilayidi se `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Into esiza kuyenza malunga ne `rest` kukufumanisa ukuba zeziphi izinto ezininzi esinokuzibeka kwelona nani lisezantsi lee-T`s.
        //
        // Kwaye zingaphi ii-T`s esizifunayo kwi-"multiple" nganye.
        //
        // Cinga ngomzekelo T=u8 U=u16.Emva koko singabeka u-1 ku-2 Ts.Elula.
        // Ngoku, qwalasela umzekelo kwimeko apho ubukhulu_of: :<T>=16, ubungakanani_of::<U>=24.</u>
        // Singasibeka endaweni yesi-2 kwindawo nganye ye-3 Ts kwisilayi se `rest`.
        // Into enzima ngakumbi.
        //
        // Ifomula yokubala oku:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Yandiswa kwaye yenziwa lula:
        //
        // Us=ubungakanani_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=ubungakanani_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Ngethamsanqa kuba yonke le nto ivavanywa rhoqo ... ukusebenza apha akunamsebenzi!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // Iterative stein's algorithm Sifanele siyenze le `const fn` (kwaye sibuyele kwi-algorithm ephindaphindayo ukuba siyayenza) kuba ukuthembela kwi-llvm ukwenza yonke le nto…kulungile, kuyandonwabisa.
            //
            //

            // UKHUSELEKO: I `a` kunye ne `b` zikhangelwe ukuba azizizo amaxabiso.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // susa zonke izinto ezi-2 ku-b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // UKHUSELEKO: `b` ikhangelwe ukuba ayisiyo-zero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Ukuxhobisa olu lwazi, sinokufumana ukuba zingaphi ii-U`s esinokulingana ngazo!
        let us_len = self.len() / ts * us;
        // Kwaye zingaphi ii-T`s eziza kubakho kwisilayidi esilandelayo!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Tshintshela isilayi kwisilayidi solunye uhlobo, uqinisekise ukuba ulungelelwaniso lweentlobo luyagcinwa.
    ///
    /// Le ndlela yahlula isilayi kwizilayi ezintathu ezahlukileyo: isimaphambili, isilayidi esiphakathi esilungelelaniswe ngokuchanekileyo sohlobo olutsha, kunye nesimamva sesilayidi.
    /// Le ndlela inokwenza ukuba isilayidi esiphakathi sibe nobude obude kunokwenzeka kuhlobo olunikiweyo kunye nesilayidi sokufaka, kodwa kuphela kukusebenza kwealgorithm yakho ekufuneka kuxhomekeke kuloo, hayi kukuchaneka kwayo.
    ///
    /// Kuvumelekile kuyo yonke idatha yegalelo ukuba ibuyiselwe njengesiqalo okanye isilayidi sesimamva.
    ///
    /// Le ndlela ayinanjongo xa nayiphi na into yokufaka i `T` okanye into ekhutshiweyo engu `U` ilingana noziro kwaye iya kubuyisa isilayi sokuqala ngaphandle kokuqhekeza nantoni na.
    ///
    /// # Safety
    ///
    /// Le ndlela ngokuyintloko i `transmute` ngokubhekisele kwizinto ezikwisilayidi esiphakathi esibuyiselweyo, ke zonke imiqolomba yesiqhelo emalunga ne `transmute::<T, U>` nayo iyasebenza apha.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Qaphela ukuba uninzi lwalo msebenzi luya kuvavanywa rhoqo,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // phatha ii-ZSTs ngokukodwa, ezingashukumiyo kwaphela.
            return (self, &[], &[]);
        }

        // Kuqala, fumana ukuba leliphi ixesha lokwahlula phakathi kwesilayidi sokuqala kunye nesesi-2.
        // Kulula nge ptr.align_offset.
        let ptr = self.as_ptr();
        // UKHUSELEKO: Jonga indlela ye `align_to_mut` yokufaka ingxelo eneenkcukacha ngokhuseleko.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // UKHUSELEKO: ngoku i `rest` ilungelelaniswe ngokuqinisekileyo, ke i `from_raw_parts` engezantsi ilungile,
            // kuba lowo ufowunayo uqinisekisa ukuba singadlulisa i `T` ukuya kwi `U` ngokukhuselekileyo.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Tshintshela isilayi kwisilayidi solunye uhlobo, uqinisekise ukuba ulungelelwaniso lweentlobo luyagcinwa.
    ///
    /// Le ndlela yahlula isilayi kwizilayi ezintathu ezahlukileyo: isimaphambili, isilayidi esiphakathi esilungelelaniswe ngokuchanekileyo sohlobo olutsha, kunye nesimamva sesilayidi.
    /// Le ndlela inokwenza ukuba isilayidi esiphakathi sibe nobude obude kunokwenzeka kuhlobo olunikiweyo kunye nesilayidi sokufaka, kodwa kuphela kukusebenza kwealgorithm yakho ekufuneka kuxhomekeke kuloo, hayi kukuchaneka kwayo.
    ///
    /// Kuvumelekile kuyo yonke idatha yegalelo ukuba ibuyiselwe njengesiqalo okanye isilayidi sesimamva.
    ///
    /// Le ndlela ayinanjongo xa nayiphi na into yokufaka i `T` okanye into ekhutshiweyo engu `U` ilingana noziro kwaye iya kubuyisa isilayi sokuqala ngaphandle kokuqhekeza nantoni na.
    ///
    /// # Safety
    ///
    /// Le ndlela ngokuyintloko i `transmute` ngokubhekisele kwizinto ezikwisilayidi esiphakathi esibuyiselweyo, ke zonke imiqolomba yesiqhelo emalunga ne `transmute::<T, U>` nayo iyasebenza apha.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Qaphela ukuba uninzi lwalo msebenzi luya kuvavanywa rhoqo,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // phatha ii-ZSTs ngokukodwa, ezingashukumiyo kwaphela.
            return (self, &mut [], &mut []);
        }

        // Kuqala, fumana ukuba leliphi ixesha lokwahlula phakathi kwesilayidi sokuqala kunye nesesi-2.
        // Kulula nge ptr.align_offset.
        let ptr = self.as_ptr();
        // UKHUSELEKO: Apha siqinisekisa ukuba siza kusebenzisa izikhombisi ezingqameneyo ze-U ze
        // indlela eseleyo.Oku kwenziwa ngokudlulisa isikhombisi kwi&[T] ngolungelelwaniso olujolise ku-U.
        // `crate::ptr::align_offset` ibizwa ngokuba ilungelelaniswe ngokuchanekileyo nangokuchanekileyo isikhombisi `ptr` (sivela kwisalathiso se `self`) kunye nobukhulu obungamandla amabini (kuba isuka kulungelelwaniso lwe-U), yanelisa imiqobo yokhuseleko.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Asinakho ukusebenzisa i `rest` kwakhona emva koku, oko kungavula igama layo elithi `mut_ptr`!UKHUSELEKO: jonga amagqabantshintshi e `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Ukukhangela ukuba ngaba izinto zeli qhekeza zilungisiwe.
    ///
    /// Oko kukuthi, kwinto nganye `a` kunye nezinto zayo ezilandelayo `b`, `a <= b` kufuneka ibambe.Ukuba isilayidi sivelisa ngokuthe ngqo zero okanye into enye, i `true` iyabuyiselwa.
    ///
    /// Qaphela ukuba i-`Self::Item` yi-`PartialOrd` kuphela, kodwa ingeyiyo i-`Ord`, le nkcazo ingentla ichaza ukuba lo msebenzi ubuyisela i-`false` ukuba kukho naziphi na izinto ezimbini ezilandelelanayo ezingalinganiyo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Ukujonga ukuba ngaba izinto zesilayidi zihleliwe kusetyenziswa umsebenzi othelekisiweyo.
    ///
    /// Endaweni yokusebenzisa i `PartialOrd::partial_cmp`, lo msebenzi usebenzisa umsebenzi onikiweyo we `compare` ukumisela uku-odolwa kwezinto ezimbini.
    /// Ngaphandle kwalonto, ilingana ne [`is_sorted`];jonga amaxwebhu alo ngolwazi oluthe kratya.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Ukujonga ukuba ngaba izinto zesilayidi zihleliwe kusetyenziswa umsebenzi ongundoqo wokukhupha.
    ///
    /// Endaweni yokuthelekisa izinto zesilayidi ngokuthe ngqo, lo msebenzi uthelekisa amaqhosha ezinto, njengoko kumiselwe yi `f`.
    /// Ngaphandle kwalonto, ilingana ne [`is_sorted`];jonga amaxwebhu alo ngolwazi oluthe kratya.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Ibuyisa isalathiso senqaku lokwahlulahlula ngokwengxelo enikiweyo (isalathiso sokuqala kwesahlulelo sesibini).
    ///
    /// Isilayidi kucingelwa ukuba sahlulwe ngokwesivisa esinikiweyo.
    /// Oku kuthetha ukuba zonke izinto ekubhekiswa kuzo sisichazi ziyinyani ekuqaleni kwesilayidi kwaye zonke izinto ekubhekiswa kuzo sisivisa zibubuxoki zisekupheleni.
    ///
    /// Umzekelo, i [7, 15, 3, 5, 4, 12, 6] yahlulahlulwe phantsi kwesivakalisi x% 2!=0 (onke amanani angaqhelekanga asekuqalekeni, onke ade ekugqibeleni).
    ///
    /// Ukuba esi silayi asihlulwanga, isiphumo esibuyiselweyo asichazwanga kwaye asinantsingiselo, njengoko le ndlela yenza uhlobo lokukhangela okwenziwa kabini.
    ///
    /// Jonga kwakhona i [`binary_search`], [`binary_search_by`], kunye ne [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // UKHUSELEKO: Xa i `left < right`, `left <= mid < right`.
            // Ke ngoko i `left` ihlala inyuka kwaye i `right` ihlala iyancipha, kwaye enye yazo iyakhethwa.Kuzo zombini iimeko i `left <= right` yanelisekile.Ke ukuba i `left < right` kwinyathelo, i `left <= right` yanelisekile kwinyathelo elilandelayo.
            //
            // Ke ngoko lo gama i `left != right`, i `0 <= left < right <= len` yanelisekile kwaye ukuba le meko i `0 <= mid < len` yanelisekile nayo.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Kufuneka sizicace ngokucacileyo kubude obulinganayo
        // ukwenza kube lula kwisenzi sokujonga kwimida yokujonga.
        // Kodwa ekubeni ingenakuthenjelwa kuthi sikwanobuchule obucacileyo beT: Ikopi.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Yenza isilayi esingenanto.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Yenza isilayi esingenanto esinokutshintsha.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Iipateni kwizilayi, okwangoku, zisetyenziswa kuphela yi `strip_prefix` kunye ne `strip_suffix`.
/// Kwinqaku le-future, sinethemba lokwenza i-`core::str::Pattern` (ethi ngexesha lokubhalwa inqunyelwe kwi-`str`) kwizilayi, emva koko le trait iyakutshintshwa okanye ipheliswe.
///
pub trait SlicePattern {
    /// Uhlobo lwento yesilayidi ehambelana nayo.
    type Item;

    /// Okwangoku, abathengi be `SlicePattern` bafuna isilayi.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}