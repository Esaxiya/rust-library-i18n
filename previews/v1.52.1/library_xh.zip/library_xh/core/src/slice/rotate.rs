// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Iyajikeleza uluhlu lwe `[mid-left, mid+right)` kangangokuba into eku-`mid` iba yinto yokuqala.Ngokulinganayo, ujikeleza uluhlu lwe-`left` ukuya ekhohlo okanye izinto ze-`right` ngasekunene.
///
/// # Safety
///
/// Uluhlu oluchaziweyo kufuneka lube semthethweni ekufundeni nasekubhaleni.
///
/// # Algorithm
///
/// Ialgorithm 1 isetyenziselwa amaxabiso amancinci e `left + right` okanye i `T` enkulu.
/// Izinto zihanjiswa kwizikhundla zazo zokugqibela ngexesha elinye ukuqala nge-`mid - left` kunye nokuqhubela phambili ngamanyathelo e-`right` modulo `left + right`, njengokuthi kufuneka kuphela okwethutyana.
/// Ekugqibeleni, sifika emva kwi `mid - left`.
/// Nangona kunjalo, ukuba i `gcd(left + right, right)` ayingo-1, la manyathelo angentla atsibe ngaphezulu kwezinto.
/// Umzekelo:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Ngethamsanqa, inani lokutsiba ngaphezulu kwezinto ezigqityiweyo lihlala lilingana, ke sinokususa indawo yethu yokuqala kwaye senze imijikelo engaphezulu (inani elipheleleyo leerandi yi `gcd(left + right, right)` value).
///
/// Isiphumo kukuba zonke izinto zigqityiwe kube kanye kwaye kube kanye.
///
/// Ialgorithm 2 iyasetyenziswa ukuba i `left + right` inkulu kodwa i `min(left, right)` incinci ngokwaneleyo ukuba ingene kwisitampu sesitaki.
/// Izinto ze `min(left, right)` zikotshelwe kwitephu, i `memmove` isetyenziselwa ezinye, kwaye zona ezikwi-buffer zibuyiselwa umngxuma kwelinye icala apho zazivela khona.
///
/// Iialgorithms ezinokuthi ziveliswe ngaphandle kwevektha xa sele i `left + right` iba nkulu ngokwaneleyo.
/// Ialgorithm 1 inokufakwa kumatshini wobuchwephesha ngokwenza i-chunking kunye nokwenza imijikelezo emininzi ngaxeshanye, kodwa kukho imijikelo embalwa kakhulu ukuya kuthi ga kwi-`left + right` enkulu kakhulu, kwaye elona tyala libi kakhulu kumjikelo omnye lihlala likhona.
/// Endaweni yoko, ialgorithm 3 isebenzisa ukutshintshwa okuphindaphindwayo kwezinto ze `min(left, right)` de kube ingxaki encinci yokujikeleza ishiyekile.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// xa i `left < right` ukutshintshwa kwenzeka ukusuka ngasekhohlo endaweni yoko.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ii-algorithms ezingezantsi zinokungaphumeleli ukuba la matyala awajongwa
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Ialgorithm 1 Iimpawu zeMicrobenchmarks zibonisa ukuba umndilili wentsebenzo yotshintsho olungalunganga lungcono kuyo yonke indlela kude kube malunga ne `left + right == 32`, kodwa elona tyala libi kakhulu liphula nokuba li-16.
            // I-24 yakhethwa njengomhlaba ophakathi.
            // Ukuba ubungakanani be `T` bukhulu kune-4`usize`s, le algorithm ikwahlula ezinye ii-algorithms.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ukuqala komjikelo wokuqala
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` ingafunyanwa ngaphambi kwesandla ngokubala i `gcd(left + right, right)`, kodwa kuyakhawuleza ukwenza iluphu enye ebala i-gcd njengempembelelo esecaleni, emva koko wenze enye i-chunk
            //
            //
            let mut gcd = right;
            // Iibhentshi zibonisa ukuba kuyakhawuleza ukutshintshela iitempers kuyo yonke indlela endaweni yokufunda okwethutyana kube kanye, ukukopa umva, emva koko ubhale okwethutyana ekugqibeleni.
            // Oku kunokwenzeka ngenxa yokuba ukutshintsha okanye ukutshintsha iithemorari kusetyenziswa idilesi enye yenkumbulo kwilog endaweni yokufuna ukulawula ezimbini.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // endaweni yokonyusa i `i` kwaye ujonge ukuba ingaphandle kwemida, sijonga ukuba ngaba i `i` izakuphuma ngaphandle kwemida kulwandiso olulandelayo.
                // Oku kuthintela nakuphi na ukusongelwa kwezikhombisi okanye i `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // Ukuphela komjikelo wokuqala
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // lo mqathango kufuneka ubelapha ukuba i `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // gqibezela i-chunk ngemijikelezo engaphezulu
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ayilodidi olungu-zero, ke kulungile ukuba yahlulahlulwe ngokobungakanani bayo.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Ialgorithm 2 I `[T; 0]` apha kukuqinisekisa ukuba oku kulungelelaniswe ngokufanelekileyo kwiT
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Ialgorithm 3 Kukho enye indlela yokutshintsha okubandakanya ukufumana apho kutshintshwe khona okugqibela kwealgorithm, kunye nokutshintsha usebenzisa loo chunk yokugqibela endaweni yokutshintsha ii-chunks ezikufutshane nale algorithm iyenzayo, kodwa le ndlela isakhawuleza.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Ialgorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}