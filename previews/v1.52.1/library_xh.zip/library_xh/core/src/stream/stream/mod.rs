use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Ujongano lokujongana nee-asynchronous iterators.
///
/// Lo ngowona mlambo uphambili trait.
/// Ngolwazi oluthe kratya malunga nomxholo wemijelo ngokubanzi, nceda ubone i [module-level documentation].
/// Ngokukodwa, unokufuna ukwazi ukuba uyenza njani i [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Uhlobo lwezinto eziveliswe ngumsinga.
    type Item;

    /// Ukuzama ukukhupha ixabiso elilandelayo lalo mlambo, ukubhalisa umsebenzi wangoku wokuvuka ukuba ixabiso alikafumaneki, kunye nokubuyisa i `None` ukuba umlambo udiniwe.
    ///
    /// # Ixabiso lokubuyisa
    ///
    /// Kukho amaxabiso amaninzi anokubakho, ngalinye libonisa imeko yomjelo eyahlukileyo:
    ///
    /// - `Poll::Pending` kuthetha ukuba ixabiso elilandelayo lomsinga alikakulungeli okwangoku.Ukuphunyezwa kuya kuqinisekisa ukuba umsebenzi wangoku uza kwaziswa xa ixabiso elilandelayo lilungile.
    ///
    /// - `Poll::Ready(Some(val))` kuthetha ukuba umlambo uvelise ngempumelelo ixabiso, i `val`, kwaye unokuvelisa amanye amaxabiso kwiminxeba elandelayo ye `poll_next`.
    ///
    /// - `Poll::Ready(None)` kuthetha ukuba umjelo uphelisiwe, kwaye i `poll_next` akufuneki iphinde ibuzwe.
    ///
    /// # Panics
    ///
    /// Nje ukuba umsinga ugqibe (ubuyisele i `Ready(None)` from `poll_next`), ebiza indlela yayo ye `poll_next` kwakhona i panic, ibhlokhi unaphakade, okanye ibangele ezinye iintlobo zeengxaki; i `Stream` trait ayibeki ziphumo kwifowuni enjalo.
    ///
    /// Nangona kunjalo, njengoko indlela ye `poll_next` ingaphawulwanga i `unsafe`, imigaqo eqhelekileyo ye Rust iyasebenza: iifowuni mazingaze zibangele isimilo esingachazwanga (inkohliso yenkumbulo, ukusetyenziswa gwenxa kwemisebenzi ye `unsafe`, okanye okunjalo), nokuba injani imeko yomjelo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Ibuyisa imida kubude obushiyekileyo bomjelo.
    ///
    /// Ngokukodwa, i-`size_hint()` ibuyisa isiTuple apho into yokuqala ibotshelelwe khona, kwaye into yesibini ibotshelelwe ngaphezulu.
    ///
    /// Isiqingatha sesibini sesiXhobo esibuyisiweyo yi [`Option`]`<`[usize`]`> `.
    /// I-[`None`] apha ithetha ukuba akukho kwaziweyo kungasentla, okanye ukubopha okuphezulu kukhulu kune-[`usize`].
    ///
    /// # Amanqaku okuphunyezwa
    ///
    /// Ayinyanzeliswa ukuba ukuphunyezwa komjelo kuvelisa inani lezinto ezibhengeziweyo.Umjelo wenqwelwana unokuvelisa ngaphantsi komda osezantsi okanye ngaphezulu komda ophezulu wezinto.
    ///
    /// `size_hint()` ijolise ikakhulu ekubeni isetyenziselwe ukwandiswa njengokugcina indawo yezinto zomjelo, kodwa akufuneki ithembeke kumzekelo, shiya umda wokutshekishwa kwikhowudi engakhuselekanga.
    /// Ukuphunyezwa ngokungachanekanga kwe `size_hint()` akufuneki kukhokelele ekuphulweni kwememori yokhuseleko.
    ///
    /// Oko kwathethi, ukuphunyezwa kufuneka kubonelele ngoqikelelo oluchanekileyo, kuba kungenjalo iya kuba kukwaphula umthetho we-trait.
    ///
    /// Ukuphunyezwa okungagqibekanga kubuyisela `(0,` ["None`]`)`echanekileyo kuwo nawuphi na umlambo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}