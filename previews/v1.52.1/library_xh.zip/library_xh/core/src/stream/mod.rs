//! Ukudityaniswa kwe-asynchronous iteration.
//!
//! Ukuba i-futures ngamaxabiso asynchronous, ke imilambo zi-asynchronous iterators.
//! Ukuba uzifumanele ingqokelela ye-asynchronous yohlobo oluthile, kwaye kufuneka wenze utyando kwizinto eziqokelelweyo, uya kukhawuleza ungene kwi 'streams'.
//! Imijelo isetyenziswa kakhulu kwikhowudi ye-asymchronous Rust, ke kufanelekile ukuba uyaziqhelanise nayo.
//!
//! Ngaphambi kokuchaza ngakumbi, masithethe ngendlela eyakhiwe ngayo le modyuli:
//!
//! # Organization
//!
//! Le modyuli icwangciswe ikakhulu ngohlobo:
//!
//! * [Traits] elona candelo lingundoqo: ezi traits zichaza ukuba loluphi uhlobo lwemilambo ekhoyo kunye nento onokuyenza ngayo.Iindlela zezi traits kufanelekile ukubeka ixesha elongezelelweyo lokufunda.
//! * Imisebenzi ibonelela ngeendlela eziluncedo zokwenza imijelo ethile esisiseko.
//! * Izitraki zihlala ziindlela ezibuyayo zeendlela ezahlukeneyo kule modyuli ye traits.Uya kuhlala ufuna ukujonga indlela eyila i `struct`, endaweni ye `struct` uqobo.
//! Ngolwazi oluthe kratya malunga nokuba kutheni, bona '[Ukuphumeza uMsinga](#ukumilisela-umsinga)'.
//!
//! [Traits]: #traits
//!
//! Yiyo leyo!Masambe kwimisinga.
//!
//! # Stream
//!
//! Intliziyo nomphefumlo wale modyuli yi [`Stream`] trait.Isiseko se [`Stream`] sijongeka njengoku:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Ngokungafaniyo ne `Iterator`, i `Stream` yenza umahluko phakathi kwendlela ye [`poll_next`] esetyenziswa xa kusenziwa i `Stream`, kunye nendlela ye (to-be-implemented) `next` esetyenziswa xa kusenziwa umlambo.
//!
//! Abasebenzisi be `Stream` kufuneka baqwalasele i `next`, ethi xa ibizwa, ibuyise i future evelisa i `Option<Stream::Item>`.
//!
//! I-future ebuyiswe yi-`next` iya kuvelisa i-`Some(Item)` okoko nje kukho izinto, kwaye xa sele ziphelile, ziya kuvelisa i-`None` ukubonisa ukuba i-iteration igqityiwe.
//! Ukuba silinde into asynchronous ukuyisombulula, i-future iya kulinda de umlambo ukulungele ukuvelisa kwakhona.
//!
//! Imilambo nganye inokukhetha ukuphinda iqhubeke kwakhona, kwaye ke ukubiza i `next` kwakhona kungenza okanye kungaze kuphume i `Some(Item)` kwakhona ngaxa lithile.
//!
//! Inkcazo epheleleyo ye "Stream" ibandakanya inani lezinye iindlela, kodwa ziindlela ezingagqibekanga, ezakhiwe ngaphezulu kwe [`poll_next`], kwaye ke uzifumana simahla.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Ukuphumeza uMsinga
//!
//! Ukwenza umjelo wakho kubandakanya amanyathelo amabini: ukwenza i-`struct` ukubamba imeko yomjelo, kunye nokuphumeza i-[`Stream`] kuloo `struct`.
//!
//! Masenze umlambo ogama lingu-`Counter` obala ukusuka kwi-`1` ukuya kwi-`5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Kuqala, ulwakhiwo:
//!
//! /// Umjelo obala ukusuka kwelinye ukuya kwisihlanu
//! struct Counter {
//!     count: usize,
//! }
//!
//! // sifuna ukuba ukubala kwethu kuqalwe kube kanye, ke masongeze indlela ye new() yokunceda.
//! // Oku akuyomfuneko ngokungqongqo, kodwa kufanelekile.
//! // Qaphela ukuba siqala i-`count` kwi-zero, siza kubona ukuba kutheni kumiliselo lwe-`poll_next()`'s apha ngezantsi.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Emva koko, sisebenzisa i `Stream` kwi `Counter` yethu:
//!
//! impl Stream for Counter {
//!     // siza kubala kunye nosize
//!     type Item = usize;
//!
//!     // poll_next() kuphela kwendlela efunekayo
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Yandisa ukubala kwethu.Kungenxa yoko le nto siqale ngo-zero.
//!         self.count += 1;
//!
//!         // Jonga ukubona ukuba sigqibile ukubala okanye hayi.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Imijelo iyonqena *.Oku kuthetha ukuba ukwenza umjelo nje akuyiyo i-_do_ ngokupheleleyo.Akukho nto yenzekayo de ubize i `next`.
//! Ngamanye amaxesha kungumthombo wesiphithiphithi xa usenza umlambo kuphela kwiziphumo zawo ebezingalindelekanga.
//! Umhlanganisi uya kusilumkisa ngolu hlobo lokuziphatha:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;