//! Izikhongozeli ezinokwabiwa ezinokwabiwa.
//!
//! Ukhuseleko lweenkumbulo ze-Rust lusekwe kulo mthetho: Unikwe into eyi-`T`, kunokwenzeka ukuba ube noku kulandelayo:
//!
//! - Ukuba nezalathiso ezininzi ezingenakuguqulwa (`&T`) kwinto (ekwabizwa ngokuba yi **aliasing**).
//! - Ukuba nesalathiso esinye esinokuguqulwa (`&mut T`) kwinto (ekwabizwa ngokuba yi **mutability**).
//!
//! Oku kunyanzeliswa ngumhlanganisi we-Rust.Nangona kunjalo, kukho iimeko apho lo mthetho awunakho ukuguquguquka ngokwaneleyo.Ngamanye amaxesha kuye kufuneke ukuba ube nezalathiso ezininzi kwinto ethile kodwa uyiguqule.
//!
//! Izikhongozeli ezinokwabiwa ezabiwayo zikhona ukuvumela ukuguquguquka ngendlela elawulwayo, nokuba kukwakho nendawo ekuyo.Zombini i [`Cell<T>`] kunye ne [`RefCell<T>`] zivumela ukwenza oku ngendlela enomsonto omnye.
//! Nangona kunjalo, nokuba i `Cell<T>` okanye i `RefCell<T>` ayikhuselekanga ngentambo (ayizalisekisi i [`Sync`]).
//! Ukuba ufuna ukwenza indawo yokutshintsha kunye nokutshintsha phakathi kwemisonto emininzi kunokwenzeka ukuba usebenzise i [`Mutex<T>`], [`RwLock<T>`] okanye [`atomic`] iintlobo.
//!
//! Ixabiso le-`Cell<T>` kunye ne-`RefCell<T>` iintlobo zinokutshintshwa kwizalathiso ekwabelwana ngazo (okt
//! Uhlobo oluqhelekileyo lwe `&T`), ngelixa uninzi lwe Rust iintlobo zinokutshintshwa kuphela kwizalathiso ezizodwa (`&mut T`).
//! Sithi i `Cell<T>` kunye ne `RefCell<T>` zibonelela 'ngokuguquguquka kwangaphakathi', ngokwahlukileyo kwiindidi eziqhelekileyo ze Rust ezibonisa 'ilifa eliguqukayo'.
//!
//! Iindidi zeseli ziza kwiincasa ezimbini: `Cell<T>` kunye ne `RefCell<T>`.I `Cell<T>` inyanzelisa ukuguquguquka okungaphakathi ngokuhambisa amaxabiso ngaphakathi nangaphandle kwe `Cell<T>`.
//! Sebenzisa izingqinisiso endaweni yamaxabiso, umntu kufuneka asebenzise uhlobo lwe `RefCell<T>`, ukufumana isitshixo sokubhala ngaphambi kokutshintsha.I `Cell<T>` ibonelela ngeendlela zokubuyisa kunye nokutshintsha ixabiso langoku langaphakathi:
//!
//!  - Kwiindidi ezisebenzisa i [`Copy`], indlela ye [`get`](Cell::get) ifumana ixabiso langaphakathi langoku.
//!  - Kwiindidi ezisebenzisa i [`Default`], indlela ye [`take`](Cell::take) ithathe indawo yexabiso langaphakathi langoku nge [`Default::default()`] kwaye ibuyisele ixabiso elitshintshiweyo.
//!  - Kuzo zonke iintlobo, indlela ye [`replace`](Cell::replace) ithatha indawo yexabiso langaphakathi langoku kwaye ibuyisele ixabiso elitshintshiweyo kwaye indlela ye [`into_inner`](Cell::into_inner) isebenzisa i `Cell<T>` kwaye ibuyisele ixabiso langaphakathi.
//!  Ukongeza, indlela ye [`set`](Cell::set) ithathe indawo yexabiso elingaphakathi, ushiye ixabiso elifakelweyo.
//!
//! `RefCell<T>` isebenzisa ixesha lobomi be-Rust ukwenza 'ukuboleka okunamandla', inkqubo apho umntu anokubanga ukufikelela okwethutyana, okukhethekileyo, nokufikelela kwixabiso langaphakathi.
//! Uboleka i-RefCell<T>Ziyalandelwa 'ngexesha lokubaleka', ngokungafaniyo ne Rust zeentlobo zesalathiso sendalo ezilandelwa ngokupheleleyo ngokwezibalo, ngexesha lokudityaniswa.
//! Ngenxa yokuba i-`RefCell<T>` ebolekayo inamandla kunokwenzeka ukuzama ukuboleka ixabiso esele libolekwe ngokuguqukayo;xa oku kusenzeka kubangela umsonto panic.
//!
//! # Nini ukukhetha ukutshintsha ngaphakathi
//!
//! Ukuguquka okuqheleke ngakumbi njengelifa, apho umntu kufuneka abe nokufikelela okungafaniyo ekuguqulweni kwexabiso, yenye yezinto eziphambili kulwimi ezenza i-Rust iqiqise ngokuqatha ngesikhombisi, ukuthintela ukungqubana kweempazamo.
//! Ngenxa yoko, ukuthanda ukutshintsha njengelifa kuyakhethwa, kwaye ukungaguquguquki ngaphakathi yinto eyokugqibela.
//! Kuba iintlobo zeeseli zenza ukuba kuguquke indawo apho bekungavunyelwanga khona, kukho iimeko apho ukuguquguquka kwangaphakathi kunokuba kufanelekile, okanye kufuneka * kusetyenziswe, umz.
//!
//! * Kwazisa ukuguquguquka kwe 'inside' yento engaguqukiyo
//! * Iinkcukacha zokuphunyezwa kweendlela ezinokungaguquki.
//! * Ukuphunyezwa kokuphunyezwa kwe [`Clone`].
//!
//! ## Kwazisa ukuguquguquka kwe 'inside' yento engaguqukiyo
//!
//! Uninzi lweentlobo zesikhombisi ekwabelwana ngazo, kubandakanya i [`Rc<T>`] kunye ne [`Arc<T>`], zibonelela ngezikhongozeli ezinokubumbana kwaye zabelwane phakathi kwamaqela amaninzi.
//! Ngenxa yokuba amaxabiso aqulathiweyo anokuphindaphindeka-ngokungahlulwahlulwa, anokubolekwa kuphela nge `&`, hayi i `&mut`.
//! Ngaphandle kweeseli bekungayi kuba nakho ukuguqula idatha ngaphakathi kwezi zikhombisi zi-smart kwaphela.
//!
//! Kuqheleke kakhulu ukubeka i `RefCell<T>` ngaphakathi kweentlobo zesikhombisi ekwabelwana ngazo ukuphinda uvelise ukuguquka:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Yenza ibhloko entsha ukunciphisa umda wokuboleka okunamandla
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Qaphela ukuba ukuba besingavumanga ukubolekwa kwangaphambili kwe-cache kuphume kwinqanaba emva koko ukuboleka okulandelayo kuya kubangela umsonto onamandla panic.
//!     //
//!     // Le yeyona ngozi iphambili yokusebenzisa i `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Qaphela ukuba lo mzekelo usebenzisa i-`Rc<T>` hayi i-`Arc<T>`.Refell<T>ziimeko ezinomsonto omnye.Cinga ukusebenzisa i [`RwLock<T>`] okanye i [`Mutex<T>`] ukuba ufuna ukwahluka okwabelwanayo kwimeko enemisonto emininzi.
//!
//! ## Iinkcukacha zokuphunyezwa kweendlela ezinokungaguquki
//!
//! Ngamaxesha athile kunokuba yinto enqwenelekayo ukungabhenisi kwi-API ukuba kukho utshintsho olwenzekayo kwi "under the hood".
//! Oku kunokuba ngenxa yokuba ngokusebenzayo ukusebenza kungaguquki, kodwa umzekelo, i-caching inyanzela ukwenziwa ukuba kuguqulwe;okanye ngenxa yokuba kuya kufuneka usebenzise ukuguquka ukuze usebenzise i-trait indlela eyayichazwe kwasekuqaleni ukuba ithathe i `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Ubalo oluninzi lubiza apha
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Ukuphunyezwa kokuphunyezwa kwe `Clone`
//!
//! Le yimeko ekhethekileyo, kodwa eqhelekileyo, yexesha elidlulileyo: ukufihla ukuguquguquka kwemisebenzi ebonakala ngathi ayinakuguquka.
//! Indlela ye [`clone`](Clone::clone) kulindeleke ukuba ingatshintshi ixabiso lomthombo, kwaye kubhengezwe ukuthatha i `&self`, hayi i `&mut self`.
//! Ke ngoko, naluphi na utshintsho olwenzeka kwindlela ye `clone` kufuneka lusebenzise iintlobo zeeseli.
//! Umzekelo, i [`Rc<T>`] igcina ukubalwa kwayo ngaphakathi kwe `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Indawo yememori enokutshintsha.
///
/// # Examples
///
/// Kule mzekelo, uyabona ukuba i `Cell<T>` yenza utshintsho ngaphakathi kolwakhiwo olungaguqukiyo.
/// Ngamanye amagama, yenza i "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // IMPazamo: I `my_struct` ayinakuchaphazeleka
/// // my_struct.regular_field =ixabiso_elitsha;
///
/// // IMISEBENZI: nangona i `my_struct` ingaguquki, i `special_field` yi `Cell`,
/// // enokuhlala itshintshwa
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Bona i [module-level documentation](self) ngaphezulu.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Yenza i `Cell<T>`, enexabiso le `Default` leT.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Yenza i `Cell` entsha enexabiso elinikiweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Icwangcisa ixabiso eliqulathiweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ukutshintsha amaxabiso eeSeli ezimbini.
    /// Umahluko kwi `std::mem::swap` kukuba lo msebenzi awufuni x01X ireferensi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // UKHUSELEKO: Oku kunokuba semngciphekweni xa ubizwa kwimisonto eyahlukileyo, kodwa i `Cell`
        // Ngu-`!Sync` ke oku ngekhe kwenzeke.
        // Oku ngekhe kungasebenzi nasiphi na isikhombisi kuba i `Cell` iqinisekisa ukuba ayikho enye into eya kwalatha kwezi `Cells.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Faka endaweni yexabiso eliqulathiweyo nge `val`, kwaye ubuyise ixabiso elidala eliqulathiweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // UKHUSELEKO: Oku kunokubangela ukhuphiswano lweedatha ukuba lubizwe ngentambo eyahlukileyo,
        // kodwa i `Cell` ngu `!Sync` ke oku ngekhe kwenzeke.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Lishenxise ixabiso.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Ibuyisa ikopi yexabiso eliqulathiweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // UKHUSELEKO: Oku kunokubangela ukhuphiswano lweedatha ukuba lubizwe ngentambo eyahlukileyo,
        // kodwa i `Cell` ngu `!Sync` ke oku ngekhe kwenzeke.
        unsafe { *self.value.get() }
    }

    /// Ukuhlaziya ixabiso eliqulathiweyo kusetyenziswa umsebenzi kunye nokubuyisela ixabiso elitsha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Buyisela isalathi esiluhlaza kwidatha engaphantsi kweseli.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ibuyisa ireferensi enokuguquguquka kwidatha engaphantsi.
    ///
    /// Le fowuni iboleka i `Cell` ngokuguqukayo (ngexesha lokudityaniswa) eliqinisekisa ukuba kuphela kwesalathiso.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Ibuyisa i `&Cell<T>` ukusuka kwi `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // UKHUSELEKO: `&mut` iqinisekisa ukufikelela okhethekileyo.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Ithatha ixabiso leseli, ishiya i `Default::default()` endaweni yayo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Ibuyisa i `&[Cell<T>]` ukusuka kwi `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // UKHUSELEKO: I-`Cell<T>` inesimo sememori esifanayo ne `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Indawo yememori enokuguquguquka enemithetho ebolekwe ngamandla
///
/// Bona i [module-level documentation](self) ngaphezulu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Impazamo ibuyiswe yi [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Impazamo ibuyiswe yi [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Amaxabiso afanelekileyo abonisa inani le-`Ref` esebenzayo.Ixabiso elibi libonisa inani le-`RefMut` esebenzayo.
// I-RefMut`s ezininzi zinokusebenza kuphela ngexesha ukuba zibhekisa kwizinto ezahlukileyo, ezingafakwanga izinto ze-`RefCell` (umzekelo, iindidi ezahlukeneyo zesilayidi).
//
// `Ref` Kwaye i `RefMut` ngamagama amabini ngobukhulu, kwaye ke ngekhe kubekhona eyoneleyo i-Ref`s okanye i-RefMut`s ekhoyo ukugcwala kwesiqingatha sohlu lwe-`usize`.
// Ke, i `BorrowFlag` ngekhe iphinde iphuphume okanye iphuphume.
// Nangona kunjalo, esi ayisosiqinisekiso, njengoko inkqubo ye-pathological inokuphinda-phinda emva koko i-mem::forget `Ref`s okanye`RefMut`s.
// Yiyo loo nto yonke ikhowudi kufuneka ikhangele ngokucacileyo ukuphuphuma kunye nokuphuphuma kwayo ukuthintela ukungakhuselekanga, okanye ubuncinci uziphathe ngokuchanekileyo kwimeko yokuphuphuma okanye yokugcwala kwenzeka (umzekelo, bona i BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Yenza i `RefCell` entsha ene-`value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Isebenzisa i `RefCell`, ibuyisa ixabiso elisongelweyo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Kuba lo msebenzi uthatha i `self` (i `RefCell`) ngexabiso, umhlanganisi uyaqinisekisa ukuba ayibolekwanga ngoku.
        //
        self.value.into_inner()
    }

    /// Faka endaweni yexabiso elisongelweyo elitsha, ubuyise ixabiso elidala, ngaphandle kokukhetha enye.
    ///
    ///
    /// Lo msebenzi uhambelana ne [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics ukuba ixabiso libolekwe okwangoku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Faka endaweni yexabiso elisongelweyo elitsha libaliwe ukusuka kwi `f`, ukubuyisa ixabiso elidala, ngaphandle kokuyekisa enye.
    ///
    ///
    /// # Panics
    ///
    /// Panics ukuba ixabiso libolekwe okwangoku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ukutshintsha ixabiso elisongelweyo le `self` ngexabiso elisongelweyo le `other`, ngaphandle kokuyekisa enye.
    ///
    ///
    /// Lo msebenzi uhambelana ne [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// I-Panics ukuba ixabiso kwi `RefCell` ngoku ibolekwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Ngaphandle kokuboleka ixabiso elisongelweyo.
    ///
    /// Okubolekayo kuhlala kude kubuyiswe i `Ref`.
    /// Iimali-mboleko ezininzi ezingaguqukiyo zinokuthathwa ngaxeshanye.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba ixabiso okwangoku liboleke ngokuchanekileyo.
    /// Umahluko ongoyikisiyo, sebenzisa i [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Umzekelo we-panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Uboleka ngokungazenzisiyo ixabiso elisongelweyo, ubuyise impazamo ukuba ixabiso libolekwe ngoku.
    ///
    ///
    /// Okubolekayo kuhlala kude kubuyiswe i `Ref`.
    /// Iimali-mboleko ezininzi ezingaguqukiyo zinokuthathwa ngaxeshanye.
    ///
    /// Olu ngumahluko ongoyikiyo we [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // UKHUSELEKO: `BorrowRef` iqinisekisa ukuba kukho ukufikelela okungaguqukiyo kuphela
            // kwixabiso ngelixa ubolekwe.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Unokuboleka ixabiso elisongelweyo.
    ///
    /// Okubolekayo kuhlala kude kubuyiswe i `RefMut` okanye zonke iiRefMut`s ezivela kuyo.
    ///
    /// Ixabiso alinakuboleka ngelixa le mboleko isebenza.
    ///
    /// # Panics
    ///
    /// Panics ukuba ixabiso libolekwe okwangoku.
    /// Umahluko ongoyikisiyo, sebenzisa i [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Umzekelo we-panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Unokuboleka ixabiso elisongelweyo, ubuyise impazamo ukuba ixabiso ngoku libolekiwe.
    ///
    ///
    /// Okubolekayo kuhlala kude kubuyiswe i `RefMut` okanye zonke iiRefMut`s ezivela kuyo.
    /// Ixabiso alinakuboleka ngelixa le mboleko isebenza.
    ///
    /// Olu ngumahluko ongoyikiyo we [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // UKHUSELEKO: `BorrowRef` iqinisekisa ukufikelela okhethekileyo.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Buyisela isalathi esiluhlaza kwidatha engaphantsi kweseli.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ibuyisa ireferensi enokuguquguquka kwidatha engaphantsi.
    ///
    /// Lo mnxeba uboleka i `RefCell` ngokuguqukayo (ngexesha lokudityaniswa) ke akukho mfuneko yokutshekishwa okuguqukayo.
    ///
    /// Nangona kunjalo ulumke: le ndlela ilindele ukuba i `self` iguquke, nto leyo ingekho njalo xa usebenzisa i `RefCell`.
    ///
    /// Jonga indlela ye [`borrow_mut`] endaweni yokuba i `self` ayinakuguquka.
    ///
    /// Kwakhona, nceda uqaphele ukuba le ndlela yenzelwe iimeko ezizodwa kwaye ihlala ingeyiyo le uyifunayo.
    /// Kwimeko yokuthandabuza, sebenzisa i [`borrow_mut`] endaweni yoko.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Rhoxisa umphumo woonogada abavuzayo kwimeko yokuboleka ye `RefCell`.
    ///
    /// Le fowuni iyafana ne-[`get_mut`] kodwa ikhetheke ngakumbi.
    /// Iboleka i `RefCell` ngokuguqukayo ukuze kuqinisekiswe ukuba akukho mboleko ikhoyo kwaye iphinde icwangcise imeko yokulandela umkhondo ebolekwe ngurhulumente.
    /// Oku kufanelekile ukuba i `Ref` okanye i `RefMut` ibolekiwe.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Uboleka ngokungazenzisiyo ixabiso elisongelweyo, ubuyise impazamo ukuba ixabiso libolekwe ngoku.
    ///
    /// # Safety
    ///
    /// Ngokungafaniyo ne `RefCell::borrow`, le ndlela ayikhuselekanga kuba ayibuyisi i `Ref`, yiyo loo nto ishiya iflegi yokuboleka ingakhange ifunyanwe.
    /// Ukuboleka ngokufanelekileyo i `RefCell` ngelixa ireferensi ebuyiswe ngale ndlela iphila kukuziphatha okungachazwanga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // UKHUSELEKO: Sijonga ukuba akukho mntu ubhalayo ngoku, kodwa kunjalo
            // uxanduva lomntu ofowunayo lokuqinisekisa ukuba akukho mntu ubhalayo de isalathiso esibuyisiweyo singasasebenzi.
            // Kwakhona, i-`self.value.get()` ibhekisa kwixabiso le-`self` kwaye ke iqinisekisiwe ukuba iyasebenza ebomini be-`self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Ithatha ixabiso elisongelweyo, ishiya i `Default::default()` endaweni yayo.
    ///
    /// # Panics
    ///
    /// Panics ukuba ixabiso libolekwe okwangoku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// I-Panics ukuba ixabiso okwangoku liboleke ngokuchanekileyo.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Yenza i `RefCell<T>`, enexabiso le `Default` leT.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// I-Panics ukuba ixabiso kwi `RefCell` ngoku ibolekwe.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// I-Panics ukuba ixabiso kwi `RefCell` ngoku ibolekwe.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// I-Panics ukuba ixabiso kwi `RefCell` ngoku ibolekwe.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// I-Panics ukuba ixabiso kwi `RefCell` ngoku ibolekwe.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// I-Panics ukuba ixabiso kwi `RefCell` ngoku ibolekwe.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// I-Panics ukuba ixabiso kwi `RefCell` ngoku ibolekwe.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// I-Panics ukuba ixabiso kwi `RefCell` ngoku ibolekwe.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Ukonyusa imali mboleko kunokubangela ukungafundi (<=0) kwezi meko:
            // 1. Kwakungu-<0, Oko kukuthi kubhalwa imali ebolekiweyo, ke ngekhe sivumele ukufundwa kubolekwe ngenxa yemithetho yokujonga isiseko se Rust
            // 2.
            // Yayiyi-isize::MAX (ubuninzi bokufunda uboleka) kwaye yaphuphuma yaya kwi-isize::MIN (ubuninzi bokubhalwa kwemali ebolekiweyo) ke ngekhe sivumele eyongezelelweyo ifundwe ngokuboleka kuba i-isize ayinakubonisa ukubolekwa okuninzi okufundwayo (oku kunokwenzeka kuphela ukuba U-mem::forget ungaphezulu kwesixa esincinci esiqhelekileyo se-`Ref`s, engalunganga ukwenza)
            //
            //
            //
            //
            None
        } else {
            // Ukonyusa imali mboleko kunokubangela ixabiso lokufunda (> 0) kwezi meko:
            // 1. Ibingu=0, okt ibingabolekwanga, kwaye sithatha okokuqala ukubolekwa okufundwayo
            // 2. Kwakungu> 0 kunye <isize::MAX, okt
            // bekufundwa ukubolekwa, kwaye isize inkulu ngokwaneleyo ukuba imele ukuba enye ifundwe iboleke
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Kuba le Ref ikhona, siyazi ukuba iflegi ebolekayo kukuboleka okufundwayo.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Thintela ikhawuntari yokuboleka ekuphuphumeni iye ekubhaleni ngokubhalwa.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Isonga isalathiso esibolekiweyo kwixabiso kwibhokisi ye `RefCell`.
/// Uhlobo olusongelayo lwexabiso elibolekiweyo kwi `RefCell<T>`.
///
/// Bona i [module-level documentation](self) ngaphezulu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Ikopa i `Ref`.
    ///
    /// I `RefCell` sele ibolekwe ngokungaguquguqukiyo, ke oku akunakusilela.
    ///
    /// Lo ngumsebenzi onxulumene noko ofuna ukusetyenziswa njenge-`Ref::clone(...)`.
    /// Ukuphunyezwa kwe `Clone` okanye indlela inokuphazamisa ukusetyenziswa ngokubanzi kwe `r.borrow().clone()` ukwenza umxholo we `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Yenza i `Ref` entsha yecandelo ledatha ebolekiweyo.
    ///
    /// I `RefCell` sele ibolekwe ngokungaguquguqukiyo, ke oku akunakusilela.
    ///
    /// Lo ngumsebenzi onxulumene noko ofuna ukusetyenziswa njenge-`Ref::map(...)`.
    /// Indlela enokuthi iphazamisane neendlela zegama elifanayo kwimixholo ye `RefCell` esetyenziswe kwi `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Yenza i `Ref` entsha yecandelo lokhetho lwedatha ebolekiweyo.
    /// Unogada wokuqala ubuyiswa njenge `Err(..)` ukuba ukuvalwa kubuyisa i `None`.
    ///
    /// I `RefCell` sele ibolekwe ngokungaguquguqukiyo, ke oku akunakusilela.
    ///
    /// Lo ngumsebenzi onxulumene noko ofuna ukusetyenziswa njenge-`Ref::filter_map(...)`.
    /// Indlela enokuthi iphazamisane neendlela zegama elifanayo kwimixholo ye `RefCell` esetyenziswe kwi `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Ukwahlula i `Ref` kwii-Ref ezininzi kwizinto ezahlukeneyo zedatha ebolekiweyo.
    ///
    /// I `RefCell` sele ibolekwe ngokungaguquguqukiyo, ke oku akunakusilela.
    ///
    /// Lo ngumsebenzi onxulumene noko ofuna ukusetyenziswa njenge-`Ref::map_split(...)`.
    /// Indlela enokuthi iphazamisane neendlela zegama elifanayo kwimixholo ye `RefCell` esetyenziswe kwi `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Guqula ireferensi yedatha engaphantsi.
    ///
    /// Isiseko se `RefCell` asinakuze sibolekwe kwakhona kwaye iya kuhlala ibonakala ngathi ibolekwe ngokungaguqukiyo.
    ///
    /// Ayilombono ulungileyo ukuvuza ngaphezulu kwenani lezalathiso.
    /// I `RefCell` inokubolekiswa ngokungaguquguqukiyo kwakhona ukuba kuphela inani elincinci lokuvuza lenzekile lilonke.
    ///
    /// Lo ngumsebenzi onxulumene noko ofuna ukusetyenziswa njenge-`Ref::leak(...)`.
    /// Indlela enokuthi iphazamisane neendlela zegama elifanayo kwimixholo ye `RefCell` esetyenziswe kwi `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Ngokulibala le Ref siqinisekisa ukuba ikhawuntari yokuboleka kwi-RefCell ayinakubuyela kwi-UNUSED ngaphakathi kobomi be `'b`.
        // Ukusetha kwakhona imeko yokulandela umkhondo wesalathiso kuya kufuna ireferensi eyodwa kwiRefCell ebolekiweyo.
        // Akukho zingqinisiso zingaguqukayo ezinokwenziwa kwiseli yoqobo.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Yenza i `RefMut` entsha yecandelo ledatha ebolekiweyo, umzekelo, umahluko we-enum.
    ///
    /// I `RefCell` sele ibolekwe ngokufanelekileyo, ke oku akunakusilela.
    ///
    /// Lo ngumsebenzi onxulumene noko ofuna ukusetyenziswa njenge-`RefMut::map(...)`.
    /// Indlela enokuthi iphazamisane neendlela zegama elifanayo kwimixholo ye `RefCell` esetyenziswe kwi `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): lungisa ukujonga-ukujonga
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Yenza i `RefMut` entsha yecandelo lokhetho lwedatha ebolekiweyo.
    /// Unogada wokuqala ubuyiswa njenge `Err(..)` ukuba ukuvalwa kubuyisa i `None`.
    ///
    /// I `RefCell` sele ibolekwe ngokufanelekileyo, ke oku akunakusilela.
    ///
    /// Lo ngumsebenzi onxulumene noko ofuna ukusetyenziswa njenge-`RefMut::filter_map(...)`.
    /// Indlela enokuthi iphazamisane neendlela zegama elifanayo kwimixholo ye `RefCell` esetyenziswe kwi `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): lungisa ukujonga-ukujonga
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // UKHUSELEKO: umsebenzi ubambe kwisalathiso esikhethekileyo ixesha
        // yomnxeba wayo nge `orig`, kwaye isikhombisi sichazwe kuphela ngaphakathi kwifowuni yomsebenzi esingaze sivumele isalathiso esisodwa ukuba sibaleke.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // UKHUSELEKO: ngokufanayo ngasentla.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Ukwahlula i `RefMut` kwii-RefMut`s ezininzi zamacandelo edatha ebolekiweyo.
    ///
    /// Isiseko se `RefCell` siyakuhlala siboleke ngokugqibeleleyo de bobabini babuyile`RefMut`s baphume esikalini.
    ///
    /// I `RefCell` sele ibolekwe ngokufanelekileyo, ke oku akunakusilela.
    ///
    /// Lo ngumsebenzi onxulumene noko ofuna ukusetyenziswa njenge-`RefMut::map_split(...)`.
    /// Indlela enokuthi iphazamisane neendlela zegama elifanayo kwimixholo ye `RefCell` esetyenziswe kwi `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Guqula ireferensi eguqukayo kwidatha engaphantsi.
    ///
    /// Isiseko se `RefCell` asinakho ukubolekwa kwakhona kwaye siyakuhlala sivela sele sibolekwe ngokuguqukayo, senza ireferensi ebuyisiweyo ibe yeyangaphakathi kuphela.
    ///
    ///
    /// Lo ngumsebenzi onxulumene noko ofuna ukusetyenziswa njenge-`RefMut::leak(...)`.
    /// Indlela enokuthi iphazamisane neendlela zegama elifanayo kwimixholo ye `RefCell` esetyenziswe kwi `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ngokulibala le BorrowRefMut siyaqinisekisa ukuba ikhawuntari yokuboleka kwi-RefCell ayinakubuyela kwi-UNUSED ngaphakathi kwe `'b` yobomi.
        // Ukusetha kwakhona imeko yokulandela umkhondo wesalathiso kuya kufuna ireferensi eyodwa kwiRefCell ebolekiweyo.
        // Akukho ezinye izingqinisiso ezinokwenziwa kwiseli yoqobo ngaphakathi kwelo xesha lobomi, zisenza ukuba ibolekwe ngoku ibe sisalathiso sobomi obuseleyo.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Ngokungafaniyo ne BorrowRefMut::clone, entsha ibizwa ukuba yenze eyokuqala
        // Isalathiso esinokutshintshwa, kwaye ke kungangokunje akukho zingqinisiso ezikhoyo.
        // Ke ngoko, ngelixa i-clone inyusa ukubalwa okungaguqukiyo, apha ngokucacileyo sivumela kuphela ukusuka UNUSED kuye UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Iintsimbi ze `BorrowRefMut`.
    //
    // Oku kusebenza kuphela ukuba i-`BorrowRefMut` nganye isetyenziselwe ukujonga isalathiso esinokutshintshwa kuluhlu olwahlukileyo, olungafakwanga into yokuqala.
    //
    // Oku akukho kwi-Clone impl ukuze ikhowudi ingabizi oku ngokungagungqiyo.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Thintela ikhawuntari yokuboleka ekuphuphumeni.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Uhlobo olusongelayo lwexabiso elibolekiweyo kwi `RefCell<T>`.
///
/// Bona i [module-level documentation](self) ngaphezulu.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Isiseko sokuqala sokungaguquguquki ngaphakathi kwi-Rust.
///
/// Ukuba unesalathiso `&T`, ngesiqhelo kwi Rust umhlanganisi wenza ulwakhiwo ngokusekwe kulwazi lokuba i `&T` yalatha kwidatha engaguqukiyo.Ukutshintsha loo datha, umzekelo ngokusebenzisa i-alias okanye ngokuhambisa i-`&T` kwi-`&mut T`, kuthathwa njengokuziphatha okungachazwanga.
/// `UnsafeCell<T>` ukuphuma kwesiqinisekiso sokungafikeleli kwe `&T`: ireferensi ekwabelwana ngayo i `&UnsafeCell<T>` inokwalatha kwidatha eguqulweyo.Oku kubizwa ngokuba yi "interior mutability".
///
/// Zonke ezinye iintlobo ezivumela ukutshintsha ngaphakathi, ezinje nge `Cell<T>` kunye ne `RefCell<T>`, zisebenzisa ngaphakathi i `UnsafeCell` ukusonga idatha yazo.
///
/// Qaphela ukuba kuphela sisiqinisekiso sokungafikeleli kwizalathiso ekwabelwana ngazo ezichaphazeleka yi `UnsafeCell`.Isiqinisekiso esikhethekileyo sokungqinisisa okunokuchaphazeleka asichaphazeleki.Akukho *ndlela* esemthethweni yokufumana i-aliasing `&mut`, nkqu ne `UnsafeCell<T>`.
///
/// I-`UnsafeCell` API uqobo ngobuchwephesha ilula kakhulu: i [`.get()`] ikunika isikhombisi eluhlaza `*mut T` kwimixholo yayo.Ukuya kuthi ga kwi-_you_ njengomyili we-abstraction yokusebenzisa eso sikhombisi siluhlaza ngokuchanekileyo.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Imigaqo echanekileyo ye-Rust yokuchwetheza ngokuthe ngcembe iyahamba, kodwa amanqaku aphambili awanangxabano:
///
/// - Ukuba wenza ireferensi ekhuselekileyo enobomi be `'a` (nokuba yi-`&T` okanye i-`&mut T` ireferensi) efikeleleka ngekhowudi ekhuselekileyo (umzekelo, kuba uyibuyisile), awunakufikelela kwidatha nangayiphi na indlela ephikisana nesalathiso sentsalela ye `'a`.
/// Umzekelo, oku kuthetha ukuba ukuba uthatha i `*mut T` kwi `UnsafeCell<T>` kwaye uyiphose kwi `&T`, idatha ekwi `T` kufuneka ihlale ingaguquki (imodulo nayiphi na idatha ye `UnsafeCell` efumaneka ngaphakathi kwe `T`, kunjalo) kude kuphele ixesha lokuphila.
/// Kwangokunjalo, ukuba wenza ireferensi ye `&mut T` ekhutshwe kwikhowudi ekhuselekileyo, emva koko akufuneki ufikelele kwidatha ngaphakathi kwe `UnsafeCell` ide iphele ireferensi.
///
/// - Ngawo onke amaxesha, kuya kufuneka uphephe ukhuphiswano lweedatha.Ukuba imisonto emininzi inokufikelela kwi-`UnsafeCell` efanayo, ke nakuphi na ukubhalwa kufuneka kwenzeke ngokwenzeka-phambi kokunxibelelana nolunye ufikelelo (okanye sebenzisa iiathom).
///
/// Ukuncedisa kuyilo olufanelekileyo, ezi meko zilandelayo zibhengezwe ngokucacileyo ukuba zisemthethweni kwikhowudi enomsonto omnye:
///
/// 1. Isalathiso se `&T` sinokukhutshelwa kwikhowudi ekhuselekileyo kwaye apho inokubakho ngokubakho nezinye izingqinisiso ze `&T`, kodwa hayi nge `&mut T`
///
/// 2. Isalathiso se `&mut T` sinokukhutshelwa kwikhowudi ekhuselekileyo ngaphandle kokuba enye i `&mut T` okanye i `&T` ayibikho nayo.I `&mut T` kufuneka ihlale yahlukile.
///
/// Qaphela ukuba ngelixa uguqula imixholo ye-`&UnsafeCell<T>` (nokuba ezinye izingqinisiso ze-`&UnsafeCell<T>` azikho kwiseli) zilungile (ngaphandle kokuba unyanzelisa abahlaseli bangentla ngenye indlela), isengachazekanga isimilo sokuba nezivumelwano ezininzi ze `&mut UnsafeCell<T>`.
/// Oko kukuthi, i `UnsafeCell` sisongelo esenzelwe ukuba sinxibelelane ngokukhethekileyo ne _shared_ accesses (_i.e._, ngokusebenzisa isalathiso se `&UnsafeCell<_>`);akukho bugqi nantoni na xa ujongene ne-_exclusive_ accesses (_e.g._, ngokusebenzisa i-`&mut UnsafeCell<_>`): nokuba iseli okanye ixabiso elisongelweyo alinakubekwa ecaleni ngalo lonke ixesha lokubolekwa kwe `&mut`.
///
/// Oku kuboniswa ngumngenisi we [`.get_mut()`], eyi _safe_ getter evelisa i `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Nanku umzekelo obonisa indlela yokutshintsha ngokuvakalayo imixholo ye `UnsafeCell<_>` nangona kukho izingqinisiso ezininzi ezibeka iseli esichengeni:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Fumana izikhombisi ezininzi/ezabelwana ngazo kwi `x` efanayo.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // UKHUSELEKO: ngaphakathi kwesi sithuba akukho ezinye izingqinisiso kwimixholo ye-x,
///     // ke eyethu yahlukile ngokukuko.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- mboleka-+
///     *p1_exclusive += 27; // |
/// } // <---------- ayinakudlula kweli nqanaba -------------------+
///
/// unsafe {
///     // UKHUSELEKO: ngaphakathi kwesi sithuba akukho mntu ulindele ukuba nokufikelela okukhethekileyo kwimixholo ye-x,
///     // ke sinokuba nofikelelo oluninzi ekwabelwana ngalo ngaxeshanye.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Lo mzekelo ulandelayo ubonakalisa inyani yokuba ukufikelela okukodwa kwi-`UnsafeCell<T>` kuthetha ukufikelela okukodwa kwi-`T` yayo:
///
/// ```rust
/// #![forbid(unsafe_code)] // ngokufikelela okukhethekileyo,
///                         // `UnsafeCell` sisisongelo esivelayo esingavalwanga, ke akukho sidingo se `unsafe` apha.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Fumana ireferensi yexesha elihlanganisiweyo elijongwa kwi `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Ngereferensi ekhethekileyo, sinokuguqula imixholo simahla.
/// *p_unique.get_mut() = 0;
/// // Okanye, ngokufanayo:
/// x = UnsafeCell::new(0);
///
/// // Xa singabanini bexabiso, sinokukhupha imixholo simahla.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Yakha imeko entsha ye `UnsafeCell` eya kusonga ixabiso elichaziweyo.
    ///
    ///
    /// Lonke ufikelelo kwixabiso elingaphakathi ngeendlela liyi-`unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Lishenxise ixabiso.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Ifumana isikhombisi esinokutshintsha kwixabiso elisongelweyo.
    ///
    /// Oku kunokuphoswa kwisikhombisi salo naluphi na uhlobo.
    /// Qinisekisa ukuba ukufikelela kuyingqayizivele (akukho zikhombisi zisebenzayo, ezinokutshintsha okanye ezingasebenziyo) xa uphosa kwi `&mut T`, kwaye uqinisekise ukuba akukho lutshintsho okanye izinto eziguqukayo eziqhubekayo xa usenza kwi `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Singasiphosa isikhombisi ukusuka kwi `UnsafeCell<T>` ukuya kwi `T` ngenxa ye #[repr(transparent)].
        // Oku kuxhaphaza ubume obukhethekileyo be-libstd, akukho siqinisekiso sekhowudi yomsebenzisi sokuba oku kuyakusebenza kwiinguqulelo ze-future zomqokeleli!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Ibuyisa ireferensi enokuguquguquka kwidatha engaphantsi.
    ///
    /// Le fowuni iboleka i `UnsafeCell` ngokuguqukayo (ngexesha lokudityaniswa) eliqinisekisa ukuba kuphela kwesalathiso.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Ifumana isikhombisi esinokutshintsha kwixabiso elisongelweyo.
    /// Umahluko ku-[`get`] kukuba lo msebenzi wamkela isikhombisi esiluhlaza, esiluncedo ukunqanda ukwenziwa kwesalathiso sethutyana.
    ///
    /// Iziphumo zinokuphoswa kwisikhombisi salo naluphi na uhlobo.
    /// Qinisekisa ukuba ukufikelela kuyingqayizivele (akukho zikhombisi zisebenzayo, ezinokutshintsha okanye ezingasebenziyo) xa uphosa kwi `&mut T`, kwaye uqinisekise ukuba akukho lutshintsho okanye izinto eziguqukayo eziqhubekayo xa usenza i `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Ukuqala ngokuthe ngcembe kwe `UnsafeCell` kufuna i `raw_get`, njengoko ukubiza i `get` kungafuna ukudala ireferensi kwidatha engachazwanga:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Singasiphosa isikhombisi ukusuka kwi `UnsafeCell<T>` ukuya kwi `T` ngenxa ye #[repr(transparent)].
        // Oku kuxhaphaza ubume obukhethekileyo be-libstd, akukho siqinisekiso sekhowudi yomsebenzisi sokuba oku kuyakusebenza kwiinguqulelo ze-future zomqokeleli!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Yenza i `UnsafeCell`, enexabiso le `Default` leT.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}