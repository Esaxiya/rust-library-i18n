//! Umsebenzi woku-odola kunye nokuthelekisa.
//!
//! Le modyuli inezixhobo ezahlukeneyo zoku-odola kunye nokuthelekisa amaxabiso.Isishwankathelo:
//!
//! * [`Eq`] kunye ne [`PartialEq`] zi traits ezikuvumela ukuba uchaze ukulingana okupheleleyo kunye nokulinganayo phakathi kwamaxabiso, ngokulandelelana.
//! Ukuphumeza kwabo ukulayisha ngaphezulu i `==` kunye ne `!=` abaqhubi.
//! * [`Ord`] kunye ne-[`PartialOrd`] zii-traits ezikuvumela ukuba uchaze iodolo iyonke kunye nenxalenye phakathi kwamaxabiso, ngokulandelelana.
//!
//! Ukuphumeza kwabo ukulayisha ngaphezulu i `<`, `<=`, `>`, kunye nabaqhubi be `>=`.
//! * [`Ordering`] i-enum ibuyiswe yimisebenzi ephambili ye-[`Ord`] kunye ne-[`PartialOrd`], kwaye ichaza uku-odolwa.
//! * [`Reverse`] ulwakhiwo olukuvumela ukuba uguqule ngokulula iodolo.
//! * [`max`] kunye ne [`min`] yimisebenzi eyakha i [`Ord`] kwaye ikuvumela ukuba ufumane ubuninzi okanye ubuncinci bamaxabiso amabini.
//!
//! Ngolwazi oluthe kratya, jonga amaxwebhu afanelekileyo wento nganye kuluhlu.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// I-Trait yokuthelekisa ukulingana eyi-[partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Le trait ivumela ukulingana okungagqibelelanga, kweentlobo ezingenalo ulwalamano olupheleleyo lokulingana.
/// Umzekelo, kumanani eendawo zokudada `NaN != NaN`, ke iintlobo zeendawo zokudada zisebenzisa i `PartialEq` kodwa hayi i [`trait@Eq`].
///
/// Ngokusesikweni, ukulingana kufuneka (kuko konke i `a`, `b`, `c` yohlobo `A`, `B`, `C`):
///
/// - **Symmetric**: ukuba i-`A: PartialEq<B>` kunye ne-`B: PartialEq<A>`, ke **`a==b` ichaza`b==a`**;kwaye
///
/// - **Utshintsho**: ukuba i `A: PartialEq<B>` kunye ne `B: PartialEq<C>` kunye `A:
///   InxalenyeEq<C>`, then **` a==b`kunye `b == c` zithetha`a==c`**.
///
/// Qaphela ukuba i-`B: PartialEq<A>` (symmetric) kunye ne-`A: PartialEq<C>` (transitive) impls azinyanzelwanga ukuba zibekho, kodwa ezi mfuno zisebenza nanini na xa zikhona.
///
/// ## Derivable
///
/// Le trait inokusetyenziswa kunye ne `#[derive]`.Xa u-`derive`d on structs, iimeko ezimbini ziyalingana ukuba onke amasimi ayalingana, kwaye awalingani ukuba kukho nayiphi na imihlaba engalinganiyo.Xa `kuvela`d kwii-enum, umahluko ngamnye ulingana ngokwawo kwaye awulingani nezinye izinto ezahlukeneyo.
///
/// ## Ndingayisebenzisa njani i `PartialEq`?
///
/// `PartialEq` ifuna kuphela indlela ye [`eq`] ukuba yenziwe;I-[`ne`] ichazwa ngokwemigaqo yayo ngokwendalo.Nakuphi na ukuphunyezwa ngesandla kwe [`ne`]*kufuneka* uyihlonele imigaqo yokuba i [`eq`] yinto engqongqo ye [`ne`];Oko kukuthi, i `!(a == b)` ukuba kwaye kuphela ukuba yi `a != b`.
///
/// Ukuphunyezwa kwe `PartialEq`, [`PartialOrd`], kunye ne [`Ord`]*kufuneka* bavumelane.Kulula ukubenza bangavumelani ngengozi ngokufumana ezinye ze-traits kunye nokwenza ezinye ngesandla.
///
/// Umzekelo wokuphunyezwa kwesizinda apho iincwadi ezimbini zithathwa njengencwadi enye ukuba ii-ISBN ziyahambelana, nokuba iifomathi ziyahluka:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Ndingazithelekisa njani iintlobo ezimbini ezahlukeneyo?
///
/// Uhlobo onokuluthelekisa nalo lulawulwa yindidi yeparam`Eq`'s type.
/// Umzekelo, masicofe ikhowudi yethu yangaphambili kancinane:
///
/// ```
/// // Ukufumana izixhobo<BookFormat>==<BookFormat>uthelekiso
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Phumeza<Book>==<BookFormat>uthelekiso
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Phumeza<BookFormat>==<Book>uthelekiso
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Ngokutshintsha i-`impl PartialEq for Book` ukuya kwi-`impl PartialEq<BookFormat> for Book`, sivumela i-BookFormat`s ukuba ithelekiswe ne-Book`s.
///
/// Ukuthelekisa oku kungasentla, okutyeshela ezinye iinkalo zesakhiwo, kunokuba yingozi.Ingakhokelela ngokulula kulwaphulo olungenanjongo lweemfuno zobudlelwane obulinganayo.
/// Umzekelo, ukuba sigcine ukuphunyezwa okungasentla kwe `PartialEq<Book>` ye `BookFormat` kwaye songeze ukuphunyezwa kwe `PartialEq<Book>` ye `Book` (nokuba kungadlula nge `#[derive]` okanye ngokusebenzisa ukwenziwa kwencwadana yomzekelo wokuqala) emva koko iziphumo ziya kwaphula umthetho:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Le ndlela yovavanyo lwe `self` kunye ne `other` yokulingana, kwaye isetyenziswa yi `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Olu vavanyo lwendlela lwe `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Ukufumana okuphezulu okuvelisa i-impl ye-trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// I-Trait yokuthelekisa ukulingana eyi-[equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Oku kuthetha ukuba, ukongeza kwi-`a == b` kunye ne-`a != b` ngokungqinelana ngokungqongqo, ukulingana kufuneka (kuko konke i-`a`, `b` kunye ne-`c`):
///
/// - reflexive: `a == a`;
/// - Umlinganiso: i `a == b` ithetha i `b == a`;kwaye
/// - Uguqulelo: `a == b` kunye ne `b == c` zithetha i `a == c`.
///
/// Le propati ayinakujongwa ngumhlanganisi, yiyo loo nto i `Eq` ichaza i [`PartialEq`], kwaye ayinandlela zongezelelekileyo.
///
/// ## Derivable
///
/// Le trait inokusetyenziswa kunye ne `#[derive]`.
/// Xa i-'dive`d, kuba i `Eq` ayinazindlela zongezelelekileyo, kukwazisa kuphela umhlanganisi ukuba obu bubudlelwane obulinganayo endaweni yolwalamano olulinganayo.
///
/// Qaphela ukuba isicwangciso se `derive` sifuna onke amasimi ukuba abe yi `Eq`, engasoloko ifunwa.
///
/// ## Ndingayisebenzisa njani i `Eq`?
///
/// Ukuba awukwazi ukusebenzisa isicwangciso se `derive`, chaza ukuba uhlobo lwakho lusebenzisa i `Eq`, engenazo iindlela:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // le ndlela isetyenziswa kuphela ngu-#[ukufumana] ukubanga ukuba zonke izinto zoluhlobo zisebenzisa#[zivela], iziseko zophuhliso ezikhoyo ngoku zithetha ukwenza oku ngaphandle kokusebenzisa indlela kule trait phantse ayinakwenzeka.
    //
    //
    // Oku akufuneki kwenziwe ngesandla.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Ukufumana okuphezulu okuvelisa i-impl ye-trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: Olu lwakhiwo lusetyenziswa kuphela ngu-#[derive] ku
// bamba ukuba onke amacandelo ohlobo asebenzise i-Eq.
//
// Olu lwakhiwo akufuneki luvele kwikhowudi yomsebenzisi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// I `Ordering` sisiphumo sokuthelekisa phakathi kwamaxabiso amabini.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Uku-odola apho ixabiso elithelekisiweyo lingaphantsi kwelinye.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Umyalelo apho ixabiso elithelekisiweyo lilingana nelinye.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Uku-odola apho ixabiso elithelekisiweyo likhulu kunomnye.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Ibuyisa i `true` ukuba uku-odola kukwahluka kwe `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Ibuyisa i `true` ukuba uku-odola ayisiyiyo i `Equal` eyahlukileyo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Ibuyisa i `true` ukuba uku-odola kukwahluka kwe `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Ibuyisa i `true` ukuba uku-odola kukwahluka kwe `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Ibuyisa i `true` ukuba uku-odola nokuba kungu `Less` okanye u `Equal` okwahlukileyo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Ibuyisa i `true` ukuba uku-odola nokuba kungu `Greater` okanye u `Equal` okwahlukileyo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Ukubuyisa umva i `Ordering`.
    ///
    /// * `Less` iba yi `Greater`.
    /// * `Greater` iba yi `Less`.
    /// * `Equal` iba yi `Equal`.
    ///
    /// # Examples
    ///
    /// Ukuziphatha okusisiseko:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Le ndlela inokusetyenziselwa ukubuyisela umva uthelekiso:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // Hlela uluhlu ukusuka kwelona likhulu kuye kwelona lincinci.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Amatyathanga odolo amabini.
    ///
    /// Ibuyisa i `self` xa ingeyiyo i `Equal`.Ngaphandle koko ibuyisa i `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Utyhafisa uku-odola kunye nomsebenzi owunikiweyo.
    ///
    /// Ibuyisa i `self` xa ingeyiyo i `Equal`.
    /// Ngaphandle koko ubiza i `f` kwaye ubuyise iziphumo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Isakhiwo somncedisi soku-odola umva.
///
/// Olu lwakhiwo ngumncedisi oza kusetyenziswa nemisebenzi efana ne [`Vec::sort_by_key`] kwaye inokusetyenziselwa ukubuyisela umva inxenye yesitshixo.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait zeentlobo ezenza i [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// I-odolo iyonke iodolo ukuba iyiyo (yazo zonke i `a`, `b` kunye ne `c`):
///
/// - iyonke kunye ne-asymmetric: ngokuchanekileyo enye ye `a < b`, `a == b` okanye `a > b` yinyani;kwaye
/// - Ukutshintsha, i `a < b` kunye ne `b < c` kuthetha i `a < c`.Kuyafana ukubambelela kuzo zombini i `==` kunye ne `>`.
///
/// ## Derivable
///
/// Le trait inokusetyenziswa kunye ne `#[derive]`.
/// Xa i-derive`d kwi-structs, iya kuvelisa i-odolo ye-[lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) esekwe kulungelelwaniso oluphezulu ukuya ezantsi lwamalungu ezakhiwo.
///
/// Xa 'zivela`d kwii-enum, umahluko uyalelwa ngokomyalelo wabo wokucalula ukuya ezantsi.
///
/// ## Uthelekiso lwesichazi magama
///
/// Uthelekiso lwesichazimagama kukusebenza kwezi zinto zilandelayo:
///  - Ukulandelelana okubini kuthelekiswa ngento yento.
///  - Into yokuqala yokungafani kakuhle ichaza ukuba loluphi ulandelelwano oluncinci okanye olukhulu kunolunye.
///  - Ukuba ulandelelwano olunye sisiqalo sesinye, ulandelelwano olufutshane lunezichaphazeli esingaphantsi kwesinye.
///  - Ukuba ulandelelwano olunezinto ezilinganayo kwaye zilingana ngokulinganayo, ngokulandelelana kwazo ziyalingana ngokwelichaphografi.
///  - Ulandelelwano olungenanto luyichaphazeli kunophicotho-zincwadi kunoluphi na ulandelelwano olungenanto.
///  - Ulandelelwano ezimbini ezingenanto ziyalingana ngokwelichophografi.
///
/// ## Ndingayisebenzisa njani i `Ord`?
///
/// `Ord` Ifuna ukuba uhlobo lube yi [`PartialOrd`] kunye ne [`Eq`] (efuna i [`PartialEq`]).
///
/// Ke kuya kufuneka uchaze ukumiliselwa kwe [`cmp`].Unokukufumanisa kuluncedo ukusebenzisa i [`cmp`] kumabala ohlobo lwakho.
///
/// Ukuphunyezwa kwe [`PartialEq`], [`PartialOrd`], kunye ne `Ord`*kufuneka* bavumelane.
/// Oko kukuthi, i `a.cmp(b) == Ordering::Equal` ukuba kwaye kuphela ukuba i `a == b` kunye ne `Some(a.cmp(b)) == a.partial_cmp(b)` yazo zonke i `a` kunye ne `b`.
/// Kulula ukubenza bangavumelani ngengozi ngokufumana ezinye ze-traits kunye nokwenza ezinye ngesandla.
///
/// Nanku umzekelo apho ufuna ukuhlela abantu ngobude kuphela, ungakhathaleli i `id` kunye ne `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Le ndlela ibuyisela i [`Ordering`] phakathi kwe `self` kunye ne `other`.
    ///
    /// Ngendibano, i `self.cmp(&other)` ibuyisa iodolo ehambelana nebinzana `self <operator> other` ukuba liyinyani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Ukuthelekisa kunye nokubuyisa ubuninzi bexabiso ezimbini.
    ///
    /// Ibuyisa impikiswano yesibini ukuba uthelekiso lubamisa ukuba balingane.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Ukuthelekisa kunye nokubuyisa ubuncinci bexabiso ezimbini.
    ///
    /// Ibuyisa impikiswano yokuqala ukuba uthelekiso lubamisa ukuba balingane.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Thintela ixabiso kwixesha elithile.
    ///
    /// Ibuyisa i `max` ukuba i `self` ingaphezulu kwe `max`, kunye ne `min` ukuba i `self` ingaphantsi kwe `min`.
    /// Ngaphandle koko oku kubuyisela i `self`.
    ///
    /// # Panics
    ///
    /// Panics ukuba i `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Ukufumana okuphezulu okuvelisa i-impl ye-trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// I-Trait yamaxabiso anokuthelekiswa ngokulandelelana kohlobo.
///
/// Thelekisa kufuneka yanelise, kuzo zonke i `a`, `b` kunye ne `c`:
///
/// - asymmetry: ukuba i `a < b` emva koko yi `!(a > b)`, kunye ne `a > b` ebonisa i `!(a < b)`;kwaye
/// - Ukuhanjiswa: `a < b` kunye ne `b < c` kuthetha i `a < c`.Kuyafana ukubambelela kuzo zombini i `==` kunye ne `>`.
///
/// Qaphela ukuba ezi mfuno zithetha ukuba i-trait ngokwayo kufuneka yenziwe ngokuvumelanayo nangokuguqukayo: ukuba i-`T: PartialOrd<U>` kunye ne-`U: PartialOrd<V>` ke i-`U: PartialOrd<T>` kunye no-`T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Le trait inokusetyenziswa kunye ne `#[derive]`.Xa i-'ived`d kwi-structs, iya kuvelisa i-odoloyografiki yoku-odola ngokusekwe kumyalelo wokuya ezantsi ukuya ezantsi wamalungu ezakhiwo.
/// Xa 'zivela`d kwii-enum, umahluko uyalelwa ngokomyalelo wabo wokucalula ukuya ezantsi.
///
/// ## Ndingayisebenzisa njani i `PartialOrd`?
///
/// `PartialOrd` ifuna kuphela ukumiliselwa kwendlela ye [`partial_cmp`], kunye nezinye eziveliswe kusetyenziso olungagqibekanga.
///
/// Nangona kunjalo kuhlala kunokwenzeka ukuphumeza abanye ngokwahlukeneyo kwiindidi ezingenayo iodolo iyonke.
/// Umzekelo, iinombolo zamanqaku ezidadayo, i `NaN < 0 == false` kunye ne `NaN >= 0 == false` (cf.
/// IEEE 754-2008 icandelo 5.11).
///
/// `PartialOrd` Ifuna ukuba uhlobo lwakho lube yi [`PartialEq`].
///
/// Ukuphunyezwa kwe [`PartialEq`], `PartialOrd`, kunye ne [`Ord`]*kufuneka* bavumelane.
/// Kulula ukubenza bangavumelani ngengozi ngokufumana ezinye ze-traits kunye nokwenza ezinye ngesandla.
///
/// Ukuba uhlobo lwakho luyi [`Ord`], unokusebenzisa i [`partial_cmp`] usebenzisa i [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Unokukufumanisa kuluncedo ukusebenzisa i [`partial_cmp`] kumabala ohlobo lwakho.
/// Nanku umzekelo weentlobo ze-`Person` ezinendawo yokudada ye-`height` yintsimi ekuphela kwayo enokusetyenziselwa ukuhlela:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Le ndlela ibuyisela iodolo phakathi kwe `self` kunye ne `other` yamaxabiso ukuba ikhona.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Xa uthelekiso lungenakwenzeka:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Le ndlela ivavanya ngaphantsi kwe (ye `self` kunye ne `other`) kwaye isetyenziswa ngumqhubi we `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Le ndlela ivavanya ngaphantsi okanye ilingane (kwi `self` kunye ne `other`) kwaye isetyenziswa ngumsebenzisi we `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Le ndlela ivavanya ngaphezulu kwe (ye `self` kunye ne `other`) kwaye isetyenziswa ngumsebenzisi we `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Le ndlela ivavanya ngaphezulu okanye ilingane (ye `self` kunye ne `other`) kwaye isetyenziswa ngumsebenzisi we `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Ukufumana okuphezulu okuvelisa i-impl ye-trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Ukuthelekisa kunye nokubuyisa ubuncinci bexabiso ezimbini.
///
/// Ibuyisa impikiswano yokuqala ukuba uthelekiso lubamisa ukuba balingane.
///
/// Ngaphakathi isebenzisa i-alias ukuya kwi-[`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Ibuyisa ubuncinci bamaxabiso amabini ngokubhekisele kumsebenzi othelekisiweyo.
///
/// Ibuyisa impikiswano yokuqala ukuba uthelekiso lubamisa ukuba balingane.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Ibuyisela into enika elona xabiso lincinci lomsebenzi ochaziweyo.
///
/// Ibuyisa impikiswano yokuqala ukuba uthelekiso lubamisa ukuba balingane.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Ukuthelekisa kunye nokubuyisa ubuninzi bexabiso ezimbini.
///
/// Ibuyisa impikiswano yesibini ukuba uthelekiso lubamisa ukuba balingane.
///
/// Ngaphakathi isebenzisa i-alias ukuya kwi-[`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Ibuyisa ubuninzi bexabiso ezimbini ngokubhekisele kumsebenzi othelekisiweyo.
///
/// Ibuyisa impikiswano yesibini ukuba uthelekiso lubamisa ukuba balingane.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Ibuyisela into enika elona xabiso liphezulu lomsebenzi ochaziweyo.
///
/// Ibuyisa impikiswano yesibini ukuba uthelekiso lubamisa ukuba balingane.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Ukuphunyezwa kwePartialEq, i-Eq, i-PartialOrd kunye ne-Ord yeentlobo zokuqala
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Umyalelo apha ubalulekile ukuvelisa indibano efanelekileyo.
                    // Bona i <https://github.com/rust-lang/rust/issues/63758> ngolwazi oluthe kratya.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Ukuphosa ii-i8's kunye nokuguqula umahluko ku-Oda kuvelisa indibano efanelekileyo.
            //
            // Bona i <https://github.com/rust-lang/rust/issues/66780> ngolwazi oluthe kratya.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // UKHUSELEKO: bool njenge i8 ibuyisa 0 okanye 1, ke umahluko awunakuba yenye into
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &izikhombisi

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}