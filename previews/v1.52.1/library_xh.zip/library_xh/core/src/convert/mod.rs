//! Traits zotshintsho phakathi kweentlobo.
//!
//! I-traits kule modyuli zibonelela ngendlela yokuguqula ukusuka kolunye uhlobo ukuya kolunye uhlobo.
//! I-trait nganye isebenza ngendlela eyahlukileyo:
//!
//! - Sebenzisa i [`AsRef`] trait yotshintsho olulula lwereferensi yesalathiso
//! - Sebenzisa i [`AsMut`] trait yotshintsho olunokutshintsheka olunokutshintsha
//! - Sebenzisa i [`From`] trait yokusebenzisa ukuguqulwa kwexabiso ukuya kwixabiso
//! - Sebenzisa i [`Into`] trait yokusebenzisa ukuguqulwa kwexabiso ukuya kwixabiso kwiindidi ezingaphandle kwe crate yangoku.
//! - I [`TryFrom`] kunye ne [`TryInto`] traits ziziphatha njenge [`From`] kunye ne [`Into`], kodwa kufuneka ziphunyezwe xa uguquko lusilela.
//!
//! I-traits kule modyuli zihlala zisetyenziswa njenge-trait bound kwimisebenzi yohlobo oluthile enokuthi kuxhaswe iimpikiswano zeentlobo ezininzi.Jonga amaxwebhu e trait nganye kwimizekelo.
//!
//! Njengombhali wethala leencwadi, kuya kufuneka ukhethe ukusebenzisa i [`From<T>`][`From`] okanye i [`TryFrom<T>`][`TryFrom`] endaweni ye [`Into<U>`][`Into`] okanye i [`TryInto<U>`][`TryInto`], njengoko i [`From`] kunye ne [`TryFrom`] zibonelela ngokuguquguquka okukhulu kwaye zinikezela ngokulingana kwe [`Into`] okanye i [`TryInto`] simahla, enkosi ukumiliselwa kwengubo kwilayibrari esemgangathweni.
//! Xa ujolise kuguqulelo ngaphambi kwe-Rust 1.41, kunokuba yimfuneko ukuphumeza i-[`Into`] okanye i-[`TryInto`] ngokuthe ngqo xa uguqula udidi olungaphandle kwe-crate yangoku.
//!
//! # Ukuphunyezwa kwesiqhelo
//!
//! - [`AsRef`] kunye ne-[`AsMut`] auto-dereferefere ukuba uhlobo lwangaphakathi sisalathiso
//! - [`Ukusuka`]`<U>kuba T` ichaza [`Into"] `</u><T><U>ye-U`</u>
//! - [`TryFrom`]`<U>for T` means [`TryInto`]`</u><T><U>ye-U`</u>
//! - [`From`] kwaye i-[`Into`] ayisiyonto, oko kuthetha ukuba zonke iintlobo zinokuzi-`into` ngokwazo kunye ne-`from` ngokwazo
//!
//! Jonga i-trait nganye kwimizekelo yokusebenzisa.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Umsebenzi wesazisi.
///
/// Izinto ezimbini kubalulekile ukuba uziqaphele malunga nalo msebenzi:
///
/// - Ayisoloko ilingana nokuvalwa njenge-`|x| x`, kuba ukuvalwa kunokunyanzela i-`x` kuhlobo olwahlukileyo.
///
/// - Ihambisa igalelo `x` edluliselwe emsebenzini.
///
/// Ngelixa kunokubonakala kungaqhelekanga ukuba nomsebenzi obuyisela umva nje igalelo, kukho izinto ezithile ezinomdla ozisebenzisayo.
///
///
/// # Examples
///
/// Sebenzisa i `identity` ungenzi nto ngokulandelelana kwezinye, ezinomdla, nemisebenzi:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Masenze ngathi ukongeza enye ngumsebenzi onomdla.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Sebenzisa i `identity` njenge "do nothing" yesiseko semeko enemiqathango:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Yenza izinto ezinomdla ngakumbi ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Sebenzisa i-`identity` ukugcina i-`Some` eyahlukileyo ye-iterator ye-`Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Isetyenziselwe ukwenza uguqulelo olunereferensi ekubhekiswa lula kulo.
///
/// Le trait iyafana ne [`AsMut`] esetyenziselwa ukuguqula phakathi kwezalathiso eziguqukayo.
/// Ukuba ufuna ukwenza uguquko olunendleko kubhetele ukumilisela i [`From`] ngohlobo `&T` okanye ubhale umsebenzi wesiko.
///
/// `AsRef` unesiginitsha efanayo ne [`Borrow`], kodwa i [`Borrow`] yahlukile kwimiba embalwa:
///
/// - Ngokungafaniyo ne `AsRef`, i [`Borrow`] inengubo yokufakwa kuyo nayiphi na i `T`, kwaye inokusetyenziselwa ukwamkela isalathiso okanye ixabiso.
/// - [`Borrow`] ikwafuna ukuba i [`Hash`], [`Eq`] kunye ne [`Ord`] ngexabiso elibolekiweyo zilingana nezo zexabiso.
/// Ngesi sizathu, ukuba ufuna ukuboleka indawo enye kuphela yolwakhiwo ungaphumeza i `AsRef`, kodwa hayi i [`Borrow`].
///
/// **Note: Le trait akufuneki isilele **.Ukuba uguquko alunakusilela, sebenzisa indlela ezinikeleyo ebuyisa i [`Option<T>`] okanye i [`Result<T, E>`].
///
/// # Ukuphunyezwa kwesiqhelo
///
/// - `AsRef` Ukuzikhethela ngokuzenzekelayo ukuba uhlobo lwangaphakathi sisalathiso okanye isalathiso esinokuguquguquka (umzekelo: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Ngokusebenzisa i-trait bound singazamkela iimpikiswano zeentlobo ezahlukeneyo okoko zinokuguqulelwa kuhlobo oluchaziweyo `T`.
///
/// Umzekelo: Ngokwenza umsebenzi oqhelekileyo othatha i `AsRef<str>` sivakalisa ukuba sifuna ukwamkela zonke izingqinisiso ezinokuguqulwa zibe yi [`&str`] njengengxoxo.
/// Kuba zombini i [`String`] kunye ne [`&str`] zisebenzisa i `AsRef<str>` singazamkela zombini njengempikiswano yegalelo.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Yenza uguquko.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Isetyenziselwe ukwenza uguqulo olunokutshintsha olunokubakho ngokuguqukayo.
///
/// Le trait iyafana ne [`AsRef`] kodwa isetyenziselwa ukuguqula phakathi kwezalathiso eziguqukayo.
/// Ukuba ufuna ukwenza uguquko olunendleko kubhetele ukumilisela i [`From`] ngohlobo `&mut T` okanye ubhale umsebenzi wesiko.
///
/// **Note: Le trait akufuneki isilele **.Ukuba uguquko alunakusilela, sebenzisa indlela ezinikeleyo ebuyisa i [`Option<T>`] okanye i [`Result<T, E>`].
///
/// # Ukuphunyezwa kwesiqhelo
///
/// - `AsMut` Ukuzikhethela ngokuzenzekelayo ukuba uhlobo lwangaphakathi sisalathiso esinokuguquguquka (umzekelo: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Sisebenzisa i-`AsMut` njenge-trait bound yomsebenzi oqhelekileyo sinokwamkela zonke izingqinisiso ezinokuguqulwa ezinokuguqulwa zibe luhlobo lwe `&mut T`.
/// Kungenxa yokuba i [`Box<T>`] isebenzisa i `AsMut<T>` singabhala umsebenzi `add_one` othatha zonke iimpikiswano ezinokuguqulwa zibe yi `&mut u64`.
/// Kungenxa yokuba i [`Box<T>`] isebenzisa i `AsMut<T>`, i `add_one` yamkela iimpikiswano zohlobo `&mut Box<u64>` ngokunjalo:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Yenza uguquko.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Ixabiso lokuguqula ixabiso elisebenzisa ixabiso lokufaka.Okuchasene ne [`From`].
///
/// Umntu kufuneka aphephe ukumilisela i [`Into`] kwaye asebenzise i [`From`] endaweni yoko.
/// Ukuphunyezwa kwe [`From`] ngokuzenzekelayo kubonelela ngokumiliselwa kwe [`Into`] enkosi ekuphunyezweni kwengubo kwilayibrari esemgangathweni.
///
/// Khetha ukusebenzisa i-[`Into`] ngaphezulu kwe-[`From`] xa ucacisa i-trait bound kumsebenzi oqhelekileyo ukuqinisekisa ukuba iintlobo ezisebenzisa kuphela i-[`Into`] zinokusetyenziswa ngokunjalo.
///
/// **Note: Le trait akufuneki isilele **.Ukuba uguquko alunakusilela, sebenzisa i [`TryInto`].
///
/// # Ukuphunyezwa kwesiqhelo
///
/// - [`Ukusuka`]`<T>ye-U` ichaza i `Into<U> for T`
/// - [`Into`] ayinangqondo, oko kuthetha ukuba i `Into<T> for T` iyenziwa
///
/// # Ukuphumeza i [`Into`] yotshintsho kwiindidi zangaphandle kwiinguqulelo ezindala ze Rust
///
/// Phambi kwe Rust 1.41, ukuba uhlobo lwendawo ekuyiwa kuyo ibingeyonxalenye ye crate yangoku awunakukwazi ukusebenzisa i [`From`] ngokuthe ngqo.
/// Umzekelo, thatha le khowudi:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Oku kuyakusilela ukuqokelela kwiinguqulelo ezindala zolwimi kuba imithetho yeenkedama ye-Rust ibidla ngokuba ngqongqo kancinci.
/// Ukugqithisa oku, unokusebenzisa i [`Into`] ngokuthe ngqo:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Kubalulekile ukuba uqonde ukuba i [`Into`] ayiboneleli nge [`From`] yokuphunyezwa (njengoko i [`From`] isenza nge [`Into`]).
/// Ke ngoko, kuya kufuneka uzame ukusebenzisa i [`From`] kwaye emva koko ubuyele kwi [`Into`] ukuba i [`From`] ayinakuphunyezwa.
///
/// # Examples
///
/// [`String`] izixhobo (`Into``` <`[` Vec`]`<<["u8`] ``>>`:
///
/// Ukucacisa ukuba sifuna umsebenzi oqhelekileyo uthathe zonke iimpikiswano ezinokuguqulelwa kuhlobo oluchaziweyo `T`, singasebenzisa i trait bound ye [`Into`]`<T>`.
///
/// Umzekelo: Umsebenzi `is_hello` uthatha zonke iimpikiswano ezinokuguqulwa zenziwe [[Vec`]`<<[[u8`]`> `.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Yenza uguquko.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Kusetyenziselwa ukwenza ukuguqulwa kwexabiso ukuya kwixabiso ngelixa usebenzisa ixabiso lokufaka.Kukuphindaphinda kwe [`Into`].
///
/// Umntu uya kuhlala ekhetha ukumilisela i `From` ngaphezulu kwe [`Into`] kuba ukumiliselwa kwe `From` ngokuzenzekelayo kubonelela ngokumiliselwa kwe [`Into`] enkosi ngokuphunyezwa kwengubo kwilayibrari esemgangathweni.
///
///
/// Sebenzisa kuphela i [`Into`] xa ujolise kuguqulelo ngaphambi kwe Rust 1.41 kunye nokuguqula udidi olungaphandle kwe crate yangoku.
/// `From` khange ikwazi ukwenza ezi ntlobo zotshintsho kwiinguqulelo zangaphambili ngenxa yemithetho yeenkedama ye-Rust.
/// Bona i [`Into`] ngolwazi oluthe kratya.
///
/// Khetha ukusebenzisa i [`Into`] ngaphezulu kokusebenzisa i `From` xa ucacisa i trait bound ekusebenzeni kohlobo oluqhelekileyo.
/// Ngale ndlela, iintlobo ezisebenzisa ngokuthe ngqo i [`Into`] zinokusetyenziswa njengeempikiswano ngokunjalo.
///
/// I `From` iluncedo kakhulu xa kusenziwa impazamo.Xa usakha umsebenzi okwaziyo ukusilela, uhlobo lokubuya luya kuba kwifom ye `Result<T, E>`.
/// I `From` trait yenza lula ukuphathwa kwempazamo ngokuvumela umsebenzi ukuba ubuyisele uhlobo olunye lweempazamo ezibandakanya iintlobo zeempazamo ezininzi.Bona icandelo le "Examples" kunye ne [the book][book] ngolwazi oluthe kratya.
///
/// **Note: Le trait akufuneki isilele **.Ukuba uguquko alunakusilela, sebenzisa i [`TryFrom`].
///
/// # Ukuphunyezwa kwesiqhelo
///
/// - `From<T> for U` kuthetha ["Into`] <U>ye T`</u>
/// - `From` ayinangqondo, oko kuthetha ukuba i `From<T> for T` iyenziwa
///
/// # Examples
///
/// [`String`] izixhobo `From<&str>`:
///
/// Ukuguqulwa okucacileyo ukusuka kwi-`&str` ukuya kwi-String kwenziwa ngolu hlobo lulandelayo:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ngelixa usenza impazamo yokuphatha kuhlala kuluncedo ekuphumezeni i `From` yohlobo lwempazamo yakho.
/// Ngokuguqula iintlobo zempazamo zibe zezethu iimpazamo zohlobo lwesiko oluhlanganisa isiphoso sohlobo oluphambili, sinokubuyisa uhlobo olunye lweempazamo ngaphandle kokuphulukana nolwazi ngesizathu esisisiseko.
/// Umqhubi we '?' uguqula ngokuzenzekelayo uhlobo olusezantsi lwemposiso kuhlobo lwempazamo yethu ngokubiza i `Into<CliError>::into` enikezelwa ngokuzenzekelayo xa kusenziwa i `From`.
/// Umhlanganisi emva koko uchaphazela ukumiliselwa kwe `Into` ekufuneka isetyenzisiwe.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Yenza uguquko.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Uvavanyo lokuzama ukusebenzisa i `self`, enokuthi okanye ingabizi.
///
/// Ababhali bethala lencwadi akufuneki bayenze ngokuthe ngqo le trait, kodwa bakhethe ukusebenzisa i [`TryFrom`] trait, enika ubhetyebhetye obukhulu kwaye ibonelele ngokumiliselwa kwe `TryInto` simahla, ngenxa yokuphunyezwa kwengubo kwilayibrari esemgangathweni.
/// Ngolwazi oluthe kratya koku, bona amaxwebhu e [`Into`].
///
/// # Kumiliselwa i `TryInto`
///
/// Oku kunengxaki efanayo kunye nokuqiqa njengokumiliselwa kwe [`Into`], jonga apho ngeenkcukacha.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Uhlobo lubuyisiwe kwimeko yempazamo yokuguqula.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Yenza uguquko.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Utshintsho olulula nolukhuselekileyo olunokuthi lusilele ngendlela elawulwayo phantsi kweemeko ezithile.Kukuphindaphinda kwe [`TryInto`].
///
/// Oku kuluncedo xa usenza uhlobo loguquko olunokuphumelela kancinci kodwa unokufuna ukuphathwa okukhethekileyo.
/// Umzekelo, akukho ndlela yokuguqula i-[`i64`] ibe yi-[`i32`] usebenzisa i-[`From`] trait, kuba i-[`i64`] inokuba nexabiso elingenakuboniswa yi-[`i32`] kwaye ke uguquko luya kuphulukana nedatha.
///
/// Oku kunokulawulwa ngokuphungula i [`i64`] ukuya kwi [`i32`] (ngokuyintloko inika [`i64`] ixabiso lemodyuli [`i32::MAX`]) okanye ngokumane ubuyise i [`i32::MAX`], okanye ngenye indlela.
/// I [`From`] trait yenzelwe uguquko olugqibeleleyo, ke i `TryFrom` trait yazisa umdwelisi wenkqubo xa uguquko lwendlela lungahambi kakuhle kwaye lubavumele bathathe isigqibo sokuba bayiphathe njani.
///
/// # Ukuphunyezwa kwesiqhelo
///
/// - `TryFrom<T> for U` kuthetha ["ZamaInto`] <U>kwi-T`</u>
/// - [`try_from`] ayinangqondo, oko kuthetha ukuba i `TryFrom<T> for T` iyaphunyezwa kwaye ayinakusilela-uhlobo oluhambelana ne `Error` yokubiza i `T::try_from()` ngexabiso lohlobo `T` yi [`Infallible`].
/// Xa uhlobo lwe [`!`] luzinzile i [`Infallible`] kunye ne [`!`] ziya kulingana.
///
/// `TryFrom<T>` inokwenziwa ngolu hlobo lulandelayo:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Njengoko kuchaziwe, izixhobo ze [`i32`] `TryFrom <` [``i64`] `>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Ngokuthe cwaka i-`big_number`, ifuna ukubonwa kunye nokuphathwa kwe-truncation emva kwenyani.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Ibuyisa impazamo kuba i `big_number` inkulu kakhulu ukuba ingangena kwi `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Ibuyisa i `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Uhlobo lubuyisiwe kwimeko yempazamo yokuguqula.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Yenza uguquko.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IZIPHUMO NGOKUBANZI
////////////////////////////////////////////////////////////////////////////////

// Njengokunyusa ngaphezulu&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Njengokunyusa ngaphezulu kwe &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// I-FIXME (#45742) ithathe indawo yeempls ezingasentla ze&/&mut ngoku kulandelayo ngokubanzi:
// // Njengokunyusa ngaphezulu kweDeref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U: Sized> AsRef <U>ye D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// I-AsMut inyusa ngaphezulu kwe &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// I-FIXME (#45742) ithathe indawo yokufakwa okungasentla kwe &mut ngale ilandelayo ngokubanzi:
// // I-AsMut inyusa ngaphezulu kweDerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Ubungakanani> i-AsMut <U>ye-D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Ukusuka kuthetha ukuya
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Ukusuka (kwaye ngaloo ndlela ungene) kuyacaca
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Inqaku lozinzo:** Le impl ayikabikho, kodwa siyi-"reserving space" ukuyongeza kwi-future.
/// Jonga i [rust-lang/rust#64715][#64715] ngeenkcukacha.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): yenza ukulungiswa kwemigaqo endaweni yoko.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom kuthetha TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Uguquko olungafezekiyo lulingana ngokwasemthethweni noguquko olunokwenzeka kunye nohlobo lwempazamo engahlali bantu.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IZIPHUMO ZE-CONCRETE
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// UHLOBO LWEPHOSI OLUNGENAYO
////////////////////////////////////////////////////////////////////////////////

/// Uhlobo lwempazamo lweempazamo ezingenakuze zenzeke.
///
/// Kuba le enum ayinantlukwano, ixabiso lolu hlobo alunakubakho.
/// Oku kunokuba luncedo kwii-API eziqhelekileyo ezisebenzisa i-[`Result`] kunye neparameter yohlobo lwempazamo, ukubonisa ukuba iziphumo zihlala zili-[`Ok`].
///
/// Umzekelo, i [`TryFrom`] trait (uguquko olubuyisela i [`Result`]) inokuphunyezwa kwengubo kuzo zonke iintlobo apho kukho umiliselo lwe [`Into`] olubuyela umva.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Ukuhambelana kwe Future
///
/// Le enum inendima efanayo ne [the `!`“never”type][never], engazinzanga kule nguqulo ye Rust.
/// Xa i `!` izinzisiwe, siceba ukwenza i `Infallible` ibe luhlobo oluchaseneyo nayo:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Kwaye ekugqibeleni yehlise i `Infallible`.
///
/// Nangona kunjalo kukho imeko enye apho i-`!` syntax inokusetyenziswa ngaphambi kokuba i `!` izinziswe njengohlobo olupheleleyo: kwindawo yohlobo lomsebenzi obuyayo.
/// Ngokukodwa, kunokwenzeka ukwenziwa kweentlobo ezimbini ezahlukeneyo zesikhombisi:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Nge-`Infallible` ekubeni yi-enum, le khowudi iyasebenza.
/// Nangona kunjalo xa i `Infallible` iba ligama le never type, ezi`impl`s ezimbini ziya kuqala ukugqagqana kwaye ke ziya kuvunyelwa yimigaqo yolungelelwaniso lwe trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}