//! I-libcore prelude
//!
//! Le modyuli yenzelwe abasebenzisi be-libcore abangadibanisi ne-libstd nayo.
//! Le modyuli ingeniswa ngokungagqibekanga xa i `#![no_std]` isetyenziswa ngendlela efanayo nelayibrari esemgangathweni ye prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Inguqulelo ka-2015 yesiseko se prelude.
///
/// Bona i [module-level documentation](self) ngaphezulu.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Inguqulelo ka-2018 yesiseko se prelude.
///
/// Bona i [module-level documentation](self) ngaphezulu.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Inguqulelo ka-2021 yesiseko se prelude.
///
/// Bona i [module-level documentation](self) ngaphezulu.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Yongeza ezinye izinto.
}