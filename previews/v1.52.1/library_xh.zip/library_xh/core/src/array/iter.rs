//! Ichaza i-`IntoIter` yayo i-iterator kulungelelwaniso.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Ixabiso nge [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Olu luluhlu esisebenza ngalo ngaphezulu.
    ///
    /// Izinto ezinesalathiso `i` apho i-`alive.start <= i < alive.end` ingekaveliswa okwangoku kwaye zingeniso olufanelekileyo.
    /// Izinto ezinee-indices `i < alive.start` okanye i `i >= alive.end` sele zivelisiwe kwaye akufuneki ukuba ziphinde zifumaneke!Ezo zinto zifileyo zinokuba zikwimeko engachazwanga ngokupheleleyo!
    ///
    ///
    /// Abahlaseli ke:
    /// - `data[alive]` uyaphila (okt iqulethe izinto ezifanelekileyo)
    /// - `data[..alive.start]` kwaye i `data[alive.end..]` ifile (okt izinto bezisele zifundekile kwaye akufuneki ziphinde zithintwe!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Izinto ezikwi `data` ezingekaveliswa okwangoku.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Yenza i-iterator entsha kwi-`array` enikiweyo.
    ///
    /// *Qaphela*: le ndlela inokuncitshiswa kwi future, emva kwe [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Uhlobo lwe `value` yi `i32` apha, endaweni ye `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // UKHUSELEKO: Ukuhamba apha kukhuselekile ngokwenene.Amaxwebhu e `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` iqinisekisiwe ukuba inesayizi efanayo kunye nolungelelwaniso
        // > njenge `T`.
        //
        // Amaxwebhu abonisa ukuhambisa ukusuka kuluhlu lwe-`MaybeUninit<T>` ukuya kuluhlu lwe `T`.
        //
        //
        // Ngale nto, oku kuqaliswa kuyanelisa abahlali.

        // FIXME(LukasKalbertodt): ngenene sebenzisa i `mem::transmute` apha, nje ukuba isebenze kunye ne-generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Kude kube lelo xesha, sinokusebenzisa i `mem::transmute_copy` ukwenza ikopi ethe tyaba njengohlobo olwahlukileyo, emva koko ulibale i `array` ukuze ingalahli.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Ibuyisa isilayidi esingaguqukiyo sayo yonke into engekakhutshwa.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // UKHUSELEKO: Siyazi ukuba zonke izinto ngaphakathi kwe `alive` ziqaliswe ngokufanelekileyo.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Ibuyisa isilayidi esiguquguqukayo sazo zonke izinto ezingekaveliswa okwangoku.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // UKHUSELEKO: Siyazi ukuba zonke izinto ngaphakathi kwe `alive` ziqaliswe ngokufanelekileyo.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Fumana isalathiso esilandelayo ngaphambili.
        //
        // Ukonyusa i-`alive.start` ngo-1 kugcina ukungangenisi malunga ne `alive`.
        // Nangona kunjalo, ngenxa yolu tshintsho, okwexeshana, indawo ephilayo ayisiyi `data[alive]` kwakhona, kodwa yi `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Funda into kuludwe.
            // UKHUSELEKO: `idx` sisalathiso kwingingqi yangaphambili ye "alive" ye-
            // uluhlu.Ukufunda le nto kuthetha ukuba i `data[idx]` ithathwa njengefileyo ngoku (okt musa ukubamba).
            // Njengoko i `idx` yayikukuqala kwendawo ephilayo, indawo ephilayo ngoku iyi-`data[alive]` kwakhona, ibuyisela bonke abangenayo.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Fumana isalathiso esilandelayo ngasemva.
        //
        // Ukwehla kwe `alive.end` ngo-1 kugcina ukungangenisi malunga ne `alive`.
        // Nangona kunjalo, ngenxa yolu tshintsho, okwexeshana, indawo ephilayo ayisiyi `data[alive]` kwakhona, kodwa yi `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Funda into kuludwe.
            // UKHUSELEKO: `idx` sisalathiso kwingingqi yangaphambili ye "alive" ye-
            // uluhlu.Ukufunda le nto kuthetha ukuba i `data[idx]` ithathwa njengefileyo ngoku (okt musa ukubamba).
            // Njengoko i `idx` yayisisiphelo sendawo ephilayo, indawo ephilayo ngoku iyi-`data[alive]` kwakhona, ibuyisela bonke abangenayo.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // UKHUSELEKO: Oku kukhuselekile: `as_mut_slice` ibuyisa ngqo isilayidi
        // zezinto ezingakhutshelwanga ngaphandle kwaye ezisahleli ukuba zilahlwe.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ayisoze yaphuphuma ngenxa yokungangenisi `kuyaphila.qala <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterator inika ingxelo yobude obuchanekileyo.
// Inani lezinto ze "alive" (ezisaza kuveliswa) bubude boluhlu `alive`.
// Olu luhlu luyancitshiswa kubude nokuba yi-`next` okanye i-`next_back`.
// Ihlala incitshiswa yi-1 kwezi ndlela, kodwa kuphela ukuba i `Some(_)` ibuyisiwe.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Qaphela, akuyomfuneko ukuba singqinelane noluhlu luphilayo ngokuchanekileyo, ke sinako ukuhlangana kwi-offset 0 ngaphandle kwe `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Dibanisa zonke izinto eziphilayo.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Bhala iqela kuludwe olutsha, emva koko uhlaziye uluhlu lwalo oluphilayo.
            // Ukuba i-cloning panics, siza kuzilahla ngokuchanekileyo izinto zangaphambili.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Kuprinta kuphela izinto ezazingekaveliswa okwangoku: asinakho ukufikelela kwizinto ezivelisiweyo kwakhona.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}