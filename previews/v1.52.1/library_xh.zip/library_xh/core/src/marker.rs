//! I-traits yamandulo kunye neendidi ezimele iipropathi ezisisiseko zeentlobo.
//!
//! Iindidi ze-Rust zinokuhlelwa ngeendlela ngeendlela eziluncedo ngokweempawu zazo zangaphakathi.
//! Olu luhlu lubonakaliswa njenge traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Iindidi ezinokudluliselwa kwimida yomtya.
///
/// Le trait iphunyezwa ngokuzenzekelayo xa umhlanganisi egqiba ukuba kufanelekile.
///
/// Umzekelo wohlobo olungelulo lwe-`Send` sisalathiso sokubala isikhombisi [`rc::Rc`][`Rc`].
/// Ukuba imisonto emibini izama ukwenza i-clone [`Rc`] ekhomba kwixabiso elifanayo-elibaliweyo, banokuzama ukuhlaziya inani lesalathiso ngaxeshanye, eyi-[undefined behavior][ub] kuba i-[`Rc`] ayisebenzisi imisebenzi ye-athomu.
///
/// Umzala wakhe u [`sync::Arc`][arc] usebenzisa imisebenzi yeatom (eyenzeka ngaphezulu) kwaye ke yi `Send`.
///
/// Bona i [the Nomicon](../../nomicon/send-and-sync.html) ngolwazi oluthe kratya.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Iindidi ezinobungakanani obuqhelekileyo obaziwa ngexesha lokudityaniswa.
///
/// Zonke iintlobo zeeparameter zinesibophelelo se-`Sized`.I-syntax ekhethekileyo `?Sized` inokusetyenziselwa ukususa oku kubotshwa ukuba ayifanelekanga.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // ulwakhiwo FooUse(Foo<[i32]>);//Impazamo: Ubungakanani abuphunyezwanga kwi [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Umahluko omnye luhlobo lwe `Self` olucacisiweyo lwe trait.
/// I-trait ayinayo i-`Sized` ebotshiweyo njengoko oku kungahambelani ne-[trait object] s apho, ngokwenkcazo, i trait kufuneka isebenze nabo bonke abanokubakho, kwaye ngenxa yoko inokuba nabuphi na ubungakanani.
///
///
/// Nangona i-Rust izakuvumela ukuba ubophe i-`Sized` kwi-trait, ngekhe ukwazi ukuyisebenzisa ukwenza into eyi-trait kamva:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // let y: &dyn Bar= &Impl;//Impazamo: i-trait `Bar` ayinakwenziwa ibe yinto
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // Okwendalo, umzekelo, ofuna ukuba i `[T]: !Default` ivavanywe
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Iindidi ezinokuthi zibe yi-"unsized" kuhlobo lobungakanani obuguqukayo.
///
/// Umzekelo, udidi olulinganayo lwe `[i8; 2]` lusebenzisa i `Unsize<[i8]>` kunye ne `Unsize<dyn fmt::Debug>`.
///
/// Konke ukuphunyezwa kwe `Unsize` kubonelelwa ngokuzenzekelayo ngumhlanganisi.
///
/// `Unsize` iphunyelelwe:
///
/// - `[T; N]` ngu `Unsize<[T]>`
/// - `T` ngu `Unsize<dyn Trait>` xa i `T: Trait`
/// - `Foo<..., T, ...>` ngu `Unsize<Foo<..., U, ...>>` ukuba:
///   - `T: Unsize<U>`
///   - Foo sisakhiwo
///   - Kuphela yintsimi yokugqibela ye `Foo` enodidi olubandakanya i `T`
///   - `T` ayiyonxalenye yohlobo lwayo nayiphi na eminye imihlaba
///   - `Bar<T>: Unsize<Bar<U>>`, ukuba umhlaba wokugqibela we `Foo` unodidi `Bar<T>`
///
/// `Unsize` isetyenziswa kunye ne [`ops::CoerceUnsized`] ukuvumela izikhongozeli ze "user-defined" ezinje nge [`Rc`] ukuba ziqulathe iintlobo ezinobungakanani obuguquguqukayo.
/// Bona i [DST coercion RFC][RFC982] kunye ne [the nomicon entry on coercion][nomicon-coerce] ngolwazi oluthe kratya.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// I-trait efunekayo yeekhontrakthi ezisetyenziswa kwimidlalo yeepateni.
///
/// Naluphi na uhlobo olufumana i-`PartialEq` lusebenzisa ngokuzenzekelayo le trait,*ngaphandle kokuba* ingaba iiparameter zohlobo lwazo ziyayisebenzisa na i `Eq`.
///
/// Ukuba into eyi-`const` inohlobo oluthile olungayisebenzisiyo le trait, ke olo hlobo nokuba lolungu-(1.) alusebenzisi i-`PartialEq` (oko kuthetha ukuba i-rhoqo ayizukubonelela ngale ndlela yokuthelekisa, yeyiphi ikhowudi evelisayo ekhoyo), okanye i-(2.) isebenzisa * eyayo Inguqulelo ye `PartialEq` (esicinga ukuba ayihambelani nolungelelwaniso lolwakhiwo).
///
///
/// Kuzo zombini ezi meko zingentla, siyakwala ukusetyenziswa kwezinto ezinje kumdlalo wepateni.
///
/// Jonga kwakhona i [structural match RFC][RFC1445], kunye ne [issue 63438] ekhuthaze ukufuduka kuyilo olusekwe kuphawu luye kule trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// I-trait efunekayo yeekhontrakthi ezisetyenziswa kwimidlalo yeepateni.
///
/// Naluphi na uhlobo olufumana i-`Eq` luzalisekisa ngokuzenzekelayo le trait, * ngaphandle kokujonga ukuba ingaba iiparameter zohlobo lwazo ziyayisebenzisa na i `Eq`.
///
/// Oku kukukhohlisa ukusebenza ngokujikeleza ukusikelwa umda kwinkqubo yohlobo lwethu.
///
/// # Background
///
/// Sifuna ukuba ezi ntlobo zee-consts zisetyenziswe kwimodeli yemodeli zineempawu `#[derive(PartialEq, Eq)]`.
///
/// Kwilizwe elifanelekileyo ngakumbi, singayijonga le mfuno ngokujonga nje ukuba uhlobo olunikiweyo lusebenzisa zombini i `StructuralPartialEq` trait *kunye* ne `Eq` trait.
/// Nangona kunjalo, unokuba nee-ADTs ezenza * i `derive(PartialEq, Eq)`, kwaye ube yimeko esifuna ukuba umhlanganisi ayamkele, ukanti uhlobo oluhlala luhleli luyasilela ekuphumezeni i `Eq`.
///
/// Ngokufanelekileyo, imeko enje:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Ingxaki kule khowudi ingentla kukuba i `Wrap<fn(&())>` ayizalisekisi i `PartialEq`, okanye i `Eq`, kuba `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Ke ngoko, asinakuthembela kuhlobo lwe-`StructuralPartialEq` kunye ne-`Eq`.
///
/// Njengokuqhekeza ukusebenza kule nto, sisebenzisa i traits ezimbini ezahlulwe ngenalinye kwezi zimbini ze (`#[derive(PartialEq)]` kunye ne `#[derive(Eq)]`) kwaye ujonge ukuba bobabini abekho njengenxalenye yokujonga umdlalo.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Iindidi ezinamaxabiso anokuphindwa nje ngokukopa iibits.
///
/// Ngokuzenzekelayo, izibophelelo eziguquguqukayo 'zihambisa iisemics.'Ngamanye amazwi:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ingene kwi `y`, kwaye ayinakusetyenziswa
///
/// // println! ("{: ?}", x);//Impazamo: ukusetyenziswa kwexabiso elihanjisiweyo
/// ```
///
/// Nangona kunjalo, ukuba uhlobo lusebenzisa i `Copy`, endaweni yoko ine 'copy semantics':
///
/// ```
/// // Sinokufumana ukuphunyezwa kwe `Copy`.
/// // `Clone` ikwafuneka, njengoko i-supertrait ye `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` Ikopi ye `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Kubalulekile ukuba uqaphele ukuba kule mizekelo mibini, umahluko kuphela kukuba uvunyelwe na ukufikelela kwi `x` emva kwesabelo.
/// Ngaphantsi kwe-hood, zombini ikopi kunye nokuhamba kunokubangela ukuba iibits zikhutshelwe kwimemori, nangona oku ngamanye amaxesha kulungiswa kude.
///
/// ## Ndingayisebenzisa njani i `Copy`?
///
/// Zimbini iindlela zokuphumeza i `Copy` kuhlobo lwakho.Eyona ilula kukusebenzisa i `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Unokusebenzisa i `Copy` kunye ne `Clone` ngesandla:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Kukho umahluko omncinci phakathi kwezi zimbini: isicwangciso se `derive` siza kubeka i `Copy` eboshwe kwiiparameter zohlobo, ezingasoloko zifunwa.
///
/// ## Yintoni umahluko phakathi kwe `Copy` kunye ne `Clone`?
///
/// Iikopi zenzeka ngokungagungqiyo, umzekelo njengenxalenye yesabelo `y = x`.Ukuziphatha kwe `Copy` akunakulayishwa kakhulu;ihlala ikopi elula enobulumko.
///
/// Ukwenza ikhonkco sisenzo esicacileyo, i `x.clone()`.Ukuphunyezwa kwe [`Clone`] kunokubonelela ngalo naluphi na uhlobo lokuziphatha oluchanekileyo olufunekayo ukuphinda amaxabiso ngokukhuselekileyo.
/// Umzekelo, ukumiliselwa kwe [`Clone`] ye [`String`] kufuneka ikope isikhombisi esikhombise umtya kwimfumba.
/// Ikopi elula ethe kratya yamaxabiso e [`String`] inokukhuphela nje isikhombisi, esikhokelela kukukhululeka kabini ezantsi emgceni.
/// Ngesi sizathu, i [`String`] yi [`Clone`] kodwa hayi i `Copy`.
///
/// [`Clone`] supertrait ye `Copy`, ke yonke into eyi-`Copy` kufuneka isebenzise i [`Clone`].
/// Ukuba uhlobo luyi-`Copy` emva koko ukumiliselwa kwe [`Clone`] kufuna kuphela ukubuyisa i-`*self` (jonga umzekelo ongentla).
///
/// ## Uhlobo lwam lungaba nini i `Copy`?
///
/// Uhlobo lunokumilisela i-`Copy` ukuba onke amacandelo ayo amilisela i-`Copy`.Umzekelo, olu lwakhiwo lunokuba yi-`Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Isakhiwo sinokuba yi-`Copy`, kwaye i-[`i32`] yi-`Copy`, ke ngoko i-`Point` iyafaneleka ukuba yi-`Copy`.
/// Ngokwahlukileyo, cinga
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Ulwakhiwo `PointList` alunakho ukumilisela i `Copy`, kuba i [`Vec<T>`] ayisiyi `Copy`.Ukuba sizama ukufumana ukumiliselwa kwe `Copy`, siya kufumana impazamo:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Iireferensi ekwabelwana ngazo i (`&T`) ikwangama `Copy`, ke uhlobo lunokuba yi `Copy`, nokuba ibambe izingqinisiso ekwabelwana ngazo zeentlobo `T` ezingezizo * `Copy`.
/// Cinga ngolu lwakhiwo lulandelayo, olunokuphumeza i-`Copy`, kuba ibambe kuphela *ireferensi ekwabelwana ngayo* kuhlobo lwethu `
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Nini *ayinakuba* uhlobo lwam lube ngu `Copy`?
///
/// Ezinye iintlobo azinakukhutshelwa ngokukhuselekileyo.Umzekelo, ukukopa i `&mut T` kunokwenza ireferensi enokuguquguquka.
/// Ukukopa i [`String`] kuya kuphinda phinda uxanduva lokulawula [`String`] 's buffer, ekhokelela kukukhululeka simahla.
///
/// Ukwenza ngokubanzi ityala lokugqibela, naluphi na uhlobo olusebenzisa i-[`Drop`] alunakuba yi-`Copy`, kuba ilawula ubutyebi ngaphandle kwe-[`size_of::<T>`] byte.
///
/// Ukuba uzama ukumilisela i-`Copy` kwisakhiwo okanye i-enum equlathe idatha engeyiyo-`Copy`, uyakufumana impazamo [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kufuneka * uhlobo lwam lube ngu-`Copy`?
///
/// Ukuthetha ngokubanzi, ukuba uhlobo lwakho _can_ lumilisela i `Copy`, kufanelekile.
/// Gcina ukhumbula, nangona kunjalo, ukuba ukumiliselwa kwe `Copy` yinxalenye ye-API yoluntu yohlobo lwakho.
/// Ukuba udidi lunokuba yi-non-`Copy` kwi-future, kunokuba bubulumko ukushiya ukumiliselwa kwe `Copy` ngoku, ukunqanda ukwaphuka kwe-API.
///
/// ## Abaphumezi abongezelelweyo
///
/// Ukongeza kwi-[implementors listed below][impls], ezi ndidi zilandelayo zikwaphumeza i-`Copy`:
///
/// * Iindidi zezinto zomsebenzi (okt, iindidi ezahlukileyo ezichazwe kumsebenzi ngamnye)
/// * Iindidi zesikhombisi somsebenzi (umzekelo, `fn() -> i32`)
/// * I-Array iintlobo, zazo zonke ubukhulu, ukuba uhlobo lwento nalo lusebenzisa i-`Copy` (umzekelo, `[i32; 123456]`)
/// * Iindidi zeTuple, ukuba icandelo ngalinye likwasebenzisa i `Copy` (umzekelo, `()`, `(i32, bool)`)
/// * Iindidi zokuvalwa, ukuba azifaki xabiso kwindalo esingqongileyo okanye ukuba onke amaxabiso afakiweyo azalisekisa i `Copy` ngokwazo.
///   Qaphela ukuba izinto eziguquguqukayo ezifakwe kwisalathiso ekwabelwana ngaso zihlala zisenza i-`Copy` (nokuba imeko ayichaphazeli), ngelixa izinto eziguquguqukayo ezithathwe sisalathiso esiguqukayo zingaze zisebenzise i `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Oku kuvumela ukukopa uhlobo olungasebenzisi i-`Copy` ngenxa yokungoneliseki kwemida yobomi (ukukopa i-`A<'_>` xa kuphela i-`A<'static>: Copy` kunye ne-`A<'_>: Clone`).
// Olu phawu sinalo apha okwangoku kuphela ngenxa yokuba kukho ubuchwephesha obukhoyo kwi-`Copy` esele ikho kwithala leencwadi eliqhelekileyo, kwaye akukho ndlela yakuziphatha ngokukhuselekileyo ngoku.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Ukufumana okuphezulu okuvelisa i-impl ye-trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Iindidi ezikhuselekileyo zokwabelana ngesalathiso phakathi kwemisonto.
///
/// Le trait iphunyezwa ngokuzenzekelayo xa umhlanganisi egqiba ukuba kufanelekile.
///
/// Inkcazo echanekileyo yile: uhlobo `T` ngu [`Sync`] ukuba kwaye kuphela ukuba i `&T` yi [`Send`].
/// Ngamanye amagama, ukuba akukho thuba le-[undefined behavior][ub] (kubandakanya imidyarho yedatha) xa kudlula i-`&T` izingqinisiso phakathi kwemisonto.
///
/// Njengoko umntu ebenokulindela, iintlobo zakudala ezinje nge-[`u8`] kunye ne-[`f64`] zonke ziyi-[`Sync`], kwaye ke iintlobo ezilula zomdibaniso eziqulethe, njengamawele, izitrato kunye nee-enum.
/// Eminye imizekelo yeendidi ze-[`Sync`] ezisisiseko zibandakanya iintlobo ze-"immutable" ezinje nge `&T`, kunye nezo zinokuguquguquka okulula okuzuzwe njengelifa, njenge [`Box<T>`][box], [`Vec<T>`][vec] kunye nolunye uninzi lweendidi zokuqokelela.
///
/// (Iparameter yesiqhelo kufuneka ibeyi-[`Sync`] ukuze isikhongozeli sayo sibe [`Sync`].)
///
/// Iziphumo ezothusayo zenkcazo kukuba i `&mut T` yi `Sync` (ukuba i `T` yi `Sync`) nangona kubonakala ngathi inokunika utshintsho olungahambelaniyo.
/// Icebo kukuba ireferensi enokutshintsha emva kwesalathiso ekwabelwana ngaso (Oko kukuthi, i `& &mut T`) ifundeka-kuphela, ngokungathi yi `& &T`.
/// Kungoko kungekho bungozi bohlanga lwedatha.
///
/// Iindidi ezingezizo i-`Sync` zezo zine-"interior mutability" kwifom engakhuselekanga njengomsonto, njenge [`Cell`][cell] kunye ne [`RefCell`][refcell].
/// Ezi ntlobo zivumela utshintsho kwimixholo yazo nokuba kungenakuguqulwa, kwabelwana ngesalathiso.
/// Umzekelo indlela ye `set` kwi [`Cell<T>`][cell] ithatha i `&self`, ke ifuna kuphela ireferensi ekwabelwana ngayo nge [`&Cell<T>`][cell].
/// Indlela ayenzi kungqamaniso, yiyo loo nto i [`Cell`][cell] ayinakuba yi `Sync`.
///
/// Omnye umzekelo wohlobo olungelulo olungu-`Sync` sisikhombisi-sokubala isikhombisi [`Rc`][rc].
/// Ngokunikwa nasiphi na isalathiso [`&Rc<T>`][rc], unokwenza i-[`Rc<T>`][rc] entsha, uguqule ukubalwa kwesalathiso ngendlela engeyiyo yeathom.
///
/// Kumatyala xa umntu efuna ukuguquguquka okungaphakathi okukhuselekileyo ngaphakathi, i Rust ibonelela nge [atomic data types], kunye nokutshixeka okucacileyo nge [`sync::Mutex`][mutex] kunye ne [`sync::RwLock`][rwlock].
/// Ezi ntlobo ziqinisekisa ukuba naluphi na utshintsho olungenakubangela ugqatso lwedatha, kungoko iintlobo zi-`Sync`.
/// Ngokunjalo, i [`sync::Arc`][arc] ibonelela nge-analogue ekhuselekileyo ye-[`Rc`][rc].
///
/// Naziphi na iintlobo ezinokuguquguquka ngaphakathi kufuneka zisebenzise isongelo se [`cell::UnsafeCell`][unsafecell] ejikeleze i value(s) enokuthi iguqulwe ngesalathiso ekwabelwana ngaso.
/// Ukusilela ukwenza oku yi-[undefined behavior][ub].
/// Umzekelo, [`transmute`][transmute]-ing ukusuka kwi `&T` ukuya kwi `&mut T` ayisebenzi.
///
/// Bona i [the Nomicon][nomicon-send-and-sync] ngolwazi oluthe kratya malunga ne `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ukuxhasa ukongeza amanqaku kumazwe e-`rustc_on_unimplemented` kwi-beta, kwaye kwandisiwe ukujonga ukuba ukuvalwa kuko naphi na kwikhonkco lokufuna, yandisa njenge (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Uhlobo lweZero-esetyenziselwa ukumakisha izinto eziyi-"act like" ezizezabo i-`T`.
///
/// Ukongeza intsimi ye-`PhantomData<T>` kuhlobo lwakho uxelela umhlanganisi ukuba uhlobo lwakho lusebenza ngokungathi ligcina ixabiso lohlobo `T`, nangona lungekho ngokwenene.
/// Olu lwazi lusetyenziswa xa kubhalwa iipropathi ezithile zokhuseleko.
///
/// Ukufumana inkcazo enzulu ngakumbi ngendlela yokusebenzisa i `PhantomData<T>`, nceda ubone i [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Inqaku eliqaqambileyo 👻👻👻
///
/// Nangona bobabini benamagama ayoyikisayo, i-`PhantomData` kunye 'neentlobo ze-phantom' zinxulumene, kodwa azifani.Uhlobo lweparantom yiparameter luhlobo nje lweparadesi engasetyenziswanga.
/// Kwi-Rust, oku kuhlala kubangela ukuba umhlanganisi akhalaze, kwaye isisombululo kukongeza ukusetyenziswa kwe "dummy" ngendlela ye `PhantomData`.
///
/// # Examples
///
/// ## Iiparamitha zobomi ezingasetyenziswanga
///
/// Mhlawumbi elona tyala liqhelekileyo lokusetyenziswa kwe `PhantomData` sisakhiwo esineparameter engasetyenziswanga yobomi, ngesiqhelo njengenxalenye yekhowudi engakhuselekanga.
/// Umzekelo, nantsi ulwakhiwo `Slice` olunezikhombisi ezibini zohlobo `*const T`, ngokunokwenzeka zikhomba kuludwe kwenye indawo:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Injongo kukuba idatha esisiseko isebenza kuphela kubomi be `'a`, ke i `Slice` akufuneki iphile i `'a`.
/// Nangona kunjalo, le njongo ayichazwanga kwikhowudi, kuba akukho zixhobo ze `'a` yobomi kwaye ke ayicacanga ukuba yeyiphi idatha esebenza kuyo.
/// Singayilungisa le nto ngokuxelela umhlanganisi ukuba enze * ngokungathi i-`Slice` struct inesalathiso `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Oku kufuna isichaso `T: 'a`, esibonisa ukuba naziphi na izingqinisiso kwi `T` zisebenza ngaphezulu kwe `'a` yobomi.
///
/// Xa usungula i `Slice` ngokulula unikezela ngexabiso `PhantomData` yentsimi `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Uhlobo lweparamitha ezingasetyenziswanga
///
/// Ngamanye amaxesha kuyenzeka ukuba uneeparameter zohlobo olungasetyenziswanga ezibonisa ukuba loluphi uhlobo lwedatha eyi-"tied" kuyo, nangona loo datha ingafumaneki kulwakhiwo ngokwalo.
/// Nanku umzekelo apho oku kuvela nge [FFI].
/// Ujongano lwangaphandle lusebenzisa izibambo zohlobo `*mut ()` ukubhekisa kwixabiso le-Rust leentlobo ezahlukeneyo.
/// Silandelela uhlobo lwe-Rust sisebenzisa uhlobo lweparantom parameter kwi-`ExternalResource` esonga isiphatho.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Ubunini kunye netsheki eyehlisiweyo
///
/// Ukongeza intsimi yohlobo `PhantomData<T>` ibonisa ukuba uhlobo lwakho lunedatha yohlobo `T`.Oku kuthetha ukuba xa uhlobo lwakho luyehlisiwe, lunokuwisa imeko enye okanye ezingaphezulu zohlobo `T`.
/// Oku kuyasebenza kuhlalutyo lomhlanganisi we-Rust we [drop check].
///
/// Ukuba ulwakhiwo lwakho alunayo *idatha yohlobo `T`, kungcono usebenzise uhlobo lwesalathiso, njenge-`PhantomData<&'a T>` (ideally) okanye i-`PhantomData<* const T>` (ukuba akukho xesha lokuphila), ukuze ungabonisi ubunini.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Ikhompyuter yangaphakathi i-trait esetyenzisiweyo ukubonisa uhlobo lokhetho lwe-enum.
///
/// Le trait yenziwe ngokuzenzekelayo kuzo zonke iintlobo kwaye ayongezi naziphi na iziqinisekiso kwi [`mem::Discriminant`].
/// Ukuziphatha okungachazwanga ** ukuhambisa phakathi kwe `DiscriminantKind::Discriminant` kunye ne `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Uhlobo lokhetho, ekufuneka yanelise i-trait bounds ezifunwa yi `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Ikhompyuter yangaphakathi i-trait isetyenziselwa ukumisela ukuba ngaba uhlobo luqulathe nayiphi na i-`UnsafeCell` ngaphakathi, kodwa hayi ngokolwalathiso.
///
/// Oku kuchaphazela, umzekelo, nokuba i-`static` yolo hlobo ibekwe kwimemori emileyo yokufunda-kuphela okanye inkumbulo ebhaliweyo ebhaliweyo.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Iindidi ezinokuhanjiswa ngokukhuselekileyo emva kokuba zicofiwe.
///
/// I-Rust ngokwayo ayinalo uluvo lweentlobo ezingashukumiyo, kwaye ithathela ingqalelo intshukumo (umzekelo, ngokunikezelwa okanye nge [`mem::replace`]) ukuba ihlale ikhuselekile.
///
/// Uhlobo lwe [`Pin`][Pin] luyasetyenziselwa ukuthintela ukuhamba ngohlobo lwenkqubo.Izikhombisi `P<T>` ezisongelwe kwi-[`Pin<P<T>>`][Pin] ezisongelayo azinakukhutshwa ngaphandle.
/// Jonga amaxwebhu e [`pin` module] ngolwazi oluthe kratya malunga nokuphina.
///
/// Ukuphunyezwa kwe `Unpin` trait ye `T` kuphakamisa izithintelo zokucofa kolo hlobo, oluvumela ukuhambisa i `T` ngaphandle kwe [`Pin<P<T>>`][Pin] ngemisebenzi efana ne [`mem::replace`].
///
///
/// `Unpin` ayinasiphumo kuyo yonke idatha engacinezelwanga.
/// Ngokukodwa, i [`mem::replace`] ihambisa idatha ye `!Unpin` ngovuyo (isebenza kuyo nayiphi na i `&mut T`, hayi xa i `T: Unpin`).
/// Nangona kunjalo, awungekhe usebenzise i [`mem::replace`] kwidatha esongelwe ngaphakathi kwe [`Pin<P<T>>`][Pin] kuba awunakufumana i `&mut T` oyifunayo, kwaye * yiyo le nto eyenza ukuba le nkqubo isebenze.
///
/// Ke oku, umzekelo, kunokwenziwa kuphela kwiindidi ezisebenzisa i `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Sifuna ireferensi enokuguquguquka ukubiza i `mem::replace`.
/// // Singasifumana isalathiso esinje nge (implicitly) ebiza i `Pin::deref_mut`, kodwa oko kunokwenzeka kuphela kuba i `String` isebenzisa i `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Le trait yenziwe ngokuzenzekelayo phantse kuzo zonke iintlobo.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Uhlobo lwesiphawuli olungasebenzisi i `Unpin`.
///
/// Ukuba uhlobo luqukethe i `PhantomPinned`, ayizukuphumeza i `Unpin` ngokungagqibekanga.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Ukuphunyezwa kwe `Copy` yeentlobo zamandulo.
///
/// Ukuphunyezwa okungenakuchazwa kwi-Rust kwenziwa kwi-`traits::SelectionContext::copy_clone_conditions()` kwi-`rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Izalathiso ekwabelwana ngazo zinokukhutshelwa, kodwa izingqinisiso eziguqukayo *azinakho*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}