//! Imisebenzi esisiseko yokujongana nenkumbulo.
//!
//! Le modyuli iqulethe imisebenzi yokubuza ubungakanani kunye nokulungelelaniswa kweentlobo, ukuqala nokukhohlisa inkumbulo.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Thatha ubunini kunye ne "forgets" malunga nexabiso **ngaphandle kokusebenzisa isonakalisi sayo**.
///
/// Naziphi na izixhobo ezilawulwa lixabiso, ezinje ngememori yemfumba okanye isiphatho sefayile, ziya kuhlala ixesha elingenakufikeleleka kwimeko.Nangona kunjalo, oko akuqinisekisi ukuba izikhombisi kule nkumbulo ziya kuhlala zisebenza.
///
/// * Ukuba ufuna ukuvuza imemori, bona i [`Box::leak`].
/// * Ukuba ufuna ukufumana isikhombisi esiluhlaza kwimemori, bona i [`Box::into_raw`].
/// * Ukuba ufuna ukulahla ixabiso ngokufanelekileyo, usebenzisa isonakalisi sayo, bona i [`mem::drop`].
///
/// # Safety
///
/// `forget` ayiphawulwanga njenge `unsafe`, kuba ukhuseleko lwe Rust alubandakanyi siqinisekiso sokuba abonakalisi baya kuhlala beqhuba.
/// Umzekelo, inkqubo inokwenza umjikelo wesalathiso usebenzisa i [`Rc`][rc], okanye ubize i [`process::exit`][exit] ukuphuma ngaphandle kokuchitha.
/// Ke, ukuvumela i `mem::forget` kwikhowudi ekhuselekileyo ayitshintshi ngokusisiseko isiqinisekiso sokhuseleko se Rust.
///
/// Oko kwathethi, ukuvuza kwezixhobo ezinjengememori okanye izinto ze I/O kuhlala kungafuneki.
/// Isidingo sivela kwezinye iimeko ezikhethekileyo zokusetyenziswa kwe-FFI okanye ikhowudi engakhuselekanga, kodwa nalapho, i-[`ManuallyDrop`] iyathandwa.
///
/// Kuba ukulibala ixabiso kuvunyelwe, nayiphi na ikhowudi ye-`unsafe` oyibhalayo kufuneka ivumele oku kunokwenzeka.Awunakho ukubuyisa ixabiso kwaye ulindele ukuba lowo ufowunayo uya kuqhuba umonakalisi wexabiso.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Ukusetyenziswa ngokukhuselekileyo kwe-`mem::forget` kukuthintela umtshabalalisi wexabiso ophunyezwe yi `Drop` trait.Umzekelo, oku kuya kuvuza i `File`, okt
/// phinda ubuyise indawo ethathwe ngumahluko kodwa ungaze uvale isiseko senkqubo:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Oku kuluncedo xa ubunini bezixhobo ezingaphantsi besigqithiselwe kwikhowudi engaphandle kwe Rust, umzekelo ngokudlulisa isichazi sefayile eluhlaza kwikhowudi ye-C.
///
/// # Ubudlelwane kunye ne `ManuallyDrop`
///
/// Ngelixa i `mem::forget` inokusetyenziselwa ukuhambisa *ubunini* bememori, ukwenza njalo kuyimpazamo.
/// [`ManuallyDrop`] kufuneka isetyenziswe endaweni yoko.Cinga, umzekelo, le khowudi:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Yakha i `String` usebenzisa imixholo ye `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // ukuvuza kwe `v` kuba imemori yayo ngoku ilawulwa yi `s`
/// mem::forget(v);  // Impazamo, v ayisebenzi kwaye akufuneki idluliselwe kumsebenzi
/// assert_eq!(s, "Az");
/// // `s` ilahliwe ngokungagungqiyo kwaye imemori yayo yahanjiswa.
/// ```
///
/// Kukho imiba emibini ngalo mzekelo ungasentla:
///
/// * Ukuba enye ikhowudi yongezwa phakathi kolwakhiwo lwe `String` kunye nokucela i `mem::forget()`, i panic ngaphakathi kuyo inokubangela ukuba ikhululeke kabini kuba imemori efanayo iphathwa zizo zombini i `v` kunye ne `s`.
/// * Emva kokubiza i-`v.as_mut_ptr()` kunye nokuhambisa ubunini bedatha kwi-`s`, ixabiso le-`v` alisebenzi.
/// Nokuba ixabiso lisuswe nje lasiwa kwi `mem::forget` (engazukuyihlola), ezinye iindidi zineemfuno ezingqongqo kumaxabiso azo ezibenza bangasebenzi xa belengise okanye bengasenabo.
/// Sebenzisa amaxabiso angasebenziyo nangayiphi na indlela, kubandakanya ukuyidlulisa okanye ukuyibuyisela kwimisebenzi, yenza isimilo esingachazwanga kwaye inokuphula uqikelelo olwenziwe ngumhlanganisi.
///
/// Ukutshintshela kwi `ManuallyDrop` kuthintela yomibini le micimbi:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Ngaphambi kokuba sidibanise i `v` kwiindawo zayo eziluhlaza, qiniseka ukuba ayilahli!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Ngoku hlanganisa i-`v`.Le misebenzi ayinakho i panic, ke ngoko akunakubakho ukuvuza.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Okokugqibela, yakha i `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ilahliwe ngokungagungqiyo kwaye imemori yayo yahanjiswa.
/// ```
///
/// `ManuallyDrop` ngokuqinileyo kuthintela ukungabikho simahla kuba sikhubaza umtshabalalisi ngaphambi kokuba senze enye into.
/// `mem::forget()` ayikuvumeli oku kuba itya impikiswano yayo, isinyanzela ukuba siyitsalele umnxeba kuphela emva kokukhupha nantoni na esiyifunayo kwi `v`.
/// Nokuba i-panic ingenisiwe phakathi kolwakhiwo lwe `ManuallyDrop` kunye nokwakha umtya (ongenakwenzeka kwikhowudi njengoko kubonisiwe), oko kungakhokelela kukuvuza kwaye kungabi simahla kabini.
/// Ngamanye amagama, i `ManuallyDrop` iyaphazama kwicala lokuvuza endaweni yokona kwicala loku (kabini-) ukulahla.
///
/// Kwakhona, i `ManuallyDrop` isithintela ekubeni siye kwi "touch" `v` emva kokudlulisela ubunini kwi `s`-inyathelo lokugqibela lokunxibelelana ne `v` ukuyilahla ngaphandle kokusebenzisa umonakalisi wayo ithintelwe ngokupheleleyo.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Njengo [`forget`], kodwa ukwamkela amaxabiso angalinganiswanga.
///
/// Lo msebenzi yinto nje ye-shim ekujongwe ukuba isuswe xa inqaku le-`unsized_locals` lizinzile.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Ibuyisa ubungakanani bohlobo lwee-byte.
///
/// Ngokukodwa, oku kukuseta kwi-byte phakathi kwezinto ezilandelanayo kuluhlu olunoluhlobo lwento kubandakanya ulungelelwaniso lokutshixa.
///
/// Ke, kulo naluphi na uhlobo `T` kunye nobude `n`, `[T; n]` inobungakanani be `n * size_of::<T>()`.
///
/// Ngokubanzi, ubungakanani bohlobo aluzinzanga kudityaniso, kodwa iintlobo ezithile ezinje ngezokuqala.
///
/// Le theyibhile ilandelayo inika ubungakanani bezinto zokuqala.
///
/// Uhlobo |ubungakanani_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 itshathi |4
///
/// Ngapha koko, i `usize` kunye ne `isize` zinobungakanani obulinganayo.
///
/// Iindidi ze `*const T`, `&T`, `Box<T>`, `Option<&T>`, kunye ne `Option<Box<T>>` zonke zinobungakanani obulinganayo.
/// Ukuba i-`T` ibukhulu, zonke ezo ntlobo zinobungakanani obufanayo ne-`usize`.
///
/// Ukutshintsha kwesikhombisi akubutshintshi ubungakanani baso.Kananjalo, i `&T` kunye ne `&mut T` zinobungakanani obulinganayo.
/// Ngokunjalo nge `*const T` kunye ne `* mut T`.
///
/// # Ubungakanani bezinto ze `#[repr(C)]`
///
/// Umelo lwe `C` lwezinto zinoyilo oluchaziweyo.
/// Ngolu lwakhiwo, ubungakanani bezinto buzinzile okoko onke amasimi anobungakanani obuzinzileyo.
///
/// ## Ubungakanani beZakhiwo
///
/// Kwi-`structs`, ubungakanani bumiselwe yile algorithm ilandelayo.
///
/// Kwintsimi nganye kulwakhiwo oluyalelwe ngokomyalelo wokubhengezwa:
///
/// 1. Yongeza ubungakanani bentsimi.
/// 2. Hlanganisa ubungakanani obukhoyo ngoku kwinqanaba elikufutshane le-[alignment].
///
/// Okokugqibela, ujikeleze ubungakanani besakhiwo kwi-[alignment] yayo ekufutshane.
/// Ukulungelelaniswa kwesakhiwo kuhlala kulungelelwaniso olukhulu lwayo yonke imihlaba yayo;oku kungatshintshwa kusetyenziswa i `repr(align(N))`.
///
/// Ngokungafaniyo ne `C`, zero zero struct are not rounded up to one byte in size.
///
/// ## Ubungakanani bee-Enum
///
/// Ii-Enum ezingafakwanga datha ngaphandle kocalucalulo zinobungakanani obulinganayo nee-enums kwiqonga abalungiselelwe zona.
///
/// ## Ubungakanani beManyano
///
/// Ubungakanani bemanyano bubungakanani bentsimi yayo enkulu.
///
/// Ngokungafaniyo ne `C`, iimanyano ezinobungakanani obunguziro azijikelezwanga nge-byte enye ngobukhulu.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Ezinye izinto zokuqala
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Olunye uluhlu
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Ubungakanani besikhombi ukulingana
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Sebenzisa i `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ubungakanani bentsimi yokuqala ngu-1, ke yongeza u-1 kubungakanani.Ubungakanani bungu-1.
/// // Ukulungelelaniswa kwentsimi yesibini ngu-2, ke yongeza u-1 kubungakanani bokutshixa.Ubungakanani bungu-2.
/// // Ubungakanani bentsimi yesibini ngu-2, ke yongeza 2 kubungakanani.Ubungakanani bungu-4.
/// // Ukulungelelaniswa kwentsimi yesithathu ngu-1, ke yongeza u-0 kubungakanani bokutshixa.Ubungakanani bungu-4.
/// // Ubungakanani bentsimi yesithathu ngu-1, ke yongeza u-1 kubungakanani.Ubungakanani bungu-5.
/// // Okokugqibela, ulungelelwaniso lolwakhiwo luyi-2 (kuba olona lungelelwaniso lukhulu phakathi kwecandelo lalo ngu-2), ke yongeza u-1 kubungakanani beephedi.
/// // Ubungakanani bungu-6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // AmaTuple structs alandela imigaqo efanayo.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Qaphela ukuba ukuhlela kwakhona amasimi kungathoba ubungakanani.
/// // Singazisusa zombini ii-padding byte ngokubeka i-`third` ngaphambi kwe `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Ubungakanani beManyano bubungakanani bentsimi enkulu.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Ibuyisela ubungakanani bexabiso elalathelwe kwi-byte.
///
/// Oku kuhlala kufana ne `size_of::<T>()`.
/// Nangona kunjalo, xa i-`T` * ingenabungakanani obaziwayo ngokwamanani, umzekelo, isilayidi [`[T]`][slice] okanye i-[trait object], emva koko i-`size_of_val` inokusetyenziselwa ukufumana ubungakanani obaziwayo ngokwamandla.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // UKHUSELEKO: I `val` sisalathiso, ke sisikhombisi esilungileyo esiluhlaza
    unsafe { intrinsics::size_of_val(val) }
}

/// Ibuyisela ubungakanani bexabiso elalathelwe kwi-byte.
///
/// Oku kuhlala kufana ne `size_of::<T>()`.Nangona kunjalo, xa i `T` * ingenabungakanani obaziwayo ngokwamanani, umzekelo, isilayidi [`[T]`][slice] okanye i [trait object], emva koko i `size_of_val_raw` inokusetyenziselwa ukufumana ubungakanani obaziwayo.
///
/// # Safety
///
/// Lo msebenzi ukhuselekile kuphela ukubiza ukuba le miqathango ilandelayo ibambe:
///
/// - Ukuba i `T` yi `Sized`, lo msebenzi uhlala ukhuselekile ukubiza.
/// - Ukuba umsila ongalinganiswanga we `T` ngu:
///     - i [slice], emva koko ubude bomsila wesilayidi kufuneka ube linani elipheleleyo, kunye nobungakanani bexabiso elipheleleyo * (ubude bomsila obunamandla + isimaphambili sobungakanani ngokobalo) kufuneka lulingane kwi `isize`.
///     - i [trait object], emva koko icandelo lesixokelelwano sesikhombisi kufuneka likhombe kwinto efanelekileyo enokufunyanwa ngokunyanzelwa okunganyanzelekanga, kunye nobungakanani bexabiso elipheleleyo * (ubude bomsila obuguqukayo + isimaphambili sobungakanani ngokobungakanani) kufuneka zilingane kwi `isize`.
///
///     - i (unstable) [extern type], emva koko lo msebenzi uhlala ukhuselekile ukubiza, kodwa anga panic okanye ngenye indlela ibuyise ixabiso elingalunganga, njengoko uhlobo lwangaphandle lungaziwa.
///     Oku kuziphatha okufanayo ne [`size_of_val`] kwisalathiso kudidi olunomsila wohlobo lwangaphandle.
///     - Ngaphandle koko, akuvumelekanga ukuba ubize lo msebenzi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // UKHUSELEKO: umntu ofowunayo kufuneka anikeze isikhombisi esingavumelekanga
    unsafe { intrinsics::size_of_val(val) }
}

/// Ibuyisa [ABI] ulungelelwaniso oluncinci olufunekayo lodidi.
///
/// Yonke into ekubhekiswa kuyo kwixabiso lohlobo `T` kufuneka iphindaphindwe kweli nani.
///
/// Olu lulungelelwaniso olusetyenziselwa imihlaba yolwakhiwo.Isenokuba ncinane kunolungelelwaniso olukhethiweyo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ibuyisela i [ABI]-ulungelelwaniso oluncinci olufunekayo lodidi lwexabiso olalatha kwi `val`.
///
/// Yonke into ekubhekiswa kuyo kwixabiso lohlobo `T` kufuneka iphindaphindwe kweli nani.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // UKHUSELEKO: i-val sisalathiso, ke sisikhombisi esiluhlaza esisebenzayo
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ibuyisa [ABI] ulungelelwaniso oluncinci olufunekayo lodidi.
///
/// Yonke into ekubhekiswa kuyo kwixabiso lohlobo `T` kufuneka iphindaphindwe kweli nani.
///
/// Olu lulungelelwaniso olusetyenziselwa imihlaba yolwakhiwo.Isenokuba ncinane kunolungelelwaniso olukhethiweyo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ibuyisela i [ABI]-ulungelelwaniso oluncinci olufunekayo lodidi lwexabiso olalatha kwi `val`.
///
/// Yonke into ekubhekiswa kuyo kwixabiso lohlobo `T` kufuneka iphindaphindwe kweli nani.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // UKHUSELEKO: i-val sisalathiso, ke sisikhombisi esiluhlaza esisebenzayo
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ibuyisela i [ABI]-ulungelelwaniso oluncinci olufunekayo lodidi lwexabiso olalatha kwi `val`.
///
/// Yonke into ekubhekiswa kuyo kwixabiso lohlobo `T` kufuneka iphindaphindwe kweli nani.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Lo msebenzi ukhuselekile kuphela ukubiza ukuba le miqathango ilandelayo ibambe:
///
/// - Ukuba i `T` yi `Sized`, lo msebenzi uhlala ukhuselekile ukubiza.
/// - Ukuba umsila ongalinganiswanga we `T` ngu:
///     - i [slice], emva koko ubude bomsila wesilayidi kufuneka ube linani elipheleleyo, kunye nobungakanani bexabiso elipheleleyo * (ubude bomsila obunamandla + isimaphambili sobungakanani ngokobalo) kufuneka lulingane kwi `isize`.
///     - i [trait object], emva koko icandelo lesixokelelwano sesikhombisi kufuneka likhombe kwinto efanelekileyo enokufunyanwa ngokunyanzelwa okunganyanzelekanga, kunye nobungakanani bexabiso elipheleleyo * (ubude bomsila obuguqukayo + isimaphambili sobungakanani ngokobungakanani) kufuneka zilingane kwi `isize`.
///
///     - i (unstable) [extern type], emva koko lo msebenzi uhlala ukhuselekile ukubiza, kodwa anga panic okanye ngenye indlela ibuyise ixabiso elingalunganga, njengoko uhlobo lwangaphandle lungaziwa.
///     Oku kuziphatha okufanayo ne [`align_of_val`] kwisalathiso kudidi olunomsila wohlobo lwangaphandle.
///     - Ngaphandle koko, akuvumelekanga ukuba ubize lo msebenzi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // UKHUSELEKO: umntu ofowunayo kufuneka anikeze isikhombisi esingavumelekanga
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ibuyisa i `true` ukuba iwisa amaxabiso ohlobo `T` imicimbi.
///
/// Olu luphawu olusebenzayo, kwaye lunokuphunyezwa ngokufanelekileyo:
/// inokubuyisa i `true` yeentlobo ezingafuneki ukuba ziphoswe.
/// Kananjalo uhlala ebuyisa i `true` iya kuba sisenzo esisebenzayo salo msebenzi.Nangona kunjalo ukuba lo msebenzi ubuyisa i `false`, unokuqiniseka ukuba ukulahla i `T` akunaziphumo zisecaleni.
///
/// Ukuphunyezwa kwenqanaba elisezantsi lezinto ezinje ngengqokelela, ekufuneka zilahle idatha yazo ngesandla, kufuneka zisebenzise lo msebenzi ukunqanda ukuzama ngokungeyomfuneko ukulahla yonke imixholo yazo xa zitshatyalalisiwe.
///
/// Oku akunakwenza mahluko ekukhululweni kwakhiwe (apho iluphu engenazo iziphumo ebezingalindelekanga ifunyanwa ngokulula kwaye isuswe), kodwa ihlala iphumelela kakhulu kulungiso lweempazamo.
///
/// Qaphela ukuba i [`drop_in_place`] sele iyenzile le tshekhi, ke ukuba umthwalo wakho ungancitshiswa uye kwinani elincinci leefowuni ze [`drop_in_place`], ukusebenzisa oku akuyomfuneko.
/// Ngokukodwa qaphela ukuba unokwenza i-[`drop_in_place`] isilayi, kwaye oko kuyakwenza into enye_ukujonga indawo kuwo onke amaxabiso.
///
/// Iindidi ezinje ngeVec ke yi `drop_in_place(&mut self[..])` ngaphandle kokusebenzisa ngokucacileyo i `needs_drop`.
/// Iindidi ezinje nge [`HashMap`], kwelinye icala, kufuneka zilahle amaxabiso elinye ngexesha kwaye kufuneka zisebenzise le API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Nanku umzekelo wendlela ingqokelela enokusebenzisa ngayo i `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ulahle idatha
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Ibuyisa ixabiso lohlobo `T` emelwe yiyo yonke-zero byte-ipateni.
///
/// Oku kuthetha ukuba, umzekelo, i-padding byte kwi-`(u8, u16)` ayinyanzelekanga.
///
/// Akukho siqinisekiso sokuba i-zero-byte-pattern ibonisa ixabiso elifanelekileyo lolunye uhlobo `T`.
/// Umzekelo, iphethini ye-zero-byte ayiloxabiso elifanelekileyo leentlobo zesalathiso (`&T`, `&mut T`) kunye nezikhombisi zemisebenzi.
/// Sebenzisa i `zeroed` kwezi ntlobo kubangela i [undefined behavior][ub] kwangoko kuba i [the Rust compiler assumes][inv] ihlala ihleli ixabiso elifanelekileyo kwisiguquguquko esicinga ukuba siqalisiwe.
///
///
/// Oku kunefuthe elifanayo ne [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Iluncedo kwi-FFI ngamanye amaxesha, kodwa kufanelekile kuthintelwe.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Ukusetyenziswa ngokuchanekileyo kwalo msebenzi: ukuqala inani elipheleleyo elino-zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Ukungalunganga* kosetyenziso lwalo msebenzi: ukuqala ireferensi nge-zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Ukuziphatha okungachazwanga!
/// let _y: fn() = unsafe { mem::zeroed() }; // Kwaye kwakhona!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // UKHUSELEKO: umntu ofowunayo uyaqinisekisa ukuba ixabiso elipheleleyo-zero lisebenza kwi `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Iibhodi ze-Rust eziqhelekileyo zokuqalisa ukukhumbula ngokuzenza ngathi zivelisa ixabiso lohlobo `T`, ngelixa ungenzi nto kwaphela.
///
/// **Lo msebenzi uhlisiwe.** Sebenzisa i [`MaybeUninit<T>`] endaweni yoko.
///
/// Isizathu sokurhoxiswa kukuba umsebenzi ngokusisiseko awunakusetyenziswa ngokuchanekileyo: unesiphumo esifanayo ne [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Njengoko i [`assume_init` documentation][assume_init] icacisa, i [the Rust compiler assumes][inv] ukuba amaxabiso aqaliswe ngokufanelekileyo.
/// Ngenxa yoko, ukubiza umz
/// `mem::uninitialized::<bool>()` ibangela isimilo esingachazwanga kwangoko sokubuyisa i `bool` ngokuqinisekileyo engekho i `true` okanye i `false`.
/// Okubi kakhulu, inkumbulo engachazwanga ngokwenyani enje ebuyiswayo apha ikhethekile kuba umhlanganisi uyazi ukuba ayinalo ixabiso elimiselweyo.
/// Oku kuyenza isimilo esingachazwanga ukuba sinedatha engachazwanga kuguquguquko nokuba olo tshintsho lunohlobo olupheleleyo.
/// (Qaphela ukuba imigaqo ejikeleze iinamba ezingagqitywanga ayikagqitywa okwangoku, kodwa de kube kunjalo, kuyacetyiswa ukuyiphepha.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba ixabiso elingachazwanga lisemthethweni kwi `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ukutshintsha amaxabiso kwiindawo ezimbini ezinokuguquguquka, ngaphandle kokukhetha enye.
///
/// * Ukuba ufuna ukutshintsha ngokungagqibekanga okanye ixabiso ledummy, bona i [`take`].
/// * Ukuba ufuna ukutshintsha ngexabiso elidlulisiweyo, ubuyisela ixabiso elidala, bona i [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // UKHUSELEKO: izikhombisi eziluhlaza zenziwe ukusuka kwizalathiso ezikhuselekileyo ezinokuguqula zonke
    // Izithintelo kwi `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Faka endaweni ye `dest` ngexabiso elingagqibekanga le `T`, ubuyise ixabiso langaphambili le `dest`.
///
/// * Ukuba ufuna ukutshintsha amaxabiso eziguquguquko ezimbini, bona i [`swap`].
/// * Ukuba ufuna ukubuyisela ngexabiso elidlulisiweyo endaweni yexabiso elingagqibekanga, bona i [`replace`].
///
/// # Examples
///
/// Umzekelo olula:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ivumela ukuthatha ubunini bentsimi eyakhiweyo ngokuyitshintsha ngexabiso le "empty".
/// Ngaphandle kwe `take` ungabaleka ungene kwimicimbi efana nale:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Qaphela ukuba i `T` ayizukusebenzisa i [`Clone`], ngenxa yoko ayinakho nokuhlangana kunye nokuseta kwakhona i `self.buf`.
/// Kodwa i `take` inokusetyenziselwa ukwahlulahlula ixabiso lokuqala le `self.buf` ukusuka kwi `self`, ukuyivumela ukuba ibuyiselwe:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Ihambisa i-`src` kwi-`dest` ekhankanyiweyo, ibuyisa ixabiso elidlulileyo le-`dest`.
///
/// Akukho xabiso liyehla.
///
/// * Ukuba ufuna ukutshintsha amaxabiso eziguquguquko ezimbini, bona i [`swap`].
/// * Ukuba ufuna ukubuyisela ixabiso elisisiseko, bona i [`take`].
///
/// # Examples
///
/// Umzekelo olula:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ivumela ukusetyenziswa kwentsimi eyakhiweyo ngokuyitshintsha ngexabiso elithile.
/// Ngaphandle kwe `replace` ungabaleka ungene kwimicimbi efana nale:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Qaphela ukuba i-`T` ayinyanzelisi i-[`Clone`], ke ngekhe singayichukumisi i-`self.buf[i]` ukunqanda intshukumo.
/// Kodwa i `replace` inokusetyenziselwa ukwahlulahlula ixabiso lolo hlobo kwisalathiso esivela kwi `self`, ivumele ukuba ibuyiselwe:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // UKHUSELEKO: Sifunda kwi `dest` kodwa sibhale ngqo i `src` kuyo emva koko,
    // kangangokuba ixabiso elidala aliphindiwe.
    // Akukho nanye into eyehlisiweyo kwaye akukho nto apha i-panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Ukulahla ixabiso.
///
/// Oku kuyenza ngokubiza ukuphunyezwa kwengxoxo ye [`Drop`][drop].
///
/// Oku akunakwenza nto kwiindidi ezisebenzisa i `Copy`, umzekelo
/// integers.
/// Amaxabiso anjalo ayakhutshelwa kwaye i-_then_ yahanjiswa yangena emsebenzini, ke ixabiso liyaqhubeka emva kwalo mnxeba womsebenzi.
///
///
/// Lo msebenzi awungomlingo;ichazwa ngokoqobo njenge
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Ngenxa yokuba i `_x` ihanjiselwe emsebenzini, iyaziphosa ngokuzenzekelayo ngaphambi kokuba umsebenzi ubuye.
///
/// [drop]: Drop
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // yehla ngokucacileyo i-vector
/// ```
///
/// Kuba i [`RefCell`] inyanzelisa imigaqo yokuboleka ngexesha lokubaleka, i `drop` inokukhupha i [`RefCell`] iboleke:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // yeka ukubolekwa okuguqukayo kule slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Amanani apheleleyo kunye nezinye iintlobo ezisebenzisa i [`Copy`] azichaphazeleki yi `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // ikopi ye `x` iyasuswa kwaye ilahlwe
/// drop(y); // ikopi ye `y` iyasuswa kwaye ilahlwe
///
/// println!("x: {}, y: {}", x, y.0); // isekhona
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Utolika i-`src` njengoluhlobo lwe-`&U`, emva koko ufunde i-`src` ngaphandle kokuhambisa ixabiso elikuyo.
///
/// Lo msebenzi uya kuthatha ngokungakhuselekanga ukuba isikhombisi `src` sisebenza nge-[`size_of::<U>`][size_of] byte ngokuhambisa i-`&T` ukuya kwi-`&U` kwaye emva koko ufunde i-`&U` (ngaphandle kokuba oku kwenziwa ngendlela echanekileyo naxa i-`&U` yenza iimfuno ezingqinelanayo ezingqongqo kune-`&T`).
/// Iya kwenza ngokungakhuselekanga ikopi yexabiso eliqulathiweyo endaweni yokuphuma kwi `src`.
///
/// Ayisiyo mpazamo yexesha lokudityaniswa ukuba i-`T` kunye ne-`U` zinobungakanani obahlukeneyo, kodwa kuyakhuthazwa kakhulu ukuba ubize lo msebenzi apho i-`T` kunye ne-`U` zinobungakanani obulinganayo.Lo msebenzi ubangela i-[undefined behavior][ub] ukuba i-`U` inkulu kune-`T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Khuphela idatha kwi-'foo_array' kwaye uyiphathe njenge-'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Guqula idatha ekhutshiweyo
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Imixholo ye 'foo_array' akufuneki itshintshe
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ukuba u-U unemfuneko yokulungelelaniswa okuphezulu, i-src ayinakulungelelaniswa ngokufanelekileyo.
    if align_of::<U>() > align_of::<T>() {
        // UKHUSELEKO: `src` sisalathiso esiqinisekisiweyo sokuba sisemthethweni ukufundwa.
        // Umntu ofowunayo makaqinisekise ukuba ugqithiso lwangempela lukhuselekile.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // UKHUSELEKO: `src` sisalathiso esiqinisekisiweyo sokuba sisemthethweni ukufundwa.
        // Sijonge nje ukuba i `src as *const U` ilungelelaniswe ngokufanelekileyo.
        // Umntu ofowunayo makaqinisekise ukuba ugqithiso lwangempela lukhuselekile.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Uhlobo lwe-Opaque emele ucalucalulo lwe-enum.
///
/// Jonga umsebenzi we [`discriminant`] kule modyuli ngolwazi oluthe kratya.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Oku kuphunyezwa kwe-trait akunakufunyanwa kuba asifuni nayiphi na imida kwi-T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Ibuyisa ixabiso elibonisa ngokukodwa umahluko we-enum kwi `v`.
///
/// Ukuba i `T` ayisiyo i-enum, ukubiza lo msebenzi akuyi kukhokelela kukungachazeki kokuziphatha, kodwa ixabiso lokubuya alichazwanga.
///
///
/// # Stability
///
/// Ucalucalulo lokwahluka kwe-enum lunokutshintsha ukuba inkcazo ye-enum iyatshintsha.
/// Ucalucalulo lokwahluka okuthile aluyi kutshintsha phakathi kokudityaniswa komhlanganisi omnye.
///
/// # Examples
///
/// Oku kunokusetyenziselwa ukuthelekisa ii-enum eziphethe idatha, ngelixa ungakhathaleli eyona datha:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Ibuyisa inani lokwahluka kuhlobo lwe-enum `T`.
///
/// Ukuba i `T` ayisiyo i-enum, ukubiza lo msebenzi akuyi kukhokelela kukungachazeki kokuziphatha, kodwa ixabiso lokubuya alichazwanga.
/// Ngokulinganayo, ukuba i `T` yi-enum enezinto ezahlukeneyo kune-`usize::MAX` ixabiso lokubuya alichazwanga.
/// Izinto ezingafakwanga ndawo ziya kubalwa.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}