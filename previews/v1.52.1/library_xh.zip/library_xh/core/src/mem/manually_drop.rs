use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Isisongelo sokuthintela umhlanganisi ekubizeni ngokuzenzekelayo umtshabalalisi.
/// Esi sisongelo lixabiso le-0.
///
/// `ManuallyDrop<T>` ixhomekeke kulwakhiwo olufanayo nolwe `T`.
/// Ngenxa yoko, ayinampembelelo * kuqikelelo olwenziwa ngumhlanganisi malunga nomxholo wayo.
/// Umzekelo, ukuqala i `ManuallyDrop<&mut T>` nge [`mem::zeroed`] kukungazichazi isimilo.
/// Ukuba ufuna ukuphatha idatha engachazwanga, sebenzisa i [`MaybeUninit<T>`] endaweni yoko.
///
/// Qaphela ukuba ukufikelela kwixabiso ngaphakathi kwe `ManuallyDrop<T>` kukhuselekile.
/// Oku kuthetha ukuba i-`ManuallyDrop<T>` enomxholo oye wehliswa akufuneki uvezwe kwi-API ekhuselekileyo yoluntu.
/// Ngokulandelanayo, i `ManuallyDrop::drop` ayikhuselekanga.
///
/// # `ManuallyDrop` kwaye ulahle iodolo.
///
/// I-Rust ine-[drop order] echazwe kakuhle yamaxabiso.
/// Ukuqinisekisa ukuba amasimi okanye abahlali baphoselwe kulandelelwano oluthile, lungisa kwakhona izibhengezo ezinje ngokuba i-odolo ebekiweyo ilungile.
///
/// Kuyenzeka ukuba kusetyenziswe i `ManuallyDrop` ukulawula i-odolo, kodwa oku kufuna ikhowudi engakhuselekanga kwaye kunzima ukuyenza ngokuchanekileyo phambi kokukhulula.
///
///
/// Umzekelo, ukuba ufuna ukuqinisekisa ukuba umhlaba othile ulahliwe emva kwabanye, yenze intsimi yokugqibela yesakhiwo:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` iya kulahlwa emva kwe `children`.
///     // I-Rust iqinisekisa ukuba amasimi ayaphoswa ngokulandelelana kwesibhengezo.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Songa ixabiso eliza kulahlwa ngesandla.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Usenokusebenza ngokukhuselekileyo kwixabiso
    /// assert_eq!(*x, "Hello");
    /// // Kodwa i `Drop` ayizukuqhutywa apha
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Ikhupha ixabiso kwisitya se `ManuallyDrop`.
    ///
    /// Oku kuvumela ixabiso ukuba liphinde liphoswe.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Oku kwehla i `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Ithatha ixabiso elivela kwisitya se `ManuallyDrop<T>` ngaphandle.
    ///
    /// Le ndlela yenzelwe ikakhulu ukukhupha amaxabiso kudrophu.
    /// Endaweni yokusebenzisa i [`ManuallyDrop::drop`] ukulahla ixabiso ngesandla, ungasebenzisa le ndlela ukuthatha ixabiso kwaye ulisebenzise nangona ufuna njalo.
    ///
    /// Nanini na xa kunokwenzeka, kukhethwa ukuba kusetyenziswe i-[`into_inner`][`ManuallyDrop::into_inner`] endaweni yoko, ethintela ukuphinda umxholo we `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Lo msebenzi ukhupha ixabiso eliqulathiweyo ngaphandle kokuthintela ukusetyenziswa kwakhona, ushiya imeko yesi sikhongozeli ingatshintshanga.
    /// Luxanduva lwakho ukuqinisekisa ukuba le `ManuallyDrop` ayisetyenziswa kwakhona.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // UKHUSELEKO: sifunda kwisalathiso, esiqinisekileyo
        // ukuba isebenze ukuze ifundwe.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ngokuzenzekelayo ilahla ixabiso eliqulathiweyo.Oku kulingana ngokuthe ngqo nokubiza i [`ptr::drop_in_place`] ngesikhombisi kwixabiso eliqulathiweyo.
    /// Kananjalo, ngaphandle kokuba ixabiso eliqulathiweyo lipakishwe, umtshabalalisi uya kubizwa endaweni ngaphandle kokuhambisa ixabiso, kwaye ngenxa yoko unokusetyenziselwa ukulahla idatha ye [pinned] ngokukhuselekileyo.
    ///
    /// Ukuba ubunini bexabiso, ungasebenzisa i [`ManuallyDrop::into_inner`] endaweni yoko.
    ///
    /// # Safety
    ///
    /// Lo msebenzi uqhuba umonakalisi wexabiso eliqulathiweyo.
    /// Ngaphandle kotshintsho olwenziwe ngumtshabalalisi uqobo, imemori ishiye ingaguqukanga, kwaye ukuza kuthi ga ngoku ngokubhekisele kumhlanganisi isabambe ipateni encinci esebenzayo kuhlobo `T`.
    ///
    ///
    /// Nangona kunjalo, eli x00X xabiso akufuneki libhengezwe kwikhowudi ekhuselekileyo, kwaye lo msebenzi akufuneki ubizwe ngaphezulu kwesinye.
    /// Sebenzisa ixabiso emva kokuba lilahliwe, okanye ukulahla ixabiso amaxesha amaninzi, kunokubangela ukungaziphathi kakuhle (kuxhomekeke kwinto eyenziwa yi `drop`).
    /// Oku kuhlala kuthintelwa yinkqubo yohlobo, kodwa abasebenzisi be `ManuallyDrop` kufuneka bazigcine ezo ziqinisekiso ngaphandle koncedo kumqokeleli.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // UKHUSELEKO: siwisa ixabiso elalatha kwisalathiso esinokutshintsha
        // eqinisekisiweyo ukuba iyasebenza ukubhala.
        // Kuxhomekeke kulowo ufowunayo ukuba aqiniseke ukuba i `slot` ayiphoswa kwakhona.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}