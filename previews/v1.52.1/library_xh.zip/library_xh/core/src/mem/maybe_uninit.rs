use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Uhlobo olusongelayo lokwakha iimeko ezingachazwanga ze `T`.
///
/// # Ukuqalisa kokungenzi
///
/// Umhlanganisi, ngokubanzi, ucinga ukuba umahluko uqaliswe ngokufanelekileyo ngokweemfuno zohlobo olwahlukileyo.Umzekelo, umahluko wohlobo lwesalathiso kufuneka ulungelelaniswe kwaye ungabi yi-NULL.
/// Oku kukungaguquguquki ekufuneka * kusoloko kugcinwa, nkqu nakwikhowudi engakhuselekanga.
/// Ngenxa yoko, zero-ukuqala kokwahluka kohlobo lwesalathiso kubangela i [undefined behavior][ub] yangoko nangoko, nokuba ireferensi ikhe yasetyenziselwa ukufikelela kwimemori:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // Ukuziphatha okungachazwanga!.️
/// // Ikhowudi efanayo ne `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // Ukuziphatha okungachazwanga!.️
/// ```
///
/// Oku kuxhamla ngumhlanganisi wolungelelwaniso olwahlukeneyo, njengokuphuma kwexesha lokujonga kunye nokwenza ubeko lwe `enum`.
///
/// Kwangokunjalo, inkumbulo engagqitywanga inokuba nayo nayiphi na into, ngelixa i-`bool` kufuneka ihlale iyi-`true` okanye i-`false`.Yiyo loo nto ukwenza i-`bool` engachazwanga kukuziphatha okungachazwanga:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // Ukuziphatha okungachazwanga!.️
/// // Ikhowudi efanayo ne `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // Ukuziphatha okungachazwanga!.️
/// ```
///
/// Ngaphaya koko, inkumbulo engachazwanga ibalulekile kuba ayinalo ixabiso elimiselweyo ("fixed" ethetha i "it won't change without being written to").Ukufunda i-byte efanayo engachazwanga amaxesha amaninzi kunokunika iziphumo ezahlukeneyo.
/// Oku kuyenza isimilo esingachazwanga ukuba sinedatha engachazwanga kuguquguquko nokuba olo tshintsho lunohlobo olupheleleyo, olunokubamba nayiphi na ipateni * esisigxina.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // Ukuziphatha okungachazwanga!.️
/// // Ikhowudi efanayo ne `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // Ukuziphatha okungachazwanga!.️
/// ```
/// (Qaphela ukuba imigaqo ejikeleze iinamba ezingagqitywanga ayikagqitywa okwangoku, kodwa de kube kunjalo, kuyacetyiswa ukuyiphepha.)
///
/// Ngaphezulu koku, khumbula ukuba uninzi lweentlobo zinokongezwa okungaphaya kokuthathelwa ingqalelo kokuqaliswa kwinqanaba lohlobo.
/// Umzekelo, i-1`-eqalisiweyo ye [`Vec<T>`] ithathwa njengeqalisiwe (phantsi kokuphunyezwa kwangoku; oku akusosiqinisekiso esizinzileyo) kuba ekuphela kwemfuno umhlanganisi ayaziyo ngayo kukuba isalathiso sedatha kufuneka singasebenzi.
/// Ukwenza i `Vec<T>` enjalo ayibangi *kwangoko* isimilo esingachazwanga, kodwa kuya kubangela ukungazichazi indlela yokuziphatha kunye nemisebenzi ekhuselekileyo (kubandakanya ukuyilahla).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` isebenza ukwenza ikhowudi engakhuselekanga ukujongana nedatha engachazwanga.
/// Luphawu kumqokeleli obonisa ukuba idatha apha ayinakho * ukuba ingaqaliswa:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Yenza isalathiso esingacaciswanga ngokucacileyo.
/// // Umhlanganisi uyazi ukuba idatha ngaphakathi kwe `MaybeUninit<T>` isenokungasebenzi, yiyo ke le ayisiyi-UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Misela kwixabiso elifanelekileyo.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Ukukhupha idatha eqalisiweyo-oku kuvunyelwe kuphela emva * kokuqalisa ngokufanelekileyo i `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Umhlanganisi uyazi ke ukuba angenzi naluphi na uqikelelo olungelulo okanye ulungelelwaniso kule khowudi.
///
/// Ungacinga nge `MaybeUninit<T>` njengokufana ne `Option<T>` kodwa ngaphandle kwayo nayiphi na indlela yokubaleka ixesha lokubaleka kwaye ngaphandle koqwalaselo lokhuseleko.
///
/// ## out-pointers
///
/// Ungasebenzisa i `MaybeUninit<T>` ukwenza i "out-pointers": endaweni yokubuyisa idatha evela emsebenzini, yigqithisele kwisikhombisi kwimemori ye (uninitialized) ukubeka iziphumo.
/// Oku kunokuba luncedo xa kubalulekile ukuba umntu ofowunayo alawule indlela imemori egcinwe ngayo kwisiphumo esabelweyo, kwaye ufuna ukunqanda iintshukumo ezingeyomfuneko.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ayilahli imixholo yakudala, ebalulekileyo.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Ngoku siyazi ukuba i `v` iqalisiwe!Oku kukwaqinisekisa ukuba i-vector iyehla ngokufanelekileyo.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Kuqala uluhlu lwezinto-ngezinto
///
/// `MaybeUninit<T>` inokusetyenziselwa ukuqala into enkulu yoluhlu-yento:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Yenza uluhlu olungachazwanga lwe `MaybeUninit`.
///     // I `assume_init` ikhuselekile kuba uhlobo esithi sibenalo apha sisiqwengana se-`UnUnitit`s, esingadingi kuqalwa.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Ukulahla i `MaybeUninit` akwenzi nto.
///     // Yiyo loo nto ukusebenzisa ulwabiwo lwesikhombisi esiluhlaza endaweni ye `ptr::write` akubangeli ukuba ixabiso elidala elingachazwanga liyekiswe.
/////
///     // Kananjalo ukuba kukho i-panic ngeli xesha lokujikeleza, sinememori evuzayo, kodwa akukho ngxaki yokhuseleko kwimemori.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Yonke into iqalisiwe.
///     // Dlulisela uluhlu kuhlobo oluqalisiweyo.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Unokusebenza ngokudwelisa ngokungagqibelelanga, okunokufunyanwa kulwakhiwo olukumgangatho ophantsi.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Yenza uluhlu olungachazwanga lwe `MaybeUninit`.
/// // I `assume_init` ikhuselekile kuba uhlobo esithi sibenalo apha sisiqwengana se-`UnUnitit`s, esingadingi kuqalwa.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Bala inani lezinto esizabele zona.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Kwinto nganye kuluhlu, yeka ukuba sabele yona.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Ukuqala intsimi yentsimi
///
/// Ungasebenzisa i-`MaybeUninit<T>`, kunye ne-[`std::ptr::addr_of_mut`] macro, ukuqala intsimi yentsimi:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Kuqala umhlaba we `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Ukuqalisa intsimi ye `list` Ukuba kukho i panic apha, emva koko i `String` kwindawo evulekileyo ye `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Onke amasimi aqalisiwe, ke sibiza i `assume_init` ukufumana iFoo eqalisiweyo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` Iqinisekisiwe ukuba inesayizi efanayo, ulungelelwaniso, kunye neABI njenge `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Nangona kunjalo khumbula ukuba uhlobo *oluqukethe* i `MaybeUninit<T>` ayisiyiyo ubeko olufanayo;I-Rust ayiqinisekisi ngokubanzi ukuba amasimi e-`Foo<T>` aneodolo efanayo ne-`Foo<U>` nokuba i-`T` kunye ne-`U` zinobungakanani obulinganayo kunye nolungelelwaniso.
///
/// Ngaphaya koko, ngenxa yokuba naliphi na ixabiso elisebenzayo lisemthethweni kwi `MaybeUninit<T>` umhlanganisi akanakusebenzisa ukulungiswa kwe non-zero/niche-filling, okunokubangela ubungakanani obukhulu:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ukuba i `T` ikhuselekile kwi-FFI, kunjalo ke kwi `MaybeUninit<T>`.
///
/// Ngelixa i `MaybeUninit` ingu `#[repr(transparent)]` (ebonisa ukuba iqinisekisa ubungakanani obufanayo, ulungelelwaniso, kunye neABI njenge `T`), oku * ayitshintshi nayiphi na imiqolomba yangaphambili.
/// `Option<T>` kwaye i-`Option<MaybeUninit<T>>` isenokuba nobukhulu obahlukeneyo, kwaye iintlobo eziqulathe umhlaba wohlobo `T` zinokubekwa (kunye nobukhulu) ngokwahlukileyo kunokuba loo ntsimi ibiyi `MaybeUninit<T>`.
/// `MaybeUninit` luhlobo lomanyano, kwaye i `#[repr(transparent)]` kwiimanyano azizinzanga (jonga i [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Ixesha elingaphezulu, iziqinisekiso ezichanekileyo ze `#[repr(transparent)]` kwimibutho yabasebenzi zinokuvela, kwaye i `MaybeUninit` inokuthi okanye ingahlali i `#[repr(transparent)]`.
/// Oko kwathethi, i-`MaybeUninit<T>` iya kuhlala iqinisekisa ukuba inobungakanani obulinganayo, ulungelelwaniso, kunye ne-ABI njenge `T`;inye indlela `MaybeUninit` ephumeza ngayo isiqinisekiso sinokuvela.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang ukuze sikwazi ukusonga ezinye iintlobo kuyo.Oku kuluncedo kubavelisi.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ungabizi i `T::clone()`, asinokwazi ukuba siqaliswe ngokwaneleyo ukulungiselela loo nto.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Yenza i `MaybeUninit<T>` entsha eqalisiweyo ngexabiso elinikiweyo.
    /// Kukhuselekile ukubiza i-[`assume_init`] ngexabiso lokubuya lalo msebenzi.
    ///
    /// Qaphela ukuba ukulahla i-`MaybeUninit<T>` ngekhe kubize ikhowudi ye-T's.
    /// Luxanduva lwakho ukuqinisekisa ukuba i `T` iyehla xa iye yaqala.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Yenza i `MaybeUninit<T>` entsha kwimeko engachazwanga.
    ///
    /// Qaphela ukuba ukulahla i-`MaybeUninit<T>` ngekhe kubize ikhowudi ye-T's.
    /// Luxanduva lwakho ukuqinisekisa ukuba i `T` iyehla xa iye yaqala.
    ///
    /// Jonga i [type-level documentation][MaybeUninit] yeminye imizekelo.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Yenza uluhlu olutsha lwezinto ze `MaybeUninit<T>`, kwindawo engachazwanga.
    ///
    /// Note: kuhlobo lwe future Rust le ndlela inokungafuneki xa uluhlu lwamagama lwangempela luvumela i [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Umzekelo ongezantsi unokusebenzisa i `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Ibuyisa isilayidi sedata (esincinci) esasifundwe ngenene
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // UKHUSELEKO: I `[MaybeUninit<_>; LEN]` engachazwanga iyasebenza.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Yenza i `MaybeUninit<T>` entsha kwimeko engagqitywanga, inkumbulo izaliswe zii-`0` byte.Kuxhomekeka kwi `T` nokuba oko sele kwenzelwe ukuqaliswa okufanelekileyo.
    ///
    /// Umzekelo, i `MaybeUninit<usize>::zeroed()` iqalisiwe, kodwa i `MaybeUninit<&'static i32>::zeroed()` ayibangelwa kukuba izingqinisiso akufuneki zingasebenzi.
    ///
    /// Qaphela ukuba ukulahla i-`MaybeUninit<T>` ngekhe kubize ikhowudi ye-T's.
    /// Luxanduva lwakho ukuqinisekisa ukuba i `T` iyehla xa iye yaqala.
    ///
    /// # Example
    ///
    /// Ukusetyenziswa ngokuchanekileyo kwalo msebenzi: ukuqala ukwakheka nge-zero, apho onke amacandelo esakhiwo anokubamba ipateni-0 njengexabiso elifanelekileyo.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// Ukusetyenziswa okungalunganga * kwalo msebenzi: ukubiza i-`x.zeroed().assume_init()` xa i-`0` ingeyiyo iphethini efanelekileyo yolu hlobo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Ngaphakathi kwisibini, senza i `NotZero` engenamkhethe ngokusemthethweni.
    /// // Le yindlela yokuziphatha engachazwanga..️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // UKHUSELEKO: Amanqaku e `u.as_mut_ptr()` kwimemori eyabelweyo.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Icwangcisa ixabiso le `MaybeUninit<T>`.
    /// Oku kubhala ngaphezulu kwalo naliphi na ixabiso langaphambili ngaphandle kokulahla, ke ulumke ungasebenzisi oku kabini ngaphandle kokuba ufuna ukutsiba ukuhambisa umonakalisi.
    ///
    /// Ukulungiselela ukuba kube lula kuwe, oku kubuyisela ireferensi enokuguqukayo kwimixholo (ngoku eqaliswe ngokukhuselekileyo) ye `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // UKHUSELEKO: Siqalise nje eli xabiso.
        unsafe { self.assume_init_mut() }
    }

    /// Ufumana isikhombisi kwixabiso eliqulathiweyo.
    /// Ukufunda kwesi sikhombisi okanye ukusiguqula sibe sisalathiso kukuziphatha okungachazwanga ngaphandle kokuba i-`MaybeUninit<T>` iqalisiwe.
    /// Ukubhala kwimemori yokuba esi sikhombisi (non-transitively) sikhomba kwindlela yokuziphatha engachazwanga (ngaphandle kwangaphakathi kwe `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Ukusetyenziswa ngokuchanekileyo kwale ndlela:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Yenza isalathiso kwi `MaybeUninit<T>`.Oku kulungile kuba siyiqalisile.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Ukusetyenziswa gwenxa kwale ndlela:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Senze isalathiso kwi-vector engacaciswanga!Le yindlela yokuziphatha engachazwanga..️
    /// ```
    ///
    /// (Qaphela ukuba imigaqo ejikeleze izingqinisiso kwidatha engagqitywanga ayikagqitywa okwangoku, kodwa kude kube kunjalo, kuyacetyiswa ukuyiphepha.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` kunye ne `ManuallyDrop` zombini ziyi-`repr(transparent)` ukuze sikwazi ukuphosa isikhombisi.
        self as *const _ as *const T
    }

    /// Ifumana isikhombisi esinokutshintsha kwixabiso eliqulathiweyo.
    /// Ukufunda kwesi sikhombisi okanye ukusiguqula sibe sisalathiso kukuziphatha okungachazwanga ngaphandle kokuba i-`MaybeUninit<T>` iqalisiwe.
    ///
    /// # Examples
    ///
    /// Ukusetyenziswa ngokuchanekileyo kwale ndlela:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Yenza isalathiso kwi `MaybeUninit<Vec<u32>>`.
    /// // Oku kulungile kuba siyiqalisile.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Ukusetyenziswa gwenxa kwale ndlela:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Senze isalathiso kwi-vector engacaciswanga!Le yindlela yokuziphatha engachazwanga..️
    /// ```
    ///
    /// (Qaphela ukuba imigaqo ejikeleze izingqinisiso kwidatha engagqitywanga ayikagqitywa okwangoku, kodwa kude kube kunjalo, kuyacetyiswa ukuyiphepha.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` kunye ne `ManuallyDrop` zombini ziyi-`repr(transparent)` ukuze sikwazi ukuphosa isikhombisi.
        self as *mut _ as *mut T
    }

    /// Ikhupha ixabiso kwisitya se `MaybeUninit<T>`.Le yeyona ndlela ilungileyo yokuqinisekisa ukuba idatha iya kulahla, kuba iziphumo ze `T` zixhomekeke ekuphatheni okuqhelekileyo kwethontsi.
    ///
    /// # Safety
    ///
    /// Kuxhomekeke kulowo ufowunayo ukuba aqinisekise ukuba i `MaybeUninit<T>` ikwimeko eqalisiweyo.Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela indlela yokuziphatha engachazwanga kwangoko.
    /// I [type-level documentation][inv] iqulethe ulwazi oluthe kratya malunga noku kungangenisi kokuqala.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Ngaphezulu koku, khumbula ukuba uninzi lweentlobo zinokongezwa okungaphaya kokuthathelwa ingqalelo kokuqaliswa kwinqanaba lohlobo.
    /// Umzekelo, i-1`-eqalisiweyo ye [`Vec<T>`] ithathwa njengeqalisiwe (phantsi kokuphunyezwa kwangoku; oku akusosiqinisekiso esizinzileyo) kuba ekuphela kwemfuno umhlanganisi ayaziyo ngayo kukuba isalathiso sedatha kufuneka singasebenzi.
    ///
    /// Ukwenza i `Vec<T>` enjalo ayibangi *kwangoko* isimilo esingachazwanga, kodwa kuya kubangela ukungazichazi indlela yokuziphatha kunye nemisebenzi ekhuselekileyo (kubandakanya ukuyilahla).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Ukusetyenziswa ngokuchanekileyo kwale ndlela:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Ukusetyenziswa gwenxa kwale ndlela:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ayikaqaliswa okwangoku, ke lo mgca wokugqibela ubangele ukungachazeki..️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyaqaliswa.
        // Oku kuthetha ukuba i `self` kufuneka ibeyinto eyahlukileyo ye `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Ufunda ixabiso kwisitya se `MaybeUninit<T>`.Isiphumo se `T` sixhomekeke ekuphatheni okuqhelekileyo kwethontsi.
    ///
    /// Nanini na xa kunokwenzeka, kukhethwa ukuba kusetyenziswe i-[`assume_init`] endaweni yoko, ethintela ukuphinda umxholo we `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Kuxhomekeke kulowo ufowunayo ukuba aqinisekise ukuba i `MaybeUninit<T>` ikwimeko eqalisiweyo.Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela isimilo esingachazwanga.
    /// I [type-level documentation][inv] iqulethe ulwazi oluthe kratya malunga noku kungangenisi kokuqala.
    ///
    /// Ngaphaya koko, oku kushiya ikopi yedatha efanayo ngasemva kwi `MaybeUninit<T>`.
    /// Xa usebenzisa iikopi ezininzi zedatha (ngokufowuna i `assume_init_read` amatyeli amaninzi, okanye kuqala ubize i-`assume_init_read` emva koko u-[`assume_init`]), luxanduva lwakho ukuqinisekisa ukuba loo datha inokuphindaphindwa.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Ukusetyenziswa ngokuchanekileyo kwale ndlela:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` Ngu-`Copy`, ke sinokufunda amaxesha amaninzi.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Ukuphinda-phinda ixabiso le `None` kulungile, ke sinokufunda amaxesha amaninzi.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Ukusetyenziswa gwenxa kwale ndlela:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Ngoku senze iikopi ezimbini ze-vector efanayo, ekhokelela ekubeni isimahla-iphindwe kabini xa zombini ziyehla!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyaqaliswa.
        // Ukufunda kwi `self.as_ptr()` kukhuselekile kuba i `self` kufuneka iqaliswe.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Uwisa ixabiso elikuyo endaweni.
    ///
    /// Ukuba ungumnini we `MaybeUninit`, ungasebenzisa i [`assume_init`] endaweni yoko.
    ///
    /// # Safety
    ///
    /// Kuxhomekeke kulowo ufowunayo ukuba aqinisekise ukuba i `MaybeUninit<T>` ikwimeko eqalisiweyo.Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela isimilo esingachazwanga.
    ///
    /// Ngaphezulu, zonke izinto ezingenayo zohlobo `T` kufuneka zonelisekile, njengoko ukuphunyezwa kwe `Drop` kwe `T` (okanye amalungu ayo) kunokuxhomekeka koku.
    /// Umzekelo, i-1`-eqalisiweyo ye [`Vec<T>`] ithathwa njengeqalisiwe (phantsi kokuphunyezwa kwangoku; oku akusosiqinisekiso esizinzileyo) kuba ekuphela kwemfuno umhlanganisi ayaziyo ngayo kukuba isalathiso sedatha kufuneka singasebenzi.
    ///
    /// Ukulahla i `Vec<T>` enjalo kuya kubangela ukungazichazi isimilo.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyaqaliswa kwaye
        // yanelisa bonke abangeneleli be `T`.
        // Ukulahla ixabiso endaweni kukhuselekile ukuba kunjalo.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Ufumana ireferensi ekwabelwana ngayo kwixabiso eliqulathiweyo.
    ///
    /// Oku kunokuba luncedo xa sifuna ukufikelela kwi `MaybeUninit` eqalisiweyo kodwa engenabunini be `MaybeUninit` (ethintela ukusetyenziswa kwe `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela isimilo esingachazwanga: kuxhomekeke kulowo ufowunayo ukuqinisekisa ukuba i `MaybeUninit<T>` ikwimeko eqalisiweyo.
    ///
    ///
    /// # Examples
    ///
    /// ### Ukusetyenziswa ngokuchanekileyo kwale ndlela:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Qalisa i `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Ngoku i `MaybeUninit<_>` yethu iyaziwa ukuba iqaliswe, kulungile ukwenza ireferensi ekwabelwana ngayo kuyo:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // UKHUSELEKO: I `x` iqalile.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Ayichanekanga* usetyenziso lwale ndlela:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Senze isalathiso kwi-vector engacaciswanga!Le yindlela yokuziphatha engachazwanga..️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Qalisa i `MaybeUninit` usebenzisa i `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Isalathiso kwi-`Cell<bool>` engachazwanga: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyaqaliswa.
        // Oku kuthetha ukuba i `self` kufuneka ibeyinto eyahlukileyo ye `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Ifumana ireferensi enokuguquguquka ye (unique) kwixabiso eliqulathiweyo.
    ///
    /// Oku kunokuba luncedo xa sifuna ukufikelela kwi `MaybeUninit` eqalisiweyo kodwa engenabunini be `MaybeUninit` (ethintela ukusetyenziswa kwe `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela isimilo esingachazwanga: kuxhomekeke kulowo ufowunayo ukuqinisekisa ukuba i `MaybeUninit<T>` ikwimeko eqalisiweyo.
    /// Umzekelo, i `.assume_init_mut()` ayinakusetyenziselwa ukwenza i `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Ukusetyenziswa ngokuchanekileyo kwale ndlela:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Iqala * zonke ii-byte ze-buffer yegalelo.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Qalisa i `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Ngoku siyazi ukuba i-`buf` sele iqalisiwe, ngenxa yoko singayi-`.assume_init()`.
    /// // Nangona kunjalo, ukusebenzisa i `.assume_init()` kunokubangela i `memcpy` yee-2048 byte.
    /// // Ukuqinisekisa ukuba i-buffer yethu iqalile ngaphandle kokuyikopa, siphucula i-`&mut MaybeUninit<[u8; 2048]>` ukuya kwi-`&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // UKHUSELEKO: I `buf` iqalile.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ngoku singasebenzisa i `buf` njengesilayidi esiqhelekileyo:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Ayichanekanga* usetyenziso lwale ndlela:
    ///
    /// Awunakho ukusebenzisa i `.assume_init_mut()` ukwenza ixabiso:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Senze isalathiso se (mutable) kwi `bool` engachazwanga!
    ///     // Le yindlela yokuziphatha engachazwanga..️
    /// }
    /// ```
    ///
    /// Umzekelo, awungekhe u [`Read`] kwi-buffer engachazwanga:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) Isalathiso kwimemori engachazwanga!
    ///                             // Le yindlela yokuziphatha engachazwanga.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Kwaye awunakho ukusebenzisa ufikelelo ngqo lwentsimi ukwenza intsimi-nge-intsimi yokuqalisa ngokuthe ngcembe:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) Isalathiso kwimemori engachazwanga!
    ///                  // Le yindlela yokuziphatha engachazwanga.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) Isalathiso kwimemori engachazwanga!
    ///                  // Le yindlela yokuziphatha engachazwanga.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Okwangoku sixhomekeke koku kungasentla ukuba ayichanekanga, okt, sinezalathiso kwidatha engachazwanga (umzekelo, kwi `libcore/fmt/float.rs`).
    // Kuya kufuneka senze isigqibo sokugqibela malunga nemithetho ngaphambi kokuzinza.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyaqaliswa.
        // Oku kuthetha ukuba i `self` kufuneka ibeyinto eyahlukileyo ye `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Ikhupha amaxabiso kuluhlu lwezikhongozeli ze `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Kuxhomekeke kulowo ufowunayo ukuba aqinisekise ukuba zonke izinto zoluhlu zikwimo yokuqalisa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // UKHUSELEKO: Kukhuselekile ngoku njengoko siqale zonke izinto
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Umntu ofowunayo uqinisekisa ukuba zonke izinto zoluhlu ziyaqaliswa
        // * `MaybeUninit<T>` kwaye T ziqinisekisiwe ukuba zinobume obufanayo
        // * Mhlawumbi i-Unint ayilahli, ke akukho kukhululeka kabini kwaye ke uguquko lukhuselekile
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Ukuthatha ukuba zonke izinto ziqalisiwe, fumana isilayidi kubo.
    ///
    /// # Safety
    ///
    /// Kuxhomekeke kulowo ufowunayo ukuqinisekisa ukuba izinto ze-`MaybeUninit<T>` zikwimeko eqalisiweyo.
    ///
    /// Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela isimilo esingachazwanga.
    ///
    /// Bona i [`assume_init_ref`] ngolwazi oluthe kratya kunye nemizekelo.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // UKHUSELEKO: Ukuphosa isilayidi kwi `*const [T]` kukhuselekile kuba umntu ofowunayo uqinisekisa oko
        // `slice` iyaqaliswa, kwaye`MhlawumbiUninit` iqinisekisiwe ukuba inolwakhiwo olufanayo ne `T`.
        // Isikhombisi esifunyenwe sisebenza kuba sibhekisa kwimemori ye-`slice` esisalathiso kwaye ke siqinisekisiwe ukuba siyasebenza ukuze sifundwe.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Ukuthatha ukuba zonke izinto ziqalisiwe, fumana isilayidi esitshintshayo kubo.
    ///
    /// # Safety
    ///
    /// Kuxhomekeke kulowo ufowunayo ukuqinisekisa ukuba izinto ze-`MaybeUninit<T>` zikwimeko eqalisiweyo.
    ///
    /// Ukutsalela umnxeba oku xa umxholo ungekaqaliswa ngokupheleleyo kubangela isimilo esingachazwanga.
    ///
    /// Bona i [`assume_init_mut`] ngolwazi oluthe kratya kunye nemizekelo.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // UKHUSELEKO: ngokufanayo kumanqaku okhuseleko e `slice_get_ref`, kodwa sine
        // Isethenjwa esiguqukayo esiqinisekisiweyo ukuba siyasebenza ukubhala.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Ufumana isikhombisi kwinto yokuqala yoluhlu.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Ifumana isikhombisi esinokuguquguquka kwinto yokuqala yoluhlu.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Ikopa izinto ukusuka ku-`src` ukuya kwi-`this`, ibuyisele ireferensi enokuguquguquka kwimixholo engalunganga ye `this`.
    ///
    /// Ukuba i `T` ayizalisekisi i `Copy`, sebenzisa i [`write_slice_cloned`]
    ///
    /// Oku kuyafana ne [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Lo msebenzi uya kuba panic ukuba izilayi ezibini zinobude obahlukeneyo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // UKHUSELEKO: sikhuphele nje zonke izinto ze-len kwisithuba sokugcina
    /// // Izinto zokuqala ze src.len() zevec ziyasebenza ngoku.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // UKHUSELEKO: &[T] kunye&[MaybeUninit<T>] babe nobeko olufanayo
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // UKHUSELEKO: Izinto ezisemthethweni zisandula ukukhutshelwa kwi `this` ngenxa yoko ayikhutshiwe
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// I-Clones izinto ezisuka kwi-`src` ukuya kwi-`this`, zibuyisela ireferensi enokuguquguquka kwimixholo engalunganga ye `this`.
    /// Naziphi na izinto esele zikhulelwe azizukuphoswa.
    ///
    /// Ukuba i `T` inyanzelisa i `Copy`, sebenzisa i [`write_slice`]
    ///
    /// Oku kuyafana ne [`slice::clone_from_slice`] kodwa ayizilahli izinto ezikhoyo.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uya kuba panic ukuba ezi zilayi zibini zinobude obahlukeneyo, okanye ukuba ukumiliselwa kwe `Clone` panics.
    ///
    /// Ukuba kukho i-panic, izinto esele zenziwe zenziwe ziya kulahlwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // UKHUSELEKO: sikhuphe nje zonke izinto ze-len kwisithuba sokugcina
    /// // Izinto zokuqala ze src.len() zevec ziyasebenza ngoku.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Ngokungafaniyo copy_from_slice le ayibizi clone_from_slice kwisilayidi kungenxa yokuba i `MaybeUninit<T: Clone>` ayiphumezi Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // UKHUSELEKO: esi silayi eluhlaza siza kuba nezinto ezinokuqaliswa kuphela
                // Kungenxa yoko, kuvunyelwe ukuyilahla.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Kufuneka sizicace ngokucacileyo kubude obulinganayo
        // yokujonga imida ukuba ingaphumeleli, kwaye i-optimizer iya kuvelisa i-memcpy yamatyala alula (umzekelo T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // unogada uyafuneka b/c panic inokwenzeka ngexesha lokuhlangana
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // UKHUSELEKO: Izinto ezisemthethweni zisandula ukubhalwa kwi `this` ngoko ke ikhutshiwe
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}