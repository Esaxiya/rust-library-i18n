//! Amaxabiso adangeleyo kunye nokuqaliswa kwexesha elinye kwedatha emileyo.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Iseli enokubhalwa kube kanye kuphela.
///
/// Ngokungafaniyo ne `RefCell`, i `OnceCell` ibonelela kuphela ngeereferensi ezabelwana nge `&T` kwixabiso lazo.
/// Ngokungafaniyo ne `Cell`, i `OnceCell` ayifuni ukukopa okanye ukubuyisela ixabiso ukuyifumana.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Eguqukayo: ibhalelwe kanye kanye.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Yenza iseli entsha engenanto.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Ufumana isalathiso sexabiso elingaphantsi.
    ///
    /// Ibuyisa i `None` ukuba iseli ayinanto.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // UKHUSELEKO: Ukhuselekile ngenxa yangaphakathi `engangenisiyo
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Ifumana ireferensi enokuguquguquka kwixabiso elisisiseko.
    ///
    /// Ibuyisa i `None` ukuba iseli ayinanto.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // UKHUSELEKO: Kukhuselekile kuba sinokufikelela okukhethekileyo
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Cwangcisa imixholo yeseli kwi `value`.
    ///
    /// # Errors
    ///
    /// Le ndlela ibuyisela i-`Ok(())` ukuba iseli ayinanto kwaye i-`Err(value)` ukuba igcwele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // UKHUSELEKO: Kukhuselekile kuba asinakuba nokuboleka okungaphezulu okutyanayo
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // UKHUSELEKO: Le yindawo kuphela apho sibeka khona islot, akukho luhlanga
        // ngenxa ye reentrancy/concurrency inokwenzeka, kwaye siqwalasele ukuba indawo okwangoku i `None`, ke oku kubhala kugcina `ngaphakathi '.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Ufumana imixholo yeseli, eyiqala nge-`f` ukuba iseli ayinanto.
    ///
    /// # Panics
    ///
    /// Ukuba i `f` panics, i-panic isasazwa kulowo ufowunayo, kwaye iseli ihleli ingachazwanga.
    ///
    ///
    /// Yimpazamo ukuphinda ungene kwiseli ukusuka kwi `f`.Ukwenza oku kukhokelela kwi-panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Ufumana imixholo yeseli, eyiqala nge-`f` ukuba iseli ayinanto.
    /// Ukuba iseli ayinanto kwaye i `f` ayiphumelelanga, impazamo iyabuyiselwa.
    ///
    /// # Panics
    ///
    /// Ukuba i `f` panics, i-panic isasazwa kulowo ufowunayo, kwaye iseli ihleli ingachazwanga.
    ///
    ///
    /// Yimpazamo ukuphinda ungene kwiseli ukusuka kwi `f`.Ukwenza oku kukhokelela kwi-panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Qaphela ukuba * ezinye zeefom zokuqalisa kwakhona zinokukhokelela kwi-UB (jonga kuvavanyo lwe `reentrant_init`).
        // Ndiyakholelwa ukuba ukususa nje le `assert`, ngelixa ukugcina i `set/get` kungavakala, kodwa kubonakala kungcono kwi panic, endaweni yokusebenzisa ngokuthe cwaka ixabiso elidala.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Isebenzisa iseli, ibuyisa ixabiso elisongelweyo.
    ///
    /// Ibuyisa i `None` ukuba iseli ayinanto.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Ngenxa yokuba i `into_inner` ithatha i `self` ngexabiso, umhlanganisi uyaqinisekisa ukuba ayibolekwanga ngoku.
        // Kukhuselekile ukuphuma kwi `Option<T>`.
        self.inner.into_inner()
    }

    /// Ithatha ixabiso kule `OnceCell`, iyibuyisele kwimeko engachazwanga.
    ///
    /// Ayinampembelelo kwaye ibuyisa i `None` ukuba i `OnceCell` ayikaze iqaliswe.
    ///
    /// Ukhuseleko luqinisekisiwe ngokufuna ireferensi enokutshintsha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Ixabiso eliqaliswe kufikelelo lokuqala.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   ukulungele ukuqala
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Yenza ixabiso elitsha elinobuvila nomsebenzi onikiweyo wokuqalisa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Ukunyanzelwa kokuvavanywa kweli xabiso livila kwaye kubuyiselwe ireferensi kwiziphumo.
    ///
    ///
    /// Oku kulingana ne-`Deref` impl, kodwa icacile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Yenza ixabiso elitsha elinobuvila usebenzisa i `Default` njengomsebenzi wokuqalisa.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}