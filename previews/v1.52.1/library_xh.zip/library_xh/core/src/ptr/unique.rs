use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Isisongeli esingqonge i-`*mut T` eluhlaza engabonakalisiyo ukuba umnini wale wrapper ungumnini wakhe.
/// Iluncedo ekwakhiweni kwezinto ezinje nge `Box<T>`, `Vec<T>`, `String`, kunye ne `HashMap<K, V>`.
///
/// Ngokungafaniyo ne `*mut T`, i `Unique<T>` iziphatha i "as if" yayingumzekelo we `T`.
/// Isebenzisa i `Send`/`Sync` ukuba i `T` yi `Send`/`Sync`.
/// Ikwathetha ukuba uhlobo lwesiqinisekiso esomeleleyo siqinisekisa imeko ye `T` enokulindela:
/// Isalathiso sesikhombisi akufuneki silungiswe ngaphandle kwendlela eyahlukileyo eya kubunini bayo.
///
/// Ukuba awuqinisekanga ukuba ichanekile na ukusebenzisa i `Unique` ngeenjongo zakho, cinga ukusebenzisa i `NonNull`, eneesemantiki ezibuthathaka.
///
///
/// Ngokungafaniyo ne `*mut T`, isikhombisi kufuneka sihlale singasebenzi, nokuba isikhombisi asikaze siphinde siboniswe.
/// Kungenxa yokuba ii-enum zinokusebenzisa eli xabiso lingavumelekanga njengocalucalulo-i `Option<Unique<T>>` inobungakanani obufanayo ne `Unique<T>`.
/// Nangona kunjalo isikhombisi sisenokungxama ukuba asichazwanga.
///
/// Ngokungafaniyo ne-`*mut T`, i-`Unique<T>` i-covariant ngaphezulu kwe-`T`.
/// Oku kuya kuhlala kuchanekile kulo naluphi na uhlobo olugcina iimfuno ezizodwa zokuzikhethela.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: isiphawuli asinaziphumo zomahluko, kodwa siyimfuneko
    // ukuze i-dropck iqonde ukuba ngokwethu sinayo i-`T`.
    //
    // Ngeenkcukacha, bona:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` izikhombisi zi-`Send` ukuba i-`T` yi-`Send` kuba idatha ekubhekiswa kuyo iyabhengezwa.
/// Qaphela ukuba oku kungasokuze kunganyanzeliswa luhlobo lwenkqubo;Ukukhutshwa kusetyenziswa i `Unique` kufuneka kuyinyanzelise.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` izikhombisi zi-`Sync` ukuba i-`T` yi-`Sync` kuba idatha ekubhekiswa kuyo iyabhengezwa.
/// Qaphela ukuba oku kungasokuze kunganyanzeliswa luhlobo lwenkqubo;Ukukhutshwa kusetyenziswa i `Unique` kufuneka kuyinyanzelise.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Yenza i `Unique` entsha ejingayo, kodwa elungelelaniswe kakuhle.
    ///
    /// Oku kuluncedo ekuqaliseni iintlobo ezabiweyo ngobuvila, njenge `Vec::new`.
    ///
    /// Qaphela ukuba ixabiso lesikhombisi linokubonisa isikhombisi esisemthethweni kwi `T`, okuthetha ukuba oku akufuneki kusetyenziswe njengexabiso le-"not yet initialized" ye-sentinel.
    /// Iindidi ezabileyo ngobuvila kufuneka zilandelele ukuqaliswa ngezinye iindlela.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // UKHUSELEKO: I mem::align_of() ibuyisa isikhombisi esisemthethweni, esingasebenziyo.Inkqubo ye-
        // iimeko zokubiza i new_unchecked() ziyahlonitshwa.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Yenza i `Unique` entsha.
    ///
    /// # Safety
    ///
    /// `ptr` mayingabinanto.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `ptr` ayisiyonto ilungileyo.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Yenza i `Unique` entsha ukuba i `ptr` ayisiyonto ililize.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // UKHUSELEKO: Isikhombisi sele sihloliwe kwaye asisebenzi.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Ifumana isiseko se `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Ikhetha umxholo.
    ///
    /// Ubomi obunokubangelwa bubotshelelwe kwisiqu sakho ngenxa yoko le nto iziphatha njenge "as if" eneneni yayiyimeko ye-T ebolekwayo.
    /// Ukuba kufuneka ixesha elide le-(unbound), sebenzisa i `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyahlangabezana nazo zonke iindlela
        // iimfuno zesalathiso.
        unsafe { &*self.as_ptr() }
    }

    /// Ngokuchasene nokukhetha umxholo.
    ///
    /// Ubomi obunokubangelwa bubotshelelwe kwisiqu sakho ngenxa yoko le nto iziphatha njenge "as if" eneneni yayiyimeko ye-T ebolekwayo.
    /// Ukuba kufuneka ixesha elide le-(unbound), sebenzisa i `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyahlangabezana nazo zonke iindlela
        // iimfuno zereferensi enokutshintsha.
        unsafe { &mut *self.as_ptr() }
    }

    /// Yilahla kwisikhombisi solunye uhlobo.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // UKHUSELEKO: Unique::new_unchecked() yenza into eyahlukileyo eyahlukileyo kunye neemfuno
        // Isikhombisi esinikiweyo ukuba singasebenzi.
        // Kuba sidlula ngokwakho njengesikhombisi, ayinakuba lilize.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // UKHUSELEKO: Isalathiso esinokuguquguquka asinakusebenza
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}