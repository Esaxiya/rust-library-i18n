use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` kodwa ingeyo-zero kunye ne-covariant.
///
/// Oku kuhlala kuyinto echanekileyo yokusebenzisa xa usakha izakhiwo zedatha usebenzisa izikhombisi eziluhlaza, kodwa ekugqibeleni kuyingozi kakhulu ukusebenzisa ngenxa yeepropathi zayo ezongezelelweyo.Ukuba awuqinisekanga ukuba usebenzisa i `NonNull<T>`, sebenzisa nje i `*mut T`!
///
/// Ngokungafaniyo ne `*mut T`, isikhombisi kufuneka sihlale singasebenzi, nokuba isikhombisi asikaze siphinde siboniswe.Oku kwenzelwa ukuba ii-enum zisebenzise eli xabiso lingavumelekanga njengocalucalulo-i `Option<NonNull<T>>` inobungakanani obulinganayo ne `* mut T`.
/// Nangona kunjalo isikhombisi sisenokungxama ukuba asichazwanga.
///
/// Ngokungafaniyo ne `*mut T`, i `NonNull<T>` yakhethwa ukuba ibe yicovariant ngaphezulu kwe `T`.Oku kwenza ukuba kube nokwenzeka ukusebenzisa i-`NonNull<T>` xa usakha iintlobo ze-covariant, kodwa ukwazisa umngcipheko wokungaqiniseki ukuba usetyenziswe kuhlobo olungafanelekanga ukuba lube lu-covariant.
/// (Ukhetho oluchaseneyo lwenzelwa i `*mut T` nangona ngobuchwephesha ubuzaza bunokubangelwa kuphela kukubiza imisebenzi engakhuselekanga.)
///
/// I-Covariance ichanekile kwizinto ezininzi ezikhuselekileyo, ezinje nge `Box`, `Rc`, `Arc`, `Vec`, kunye ne `LinkedList`.Injalo imeko kuba banikezela nge-API kawonke-wonke elandela imigaqo yesiqhelo ekwabelwana ngayo yeXOR ye Rust.
///
/// Ukuba udidi lwakho alunakukhuselwa ngokukhuselekileyo, kufuneka uqiniseke ukuba unendawo eyongezelelweyo yokubonelela ngokungena.Rhoqo le ndawo iyakuba luhlobo lwe [`PhantomData`] njenge `PhantomData<Cell<T>>` okanye i `PhantomData<&'a mut T>`.
///
/// Qaphela ukuba i `NonNull<T>` ine `From` ye `&T`.Nangona kunjalo, oku akuyitshintshi inyani yokuba ukutshintsha ngokusebenzisa (isikhombisi esifunyenwe kwi) Isalathiso ekwabelwana ngaso kukuziphatha okungachazwanga ngaphandle kokuba utshintsho lwenzeka ngaphakathi kwe [`UnsafeCell<T>`].Kuyafana nokwenza ireferensi enokutshintsha ukusuka kwisalathiso ekwabelwana ngaso.
///
/// Xa usebenzisa lo mzekelo we `From` ngaphandle kwe `UnsafeCell<T>`, luxanduva lwakho ukuqinisekisa ukuba i `as_mut` ayibizwa, kwaye i `as_ptr` ayikaze isetyenziselwe utshintsho.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` izikhombisi ayisiyi-`Send` kuba idatha ekubhekiswa kuyo inokubekwa ecaleni.
// Qaphela, le impl ayimfuneko, kodwa kufuneka inikezele ngemiyalezo ephucukileyo.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` izikhombisi ayisiyi-`Sync` kuba idatha ekubhekiswa kuyo inokubekwa ecaleni.
// Qaphela, le impl ayimfuneko, kodwa kufuneka inikezele ngemiyalezo ephucukileyo.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Yenza i `NonNull` entsha ejingayo, kodwa elungelelaniswe kakuhle.
    ///
    /// Oku kuluncedo ekuqaliseni iintlobo ezabiweyo ngobuvila, njenge `Vec::new`.
    ///
    /// Qaphela ukuba ixabiso lesikhombisi linokubonisa isikhombisi esisemthethweni kwi `T`, okuthetha ukuba oku akufuneki kusetyenziswe njengexabiso le-"not yet initialized" ye-sentinel.
    /// Iindidi ezabileyo ngobuvila kufuneka zilandelele ukuqaliswa ngezinye iindlela.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // UKHUSELEKO: mem::align_of() ibuyisa usize ongezizo zero emva koko ophoswe
        // kwi * mut T.
        // Ke ngoko, i `ptr` ayisebenzi kwaye iimeko zokubiza i new_unchecked() ziyahlonitshwa.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Ibuyisa izingqinisiso ekwabelwana ngazo kwixabiso.Ngokuchasene ne-[`as_ref`], oku akufuneki ukuba ixabiso kufuneka liqaliswe.
    ///
    /// Kumlingane onokutshintsha jonga i [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqinisekise ukuba konke oku kuyinyani:
    ///
    /// * Isikhombisi kufuneka silungelelaniswe ngokufanelekileyo.
    ///
    /// * Kufuneka ibe yi-"dereferencable" ngokwendlela echazwe kwi-[the module documentation].
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///
    ///   Ngokukodwa, ixesha lokuphila, imemori yesalathi esalatha kuyo akufuneki iguqulwe (ngaphandle kwe `UnsafeCell`).
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyahlangabezana nazo zonke iindlela
        // iimfuno zesalathiso.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Ibuyisa izingqinisiso ezizodwa kwixabiso.Ngokuchasene ne-[`as_mut`], oku akufuneki ukuba ixabiso kufuneka liqaliswe.
    ///
    /// Kwiqabane ekwabelwana ngalo bona i [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqinisekise ukuba konke oku kuyinyani:
    ///
    /// * Isikhombisi kufuneka silungelelaniswe ngokufanelekileyo.
    ///
    /// * Kufuneka ibe yi-"dereferencable" ngokwendlela echazwe kwi-[the module documentation].
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///
    ///   Ngokukodwa, ixesha lokuphila, imemori isikhombisi esikhomba kuso kufuneka singafikeleli (sifunde okanye sibhalwe) ngayo nayiphi na enye isikhombisi.
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyahlangabezana nazo zonke iindlela
        // iimfuno zesalathiso.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Yenza i `NonNull` entsha.
    ///
    /// # Safety
    ///
    /// `ptr` mayingabinanto.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `ptr` ayisiyonto ilungileyo.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Yenza i `NonNull` entsha ukuba i `ptr` ayisiyonto ililize.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // UKHUSELEKO: Isikhombisi sele sihloliwe kwaye asisebenzi
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Yenza ukusebenza okufanayo ne [`std::ptr::from_raw_parts`], ngaphandle kokuba isikhombisi se `NonNull` sibuyisiwe, ngokuchasene nesikhombisi se `*const` eluhlaza.
    ///
    ///
    /// Bona amaxwebhu e [`std::ptr::from_raw_parts`] ngolwazi oluthe kratya.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // UKHUSELEKO: Iziphumo ze `ptr::from::raw_parts_mut` azisebenzi ngenxa yokuba i `data_address` iyi.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Ukubola isikhombisi (ngokunokwenzeka sibanzi) kwidilesi kunye neemetadatha.
    ///
    /// Isikhombisi sinokwakhiwa kwakhona nge [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Ifumana isiseko se `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Ibuyisa ireferensi ekwabelwana ngayo kwixabiso.Ukuba ixabiso alinakuqaliswa, kufuneka kusetyenziswe i [`as_uninit_ref`] endaweni yoko.
    ///
    /// Kumlingane onokutshintsha jonga i [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqinisekise ukuba konke oku kuyinyani:
    ///
    /// * Isikhombisi kufuneka silungelelaniswe ngokufanelekileyo.
    ///
    /// * Kufuneka ibe yi-"dereferencable" ngokwendlela echazwe kwi-[the module documentation].
    ///
    /// * Isikhombisi kufuneka sikhombe kumzekelo wokuqala we `T`.
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///
    ///   Ngokukodwa, ixesha lokuphila, imemori yesalathi esalatha kuyo akufuneki iguqulwe (ngaphandle kwe `UnsafeCell`).
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    /// (Inxalenye malunga nokuqaliswa ayikagqitywa ngokupheleleyo, kodwa kude kube ngoku, ekuphela kwendlela ekhuselekileyo kukuqinisekisa ukuba bayasungulwa ngenene.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyahlangabezana nazo zonke iindlela
        // iimfuno zesalathiso.
        unsafe { &*self.as_ptr() }
    }

    /// Ibuyisa ireferensi eyahlukileyo kwixabiso.Ukuba ixabiso alinakuqaliswa, kufuneka kusetyenziswe i [`as_uninit_mut`] endaweni yoko.
    ///
    /// Kwiqabane ekwabelwana ngalo bona i [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqinisekise ukuba konke oku kuyinyani:
    ///
    /// * Isikhombisi kufuneka silungelelaniswe ngokufanelekileyo.
    ///
    /// * Kufuneka ibe yi-"dereferencable" ngokwendlela echazwe kwi-[the module documentation].
    ///
    /// * Isikhombisi kufuneka sikhombe kumzekelo wokuqala we `T`.
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///
    ///   Ngokukodwa, ixesha lokuphila, imemori isikhombisi esikhomba kuso kufuneka singafikeleli (sifunde okanye sibhalwe) ngayo nayiphi na enye isikhombisi.
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    /// (Inxalenye malunga nokuqaliswa ayikagqitywa ngokupheleleyo, kodwa kude kube ngoku, ekuphela kwendlela ekhuselekileyo kukuqinisekisa ukuba bayasungulwa ngenene.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyahlangabezana nazo zonke iindlela
        // iimfuno zereferensi enokutshintsha.
        unsafe { &mut *self.as_ptr() }
    }

    /// Yilahla kwisikhombisi solunye uhlobo.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // UKHUSELEKO: I `self` sisikhombisi se `NonNull` esinganyanzelekanga
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Yenza isilayidi esiluhlaza esingasasebenziyo esivela kwisikhombisi esincinci kunye nobude.
    ///
    /// Impikiswano ye `len` linani lezinto eziyi **, hayi inani lee-byte.
    ///
    /// Lo msebenzi ukhuselekile, kodwa ukungabhekiseli kwixabiso lokubuyisa akukhuselekanga.
    /// Jonga amaxwebhu e [`slice::from_raw_parts`] ukulungiselela iimfuno zokhuselo lwesilayidi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // yenza isikhombisi sesilayidi xa uqala ngesikhombisi kwinto yokuqala
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Qaphela ukuba lo mzekelo ubonakalisa ukusetyenziswa kwale ndlela, kodwa` slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // UKHUSELEKO: I `data` sisikhombisi se `NonNull` esinganyanzelekanga
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Ibuyisa ubude besilayidi esingasasebenziyo esiluhlaza.
    ///
    /// Ixabiso elibuyiselweyo linani lezinto **, hayi inani lee-byte.
    ///
    /// Lo msebenzi ukhuselekile, nokuba isilayidi esiluhlaza esingasasebenziyo asinakuphinda senziwe kwisilayidi kuba isalathiso asinayo idilesi efanelekileyo.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Ibuyisa isikhombisi esingasebenziyo kwisilayidi sesilayidi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // UKHUSELEKO: Siyazi ukuba i `self` ayisiyiyo.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Ibuyisa isikhombisi esiluhlaza kwisikhuseli sesilayi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Ibuyisa ireferensi ekwabelwana ngayo kwisilayidi samaxabiso anokungaqaliswa.Ngokuchasene ne-[`as_ref`], oku akufuneki ukuba ixabiso kufuneka liqaliswe.
    ///
    /// Kumlingane onokutshintsha jonga i [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqinisekise ukuba konke oku kuyinyani:
    ///
    /// * Isikhombisi kufuneka sibe yi-[valid] ukuze ifundelwe i-`ptr.len() * mem::size_of::<T>()` ii-byte ezininzi, kwaye kufuneka zilungelelaniswe ngokufanelekileyo.Oku kuthetha ngokukodwa:
    ///
    ///     * Uluhlu lonke lwenkumbulo yesi silayi kufuneka siqulathwe kwinto enye eyabelweyo!
    ///       Iziqwenga azinakuze zijikeleze izinto ezininzi ezabiweyo.
    ///
    ///     * Isikhombisi kufuneka silungelelaniswe nakwizilayi ezide.
    ///     Isizathu esinye soku kukuba ulungelelwaniso lwe-enum lunokuxhomekeka kwizalathiso (kubandakanya izilayi zobuphi na ubude) zilungelelaniswe kwaye zingabinanto ukwahlulahlula kwezinye idatha.
    ///
    ///     Unokufumana isikhombisi esinokusetyenziswa njenge-`data` kwizilayi ezide zobude usebenzisa i [`NonNull::dangling()`].
    ///
    /// * Ubungakanani bebonke be-`ptr.len() * mem::size_of::<T>()` yesilayidi kufuneka kungabikho ngaphezulu kwe `isize::MAX`.
    ///   Jonga amaxwebhu okhuseleko e [`pointer::offset`].
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///   Ngokukodwa, ixesha lokuphila, imemori yesalathi esalatha kuyo akufuneki iguqulwe (ngaphandle kwe `UnsafeCell`).
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    ///
    /// Jonga kwakhona i [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Ibuyisa ireferensi eyahlukileyo kwisilayidi esinexabiso elingenasiseko.Ngokuchasene ne-[`as_mut`], oku akufuneki ukuba ixabiso kufuneka liqaliswe.
    ///
    /// Kwiqabane ekwabelwana ngalo bona i [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqinisekise ukuba konke oku kuyinyani:
    ///
    /// * Isikhombisi kufuneka sibe yi-[valid] yokufunda kwaye sibhalele i-`ptr.len() * mem::size_of::<T>()` ii-byte ezininzi, kwaye kufuneka zilungelelaniswe ngokufanelekileyo.Oku kuthetha ngokukodwa:
    ///
    ///     * Uluhlu lonke lwenkumbulo yesi silayi kufuneka siqulathwe kwinto enye eyabelweyo!
    ///       Iziqwenga azinakuze zijikeleze izinto ezininzi ezabiweyo.
    ///
    ///     * Isikhombisi kufuneka silungelelaniswe nakwizilayi ezide.
    ///     Isizathu esinye soku kukuba ulungelelwaniso lwe-enum lunokuxhomekeka kwizalathiso (kubandakanya izilayi zobuphi na ubude) zilungelelaniswe kwaye zingabinanto ukwahlulahlula kwezinye idatha.
    ///
    ///     Unokufumana isikhombisi esinokusetyenziswa njenge-`data` kwizilayi ezide zobude usebenzisa i [`NonNull::dangling()`].
    ///
    /// * Ubungakanani bebonke be-`ptr.len() * mem::size_of::<T>()` yesilayidi kufuneka kungabikho ngaphezulu kwe `isize::MAX`.
    ///   Jonga amaxwebhu okhuseleko e [`pointer::offset`].
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///   Ngokukodwa, ixesha lokuphila, imemori isikhombisi esikhomba kuso kufuneka singafikeleli (sifunde okanye sibhalwe) ngayo nayiphi na enye isikhombisi.
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    ///
    /// Jonga kwakhona i [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Oku kukhuselekile njengoko i `memory` isebenza ngokufundwayo kwaye ibhalela i `memory.len()` ii-byte ezininzi.
    /// // Qaphela ukuba ukubiza i-`memory.as_mut()` akuvumelekanga apha njengoko umxholo unokuba ungachazwanga.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Ibuyisa isikhombisi esiluhlaza kwinto ethile okanye kwintengiso, ngaphandle kokujonga imida.
    ///
    /// Ukutsalela umnxeba le ndlela ngesalathiso esingaphandle kwemida okanye xa i `self` ingafakwanga kubhekiswa kuyo *[isimilo esingachazwanga]* nokuba isikhombisi esisiphumo asisetyenziswanga.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // UKHUSELEKO: umntu ofowunayo uqinisekisa ukuba i `self` ayinakuphinda yenziwe kwaye i `index` iyangena.
        // Ngenxa yoko, isikhombisi esisiphumo asinakuba yi-NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // UKHUSELEKO: Isikhombisi esahlukileyo asinakuba lilize, ke iimeko ze
        // new_unchecked() ziyahlonitshwa.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // UKHUSELEKO: Isalathiso esinokuguquguquka asinakusebenza.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // UKHUSELEKO: Isalathiso asinakho ukungasebenzi, ke iimeko ze
        // new_unchecked() ziyahlonitshwa.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}