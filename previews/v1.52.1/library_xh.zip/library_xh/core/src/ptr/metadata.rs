#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Inikezela ngesikhombisi sohlobo lweemethadatha zalo naluphi na uhlobo oluchaziweyo.
///
/// # Isikhombisi sedatha
///
/// Iindidi zesikhombisi eluhlaza kunye neentlobo zesalathiso kwi Rust zinokucingelwa njengezenziwe ngamacandelo amabini:
/// Isikhombisi sedatha esineedilesi zememori zexabiso, kunye nemethadatha ethile.
///
/// Kwiindidi ezinobungakanani ngokwezibalo (ezisebenzisa i `Sized` traits) kunye neentlobo ze `extern`, izikhombisi kuthiwa "zibhityile": imethadatha ilingene zero kwaye uhlobo lwayo yi `()`.
///
///
/// Izikhombisi eziya kwi [dynamically-sized types][dst] kuthiwa "zibanzi" okanye "zityebile", zinemethadatha engalinganiyo.
///
/// * Ukulungiselela intsimi yayo yokugqibela yi-DST, imethadatha yimethadatha yentsimi yokugqibela
/// * Ngohlobo lwe `str`, imethadatha ubude kwii-byte njenge-`usize`
/// * Kwiintlobo zesilayidi ezinje nge `[T]`, imethadatha ubude bezinto njenge `usize`
/// * Izinto ze-trait ezinje nge `dyn SomeTrait`, imethadatha yi-[`DynMetadata<Self>`][DynMetadata] (umz. `DynMetadata<dyn SomeTrait>`)
///
/// Kwi-future, ulwimi lwe-Rust lunokufumana iintlobo ezintsha zeentlobo ezineemethadatha zesikhombisi esahlukileyo.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Inqaku lale trait luhlobo lwayo oluhambelana ne `Metadata`, eyi `()` okanye i `usize` okanye i `DynMetadata<_>` njengoko kuchaziwe apha ngasentla.
/// Yenziwa ngokuzenzekelayo kuzo zonke iintlobo.
/// Inokucingelwa ukuba iphunyezwe kwimeko yesiqhelo, nangaphandle kokubopha okuhambelanayo.
///
/// # Usage
///
/// Izikhombisi eziluhlaza zinokuchithwa kwidilesi yedatha kunye nezinto zemethadatha ngendlela yazo ye [`to_raw_parts`].
///
/// Ngenye indlela, imethadatha kuphela inokukhutshwa kunye nomsebenzi we [`metadata`].
/// Isalathiso singadluliselwa kwi [`metadata`] kwaye sinyanzeliswe ngokungagungqiyo.
///
/// Isikhombisi se (possibly-wide) sinokuphinda sibuyiselwe kunye kwidilesi yayo kunye nemethadatha ene [`from_raw_parts`] okanye i [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Uhlobo lweemethadatha kwizikhombisi kunye nezalathiso kwi `Self`.
    #[lang = "metadata_type"]
    // NOTE: Gcina i-trait bounds kwi `static_assert_expected_bounds_for_metadata`
    //
    // kwi `library/core/src/ptr/metadata.rs` ngokuvumelanisa nala alapha:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Izikhombisi kwiindidi zokuphumeza le trait alias "zibhityile".
///
/// Oku kubandakanya iintlobo ze-statistic-`Sized` kunye ne-`extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: sukuzinzisa oku ngaphambi kokuba ii-ali0 ze-trait zizinze kulwimi?
pub trait Thin = Pointee<Metadata = ()>;

/// Ukukhupha icandelo lemethadatha yesikhombisi.
///
/// Amaxabiso ohlobo `*mut T`, `&T`, okanye `&mut T` angadluliselwa ngokuthe ngqo kulo msebenzi njengoko enyanzelisa i `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // UKHUSELEKO: Ukufikelela kwixabiso kumanyano we `PtrRepr` kukhuselekile ukusukela * const T
    // kunye nePtrComponents<T>ubeko lwenkumbulo olufanayo.
    // std kuphela enokwenza esi siqinisekiso.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Yenza i-(possibly-wide) pointer eluhlaza kwidilesi yedatha kunye nemethadatha.
///
/// Lo msebenzi ukhuselekile kodwa isikhombisi esibuyisiweyo asikhuselekanga ekuchazeni.
/// Kwizilayi, jonga amaxwebhu e [`slice::from_raw_parts`] malunga neemfuno zokhuseleko.
/// Izinto ze-trait, imethadatha kufuneka ivele kwisikhombisi siye kuhlobo olufanayo lokunciphisa.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // UKHUSELEKO: Ukufikelela kwixabiso kumanyano we `PtrRepr` kukhuselekile ukusukela * const T
    // kunye nePtrComponents<T>ubeko lwenkumbulo olufanayo.
    // std kuphela enokwenza esi siqinisekiso.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Yenza ukusebenza okufanayo ne [`from_raw_parts`], ngaphandle kokuba isikhombisi se `*mut` eluhlaza sibuyisiwe, ngokuchasene nesikhombisi se `* const` eluhlaza.
///
///
/// Bona amaxwebhu e [`from_raw_parts`] ngolwazi oluthe kratya.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // UKHUSELEKO: Ukufikelela kwixabiso kumanyano we `PtrRepr` kukhuselekile ukusukela * const T
    // kunye nePtrComponents<T>ubeko lwenkumbulo olufanayo.
    // std kuphela enokwenza esi siqinisekiso.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Ukunyanzeliswa kwemanyuwali kuyadingeka ukunqanda ukubopha kwe `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Ukunyanzeliswa kwemanyuwali kuyadingeka ukunqanda ukubopha kwe `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Imethadatha yohlobo lwento eyi-`Dyn = dyn SomeTrait` trait.
///
/// Sisikhombisi esivelisayo (itafile yefowuni ebonakalayo) emele lonke ulwazi oluyimfuneko lokusebenzisa uhlobo lwekhonkrithi eligcinwe ngaphakathi kwento ye trait.
/// I-vtable ebonakalayo iqulathe:
///
/// * uhlobo lobungakanani
/// * ulungelelwaniso lohlobo
/// * Isikhombisi kuhlobo lwe-`drop_in_place` impl (isenokungabikho-op kwidatha-endala-yedatha)
/// * izikhombisi kuzo zonke iindlela zokuphunyezwa kohlobo lwe trait
///
/// Qaphela ukuba ezintathu zokuqala zikhethekile kuba ziyimfuneko ukwaba, ukulahla, kunye nokuhambisa nayiphi na into ye trait.
///
/// Kuyenzeka ukuba ubize olu lwakhiwo ngohlobo lweparadesi engeyiyo i `dyn` trait (umzekelo `DynMetadata<u64>`) kodwa ungafumani ixabiso elifanelekileyo lolwakhiwo.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Isimaphambili esiqhelekileyo sazo zonke i-vtable.Ilandelwa zizikhombisi zomsebenzi zeendlela ze trait.
///
/// Iinkcukacha zokuphunyezwa kwangasese kwe `DynMetadata::size_of` njl.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Ibuyisa ubungakanani bohlobo oludityaniswe nale vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Ibuyisa ulungelelwaniso lohlobo olunxulumene nale vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Ibuyisa ubungakanani kunye nokulungelelana kunye njenge `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // UKHUSELEKO: umhlanganisi ukhuphe le vtable yohlobo lwe-Rust ephathekayo
        // yaziwa ngokuba nobeko olusebenzayo.Isizathu esifanayo ne-`Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Iimpawu ze-Manual ziyafuneka ukunqanda umda we `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}