use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Ibuyisa i `true` ukuba isikhombisi asisebenzi.
    ///
    /// Qaphela ukuba iintlobo ezingalinganiswanga zinezikhombisi ezininzi ezingenanto, kuba sisikhombisi sedatha eluhlaza esiqwalaselweyo, hayi ubude baso, vtable, njl.
    /// Ke ngoko, izikhombisi ezibini ezingasebenziyo zisenokungathelekisi zilingane.
    ///
    /// ## Ukuziphatha ngexesha lokuvavanywa komgaqo
    ///
    /// Xa lo msebenzi usetyenzisiwe ngexesha lovavanyo lwe-const, unokubuyisa i `false` kwizikhombisi eziya kuthi zingasebenzi ngexesha lokubaleka.
    /// Ngokukodwa, xa isikhombisi kwimemori ethile sisuswe ngaphaya kwemida yaso ngendlela yokuba isikhombisi esiphumeleleyo asisebenzi, umsebenzi uya kubuya u-`false`.
    ///
    /// Akukho ndlela ye-CTFE yokwazi eyona ndawo imemori, ngenxa yoko asinakuxela ukuba isikhombisi asisebenzi okanye hayi.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Thelekisa nge-cast kwisikhombisi esincinci, ke izikhombisi ezityebileyo zijonga kuphela i-"data" yenxalenye ye-null-ness.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Yilahla kwisikhombisi solunye uhlobo.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Ukubola isikhombisi (ngokunokwenzeka sibanzi) kwidilesi kunye neemetadatha.
    ///
    /// Isikhombisi sinokwakhiwa kwakhona nge [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Ibuyisa i `None` ukuba isikhombisi asisebenzi, okanye enye into ibuyisela ireferensi ekwabelwana ngayo kwixabiso elisongelwe kwi `Some`.Ukuba ixabiso alinakuqaliswa, kufuneka kusetyenziswe i [`as_uninit_ref`] endaweni yoko.
    ///
    /// Kumlingane onokutshintsha jonga i [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqiniseke ukuba *nokuba sisikhombisi asinguNULL* okanye * konke oku kulandelayo kuyinyani:
    ///
    /// * Isikhombisi kufuneka silungelelaniswe ngokufanelekileyo.
    ///
    /// * Kufuneka ibe yi-"dereferencable" ngokwendlela echazwe kwi-[the module documentation].
    ///
    /// * Isikhombisi kufuneka sikhombe kumzekelo wokuqala we `T`.
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///   Ngokukodwa, ixesha lokuphila, imemori yesalathi esalatha kuyo akufuneki iguqulwe (ngaphandle kwe `UnsafeCell`).
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    /// (Inxalenye malunga nokuqaliswa ayikagqitywa ngokupheleleyo, kodwa kude kube ngoku, ekuphela kwendlela ekhuselekileyo kukuqinisekisa ukuba bayasungulwa ngenene.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Inguqulelo engakhange ihlolwe
    ///
    /// Ukuba uqinisekile ukuba isikhombisi asinakuze singasebenzi kwaye ujonge uhlobo oluthile lwe `as_ref_unchecked` olubuyisela i `&T` endaweni ye `Option<&T>`, yazi ukuba ungasikhomba kwakhona isikhombisi ngokuthe ngqo.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` isebenza ngokusemthethweni
        // Isalathiso ukuba ayisebenzi.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Ibuyisa i `None` ukuba isikhombisi asisebenzi, okanye enye into ibuyisela ireferensi ekwabelwana ngayo kwixabiso elisongelwe kwi `Some`.
    /// Ngokuchasene ne-[`as_ref`], oku akufuneki ukuba ixabiso kufuneka liqaliswe.
    ///
    /// Kumlingane onokutshintsha jonga i [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqiniseke ukuba *nokuba sisikhombisi asinguNULL* okanye * konke oku kulandelayo kuyinyani:
    ///
    /// * Isikhombisi kufuneka silungelelaniswe ngokufanelekileyo.
    ///
    /// * Kufuneka ibe yi-"dereferencable" ngokwendlela echazwe kwi-[the module documentation].
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///
    ///   Ngokukodwa, ixesha lokuphila, imemori yesalathi esalatha kuyo akufuneki iguqulwe (ngaphandle kwe `UnsafeCell`).
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyahlangabezana nazo zonke iindlela
        // iimfuno zesalathiso.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ibala isilinganisi esivela kwisikhombisi.
    ///
    /// `count` ikwiiyunithi zika-T;Umzekelo, i `count` ka-3 imele isalathiso esingumfuziselo nge-`3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Ukuba kukho nayiphi na kwezi meko iphuliweyo, isiphumo kukungaziphathi kakuhle:
    ///
    /// * Zombini isikhombisi sokuqala kunye nesiphumo kufuneka sibe kwimida okanye kwi-byte enye emva kokuphela kwento eyabelweyo.
    /// Qaphela ukuba kwi-Rust, yonke into eyahlukileyo ye (stack-allocated) ithathwa njengento eyahlukileyo eyabiweyo.
    ///
    /// * Icompset offset,**kwii-byte**, ayinakudlula kwi `isize`.
    ///
    /// * Ukuseta kwimida akunakuxhomekeka kwi "wrapping around" kwindawo yedilesi.Oko kukuthi, isilinganiselo esingapheliyo sokuchaneka,**kwii-byte** kufuneka zilungele usize.
    ///
    /// Umhlanganisi kunye nethala leencwadi eliqhelekileyo ngokubanzi lizama ukuqinisekisa ukuba ulwabiwo alufikeleli kubungakanani apho iseti yinto exhalabisayo.
    /// Umzekelo, i `Vec` kunye ne `Box` baqinisekisa ukuba abaze babeke ngaphezulu kwe-`isize::MAX` byte, ke i `vec.as_ptr().add(vec.len())` ihlala ikhuselekile.
    ///
    /// Uninzi lwamaqonga ngokusisiseko alunakho nokwakha ulwabiwo olunjalo.
    /// Umzekelo, akukho qonga le-64-bit laziwayo linokuze lenze isicelo <sup>see-</sup> byte <sup>ezingama-</sup> 2 <sup>63</sup> ngenxa yokuncitshiswa kwetafile yamaphepha okanye ukwahlula indawo yedilesi.
    /// Nangona kunjalo, amaqonga ama-32-bit kunye ne-16-bit amaqonga anokusebenza ngempumelelo kwisicelo esingaphezulu kwe-`isize::MAX` byte ngezinto ezinjengeDilesi yePhysical Extension.
    ///
    /// Kananjalo, inkumbulo efunyenwe ngokuthe ngqo kubanikezeli okanye kwiifayile ezibhalwe kwimemori *inokuba* inkulu kakhulu ukuba ingaphathwa ngalo msebenzi.
    ///
    /// Cinga ukusebenzisa i [`wrapping_offset`] endaweni yokuba ezi ngxaki zinzima ukuzanelisa.
    /// Olona luhle kuphela kule ndlela kukuba yenza ukuba ulungelelwaniso lomdibaniso olunobukrakra ngakumbi.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `offset`.
        // Isalathiso esifunyenweyo sisebenza ngokubhaliweyo kuba umntu ofowunayo kufuneka aqinisekise ukuba yalatha kwinto enye eyabelweyo njenge `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Ibala isilinganisi esisuka kwisikhombisi usebenzisa usongelo lwezibalo.
    /// `count` ikwiiyunithi zika-T;Umzekelo, i `count` ka-3 imele isalathiso esingumfuziselo nge-`3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Lo msebenzi ngokwawo uhlala ukhuselekile, kodwa ukusebenzisa isikhombisi esiphumela akunjalo.
    ///
    /// Isikhombisi esisiphumo sihlala siqhotyoshelwe kwinto enye eyabelweyo eyalatha kuyo i `self`.
    /// Isenokungasetyenziselwa ukufikelela kwinto eyabiweyo eyahlukileyo.Qaphela ukuba kwi-Rust, yonke into eyahlukileyo ye (stack-allocated) ithathwa njengento eyahlukileyo eyabiweyo.
    ///
    /// Ngamanye amagama, i-`let z = x.wrapping_offset((y as isize) - (x as isize))` ayenzi * i-`z` ifane ne-`y` nokuba sicinga ukuba i-`T` inobungakanani be-`1` kwaye akukho kuphuphuma: I-`z` isancanyathiselwe kwinto engu-`x` incanyathiselwe kuyo, kwaye ukuyichaza ukuba ayizichazanga indlela yokuziphatha ngaphandle kwe `x` kunye `y` yalatha kwinto enye eyabelweyo.
    ///
    /// Xa kuthelekiswa ne-[`offset`], le ndlela icothisa imfuno yokuhlala kwinto enye eyabelweyo: [`offset`] kukuziphatha okungachazwanga kwangoko xa uwela imida yento;I-`wrapping_offset` ivelisa isikhombisi kodwa isakhokelela kwiNdlela yokuNgazichazi ukuba isikhombisi asichazwanga xa singaphandle kwemida yento encanyathiselwe kuyo.
    /// [`offset`] inokulungiswa ngcono kwaye ngenxa yoko ikhethwe kwikhowudi ebuthathaka ekusebenzeni.
    ///
    /// Ukutsala okulibazisekileyo kuthathela ingqalelo kuphela ixabiso lesikhombisi ebelichaziwe, hayi amaxabiso aphakathi asetyenzisiweyo ngexesha lokudityaniswa kwesiphumo sokugqibela.
    /// Umzekelo, i `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` ihlala ifana ne `x`.Ngamanye amagama, ukushiya into eyabelweyo kwaye uphinde ungene kwakhona emva kwexesha kuvunyelwe.
    ///
    /// Ukuba ufuna ukuwela imida yento, phosa isalathiso kwinani elipheleleyo kwaye wenze izibalo apho.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // Iterate usebenzisa isikhombisi eluhlaza ekonyuseni izinto ezimbini
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // UKHUSELEKO: i-`arith_offset` intrinsic ayinazo iimfuneko zokubizwa.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Ibuyisa i `None` ukuba isikhombisi asisebenzi, okanye enye into ibuyisela ireferensi eyahlukileyo kwixabiso elisongelwe kwi `Some`.Ukuba ixabiso alinakuqaliswa, kufuneka kusetyenziswe i [`as_uninit_mut`] endaweni yoko.
    ///
    /// Kwiqabane ekwabelwana ngalo bona i [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqiniseke ukuba *nokuba sisikhombisi asinguNULL* okanye * konke oku kulandelayo kuyinyani:
    ///
    /// * Isikhombisi kufuneka silungelelaniswe ngokufanelekileyo.
    ///
    /// * Kufuneka ibe yi-"dereferencable" ngokwendlela echazwe kwi-[the module documentation].
    ///
    /// * Isikhombisi kufuneka sikhombe kumzekelo wokuqala we `T`.
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///   Ngokukodwa, ixesha lokuphila, imemori isikhombisi esikhomba kuso kufuneka singafikeleli (sifunde okanye sibhalwe) ngayo nayiphi na enye isikhombisi.
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    /// (Inxalenye malunga nokuqaliswa ayikagqitywa ngokupheleleyo, kodwa kude kube ngoku, ekuphela kwendlela ekhuselekileyo kukuqinisekisa ukuba bayasungulwa ngenene.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Iyakuprinta: "[4, 2, 3]".
    /// ```
    ///
    /// # Inguqulelo engakhange ihlolwe
    ///
    /// Ukuba uqinisekile ukuba isikhombisi asinakuze singasebenzi kwaye ujonge uhlobo oluthile lwe `as_mut_unchecked` olubuyisela i `&mut T` endaweni ye `Option<&mut T>`, yazi ukuba ungasikhomba kwakhona isikhombisi ngokuthe ngqo.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Iyakuprinta: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyasebenza
        // ireferensi enokutshintsha ukuba ayisebenzi.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Ibuyisa i `None` ukuba isikhombisi asisebenzi, okanye enye into ibuyisela ireferensi eyahlukileyo kwixabiso elisongelwe kwi `Some`.
    /// Ngokuchasene ne-[`as_mut`], oku akufuneki ukuba ixabiso kufuneka liqaliswe.
    ///
    /// Kwiqabane ekwabelwana ngalo bona i [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqiniseke ukuba *nokuba sisikhombisi asinguNULL* okanye * konke oku kulandelayo kuyinyani:
    ///
    /// * Isikhombisi kufuneka silungelelaniswe ngokufanelekileyo.
    ///
    /// * Kufuneka ibe yi-"dereferencable" ngokwendlela echazwe kwi-[the module documentation].
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///
    ///   Ngokukodwa, ixesha lokuphila, imemori isikhombisi esikhomba kuso kufuneka singafikeleli (sifunde okanye sibhalwe) ngayo nayiphi na enye isikhombisi.
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `self` iyahlangabezana nazo zonke iindlela
        // iimfuno zesalathiso.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Ibuyisa ukuba ngaba izikhombisi ezimbini ziqinisekisiwe ukuba ziyalingana.
    ///
    /// Ngexesha lokubaleka lo msebenzi uziphatha njenge `self == other`.
    /// Nangona kunjalo, kweminye imixholo (umz., Uvandlakanyo lwexesha), akusoloko kunokwenzeka ukumisela ukulingana kwezikhombisi ezibini, ke lo msebenzi unokubuyisa ngobunono i `false` yezikhombisi eziya kuthi kamva zilingane.
    ///
    /// Kodwa xa ibuyisa i `true`, izikhombisi ziqinisekisiwe ukuba zilingana.
    ///
    /// Lo msebenzi sisipili se [`guaranteed_ne`], kodwa hayi okungafaniyo.Kukho uthelekiso lwesikhombisi ekuthi kuyo yomibini imisebenzi ibuyise i `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Ixabiso lokubuya linokutshintsha kuxhomekeka kuhlobo lwekhomishini kwaye ikhowudi engakhuselekanga ayinakuxhomekeka kwisiphumo salo msebenzi ukuze ube nesandi.
    /// Kuyacetyiswa ukuba kusetyenzwe kuphela lo msebenzi ukulungiselela ukwenziwa kokusebenza apho i-`false` yokubuya yamaxabiso ngalo msebenzi ingachaphazeli isiphumo, kodwa ukusebenza kuphela.
    /// Iziphumo zokusebenzisa le ndlela ukwenza ixesha lokubaleka kunye nekhowudi yexesha lokuziphatha ngendlela eyahlukileyo azange ziphononongwe.
    /// Le ndlela akufuneki isetyenziselwe ukwazisa umahluko, kwaye ayizinziswa ngaphambi kokuba siwuqonde ngcono lo mba.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Ukubuyisa nokuba izikhombisi ezimbini ziqinisekisiwe ukuba azilingani.
    ///
    /// Ngexesha lokubaleka lo msebenzi uziphatha njenge `self != other`.
    /// Nangona kunjalo, kweminye imixholo (umz., Uvandlakanyo lwexesha), akusoloko kunokwenzeka ukumisela ukungalingani kwezikhombisi ezibini, ke lo msebenzi unokubuyisa ngokungathandabuzekiyo i `false` kwizikhombisi eziya kuthi kamva zingalingani.
    ///
    /// Kodwa xa ibuyisa i `true`, izikhombisi ziqinisekisiwe ukuba azilingani.
    ///
    /// Lo msebenzi sisipili se [`guaranteed_eq`], kodwa hayi okungafaniyo.Kukho uthelekiso lwesikhombisi ekuthi kuyo yomibini imisebenzi ibuyise i `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Ixabiso lokubuya linokutshintsha kuxhomekeka kuhlobo lwekhomishini kwaye ikhowudi engakhuselekanga ayinakuxhomekeka kwisiphumo salo msebenzi ukuze ube nesandi.
    /// Kuyacetyiswa ukuba kusetyenzwe kuphela lo msebenzi ukulungiselela ukwenziwa kokusebenza apho i-`false` yokubuya yamaxabiso ngalo msebenzi ingachaphazeli isiphumo, kodwa ukusebenza kuphela.
    /// Iziphumo zokusebenzisa le ndlela ukwenza ixesha lokubaleka kunye nekhowudi yexesha lokuziphatha ngendlela eyahlukileyo azange ziphononongwe.
    /// Le ndlela akufuneki isetyenziselwe ukwazisa umahluko, kwaye ayizinziswa ngaphambi kokuba siwuqonde ngcono lo mba.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Ubala umgama phakathi kwezikhombisi ezibini.Ixabiso elibuyisiweyo likwiiyunithi ze-T: umgama kwii-byte wahlulwe nge-`mem::size_of::<T>()`.
    ///
    /// Lo msebenzi uguqulweyo nge [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Ukuba kukho nayiphi na kwezi meko iphuliweyo, isiphumo kukungaziphathi kakuhle:
    ///
    /// * Zombini ezokuqala kunye nesinye isikhombisi kufuneka zibe kwimida okanye nge-byte enye emva kokuphela kwento efanayo eyabelweyo.
    /// Qaphela ukuba kwi-Rust, yonke into eyahlukileyo ye (stack-allocated) ithathwa njengento eyahlukileyo eyabiweyo.
    ///
    /// * Zombini izikhombisi kufuneka zenziwe * kwisikhombisi kwinto enye.
    ///   (Jonga apha ngezantsi umzekelo.)
    ///
    /// * Umgama phakathi kwezikhombisi, kwii-byte, kufuneka ubephindaphindeke ngokuthe ngqo kubungakanani be `T`.
    ///
    /// * Umgama phakathi kwezikhombisi,**kwii-byte**, awunakudlula kwi `isize`.
    ///
    /// * Umgama okwimida awunakuxhomekeka kwi "wrapping around" kwindawo yedilesi.
    ///
    /// Iindidi ze-Rust azikaze zibe nkulu kune-`isize::MAX` kunye nolwabiwo lwe-Rust aluzange lusongele indawo yedilesi, ke izikhombisi ezibini ngaphakathi kwexabiso lalo naluphi na uhlobo lwe-Rust `T` ziya kuhlala ziyanelisa iimeko ezimbini zokugqibela.
    ///
    /// Ithala lencwadi eliqhelekileyo likwaqinisekisa ngokubanzi ukuba ulwabiwo alusoze lufikelele kubungakanani apho iseti yinto exabisekileyo.
    /// Umzekelo, i `Vec` kunye ne `Box` baqinisekisa ukuba abaze babeke ngaphezulu kwe-`isize::MAX` byte, ke i `ptr_into_vec.offset_from(vec.as_ptr())` ihlala yanelisa iimeko ezimbini zokugqibela.
    ///
    /// Uninzi lwamaqonga ngokusisiseko alunakho nokwakha ulwabiwo olukhulu kangako.
    /// Umzekelo, akukho qonga le-64-bit laziwayo linokuze lenze isicelo <sup>see-</sup> byte <sup>ezingama-</sup> 2 <sup>63</sup> ngenxa yokuncitshiswa kwetafile yamaphepha okanye ukwahlula indawo yedilesi.
    /// Nangona kunjalo, amaqonga ama-32-bit kunye ne-16-bit amaqonga anokusebenza ngempumelelo kwisicelo esingaphezulu kwe-`isize::MAX` byte ngezinto ezinjengeDilesi yePhysical Extension.
    /// Kananjalo, inkumbulo efunyenwe ngokuthe ngqo kubanikezeli okanye kwiifayile ezibhalwe kwimemori *inokuba* inkulu kakhulu ukuba ingaphathwa ngalo msebenzi.
    /// (Qaphela ukuba i [`offset`] kunye ne [`add`] nazo zinomda ofanayo kwaye ngenxa yoko azinakusetyenziswa kulwabiwo olukhulu kangako.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Lo msebenzi yi-panics ukuba i-`T` luhlobo olulinganiswa ngeZero ("ZST").
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Ukusetyenziswa okungalunganga *:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Yenza ptr2_enye i "alias" ye ptr2, kodwa ivela kwi ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Kuba i-ptr2_other kunye ne-ptr2 zithathwe kwizikhombisi ukuya kwizinto ezahlukeneyo, ikhompyuter yabo kukungaziphathi kakuhle, nangona besalatha kwidilesi enye!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Ukuziphatha okungachazwanga
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Ibala isisiqalo ukusuka kwisikhombisi (uncedo kwi `.offset(count as isize)`).
    ///
    /// `count` ikwiiyunithi zika-T;Umzekelo, i `count` ka-3 imele isalathiso esingumfuziselo nge-`3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Ukuba kukho nayiphi na kwezi meko iphuliweyo, isiphumo kukungaziphathi kakuhle:
    ///
    /// * Zombini isikhombisi sokuqala kunye nesiphumo kufuneka sibe kwimida okanye kwi-byte enye emva kokuphela kwento eyabelweyo.
    /// Qaphela ukuba kwi-Rust, yonke into eyahlukileyo ye (stack-allocated) ithathwa njengento eyahlukileyo eyabiweyo.
    ///
    /// * Icompset offset,**kwii-byte**, ayinakudlula kwi `isize`.
    ///
    /// * Ukuseta kwimida akunakuxhomekeka kwi "wrapping around" kwindawo yedilesi.Oko kukuthi, isilinganiselo esingapheliyo sokuchaneka kufuneka silingane kwi `usize`.
    ///
    /// Umhlanganisi kunye nethala leencwadi eliqhelekileyo ngokubanzi lizama ukuqinisekisa ukuba ulwabiwo alufikeleli kubungakanani apho iseti yinto exhalabisayo.
    /// Umzekelo, i `Vec` kunye ne `Box` baqinisekisa ukuba abaze babeke ngaphezulu kwe-`isize::MAX` byte, ke i `vec.as_ptr().add(vec.len())` ihlala ikhuselekile.
    ///
    /// Uninzi lwamaqonga ngokusisiseko alunakho nokwakha ulwabiwo olunjalo.
    /// Umzekelo, akukho qonga le-64-bit laziwayo linokuze lenze isicelo <sup>see-</sup> byte <sup>ezingama-</sup> 2 <sup>63</sup> ngenxa yokuncitshiswa kwetafile yamaphepha okanye ukwahlula indawo yedilesi.
    /// Nangona kunjalo, amaqonga ama-32-bit kunye ne-16-bit amaqonga anokusebenza ngempumelelo kwisicelo esingaphezulu kwe-`isize::MAX` byte ngezinto ezinjengeDilesi yePhysical Extension.
    ///
    /// Kananjalo, inkumbulo efunyenwe ngokuthe ngqo kubanikezeli okanye kwiifayile ezibhalwe kwimemori *inokuba* inkulu kakhulu ukuba ingaphathwa ngalo msebenzi.
    ///
    /// Cinga ukusebenzisa i [`wrapping_add`] endaweni yokuba ezi ngxaki zinzima ukuzanelisa.
    /// Olona luhle kuphela kule ndlela kukuba yenza ukuba ulungelelwaniso lomdibaniso olunobukrakra ngakumbi.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Ibala isaphulelo esivela kwisikhombisi (ukunceda i `.offset ((ubale njenge isize).wrapping_neg())`).
    ///
    /// `count` ikwiiyunithi zika-T;Umzekelo, i `count` ka-3 imele isalathiso esingumfuziselo nge-`3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Ukuba kukho nayiphi na kwezi meko iphuliweyo, isiphumo kukungaziphathi kakuhle:
    ///
    /// * Zombini isikhombisi sokuqala kunye nesiphumo kufuneka sibe kwimida okanye kwi-byte enye emva kokuphela kwento eyabelweyo.
    /// Qaphela ukuba kwi-Rust, yonke into eyahlukileyo ye (stack-allocated) ithathwa njengento eyahlukileyo eyabiweyo.
    ///
    /// * Icompset offset ayinakugqitha kwi-`isize::MAX`**byte**.
    ///
    /// * Ukuseta kwimida akunakuxhomekeka kwi "wrapping around" kwindawo yedilesi.Oko kukuthi, isibalo esingapheliyo-sokuchaneka kufuneka silungele usize.
    ///
    /// Umhlanganisi kunye nethala leencwadi eliqhelekileyo ngokubanzi lizama ukuqinisekisa ukuba ulwabiwo alufikeleli kubungakanani apho iseti yinto exhalabisayo.
    /// Umzekelo, i `Vec` kunye ne `Box` baqinisekisa ukuba abaze babeke ngaphezulu kwe-`isize::MAX` byte, ke i `vec.as_ptr().add(vec.len()).sub(vec.len())` ihlala ikhuselekile.
    ///
    /// Uninzi lwamaqonga ngokusisiseko alunakho nokwakha ulwabiwo olunjalo.
    /// Umzekelo, akukho qonga le-64-bit laziwayo linokuze lenze isicelo <sup>see-</sup> byte <sup>ezingama-</sup> 2 <sup>63</sup> ngenxa yokuncitshiswa kwetafile yamaphepha okanye ukwahlula indawo yedilesi.
    /// Nangona kunjalo, amaqonga ama-32-bit kunye ne-16-bit amaqonga anokusebenza ngempumelelo kwisicelo esingaphezulu kwe-`isize::MAX` byte ngezinto ezinjengeDilesi yePhysical Extension.
    ///
    /// Kananjalo, inkumbulo efunyenwe ngokuthe ngqo kubanikezeli okanye kwiifayile ezibhalwe kwimemori *inokuba* inkulu kakhulu ukuba ingaphathwa ngalo msebenzi.
    ///
    /// Cinga ukusebenzisa i [`wrapping_sub`] endaweni yokuba ezi ngxaki zinzima ukuzanelisa.
    /// Olona luhle kuphela kule ndlela kukuba yenza ukuba ulungelelwaniso lomdibaniso olunobukrakra ngakumbi.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Ibala isilinganisi esisuka kwisikhombisi usebenzisa usongelo lwezibalo.
    /// (Uncedo lwe `.wrapping_offset(count as isize)`)
    ///
    /// `count` ikwiiyunithi zika-T;Umzekelo, i `count` ka-3 imele isalathiso esingumfuziselo nge-`3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Lo msebenzi ngokwawo uhlala ukhuselekile, kodwa ukusebenzisa isikhombisi esiphumela akunjalo.
    ///
    /// Isikhombisi esisiphumo sihlala siqhotyoshelwe kwinto enye eyabelweyo eyalatha kuyo i `self`.
    /// Isenokungasetyenziselwa ukufikelela kwinto eyabiweyo eyahlukileyo.Qaphela ukuba kwi-Rust, yonke into eyahlukileyo ye (stack-allocated) ithathwa njengento eyahlukileyo eyabiweyo.
    ///
    /// Ngamanye amagama, i-`let z = x.wrapping_add((y as usize) - (x as usize))` ayenzi * i-`z` ifane ne-`y` nokuba sicinga ukuba i-`T` inobungakanani be-`1` kwaye akukho kuphuphuma: `y` yalatha kwinto enye eyabelweyo.
    ///
    /// Xa kuthelekiswa ne-[`add`], le ndlela icothisa imfuno yokuhlala kwinto enye eyabelweyo: [`add`] kukuziphatha okungachazwanga kwangoko xa uwela imida yento;I-`wrapping_add` ivelisa isikhombisi kodwa isakhokelela kwiNdlela yokuNgazichazi ukuba isikhombisi asichazwanga xa singaphandle kwemida yento encanyathiselwe kuyo.
    /// [`add`] inokulungiswa ngcono kwaye ngenxa yoko ikhethwe kwikhowudi ebuthathaka ekusebenzeni.
    ///
    /// Ukutsala okulibazisekileyo kuthathela ingqalelo kuphela ixabiso lesikhombisi ebelichaziwe, hayi amaxabiso aphakathi asetyenzisiweyo ngexesha lokudityaniswa kwesiphumo sokugqibela.
    /// Umzekelo, i `x.wrapping_add(o).wrapping_sub(o)` ihlala ifana ne `x`.Ngamanye amagama, ukushiya into eyabelweyo kwaye uphinde ungene kwakhona emva kwexesha kuvunyelwe.
    ///
    /// Ukuba ufuna ukuwela imida yento, phosa isalathiso kwinani elipheleleyo kwaye wenze izibalo apho.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // Iterate usebenzisa isikhombisi eluhlaza ekonyuseni izinto ezimbini
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Loop uprinta i "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Ibala isilinganisi esisuka kwisikhombisi usebenzisa usongelo lwezibalo.
    /// (Uncedo lula '.ukusonga_okusetwa ((kubalwa njenge-isize).wrapping_neg())`)
    ///
    /// `count` ikwiiyunithi zika-T;Umzekelo, i `count` ka-3 imele isalathiso esingumfuziselo nge-`3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Lo msebenzi ngokwawo uhlala ukhuselekile, kodwa ukusebenzisa isikhombisi esiphumela akunjalo.
    ///
    /// Isikhombisi esisiphumo sihlala siqhotyoshelwe kwinto enye eyabelweyo eyalatha kuyo i `self`.
    /// Isenokungasetyenziselwa ukufikelela kwinto eyabiweyo eyahlukileyo.Qaphela ukuba kwi-Rust, yonke into eyahlukileyo ye (stack-allocated) ithathwa njengento eyahlukileyo eyabiweyo.
    ///
    /// Ngamanye amagama, i-`let z = x.wrapping_sub((x as usize) - (y as usize))` ayenzi * i-`z` ifane ne-`y` nokuba sicinga ukuba i-`T` inobungakanani be-`1` kwaye akukho kuphuphuma: I-`z` isancanyathiselwe kwinto engu-`x` incanyathiselwe kuyo, kwaye ukuyichaza ukuba ayizichazanga indlela yokuziphatha ngaphandle kwe `x` kunye `y` yalatha kwinto enye eyabelweyo.
    ///
    /// Xa kuthelekiswa ne-[`sub`], le ndlela icothisa imfuno yokuhlala kwinto enye eyabelweyo: [`sub`] kukuziphatha okungachazwanga kwangoko xa uwela imida yento;I-`wrapping_sub` ivelisa isikhombisi kodwa isakhokelela kwiNdlela yokuNgazichazi ukuba isikhombisi asichazwanga xa singaphandle kwemida yento encanyathiselwe kuyo.
    /// [`sub`] inokulungiswa ngcono kwaye ngenxa yoko ikhethwe kwikhowudi ebuthathaka ekusebenzeni.
    ///
    /// Ukutsala okulibazisekileyo kuthathela ingqalelo kuphela ixabiso lesikhombisi ebelichaziwe, hayi amaxabiso aphakathi asetyenzisiweyo ngexesha lokudityaniswa kwesiphumo sokugqibela.
    /// Umzekelo, i `x.wrapping_add(o).wrapping_sub(o)` ihlala ifana ne `x`.Ngamanye amagama, ukushiya into eyabelweyo kwaye uphinde ungene kwakhona emva kwexesha kuvunyelwe.
    ///
    /// Ukuba ufuna ukuwela imida yento, phosa isalathiso kwinani elipheleleyo kwaye wenze izibalo apho.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // Iterate usebenzisa isikhombisi eluhlaza ekonyuseni izinto ezimbini (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Loop uprinta i "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Icwangcisa ixabiso lesikhombisi kwi `ptr`.
    ///
    /// Kwimeko apho i-`self` sisikhombisi se-(fat) kuhlobo olungacwangciswanga, lo msebenzi uya kuchaphazela kuphela indawo yesikhombisi, ngelixa izikhombisi ze-(thin) ukuya kwiindidi ezinobungakanani, oku kunesiphumo esifanayo nesabelo esilula.
    ///
    /// Isikhombisi esikhokelela kwisiphumo siya kuba nokuvela kwe `val`, okt, kwisikhombisi esityebileyo, lo msebenzi uyafana ngokwenziwa kwesikhombisi esitsha esinexabiso lesikhombisi sedatha ye `val` kodwa imethadatha ye `self`.
    ///
    ///
    /// # Examples
    ///
    /// Lo msebenzi uluncedo ikakhulu ekuvumela i-byte-wise pointer arithmetic kwizikhombisi ezinamafutha:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // siya kuprinta i "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // UKHUSELEKO: Kwimeko yesikhombisi esibhityileyo, le misebenzi iyafana
        // kwisabelo esilula.
        // Kwimeko yesikhombisi esityebileyo, kunye nolwakhiwo lwangoku lwesalathiso samanqatha, icandelo lokuqala lesikhombisi lihlala sisikhombisi sedatha, esabelwe ngokufanayo.
        //
        unsafe { *thin = val };
        self
    }

    /// Ufunda ixabiso kwi `self` ngaphandle kokuyihambisa.
    /// Oku kushiya imemori kwi `self` ingatshintshanga.
    ///
    /// Jonga i [`ptr::read`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye ``.
        unsafe { read(self) }
    }

    /// Yenza ukufundwa okungathandabuzekiyo kwexabiso ukusuka kwi `self` ngaphandle kokuyihambisa.Oku kushiya imemori kwi `self` ingatshintshanga.
    ///
    /// Imisebenzi eguqukayo yenzelwe ukuba isebenze kwimemori ye-I/O, kwaye iqinisekisiwe ukuba ayizukuphakanyiswa okanye iphinde icwangciswe ngumdibanisi kuyo yonke imisebenzi eguqukayo.
    ///
    ///
    /// Jonga i [`ptr::read_volatile`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Ufunda ixabiso kwi `self` ngaphandle kokuyihambisa.
    /// Oku kushiya imemori kwi `self` ingatshintshanga.
    ///
    /// Ngokungafaniyo ne `read`, isikhombisi sinokungangqinelani.
    ///
    /// Jonga i [`ptr::read_unaligned`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Iikopi ze-`count * size_of<T>` byte ukusuka kwi-`self` ukuya kwi-`dest`.
    /// Umthombo kunye nendawo ekuyiwa kuyo isenokudibana.
    ///
    /// NOTE: oku kune *efanayo* mpikiswano ngokulandelelana njenge [`ptr::copy`].
    ///
    /// Jonga i [`ptr::copy`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Iikopi ze-`count * size_of<T>` byte ukusuka kwi-`self` ukuya kwi-`dest`.
    /// Umthombo kunye nendawo ekuyiwa kuyo ayinako ukugqitha.
    ///
    /// NOTE: oku kune *efanayo* mpikiswano ngokulandelelana njenge [`ptr::copy_nonoverlapping`].
    ///
    /// Jonga i [`ptr::copy_nonoverlapping`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Iikopi ze-`count * size_of<T>` byte ukusuka kwi-`src` ukuya kwi-`self`.
    /// Umthombo kunye nendawo ekuyiwa kuyo isenokudibana.
    ///
    /// NOTE: Oku kuye *ngokuchaseneyo* mpikiswano ngokulandelelana kwe [`ptr::copy`].
    ///
    /// Jonga i [`ptr::copy`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Iikopi ze-`count * size_of<T>` byte ukusuka kwi-`src` ukuya kwi-`self`.
    /// Umthombo kunye nendawo ekuyiwa kuyo ayinako ukugqitha.
    ///
    /// NOTE: Oku kuye *ngokuchaseneyo* mpikiswano ngokulandelelana kwe [`ptr::copy_nonoverlapping`].
    ///
    /// Jonga i [`ptr::copy_nonoverlapping`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Iphumeza isonakalisi (ukuba sikhona) sexabiso esalathiweyo.
    ///
    /// Jonga i [`ptr::drop_in_place`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Ubhala ngaphezulu indawo yememori ngexabiso elinikiweyo ngaphandle kokufunda okanye ukulahla ixabiso elidala.
    ///
    ///
    /// Jonga i [`ptr::write`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `write`.
        unsafe { write(self, val) }
    }

    /// Ukubiza i-memset kwisikhombisi esichaziweyo, ukuseta i-`count * size_of::<T>()` byte zememori ukuqala kwi-`self` ukuya kwi-`val`.
    ///
    ///
    /// Jonga i [`ptr::write_bytes`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Yenza ukubhala okungazinzanga kwendawo yememori ngexabiso elinikiweyo ngaphandle kokufunda okanye ukulahla ixabiso elidala.
    ///
    /// Imisebenzi eguqukayo yenzelwe ukuba isebenze kwimemori ye-I/O, kwaye iqinisekisiwe ukuba ayizukuphakanyiswa okanye iphinde icwangciswe ngumdibanisi kuyo yonke imisebenzi eguqukayo.
    ///
    ///
    /// Jonga i [`ptr::write_volatile`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Ubhala ngaphezulu indawo yememori ngexabiso elinikiweyo ngaphandle kokufunda okanye ukulahla ixabiso elidala.
    ///
    ///
    /// Ngokungafaniyo ne `write`, isikhombisi sinokungangqinelani.
    ///
    /// Jonga i [`ptr::write_unaligned`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Faka endaweni ye `self` nge `src`, ubuyise ixabiso elidala, ngaphandle kokulahla nokuba lelinye.
    ///
    ///
    /// Jonga i [`ptr::replace`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `replace`.
        unsafe { replace(self, src) }
    }

    /// Ukutshintsha amaxabiso kwiindawo ezimbini ezinokuguquguquka zohlobo olunye, ngaphandle kokucima nokuba kukodwa.
    /// Zinokugqagqana, ngokungafaniyo ne `mem::swap` engalinganiyo.
    ///
    /// Jonga i [`ptr::swap`] malunga neenkxalabo zokhuseleko kunye nemizekelo.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `swap`.
        unsafe { swap(self, with) }
    }

    /// Icacisa into engasetyenziswayo ekufuneka isetyenzisiwe kwisikhombisi ukuze ihambelane ne `align`.
    ///
    /// Ukuba akunakwenzeka ukulungelelanisa isikhombisi, ukumiliselwa kubuyisa i `usize::MAX`.
    /// Kuvumelekile ukuba kumiliselwe *rhoqo* ukubuyisa i `usize::MAX`.
    /// Ukusebenza kwealgorithm yakho kuphela kunokuxhomekeka ekufumaneni iseti engasetyenziswayo apha, hayi ukuchaneka kwayo.
    ///
    /// Ukuseta kubonisiwe ngenani lezinto ze `T`, hayi ii-byte.Ixabiso elibuyisiweyo linokusetyenziswa ngendlela ye `wrapping_add`.
    ///
    /// Akukho siqinisekiso sokuba nantoni na yokususa isalathiso ayizukuphuphuma okanye igqithe kulwabiwo isikhombisi esikhombe kulo.
    ///
    /// Kuxhomekeke kulowo ufowunayo ukuba aqinisekise ukuba iseti ebuyisiweyo ichanekile kuwo onke amagama ngaphandle kokulungelelaniswa.
    ///
    /// # Panics
    ///
    /// Umsebenzi panics ukuba i `align` ayingamandla-amabini.
    ///
    /// # Examples
    ///
    /// Ukufikelela kufutshane ne `u8` njenge `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // Ngelixa isikhombisi sinokulungelelaniswa nge `offset`, singakhomba ngaphandle kolwabiwo
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // UKHUSELEKO: I `align` itshekishiwe ukuba ingamandla ka-2 apha ngasentla
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Ibuyisa ubude besilayidi esiluhlaza.
    ///
    /// Ixabiso elibuyiselweyo linani lezinto **, hayi inani lee-byte.
    ///
    /// Lo msebenzi ukhuselekile, nokuba isilayidi esiluhlaza asinakufakwa kwisalathiso sesilayidi kuba isikhombisi asisebenzi okanye asilungelelananga.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // UKHUSELEKO: oku kukhuselekile kuba i `*const [T]` kunye ne `FatPtr<T>` zinobeko olufanayo.
            // Yi-`std` kuphela enokwenza esi siqinisekiso.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Ibuyisa isikhombisi esiluhlaza kwisikhuseli sesilayi.
    ///
    /// Oku kulingana nokuphosa i-`self` ukuya kwi-`*mut T`, kodwa ikhuseleke ngakumbi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Ibuyisa isikhombisi esiluhlaza kwinto ethile okanye kwintengiso, ngaphandle kokujonga imida.
    ///
    /// Ukutsalela umnxeba le ndlela ngesalathiso esingaphandle kwemida okanye xa i `self` ingafakwanga kubhekiswa kuyo *[isimilo esingachazwanga]* nokuba isikhombisi esisiphumo asisetyenziswanga.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // UKHUSELEKO: umntu ofowunayo uqinisekisa ukuba i `self` ayinakuphinda yenziwe kwaye i `index` iyangena.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Ibuyisa i `None` ukuba isikhombisi asisebenzi, okanye enye into ibuyisela isilayidi ekwabelwana ngaso kwixabiso elisongelwe kwi `Some`.
    /// Ngokuchasene ne-[`as_ref`], oku akufuneki ukuba ixabiso kufuneka liqaliswe.
    ///
    /// Kumlingane onokutshintsha jonga i [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqiniseke ukuba *nokuba sisikhombisi asinguNULL* okanye * konke oku kulandelayo kuyinyani:
    ///
    /// * Isikhombisi kufuneka sibe yi-[valid] ukuze ifundelwe i-`ptr.len() * mem::size_of::<T>()` ii-byte ezininzi, kwaye kufuneka zilungelelaniswe ngokufanelekileyo.Oku kuthetha ngokukodwa:
    ///
    ///     * Uluhlu lonke lwenkumbulo yesi silayi kufuneka siqulathwe kwinto enye eyabelweyo!
    ///       Iziqwenga azinakuze zijikeleze izinto ezininzi ezabiweyo.
    ///
    ///     * Isikhombisi kufuneka silungelelaniswe nakwizilayi ezide.
    ///     Isizathu esinye soku kukuba ulungelelwaniso lwe-enum lunokuxhomekeka kwizalathiso (kubandakanya izilayi zobuphi na ubude) zilungelelaniswe kwaye zingabinanto ukwahlulahlula kwezinye idatha.
    ///
    ///     Unokufumana isikhombisi esinokusetyenziswa njenge-`data` kwizilayi ezide zobude usebenzisa i [`NonNull::dangling()`].
    ///
    /// * Ubungakanani bebonke be-`ptr.len() * mem::size_of::<T>()` yesilayidi kufuneka kungabikho ngaphezulu kwe `isize::MAX`.
    ///   Jonga amaxwebhu okhuseleko e [`pointer::offset`].
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///   Ngokukodwa, ixesha lokuphila, imemori yesalathi esalatha kuyo akufuneki iguqulwe (ngaphandle kwe `UnsafeCell`).
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    ///
    /// Jonga kwakhona i [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Ibuyisa i `None` ukuba isikhombisi asisebenzi, okanye enye into ibuyisela isilayi esahlukileyo kwixabiso elisongelwe kwi `Some`.
    /// Ngokuchasene ne-[`as_mut`], oku akufuneki ukuba ixabiso kufuneka liqaliswe.
    ///
    /// Kwiqabane ekwabelwana ngalo bona i [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Xa ubiza le ndlela, kuya kufuneka uqiniseke ukuba *nokuba sisikhombisi asinguNULL* okanye * konke oku kulandelayo kuyinyani:
    ///
    /// * Isikhombisi kufuneka sibe yi-[valid] yokufunda kwaye sibhalele i-`ptr.len() * mem::size_of::<T>()` ii-byte ezininzi, kwaye kufuneka zilungelelaniswe ngokufanelekileyo.Oku kuthetha ngokukodwa:
    ///
    ///     * Uluhlu lonke lwenkumbulo yesi silayi kufuneka siqulathwe kwinto enye eyabelweyo!
    ///       Iziqwenga azinakuze zijikeleze izinto ezininzi ezabiweyo.
    ///
    ///     * Isikhombisi kufuneka silungelelaniswe nakwizilayi ezide.
    ///     Isizathu esinye soku kukuba ulungelelwaniso lwe-enum lunokuxhomekeka kwizalathiso (kubandakanya izilayi zobuphi na ubude) zilungelelaniswe kwaye zingabinanto ukwahlulahlula kwezinye idatha.
    ///
    ///     Unokufumana isikhombisi esinokusetyenziswa njenge-`data` kwizilayi ezide zobude usebenzisa i [`NonNull::dangling()`].
    ///
    /// * Ubungakanani bebonke be-`ptr.len() * mem::size_of::<T>()` yesilayidi kufuneka kungabikho ngaphezulu kwe `isize::MAX`.
    ///   Jonga amaxwebhu okhuseleko e [`pointer::offset`].
    ///
    /// * Kuya kufuneka unyanzelise imithetho ye-Rust, kuba ixesha elibuyisiweyo le-`'a` likhethwe ngokungenamkhethe kwaye alibonisi elona xesha lokuphila ledatha.
    ///   Ngokukodwa, ixesha lokuphila, imemori isikhombisi esikhomba kuso kufuneka singafikeleli (sifunde okanye sibhalwe) ngayo nayiphi na enye isikhombisi.
    ///
    /// Oku kuyasebenza nokuba isiphumo sale ndlela singasetyenziswanga!
    ///
    /// Jonga kwakhona i [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Ukulingana kwezikhombisi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}