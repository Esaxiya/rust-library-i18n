//! Lawula imemori ngesandla ngezikhombisi eziluhlaza.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Imisebenzi emininzi kule modyuli ithatha izikhombisi eziluhlaza njengempikiswano kunye nokufunda kuzo okanye ukuzibhalela.Ukuze oku kukhuseleke, ezi zikhombisi kufuneka zibe *ziyasebenza*.
//! Nokuba isikhombisi siyasebenza ngokuxhomekeke ekusebenziseni esisetyenziselwa (ukufunda okanye ukubhala), kunye nobungakanani bememori efikelelweyo (okt, zingaphi ii-byte eziyi-read/written).
//! Imisebenzi emininzi isebenzisa i-`*mut T` kunye ne-`* const T` ukufikelela kwixabiso elinye kuphela, kwimeko apho amaxwebhu eshiya ubungakanani kwaye ngokungathandabuzekiyo ithatha njenge-`size_of::<T>()` byte.
//!
//! Imigaqo echanekileyo yokunyaniseka ayikagqitywa okwangoku.Iziqinisekiso ezibonelelweyo kweli nqanaba zincinci kakhulu:
//!
//! * Isikhombisi se [null]*soze* sisebenze, nkqu nokufikelela kwi [size zero][zst].
//! * Ukuze isikhombisi sisebenze, siyimfuneko, kodwa akusoloko sanele, ukuba isikhombisi asinakukhethwa *: uluhlu lwenkumbulo yesayizi enikiweyo eqala kwisikhombisi kufuneka yonke ibe ngaphakathi kwemida yento enye eyabelweyo.
//!
//! Qaphela ukuba kwi-Rust, yonke into eyahlukileyo ye (stack-allocated) ithathwa njengento eyahlukileyo eyabiweyo.
//! * Nokuba kusebenze i-[size zero][zst], isikhombisi akufuneki sikhombe kwimemori ehanjisiweyo, okt, ukuhanjiswa kwezinto kwenza ukuba izikhombisi zingasebenzi nakwizinto ezilinganayo.
//! Nangona kunjalo, ukuphosa naliphi na inani elingelilo zero *ngokoqobo* kwisikhombisi kusebenza ngokufikelela kubungakanani be-zero, nokuba inkumbulo ethile yenzekile ikho kuloo dilesi kwaye idlulisiwe.
//! Oku kuyahambelana nokubhala owabayo owabayo: ukwaba izinto ezinobungakanani be-zero akukho nzima kakhulu.
//! Indlela ye-canonical yokufumana isikhombisi esisemthethweni ukufikelela ku-zero-size yi-[`NonNull::dangling`].
//! * Lonke unikezelo olwenziwe yimisebenzi kule modyuli *lungeyo-atom* ngengqondo ye [atomic operations] esetyenziselwa ukungqamanisa phakathi kwemisonto.
//! Oku kuthetha ukuba kukuziphatha okungachazwanga ukwenza ufikeleleko ngaxeshanye kwindawo enye ukusuka kwimisonto eyahlukeneyo ngaphandle kokuba zombini ukufikelela kufundwa kuphela kwimemori.
//! Qaphela ukuba oku kubandakanya ngokucacileyo i-[`read_volatile`] kunye ne-[`write_volatile`]: Unikezelo olungenakufikeleleka alunakusetyenziselwa ukungqamanisa umsonto phakathi.
//! * Iziphumo zokuphosa isalathiso kwisikhombisi sisebenza ixesha elide ukuba into ephantsi iphila kwaye akukho sikhombisi (izikhombisi eziluhlaza) ezisetyenziselwa ukufikelela kwimemori efanayo.
//!
//! Ezi axioms, kunye nokusetyenziswa ngononophelo kwe [`offset`] ye-pointer arithmetic, zanele ukwenza izinto ezininzi eziluncedo kwikhowudi engakhuselekanga.
//! Iziqinisekiso ezomeleleyo ziya kubonelelwa ekugqibeleni, njengoko kumiselwa imigaqo ye [aliasing].
//! Ngolwazi oluthe kratya, bona i [book] kunye necandelo ekubhekiswe kulo kwi [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Izikhombisi ezifanelekileyo ezichaziweyo apha ngasentla azilungelelaniswanga ngokufanelekileyo (apho ulungelelwaniso lwe "proper" luchazwa luhlobo lwenqaku, okt, i `*const T` kufuneka ilungelelaniswe ne `mem::align_of::<T>()`).
//! Nangona kunjalo, uninzi lwemisebenzi ifuna ukuba iimpikiswano zabo zilungelelaniswe ngokufanelekileyo, kwaye iya kuyibeka ngokucacileyo le mfuno kumaxwebhu abo.
//! Ukwahlula okuphawulekileyo koku yi [`read_unaligned`] kunye ne [`write_unaligned`].
//!
//! Xa umsebenzi ufuna ulungelelwaniso olufanelekileyo, uyakwenza oko nokuba ukufikelela kubungakanani 0, okt nokuba imemori ayichukumiswanga.Cinga ukusebenzisa i [`NonNull::dangling`] kwiimeko ezinjalo.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Iphumeza isonakalisi (ukuba sikhona) sexabiso esalathiweyo.
///
/// Oku kuyafana nokubiza i [`ptr::read`] kunye nokulahla iziphumo, kodwa unezi zinto zilandelayo:
///
/// * Kuyimfuneko * ukusebenzisa i `drop_in_place` ukulahla iintlobo ezingacwangciswanga ezinjengezinto ze-trait, kuba azinakufundwa ngaphandle kwesitaki kwaye ziyeke ngesiqhelo.
///
/// * Ngumhlobo kumenzi wokulungileyo ukwenza oku ngaphezulu kwe [`ptr::read`] xa ushiya imemori oyinikiweyo ngesandla (umz., Ekuphunyezweni kwe `Box`/`Rc`/`Vec`), njengoko umhlanganisi engadingi kungqina ukuba kuvakala ukusebenzisa ikopi.
///
///
/// * Ingasetyenziselwa ukulahla idatha ye-[pinned] xa i-`T` ingeyiyo i-`repr(packed)` (idatha ebekiweyo akufuneki ihanjiswe ngaphambi kokuba ilahlwe).
///
/// Amaxabiso angalungelelaniswanga akanakuphoswa endaweni, kufuneka akotshelwe kwindawo elungelelanisiweyo kuqala kusetyenziswa i [`ptr::read_unaligned`].Kwizitraki ezipakishiweyo, le ntshukumo yenziwa ngokuzenzekelayo ngumqokeleli.
/// Oku kuthetha ukuba amasimi ezinto ezipakishwe awaphoswa endaweni.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `to_drop` mayibe ngu-[valid] kubo bobabini abafundayo nababhalayo.
///
/// * `to_drop` kufuneka zilungelelaniswe ngokufanelekileyo.
///
/// * Ixabiso le-`to_drop` eliza kuthi kufuneka livumeleke ukuba liyeke, oko kunokuthetha ukuba kufuneka ixhase abahlaseli abongezelelekileyo, oku kuxhomekeke kudidi.
///
/// Ukongeza, ukuba i-`T` ayisiyi-[`Copy`], ukusebenzisa ixabiso elalathiweyo emva kokubiza i-`drop_in_place` kunokubangela isimilo esingachazwanga.Qaphela ukuba i-`*to_drop = foo` ibalwa njengokusetyenziswa kuba iya kubangela ukuba ixabiso liphinde liphindwe.
/// [`write()`] inokusetyenziselwa ukubhala ngaphezulu idatha ngaphandle kokubangela ukuba ilahlwe.
///
/// Qaphela ukuba nokuba i-`T` inobungakanani be-`0`, isikhombisi kufuneka singabi yi-NULL kwaye silungelelaniswe ngokufanelekileyo.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Susa ngesandla into yokugqibela kwi-vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Fumana isikhombisi esiluhlaza kwinto yokugqibela kwi `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Mfutshane i `v` ukunqanda into yokugqibela ekuhlisweni.
///     // Senza oko kuqala, ukunqanda imiba ukuba i `drop_in_place` ingezantsi kwe panics.
///     v.set_len(1);
///     // Ngaphandle komnxeba `drop_in_place`, into yokugqibela ayinakuze ilahlwe, kwaye imemori eyilawulayo iya kuvuzwa.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Qinisekisa ukuba into yokugqibela iye yaphosa.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Qaphela ukuba umhlanganisi wenza le kopi ngokuzenzekelayo xa ewisa izitraki ezipakishiweyo, okt, akusoloko kufuneka ukhathazeke ngale micimbi ngaphandle kokuba ubize i `drop_in_place` ngesandla.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Ikhowudi apha ayinamsebenzi, oku kuthathelwe indawo yiglue yokwenyani ngumqokeleli.
    //

    // UKHUSELEKO: jonga ingxelo engentla
    unsafe { drop_in_place(to_drop) }
}

/// Yenza isikhombisi esiluhlaza.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Yenza isikhombisi esiluhlaza esingaguqukiyo.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Ukunyanzeliswa kwemanyuwali kuyadingeka ukunqanda ukubopha kwe `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Ukunyanzeliswa kwemanyuwali kuyadingeka ukunqanda ukubopha kwe `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Yenza isilayi esiluhlaza kwisikhombisi kunye nobude.
///
/// Impikiswano ye `len` linani lezinto eziyi **, hayi inani lee-byte.
///
/// Lo msebenzi ukhuselekile, kodwa ukusebenzisa ixabiso lokubuyisa akukhuselekanga.
/// Jonga amaxwebhu e [`slice::from_raw_parts`] ukulungiselela iimfuno zokhuselo lwesilayidi.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // yenza isikhombisi sesilayidi xa uqala ngesikhombisi kwinto yokuqala
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // UKHUSELEKO: Ukufikelela kwixabiso kwimanyano ye `Repr` kukhuselekile ukusukela * const [T]
        //
        // kunye neFatPtr inezakhiwo ezifanayo zememori.std kuphela enokwenza esi siqinisekiso.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Yenza ukusebenza okufanayo ne [`slice_from_raw_parts`], ngaphandle kokuba isilayidi esiluhlaza esingaguqukiyo siyabuyiselwa, ngokuchaseneyo nesilayidi esingaguqukiyo.
///
///
/// Bona amaxwebhu e [`slice_from_raw_parts`] ngolwazi oluthe kratya.
///
/// Lo msebenzi ukhuselekile, kodwa ukusebenzisa ixabiso lokubuyisa akukhuselekanga.
/// Jonga amaxwebhu e [`slice::from_raw_parts_mut`] ukulungiselela iimfuno zokhuselo lwesilayidi.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // nikezela ixabiso kwisalathiso kwisilayidi
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // UKHUSELEKO: Ukufikelela kwixabiso kumanyano we `Repr` kukhuselekile ukusukela * mut [T]
        // kunye neFatPtr inezakhiwo ezifanayo zememori
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Ukutshintsha amaxabiso kwiindawo ezimbini ezinokuguquguquka zohlobo olunye, ngaphandle kokucima nokuba kukodwa.
///
/// Kodwa kwezi zinto zimbini zilandelayo, lo msebenzi ulingana ngokwe-[`mem::swap`]:
///
///
/// * Isebenza kwizikhombisi eziluhlaza endaweni yesalathiso.
/// Xa izingqinisiso zikhona, kufuneka kukhethwe i [`mem::swap`].
///
/// * Ezi zimbini zichazwe kumaxabiso zinokudibana.
/// Ukuba amaxabiso ayangenana, indawo engqonge imemori evela kwi `x` iya kusetyenziswa.
/// Oku kubonisiwe kumzekelo wesibini apha ngezantsi.
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * Zombini i-`x` kunye ne-`y` mazibe yi-[valid] kuzo zombini ezifundwayo kwaye ziyabhala.
///
/// * Zombini i `x` kunye ne `y` kufuneka zilungelelaniswe ngokufanelekileyo.
///
/// Qaphela ukuba nokuba i-`T` inobungakanani be-`0`, izikhombisi kufuneka zingabi ze-NULL kwaye zilungelelaniswe ngokufanelekileyo.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ukutshintsha imimandla emibini engagqagqananga:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // Le yi `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // Le yi `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Ukutshintsha imimandla emibini edibeneyo:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // Le yi `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // Le yi `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // I-indices `1..3` yesilayidi esihamba ngaphezulu kwe `x` kunye ne `y`.
///     // Iziphumo ezinengqiqo ziya kuba zezo ziyi-`[2, 3]`, ukuze ii-indices `0..3` zi-`[1, 2, 3]` (ezilingana ne-`y` ngaphambi kwe-`swap`);okanye ukuba babe yi-`[0, 1]` ukuze ii-indices `1..4` ziyi-`[0, 1, 2]` (ezihambelana ne-`x` ngaphambi kwe-`swap`).
/////
///     // Olu setyenziso luchaziwe ukwenza ukhetho lwamva.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Sinike indawo yokuqala ukusebenza nayo.
    // Akunyanzelekanga ukuba sikhathazeke ngamaconsi: I `MaybeUninit` ayenzi nto xa ilahliwe.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Yenza utshintshelo UKHUSELEKO: umntu ofowunayo makaqinisekise ukuba i `x` kunye ne `y` zivumelekile ukuba zibhale kwaye zilungelelaniswe ngokufanelekileyo.
    // `tmp` ayinakho ukugqagqana nokuba yi `x` okanye i `y` kuba i `tmp` yabiwa nje kwisitaki njengento eyabelweyo eyahlukileyo.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` kunye ne `y` inokudibana
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Ukutshintsha i-`count * size_of::<T>()` byte phakathi kwemimandla emibini yememori eqala kwi-`x` kunye ne-`y`.
/// Imimandla emibini akufuneki ibaleke.
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * Zombini i-`x` kunye ne-`y` mazibe yi-[valid] kuzo zombini ezifundwayo kwaye zibhala ngokubala *
///   ubungakanani_of: :<T>() `iibhayithi.
///
/// * Zombini i `x` kunye ne `y` kufuneka zilungelelaniswe ngokufanelekileyo.
///
/// * Umda wenkumbulo oqala nge `x` ngobungakanani `count *
///   ubungakanani_of: :<T>() `byte may *not* overlap with the region of memory starting at `y` with the same size.
///
/// Qaphela ukuba nokuba ubungakanani bekopi esebenzayo (`count * size_of: :<T>()`) yi-`0`, izikhombisi kufuneka zingabi ze-NULL kwaye zilungelelaniswe ngokufanelekileyo.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `x` kunye ne `y` zi
    // isebenza ngokubhala kwaye ilungelelaniswe ngokufanelekileyo.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Kwiindidi ezincinci kunokwenziwa kwebhloko engezantsi, tshintsha nje ngokuthe ngqo ukunqanda ukucaphukisa ikhowudi.
    //
    if mem::size_of::<T>() < 32 {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `x` kunye ne `y` zisemthethweni
        // Ukubhala, ukulungelelaniswa ngokufanelekileyo, kunye nokungagqithisi.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Indlela apha kukusebenzisa i-simd ukutshintsha i-x&y ngokufanelekileyo.
    // Ukuvavanywa kutyhila ukuba ukutshintshisa ii-byte ezingama-32 okanye ii-byte ezingama-64 ngexesha kusebenza kakhulu kwiiprosesa ze-Intel Haswell E.
    // I-LLVM iyakwazi ukwenza ngcono ukuba sinika ulwakhiwo i #[repr(simd)], nokuba asilusebenzisi ngokuthe ngqo olu lwakhiwo.
    //
    //
    // I-FIXME repr(simd) yaphuke kwi-emscripten kunye ne-redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Phinda ujikeleze x&y, ubakhuphele `Block` ngexesha I-optimizer kufuneka ivule ilogo ngokupheleleyo kwiindidi ezininzi ze-NB
    // Asinakusebenzisa iluphu njengoko i `range` impl ibiza i `mem::swap` iphindayo
    //
    let mut i = 0;
    while i + block_size <= len {
        // Yenza imemori engachazwanga njengendawo yokuqala yokuxela i `t` apha ithintela ukulungelelanisa isitaki xa lo loop ingasetyenziswanga
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // UKHUSELEKO: Njenge `i < len`, nanjengokuba umntu ofowunayo kufuneka aqinisekise ukuba i `x` kunye ne `y` zisemthethweni
        // yee-`len` byte, `x + i` kunye ne-`y + i` kufuneka zibe ziidilesi ezifanelekileyo, ezizalisekisa ikhontrakthi yokhuseleko ye `add`.
        //
        // Kwakhona, umntu ofowunayo uyaqinisekisa ukuba i-`x` kunye ne-`y` zivumelekile ukuba zibhale, zilungelelaniswe ngokufanelekileyo, kwaye zingagqithisi, ezizalisekisa ikhontrakthi yokhuseleko ye `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Guqula ibhloko ye-byte ye-x&y, usebenzisa t njenge-buffer yexeshana Oku kufuneka kulungiselelwe ukusebenza kakuhle kwe-SIMD apho ifumaneka khona
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Tshintsha naziphi na ii-byte ezisele
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // UKHUSELEKO: jonga ingxelo yezokhuseleko yangaphambili.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Ihambisa i-`src` kwi-`dst` eyalathiweyo, ibuyisa ixabiso elidlulileyo le-`dst`.
///
/// Akukho xabiso liyehla.
///
/// Lo msebenzi ulingana ngokomlinganiso ne [`mem::replace`] ngaphandle kokuba usebenza kwizikhombisi eziluhlaza endaweni yesalathiso.
/// Xa izingqinisiso zikhona, kufuneka kukhethwe i [`mem::replace`].
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `dst` mayibe ngu-[valid] kubo bobabini abafundayo nababhalayo.
///
/// * `dst` kufuneka zilungelelaniswe ngokufanelekileyo.
///
/// * `dst` Kuya kufuneka ukhombe kwixabiso eliqaliswe ngokufanelekileyo lohlobo `T`.
///
/// Qaphela ukuba nokuba i-`T` inobungakanani be-`0`, isikhombisi kufuneka singabi yi-NULL kwaye silungelelaniswe ngokufanelekileyo.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` iya kuba nesiphumo esifanayo ngaphandle kokufuna ibhloko engakhuselekanga.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `dst` iyasebenza
    // phosa kwireferensi enokuguquguquka (isebenza ngokubhala, ilungelelaniswe, iqalisiwe), kwaye ayinakho ukugqitha kwi `src` kuba i `dst` kufuneka ikhombe kwinto eyabelweyo eyahlukileyo.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ayinakudibana
    }
    src
}

/// Ufunda ixabiso kwi `src` ngaphandle kokuyihambisa.Oku kushiya imemori kwi `src` ingatshintshanga.
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `src` kufuneka ibe yi-[valid] yokufunda.
///
/// * `src` kufuneka zilungelelaniswe ngokufanelekileyo.Sebenzisa i [`read_unaligned`] ukuba oku akunjalo.
///
/// * `src` Kuya kufuneka ukhombe kwixabiso eliqaliswe ngokufanelekileyo lohlobo `T`.
///
/// Qaphela ukuba nokuba i-`T` inobungakanani be-`0`, isikhombisi kufuneka singabi yi-NULL kwaye silungelelaniswe ngokufanelekileyo.
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Yenza ngesandla i [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Yenza ikopi ethe kratya yexabiso kwi `a` kwi `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ukuphuma kweli nqanaba (nokuba kubuyiswe ngokucacileyo okanye ngokubiza umsebenzi othi panics) kunokubangela ukuba ixabiso kwi `tmp` lehliswe ngelixa ixabiso elinye lisabhekiswa yi `a`.
///         // Oku kunokubangela isimilo esingachazwanga ukuba i `T` ayisiyi `Copy`.
/////
/////
///
///         // Yenza ikopi ethe kratya yexabiso kwi `b` kwi `a`.
///         // Oku kukhuselekile kuba izingqinisiso eziguqukayo azinakuli-alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Njengasentla, ukuphuma apha kunokubangela isimilo esingachazwanga kuba ixabiso elifanayo libhekiswa kwi `a` kunye ne `b`.
/////
///
///         // Hambisa i `tmp` kwi `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ihanjisiwe (`write` ithatha ubunini bempikiswano yayo yesibini), ke akukho nto ilahlwa ngokuchanekileyo apha.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Ubunini beXabiso eliBuyisiweyo
///
/// `read` yenza ikopi ethe tyaba ye `T`, nokuba i `T` yi [`Copy`].
/// Ukuba i-`T` ayisiyi-[`Copy`], ukusebenzisa zombini ixabiso elibuyisiweyo kunye nexabiso kwi-`*src` kungaphula ukhuseleko kwimemori.
/// Qaphela ukuba ukwabela inani le-`*src` njengokusetyenziswa kuba kuya kuzama ukulahla ixabiso kwi `* src`.
///
/// [`write()`] inokusetyenziselwa ukubhala ngaphezulu idatha ngaphandle kokubangela ukuba ilahlwe.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` ngoku yalatha kwimemori efanayo engaphantsi kwe `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Ukunikezela kwi `s2` kubangela ukuba ixabiso layo loqobo liyehliswe.
///     // Ngaphaya kweli nqaku, i `s` ayisayi kuphinda isetyenziswe, njengoko inkumbulo esezantsi ikhululiwe.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Ukunikezela kwi `s` kunokubangela ukuba ixabiso elidala liphinde liphinde liphinde, kukhokelele kwindlela yokuziphatha engachazwanga.
/////
///     // s= String::from("bar");//IPHUTHA
///
///     // `ptr::write` inokusetyenziselwa ukubhala ngaphezulu ixabiso ngaphandle kokulahla.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // UKHUSELEKO: umntu ofowunayo makaqinisekise ukuba i `src` isemthethweni xa ifundwa.
    // `src` ayinakudlula kwi `tmp` kuba i `tmp` yabiwa nje kwisitaki njengento eyabelweyo eyahlukileyo.
    //
    //
    // Kwakhona, kuba sibhale nje ixabiso elifanelekileyo kwi `tmp`, kuqinisekisiwe ukuba kuya kuqalwa ngokufanelekileyo.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Ufunda ixabiso kwi `src` ngaphandle kokuyihambisa.Oku kushiya imemori kwi `src` ingatshintshanga.
///
/// Ngokungafaniyo ne [`read`], i `read_unaligned` isebenza ngezikhombisi ezingalungelelaniswanga.
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `src` kufuneka ibe yi-[valid] yokufunda.
///
/// * `src` Kuya kufuneka ukhombe kwixabiso eliqaliswe ngokufanelekileyo lohlobo `T`.
///
/// Njengo [`read`], i `read_unaligned` yenza ikopi ethe xhaxhe ye `T`, nokuba i `T` yi [`Copy`].
/// Ukuba i-`T` ayisiyi-[`Copy`], usebenzisa zombini ixabiso elibuyiselweyo kunye nexabiso kwi-`*src` nge-[violate memory safety][read-ownership].
///
/// Qaphela ukuba nokuba i-`T` inobungakanani be-`0`, isikhombisi kufuneka singabi yi-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Kwi-`packed` structs
///
/// Okwangoku akunakwenzeka ukwenza izikhombisi eziluhlaza kwiindawo ezingalungelelaniswanga kulungelelwaniso.
///
/// Ukuzama ukwenza isikhombisi esiluhlaza kumhlaba we-`unaligned` ngombhalo onje nge `&packed.unaligned as *const FieldType` kudala ireferensi engahambelaniyo ngaphambi kokuyiguqula kwisikhombisi esiluhlaza.
///
/// Ukuba oku kubhekiswa okwethutyana kwaye kwangoko ukuphoswa akubalulekanga njengoko umqokeleli ehlala elindele ukuba izingqinisiso zilungelelaniswe ngokufanelekileyo.
/// Ngenxa yoko, ukusebenzisa i `&packed.unaligned as *const FieldType` kubangela kwangoko* isimilo esingachazwanga * kwinkqubo yakho.
///
/// Umzekelo wento ongayenziyo kunye nendlela edibana ngayo ne `read_unaligned` yile:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Apha sizama ukuthatha idilesi yenombolo engama-32 engahambelaniyo.
///     let unaligned =
///         // Isalathiso esingatyikitywanga sethutyana senziwe apha esikhokelela kukuziphatha okungachazwanga nokuba ireferensi iyasetyenziswa okanye ayisebenzi.
/////
///         &packed.unaligned
///         // Ukuphosa kwisikhombisi esiluhlaza akuncedi;impazamo sele yenzekile.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ukufikelela kumhlaba ongalungelelananga ngokuthe ngqo umz. `packed.unaligned` kukhuselekile nangona kunjalo.
///
///
///
///
///
///
// FIXME: Hlaziya amaxwebhu ngokusekwe kwiziphumo zeRFC #2582 kunye nabahlobo.
/// # Examples
///
/// Funda ixabiso losetyenziso ukusuka kwisikhuseli se-Byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // UKHUSELEKO: umntu ofowunayo makaqinisekise ukuba i `src` isemthethweni xa ifundwa.
    // `src` ayinakudlula kwi `tmp` kuba i `tmp` yabiwa nje kwisitaki njengento eyabelweyo eyahlukileyo.
    //
    //
    // Kwakhona, kuba sibhale nje ixabiso elifanelekileyo kwi `tmp`, kuqinisekisiwe ukuba kuya kuqalwa ngokufanelekileyo.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Ubhala ngaphezulu indawo yememori ngexabiso elinikiweyo ngaphandle kokufunda okanye ukulahla ixabiso elidala.
///
/// `write` ayikulahli imixholo ye `dst`.
/// Oku kukhuselekile, kodwa kunokuvuza ulwabiwo okanye izixhobo, ke kufuneka kuthathelwe ingqalelo ukuze kungabhalwa ngaphezulu kwento ekufuneka ilahliwe.
///
///
/// Ukongeza, ayilahli i `src`.Ngokwesiqhelo, i `src` ihanjiselwe kwindawo ekhonjwe yi `dst`.
///
/// Oku kufanelekile ukuqala imemori engagqitywanga, okanye ukubhala ngaphezulu imemori ebekade ingu [`read`] ukusuka kuyo.
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `dst` kufuneka ubengu-[valid] wokubhala.
///
/// * `dst` kufuneka zilungelelaniswe ngokufanelekileyo.Sebenzisa i [`write_unaligned`] ukuba oku akunjalo.
///
/// Qaphela ukuba nokuba i-`T` inobungakanani be-`0`, isikhombisi kufuneka singabi yi-NULL kwaye silungelelaniswe ngokufanelekileyo.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Yenza ngesandla i [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Yenza ikopi ethe kratya yexabiso kwi `a` kwi `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ukuphuma kweli nqanaba (nokuba kubuyiswe ngokucacileyo okanye ngokubiza umsebenzi othi panics) kunokubangela ukuba ixabiso kwi `tmp` lehliswe ngelixa ixabiso elinye lisabhekiswa yi `a`.
///         // Oku kunokubangela isimilo esingachazwanga ukuba i `T` ayisiyi `Copy`.
/////
/////
///
///         // Yenza ikopi ethe kratya yexabiso kwi `b` kwi `a`.
///         // Oku kukhuselekile kuba izingqinisiso eziguqukayo azinakuli-alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Njengasentla, ukuphuma apha kunokubangela isimilo esingachazwanga kuba ixabiso elifanayo libhekiswa kwi `a` kunye ne `b`.
/////
///
///         // Hambisa i `tmp` kwi `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ihanjisiwe (`write` ithatha ubunini bempikiswano yayo yesibini), ke akukho nto ilahlwa ngokuchanekileyo apha.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Sibiza i-intrinsics ngokuthe ngqo ukunqanda ukusebenza kweekhowudi njengoko i-`intrinsics::copy_nonoverlapping` ingumsebenzi osongelayo.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // UKHUSELEKO: umntu ofowunayo makaqinisekise ukuba i `dst` iyasebenza ekubhaleni.
    // `dst` ayinakudibana `src` kuba lowo ufowunayo unokufikelela ngokuguqukayo kwi `dst` ngelixa i `src` ingumnini walo msebenzi.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Ubhala ngaphezulu indawo yememori ngexabiso elinikiweyo ngaphandle kokufunda okanye ukulahla ixabiso elidala.
///
/// Ngokungafaniyo ne [`write()`], isikhombisi sinokungangqinelani.
///
/// `write_unaligned` ayikulahli imixholo ye `dst`.Oku kukhuselekile, kodwa kunokuvuza ulwabiwo okanye izixhobo, ke kufuneka kuthathelwe ingqalelo ukuze kungabhalwa ngaphezulu kwento ekufuneka ilahliwe.
///
/// Ukongeza, ayilahli i `src`.Ngokwesiqhelo, i `src` ihanjiselwe kwindawo ekhonjwe yi `dst`.
///
/// Oku kufanelekile ukuqala imemori engagqitywanga, okanye ukubhala ngaphezulu imemori ekhe yafundwa kunye ne [`read_unaligned`].
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `dst` kufuneka ubengu-[valid] wokubhala.
///
/// Qaphela ukuba nokuba i-`T` inobungakanani be-`0`, isikhombisi kufuneka singabi yi-NULL.
///
/// [valid]: self#safety
///
/// ## Kwi-`packed` structs
///
/// Okwangoku akunakwenzeka ukwenza izikhombisi eziluhlaza kwiindawo ezingalungelelaniswanga kulungelelwaniso.
///
/// Ukuzama ukwenza isikhombisi esiluhlaza kumhlaba we-`unaligned` ngombhalo onje nge `&packed.unaligned as *const FieldType` kudala ireferensi engahambelaniyo ngaphambi kokuyiguqula kwisikhombisi esiluhlaza.
///
/// Ukuba oku kubhekiswa okwethutyana kwaye kwangoko ukuphoswa akubalulekanga njengoko umqokeleli ehlala elindele ukuba izingqinisiso zilungelelaniswe ngokufanelekileyo.
/// Ngenxa yoko, ukusebenzisa i `&packed.unaligned as *const FieldType` kubangela kwangoko* isimilo esingachazwanga * kwinkqubo yakho.
///
/// Umzekelo wento ongayenziyo kunye nendlela edibana ngayo ne `write_unaligned` yile:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Apha sizama ukuthatha idilesi yenombolo engama-32 engahambelaniyo.
///     let unaligned =
///         // Isalathiso esingatyikitywanga sethutyana senziwe apha esikhokelela kukuziphatha okungachazwanga nokuba ireferensi iyasetyenziswa okanye ayisebenzi.
/////
///         &mut packed.unaligned
///         // Ukuphosa kwisikhombisi esiluhlaza akuncedi;impazamo sele yenzekile.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ukufikelela kumhlaba ongalungelelananga ngokuthe ngqo umz. `packed.unaligned` kukhuselekile nangona kunjalo.
///
///
///
///
///
///
///
///
///
// FIXME: Hlaziya amaxwebhu ngokusekwe kwiziphumo zeRFC #2582 kunye nabahlobo.
/// # Examples
///
/// Bhala ixabiso losetyenziso kwisikhuseli se-Byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // UKHUSELEKO: umntu ofowunayo makaqinisekise ukuba i `dst` iyasebenza ekubhaleni.
    // `dst` ayinakudibana `src` kuba lowo ufowunayo unokufikelela ngokuguqukayo kwi `dst` ngelixa i `src` ingumnini walo msebenzi.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Sibiza i-intrinsic ngokuthe ngqo ukunqanda ukusebenza kweekhowudi kwikhowudi evelisiweyo.
        intrinsics::forget(src);
    }
}

/// Yenza ukufundwa okungathandabuzekiyo kwexabiso ukusuka kwi `src` ngaphandle kokuyihambisa.Oku kushiya imemori kwi `src` ingatshintshanga.
///
/// Imisebenzi eguqukayo yenzelwe ukuba isebenze kwimemori ye-I/O, kwaye iqinisekisiwe ukuba ayizukuphakanyiswa okanye iphinde icwangciswe ngumdibanisi kuyo yonke imisebenzi eguqukayo.
///
/// # Notes
///
/// I-Rust okwangoku ayinemodeli engqongqo kwaye ichazwe ngokusesikweni yememori, ke isemantics echanekileyo yoko kuthethwa yi "volatile" apha inokutshintsha ngokuhamba kwexesha.
/// Oko bekutshiwo, iisemantics ziya kuhlala ziphela ngokufana ne [C11's definition of volatile][c11].
///
/// Umhlanganisi akufuneki atshintshe iodolo yesihlobo okanye inani lezinto ezinokusebenza kwimemori
/// Nangona kunjalo, imisebenzi yenkumbulo eguqukayo kwiindidi ezinobungakanani be-zero (umz., Ukuba uhlobo lobungakanani be-zero budluliselwe kwi-`read_volatile`) zii-noops kwaye zinokungahoywa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `src` kufuneka ibe yi-[valid] yokufunda.
///
/// * `src` kufuneka zilungelelaniswe ngokufanelekileyo.
///
/// * `src` Kuya kufuneka ukhombe kwixabiso eliqaliswe ngokufanelekileyo lohlobo `T`.
///
/// Njengo [`read`], i `read_volatile` yenza ikopi ethe xhaxhe ye `T`, nokuba i `T` yi [`Copy`].
/// Ukuba i-`T` ayisiyi-[`Copy`], usebenzisa zombini ixabiso elibuyiselweyo kunye nexabiso kwi-`*src` nge-[violate memory safety][read-ownership].
/// Nangona kunjalo, ukugcina izinto ezingezizo-[`Kopisha`] kwimemori eguqukayo ngokuqinisekileyo akulunganga.
///
/// Qaphela ukuba nokuba i-`T` inobungakanani be-`0`, isikhombisi kufuneka singabi yi-NULL kwaye silungelelaniswe ngokufanelekileyo.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Njengakwi-C, nokuba ukusebenza kuguquguqukayo akunanto yakwenza nemibuzo ebandakanya ukufikelela ngokufanayo kwimisonto emininzi.Ukufikelela okuguqukayo kuziphatha ngokuchanekileyo njengofikelelo olungelulo olwe-atom kule meko.
///
/// Ngokukodwa, ugqatso phakathi kwe `read_volatile` kunye nayiphi na imisebenzi yokubhala kwindawo enye kukungaziphathi kakuhle.
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ungoyiki ukugcina impembelelo ye-codegen incinci.
        abort();
    }
    // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Yenza ukubhala okungazinzanga kwendawo yememori ngexabiso elinikiweyo ngaphandle kokufunda okanye ukulahla ixabiso elidala.
///
/// Imisebenzi eguqukayo yenzelwe ukuba isebenze kwimemori ye-I/O, kwaye iqinisekisiwe ukuba ayizukuphakanyiswa okanye iphinde icwangciswe ngumdibanisi kuyo yonke imisebenzi eguqukayo.
///
/// `write_volatile` ayikulahli imixholo ye `dst`.Oku kukhuselekile, kodwa kunokuvuza ulwabiwo okanye izixhobo, ke kufuneka kuthathelwe ingqalelo ukuze kungabhalwa ngaphezulu kwento ekufuneka ilahliwe.
///
/// Ukongeza, ayilahli i `src`.Ngokwesiqhelo, i `src` ihanjiselwe kwindawo ekhonjwe yi `dst`.
///
/// # Notes
///
/// I-Rust okwangoku ayinemodeli engqongqo kwaye ichazwe ngokusesikweni yememori, ke isemantics echanekileyo yoko kuthethwa yi "volatile" apha inokutshintsha ngokuhamba kwexesha.
/// Oko bekutshiwo, iisemantics ziya kuhlala ziphela ngokufana ne [C11's definition of volatile][c11].
///
/// Umhlanganisi akufuneki atshintshe iodolo yesihlobo okanye inani lezinto ezinokusebenza kwimemori
/// Nangona kunjalo, imisebenzi yenkumbulo eguqukayo kwiindidi ezinobungakanani be-zero (umz., Ukuba uhlobo lobungakanani be-zero budluliselwe kwi-`write_volatile`) zii-noops kwaye zinokungahoywa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `dst` kufuneka ubengu-[valid] wokubhala.
///
/// * `dst` kufuneka zilungelelaniswe ngokufanelekileyo.
///
/// Qaphela ukuba nokuba i-`T` inobungakanani be-`0`, isikhombisi kufuneka singabi yi-NULL kwaye silungelelaniswe ngokufanelekileyo.
///
/// [valid]: self#safety
///
/// Njengakwi-C, nokuba ukusebenza kuguquguqukayo akunanto yakwenza nemibuzo ebandakanya ukufikelela ngokufanayo kwimisonto emininzi.Ukufikelela okuguqukayo kuziphatha ngokuchanekileyo njengofikelelo olungelulo olwe-atom kule meko.
///
/// Ngokukodwa, ugqatso phakathi kwe `write_volatile` kunye nayiphi na enye into (ukufunda okanye ukubhala) kwindawo enye kukungachazwa kokuziphatha.
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ungoyiki ukugcina impembelelo ye-codegen incinci.
        abort();
    }
    // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Lungelelanisa isikhombisi `p`.
///
/// Bala i-offset (ngokwemigaqo ye-`stride` stride) ekufuneka isetyenzisiwe kwisikhombisi `p` ukuze isalathi `p` sihambelane ne `a`.
///
/// Note: Oku kuzalisekiswa kwenzelwe ngononophelo hayi i-panic.Yi-UB yoku ukuya kwi-panic.
/// Olona tshintsho lokwenyani lunokwenziwa apha lutshintsho lwe `INV_TABLE_MOD_16` kunye nezinto ezinxulumene noko.
///
/// Ukuba singaze sithathe isigqibo sokwenza ukuba sikwazi ukubiza into engaphakathi nge-`a` engenamandla-amabini, kuya kuba bubulumko ngakumbi ukutshintsha nje kumiliselo olungenalwazi kunokuba sizame ukulungelelanisa oku kulungiselela olo tshintsho.
///
///
/// Nawuphi na umbuzo yiya ku@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Ukusetyenziswa ngokuthe ngqo kwezi zinto zangaphakathi kuphucula ikhowudigen kwinqanaba lokukhetha <=
    // 1, apho iindlela zokwenza ezi zinto zingafakwanga.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Bala ukuphindaphindwa kweemodyuli eziguqulweyo ze `x` modulo `m`.
    ///
    /// Oku kumiliselwa kulungiselelwe i `align_offset` kwaye inezi zilandelayo:
    ///
    /// * `m` amandla amabini-amabini;
    /// * `x < m`; (ukuba `x ≥ m`, dlula ngo-`x % m` endaweni yoko)
    ///
    /// Ukuphunyezwa kwalo msebenzi akuyi kuba panic.Ngonaphakade.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Iimodyuli eziphindaphindayo zemodyuli eziguqukayo zemodeli 2.=16.
        ///
        /// Qaphela, ukuba le tafile ayiqulathanga amaxabiso apho inverse ingekhoyo (okt ye `0⁻¹ mod 16`, `2⁻¹ mod 16`, njl.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Imodyuli eyenzelwe i `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // UKhuseleko
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Siphindaphinda i "up" sisebenzisa le fomyula ilandelayo:
            //
            // $$ xy 1 (imodeli 2ⁿ) → xy (2, xy) ≡ 1 (imodeli 2²ⁿ) $$
            //
            // kude kube yi-2²ⁿ ≥ m.Emva koko sinokunciphisa kwi-`m` yethu ngokuthatha iziphumo ze `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Qaphela, ukuba sisebenzisa imisebenzi yokusonga apha ngabom-indlela yentsusa isebenzisa umz., Ukuthabatha i `mod n`.
                // Kulungile ukubenza i `mod usize::MAX` endaweni yoko, kuba sithatha iziphumo ze `mod n` ekugqibeleni.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // UKHUSELEKO: `a` ngamandla-amabini, ke ngoko ayizo-zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Ityala linokubalwa ngokulula nge `-p (mod a)`, kodwa ngokwenza oko kuthintela amandla e-LLVM yokukhetha imiyalelo efana ne `lea`.Endaweni yoko siyabala
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // ehambisa imisebenzi ejikeleze ukuthwala umthwalo, kodwa ukungaqiniseki nge `and` ngokwaneleyo kwi-LLVM ukuze ikwazi ukusebenzisa ulungelelwaniso olwahlukileyo olwaziyo ngalo.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Sele zilungelelanisiwe.Yay!
        return 0;
    } else if stride == 0 {
        // Ukuba isikhombisi asihambelani, kwaye isixa silingana no-zero, ke akukho sixa sezinto ziya kuze silungelelanise isikhombisi.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // UKHUSELEKO: a amandla-amabini ngenxa yoko engekho zero.stride==0 ityala liphathwe apha ngasentla.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // UKHUSELEKO: i-gcdpow inezibophelelo ezingaphezulu kwelona lininzi lee-bits kwi-usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // UKHUSELEKO: i-gcd ihlala ikhulu okanye ilingana no-1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Le branch isombulula oku kulandelelana komlinganiso wokulingana:
        //
        // ` p + so = 0 mod a `
        //
        // `p` Nali ixabiso lesikhombisi, `s`, umtya we `T`, `o` iseti kwi-T`s, kunye ne-`a`, ulungelelwaniso oluceliweyo.
        //
        // Nge-`g = gcd(a, s)`, kwaye le meko ingentla iqinisekisa ukuba i-`p` ikwahlula-hlulwe yi-`g`, singachaza i-`a' = a/g`, `s' = s/g`, `p' = p/g`, emva koko oku kuyafana:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Ikota yokuqala ngu-"the relative alignment of `p` to `a`" (yahlulwe nge-`g`), ikota yesibini ngu-"how does incrementing `p` by `s` bytes change the relative alignment of `p`" (iphinde yahlulwa ngo-`g`).
        //
        // Ukwahlulwa nge `g` kuyimfuneko ukwenza okungafaniyo kwenziwe kakuhle ukuba i `a` kunye ne `s` ayizizo ezobambiswano.
        //
        // Ngaphaya koko, isiphumo esiveliswe sesi sisombululo asisiyi-"minimal", ke kuyafuneka ukuba uthathe iziphumo ze-`o mod lcm(s, a)`.Singabuyisela i `lcm(s, a)` nge `a'` nje.
        //
        //
        //
        //
        //

        // UKHUSELEKO: I-`gcdpow` inesibophelelo esingaphezulu kunenani lokulandela i-0-bits kwi-`a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // UKHUSELEKO: `a2` ayisiyo-zero.Ukutshintsha i `a` nge `gcdpow` akunakushenxisa nakweyiphi na into ebekiweyo
        // kwi `a` (apho inenye ngokuchanekileyo).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // UKHUSELEKO: I-`gcdpow` inesibophelelo esingaphezulu kunenani lokulandela i-0-bits kwi-`a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // UKHUSELEKO: I `gcdpow` inesibophelelo esingaphezulu kunenani lokulandela i-0-bits ngaphakathi
        // `a`.
        // Ngapha koko, ukuthabatha akunakuphuphuma, kuba i `a2 = a >> gcdpow` iya kuhlala ikhulu ngokungqongqo kune `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // UKHUSELEKO: `a2` ngamandla-amabini, njengoko kungqinwe ngasentla.I `s2` ingaphantsi kwe `a2` ngokungqongqo
        // kuba i `(s % a) >> gcdpow` ingaphantsi kwe `a >> gcdpow` ngokungqongqo.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ayinakulungelelaniswa konke konke.
    usize::MAX
}

/// Ukuthelekisa izikhombisi eziluhlaza zokulingana.
///
/// Oku kuyafana nokusebenzisa i-`==`, kodwa incinci generic:
/// iimpikiswano kufuneka zibe zizikhombisi eziluhlaza ze-`*const T`, hayi nantoni na ephumeza i `PartialEq`.
///
/// Oku kunokusetyenziselwa ukuthelekisa izingqinisiso ze-`&T` (ezinyanzela ukuya kwi-`*const T` ngokungagungqiyo) ngedilesi yazo kunokuba kuthelekiswe amaxabiso abalatha kuwo (yiyo loo nto kusenziwa i `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Iziqwenga zikwathelekiswa nobude bazo (izikhombisi ezinamanqatha):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// I-Traits nazo zithelekiswa nokuphunyezwa kwazo:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Izikhombisi zineedilesi ezilinganayo.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Izinto zineedilesi ezilinganayo, kodwa i `Trait` ineenkqubo ezahlukeneyo.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ukuguqula ireferensi ibe yi-`*const u8` ngokuthelekisa idilesi.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash isikhombisi esiluhlaza.
///
/// Oku kunokusetyenziselwa ukwenza i-hash ireferensi ye-`&T` (enyanzela i-`*const T` ngokungagungqiyo) kwidilesi yayo kunexabiso elalikhomba kulo (yiyo le nto isenziwa yi `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls zezikhombisi zomsebenzi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ukuphoswa okuphakathi njengokusetyenziswa kwe-AVR kuyadingeka
                // ukuze indawo yedilesi yesikhombisi somsebenzi igcinwe kwisikhombisi sokugqibela somsebenzi.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ukuphoswa okuphakathi njengokusetyenziswa kwe-AVR kuyadingeka
                // ukuze indawo yedilesi yesikhombisi somsebenzi igcinwe kwisikhombisi sokugqibela somsebenzi.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Akukho misebenzi eyahlukeneyo ineeparamitha eziyi-0
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Yenza isikhombisi esiluhlaza se `const` endaweni, ngaphandle kokwenza isalathiso esiphakathi.
///
/// Ukwenza ireferensi nge `&`/`&mut` kuvunyelwe kuphela ukuba isikhombisi silungelelaniswe ngokufanelekileyo kwaye sikhomba kwidatha eqalisiweyo.
/// Kwimeko apho ezo mfuno zingagciniyo, izikhombisi eziluhlaza kufuneka zisetyenziswe endaweni yoko.
/// Nangona kunjalo, i `&expr as *const _` yenza isalathiso ngaphambi kokuyiphosa kwisikhombisi esingavuthiyo, kwaye eso salathiso sixhomekeke kwimithetho efanayo nazo zonke ezinye izingqinisiso.
///
/// Le macro inokwenza isalathi eluhlaza * ngaphandle kokudala isalathiso kuqala.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` iyakwenza ireferensi engatyikitywanga, kwaye ke ibe yiNdlela yokuziPhatha!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Yenza isikhombisi esiluhlaza se `mut` endaweni, ngaphandle kokwenza isalathiso esiphakathi.
///
/// Ukwenza ireferensi nge `&`/`&mut` kuvunyelwe kuphela ukuba isikhombisi silungelelaniswe ngokufanelekileyo kwaye sikhomba kwidatha eqalisiweyo.
/// Kwimeko apho ezo mfuno zingagciniyo, izikhombisi eziluhlaza kufuneka zisetyenziswe endaweni yoko.
/// Nangona kunjalo, i `&mut expr as *mut _` yenza isalathiso ngaphambi kokuyiphosa kwisikhombisi esingavuthiyo, kwaye eso salathiso sixhomekeke kwimithetho efanayo nazo zonke ezinye izingqinisiso.
///
/// Le macro inokwenza isalathi eluhlaza * ngaphandle kokudala isalathiso kuqala.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` iyakwenza ireferensi engatyikitywanga, kwaye ke ibe yiNdlela yokuziPhatha!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` Imikhosi ikopa umhlaba endaweni yokwenza ireferensi.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}