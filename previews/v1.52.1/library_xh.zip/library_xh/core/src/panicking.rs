//! Inkxaso ye Panic ye-libcore
//!
//! Ithala lencwadi elingundoqo alinakukuchaza ukothuka, kodwa liyabhengeza * ukothuka.
//! Oku kuthetha ukuba imisebenzi engaphakathi kwe-libcore ivumelekile kwi-panic, kodwa ukuze ube luncedo ekunyukeni kwe-crate kufuneka ichaze panicking ye-libcore ukuze isetyenziswe.
//! Ujongano lwangoku lokuphaphazela yile:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Le nkcazo ivumela ukuphaphazela ngawo nawuphi na umyalezo ngokubanzi, kodwa ayikuvumeli ukusilela ngexabiso le `Box<Any>`.
//! (`PanicInfo` iqulethe nje i `&(dyn Any + Send)`, esizalisa kuyo ixabiso ledummy``PanicInfo: : internal_constructor`.) Isizathu soku kukuba libcore ayivumelekanga ukuba yabelwe.
//!
//!
//! Le modyuli inemisebenzi embalwa yokuphaphazela, kodwa ezi zizinto eziyimfuneko ze-lang zomqokeleli.Zonke i-panics zifakwe kulo msebenzi mnye.
//! Isimboli yokwenyani ibhengezwe kusetyenziswa uphawu lwe `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Ukuphunyezwa kwesiseko se-XcoreX macro xa kungekho fomathi isetyenzisiweyo.
#[cold]
// ungaze ulayini ngaphandle kokuba panic_immediate_abort ukunqanda ukudumba kwekhowudi kwiindawo zokufowuna kangangoko kunokwenzeka
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // Ifunwa yikhowudigen ye panic xa iphuphuma kunye nezinye iitheminali ze `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Sebenzisa i Arguments::new_v1 endaweni yefomathi_args! ("{}", Expr) ukunciphisa ubungakanani ngaphezulu kwentloko.
    // Ifomathi_args!I-macro isebenzisa i-str's Display trait ukubhala i-expr, ebiza i-Formatter::pad, ekufuneka ihambise i-truncation ye-string kunye ne-padding (nangona kungekho nto isetyenzisiweyo apha).
    //
    // Sebenzisa i-Arguments::new_v1 kunokuvumela umhlanganisi ukuba ashiye i-Formatter::pad kwimveliso yokubambisa, ukugcina ukuya kwiikhilobytes ezimbalwa.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // iyafuneka kuvavanyo lwe-panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // Ifunwa yikhowudigen ye panic kufikelelo ku-OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Ukuphunyezwa kwesiseko se-XcoreX macro xa kusetyenziswa ukufomatha.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // QAPHELA Lo msebenzi awunqumli umda we-FFI;yifowuni ye-Rust-to-Rust ethi isombulule umsebenzi we `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // UKHUSELEKO: `panic_impl` ichazwa ngendlela ekhuselekileyo ye Rust kwaye ngenxa yoko kukhuselekile ukubiza.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Umsebenzi wangaphakathi we `assert_eq!` kunye ne `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}