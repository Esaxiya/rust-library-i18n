#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Inenkcazo yolwakhiwo lobeko lweentlobo ezakhelweyo zomhlanganisi.
//!
//! Zingasetyenziselwa ukujolisa ekudluliseni ikhowudi engakhuselekanga yokukhohlisa ukumelwa okuluhlaza ngokuthe ngqo.
//!
//!
//! Inkcazo yabo kufuneka ihlale ihambelana ne-ABI echazwe kwi `rustc_middle::ty::layout`.
//!

/// Umelo lwento eyi-trait efana ne `&dyn SomeTrait`.
///
/// Olu lwakhiwo lunobeko olufanayo njengeentlobo ezinje nge `&dyn SomeTrait` kunye ne `Box<dyn AnotherTrait>`.
///
/// `TraitObject` Iqinisekisiwe ukuhambelana nokubekwa, kodwa ayilulo uhlobo lwezinto ze-trait (umz., amasimi awafikeleleki ngokuthe ngqo kwi `&dyn SomeTrait`) kwaye ayilawuli ubeko olo (ukutshintsha inkcazo akuyi kutshintsha ubume be `&dyn SomeTrait`).
///
/// Yenzelwe kuphela ukuba isetyenziswe yikhowudi engakhuselekanga efuna ukuhambisa iinkcukacha zenqanaba elisezantsi.
///
/// Akukho ndlela yokubhekisa kuzo zonke izinto ze-trait ngokubanzi, ke kuphela kwendlela yokwenza amaxabiso olu hlobo yimisebenzi efana ne [`std::mem::transmute`][transmute].
/// Ngokufanayo, ekuphela kwendlela yokwenza into eyi-trait eyinyani esuka kwixabiso le-`TraitObject` ine-`transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Ukudityaniswa kwento eyi-trait eneentlobo ezingalunganga-enye apho i-vtable ingahambelaniyo nohlobo lwexabiso apho isikhombisi sedatha-sikhokelela ekuziphatheni okungachazwanga.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // umzekelo trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // vumela umhlanganisi enze into eyi-trait
/// let object: &dyn Foo = &value;
///
/// // jonga kumelo oluhlaza
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // Isikhombisi sedatha yidilesi ye `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // yakha into entsha, yalatha kwi `i32` eyahlukileyo, ulumke ekusebenziseni i `i32` vtable evela kwi `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // Kuya kufuneka isebenze ngokungathi siyile into eyi-trait ngaphandle kwe `other_value` ngokuthe ngqo
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}