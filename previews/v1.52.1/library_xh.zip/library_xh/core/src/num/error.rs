//! Iimpazamo kwiindidi zokuguqula zibe ziindidi zokudibanisa.

use crate::convert::Infallible;
use crate::fmt;

/// Uhlobo lwempazamo lubuyile xa kuguqulwe uhlobo oluhlanganisiweyo olungaguqukiyo.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Tshatisa endaweni yokunyanzela ukuqinisekisa ukuba ikhowudi efana ne `From<Infallible> for TryFromIntError` apha ngasentla iya kuhlala isebenza xa i `Infallible` iba ligama le `!`.
        //
        //
        match never {}
    }
}

/// Impazamo enokubuyiselwa xa kudluliswa inani elipheleleyo.
///
/// Impazamo isetyenziswa njengohlobo lwempazamo kwimisebenzi ye-`from_str_radix()` kwiindidi zenamba zokuqala, ezinje nge [`i8::from_str_radix`].
///
/// # Izinto ezinokubangela
///
/// Phakathi kwezinye izizathu, i `ParseIntError` inokuphoswa ngenxa yendawo emhlophe ekhokelayo okanye ehambayo emva komtya, xa ifunyenwe kwigalelo eliqhelekileyo.
///
/// Sebenzisa indlela ye [`str::trim()`] kuqinisekisa ukuba akukho ndawo imhlophe ihleliyo ngaphambi kokuhluza.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// I-Enum yokugcina iintlobo ezahlukeneyo zeempazamo ezinokubangela ukuba inani elipheleleyo lisilele.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Ixabiso lokwahlulahlula alinanto.
    ///
    /// Phakathi kwezinye izizathu, lo mahluko uyakwakhiwa xa kudityaniswa umtya ongenanto.
    Empty,
    /// Inedijithi engavumelekanga kwimeko yayo.
    ///
    /// Phakathi kwezinye izizathu, lo mahluko uyakwakhiwa xa kudityaniswa umtya oqukethe i-non-ASCII char.
    ///
    /// Lo mahluko ukwakhiwa kwakhona xa i `+` okanye i `-` ibekwe endaweni engafanelekanga ngaphakathi komtya ngokwawo okanye embindini wenani.
    ///
    ///
    InvalidDigit,
    /// Inani elipheleleyo likhulu kakhulu ukuba lingagcinwa kuhlobo lwenani ekujoliswe kulo.
    PosOverflow,
    /// Inani elipheleleyo lincinci ukuba lingagcinwa kudidi olupheleleyo lwethagethi.
    NegOverflow,
    /// Ixabiso lalingu Zero
    ///
    /// Oku kwahluka kuya kukhutshwa xa umtya wokuhluza unexabiso le-zero, nto leyo ingangabikho mthethweni kwiintlobo ezingezizo eziro.
    ///
    Zero,
}

impl ParseIntError {
    /// Iziphumo ezingunobangela wokucacisa inani elipheleleyo lisilele.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}