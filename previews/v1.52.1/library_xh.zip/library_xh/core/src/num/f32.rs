//! Izinto ezijolise ngqo kuhlobo lwe-`f32` eyodwa-yokuchaneka kwenqaku lokudada.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Amanani abalulekileyo eMathematika abonelelwe kwimodyuli ye `consts`.
//!
//! Kwimixokelelwano echazwe ngokuthe ngqo kule modyuli (ngokwahlukileyo kuleyo ichazwe kwimodyuli ye `consts`), ikhowudi entsha endaweni yoko kufuneka isebenzise izinto ezinxulumene noko ezichazwe ngokuthe ngqo kuhlobo lwe `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Irediyo okanye isiseko sokumelwa kwangaphakathi kwe `f32`.
/// Sebenzisa i [`f32::RADIX`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // indlela ekujoliswe kuyo
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Inani lamanani abalulekileyo kwisiseko 2.
/// Sebenzisa i [`f32::MANTISSA_DIGITS`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // indlela ekujoliswe kuyo
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Inani eliqikelelweyo lamanani abalulekileyo kwisiseko 10.
/// Sebenzisa i [`f32::DIGITS`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // indlela ekujoliswe kuyo
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] Ixabiso le `f32`.
/// Sebenzisa i [`f32::EPSILON`] endaweni yoko.
///
/// Lo ngumahluko phakathi kwe `1.0` kunye nenani elilandelayo elikhulu elinokumelwa.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // indlela ekujoliswe kuyo
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Elona xabiso lincinci le `f32`.
/// Sebenzisa i [`f32::MIN`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // indlela ekujoliswe kuyo
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Elona xabiso lincinci liqhelekileyo le `f32`.
/// Sebenzisa i [`f32::MIN_POSITIVE`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // indlela ekujoliswe kuyo
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Elona xabiso liphezulu le `f32`.
/// Sebenzisa i [`f32::MAX`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // indlela ekujoliswe kuyo
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Inye inkulu kunamandla asezantsi anokubakho ekhupha i-2 ekhupha.
/// Sebenzisa i [`f32::MIN_EXP`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // indlela ekujoliswe kuyo
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Ubuninzi bamandla anokubakho esi-2 sokukhupha.
/// Sebenzisa i [`f32::MAX_EXP`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // indlela ekujoliswe kuyo
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Ubuncinci obunokwenzeka ngamandla aqhelekileyo e-10 ekhupha.
/// Sebenzisa i [`f32::MIN_10_EXP`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // indlela ekujoliswe kuyo
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Ubuninzi bamandla anokubakho kwisiphumo se-10.
/// Sebenzisa i [`f32::MAX_10_EXP`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // indlela ekujoliswe kuyo
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ayililo inani (NaN).
/// Sebenzisa i [`f32::NAN`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // indlela ekujoliswe kuyo
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Ubuninzi be (∞).
/// Sebenzisa i [`f32::INFINITY`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // indlela ekujoliswe kuyo
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Ukungabikho kakubi kwe (−∞).
/// Sebenzisa i [`f32::NEG_INFINITY`] endaweni yoko.
///
/// # Examples
///
/// ```rust
/// // indlela ehlisiweyo
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // indlela ekujoliswe kuyo
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Iziqulatho ezisisiseko zezibalo.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: buyisela endaweni yemathematics kwi-cmath.

    /// IArchimedes rhoqo i (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Isangqa esipheleleyo rhoqo (τ)
    ///
    /// Ilingana no 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Inombolo ye-Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Irediyo okanye isiseko sokumelwa kwangaphakathi kwe `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Inani lamanani abalulekileyo kwisiseko 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Inani eliqikelelweyo lamanani abalulekileyo kwisiseko 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] Ixabiso le `f32`.
    ///
    /// Lo ngumahluko phakathi kwe `1.0` kunye nenani elilandelayo elikhulu elinokumelwa.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Elona xabiso lincinci le `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Elona xabiso lincinci liqhelekileyo le `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Elona xabiso liphezulu le `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Inye inkulu kunamandla asezantsi anokubakho ekhupha i-2 ekhupha.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Ubuninzi bamandla anokubakho esi-2 sokukhupha.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Ubuncinci obunokwenzeka ngamandla aqhelekileyo e-10 ekhupha.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Ubuninzi bamandla anokubakho kwisiphumo se-10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ayililo inani (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Ubuninzi be (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Ukungabikho kakubi kwe (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Ibuyisa i `true` ukuba eli xabiso liyi `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): I `abs` ayifumaneki esidlangalaleni kwi-libcore ngenxa yenkxalabo malunga nokuphatheka, ke oku kuphunyezwa kwenzelwe ukusetyenziswa ngasese ngaphakathi.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Ibuyisa i `true` ukuba eli xabiso li-infinity elungileyo okanye i-negative infinity, kunye ne-`false` ngenye indlela.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Ibuyisa i `true` ukuba eli nani alinasiphelo okanye i `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Akukho sidingo sokuphatha i-NaN ngokwahlukeneyo: ukuba isiqu sakho ngu-NaN, uthelekiso aluyonyani, ngokuchanekileyo njengoko ufuna.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Ibuyisa i `true` ukuba inani liyi-[subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Ixabiso eliphakathi kwe `0` kunye ne `min` aliqhelekanga.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Ibuyisa i `true` ukuba inani aliloziro, alinasiphelo, [subnormal], okanye i `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Ixabiso eliphakathi kwe `0` kunye ne `min` aliqhelekanga.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Ibuyisa inqanaba lendawo yokudada yenani.
    /// Ukuba ipropathi inye kuphela eza kuvavanywa, ngokukhawuleza kuyasetyenziswa isimiselo esithile endaweni yoko.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Ibuyisa i-`true` ukuba i-`self` inophawu oluqinisekileyo, kubandakanya i-`+0.0`, `NaN's enesibonakaliso esichazayo kunye ne-infinity efanelekileyo.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Ibuyisa i-`true` ukuba i-`self` inophawu olubi, kubandakanya i-`-0.0`, `NaN's enesibonakaliso esingalunganga kunye nokungabikho okungalunganga.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 ithi: I isSignMinus(x) iyinyani ukuba kwaye kuphela ukuba u-x unophawu olubi.
        // isSignMinus isebenza kwii-zeros nakwi-NaNs ngokunjalo.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Ithatha ukuphindaphinda i (inverse) yenani, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Guqula ii-radians zibe ziziidigri.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Sebenzisa i-rhoqo ngokuchaneka okungcono.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Guqula iidigri zibe ziradians.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Ibuyisa ubuninzi bamanani amabini.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Ukuba enye yeempikiswano ngu-NaN, enye impikiswano iyabuyiselwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Ibuyisa ubuncinci bamanani amabini.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Ukuba enye yeempikiswano ngu-NaN, enye impikiswano iyabuyiselwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Ukujikeleza ukuya ku-zero kwaye kuguqukele kulo naluphi na uhlobo lwenamba yamandulo, ucinga ukuba ixabiso liphelile kwaye liyangena kolo hlobo.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Ixabiso kufuneka:
    ///
    /// * Ungabi yi `NaN`
    /// * Ungapheli
    /// * Bonakaliswa kuhlobo lokubuya `Int`, emva kokuncipha kwinxalenye yeqhezu
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // UKHUSELEKO: lowo ufowunayo kufuneka axhase ikhontrakthi yokhuseleko ye `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Ukuhanjiswa okuluhlaza ukuya kwi `u32`.
    ///
    /// Oku ngoku kuyafana ne `transmute::<f32, u32>(self)` kuwo onke amaqonga.
    ///
    /// Jonga i `from_bits` ngengxoxo ethile yokuphatheka kwalo msebenzi (akukho ngxaki).
    ///
    /// Qaphela ukuba lo msebenzi wahlukile ekubunjweni kwe-`as`, ethi izame ukugcina ixabiso * lamanani, hayi ixabiso elilinganayo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() ayilahli!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // UKHUSELEKO: I `u32` luhlobo oludala lwedatha esecaleni ukuze sihlale siyidlulisela kuyo
        unsafe { mem::transmute(self) }
    }

    /// Ukuhanjiswa okuluhlaza ukusuka kwi `u32`.
    ///
    /// Oku ngoku kuyafana ne `transmute::<u32, f32>(v)` kuwo onke amaqonga.
    /// Kuya kuvela ukuba iyaphatheka ngokumangalisayo, ngenxa yezizathu ezibini:
    ///
    /// * Iiflothi kunye nee-Int zinokungqinelani okufanayo kuwo onke amaqonga axhaswayo.
    /// * IEEE-754 ichaza ngokuchanekileyo ubume beebhanti zokudada.
    ///
    /// Nangona kunjalo kukho umqolomba omnye: ngaphambi kwenguqulelo ka-2008 ye-IEEE-754, indlela yokutolika into yokubonisa i-NaN ayichazwanga ngokwenyani.
    /// Uninzi lwamaqonga (ngokukodwa i-x86 kunye ne-ARM) zikhethe ukutolikwa okwakumgangatho wokugqibela ngo-2008, kodwa ezinye azizange (ngokukodwa ii-MIPS).
    /// Ngenxa yoko, konke ukutyikitya ii-NaNs kwi MIPS zii-NaNs ezithuleyo kwi x86, kwaye ngokuchaseneyo.
    ///
    /// Endaweni yokuzama ukugcina umqondiso weqonga lomnqamlezo, olu setyenziso luthanda ukugcina iibits ngqo.
    /// Oku kuthetha ukuba nayiphi na imirhumo ebhalwe kwiiNaNs iya kugcinwa nokuba iziphumo zale ndlela zithunyelwe kwinethiwekhi ukusuka kumatshini we x86 ukuya kwi MIPS.
    ///
    ///
    /// Ukuba iziphumo zale ndlela zilawulwa kuphela kuyilo olufanayo olubenzileyo, akukho zinkxalabo zithwelekayo.
    ///
    /// Ukuba igalelo elingelilo i-NaN, akukho ngxaki.
    ///
    /// Ukuba awukhathali malunga nokutyikitywa (kunokwenzeka kakhulu), akukho zinkxalabo yokuphatheka.
    ///
    /// Qaphela ukuba lo msebenzi wahlukile ekubunjweni kwe-`as`, ethi izame ukugcina ixabiso * lamanani, hayi ixabiso elilinganayo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // UKHUSELEKO: I `u32` luhlobo lwedatha oludala olucacileyo ukuze sihlale sidlulisa kulo
        // Kuya kuvela ukuba imiba yezokhuseleko ne-sNaN ibigqithisile!Molo!
        unsafe { mem::transmute(v) }
    }

    /// Buyisela ukubonakaliswa kwememori kwale nombolo yendawo yokudada njengoluhlu lwe-byte kwi-big-endian (network) byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Buyisela ukubonakaliswa kwememori kwale nombolo yenqaku lokudada njengoluhlu lwe-byte kuludwe lwe-endian byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Buyisela ukubonakaliswa kwememori kwale nombolo yendawo yokudada njengoluhlu lwe-byte kulungelelwaniso lwe-byte yemveli.
    ///
    /// Njengoko iqonga ekujoliswe kulo lisetyenziswa, ikhowudi ephathekayo kufuneka isebenzise i [`to_be_bytes`] okanye i [`to_le_bytes`], ngokufanelekileyo, endaweni yoko.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Buyisela ukubonakaliswa kwememori kwale nombolo yendawo yokudada njengoluhlu lwe-byte kulungelelwaniso lwe-byte yemveli.
    ///
    ///
    /// [`to_ne_bytes`] kufanele kukhethwe ngaphezulu koku xa kunokwenzeka.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // UKHUSELEKO: I `f32` luhlobo oludala lwedatha esecaleni ukuze sihlale siyidlulisela kuyo
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Yenza ixabiso lencopho yokudada kumelo lwalo njengoluhlu lwee-byte kwi-endian enkulu.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Yenza ixabiso lencopho yokudada kumelo lwalo njengoluhlu lwe-byte kwi-endian encinci.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Yenza ixabiso lencopho yokudada kumelo lwalo njengoluhlu lwee-endian.
    ///
    /// Njengoko iqonga ekujoliswe kulo lendalo lisetyenzisiwe, ikhowudi ephathekayo inokuba ifuna ukusebenzisa i [`from_be_bytes`] okanye i [`from_le_bytes`], ngokufanelekileyo endaweni yoko.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Ibuyisa iodolo phakathi kwesiqu sakho namanye amaxabiso.
    /// Ngokungafaniyo nenqanaba eliqhelekileyo lokuthelekisa phakathi kwamanani eendawo zokudada, olu thelekiso luhlala luvelisa uku-odola ngokungqinelana ne-totali yomyalelo njengoko kuchaziwe kwi-IEEE 754 (uhlaziyo luka-2008) lomgangatho wenqanaba lokudada.
    /// Amaxabiso ayalelwa ngokulandelelana:
    /// - Ukuthula okungalunganga NaN
    /// - Ukusayina okungalunganga NaN
    /// - Ukungabikho kakubi
    /// - Amanani amabi
    /// - Amanani aqhelekileyo angaqhelekanga
    /// - I-zero engalunganga
    /// - I-zero efanelekileyo
    /// - Amanani angaqhelekanga aqinisekileyo
    /// - Amanani afanelekileyo
    /// - Ukungapheli okuqinisekileyo
    /// - Ukutyikitya okuhle NaN
    /// - Ukuthula okuthe tye
    ///
    /// Qaphela ukuba lo msebenzi awusoloko uvumelana nokuphunyezwa kwe [`PartialOrd`] kunye ne [`PartialEq`] ye `f32`.Ngokukodwa, bathathela ingqalelo i-zero kunye ne-zero ezilinganayo, ngelixa i-`total_cmp` ingenjalo.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Kwimeko yezinto ezingalunganga, flip zonke iibits ngaphandle komqondiso ukufezekisa ubume obufanayo njengamanani apheleleyo okuzalisa
        //
        // Kutheni le nto isebenza?I-IEEE 754 edadayo inamacandelo amathathu:
        // Isayinwe kancinci, isibonisi kunye nemantissa.Iseti yeendawo zokukhupha kunye ne-mantissa xa iyonke inepropathi yokuba iodolo yazo encinci ilingana nobukhulu bamanani apho ubukhulu buchazwe khona.
        // Ubukhulu abuqhelekanga ngokwamaxabiso e-NaN, kodwa i-IEEE 754 iyonkeOrder ichaza amaxabiso e-NaN nayo ukuze ilandele ulandelelwano olungephi.Oku kukhokelela kulandelelo oluchazwe kwinkcazo ye-doc.
        // Nangona kunjalo, ukumelwa kobukhulu kuyafana ngamanani a-negative kunye no-positive-kuphela uphawu lomqondiso olwahlukileyo.
        // Ukuthelekisa ngokulula ukuntywila njengamanani apheleleyo asayiniweyo, kufuneka sifake i-exponent kunye ne-mantissa bits kwimeko yamanani amabi.
        // Siwaguqula ngokufanelekileyo amanani abe yifom ye "two's complement".
        //
        // Ukwenza i-flipping, sakha imaski kunye ne-XOR ngokuchasene nayo.
        // Thina ngaphandle kwesebe sibala imaski ye "all-ones except for the sign bit" kumaxabiso asayiniweyo: ekunene ukushenxisa uphawu-lwandisa inani elipheleleyo, ke thina "fill" imaski eneempawu zomqondiso, emva koko siguqulele kwi-unsigned ukuze sityhale enye zero.
        //
        // Ngamaxabiso aqinisekileyo, imaski zonke zii-zeros, ke ayiyondawo.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Thintela ixabiso kwixesha elithile ngaphandle kokuba yi-NaN.
    ///
    /// Ibuyisa i `max` ukuba i `self` ingaphezulu kwe `max`, kunye ne `min` ukuba i `self` ingaphantsi kwe `min`.
    /// Ngaphandle koko oku kubuyisela i `self`.
    ///
    /// Qaphela ukuba lo msebenzi ubuyisela i-NaN ukuba ixabiso lokuqala belingu-NaN ngokunjalo.
    ///
    /// # Panics
    ///
    /// Panics ukuba i `min > max`, i `min` yiNaN, okanye i `max` yiNaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}