//! Ukubetha kancinci kwi-IEEE 754 edadayo.Amanani amabi awakho kwaye akukho mfuneko yokuba aphathwe.
//! Amanani amanqaku aqhelekileyo okudada anokubonakaliswa kwe-canonical njenge (frac, exp) kangangokuba ixabiso liyi-2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) apho N linani leebits.
//!
//! Izinto ezingaqhelekanga zahluke kancinane kwaye aziqhelekanga, kodwa umgaqo ofanayo uyasebenza.
//!
//! Apha, nangona kunjalo, sibamele njengo (sig, k) nge f positive, ukuze ixabiso li f *
//! 2 <sup>e</sup> .Ngaphandle kokwenza i "hidden bit" icace gca, oku kuyayitshintsha i-exponent ngokubizwa ngokuba yimantissa shift.
//!
//! Beka enye indlela, ngesiqhelo ukubhukuda kubhalwa njenge-(1) kodwa ke apha kubhalwe njenge-(2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Sithi (1) the **fractional representation** and (2) the **integral representation**.
//!
//! Imisebenzi emininzi kule modyuli iphatha kuphela amanani aqhelekileyo.Iindlela ze-dec2flt ngokulungileyo zithatha indawo echanekileyo echanekileyo kwindalo (i-Algorithm M) yamanani amancinci kwaye makhulu kakhulu.
//! Ialgorithm ifuna kuphela i next_float() ejongana nokungaqhelekanga kunye noziro.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Umncedisi u trait ukunqanda ukuphinda kabini yonke ikhowudi yokuguqula i `f32` kunye ne `f64`.
///
/// Jonga uluvo lwemodyuli yomzali ukuba kutheni le nto iyimfuneko.
///
/// Ungaze **ungaze usebenze** kwezinye iintlobo okanye usetyenziswe ngaphandle kwemodyuli ye-dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Uhlobo olusetyenziswe yi `to_bits` kunye ne `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Yenza ukuhanjiswa okungafakwanga kwinani elipheleleyo.
    fn to_bits(self) -> Self::Bits;

    /// Yenza usasazo oluhlaza ukusuka kwinani elipheleleyo.
    fn from_bits(v: Self::Bits) -> Self;

    /// Ibuyisela udidi eli nani eliwela kulo.
    fn classify(self) -> FpCategory;

    /// Ibuyisa i-mantissa, i-exponent kwaye isayine njengamanani apheleleyo.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Ukucazulula ukudada.
    fn unpack(self) -> Unpacked;

    /// Ukuphosa kwinani elipheleleyo elinokumelwa ngokuchanekileyo.
    /// Panic ukuba inani elipheleleyo alinakuboniswa, enye ikhowudi kule modyuli iqinisekisa ukuba ayisoze yenzeke.
    fn from_int(x: u64) -> Self;

    /// Ufumana ixabiso 10 <sup>e</sup> kwitafile ebalwe ngaphambili.
    /// Panics ze `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Lithini igama.
    /// Kulula ukwenza ikhowudi elukhuni kunokugijimisa i-intrinsics kwaye unethemba lokuba i-LLVM ihlala iyisonga.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Isibophelelo esibophelelayo kumanani okugqibela egalelo elingenakuvelisa ukugcwala okanye iqanda okanye
    /// izinto ezingaqhelekanga.Ngokucacileyo i-decimal ekhupha elona xabiso liphezulu liqhelekileyo, kungoko igama.
    const MAX_NORMAL_DIGITS: usize;

    /// Xa elona nani libalulekileyo lokugqibela linexabiso lendawo elingaphezulu koku, inani ngokuqinisekileyo lijikeleziswe kubuncinci.
    ///
    const INF_CUTOFF: i64;

    /// Xa elona nani libalulekileyo lokugqibela linenani lendawo elingaphantsi koku, inani ngokuqinisekileyo lisondele ukuba libe nguziro.
    ///
    const ZERO_CUTOFF: i64;

    /// Inani leebits kwi-exponent.
    const EXP_BITS: u8;

    /// Inani leebits kwixabiso elibalulekileyo, kubandakanya * into efihliweyo.
    const SIG_BITS: u8;

    /// Inani leebits kwixabiso elibalulekileyo, ngaphandle kwe * into efihliweyo.
    const EXPLICIT_SIG_BITS: u8;

    /// Elona xabiso liphezulu lomthetho kumzobo wamaqhezu.
    const MAX_EXP: i16;

    /// Elona xabiso lisezantsi lokumela ngokomthetho, ngaphandle kokungaqhelekanga.
    const MIN_EXP: i16;

    /// `MAX_EXP` ukumelwa kokudibeneyo, okt, kunye notshintsho olusetyenzisiweyo.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kufakwe iikhowudi (okt, kunye nokukhetha okungalunganga)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ukumelwa kokudibeneyo, okt, kunye notshintsho olusetyenzisiweyo.
    const MIN_EXP_INT: i16;

    /// Elona xabiso liphezulu liqhelekile kubume obudibeneyo.
    const MAX_SIG: u64;

    /// Ixabiso elincinci eliqhelekileyo kumelo oluhlanganisiweyo.
    const MIN_SIG: u64;
}

// Ubukhulu becala indawo yokusebenza ye #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Ibuyisa i-mantissa, i-exponent kwaye isayine njengamanani apheleleyo.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Umkhethe okwahlukileyo + ukutshintsha kwemantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // I-rkruppe ayiqinisekanga ukuba i `as` ijikeleze ngokuchanekileyo kuwo onke amaqonga.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Ibuyisa i-mantissa, i-exponent kwaye isayine njengamanani apheleleyo.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Umkhethe okwahlukileyo + ukutshintsha kwemantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // I-rkruppe ayiqinisekanga ukuba i `as` ijikeleze ngokuchanekileyo kuwo onke amaqonga.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Guqula i-`Fp` iye kuhlobo olusondeleyo lomatshini wokudada.
/// Ayiphathi iziphumo ezingaqhelekanga.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f ngu 64 bit, ke xe unesimantissa shift sika 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Ukujikeleza ukubaluleka kwe-64-bit ukuya kwi-T::SIG_BITS bits kunye nesiqingatha-ukuya-kude.
/// Ayiphathi ukuphuphuma okungaphandle.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Lungisa utshintsho lwe mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Ukujika kwe-`RawFloat::unpack()` kumanani aqhelekileyo.
/// I-Panics ukuba ukubaluleka okanye i-exponent ayisebenzi kumanani aqhelekileyo.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Susa into efihliweyo
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Lungisa i-exponent kwi-expas bias kunye ne-mantissa shift
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Shiya uphawu kancinci ku-0 ("+"), amanani ethu onke alungile
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Yakha into engaqhelekanga.Imantissa ye-0 ivumelekile kwaye yakha u-zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Ukukhuphela okufihliweyo ngu-0, uphawu lomqondiso ngu-0, ke kuya kufuneka siphinde sichaze ii-bits.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Malunga ne-bignum ene-Fp.Ukujikeleza phakathi kwe 0.5 ULP ngesiqingatha-ukuya-kude.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Sinqumle zonke iibits ngaphambi kwesalathiso `start`, okt, ngokufanelekileyo-sihamba ngokufanelekileyo ngesixa se-`start`, yiyo le ke ikwangumbonisi esiwudingayo.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Ujikeleze i (half-to-even) ngokuxhomekeke kumabhithi ancitshisiweyo.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Fumana elona nqaku likhulu lokudada ngokungqongqo kuncinci kunempikiswano.
/// Ayiphathi izinto ezingaphantsi, zero, okanye i-exponent underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Fumana elona nani lincinci lencopho yokudada ngokungqongqo enkulu kunempikiswano.
// Lo msebenzi uyahlutha, okt next_float(inf) ==inf.
// Ngokungafaniyo nekhowudi emininzi kule modyuli, lo msebenzi uphatha i-zero, izinto ezingaqhelekanga, kunye ne-infinities.
// Nangona kunjalo, njengayo yonke enye ikhowudi apha, ayisebenzi ngeNaN kunye neenombolo ezimbi.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Oku kubonakala kulungile kakhulu ukuba kuyinyani, kodwa kuyasebenza.
        // 0.0 ikhowudwe njengegama elingunothi-wonke.Izinto ezingaqhelekanga ziyi-0x000m ... m apho i-mantissa.
        // Ngokukodwa, eyona incinci incinci iqhelekileyo ngu-0x0 ... 01 kwaye eyona inkulu ngu-0x000F ... F.
        // Elona nani lincinci lincinci eliqhelekileyo lingu-0x0010 ... 0, ke eli tyala lembombo liyasebenza ngokunjalo.
        // Ukuba ukunyuka kuphuphuma i-mantissa, ukunyusa kancinci ukunyusa i-exponent njengoko sifuna, kwaye i-mantissa bits iba zero.
        // Ngenxa yendibano encinci efihliweyo, nayo le nto yile nto siyifunayo!
        // Okokugqibela, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}