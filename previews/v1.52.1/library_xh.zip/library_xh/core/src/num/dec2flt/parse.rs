//! Ukuqinisekisa kunye nokubola komtya wokugqibela wefom:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Ngamanye amagama, i-syntax yendawo yokudada esemgangathweni, ngaphandle kwezinto ezimbini: Akukho phawu, kwaye akukho ukuphatha i "inf" kunye ne "NaN".Ezi ziphathwa ngumsebenzi womqhubi (super::dec2flt).
//!
//! Nangona ukuqaphela ungeniso olusebenzayo kulula ngokulula, le modyuli ikwalile ukungafani okungafaniyo okungasokuze kwenzeke, kungaze kube yi-panic, kwaye yenze uhlolo oluninzi ukuba ezinye iimodyuli zixhomekeke kwi-panic (okanye ukuphuphuma) ngokulandelelana.
//!
//! Ukwenza izinto zibe mbi ngakumbi, konke okwenzekayo kudlula kube kanye ngaphezulu kwegalelo.
//! Ke ulumke xa uguqula nantoni na, kwaye ujonge ezinye iimodyuli.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Iindawo ezinomdla zomtya wokugqibela.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Isiphumo sokugqibela, siqinisekisiwe ukuba sinamanani angaphantsi kweshumi elinesibhozo.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Ukujonga ukuba ngaba umtya wokufaka linani lencopho yokudada evumelekileyo kwaye ukuba kunjalo, khangela indawo edibeneyo, icandelo leqhezu, kunye nokucacisa okukulo.
/// Ayiphathi imiqondiso.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Akukho manani ngaphambi kwe 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Sifuna ubuncinci inamba enye ngaphambi okanye emva kwenqaku.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Ukulandela umkhondo wenkunkuma emva kwenxalenye yeqhekeza
            }
        }
        _ => Invalid, // Ukulandela umkhondo wenkunkuma emva komtya onamanani okuqala
    }
}

/// Wenza amanani edesimali ukuya kumlingisi wokuqala ongengowamanani.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Ukukhutshwa kwezinto ezikhethiweyo kunye nokujonga impazamo.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Ukulandela umkhondo wenkunkuma emva kokuveza
    }
    if number.is_empty() {
        return Invalid; // Ukukhupha ngaphandle
    }
    // Okwangoku, ngokuqinisekileyo sinomtya osebenzayo wamanani.Kungade kube kudala ukubekwa kwi-`i64`, kodwa ukuba inkulu kangako, igalelo ngokuqinisekileyo alikho okanye alinasiphelo.
    // Kuba i-zero nganye kwidijithi yedesimali ilungisa kuphela i-exponent ngo +/-1, nge-exp=10 ^ 18 igalelo kufuneka libe yi-17 exabyte (!) ye-zeros ukuze ikude kude kube kude.
    //
    // Le ayisiyiyo imeko yokusebenzisa ekufuneka siyenzile.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}