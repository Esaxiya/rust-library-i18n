//! Imisebenzi eluncedo yeebignum ezingenangqondo kakhulu ukuba ibe ziindlela.

// I-FIXME Igama lale modyuli lilishwa elincinci, kuba ezinye iimodyuli zikwangenisa i `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Vavanya ukuba unciphisa zonke iibits ezingabalulekanga kangako kune-`ones_place` yokwazisa ngempazamo yesihlobo, elinganayo, okanye enkulu kune-0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ukuba onke amasuntswana ashiyekileyo ayi-zero, ngu= 0.5 ULP, kungenjalo> 0.5 Ukuba akusekho bits (half_bit==0), ngezantsi kubuye ngokuchanekileyo ukulingana.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Guqula umtya we-ASCII oqukethe kuphela amanani edesimali ukuya kwi-`u64`.
///
/// Ayenzi uhlolo lokugqobhoza okanye oonobumba abangasebenziyo, ke ukuba umntu ofowunayo akalumkanga, isiphumo siyimbumbulu kwaye sinako i panic (nangona ayizukuba yi `unsafe`).
/// Ukongeza, imitya engenanto iphathwa njenge-zero.
/// Lo msebenzi ukhona ngenxa yokuba
///
/// 1. ukusebenzisa i `FromStr` kwi `&[u8]` kufuna i `from_utf8_unchecked`, embi, kwaye
/// 2. Ukudibanisa iziphumo ze-`integral.parse()` kunye ne-`fractional.parse()` kunzima ngakumbi kunalo msebenzi uphela.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Guqula umtya wamanani ASCII ube yibignum.
///
/// Njengo `from_str_unchecked`, lo msebenzi uxhomekeke kwisikhombisi ukuze ukhule ngaphandle kwamanani.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Isonga ibignum ibe ngamanani angama-64.Panics ukuba inani likhulu kakhulu.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Ikhupha uluhlu lweebhit.

/// Isalathiso 0 sesona sincinci sibalulekileyo kwaye uluhlu luvuleke ngesiqingatha njengesiqhelo.
/// I-Panics ukuba iceliwe ukuba ikhuphe iibits ezingaphezulu kunokulingana kuhlobo lokubuyela.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}