//! Ii-algorithms ezahlukeneyo ezivela ephepheni.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Inani leentsingiselo zexabiso kwi-Fp
const P: u32 = 64;

// Simane sigcina olona hlobo lusondeleyo kuzo zonke ii-exponents, ke umahluko we "h" kunye neemeko ezinxulumene noko zinokushiywa.
// Oku kusebenza kwintengiso yeekilobytes ezimbalwa zendawo.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Kuninzi loyilo, ukusebenza kweendawo zokudada zinobungakanani obucacileyo besithintelo, ke ngoko ukuchaneka kokubala kumiselwe ngokwesiseko sokusebenza.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Kwi-x86, i x87 FPU isetyenziselwa imisebenzi yokudada ukuba ulwandiso lwe SSE/SSE2 alufumaneki.
// I x87 FPU isebenza ngama-80 amasuntswana okuchaneka ngokungagqibekanga, oko kuthetha ukuba imisebenzi iya kujikeleza ukuya kuma-80 amasuntswana ebangela ukujikeleza kabini ukuba kwenzeke xa amaxabiso ekugqibeleni emelwe njenge
//
// 32/64 Ixabiso lokudada kancinci.Ukoyisa oku, igama lolawulo lwe-FPU linokuseta ukuze iikhompyuter zenziwe ngendlela echanekileyo.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Isakhiwo esisetyenziselwa ukugcina ixabiso elisekuqaleni kwegama lolawulo lwe-FPU, ukuze libuyiselwe xa isakhiwo siwile.
    ///
    ///
    /// I x87 FPU irejista eyi-16-bits irejista enamasimi alandelayo:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Amaxwebhu awo onke amasimi ayafumaneka kwi IA-32 yoYilo lweNkqubo yoPhuculo lweSoftware (Umqulu 1).
    ///
    /// Intsimi ekukuphela kwayo efanelekileyo kule khowudi ilandelayo yiPC, uLawulo loNgcono.
    /// Eli candelo limisela ukuchaneka kwemisebenzi eyenziwa yi-FPU.
    /// Ingasetwa apha:
    ///  - 0b00, ukuchaneka okukodwa okt, amasuntswana angama-32
    ///  - 0b10, ukuchaneka kabini, okt
    ///  - 0b11, ukuchaneka okuphindwe kabini okt, ii-80-bits (imeko emiselweyo) Ixabiso le-0b01 ligciniwe kwaye akufuneki lisetyenziswe.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // UKHUSELEKO: umyalelo we `fldcw` uphicothiwe ukuze ukwazi ukusebenza ngokuchanekileyo kunye
        // nayiphi na i `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Sisebenzisa i-syntax ye-ATT ukuxhasa i-LLVM 8 kunye ne-LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Cwangcisa intsimi echanekileyo ye-FPU ukuya kwi-`T` kwaye ibuyise i-`FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Bala ixabiso lecandelo loLawulo loLungiso elifanelekileyo kwi `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // Iibhithi ezingama-32
            8 => 0x0200, // Iibhithi ezingama-64
            _ => 0x0300, // okungagqibekanga, ii-bits ezingama-80
        };

        // Fumana ixabiso eliyintsusa legama lolawulo ukuze ulibuyisele kamva, xa isakhiwo se `FPUControlWord` sihlisiwe UKHUSELEKO: umyalelo we `fnstcw` uphicothiwe ukuze ukwazi ukusebenza ngokuchanekileyo ngayo nayiphi na i `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Sisebenzisa i-syntax ye-ATT ukuxhasa i-LLVM 8 kunye ne-LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Cwangcisa igama lolawulo kwindlela echanekileyo.
        // Oku kuphunyezwa ngokugubungela kude kude okudala (iibits ze-8 kunye ne-9, i-0x300) kwaye endaweni yazo kufakwe iflegi echanekileyo ebhalwe apha ngasentla.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Umendo okhawulezayo weBellerophon usebenzisa inani elipheleleyo lomatshini kunye nokudada.
///
/// Oku kukhutshwa kwenziwe umsebenzi owahlukileyo ukuze ube nokuzanywa ngaphambi kokwakha ibignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Sithelekisa ixabiso elichanekileyo ne-MAX_SIG kufutshane nesiphelo, oku kuyakhawuleza, ukwala okungabizi (kwaye kukhulule enye ikhowudi ekukhathazekeni ngokugcwala).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Indlela ekhawulezileyo ixhomekeke kubalo olujikelezwe kwinani elichanekileyo leebits ngaphandle kokujikeleza okuphakathi.
    // Kwi-x86 (ngaphandle kwe-SSE okanye i-SSE2) oku kufuna ukuchaneka kwesitaki se x87 FPU ukuze sitshintshwe ukuze sijikeleze ngokuthe ngqo kwi-64/32 bit.
    // Umsebenzi we `set_precision` ukhathalela ukuseta ukuchaneka kuyilo olufuna ukusetwa ngokutshintsha imeko yehlabathi (njengegama lolawulo le x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ityala e <0 alinakusongwa kwelinye i-branch.
    // Amandla angalunganga akhokelela kwinxalenye ephindayo yenxalenye yokubini, ejikeleziweyo, ebangela iimpazamo zokwenyani (kwaye ngamanye amaxesha zibaluleke kakhulu!) Kwisiphumo sokugqibela.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// I-Algorithm Bellerophon yikhowudi engenamsebenzi ethethelelekileyo ngohlalutyo olungenamsebenzi.
///
/// Iyajikeleza `` f '' kwi-float ine-64 encinci kwaye iyiphindaphinda ngokona kufana kwe-`10^e` (kwifomathi efanayo yokudada).Oku kuhlala ngokwaneleyo ukufumana iziphumo ezichanekileyo.
/// Nangona kunjalo, xa isiphumo sikufuphi nesiqingatha phakathi kwezinto ezimbini ezikufutshane ne-(ordinary), iimpazamo ezirhangqileyo zophinda-phindo usondelelo ezimbini zithetha ukuba iziphumo zinokucinywa ngamabhithi ambalwa.
/// Xa oku kusenzeka, ialgorithm R ephindaphindayo ilungisa izinto.
///
/// I-wavy "close to halfway" yesandla yenziwe ngokuchanekileyo ngohlalutyo lwamanani kwiphepha.
/// Ngamazwi kaClinger:
///
/// > I-Slop, ibonakaliswe kwiiyunithi ezincinci, zibophelelwe zibandakanya impazamo
/// > eqokelelwe ngexesha lokudibanisa ukubala kwendawo yokulinganisa kwi-f * 10 ^ e.(Slop ngu
/// > hayi ukubophelela impazamo eyinyani, kodwa ubopha umda phakathi koqikelelo z kunye
/// > olona hlobo lusondeleyo lusebenzayo olusebenzisa iipits zexabiso.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Amatyala abs(e) <log5(2^N) akwi fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Ngaba islop sikhulu ngokwaneleyo ukwenza umahluko xa ujikeleza kwiibits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Ialgorithm ye-iterative ephucula indawo yokuncamathela kwi-`f * 10^e`.
///
/// Iteration nganye ifumana iyunithi enye kwindawo yokugqibela ekufuphi, ethi yona ithathe ixesha elide kakhulu ukuba idibane ukuba i `z0` icime kancinci.
/// Ngethamsanqa, xa isetyenziselwa ukubuyela umva kweBellerophon, uqikelelo olusondeleyo lucinyiwe ubuninzi be-ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Fumana iinamba ezipheleleyo `x`, `y` ezinje ngokuba i `x / y` yeyona `(f *10^e) / (m* 2^k)`.
        // Oku akuphephi ukujongana neempawu ze-`e` kunye ne-`k`, sikwasusa amandla ezibini eziqhelekileyo kwi-`10^e` kunye ne-`2^k` ukwenza amanani abe mancinci.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Oku kubhalwe kancinci kancinci kuba iibignum zethu aziwaxhasi amanani amabi, ke sisebenzisa elona xabiso lipheleleyo + nolwazi lomqondiso.
        // Ukuphinda-phinda nge m_digits akunakuphuphuma.
        // Ukuba i `x` okanye i `y` zikhulu ngokwaneleyo kangangokuba kufuneka sizikhathaze ngokugcwala, ke zikhulu ngokwaneleyo ukuba i `make_ratio` ilinciphisile iqhezu nge-2 ^ 64 okanye nangaphezulu.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Awudingi x kwakhona, gcina i clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Usafuna y, yenza ikopi.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Ngenxa ye-`x = f` kunye ne-`y = m` apho i-`f` imele inani ledigital njengesiqhelo kwaye i-`m` ligama elichazayo lokulinganisa, yenza umlinganiso u-`x / y` ulingane ne-`(f *10^e) / (m* 2^k)`, ngokunokwenzeka uncitshiswe ngamandla ezibini ezifanayo.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ngaphandle kokuba sinciphisa iqhezu ngamagunya amabini.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Oku akunakuphuphuma kuba kufuna i-`e` kunye ne-`k` engalunganga, enokuthi yenzeke kuphela kumaxabiso asondele kakhulu ku-1, oko kuthetha ukuba i-`e` kunye ne-`k` ziya kuba zincinci ngokuthelekisa.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Oku akunakuphuphuma nokuba, jonga ngasentla.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), kwakhona ukunciphisa ngamandla aqhelekileyo amabini.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Ngokwenyani, ialgorithm M yeyona ndlela ilula yokuguqula idesimali kwi-float.
///
/// Senza umlinganiso olingana ne-`f * 10^e`, emva koko siphose amandla amabini de ibe inika ixabiso lokudada elisemthethweni.
/// I-binary exponent `k` linani lamaxesha siphindaphinde kwinani okanye kwiidinomineyitha ezimbini, okt, ngawo onke amaxesha i `f *10^e` ilingana ne `(u / v)* 2^k`.
/// Xa sifumene ukubaluleka, sifuna kuphela ukujikeleza ngokujonga intsalela yolwahlulo, olwenziwa kwimisebenzi yokunceda engezantsi.
///
///
/// Le algorithm icotha ngokugqibeleleyo, nkqu nokwenza kakuhle kuchazwe kwi `quick_start()`.
/// Nangona kunjalo, zezona zilula kubuchule bokuziqhelanisa nokuphuphuma, ukuphuphuma, kunye neziphumo ezingaqhelekanga.
/// Olu setyenziso luthatha indawo xa iBellerophon kunye neAlgorithm R zonganyelwe.
/// Ukufumanisa ukugcwala nokuphuphuma kulula: Umlinganiso awusebalulekanga kuluhlu, kodwa ukufikelela kwi minimum/maximum kufikelelwe.
/// Kwimeko yokuphuphuma, simane sibuyela kubuncinci.
///
/// Ukusingathwa kokuhamba ngaphantsi kunye nokungaqhelekanga kunzima.
/// Ingxaki enye enkulu kukuba, ngokubonisa ubuncinci, umlinganiso usenokuba mkhulu kakhulu ukuba ungabalulekanga.
/// Jonga i underflow() ngeenkcukacha.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // I-FIXME yokusebenza enokubakho: yenza ngokubanzi_kuku-_fp ukuze sikwazi ukwenza ukulingana kwe fp_to_float(big_to_fp(u)) apha, kuphela ngaphandle kokujikeleza kabini.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Kuya kufuneka simise kwelona xesha lincinci, ukuba silinda kude kube yi-`k < T::MIN_EXP_INT`, emva koko siyakucimeka ngenxa yento ezimbini.
            // Ngelishwa oku kuthetha ukuba kufuneka sibenamanani akhethekileyo aqhelekileyo kunye nesicatshulwa esisezantsi.
            // I-FIXME ifumana ukwenziwa okuhle ngakumbi, kodwa sebenzisa uvavanyo lwe `tiny-pow10` ukuqinisekisa ukuba ichanekile ngokwenene!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Tsiba ngaphezulu koninzi lweAlgorithm M ngokujonga ubude.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Ubude obuncinci luqikelelo lwesiseko se-logarithm ezimbini, kunye ne-log(u / v) = log(u), log(v).
    // Uqikelelo lucinyiwe ubuninzi be-1, kodwa uhlala uqikelelo oluphantsi, ke impazamo kwi-log(u) kunye ne-log(v) zingophawu olunye kwaye ziyacinywa (ukuba zombini zinkulu).
    // Ke ngoko impazamo ye log(u / v) yeyona inye.
    // Umlinganiso ojolise kuwo ngulapho i-u/v ikuluhlu olusembindini.Yiyo loo nto imeko yethu yokuphelisa i-log2(u / v) ziimpawu ezibalulekileyo, i-plus/minus inye.
    // I-FIXME Ukujonga isibini yesibini kunokuphucula uqikelelo kwaye kuthintele ukwahlulahlula ngakumbi.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Ukuhamba ngaphantsi okanye ukungaqhelekanga.Yiyekele kowona msebenzi uphambili.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Ukuphuphuma.Yiyekele kowona msebenzi uphambili.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ubungakanani bayo abukho kuluhlu olukuchazo kunye nesicatshulwa esincinci, ke kufuneka sigqithise iibithi ezingaphezulu kwaye silungelelanise i-exponent ngokufanelekileyo.
    // Ixabiso lokwenyani ngoku lijongeka njengoku:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q kuncitshisiwe.(imelwe ngu rem)
    //
    // Ke ngoko, xa iibits ezijikeleziweyo zikhona!= 0.5 ULP, bathatha isigqibo sokujikeleza ngokwabo.
    // Xa zilingana kwaye intsalela ingeyo-zero, ixabiso lisafuna ukurhangqwa.
    // Kuphela kuxa iibits ezijikeleziweyo ziyi-1/2 kwaye intsalela ingu-zero, sinesiqingatha-semeko.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Umjikelo oqhelekileyo wokuya ngoku-ukuya-kufutshane, obfuscated ngokuba ujikeleze ngokusekwe kwinxalenye eseleyo yolwahlulo.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}