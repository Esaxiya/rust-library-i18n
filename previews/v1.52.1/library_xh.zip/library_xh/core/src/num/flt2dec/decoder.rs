//! Imisela ixabiso lencopho yokudada kwindawo nganye kunye noluhlu lweempazamo.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Ixabiso eligqityiweyo elingasayiniwanga, elinokuthi:
///
/// - Ixabiso lokuqala lilingana ne `mant * 2^exp`.
///
/// - Naliphi na inani ukusuka kwi-`(mant - minus)*2^exp` ukuya kwi-`(mant + plus)* 2^exp` liya kujikeleza kwixabiso langaphambili.
/// Uluhlu lubandakanya kuphela xa i-`inclusive` ingu-`true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Imantissa enesikali.
    pub mant: u64,
    /// Uluhlu lwempazamo olusezantsi.
    pub minus: u64,
    /// Uluhlu lwempazamo ephezulu.
    pub plus: u64,
    /// Isicatshulwa ekwabelwana ngaso kwisiseko 2.
    pub exp: i16,
    /// Kuyinyani xa uluhlu lwempazamo lubandakanya.
    ///
    /// Kwi-IEEE 754, oku kuyinyani xa imantissa yoqobo yayinjalo.
    pub inclusive: bool,
}

/// Ixabiso elingasayiniwanga elingasayiniwanga.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Ubuncinci, nokuba kulungile okanye kubi.
    Infinite,
    /// Zero, nokuba zilungile okanye azilunganga.
    Zero,
    /// Amanani agqityiweyo ngamanye amasimi ahlaziyiweyo.
    Finite(Decoded),
}

/// Uhlobo lwendawo yokudada enokuthi `idecode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Elona xabiso liphantsi liqinisekisiwe.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Ibuyisa umqondiso (uyinyani xa ungalunganga) kunye nexabiso le-`FullDecoded` kwinombolo yenqaku edadayo.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // abamelwane: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode Ihlala igcina i-exponent, ngoko i-mantissa iyalinganiswa ngokungaqhelekanga.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // abamelwane: (maxmant, exp, 1)-(encinci, exp)-(engaqhelekanga + 1, exp)
                // apho ubuninzi=bunqabileyo * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // abamelwane: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}