//! Rust uhlengahlengiso lwe-Grisu3 algorithm echazwe kwi "Printing Floating-Point Numbers Ngokukhawuleza nangokuchanekileyo ngamanani apheleleyo" [^ 1].
//! Isebenzisa malunga ne-1KB yetafile emiselweyo, kwaye yona, iyakhawuleza kwiziphumo ezininzi.
//!
//! [^1]: Florian ILoitsch.2010. Ukuprinta amanani eendawo zokudada ngokukhawuleza kwaye
//!   ngokuchanekileyo ngamanani apheleleyo.ISIGPLAN Hayi.I-45, 6 (kaJuni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// bona amagqabantshintshi kwi `format_shortest_opt` ngengqiqo.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* mna, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Ukunikwa i `x > 0`, ibuyisa i `(k, 10^k)` enje nge `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Ukuphunyezwa kwendlela emfutshane yeGrisu.
///
/// Ibuyisa i `None` xa ibuya nembonakalo engafanelekanga ngenye indlela.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // Sifuna ubuncinci iibits ezintathu zokuchaneka okongeziweyo

    // qala ngamaxabiso aqhelekileyo ngesixhobo ekwabelwana ngaso
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // fumana nayiphi na i `cached = 10^minusk` enje nge `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // kuba i `plus` iqhelekile, oku kuthetha ukuba yi `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // ngokunikwa ukhetho lwethu lwe `ALPHA` kunye ne `GAMMA`, oku kubeka i `plus * cached` kwi `[4, 2^32)`.
    //
    // Kuyacaca ukuba kukwandisa i `GAMMA - ALPHA`, ukuze singadingi mandla agciniweyo ali-10, kodwa kukho izinto ezithile eziqwalaselwayo:
    //
    //
    // 1. Sifuna ukugcina i `floor(plus * cached)` ngaphakathi kwe `u32` kuba ifuna ulwahlulo olubiza kakhulu.
    //    (oku akunakuphepheka ngokwenene, okuseleyo kuyafuneka kuqikelelo oluchanekileyo.)
    // 2.
    // intsalela ye `floor(plus * cached)` iphindaphindwe nge-10, kwaye ayifanelanga ukuphuphuma.
    //
    // eyokuqala inika i `64 + GAMMA <= 32`, ngelixa yesibini inika i `10 * 2^-ALPHA <= 2^64`;
    // -60 kwaye i--32 lelona banga liphezulu ngale ngxaki, kwaye i V8 iyazisebenzisa.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // isikali fps.oku kunika eyona mpazamo iphambili ye-1 ulp (engqinwe yiTheorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-Uluhlu lwenene lokususa
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // ngaphezulu kwe `minus`, `v` kunye ne `plus` zii-quantified * uqikelelo (impazamo <1 ulp).
    // njengoko singazi ukuba impazamo ilungile okanye ayilunganga, sisebenzisa uqikelelo olwahlulwe ngokulinganayo kwaye sinempazamo enkulu ye-2 ulps.
    //
    // i "unsafe region" sisithuba esivulekileyo esasisenza ekuqaleni.
    // i "safe region" sisithuba esikhulayo esisamkelayo kuphela.
    // Siqala ngo repr echanekileyo ngaphakathi kommandla ongakhuselekanga, kwaye sizame ukufumana eyona repr ikufutshane kwi `v` ekwindawo ekhuselekileyo.
    // ukuba asikwazi, siyancama.
    //
    let plus1 = plus.f + 1;
    // Vumela plus0 = plus.f, 1;//Kuphela kwengcaciso x02X= minus.f + 1;//kuphela kwenkcazo
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // ekwabelwana ngayo

    // Yahlula i `plus1` ibe ngamalungu ahlanganisiweyo kunye namaqhezu.
    // Amalungu ahlanganisiweyo aqinisekisiwe ukuba anele kwi u32, kuba amandla agciniweyo aqinisekisa i `plus < 2^32` kunye ne `plus.f` yesiqhelo ihlala ingaphantsi kwe `2^64 - 2^4` ngenxa yemfuneko yokuchaneka.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // Bala i-`10^max_kappa` enkulu ngaphandle kwe-`plus1` (yiyo loo nto i-`plus1 < 10^(max_kappa+1)`).
    // lo ngumda ophezulu we `kappa` apha ngezantsi.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Ithiyori 6.2: ukuba i `k` lelona nani liphezulu st
    // `0 <= y mod 10^k <= y - x`,              emva koko i `V = floor(y / 10^k) * 10^k` ikwi `[x, y]` kwaye yenye yezona zimvo zimfutshane (ezinenani elincinci lamanani abalulekileyo) kolo luhlu.
    //
    //
    // fumana ubude bedijithi `kappa` phakathi kwe `(minus1, plus1)` ngokweTheorem 6.2.
    // Ithiyori 6.2 inokwamkelwa ngaphandle kwe `x` ngokufuna i `y mod 10^k < y - x` endaweni yoko.
    // (umzekelo, `x` =32000, `y` =32777; `kappa` =2 ukusukela `y mod 10 ^ 3=777 <y, x=777`.) Ialgorithm ixhomekeke kwisigaba sokuqinisekisa sangoku ukukhupha i `y`.
    //
    let delta1 = plus1 - minus1;
    // let delta1int=(delta1>> e) njengobungakanani;//kuphela kwenkcazo
    let delta1frac = delta1 & ((1 << e) - 1);

    // nikezela ngokuhlangeneyo, ngelixa ujonga ukuchaneka kwinqanaba ngalinye.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // amanani asazakunikezelwa
    loop {
        // Sisoloko sinenombolo enye yokunikezela, njengabahlaseli be `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (kulandela ukuba i `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // Yahlula i `remainder` nge `10^kappa`.Zombini zikalwe nge `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; Sifumene i `kappa` echanekileyo.
            let ten_kappa = (ten_kappa as u64) << e; // Isikali se-10 ^ kappa sibuyele kumbonisi ekwabelwana ngawo
            return round_and_weed(
                // UKHUSELEKO: saqala loo nkumbulo ingentla.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // qhekeza iluphu xa sele sinike onke amanani afanelekileyo.
        // Inani elichanekileyo lamanani ngu-`max_kappa + 1` njengo-`plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // buyisela izinto ezingenayo
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // nikezela ngamaqhekeza, ngelixa ujonga ukuchaneka kwinqanaba ngalinye.
    // ngeli xesha sixhomekeke ekuphindaphindweni okuphindaphindwayo, njengoko ukwahlula kuya kuphulukana nokuchaneka.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // Idijithi elandelayo kufuneka ibaluleke njengoko sivavanye oko ngaphambi kokuqhekeka kwezinto ezingenayo, apho i `m = max_kappa + 1` (#yamanani kwinxalenye yokudibanisa):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ayizukuphuphuma, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // Yahlula i `remainder` nge `10^kappa`.
        // Zombini zikalwe nge `2^e / 10^kappa`, ke le yokugqibela ichazwe apha.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // isahluli esingacacanga
            return round_and_weed(
                // UKHUSELEKO: saqala loo nkumbulo ingentla.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // buyisela izinto ezingenayo
        kappa -= 1;
        remainder = r;
    }

    // Sivelise onke amanani abalulekileyo e-`plus1`, kodwa andiqinisekanga ukuba yeyona ilungileyo.
    // Umzekelo, ukuba i-`minus1` ngu-3.14153 ... kwaye i-`plus1` ngu-3.14158 ..., kukho iindlela ezi-5 ezifutshane ezimfutshane ezisuka kwi-3.14154 ukuya kwi-3.14158 kodwa inkulu kuphela.
    // Kuya kufuneka silinciphise ngokulandelelana inani lokugqibela kwaye sijonge ukuba le yeyona repr eyiyo.
    // kukho uninzi lwabaviwa abali-9 (. 1 kuye ..9), ke oku kuyakhawuleza.(Isigaba se "rounding")
    //
    // Umsebenzi ujonga ukuba ngaba i-"optimal" repr ingaphakathi kweendawo ze-ulp, kananjalo, kunokwenzeka ukuba i-"second-to-optimal" repr inokuba ilungile ngenxa yempazamo yokujikeleza.
    // Kuzo zombini iimeko oku kubuyisa i `None`.
    // (Isigaba se "weeding")
    //
    // Zonke iimpikiswano apha zikalwe ngexabiso eliqhelekileyo (kodwa elingachazwanga) `k`, ukuze:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (kunye ne `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (Kwaye, i `threshold > plus1v` ivela kubahlaseli bangaphambili)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // ukuvelisa isilinganiselo esimalunga ne-`v` (eneneni i-`plus1 - v`) ngaphakathi kwe-1.5 ulps.
        // elona ziphumo limelweyo lelona lizwi lisondeleyo kubo bobabini.
        //
        // nantsi i `plus1 - v` iyasetyenziswa kuba ukubalwa kwenziwa ngokubhekisele kwi `plus1` ukuthintela i overflow/underflow (kungoko amagama abonakala ngathi atshintshiwe).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // yehlisa inani lokugqibela kwaye uyeke kwelona ziko lisondeleyo kwi `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // Sisebenza ngenani eliqikelelweyo i `w(n)`, elilingana no `plus1 - plus1 % 10^kappa` ekuqaleni.emva kokuqhuba umzimba we-loop `n` amaxesha, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // simisela i `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (yiyo loo nto ke `` intsalela= plus1w(0)`) ukwenza lula ukukhangela.
            // Qaphela ukuba i `plus1w(n)` ihlala inyuka.
            //
            // sinemiqathango emithathu yokuphelisa.nayiphi na kuzo iya kwenza ukuba iluphu ingakwazi ukuqhubekeka, kodwa ke ubuncinci sinokubonakaliswa okufanelekileyo okwaziwayo ukuba sikufutshane ne `v + 1 ulp` nakanjani.
            // Siza kubachaza njenge-TC1 ukuya kwi-TC3 ngobufutshane.
            //
            // TC1: I-`w(n) <= v + 1 ulp`, okt, le yeyona repr yokugqibela inokuba yeyona ikufutshane.
            // oku kulingana ne `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // Idityaniswe ne-TC2 (ejonga ukuba ngaba i-`w(n+1)` is valid), oku kuthintela ukuphuphuma okunokwenzeka kubalo lwe-`plus1w(n)`.
            //
            // TC2: I-`w(n+1) < minus1`, okt, i-repr elandelayo ngokuqinisekileyo ayijikelezi kwi-`v`.
            // oku kulingana ne `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // icala lasekhohlo linokugcwala, kodwa siyayazi i `threshold > plus1v`, ke ukuba i TC1 ayisiyonyani, i `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` kwaye sinokuvavanya ngokukhuselekileyo ukuba ngaba i `threshold - plus1w(n) < 10^kappa` endaweni yoko.
            //
            //
            // TC3: I `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, okt repr elandelayo ngu
            // akusondeli kwi `v + 1 ulp` kunaleyo ikhoyo ngoku.
            // unikwe i `z(n) = plus1v_up - plus1w(n)`, le iba yi `abs(z(n)) <= abs(z(n+1))`.kwakhona ucinga ukuba i TC1 ayisiyonyani, sine `z(n) > 0`.sinamatyala amabini ekufuneka siqwalasele:
            //
            // - xa i `z(n+1) >= 0`: TC3 iba yi `z(n) <= z(n+1)`.
            // njengoko i `plus1w(n)` inyuka, i `z(n)` kufuneka yehle kwaye oku kuyacaca ukuba bubuxoki.
            // - nini `z(n+1) < 0`:
            //   - TC3a: umqathango yi-`plus1v_up < plus1w(n) + 10^kappa`.ucinga ukuba i-TC2 ayisiyonyani, i-`threshold >= plus1w(n) + 10^kappa` ngenxa yoko ayinakuphuphuma.
            //   - I-TC3b: I-TC3 iba yi-`z(n) <= -z(n+1)`, okt, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   i-TC1 egatyiweyo inika i-`plus1v_up > plus1w(n)`, ke ayinakuphuphuma okanye iphuphume xa idityaniswe ne-TC3a.
            //
            // ngenxa yoko, kufuneka simise xa i `TC1 || TC2 || (TC3a && TC3b)`.oku kulandelayo kuyalingana nokuphambukiswa kwayo, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // elona repr lifutshane alinakuphela nge `0`
                plus1w += ten_kappa;
            }
        }

        // jonga ukuba ngaba lo mmeli ikwangowona mmeli ukufutshane kwi `v - 1 ulp`.
        //
        // Oku kuyafana nje nokuphelisa iimeko ze `v + 1 ulp`, nayo yonke i `plus1v_up` ithathelwe indawo yi `plus1v_down` endaweni yoko.
        // Uhlalutyo lokuphuphuma lubambe ngokulinganayo.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // ngoku sinommelo osondeleyo kwi `v` phakathi kwe `plus1` kunye ne `minus1`.
        // Inkululeko kakhulu, nangona kunjalo, siyala nayiphi na i `w(n)` engekho phakathi kwe `plus0` kunye ne `minus0`, okt, `plus1 - plus1w(n) <= minus0` okanye `plus1 - plus1w(n) >= plus0`.
        // sisebenzisa iinyani zokuba i `threshold = plus1 - minus1` kunye ne `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Ukuphunyezwa kwendlela emfutshane yeGrisu eneDragbackback.
///
/// Oku kufuneka kusetyenziselwe iimeko ezininzi.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // UKHUSELEKO: Isitshekhi sokuboleka asikho krelekrele ngokwaneleyo ukuba masisebenzise i `buf`
    // kwi-branch yesibini, ke sibeka ixesha lobomi apha.
    // Kodwa sisebenzisa kuphela i `buf` ukuba i `format_shortest_opt` ibuyise i `None` ke oku kulungile.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Ukuphunyezwa kwendlela echanekileyo kunye engatshintshiyo yeGrisu.
///
/// Ibuyisa i `None` xa ibuya nembonakalo engafanelekanga ngenye indlela.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // Sifuna ubuncinci iibits ezintathu zokuchaneka okongeziweyo
    assert!(!buf.is_empty());

    // kuqheleke kwaye kulinganiswe i `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // Yahlula i `v` ibe ngamalungu ahlanganisiweyo kunye namaqhezu.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // Zombini i `v` ezindala kunye ne `v` entsha (ezilinganiswe nge `10^-k`) zinempazamo ye <1 ulp (Theorem 5.1).
    // njengoko singazi ukuba impazamo ilungile okanye ayilunganga, sisebenzisa uqikelelo olwahlulwe ngokulinganayo kwaye sinempazamo enkulu ye-2 ulps (efanayo kweyona meko imfutshane).
    //
    //
    // injongo kukufumana uthotho lweenombolo ezijikelezileyo eziqhelekileyo kuzo zombini iX01 kunye ne `v + 1 ulp`, ukuze sizithembe ngokupheleleyo.
    // ukuba oku akunakwenzeka, asazi ukuba yeyiphi na imveliso echanekileyo ye `v`, ke siyancama sibuyele umva.
    //
    // `err` Ichazwa njenge-`1 ulp * 2^e` apha (efanayo kwi-ulp kwi-`vfrac`), kwaye siya kuyilinganisa nanini na xa i-`v` inyuka.
    //
    //
    //
    let mut err = 1;

    // Bala i-`10^max_kappa` enkulu ngaphandle kwe-`v` (yiyo loo nto i-`v < 10^(max_kappa+1)`).
    // lo ngumda ophezulu we `kappa` apha ngezantsi.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ukuba sisebenza nomda wokugqibela wokuthintela, kufuneka sinciphise isikhuseli ngaphambi kokunikezelwa kwangempela ukuthintela ukujikeleza kabini.
    //
    // Qaphela ukuba kufuneka sandise i-buffer kwakhona xa ukujikeleza kusenzeka!
    let len = if exp <= limit {
        // Ewe, asinako nokuvelisa * amanani amnye.
        // oku kunokwenzeka xa, sisithi, sinento efana ne 9.5 kwaye ijikelezwe ukuya kwi-10.
        //
        // Ngokomgaqo sinokubiza i `possibly_round` kwangoko nge-buffer engenanto, kodwa ukukala i `max_ten_kappa << e` nge-10 kunokubangela ukuphuphuma.
        //
        // yiyo loo nto sinobudenge apha kwaye sandisa uluhlu lweempazamo nge-10.
        // oku kuyonyusa izinga elingalunganga, kodwa kuphela,*kakhulu* kancinci;
        // Inokubaluleka kuphela xa i-mantissa inkulu kune-60 bits.
        //
        // UKHUSELEKO: `len=0`, ke uxanduva lokuqalisa le nkumbulo alubalulekanga.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // nikezela ngezinto ezifunekayo.
    // Impazamo iqhekeza ngokupheleleyo, ngenxa yoko akufuneki siyijonge kule ndawo.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // amanani asazakunikezelwa
    loop {
        // sihlala sinenombolo enye ubuncinci ekunikezeleni izinto ezingenayo:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (kulandela ukuba i `remainder = vint % 10^(kappa+1)`)
        //
        //

        // Yahlula i `remainder` nge `10^kappa`.Zombini zikalwe nge `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // i-buffer igcwele?sebenzisa ukujikeleza okudlulileyo kunye nentsalela.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // UKHUSELEKO: simisele i-`len` ii-byte ezininzi.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // qhekeza iluphu xa sele sinike onke amanani afanelekileyo.
        // Inani elichanekileyo lamanani ngu-`max_kappa + 1` njengo-`plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // buyisela izinto ezingenayo
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // unikeze iinxalenye zeqhezu.
    //
    // ngokomgaqo sinako ukuqhubeka ngokwamanani okugqibela afumanekayo kwaye sijonge ukuchaneka.
    // ngelishwa sisebenza ngenani elipheleleyo elilinganisiweyo, ngenxa yoko sifuna ikhrayitheriya ethile yokubona ukuphuphuma.
    // V8 isebenzisa i-`remainder > err`, eba bubuxoki xa i-`i` yamanani abalulekileyo e-`v - 1 ulp` kunye ne-`v` ahlukile.
    // nangona kunjalo oku kuyala uninzi lwegalelo elifanelekileyo.
    //
    // okoko isigaba samva sinokuchaphazeleka okuchanekileyo, endaweni yoko sisebenzisa ikhrayitheriya eqinileyo:
    // Siyaqhubeka de i-`err` igqithe i-`10^kappa / 2`, ukuze uluhlu oluphakathi kwe-`v - 1 ulp` kunye ne-`v + 1 ulp` ngokuqinisekileyo luqulathe ukubonakaliswa okubini okanye nangaphezulu.
    //
    // Oku kuyafana nokuthelekiswa kokuqala kwe `possibly_round`, yesalathiso.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // izinto ezingenayo, apho i `m = max_kappa + 1` (#yamanani kwinxalenye yokudibanisa):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ayizukuphuphuma, `2^e * 10 < 2^64`
        err *= 10; // ayizukuphuphuma, `err * 10 < 2^e * 5 < 2^64`

        // Yahlula i `remainder` nge `10^kappa`.
        // Zombini zikalwe nge `2^e / 10^kappa`, ke le yokugqibela ichazwe apha.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // i-buffer igcwele?sebenzisa ukujikeleza okudlulileyo kunye nentsalela.
        if i == len {
            // UKHUSELEKO: simisele i-`len` ii-byte ezininzi.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // buyisela izinto ezingenayo
        remainder = r;
    }

    // Olunye ubalo alunamsebenzi (i `possibly_round` ngokuqinisekileyo iyasilela), ke siyancama.
    return None;

    // Sivelise onke amanani aceliweyo e-`v`, ekufuneka elingana namanani ahambelana ne-`v - 1 ulp`.
    // ngoku sijonga ukuba ngaba akukho mmeli ukhethekileyo owabelwana ngawo zombini i `v - 1 ulp` kunye ne `v + 1 ulp`;oku kungafana nakwidijithi ezivelisiweyo, okanye kuhlobo olujikeleziweyo lwala manani.
    //
    // ukuba uluhlu luneengcaciso ezininzi zobude obufanayo, asinakuqiniseka kwaye kufuneka sibuyise i `None` endaweni yoko.
    //
    // Zonke iimpikiswano apha zikalwe ngexabiso eliqhelekileyo (kodwa elingachazwanga) `k`, ukuze:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // UKHUSELEKO: ii-byte zokuqala ze-`len` ze-`buf` kufuneka ziqaliswe.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (yesalathiso, umgca onamachaphaza ubonakalisa elona xabiso lokuboniswa kunokwenzeka kwinani elinikiweyo lamanani.)
        //
        //
        // Impazamo inkulu kakhulu ukuba kukho ubuncinci ukubonakaliswa okuthathu phakathi kwe `v - 1 ulp` kunye ne `v + 1 ulp`.
        // asinakucacisa ukuba yeyiphi echanekileyo.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // Ngapha koko, i-1/2 ulp yanele ukwazisa izinto ezimbini ezinokubakho.
        // (khumbula ukuba sifuna ukumelwa okwahlukileyo kuzo zombini i `v - 1 ulp` kunye `v + 1 ulp`.) ayizukuphuphuma, njenge `ulp < ten_kappa` ukusuka kwitsheki yokuqala.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ukuba i `v + 1 ulp` ikufutshane nokumelwa okusondeleyo (esele ikwi `buf`), emva koko sinokubuya ngokukhuselekileyo.
        // Qaphela ukuba i-`v - 1 ulp`*inokuba* ngaphantsi kokumelwa ngoku, kodwa njenge-`1 ulp < 10^kappa / 2`, le meko yanele:
        // umgama phakathi kwe `v - 1 ulp` kunye nomelo wangoku awunakugqitha i `10^kappa / 2`.
        //
        // imeko ilingana ne `remainder + ulp < 10^kappa / 2`.
        // kuba oku kunokuphuphuma ngokulula, jonga kuqala ukuba ngaba i `remainder < 10^kappa / 2`.
        // Sele siqinisekisile ukuba i `ulp < 10^kappa / 2`, ukuba nje i `10^kappa` ayiphuphumalanga emva kwayo yonke loo nto, itshekhi yesibini ilungile.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // UKHUSELEKO: umnxeba wethu uyiqalisile loo nkumbulo.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------intsalela------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // Ngakolunye uhlangothi, ukuba i `v - 1 ulp` ikufutshane nokumelwa okusondeleyo, kuya kufuneka sisondele kwaye sibuye.
        // ngesizathu esinye akufuneki ukuba sijonge i `v + 1 ulp`.
        //
        // imeko ilingana ne `remainder - ulp >= 10^kappa / 2`.
        // kwakhona siqala sijonge ukuba ngaba i-`remainder > ulp` (qaphela ukuba ayisiyi-`remainder >= ulp`, njengoko i-`10^kappa` ingeyo zero).
        //
        // Qaphela ukuba i `remainder - ulp <= 10^kappa`, ke itshekhi yesibini ayigqobhozi.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // UKHUSELEKO: umnxeba wethu kufuneka ayicwangcisile inkumbulo.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // yongeza kuphela idijithi eyongezelelweyo xa siceliwe ukuchaneka okuchanekileyo.
                // Sikwadinga ukukhangela ukuba, ukuba i-buffer yoqobo yayingenanto, inani elongeziweyo linokongezwa kuphela xa i-`exp == limit` (imeko ye-edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // UKHUSELEKO: thina nomnxebi wethu siyiqalisile loo nkumbulo.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // Ngaphandle koko sigwetyelwe (okt, amaxabiso athile phakathi kwe `v - 1 ulp` kunye ne `v + 1 ulp` ayajikeleza kwaye amanye ayasondeza) kwaye anikezele.
        //
        None
    }
}

/// Ukuphunyezwa ngqo kunye nokulungiswa kwendlela yeGrisu eneDragbackback.
///
/// Oku kufuneka kusetyenziselwe iimeko ezininzi.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // UKHUSELEKO: Isitshekhi sokuboleka asikho krelekrele ngokwaneleyo ukuba masisebenzise i `buf`
    // kwi-branch yesibini, ke sibeka ixesha lobomi apha.
    // Kodwa sisebenzisa kuphela i `buf` ukuba i `format_exact_opt` ibuyise i `None` ke oku kulungile.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}