//! Amacandelo ohlobo lwe-16-bit olusayiniweyo olupheleleyo.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Ikhowudi entsha kufuneka isebenzise izinto ezihambelana ngqo nohlobo lwantlandlolo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }