//! Iindidi ezicofa idatha kwindawo yazo kwimemori.
//!
//! Ngamanye amaxesha kuluncedo ukuba nezinto eziqinisekisiweyo ukuba zingahambi, ngengqondo yokuba ukubekwa kwazo kwimemori akutshintshi, kwaye ke kunokuthenjelwa kubo.
//! Owona mzekelo uphambili wale meko inokuba kukuzakha ngokuzimela, njengoko ukuhambisa into ngezikhombisi kuyo kuya kuzenza zingasebenzi, ezinokubangela isimilo esingachazwanga.
//!
//! Kwinqanaba eliphezulu, i-[`Pin<P>`] iqinisekisa ukuba i-pointee yalo naluphi na uhlobo lwesikhombisi i-`P` inendawo ezinzileyo kwimemori, okuthetha ukuba ayinakushenxiselwa kwenye indawo kwaye inkumbulo yayo ayinakuhanjiswa ide ilahle.Sitsho ukuba i-pointee yi-"pinned".Izinto ziya zikhohlakala ngakumbi xa kuxoxwa ngeentlobo ezidibanisa iipini kunye nedatha engakhanyiweyo;[see below](#projections-and-structural-pinning) ngolwazi oluthe kratya.
//!
//! Ngokuzenzekelayo, zonke iintlobo ze-Rust ziyahanjiswa.
//! I-Rust ivumela ukugqithisa zonke iintlobo ngexabiso, kunye neentlobo eziqhelekileyo zesikhombisi ezinje nge [`Box<T>`] kunye ne `&mut T` zivumela ukubuyisela nokuhambisa amaxabiso aqulathe: ungaphuma kwi [`Box<T>`], okanye ungasebenzisa i [`mem::swap`].
//! [`Pin<P>`] isonga uhlobo lwesikhombisi `P`, ke [`Pin`]`<<[[Box"]`<T>> 'isebenza kakhulu njengesiqhelo
//!
//! [`Box<T>`]: when a [`Pin`]`<<[`Ibhokisi`]`<T>> `iyalahlwa, kunye nemixholo yayo, kwaye imemori iyafika
//!
//! idlulisiwe.Ngokufanayo, [`Pin`]`<&mut T>`ifana ne `&mut T`.Nangona kunjalo, i-[`Pin<P>`] ayivumeli abathengi ukuba bafumane i-[`Box<T>`] okanye i-`&mut T` kwidatha ephiniweyo, ethetha ukuba awukwazi ukusebenzisa imisebenzi enje nge [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` idinga i `&mut T`, kodwa asikwazi ukuyifumana.
//!     // Sibambekile, asinakutshintsha imixholo yezi ngxelo.
//!     // Singasebenzisa i `Pin::get_unchecked_mut`, kodwa ayikhuselekanga ngenxa yesizathu:
//!     // Asivumelekanga ukuba siyisebenzisele ukukhupha izinto kwi `Pin`.
//! }
//! ```
//!
//! Kufanelekile ukuphinda uphinde uthi i [`Pin<P>`] * ayitshintshi into yokuba umhlanganisi we-Rust ujonga zonke iintlobo ezinokuhanjiswa.I-[`mem::swap`] ihlala ibiza nayiphi na i `T`.Endaweni yokuba i-[`Pin<P>`] ithintele amaxabiso athile (abhekiswe kwizikhombisi ezisongelwe kwi-[`Pin<P>`]) ekubeni ishukunyiswe ngokwenza kube nzima ukubiza iindlela ezifuna i-`&mut T` kuzo (njenge-[`mem::swap`]).
//!
//! [`Pin<P>`] inokusetyenziselwa ukusonga naluphi na uhlobo lwesikhombisi `P`, kwaye ngenxa yoko inxibelelana ne [`Deref`] kunye ne [`DerefMut`].I-[`Pin<P>`] apho i-`P: Deref` kufuneka ithathelwe ingqalelo njenge-"`P`-style pointer" ukuya kwi-`P::Target` ebotshiwe-ke, ["Pin`]`<<[`Box`]` `<T>>`sisikhombisi esine-`T`, kunye ne [`Pin`] `<<[` Rc`]`<T>> Isalathiso esibaliwe kwisalathiso kwi-`T` ephiniweyo.
//! Ukuchaneka, i-[`Pin<P>`] ixhomekeke ekuphunyezweni kwe-[`Deref`] kunye ne-[`DerefMut`] ukuba ingaphumi kwi-`self` parameter, kwaye iya kuhlala ibuyisela isikhombisi kwidatha ephiniweyo xa zibizwa kwisikhombisi esikhonkxiweyo.
//!
//! # `Unpin`
//!
//! Iindidi ezininzi zihlala zishenxiseka ngokukhululekileyo, nokuba zicinezelwe, kuba azixhomekeki ekubeni nedilesi ezinzileyo.Oku kubandakanya zonke iintlobo ezisisiseko (ezinje nge [`bool`], [`i32`], kunye nezalathiso) kunye neendidi ezibandakanya ezi ntlobo.Iindidi ezingakhathaliyo kukucofa kuphumeze i [`Unpin`] auto-trait, ecima isiphumo se [`Pin<P>`].
//! Nge-`T: Unpin`, [`Pin`]`<<[`Box`]`<T>> `Kunye ne-[`Box<T>`] isebenza ngokufanayo, njengoko kusenziwa [` Pin`]`<&mut T>` kunye ne `&mut T`.
//!
//! Qaphela ukuba ukuphina kunye ne-[`Unpin`] kuchaphazela kuphela uhlobo oluchaziweyo `P::Target`, hayi uhlobo lwesikhombisi `P` uqobo esongelwe kwi [`Pin<P>`].Umzekelo, nokuba i [`Box<T>`] ingu [`Unpin`] ayinampembelelo kwindlela yokuziphatha kwe [`Pin`]`<<[[Box`] `<T>>`(apha, i `T` luhlobo oluchaziweyo).
//!
//! # Umzekelo: ulwakhiwo oluzimeleyo
//!
//! Ngaphambi kokuba singene kwiinkcukacha ezithe kratya ukucacisa iziqinisekiso kunye nokukhetha okunxulunyaniswa ne `Pin<T>`, sixoxa ngemizekelo yendlela enokusetyenziswa ngayo.
//! Zive ukhululekile kwi [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Olu lungelelwaniso oluzimeleyo kuba icandelo lesilayidi likhomba kwicandelo ledatha.
//! // Asinakho ukwazisa umhlanganisi malunga nesalathiso esiqhelekileyo, njengoko le patheni ingenakuchazwa ngemigaqo eqhelekileyo yokuboleka.
//! //
//! // Endaweni yoko sisebenzisa isikhombisi esiluhlaza, nangona enye yaziwa ngokungabinanto, njengoko sisazi ukuba yalatha kumtya.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Ukuqinisekisa ukuba idatha ayishukumi xa umsebenzi ubuya, siyibeka kwimfumba apho iya kuhlala khona ixesha lokuphila kwento, kwaye ekuphela kwendlela yokufikelela kuyo kungokuya kwisikhombisi kuyo.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // Senza isikhombisi kuphela ukuba idatha ibekwe ngenye indlela iya kuba sele ihambile ngaphambi kokuba siqale
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // Siyazi ukuba oku kukhuselekile kuba ukulungisa intsimi akushukumisi lonke ulwakhiwo
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Isikhombisi kufuneka sikhombe kwindawo echanekileyo, ukuba nje ulwakhiwo alushukumi.
//! //
//! // Okwangoku, sikhululekile ukuhambisa isalathi.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Kuba uhlobo lwethu alusebenzisi i-Unpin, oku kuyasilela ukudibanisa:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Umzekelo: uluhlu olunxibelelanayo olunxibelelene kabini
//!
//! Kuluhlu olunxibelelene ngokungahambelaniyo, ingqokelela ayabelanga inkumbulo yezinto ngokwazo.
//! Ulwabiwo lulawulwa ngabathengi, kwaye izinto zinokuhlala kwisakhelo sesitaki esihlala sifutshane kunengqokelela.
//!
//! Ukwenza lo msebenzi, yonke into inezikhombisi kulanduleli kunye nomlandeli kuluhlu.Izinto zinokongezwa kuphela xa zicofiwe, kuba ukuhambisa izinto ezijikelezileyo kuya kuzenza zingasebenzi izikhombisi.Ngaphaya koko, ukumiliselwa kwe [`Drop`] yoluhlu olunonxibelelwano kuya kubamba izikhombisi zalowo ungaphambi kwakhe kunye nomlandeli ukuze azisuse kuluhlu.
//!
//! Ngokubalulekileyo, kufuneka sikwazi ukuxhomekeka ekubizeni i [`drop`].Ukuba into inokuhanjiswa okanye kungeniswe into ngaphandle kokubiza i [`drop`], izikhombisi kuyo ezivela kwizinto ezingabamelwane ziya kuba yinto engekho semthethweni, eya kuthi yaphule ubume bedatha.
//!
//! Ke ngoko, ukuphina kwakhona kuza nesiqinisekiso esinxulumene [`nokwehla`].
//!
//! # `Drop` guarantee
//!
//! Injongo yokuphina kukuxhomekeka ekubekweni kwedatha ethile kwimemori.
//! Ukwenza lo msebenzi, hayi ukuhambisa idatha kuphela;Ukuhambisa kwakhona, ukuphindaphinda kwakhona, okanye kungenjalo kungasebenzi kwimemori esetyenziselwa ukugcina idatha kuthintelwe, nako.
//! Ngokuqinisekileyo, kwidatha ephiniweyo kuya kufuneka ugcine ukungafakwanga ukuba *imemori yayo ayizukungasebenzi okanye iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde ibonakalise (ngokuchanekileyo, kwidatha ekhonjiweyo kufuneka ugcine i-invariant ukuba* imemori yayo ayiyi kugunyazwa okanye iphindwe iphindwe ukususela kumzuzu wokucofa kuze kube yilapho i [`drop`] ibizwa ngokuba *Kanye kuphela xa i-[`drop`] ibuya okanye i-panics, imemori inokuphinda isetyenziswe.
//!
//! Imemori inokuba yi-"invalidated" ngokuhambisa, kodwa kwakhona ngokutshintsha i-[`Some(v)`] nge-[`None`], okanye ukubiza i-[`Vec::set_len`] ukuya kwi-"kill" ezinye izinto zivela kwi-vector.Ingaphinda iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde iphinde ibuye kwakhona ukufunyanwa kwakhona ngokusebenzisa i-[`ptr::write`] ukuyibhala ngaphezulu ngaphandle kokubiza umonakalisi kuqala.Akukho nanye kwezi evunyelweyo kwidatha ephiniweyo ngaphandle kokubiza i [`drop`].
//!
//! Olu luhlobo ngqo lwesiqinisekiso sokuba uluhlu oludibeneyo olungena ngaphakathi kwicandelo elidlulileyo kufuneka lisebenze ngokuchanekileyo.
//!
//! Qaphela ukuba esi siqinisekiso * asithethi ukuba inkumbulo ayivuzi!Kusakulungile ngokupheleleyo ukuba ungafowuneli i [`drop`] kwinto ephiniweyo (umz., Usengatsalela umnxeba i [`mem::forget`] kwi [`Pin`]`<<([`Box`]` `<T>>``).Kumzekelo woluhlu oludityaniswe kabini, loo nto inokuhlala kuluhlu.Nangona kunjalo awungekhe ukhulule okanye uphinde usebenzise ugcino ngaphandle kokubiza [`drop"].
//!
//! # `Drop` implementation
//!
//! Ukuba uhlobo lwakho lisebenzisa ukuphina (njengemizekelo emibini engentla), kuya kufuneka ulumke xa usenza i [`Drop`].Umsebenzi we [`drop`] uthatha i `&mut self`, kodwa oku kubizwa ngokuba *nokuba uhlobo lwakho lwalukhe lwaphinwa ngaphambili*!Ingathi umhlanganisi ubizwa ngokuzenzekelayo yi [`Pin::get_unchecked_mut`].
//!
//! Oku ngekhe kubangele ingxaki kwikhowudi ekhuselekileyo kuba ukumiliselwa kohlobo oluthembele ekucofeni kufuna ikhowudi engakhuselekanga, kodwa yazi ukuba uthatha isigqibo sokusebenzisa ukucofa kuhlobo lwakho (umzekelo ngokwenza into ethile kwi [`Pin`]`<<&Self>`okanye [`Pin`] `<&mut Self>` `) ineziphumo ekuphunyezweni kwe [`Drop`] ngokunjalo: ukuba into yohlobo lwakho ibinokuphina, kuya kufuneka uphathe i [`Drop`] njengokuthatha ngokungagungqiyo [` Pin`]`<<&mut Ukuzimela>.
//!
//!
//! Umzekelo, unokusebenzisa i `Drop` ngolu hlobo lulandelayo:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` kulungile kuba siyazi ukuba eli xabiso alinakuphinda lisetyenziswe emva kokuba lilahliwe.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Eyona khowudi yokulahla iya apha.
//!         }
//!     }
//! }
//! ```
//!
//! Umsebenzi u-`inner_drop` unoluhlobo ekufuneka u-[`drop`] * abe nalo, ke oku kuya kuqinisekisa ukuba awusebenzisi ngengozi i-`self`/`this` ngendlela engqubana nokukhonkotha.
//!
//! Ngaphaya koko, ukuba uhlobo lwakho luyi-`#[repr(packed)]`, umhlanganisi uya kususa ngokuzenzekelayo imihlaba ejikelezayo ukuze akwazi ukuyilahla.Inokude iyenze loo nto kwimihlaba eyenzeka ukuba ilungelelaniswe ngokwaneleyo.Ngenxa yoko, awungekhe usebenzise ukucofa ngohlobo lwe `#[repr(packed)]`.
//!
//! # Ukuqikelela kunye nokuPhonsa uLwakhiwo
//!
//! Xa usebenza ngamaqhekeza apeyintiweyo, umbuzo uphakama ukuba umntu angafikelela njani kumhlaba walolo lwakhiwo ngendlela ethatha nje [`Pin`]`<&mut Struct>`.
//! Indlela yesiqhelo kukubhala iindlela zoncedo (ezibizwa ngokuba *ziingqikelelo*) ezijika [`Pin`]`<&mut Struct>`zibe sisalathiso ebaleni, kodwa loluphi uhlobo ekubhekiswa kulo?Ngaba [`Pin`]`<&mut Field>`okanye `&mut Field`?
//! Umbuzo ofanayo uphakama ngamacandelo e `enum`, kwaye naxa ujonga iintlobo ze container/wrapper ezinje nge [`Vec<T>`], [`Box<T>`], okanye [`RefCell<T>`].
//! (Lo mbuzo usebenza kuzo zombini izikhombisi ezinokuguquguquka kunye ekwabelwana ngazo, sisebenzisa imeko eqhelekileyo yesalathiso esiguqukayo apha ukwenza umzekeliso.)
//!
//! Kuyavela ukuba inyanzelekile ukuba ibe yeyombhali wesakhiwo sedatha ukuthatha isigqibo sokuba ngaba uqikelelo olukhonkxiweyo lwentsimi ethile luyajika [`Pin`]`<&mut Struct>`into [[Pin`]` <&mut Field> `` or `&mut Field`.Kukho iingxaki ezithile nangona esona sithintelo sibalulekileyo kukungaguquguquki *:
//! Yonke intsimi inokuqikelelwa kwisalathiso esikhonkxiweyo,*okanye* ukucinywa kususwe njengenxalenye yengqikelelo.
//! Ukuba zombini zenziwe ngentsimi enye, oko akunakulunga!
//!
//! Njengombhali wesakhiwo sedatha kufuneka uthathe isigqibo kwicandelo ngalinye nokuba uphonsa i "propagates" kule ndawo okanye hayi.
//! Ukuphina okusasazayo kukwabizwa ngokuba yi "structural", kuba kulandela ubume bohlobo.
//! Kula macandelwana alandelayo, sichaza iingqwalaselo ekufuneka zenziwe kukhetho ngalunye.
//!
//! ## Ukuphina * ayiyiyo i-`field`
//!
//! Ingabonakala ngathi iyaphikisana nokuba intsimi yesakhiwo esikhonkxiweyo ayinakucinezelwa, kodwa leyo yeyona ndlela ilula: ukuba [``Pin`] <&mut Field> `ayikaze yenziwe, akukho nto inokungahambi kakuhle!Ke, ukuba uthatha isigqibo sokuba enye intsimi ayinaso isikhonkwane sobume, into ekufuneka uyenzile kukuqinisekisa ukuba awuzange wenze ireferensi ekhonjiweyo kuloo ntsimi.
//!
//! Amabala ngaphandle kokucoca ulwakhiwo kunokuba nendlela yokubonisa ejika [`Pin`]`<&mut Struct>`kwi `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Oku kulungile kuba i `field` ayikaze ithathelwe ingqalelo iphiniwe.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Unokuba ngu `impl Unpin for Struct`*nokuba* uhlobo lwe `field` ayisiyi [`Unpin`].Into ecingwa loluhlobo malunga nokucofa ayisebenzi xa kungekho [`Pin`]`<&mut Field>`ever ever created.
//!
//! ## Ukuphina * sisakhiwo se `field`
//!
//! Olunye ukhetho kukuthatha isigqibo sokuba ukuphina yi-"structural" ye-`field`, oko kuthetha ukuba ukuba ulwakhiwo lukhonkxiwe kunjalo nakwintsimi.
//!
//! Oku kuvumela ukubhala uqikelelo oludala [`Pin`]`<&mut Field>`, kungqinwa ukuba umhlaba uphawulwe:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Oku kulungile kuba i `field` icinezelwe xa i `self` ikho.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Nangona kunjalo, ukucoca ulwakhiwo kuza neemfuno ezimbalwa ezongezelelweyo:
//!
//! 1. Ulwakhiwo kufuneka lube yi-[`Unpin`] kuphela ukuba onke amacandelo ezakhiwo angama-[`Unpin`].Oku kungagqibekanga, kodwa i-[`Unpin`] yi-trait ekhuselekileyo, ukuze umbhali wesakhiwo luxanduva lwakho *hayi* ukongeza into efana ne `impl<T> Unpin for Struct<T>`.
//! (Qaphela ukuba ukongeza ukusebenza kwengqikelelo kufuna ikhowudi engakhuselekanga, ke into yokuba i [`Unpin`] yindawo ekhuselekileyo ye trait ayophuli umthetho-siseko wokuba ukhathazeke ngayo nayiphi na le nto ukuba usebenzisa `engakhuselekanga`.)
//! 2. Umonakalisi wolwakhiwo akufuneki asuse indawo eyakhiweyo ngaphandle kwengxoxo.Le yeyona ndawo ichazwe kwi [previous section][drop-impl]: `drop` ithatha i `&mut self`, kodwa ulwakhiwo (yiyo loo nto amasimi alo) kusenokwenzeka ukuba lwalukhe lwaphinwa ngaphambili.
//!     Kuya kufuneka uqinisekise ukuba awuhambisi umhlaba ngaphakathi kokuphunyezwa kwe [`Drop`].
//!     Ngokukodwa, njengoko bekuchaziwe ngaphambili, oku kuthetha ukuba ulwakhiwo lwakho kufuneka *lungabi* yi `#[repr(packed)]`.
//!     Jonga elo candelo lendlela yokubhala i [`drop`] ngendlela yokuba umhlanganisi angakunceda ukuba ungaphuli ngengozi ukuphina.
//! 3. Kuya kufuneka uqiniseke ukuba uyayibamba i [`Drop` guarantee][drop-guarantee]:
//!     nje ukuba ulwakhiwo lukhonkxiwe, imemori equlathe umxholo ayibhalwa ngaphezulu okanye idluliselwe ngaphandle kokubiza abonakalisi bomxholo.
//!     Oku kunokuba yinkohliso, njengoko kungqinwe ngu [`VecDeque<T>`]: umtshabalalisi we [`VecDeque<T>`] angangaphumeleli ukufowunela i [`drop`] kuzo zonke izinto ukuba ngaba omnye wabonakalisi i panics.Oku kwaphula isiqinisekiso se [`Drop`], kuba kungakhokelela ekubeni izinto zihanjiswe ngaphandle kokubizwa ngumonakalisi wazo.(I-[`VecDeque<T>`] ayinangqikelelo yokuphina, ke oku akubangeli kungabinangqondo.)
//! 4. Kuya kufuneka unganikezeli ngayo nayiphi na eminye imisebenzi enokuthi ikhokelele ekubeni idatha ikhutshelwe ngaphandle kwimihlaba yolwakhiwo xa uhlobo lwakho lukhonjwe.Umzekelo, ukuba i-struct iqulethe i-[`Option<T>`] kwaye kukho intsebenzo `ethathiweyo kunye nohlobo `fn(Pin<&mut Struct<T>>) -> Option<T>`, loo msebenzi unokusetyenziselwa ukuhambisa i-`T` ngaphandle kwe-`Struct<T>` ephiniweyo-oko kuthetha ukuba ukuphina akunakuba lolwakhiwo lwentsimi ebambe oku idatha.
//!
//!     Umzekelo ontsonkothileyo wokuhambisa idatha kuhlobo olupiniweyo, cinga ukuba i [`RefCell<T>`] inendlela ye `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Emva koko sinokwenza oku kulandelayo:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Le yintlekele, oko kuthetha ukuba sinokuqala ngokuwukhonkotha umxholo we [`RefCell<T>`] (sisebenzisa i `RefCell::get_pin_mut`) emva koko sihambise loo mxholo sisebenzisa ireferensi enokuguquguquka esiyifumene kamva.
//!
//! ## Examples
//!
//! Kuhlobo olunjenge-[`Vec<T>`], omabini la mathuba anokubakho (ulwakhiwo lwepini okanye hayi) iyavakala.
//! I-[`Vec<T>`] enesipinishi esakhiweyo inokuba neendlela ze-`get_pin`/`get_pin_mut` zokufumana izikhombisi ezipinkiweyo kwizinto.Nangona kunjalo, ayinakho * ukuvumela ukubiza i-[`pop`][Vec::pop] kwi-[`Vec<T>`] ekhonkxiweyo kuba oko kungahambisa imixholo (epeyintiweyo)!Kwaye ayinakuvumela i [`push`][Vec::push], enokuthi iphinde iphinde iphinde ihambise imixholo.
//!
//! I-[`Vec<T>`] ngaphandle kokucofa ulwakhiwo inokuba yi-`impl<T> Unpin for Vec<T>`, kuba imixholo ayikaze icinezelwe kwaye i-[`Vec<T>`] ngokwayo ilungile ngokuhanjiswa nayo.
//! Ngelo xesha ukuphina akunampembelelo kwi-vector kwaphela.
//!
//! Kwithala leencwadi eliqhelekileyo, iintlobo zesikhombisi ngokubanzi azinakho ukucoca, kwaye ngenxa yoko aziboneleli ngqikelelo.Kungenxa yoko le nto i `Box<T>: Unpin` ibambe yonke i `T`.
//! Kuyavakala ukwenza oku kwiindidi zesikhombisi, kuba ukuhambisa i `Box<T>` akuyihambisi i `T`: i [`Box<T>`] inokuhanjiswa ngokukhululekileyo (aka `Unpin`) nokuba i `T` ayikho.Ngapha koko, nkqu [`Pin`]`<<[`Box`]`<T>> `Kwaye [` Pin`]`<&mut T>` bahlala be-[`Unpin`] ngokwabo, ngenxa yesizathu esinye: imixholo yabo (i-`T`) icinezelwe, kodwa izikhombisi ngokwazo zingahanjiswa ngaphandle kokuhambisa idatha ephiniweyo.
//! Kuzo zombini i [`Box<T>`] kunye [`Pin`]`<<[`Box`]`<T>> `, Nokuba umxholo uphawulwe uxhomekeke ngokupheleleyo kwisikhombisi esikhonkxiweyo, oko kuthetha ukuba ukuphina * akulolwakhiwo.
//!
//! Xa uphumeza indibaniselwano ye-[`Future`], uya kudinga ukuphina ulwakhiwo lwe-futures enedleke, njengoko ufuna ukufumana izikhombisi ezipinkiweyo kubo ukubiza i [`poll`].
//! Kodwa ukuba indibaniselwano yakho iqulethe nayiphi na enye idatha engafuneki ukuba icofwe, ungenza la masimi angabi lolwakhiwo kwaye kungoko ke ukufikelela kuwo ngokukhululekileyo ngesalathiso esinokuguquguquka nokuba une [`Pin`]`<&mut Self>`` (such njengakwindlela yakho yokuphumeza i [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Isikhombisi esikhonkxiweyo.
///
/// Esi sisongelo esijikeleze uhlobo lwesikhombisi esenza ukuba isikhombisi "pin" sibe lixabiso laso endaweni, sithintele ixabiso ekubhekiswe kulo sisikhombisi ekubeni sisuswe ngaphandle kokuba sisebenzisa i [`Unpin`].
///
///
/// *Jonga amaxwebhu e [`pin` module] ngenkcazo yokuphina.*
///
/// [`pin` module]: self
///
// Note: i `Clone` evela ngezantsi ibangela ukungathandeki njengoko kunokwenzeka ukuphumeza
// `Clone` kwizalathiso eziguqukayo.
// Bona i <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> ngolwazi oluthe kratya.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Oluphumezo lulandelayo alwenziwanga ukuthintela imiba yesandi.
// `&self.pointer` akufuneki ifikeleleke kuzalisekiso lwe trait olungathembekanga.
//
// Bona i <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> ngolwazi oluthe kratya.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Yenza i `Pin<P>` entsha ejikeleze isikhombisi kwidatha ethile yohlobo olusebenzisa i [`Unpin`].
    ///
    /// Ngokungafaniyo ne `Pin::new_unchecked`, le ndlela ikhuselekile kuba isalathiso se `P` sisetyenziselwa uhlobo lwe [`Unpin`], nesirhoxisa isiqinisekiso sokuphina.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // UKHUSELEKO: ixabiso elalathiwe kwi-`Unpin`, kwaye ke akukho mfuneko
        // ujikeleze ukuphina.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Ayisongeli le `Pin<P>` ibuyisela isikhombisi esingaphantsi.
    ///
    /// Oku kufuna ukuba idatha engaphakathi kule `Pin` ibe yi-[`Unpin`] ukuze sikwazi ukungahoyi izinto eziphikisayo xa usikhulula.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Yenza i `Pin<P>` entsha ejikeleze ireferensi kwidatha ethile yohlobo olunokuthi okanye lungasebenzi i `Unpin`.
    ///
    /// Ukuba i-`pointer` isetyenziselwa uhlobo lwe-`Unpin`, i-`Pin::new` kufuneka isetyenziswe endaweni yoko.
    ///
    /// # Safety
    ///
    /// Lo makhi akhuselekanga kuba asinakuqinisekisa ukuba idatha ekhonjwe ngu `pointer` icinezelwe, oko kuthetha ukuba idatha ayisayi kususwa okanye ukugcinwa kwayo kungasebenzi de kube kulahlekile.
    /// Ukuba i-`Pin<P>` eyakhiweyo ayiqinisekisi ukuba idatha ye-`P` ikhombe kuyo, oko kukwaphula ikhontrakthi ye-API kwaye kungakhokelela kwindlela yokuziphatha engachazwanga kwimisebenzi ye (safe) kamva.
    ///
    /// Ngokusebenzisa le ndlela, wenza i-promise malunga nokuphunyezwa kwe `P::Deref` kunye ne `P::DerefMut`, ukuba zikhona.
    /// Eyona nto ibaluleke kakhulu, akufuneki baphume ngaphandle kweempikiswano zabo ze-`self`: I-`Pin::as_mut` kunye ne-`Pin::as_ref` baya kubiza i-`DerefMut::deref_mut` kunye ne-`Deref::deref`*kwisikhombisi esikhonkxiweyo* kwaye balindele ukuba ezi ndlela zixhase abahlaseli abapholileyo.
    /// Ngapha koko, ngokubiza le ndlela wena promise ukuba isalathiso se `P` esingasayi kuphinda sikhutshwe kwakhona;Ngokukodwa, akufuneki kwenzeke ukuba ufumane i-`&mut P::Target` kwaye emva koko ushiye ireferensi (usebenzisa, umzekelo [`mem::swap`]).
    ///
    ///
    /// Umzekelo, ukubiza i-`Pin::new_unchecked` kwi-`&'a mut T` akukhuselekanga kuba ngelixa ukwazi ukuyicofa ixesha elinikiweyo le-`'a`, awunandlela yakugcina ukuba igcinwe iphiniwe xa i-`'a` iphela:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Oku kufanele ukuba kuthetha ukuba i-pointee `a` ayinakuphinda ihambe kwakhona.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Idilesi ye `a` itshintshele kwisithuba se-``b '' slot, ke i `a` yashukunyiswa nangona besikhe sayiphawula ngaphambili!Saphule ikhontrakthi ye-API yokuphina.
    /////
    /// }
    /// ```
    ///
    /// Ixabiso, nje ukuba liphiniwe, kufuneka lihlale liphiniwe unaphakade (ngaphandle kokuba uhlobo lwalo lusebenzisa i `Unpin`).
    ///
    /// Ngokufanayo, ukubiza i-`Pin::new_unchecked` kwi-`Rc<T>` akukhuselekanga kuba kunokubakho izibizo kwidatha efanayo engaphantsi kwemiqobo yokuthintela:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Oku kufanele ukuba kuthetha ukuba i-pointee ayinakuphinda ihambe kwakhona.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Ngoku, ukuba i `x` yayikukuphela kwesalathiso, sinesalathiso esinokuguquguquka kwidatha esiyikhonkxe ngentla, esinokuyisebenzisa ukuyisusa njengoko sibonile kumzekelo wangaphambili.
    ///     // Saphule ikhontrakthi ye-API yokucinezela.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ifumana isalathiso esabiweyo esikhonkxiweyo kwesi sikhombisi siphiniweyo.
    ///
    /// Le yindlela yohlobo oluqhelekileyo ukusuka kwi `&Pin<Pointer<T>>` ukuya kwi `Pin<&T>`.
    /// Kukhuselekile kuba, njengenxalenye yesivumelwano se `Pin::new_unchecked`, i-pointee ayinakushukuma emva kokuba i `Pin<Pointer<T>>` yenziwe.
    ///
    /// "Malicious" Ukuphunyezwa kwe `Pointer::Deref` ngokufanayo kugwetywe ngaphandle yimvumelwano ye `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // UKHUSELEKO: jonga amaxwebhu kulo msebenzi
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Ayisongeli le `Pin<P>` ibuyisela isikhombisi esingaphantsi.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga.Kuya kufuneka uqinisekise ukuba uya kuqhubeka nokuphatha isikhombisi `P` njengoko sikhonkxiwe emva kokuba ubize lo msebenzi, ukuze kungene kohlobo lwe `Pin` kungagcinwa.
    /// Ukuba ikhowudi isebenzisa isiphumo `P` ayiqhubeki nokugcina izinto ezihluthayo ezinyhasha ikhontrakthi ye-API kwaye zinokukhokelela ekuziphatheni okungachazwanga kwimisebenzi ye (safe) yamva.
    ///
    ///
    /// Ukuba idatha esisiseko yi [`Unpin`], [`Pin::into_inner`] kufuneka isetyenziswe endaweni yoko.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Ufumana isalathiso esinokutshintshwa esikhonkxiweyo kwisikhombisi esikhonkxiweyo.
    ///
    /// Le yindlela yohlobo oluqhelekileyo ukusuka kwi `&mut Pin<Pointer<T>>` ukuya kwi `Pin<&mut T>`.
    /// Kukhuselekile kuba, njengenxalenye yesivumelwano se `Pin::new_unchecked`, i-pointee ayinakushukuma emva kokuba i `Pin<Pointer<T>>` yenziwe.
    ///
    /// "Malicious" Ukuphunyezwa kwe `Pointer::DerefMut` ngokufanayo kugwetywe ngaphandle yimvumelwano ye `Pin::new_unchecked`.
    ///
    /// Le ndlela iluncedo xa usenza iifowuni ezininzi kwimisebenzi edla uhlobo oluchongiweyo.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // Yenza into
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` Isebenzisa i `self`, ke phinda uboleke i `Pin<&mut Self>` nge `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // UKHUSELEKO: jonga amaxwebhu kulo msebenzi
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Nika ixabiso elitsha kwimemori emva kwesalathiso esikhonkxiweyo.
    ///
    /// Oku kubhala ngaphezulu kwedatha ephiniweyo, kodwa loo nto ilungile: isonakalisi sayo siyabaleka ngaphambi kokuba sibhalwe ngaphezulu, ke akukho siqinisekiso sokuphina siphulwayo.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Yakha ipini entsha ngokwenza imephu yexabiso langaphakathi.
    ///
    /// Umzekelo, ukuba ufuna ukufumana i-`Pin` yentsimi yento ethile, ungasebenzisa oku ukufikelela kulomhlaba kumgca omnye wekhowudi.
    /// Nangona kunjalo, kukho i-gotchas ezininzi kwezi "pinning projections";
    /// jonga amaxwebhu e [`pin` module] ngeenkcukacha ezithe kratya kwesi sihloko.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga.
    /// Kuya kufuneka uqinisekise ukuba idatha oyibuyisayo ayizukuhamba ixesha elide njengoko ixabiso lempikiswano lingashukumi (umzekelo, kuba yenye yeendawo zelo xabiso), kwaye awuphumi kwimpikiswano oyifumeneyo umsebenzi wangaphakathi.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // UKHUSELEKO: ikhontrakthi yokhuseleko ye `new_unchecked` kufuneka ibenjalo
        // igcinwe ngulowo ufowunayo.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Ufumana ireferensi ekwabelwana ngayo ngaphandle kwephini.
    ///
    /// Oku kukhuselekile kuba akunakwenzeka ukuba ushiye ireferensi ekwabelwana ngayo.
    /// Ingabonakala ngathi kukho umba apha onokuguquguquka kwangaphakathi: enyanisweni, * kunokwenzeka ukuba kususwe i `T` ngaphandle kwe `&RefCell<T>`.
    /// Nangona kunjalo, ayisiyongxaki lo gama nje ingekho i-`Pin<&T>` ekhomba kwidatha efanayo, kwaye i-`RefCell<T>` ayikuvumeli ukuba wenze isalathiso esikhonkxiweyo kwimixholo yayo.
    ///
    /// Bona ingxoxo kwi ["pinning projections"] ngolwazi oluthe kratya.
    ///
    /// Note: I `Pin` ikwasebenzisa i `Deref` ekujolise kuyo, enokusetyenziselwa ukufikelela kwixabiso langaphakathi.
    /// Nangona kunjalo, i `Deref` ibonelela kuphela ngesalathiso esiphila ixesha elide njengokubolekwa kwe `Pin`, hayi ubomi be `Pin` uqobo.
    /// Le ndlela ivumela ukuguqula i `Pin` ibe sisalathiso kunye nexesha elifanayo lobomi njenge `Pin` yoqobo.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Iguqula le `Pin<&mut T>` ibe yi-`Pin<&T>` ngexesha elifanayo lobomi.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Ifumana ireferensi enokuguquguquka kwidatha engaphakathi kule `Pin`.
    ///
    /// Oku kufuna ukuba idatha engaphakathi kule `Pin` yi-`Unpin`.
    ///
    /// Note: I `Pin` ikwasebenzisa i `DerefMut` kwidatha, enokusetyenziselwa ukufikelela kwixabiso langaphakathi.
    /// Nangona kunjalo, i `DerefMut` ibonelela kuphela ngesalathiso esiphila ixesha elide njengokubolekwa kwe `Pin`, hayi ubomi be `Pin` uqobo.
    ///
    /// Le ndlela ivumela ukuguqula i `Pin` ibe sisalathiso kunye nexesha elifanayo lobomi njenge `Pin` yoqobo.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Ifumana ireferensi enokuguquguquka kwidatha engaphakathi kule `Pin`.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga.
    /// Kuya kufuneka uqinisekise ukuba awusoze uyisuse idatha kwisalathiso esiguqukayo osifumanayo xa ubiza lo msebenzi, ukuze izinto ezingenayo kuhlobo lwe `Pin` zinokugcinwa.
    ///
    ///
    /// Ukuba idatha esisiseko yi `Unpin`, `Pin::get_mut` kufuneka isetyenziswe endaweni yoko.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Yenza ipini entsha ngokwenza imephu yexabiso langaphakathi.
    ///
    /// Umzekelo, ukuba ufuna ukufumana i-`Pin` yentsimi yento ethile, ungasebenzisa oku ukufikelela kulomhlaba kumgca omnye wekhowudi.
    /// Nangona kunjalo, kukho i-gotchas ezininzi kwezi "pinning projections";
    /// jonga amaxwebhu e [`pin` module] ngeenkcukacha ezithe kratya kwesi sihloko.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga.
    /// Kuya kufuneka uqinisekise ukuba idatha oyibuyisayo ayizukuhamba ixesha elide njengoko ixabiso lempikiswano lingashukumi (umzekelo, kuba yenye yeendawo zelo xabiso), kwaye awuphumi kwimpikiswano oyifumeneyo umsebenzi wangaphakathi.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // UKHUSELEKO: umntu ofowunayo unoxanduva lokungahambi
        // value kwesi salathiso.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // UKHUSELEKO: njengoko ixabiso le `this` liqinisekisiwe ukuba alinayo
        // ikhutshiwe, le fowuni iya kwi `new_unchecked` ikhuselekile.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Fumana ireferensi ekhonkxiweyo kwisalathiso esimileyo.
    ///
    /// Oku kukhuselekile, kuba i `T` ibolekwe ixesha lokuphila le `'static`, elingaze liphele.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // UKHUSELEKO: I-static loan eqinisekisa ukuba idatha ayizukubakho
        // moved/invalidated ide ilahle (engasoze).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Fumana ireferensi enokuthenjwa kwisinxibelelanisi esingaguqukiyo.
    ///
    /// Oku kukhuselekile, kuba i `T` ibolekwe ixesha lokuphila le `'static`, elingaze liphele.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // UKHUSELEKO: I-static loan eqinisekisa ukuba idatha ayizukubakho
        // moved/invalidated ide ilahle (engasoze).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: oku kuthetha ukuba nayiphi na impl ye `CoerceUnsized` evumela ukunyanzelwa ukusuka
// Uhlobo olufaka i `Deref<Target=impl !Unpin>` kuhlobo olufaka i `Deref<Target=Unpin>` aluqinisekanga.
// Nawuphi na u-impl onjalo unokungaqondakali ngenxa yezinye izizathu, nangona kunjalo, kufuneka nje sikhathalele ukuba singazivumeli ezo mpahla ukuba zihlale e std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}