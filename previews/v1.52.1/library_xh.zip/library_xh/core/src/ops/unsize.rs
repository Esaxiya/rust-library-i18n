use crate::marker::Unsize;

/// I-Trait ebonisa ukuba esi sisikhombisi okanye esisongelayo esinye, apho ukujonga izinto kungenziwa kwisalathiso.
///
/// Bona i [DST coercion RFC][dst-coerce] kunye ne [the nomicon entry on coercion][nomicon-coerce] ngolwazi oluthe kratya.
///
/// Iindidi zesikhombisi esakhiweyo, izikhombisi eziya kwi `T` ziya kunyanzela izikhombisi ukuya kwi `U` ukuba i `T: Unsize<U>` ngokuguqula ukusuka kwisikhombisi esincinci ukuya kwisikhombisi esityebileyo.
///
/// Ngeentlobo zesiko, ukunyanzelwa apha kusebenza ngokunyanzela i `Foo<T>` ukuya kwi `Foo<U>` ukubonelelwa kokufakwa kwe `CoerceUnsized<Foo<U>> for Foo<T>`.
/// I-impl enjalo inokubhalwa kuphela ukuba i-`Foo<T>` inentsimi enye engeyiyo-phantomdata ebandakanya i-`T`.
/// Ukuba uhlobo lwentsimi ngu-`Bar<T>`, kufuneka kwenziwe i-`CoerceUnsized<Bar<U>> for Bar<T>`.
/// Ukunyanzelwa kuyakusebenza ngokunyanzela umhlaba we `Bar<T>` ukuya kwi `Bar<U>` kwaye ugcwalise amanye amasimi ukusuka kwi `Foo<T>` ukwenza i `Foo<U>`.
/// Oku kuyakuqhuba ngokuchanekileyo kumhlaba wesikhombisi kunye nokunyanzela oko.
///
/// Ngokubanzi, kwizikhombisi ezi-smart uya kuyisebenzisa i `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, ngokuzikhethela i `?Sized` eboshwe kwi `T` uqobo.
/// Iindidi ezisongelayo ezingxala ngokuthe ngqo i `T` njenge `Cell<T>` kunye ne `RefCell<T>`, ungayisebenzisa ngokuthe ngqo i `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Oku kuyakuvumela ukunyanzelwa kweentlobo ezinje nge `Cell<Box<T>>` zisebenze.
///
/// [`Unsize`][unsize] isetyenziselwa ukumakisha iintlobo ezinokunyanzelwa kwii-DSTs ukuba ngasemva kwezikhombisi.Iphunyezwa ngokuzenzekelayo ngumhlanganisi.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * u-U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * u-U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * iqumrhu U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* u-U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* u-U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *Iqela T->* u-U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Oku kusetyenziselwa ukhuseleko lwento, ukujonga ukuba uhlobo lwendlela yokwamkela enokuthunyelwa kuyo.
///
/// Umzekelo wokuphunyezwa kwe trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *Iqela T->* u-U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* u-U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}