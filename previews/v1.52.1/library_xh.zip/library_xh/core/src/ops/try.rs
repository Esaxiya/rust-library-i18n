/// I-trait yokwenza isimilo sokuziphatha komqhubi we `?`.
///
/// Uhlobo olusebenzisa i `Try` lolunye olunendlela ye-canonical yokulujonga ngokwe-success/failure dichotomy.
/// Le trait ivumela zombini ukukhupha loo mpumelelo okanye amaxabiso okusilela kwimeko esele ikhona kunye nokwenza imeko entsha kwimpumelelo okanye kwixabiso lokusilela.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Uhlobo lweli xabiso xa ujongwa njengophumeleleyo.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Uhlobo lweli xabiso xa ujongwa njengongaphumelelanga.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Sebenzisa umqhubi we "?".Ukubuyiswa kwe `Ok(t)` kuthetha ukuba ukwenziwa kufuneka kuqhubeke ngokwesiqhelo, kwaye iziphumo ze `?` lixabiso `t`.
    /// Ukubuyiswa kwe `Err(e)` kuthetha ukuba ukwenziwa kwe-branch kufuneka kufikelelwe ngaphakathi kwi-`catch`, okanye kubuya emsebenzini.
    ///
    /// Ukuba iziphumo ze-`Err(e)` zibuyisiwe, ixabiso le-`e` liya kuba yi-"wrapped" kuhlobo lokubuya kwesithuba esivaliweyo (ekufuneka sona siphumeze i-`Try`).
    ///
    /// Ngokukodwa, ixabiso le `X::from_error(From::from(e))` libuyisiwe, apho i `X` luhlobo lokubuyisa lomsebenzi ovalelweyo.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Songa ixabiso lempazamo ukwakha iziphumo ezidityanisiweyo.
    /// Umzekelo, i `Result::Err(x)` kunye ne `Result::from_error(x)` ziyalingana.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Songa ixabiso elilungileyo ukwakha iziphumo ezidityanisiweyo.
    /// Umzekelo, i `Result::Ok(x)` kunye ne `Result::from_ok(x)` ziyalingana.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}