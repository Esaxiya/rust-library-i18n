/// Isetyenziselwa imisebenzi yesalathiso (`container[index]`) kwimeko ezingaguqukiyo.
///
/// `container[index]` Iswekile yentsingiselo ye `*container.index(index)`, kodwa kuphela xa isetyenziswa njengexabiso elingenakuguquka.
/// Ukuba ixabiso elinokuguquguquka liceliwe, i [`IndexMut`] isetyenziswa endaweni yoko.
/// Oku kuvumela izinto ezintle ezinje nge `let value = v[index]` ukuba uhlobo lwe `value` lusebenzisa i [`Copy`].
///
/// # Examples
///
/// Lo mzekelo ulandelayo usebenzisa i `Index` kwisitya sokufunda kuphela se `NucleotideCount`, esenza ukuba ukubalwa komntu ngamnye kufunyanwe ngesalathiso sesintaksi.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Uhlobo olubuyisiweyo emva kokufakwa kwisalathiso.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Yenza isalathiso se-(`container[index]`) yokusebenza.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Isetyenziselwe imisebenzi yesalathiso (`container[index]`) kwimeko ezinokuguquguquka.
///
/// `container[index]` Iswekile yentsingiselo ye `*container.index_mut(index)`, kodwa kuphela xa isetyenziswa njengexabiso elinokuguquguquka.
/// Ukuba ixabiso elingaguqukiyo liyacelwa, i [`Index`] trait isetyenziswa endaweni yoko.
/// Oku kuvumela izinto ezintle ezinje nge `v[index] = value`.
///
/// # Examples
///
/// Ukuphunyezwa okulula kakhulu kwesakhiwo se `Balance` esinamacala amabini, apho ngalinye linokukhonjiswa ngokungaguquguqukiyo nangokungaguqukiyo.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Kule meko, i-`balance[Side::Right]` iswekile ye-`*balance.index(Side::Right)`, kuba sifunda*`balance[Side::Right]` kuphela, asiyibhali.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Nangona kunjalo, kule meko i-`balance[Side::Left]` iswekile ye-`*balance.index_mut(Side::Left)`, kuba sibhala i-`balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Yenza isalathiso esinokuguquguquka sokusebenza kwe (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}