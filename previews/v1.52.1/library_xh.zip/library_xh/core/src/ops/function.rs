/// Inguqulelo yomsebenzisi wefowuni ethatha umamkeli ongaguqukiyo.
///
/// Iimeko ze `Fn` zinokubizwa ziphindaphindwe ngaphandle kokutshintsha kombuso.
///
/// *Le trait (`Fn`) ayizukubhidaniswa ne [function pointers] (`fn`).*
///
/// `Fn` iphunyezwa ngokuzenzekelayo ngokuvalwa okuthatha kuphela izingqinisiso ezingaguqukiyo kwizinto eziguqulweyo okanye ezingabambi nantoni na, kunye ne (safe) [function pointers] (enezinye imiqolomba, jonga amaxwebhu abo ngeenkcukacha ezithe kratya).
///
/// Ukongeza, kulo naluphi na uhlobo `F` olusebenzisa i `Fn`, `&F` isebenzisa i `Fn`, nayo.
///
/// Kuba zombini i [`FnMut`] kunye ne [`FnOnce`] zingaphezulu kwe `Fn`, nawuphi na umzekelo we `Fn` unokusetyenziswa njengeparameter apho kulindeleke i [`FnMut`] okanye i [`FnOnce`].
///
/// Sebenzisa i `Fn` njengesibophelelo xa ufuna ukwamkela ipharamitha yohlobo olufana nomsebenzi kwaye kufuneka uyitsalele umnxeba ngokuphindaphindiweyo kwaye ngaphandle kokutshintsha ilizwe (umz., Xa uyibiza ngaxeshanye).
/// Ukuba awuyidingi loo mfuneko ingqongqo, sebenzisa i [`FnMut`] okanye i [`FnOnce`] njengemida.
///
/// Bona i [chapter on closures in *The Rust Programming Language*][book] ngolwazi oluthe kratya kwesi sihloko.
///
/// Kwakhona inqaku sis syntax ekhethekileyo ye `Fn` traits (umz
/// `Fn(usize, bool) -> sebenzisa`).Abo banomdla kwiinkcukacha zobuchwephesha boku banokubhekisa kwi [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ukubiza ukuvalwa
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Sebenzisa ipharamitha ye `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ukuze i-regex ixhomekeke kwi `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Yenza umsebenzi wokufowuna.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Inguqulelo yomsebenzisi wefowuni ethatha isamkeli esiguqukayo.
///
/// Iimeko ze `FnMut` zinokubizwa ziphindaphindwe kwaye zinokutshintsha imeko.
///
/// `FnMut` iphunyezwa ngokuzenzekelayo ngokuvalwa okuthatha izingqinisiso eziguqukayo kwizinto ezibiweyo, kunye nazo zonke iintlobo ezisebenzisa i [`Fn`], umzekelo, (safe) [function pointers] (okoko i `FnMut` yindawo ephezulu ye [`Fn`]).
/// Ukongeza, kulo naluphi na uhlobo `F` olusebenzisa i `FnMut`, `&mut F` isebenzisa i `FnMut`, nayo.
///
/// Kuba i [`FnOnce`] yindawo ephezulu ye `FnMut`, nawuphi na umzekelo we `FnMut` unokusetyenziswa apho kulindelwe i [`FnOnce`], kwaye ukusukela oko i [`Fn`] sisisulu se `FnMut`, nawuphi na umzekelo we [`Fn`] unokusetyenziswa apho kulindelwe i `FnMut`.
///
/// Sebenzisa i `FnMut` njengesibophelelo xa ufuna ukwamkela ipharamitha yohlobo olufana nomsebenzi kwaye kufuneka uyitsalele umnxeba ngokuphindaphindiweyo, ngelixa uyivumela ukuba iguqule imeko.
/// Ukuba awufuni ukuba iparameter iguqule imeko, sebenzisa i [`Fn`] njengesibophelelo;ukuba awudingi ukuyitsalela umnxeba ngokuphindaphindiweyo, sebenzisa i [`FnOnce`].
///
/// Bona i [chapter on closures in *The Rust Programming Language*][book] ngolwazi oluthe kratya kwesi sihloko.
///
/// Kwakhona inqaku sis syntax ekhethekileyo ye `Fn` traits (umz
/// `Fn(usize, bool) -> sebenzisa`).Abo banomdla kwiinkcukacha zobuchwephesha boku banokubhekisa kwi [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ukubiza ukuvalwa okungaguqukiyo
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Sebenzisa ipharamitha ye `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ukuze i-regex ixhomekeke kwi `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Yenza umsebenzi wokufowuna.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Inguqulelo yomqhubi weefowuni othatha ixabiso elamkelayo.
///
/// Iimeko ze `FnOnce` zinokubizwa, kodwa zisenokungaphinde zibekho amaxesha ngamaxesha.Ngenxa yoku, ukuba kuphela kwento eyaziwayo malunga nohlobo kukuba isebenzisa i `FnOnce`, inokubizwa kube kanye kuphela.
///
/// `FnOnce` iphunyezwa ngokuzenzekelayo ngokuvalwa okunokuthi kuthathe izinto eziguqulweyo, kunye nazo zonke iintlobo ezisebenzisa i [`FnMut`], umzekelo, (safe) [function pointers] (okoko i `FnOnce` yindawo ephezulu ye [`FnMut`]).
///
///
/// Kuba zombini i [`Fn`] kunye ne [`FnMut`] zizinto ezingaphantsi ze `FnOnce`, nawuphi na umzekelo we [`Fn`] okanye i [`FnMut`] unokusetyenziswa apho kulindelwe i `FnOnce`.
///
/// Sebenzisa i `FnOnce` njengesibophelelo xa ufuna ukwamkela ipharamitha yohlobo lomsebenzi-kwaye ufuna ukubiza kube kanye.
/// Ukuba ufuna ukubiza ipharamitha ngokuphindaphindiweyo, sebenzisa i [`FnMut`] njengesibophelelo;ukuba uyayidinga ukuba ungatshintshi imeko, sebenzisa i [`Fn`].
///
/// Bona i [chapter on closures in *The Rust Programming Language*][book] ngolwazi oluthe kratya kwesi sihloko.
///
/// Kwakhona inqaku sis syntax ekhethekileyo ye `Fn` traits (umz
/// `Fn(usize, bool) -> sebenzisa`).Abo banomdla kwiinkcukacha zobuchwephesha boku banokubhekisa kwi [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Sebenzisa ipharamitha ye `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` Isebenzisa izinto zayo eziguqulweyo, ke ayinakuqhutywa ngaphezulu kwesinye.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Ukuzama ukubhenela i `func()` kwakhona kuya kuyiphosa impazamo ye `use of moved value` ye `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` Ayinakuphinda ibhenelwe ngeli nqanaba
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ukuze i-regex ixhomekeke kwi `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Uhlobo olubuyisiweyo emva kokuba umsebenzisi wefowuni esetyenzisiwe.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Yenza umsebenzi wokufowuna.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}