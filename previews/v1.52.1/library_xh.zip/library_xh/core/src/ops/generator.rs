use crate::marker::Unpin;
use crate::pin::Pin;

/// Iziphumo zokuqalisa kwakhona komvelisi.
///
/// Le enum ibuyisiwe kwindlela ye `Generator::resume` kwaye ibonisa amaxabiso okubuyisa anokubakho omvelisi.
/// Okwangoku oku kungqinelana nokuba yindawo yokumisa i (`Yielded`) okanye indawo yokuphelisa i (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Umvelisi unqunyanyisiwe ngexabiso.
    ///
    /// Lo rhulumente ubonakalisa ukuba umvelisi unqunyanyisiwe, kwaye uhambelana nengxelo ye `yield`.
    /// Ixabiso elinikezwe kolu luhlu lihambelana nenkcazo edluliselwe kwi-`yield` kwaye ivumela iijenreyitha ukuba zibonelele ngexabiso ngalinye xa zinika.
    ///
    ///
    Yielded(Y),

    /// Umvelisi ugqibe ngexabiso lokubuyisa.
    ///
    /// Eli lizwe libonisa ukuba umvelisi ukugqibile ukwenziwa ngexabiso elinikiweyo.
    /// Nje ukuba umvelisi abuyise i `Complete` ithathwa njengempazamo yenkqubo ukubiza i `resume` kwakhona.
    ///
    Complete(R),
}

/// I-trait iphunyezwe ziindidi zejenreyitha eyakhiweyo.
///
/// Iijenreyitha, ezikwabizwa ngokuba zii-coroutines, okwangoku zilulwimi kwi Rust.
/// Yongezwe kwiijenreyitha ze [RFC 2033] okwangoku zijolise ekubeni zibonelele ngokuyintloko ibhloko yokwakha ye-async/await syntax kodwa iya kuthi yandise ikwabonelela ngenkcazo ye-ergonomic yeeterators kunye nezinye izinto zokuqala.
///
///
/// Is syntax kunye neesemantiki zabavelisi azizinzanga kwaye ziya kufuna enye iRFC yozinzo.Ngeli xesha, nangona kunjalo, i-syntax ifana nokuvalwa:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Amaxwebhu amaninzi abavelisi anokufunyanwa kwincwadi engazinzanga.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Uhlobo lwexabiso eliveliswa ngumvelisi.
    ///
    /// Olu hlobo ludibeneyo luhambelana nentetho ye `yield` kunye namaxabiso avumelekileyo ukuba abuyiswe ngalo lonke ixesha isivuno somvelisi.
    ///
    /// Umzekelo i-iterator-as-a-generator inokuba nayo olu hlobo njenge-`T`, uhlobo olo lubhalwa ngaphezulu.
    ///
    type Yield;

    /// Uhlobo lwexabiso olubuyiswa ngumvelisi.
    ///
    /// Oku kungqinelana nohlobo olubuyiswe kumvelisi wenkunkuma nokuba inesiteyitimenti se `return` okanye ngokungagungqiyo njengentetho yokugqibela yomvelisi ngokwenyani.
    /// Umzekelo i-futures inokusebenzisa oku njenge-`Result<T, E>` njengoko imele i-future egqityiweyo.
    ///
    ///
    type Return;

    /// Iqalisa kwakhona ukwenziwa kwale generator.
    ///
    /// Lo msebenzi uza kuqalisa ukwenziwa komvelisi okanye uqale ukwenziwa ukuba awukabikho.
    /// Le fowuni iya kubuyela kwindawo yokugqibela yokumiswa komvelisi, iqale kwakhona ukwenziwa kwi `yield` yamva nje.
    /// Umvelisi uya kuqhubeka esenza de kube kuvelise okanye kubuyise, ngelo xesha lo msebenzi uya kubuya.
    ///
    /// # Ixabiso lokubuyisa
    ///
    /// I-`GeneratorState` enum ebuyisiweyo ivela kulo msebenzi ibonisa ukuba injani na imeko yejeneretha ekubuyeni kwayo.
    /// Ukuba umahluko we `Yielded` ubuyisiwe emva koko umvelisi ufikelele kwinqanaba lokumiswa kwaye ixabiso likhutshiwe.
    /// Iijenreyitha zikarhulumente ziyafumaneka ukuze ziqhubeke kwakhona kwinqanaba elizayo.
    ///
    /// Ukuba i `Complete` ibuyisiwe emva koko umvelisi ugqibile ngokupheleleyo ngexabiso elinikiweyo.Akuvumelekile ukuba umvelisi aqhubeke kwakhona.
    ///
    /// # Panics
    ///
    /// Lo msebenzi unokuthi panic ukuba ubizwa emva kokuba umahluko we `Complete` ubuyisiwe ngaphambili.
    /// Ngelixa oomatshini bokuvelisa ngolwimi baqinisekisiwe ukuba panic ekuqalekeni emva kwe `Complete`, oku akuqinisekiswanga kuko konke ukuphunyezwa kwe `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}