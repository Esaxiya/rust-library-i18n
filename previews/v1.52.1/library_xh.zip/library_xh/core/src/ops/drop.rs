/// Ikhowudi yesiqhelo ngaphakathi komtshabalalisi.
///
/// Xa ixabiso lingasadingeki, i Rust iya kuqhuba i "destructor" kwelo xabiso.
/// Eyona ndlela ixhaphakileyo yokuba ixabiso alisafuneki kuxa liphuma kwinqanaba.Abonakalisi basenokuqhuba kwezinye iimeko, kodwa siza kugxila kubungakanani bemizekelo apha.
/// Ukufunda ngamanye ala matyala, nceda ubone icandelo le [the reference] kubatshabalalisi.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Lo monakalo unamalungu amabini:
/// - Ukutsalela umnxeba kwi `Drop::drop` ngexabiso elo, ukuba le `Drop` trait ekhethekileyo iphunyeziwe ngohlobo lwayo.
/// - I-"drop glue" eveliswe ngokuzenzekelayo ephinda ibize abonakalisi bayo yonke imimandla yeli xabiso.
///
/// Njengoko i-Rust ibiza ngokuzenzekelayo abonakalisi bayo yonke imimandla enayo, awunyanzelekanga ukuba uphumeze i `Drop` kwiimeko ezininzi.
/// Kodwa kukho iimeko ezithile apho kuluncedo, umzekelo kwiindidi ezilawula ngokuthe ngqo isibonelelo.
/// Oovimba bangaba yimemori, inokuba sisichazi sefayile, isokethi yenethiwekhi.
/// Nje ukuba ixabiso lolo hlobo lingasasetyenziswa, kufanele ukuba libe yi-"clean up" ngobutyebi bayo ngokukhulula imemori okanye ukuvala ifayile okanye isokethi.
/// Lo ngumsebenzi womonakalisi, kwaye ke ngumsebenzi we `Drop::drop`.
///
/// ## Examples
///
/// Ukubona abonakalisi besenzo, masiqwalasele le nkqubo ilandelayo:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// I-Rust iya kuqala ukubiza i-`Drop::drop` ye-`_x` kwaye emva koko kuzo zombini i-`_x.one` kunye ne-`_x.two`, oko kuthetha ukuba ukuqhuba oku kuya kuprinta
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Nokuba sisusa ukuphunyezwa kwe `Drop` ye `HasTwoDrop`, abonakalisi bamasimi ayo basabizwa.
/// Oku kungakhokelela kwi-
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Awunakho ukubiza i `Drop::drop` ngokwakho
///
/// Kuba i `Drop::drop` isetyenziselwa ukucoca ixabiso, kunokuba yingozi ukusebenzisa eli xabiso emva kokuba indlela ibizwa njalo.
/// Njengoko i `Drop::drop` ingathathi ubunini begalelo layo, i Rust ithintela ukusetyenziswa gwenxa ngokungakuvumeli ukuba ubize i `Drop::drop` ngokuthe ngqo.
///
/// Ngamanye amagama, ukuba uzama ukubiza ngokucacileyo i-`Drop::drop` kulo mzekelo ungasentla, uya kufumana impazamo yomhlanganisi.
///
/// Ukuba ungathanda ukubiza ngokucacileyo umonakalisi wexabiso, i [`mem::drop`] inokusetyenziswa endaweni yoko.
///
/// [`mem::drop`]: drop
///
/// ## Ukulahla iodolo
///
/// Yeyiphi eyethu i `HasDrop` eyehlayo kuqala, nangona kunjalo?Ukulungiswa, kukwimo efanayo ababhengeziweyo: kuqala i `one`, emva koko yi `two`.
/// Ukuba ungathanda ukuzama le nto ngokwakho, ungaguqula i-`HasDrop` apha ngasentla ukuze iqulathe idatha, njengenani elipheleleyo, emva koko ulisebenzise kwi `println!` ngaphakathi kwe `Drop`.
/// Oku kuziphatha kuqinisekiswe lulwimi.
///
/// Ngokungafaniyo nolwakhiwo, izinto eziguquguqukayo zasekhaya ziyekwe ngokulandelelana:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Oku kuyakuprinta
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Nceda ubone i [the reference] ngemigaqo epheleleyo.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` kunye ne `Drop` zizodwa
///
/// Awunakho ukuphumeza zombini i [`Copy`] kunye ne `Drop` kuhlobo olufanayo.Iindidi eziyi-`Copy` ziphindaphindwa ngokungangqinelaniyo ngumqokeleli, nto leyo eyenza kube nzima kakhulu ukuqikelela ukuba, kwaye bangaphi abatshabalalisi abaza kwenziwa.
///
/// Kananjalo, ezi ntlobo azinakuba nabonakalisi.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Yenza umonakalisi wolu hlobo.
    ///
    /// Le ndlela ibizwa ngokungagungqiyo xa ixabiso liphuma ngaphandle, kwaye ayinakubizwa ngokucacileyo (le yimpazamo yomhlanganisi [E0040]).
    /// Nangona kunjalo, umsebenzi we [`mem::drop`] kwi-prelude unokusetyenziselwa ukubiza ukuphunyezwa kwe-`Drop` yengxoxo.
    ///
    /// Xa le ndlela ibizwa, i `self` ayikahanjiswa.
    /// Oko kwenzeka kuphela emva kokuba indlela igqityiwe.
    /// Ukuba oku bekungenjalo, i `self` iya kuba sisalathiso esijingayo.
    ///
    /// # Panics
    ///
    /// Ngenxa yokuba i-[`panic!`] iya kubiza i-`drop` njengoko ingasebenzi, nayiphi na i-[`panic!`] ekuphunyezweni kwe-`drop` iya kuthi ikhuphe.
    ///
    /// Qaphela ukuba nokuba le panics, ixabiso lithathwa njengelilahliwe;
    /// akufuneki ubangele ukuba i `drop` iphinde ibizwe.
    /// Oku kuhlala kuphathwa ngokuzenzekelayo ngumqokeleli, kodwa xa usebenzisa ikhowudi engakhuselekanga, ngamanye amaxesha kunokwenzeka ngokungacwangciswanga, ngakumbi xa usebenzisa i [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}