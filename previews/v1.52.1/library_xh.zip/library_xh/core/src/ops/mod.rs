//! Abaqhubi abagqithisileyo.
//!
//! Ukuphumeza ezi traits kukuvumela ukuba ulayishe ngaphezulu abaqhubi abathile.
//!
//! Ezinye zezi traits zingeniswa yi-prelude, ke ziyafumaneka kuyo yonke inkqubo ye Rust.Ngabaqhubi kuphela abaxhaswe yi-traits abanokulayisha ngaphezulu.
//! Umzekelo, i-opharetha yokongeza i-(`+`) inokuphinda ilayishwe ngaphezulu kwe [`Add`] trait, kodwa ukusukela ukuba umqhubi we-(`=`) akanankxaso i-trait, akukho ndlela yakugqithisa iisemantics zayo.
//! Ukongeza, le modyuli ayinikezeli nayiphi na indlela yokwenza abaqhubi abatsha.
//! Ukuba ukulayishwa okungafunekiyo okanye abaqhubi besiko bayafuneka, kuya kufuneka ujonge kwii-macros okanye iiplagi zokuhlanganisa ukuze wandise is syntax ye Rust.
//!
//! Ukuphunyezwa komsebenzisi we-traits kufuneka kungothusi kwimeko zabo, begcina kwiintsingiselo zabo eziqhelekileyo kunye ne [operator precedence].
//! Umzekelo, xa kusenziwa i [`Mul`], umsebenzi kufuneka ubenento efanayo nokuphindaphindeka (kunye nokwabelana ngeepropathi ezilindelekileyo ezinxulumene nokudibana).
//!
//! Qaphela ukuba i-`&&` kunye ne-`||` abaqhubi beesekethe ezimfutshane, okt, bavavanya kuphela i-operand yabo yesibini ukuba inegalelo kwisiphumo.Kuba le ndlela yokuziphatha ayinyanzeliswa yi-traits, i-`&&` kunye ne-`||` ayixhaswanga njengabaqhubi abagqithisileyo.
//!
//! Uninzi lwabaqhubi bathatha ii-operands zabo ngexabiso.Kwimixholo engeyiyo eyesiqhelo ebandakanya iintlobo ezakhelwe-ngaphakathi, oku kuhlala kungangxaki.
//! Nangona kunjalo, ukusebenzisa abaqhubi kwikhowudi yohlobo oluqhelekileyo, kufuna ingqalelo ethile ukuba amaxabiso kufuneka asetyenziswe kwakhona ngokuchasene nokuvumela abaqhubi ukuba bazisebenzise.Olunye ukhetho kukusebenzisa i [`clone`] ngamanye amaxesha.
//! Olunye ukhetho kukuxhomekeka kwiindidi ezichaphazelekayo ukubonelela ngophunyezo lomqhubi owongezelelweyo kwizalathiso.
//! Umzekelo, kuhlobo oluchazwe ngumsebenzisi i `T` ekufanele ukuba ixhase ukongeza, kusenokwenzeka ukuba licebo elilungileyo ukuba zombini i `T` kunye ne `&T` ziphumeze i traits [`Add<T>`][`Add`] kunye ne [`Add<&T>`][`Add`] ukuze ikhowudi yohlobo oluqhelekileyo ibhalwe ngaphandle kokwenza okungafunekiyo.
//!
//!
//! # Examples
//!
//! Lo mzekelo wenza ulwakhiwo lwe `Point` olusebenzisa i [`Add`] kunye ne [`Sub`], emva koko lubonise ukongeza nokukhupha ii`Point`s ezimbini.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Jonga amaxwebhu e trait nganye ngomzekelo wokuphunyezwa.
//!
//! I [`Fn`], [`FnMut`], kunye ne [`FnOnce`] traits ziphunyezwa ziindidi ezinokuthi zenziwe njengemisebenzi.Qaphela ukuba i [`Fn`] ithatha i `&self`, i [`FnMut`] ithatha i `&mut self` kunye ne [`FnOnce`] ithatha i `self`.
//! Oku kuyahambelana neendidi ezintathu zeendlela ezinokuthi zibongoziswe kwimeko: ukubiza-ngereferensi, ukubiza-ngokuguqula into ekubhekiswa kuyo, kunye nexabiso lokufowuna.
//! Ukusetyenziswa okuqhelekileyo kwezi traits kukusebenza njengemida kwimisebenzi ekwinqanaba eliphezulu ethatha imisebenzi okanye ukuvalwa njengempikiswano.
//!
//! Ukuthatha i [`Fn`] njengeparameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Ukuthatha i [`FnMut`] njengeparameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Ukuthatha i [`FnOnce`] njengeparameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` Isebenzisa izinto zayo eziguqulweyo, ke ayinakuqhutywa ngaphezulu kwesinye
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Ukuzama ukubhenela i `func()` kwakhona kuya kuyiphosa impazamo ye `use of moved value` ye `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` Ayinakuphinda ibhenelwe ngeli nqanaba
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;