/// Isetyenziselwa ukungasuki kungashukumi imisebenzi, njenge `*v`.
///
/// Ukongeza ekusebenziseni imisebenzi ecacileyo yokuchasana kunye nomsebenzisi we (unary) `*` kwiimeko ezingaguqukiyo, i `Deref` ikwasetyenziswa ngokungagungqiyo ngumhlanganisi kwiimeko ezininzi.
/// Oomatshini babizwa ngokuba yi ['`Deref` coercion'][more].
/// Kwiimeko ezinokutshintsha, i [`DerefMut`] iyasetyenziswa.
///
/// Ukuphumeza i-`Deref` kwizikhombisi ezi-smart kwenza ukufikelela kwidatha esemva kwabo kube lula, yiyo loo nto besebenzisa i `Deref`.
/// Kwelinye icala, imigaqo ngokubhekisele kwi `Deref` kunye ne [`DerefMut`] yenzelwe ngokukodwa ukulungiselela izikhombisi ezifanelekileyo.
/// Ngenxa yoku,**`Deref` kufuneka yenziwe kuphela kwizikhombisi ezikrelekrele** ukunqanda ukubhideka.
///
/// Ngezizathu ezifanayo,**le trait akufuneki isilele**.Ukungaphumeleli ngexesha lokuchithwa kwe-ereferencing kunokudideka kakhulu xa i-`Deref` ifakwa ngokufanelekileyo.
///
/// # Okungakumbi kukunyanzelwa kwe `Deref`
///
/// Ukuba i `T` inyanzelisa i `Deref<Target = U>`, kunye ne `x` lixabiso lohlobo `T`, emva koko:
///
/// * Kwiimeko ezingaguqukiyo, i `*x` (apho i `T` ingeyiyo ireferensi okanye isikhombisi esiluhlaza) elingana ne `* Deref::deref(&x)`.
/// * Amaxabiso ohlobo `&T` ayanyanzelwa kumaxabiso ohlobo `&U`
/// * `T` isebenzise zonke iindlela ze (immutable) zohlobo `U`.
///
/// Ngolwazi oluthe kratya, ndwendwela i [the chapter in *The Rust Programming Language*][book] kunye namacandelo ekubhekiswa kuwo kwi [the dereference operator][ref-deref-op], [method resolution] nakwi [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Isakhiwo esinentsimi enye efikelelekayo ngokungasuki kulwakhiwo.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Uhlobo lwesiphumo emva kokwenza isalathiso.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Ukwahlula ixabiso.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Isetyenziselwe imisebenzi yokutshintsha kwakhona, njengakwi `*v = 1;`.
///
/// Ukongeza ekusetyenzisweni kokucacisa ukungabonakalisi imisebenzi kunye nomsebenzisi we (unary) `*` kwiimeko ezinokuguquguquka, i `DerefMut` ikwasetyenziswa ngokungagungqiyo ngumhlanganisi kwiimeko ezininzi.
/// Oomatshini babizwa ngokuba yi ['`Deref` coercion'][more].
/// Kwiimeko ezingaguqukiyo, i [`Deref`] iyasetyenziswa.
///
/// Ukuphumeza i-`DerefMut` kwizikhombisi ezi-smart kwenza ukuba idatha ekumva kwabo ibe lula, yiyo loo nto besebenzisa i `DerefMut`.
/// Kwelinye icala, imigaqo ngokubhekisele kwi [`Deref`] kunye ne `DerefMut` yenzelwe ngokukodwa ukulungiselela izikhombisi ezifanelekileyo.
/// Ngenxa yoku,**`DerefMut` kufuneka yenziwe kuphela kwizikhombisi ezikrelekrele** ukunqanda ukubhideka.
///
/// Ngezizathu ezifanayo,**le trait akufuneki isilele**.Ukungaphumeleli ngexesha lokuchithwa kwe-ereferencing kunokudideka kakhulu xa i-`DerefMut` ifakwa ngokufanelekileyo.
///
/// # Okungakumbi kukunyanzelwa kwe `Deref`
///
/// Ukuba i `T` inyanzelisa i `DerefMut<Target = U>`, kunye ne `x` lixabiso lohlobo `T`, emva koko:
///
/// * Kwimixholo enokuguquguquka, i-`*x` (apho i-`T` ingeyiyo ireferensi okanye isikhombisi esiluhlaza) elingana ne-`* DerefMut::deref_mut(&mut x)`.
/// * Amaxabiso ohlobo `&mut T` ayanyanzelwa kumaxabiso ohlobo `&mut U`
/// * `T` isebenzise zonke iindlela ze (mutable) zohlobo `U`.
///
/// Ngolwazi oluthe kratya, ndwendwela i [the chapter in *The Rust Programming Language*][book] kunye namacandelo ekubhekiswa kuwo kwi [the dereference operator][ref-deref-op], [method resolution] nakwi [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Isakhiwo esinentsimi enye enokutshintshwa ngokungabhekiseli kulwakhiwo.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Ngokuchasene nokukhetha ixabiso.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Ibonisa ukuba ulwakhiwo lunokusetyenziswa njengendlela yokwamkela, ngaphandle kwenqaku le `arbitrary_self_types`.
///
/// Oku kuphunyezwa ziindidi zesikhombisi se-stdlib njenge-`Box<T>`, `Rc<T>`, `&T`, kunye ne-`Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}