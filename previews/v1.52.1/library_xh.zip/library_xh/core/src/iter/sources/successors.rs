use crate::{fmt, iter::FusedIterator};

/// Yenza i-iterator entsha apho into nganye elandelwayo ibalwa ngokusekwe ngaphambili.
///
/// I-iterator iqala ngento yokuqala enikiweyo (ukuba ikhona) kwaye ibize ukuvalwa kwe `FnMut(&T) -> Option<T>` ukubala umlandeli wento nganye.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Ukuba lo msebenzi ubuyise i `impl Iterator<Item=T>` inokuba isekwe kwi `unfold` kwaye ayifuni luhlobo olunikezelweyo.
    //
    // Nangona kunjalo ukuba negama le `Successors<T, F>` eligunyazisiweyo likuvumela ukuba kubengu `Clone` xa i `T` kunye ne `F` zikhona.
    Successors { next: first, succ }
}

/// Iterator entsha apho into nganye elandelelanayo ibalwa ngokusekwe ngaphambili.
///
/// Le `struct` yenziwe ngumsebenzi we [`iter::successors()`].
/// Bona amaxwebhu ayo ngaphezulu.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}