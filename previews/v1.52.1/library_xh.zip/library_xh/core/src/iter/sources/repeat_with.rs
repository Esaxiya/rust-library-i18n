use crate::iter::{FusedIterator, TrustedLen};

/// Yenza i-iterator entsha ephinda izinto zohlobo `A` ngokungagungqiyo ngokusebenzisa ukuvalwa okubonelelweyo, umphindayo, `F: FnMut() -> A`.
///
/// Umsebenzi we `repeat_with()` ubiza umphindayo kaninzi.
///
/// Ii-iterators ezingapheliyo ezinje nge `repeat_with()` zihlala zisetyenziswa kunye neeadaptha ezinje nge [`Iterator::take()`], ukwenzela ukuba zigqitywe.
///
/// Ukuba uhlobo lwento yokwenza iterator ufuna ukusebenzisa i [`Clone`], kwaye kulungile ukugcina into yomthombo kwimemori, kuya kufuneka usebenzise umsebenzi we [`repeat()`].
///
///
/// Iterator eveliswe yi `repeat_with()` ayisiyi [`DoubleEndedIterator`].
/// Ukuba ufuna i `repeat_with()` ukubuyisa i [`DoubleEndedIterator`], nceda uvule umba weGitHub uchaze imeko yakho yokusebenzisa.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::iter;
///
/// // masicinge ukuba sinexabiso elithile lohlobo olungeyo-`Clone` okanye elingafuni ukuba nayo kwimemori okwangoku kuba iyabiza:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ixabiso elithile ngonaphakade:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Sebenzisa utshintsho kugqityiwe:
///
/// ```rust
/// use std::iter;
///
/// // Ukusuka kwi-zeroth ukuya kwisithathu amandla amabini:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... kwaye ngoku sigqibile
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// I-iterator ephinda izinto zohlobo `A` ngokungapheliyo ngokusebenzisa ukuvalwa okubonelelweyo `F: FnMut() -> A`.
///
///
/// Le `struct` yenziwe ngumsebenzi we [`repeat_with()`].
/// Bona amaxwebhu ayo ngaphezulu.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}