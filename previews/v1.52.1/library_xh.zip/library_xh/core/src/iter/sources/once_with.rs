use crate::iter::{FusedIterator, TrustedLen};

/// Yenza i-iterator evila ixabiso ngokuchanekileyo kanye ngokucela ukuvalwa okubonelelweyo.
///
/// Oku kuhlala kusetyenziswa ukulungelelanisa ixabiso lomvelisi elinye kwi [`chain()`] yolunye uhlobo lwentetho.
/// Mhlawumbi unayo iterator egubungela phantse yonke into, kodwa ufuna ityala elikhethekileyo elongezelelweyo.
/// Mhlawumbi unomsebenzi osebenza kwii-iterators, kodwa kufuneka wenze kuphela ixabiso elinye.
///
/// Ngokungafaniyo ne [`once()`], lo msebenzi uya kuvelisa ngobuvila ixabiso eliceliweyo.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::iter;
///
/// // elinye lelona nani lilodwa
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // inye kuphela, kuphela kwento esiyifumanayo
/// assert_eq!(None, one.next());
/// ```
///
/// Ukudityaniswa kunye nenye iterator.
/// Masithi sifuna ukuyilungisa kwifayile nganye yolawulo lwe-`.foo`, kodwa kunye nefayile yoqwalaselo,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // kufuneka siguqule kwi-iterator ye-DirEntry-s iye kwi-iterator yePathBufs, ke sisebenzisa imephu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ngoku, iterator yethu yokwenza ifayile yethu yoqwalaselo
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // Dityaniselani ii-iterator ezimbini zibe yiterator enye enkulu
/// let files = dirs.chain(config);
///
/// // Oku kuyakusinika zonke iifayile ezikwi .foo kunye ne .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// I-iterator evelisa into enye yohlobo `A` ngokusebenzisa ukuvalwa okubonelelweyo `F: FnOnce() -> A`.
///
///
/// Le `struct` yenziwe ngumsebenzi we [`once_with()`].
/// Bona amaxwebhu ayo ngaphezulu.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}