use crate::iter::{FusedIterator, TrustedLen};

/// Yenza i-iterator entsha ephinda into enye ngokungapheliyo.
///
/// Umsebenzi we `repeat()` uphinda ixabiso elinye ngokuphindaphindiweyo.
///
/// Ii-iterators ezingapheliyo ezinje nge `repeat()` zihlala zisetyenziswa kunye neeadaptha ezinje nge [`Iterator::take()`], ukwenzela ukuba zigqitywe.
///
/// Ukuba udidi lwento oyifunayo alusebenzisi i `Clone`, okanye ukuba awufuni kugcina into ephindaphindwayo kwimemori, ungasebenzisa umsebenzi we [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::iter;
///
/// // inani lesine 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yu, isesine
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Ukuhamba ngokugqibeleleyo nge [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // loo mzekelo wokugqibela ubuninzi kakhulu kane.Masibe neine kuphela.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... kwaye ngoku sigqibile
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// I-iterator ephinda into ngokungapheliyo.
///
/// Le `struct` yenziwe ngumsebenzi we [`repeat()`].Bona amaxwebhu ayo ngaphezulu.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}