use crate::fmt;

/// Yenza i-iterator entsha apho iteration nganye ibiza ukuvalwa okubonelelweyo `F: FnMut() -> Option<T>`.
///
/// Oku kuvumela ukwenza i-iterator yesiko nangayo nayiphi na indlela yokuziphatha ngaphandle kokusebenzisa isenzi esingaphezulu sesenzi sokwenza uhlobo oluzinikeleyo kunye nokuphumeza i-[`Iterator`] trait yayo.
///
/// Qaphela ukuba i-`FromFn` iterator ayenzi uqikelelo malunga nokuziphatha kokuvalwa, kwaye ngenxa yoko ayizalisekisi i-[`FusedIterator`], okanye ibhala ngaphezulu i-[`Iterator::size_hint()`] kwi-`(0, None)` yayo emiselweyo.
///
///
/// Ukuvalwa kungasebenzisa ukubanjwa kunye nokusingqongileyo ukulandela imeko kwilizwe lonke.Kuxhomekeke kwindlela esetyenziswa ngayo i-iterator, oku kunokufuna ukukhankanya igama eliphambili le [`move`] ekuvaleni.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Masiphinde sisebenzise i-counter iterator kwi-[module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Yandisa ukubala kwethu.Kungenxa yoko le nto siqale ngo-zero.
///     count += 1;
///
///     // Jonga ukubona ukuba sigqibile ukubala okanye hayi.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// I-iterator apho iteration nganye ibiza ukuvalwa okubonelelweyo `F: FnMut() -> Option<T>`.
///
/// Le `struct` yenziwe ngumsebenzi we [`iter::from_fn()`].
/// Bona amaxwebhu ayo ngaphezulu.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}