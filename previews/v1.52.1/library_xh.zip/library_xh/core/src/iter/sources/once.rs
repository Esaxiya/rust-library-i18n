use crate::iter::{FusedIterator, TrustedLen};

/// Yenza i-iterator evelisa into kube kanye.
///
/// Oku kuhlala kusetyenziswa ukulungelelanisa ixabiso elinye kwi [`chain()`] yolunye uhlobo lwentetho.
/// Mhlawumbi unayo iterator egubungela phantse yonke into, kodwa ufuna ityala elikhethekileyo elongezelelweyo.
/// Mhlawumbi unomsebenzi osebenza kwii-iterators, kodwa kufuneka wenze kuphela ixabiso elinye.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::iter;
///
/// // elinye lelona nani lilodwa
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // inye kuphela, kuphela kwento esiyifumanayo
/// assert_eq!(None, one.next());
/// ```
///
/// Ukudityaniswa kunye nenye iterator.
/// Masithi sifuna ukuyilungisa kwifayile nganye yolawulo lwe-`.foo`, kodwa kunye nefayile yoqwalaselo,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // kufuneka siguqule kwi-iterator ye-DirEntry-s iye kwi-iterator yePathBufs, ke sisebenzisa imephu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ngoku, iterator yethu yokwenza ifayile yethu yoqwalaselo
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // Dityaniselani ii-iterator ezimbini zibe yiterator enye enkulu
/// let files = dirs.chain(config);
///
/// // Oku kuyakusinika zonke iifayile ezikwi .foo kunye ne .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iterator evelisa into kanye kube kanye.
///
/// Le `struct` yenziwe ngumsebenzi we [`once()`].Bona amaxwebhu ayo ngaphezulu.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}