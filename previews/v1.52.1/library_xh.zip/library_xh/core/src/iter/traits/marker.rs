/// I-iterator ehlala iqhubeka ukuvelisa i-`None` xa iphelile.
///
/// Ukutsalela umnxeba ngokulandelayo kwi-iterator edibeneyo ebuyise i-`None` kwakanye kuqinisekisiwe ukubuyisa i-[`None`] kwakhona.
/// Le trait kufuneka iphunyezwe ngabo bonke abaziphethe ngale ndlela kuba ivumela ukwandiswa kwe [`Iterator::fuse()`].
///
///
/// Note: Ngokubanzi, akufuneki usebenzise i `FusedIterator` kwimida yohlobo oluqhelekileyo ukuba ufuna iterator edibeneyo.
/// Endaweni yoko, kuya kufuneka ubize i-[`Iterator::fuse()`] kwi-iterator.
/// Ukuba i-iterator sele idityanisiwe, isongezo se-[`Fuse`] esongezelelweyo asiyi kuba yi-no-op ngaphandle kwesihlwayo sokusebenza.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterator enika ingxelo yobude obuchanekileyo isebenzisa size_hint.
///
/// I-iterator inika ingxelo ngobungakanani be-hints apho ichanekile (umda osezantsi ulingana nesibophelelo esingaphezulu), okanye umda ongaphezulu yi-[`None`].
///
/// Owona mda ungaphezulu kufuneka ube yi-[`None`] kuphela ukuba ubude be-iterator bukhulu kune-[`usize::MAX`].
/// Kwimeko apho, ubotshi osezantsi kufuneka ube ngu-[`usize::MAX`], ukhokelela kwi-[`Iterator::size_hint()`] ye-`(usize::MAX, None)`.
///
/// Iterator kufuneka ivelise ngokuchanekileyo inani lezinto ebezixeliwe okanye eziphambukayo ngaphambi kokufikelela esiphelweni.
///
/// # Safety
///
/// Le trait kufuneka yenziwe kuphela xa ikhontrakthi igcinwe.
/// Abasebenzisi bale trait kufuneka bahlole i [`Iterator::size_hint()`]’s ephezulu.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// I-iterator ethi xa ivelisa into iya kuthatha ubuncinci into kwi-[`SourceIter`] yayo.
///
/// Ukufowuna nayiphi na indlela eqhubela phambili i-iterator, umz
/// [`next()`] okanye i [`try_fold()`], iqinisekisa ukuba kwinyathelo ngalinye ubuncinci bexabiso lomthombo iterator ikhutshiwe kwaye iziphumo zetyathanga layo zinokufakwa endaweni yayo, kucingelwa ukuba imiqobo yolwakhiwo lomthombo ivumela olo fakelo.
///
/// Ngamanye amagama le trait ibonisa ukuba iterator pipeline inokuqokelelwa endaweni yayo.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}