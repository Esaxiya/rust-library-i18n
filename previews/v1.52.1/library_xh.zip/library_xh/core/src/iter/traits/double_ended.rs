use crate::ops::{ControlFlow, Try};

/// Iterator ekwazi ukuvelisa izinto kuzo zombini iziphelo.
///
/// Into ephumeza i `DoubleEndedIterator` inesakhono esinye esongezelelweyo kwinto ephumeza i [`Iterator`]: ukubanakho ukuthatha ii-Items ngasemva, nangaphambili.
///
///
/// Kubalulekile ukuba uqaphele ukuba kokubini nasemva kusebenza kuluhlu olufanayo, kwaye unganqamli: iteration iphelile xa bedibana embindini.
///
/// Ngendlela efanayo kwi-[`Iterator`] protocol, nje ukuba i-`DoubleEndedIterator` ibuyise i-[`None`] ukusuka kwi-[`next_back()`], ukuyibiza kwakhona kusenokwenzeka ukuba kungaze kubuye i-[`Some`] kwakhona.
/// [`next()`] kunye ne [`next_back()`] ziyatshintshisana ngale njongo.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Isusa kwaye ibuyise into ukusuka esiphelweni sayo.
    ///
    /// Ibuyisa i `None` xa kungasekho zinto.
    ///
    /// Amaxwebhu e [trait-level] aneenkcukacha ezithe kratya.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Izinto eziveliswe ziindlela ze-DoubleEndedIterator`zinokwahluka kwezi zinikezelwe ziindlela ze-"` Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Iqhubela phambili i-iterator ngasemva zizinto ze `n`.
    ///
    /// `advance_back_by` Inguqulelo eguqukayo ye [`advance_by`].Le ndlela izokutsiba ngolangazelelo izinto ze `n` ukuqala ngasemva ngokubiza i [`next_back`] ukuya kuthi ga kumaxesha e `n` kude kube kudibana i [`None`].
    ///
    /// `advance_back_by(n)` iya kubuyisa i-[`Ok(())`] ukuba i-iterator iqhubela phambili ngempumelelo nge-`n` yezinto, okanye i-[`Err(k)`] ukuba i-[`None`] idibene nayo, apho i-`k` linani lezinto i-iterator iqhubele phambili ngaphambi kokuphuma kwezinto (okt.
    /// ubude be-iterator).
    /// Qaphela ukuba i `k` ihlala ingaphantsi kwe `n`.
    ///
    /// Ukutsalela umnxeba i `advance_back_by(0)` akutyi naziphi na izinto kwaye kuhlala kubuya i [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // yi-`&3` kuphela ebitsaliwe
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Ibuyisa i-n`th element ukusuka esiphelweni se-iterator.
    ///
    /// Le yeyona nto ibuyiselweyo ye [`Iterator::nth()`].
    /// Nangona kunje ngokusebenza kwesalathiso, ukubala kuqala ukusuka ku-zero, ke i-`nth_back(0)` ibuyisa ixabiso lokuqala ukusuka esiphelweni, i-`nth_back(1)` yesibini, njalo njalo.
    ///
    ///
    /// Qaphela ukuba zonke izinto eziphakathi kokuphela kunye nezinto ezibuyisiweyo ziya kusetyenziswa, kubandakanya into ebuyisiweyo.
    /// Oku kuthetha ukuba ukubiza i-`nth_back(0)` amatyeli amaninzi kwi-iterator efanayo kuya kubuyisa izinto ezahlukeneyo.
    ///
    /// `nth_back()` izakubuyisa i [`None`] ukuba i `n` ingaphezulu okanye ilingana nobude be-iterator.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Ukufowuna i `nth_back()` amatyeli aliqela ayibuyiseli umva iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Ukubuyisa i `None` ukuba kukho izinto ezingaphantsi kwe `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Olu luhlobo oluguquliweyo lwe [`Iterator::try_fold()`]: kuthatha izinto eziqala ngasemva kweterator.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Kungenxa yokuba ijikeleze ixesha elifutshane, izinto eziseleyo zisafumaneka ngokusebenzisa iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Indlela ye-iterator ecutha izinto ze-iterator kwixabiso elinye, lokugqibela, ukuqala ngasemva.
    ///
    /// Olu luhlobo oluguquliweyo lwe [`Iterator::fold()`]: kuthatha izinto eziqala ngasemva kweterator.
    ///
    /// `rfold()` kuthatha iimpikiswano ezibini: ixabiso lokuqala, kunye nokuvalwa ngeempikiswano ezimbini: i 'accumulator', kunye nento.
    /// Ukuvalwa kubuyisa ixabiso elifanele ukuba nomqokeleli kulwandiso olulandelayo.
    ///
    /// Ixabiso lokuqala lixabiso eliza kubakho kwi-accumulator kwifowuni yokuqala.
    ///
    /// Emva kokufaka oku kuvalwa kuyo yonke into ye-iterator, i `rfold()` ibuyisela isihlanganisi.
    ///
    /// Lo msebenzi ngamanye amaxesha ubizwa ngokuba yi-'reduce' okanye i-'inject'.
    ///
    /// Ukusonga kuluncedo nanini na xa unengqokelela yento ethile, kwaye ufuna ukuvelisa ixabiso elinye kuyo.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // Isiphumo sazo zonke izinto ze-
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Lo mzekelo wakha umtya, ukuqala ngexabiso lokuqala kunye nokuqhubeka kwento nganye ukusuka ngasemva kude kube ngaphambili:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ukukhangela into ethile yeiterator ngasemva eyanelisa isimaphambili.
    ///
    /// `rfind()` ithatha ukuvalwa okubuyisa i `true` okanye i `false`.
    /// Kusebenzisa oku kuvalwa kwinto nganye ye-iterator, ukuqala esiphelweni, kwaye ukuba kukho nayiphi na kubo ebuyisa i-`true`, emva koko i-`rfind()` ibuyisa i-[`Some(element)`].
    /// Ukuba bonke babuyisa i `false`, ibuyisa i [`None`].
    ///
    /// `rfind()` ukujikeleza okufutshane;Ngamanye amagama, iyakuyeka ukuqhubekeka kwakamsinya nje xa kuvalwa ukubuya kwe `true`.
    ///
    /// Kungenxa yokuba i `rfind()` ithatha isalathiso, kwaye uninzi lwayo luyaphindaphindeka kwizalathiso, oku kukhokelela kwimeko enokudideka apho impikiswano isalathiso esiphindiweyo.
    ///
    /// Ungasibona esi siphumo kule mizekelo ingezantsi, nge `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Ukuma kwi-`true` yokuqala:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // Sisenokusebenzisa i `iter`, njengoko zininzi izinto.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}