/// Ukuguqulwa kwi [`Iterator`].
///
/// Ngokuphumeza i-`FromIterator` yohlobo, uchaza ukuba iyakwenziwa njani ukusuka kwi-iterator.
/// Oku kuqhelekile kwiindidi ezichaza ingqokelela yohlobo oluthile.
///
/// [`FromIterator::from_iter()`] kunqabile ukubizwa ngokucacileyo, kwaye endaweni yayo kusetyenziswa indlela ye [`Iterator::collect()`].
///
/// Jonga ama [`Iterator::collect()`]'s amaxwebhu eminye imizekelo.
///
/// Bona kwakho: [`IntoIterator`].
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Sebenzisa i [`Iterator::collect()`] ukusebenzisa ngokupheleleyo i `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ukuphumeza i `FromIterator` kuhlobo lwakho:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Ingqokelela yesampulu, sisongelo ngaphezulu kweVec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Masikunike ezinye iindlela ukuze senze enye kwaye songeze izinto kuyo.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // kwaye siza kuphumeza i-FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Ngoku singenza iterator entsha ...
/// let iter = (0..5).into_iter();
///
/// // ... kwaye wenze iMyCollection kuyo
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // Ukuqokelela kuyasebenza nayo!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Yenza ixabiso kwiiterator.
    ///
    /// Bona i [module-level documentation] ngaphezulu.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Uguquko lube yi-[`Iterator`].
///
/// Ngokusebenzisa i `IntoIterator` yohlobo, uchaza ukuba iyakuguqulwa njani ibe yiterator.
/// Oku kuqhelekile kwiindidi ezichaza ingqokelela yohlobo oluthile.
///
/// Isibonelelo esinye sokuphumeza i-`IntoIterator` kukuba uhlobo lwakho luya ku-[work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Bona kwakho: [`FromIterator`].
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Ukuphumeza i `IntoIterator` kuhlobo lwakho:
///
/// ```
/// // Ingqokelela yesampulu, sisongelo ngaphezulu kweVec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Masikunike ezinye iindlela ukuze senze enye kwaye songeze izinto kuyo.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // kwaye siza kuyisebenzisa i-IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Ngoku singenza ingqokelela entsha ...
/// let mut c = MyCollection::new();
///
/// // ... yongeza ezinye izinto kuyo ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... emva koko uyijike ibe yi-Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Kuqhelekile ukusebenzisa i `IntoIterator` njenge trait bound.Oku kuvumela uhlobo lokuqokelelwa koguquko ukuba lutshintshe, okoko nje iseyisitayile.
/// Imida eyongezelelweyo inokuchazwa ngokuthintela kwi
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Uhlobo lwezinto ezenziwa ngaphezulu kwalo.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Loluphi uhlobo lwe-iterator esiluguqulela kulo?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Yenza iterator kwixabiso.
    ///
    /// Bona i [module-level documentation] ngaphezulu.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Yandisa ingqokelela kunye nomxholo wentetho.
///
/// Iterator zivelisa uthotho lwamaxabiso, kwaye ingqokelela inokucatshangelwa njengothotho lwamaxabiso.
/// I `Extend` trait ivala umsantsa, ikuvumela ukuba wandise ingqokelela ngokubandakanya imixholo yaloo iterator.
/// Xa usolula ingqokelela ngesitshixo esele sikhona, oko kungena kuyahlaziywa okanye, kwimeko yengqokelela evumela amangenelo amaninzi ngamaqhosha alinganayo, oko kungeniswa kuyafakwa.
///
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// // Unokongeza umtya ngezinye izinto:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Ukuphumeza i `Extend`:
///
/// ```
/// // Ingqokelela yesampulu, sisongelo ngaphezulu kweVec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Masikunike ezinye iindlela ukuze senze enye kwaye songeze izinto kuyo.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // okoko i-MyCollection inoluhlu lwe-i32s, siphumeza Yandisa i i32
/// impl Extend<i32> for MyCollection {
///
///     // Oku kulula ngakumbi ngohlobo olusayiniweyo lokusayina: singatsalela umnxeba kwinto enokuthi iguqulwe ibe yi-Iterator esinika i32s.
///     // Kungenxa yokuba sifuna i32s ukuyifaka kwi-MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Ukuphunyezwa ngokuthe ngqo: lungisa ngokusebenzisa iterator, kunye ne add() into nganye kuthi.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // masandise ingqokelela yethu ngamanani amathathu ngaphezulu
/// c.extend(vec![1, 2, 3]);
///
/// // Songeze ezi zinto esiphelweni
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Yandisa ingqokelela kunye nemixholo ye-iterator.
    ///
    /// Njengoko le kuphela kwendlela efunekayo yale trait, amaxwebhu e [trait-level] aneenkcukacha ezithe kratya.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // Unokongeza umtya ngezinye izinto:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Yandisa ingqokelela enento enye ngokuchanekileyo.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Oovimba bokugcina kwingqokelela yenani elinikiweyo lezinto ezongezelelweyo.
    ///
    /// Umiliselo olungagqibekanga alwenzi nto.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}