/// I-iterator ebazi ngqo ubude bayo.
///
/// Uninzi [`Iterator`] alwazi ukuba luza kuphindaphindwa kangaphi, kodwa abanye bayayazi.
/// Ukuba i-iterator iyayazi ukuba ingaphindaphindeka kangaphi, ukubonelela ukufikelela kolo lwazi kunokuba luncedo.
/// Umzekelo, ukuba ufuna ukubuyela umva, isiqalo esihle kukwazi apho isiphelo sikhona.
///
/// Xa uphumeza i `ExactSizeIterator`, kufuneka uphumeze i [`Iterator`].
/// Xa usenza njalo, ukumiliselwa kwe [`Iterator::size_hint`]*kufuneka* kubuyise ubungakanani ngqo be-iterator.
///
/// Indlela ye [`len`] inokuphunyezwa okungagqibekanga, ngenxa yoko uhlala ungayiphumezi.
/// Nangona kunjalo, unokukwazi ukubonelela ngokuphunyezwa okungaphezulu kokungagqibekanga, ngenxa yoko ngaphezulu koku kule meko kuyavakala.
///
///
/// Qaphela ukuba le trait ikhuselekile i-trait kwaye ngenxa yoko ayinayo *kwaye* ayinakuqinisekisa ukuba ubude obuyisiweyo buchanekile.
/// Oku kuthetha ukuba ikhowudi ye-`unsafe`**akufuneki** ixhomekeke ekuchanekeni kwe [`Iterator::size_hint`].
/// I [`TrustedLen`](super::marker::TrustedLen) trait engazinzanga nengakhuselekanga inika esi siqinisekiso songezelelweyo.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// // uluhlu olunqamlezayo lwazi ngokuthe ngqo ukuba mangaphi amaxesha anokuphindaphinda ngalo
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Kwi-[module-level docs], similisele i [`Iterator`], `Counter`.
/// Masisebenzise i `ExactSizeIterator` nayo:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Sinokubala ngokulula inani elishiyekileyo lokuphindaphindwa.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Kwaye ngoku sinokuyisebenzisa!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Ibuyisa ubude obuchanekileyo be-iterator.
    ///
    /// Ukuphunyezwa kuqinisekisa ukuba i-iterator iya kubuya ngokuthe ngqo ngama-`len()` ngaphezulu kwamaxabiso e-[`Some(T)`], ngaphambi kokuba ibuyise i-[`None`].
    ///
    /// Le ndlela inokumiliselwa okungagqibekanga, ngenxa yoko uhlala ungayisebenzisi ngokuthe ngqo.
    /// Nangona kunjalo, ukuba unakho ukubonelela ngophumezo olusebenzayo, ungakwenza oko.
    /// Jonga i [trait-level] yamaxwebhu ngokomzekelo.
    ///
    /// Lo msebenzi uneziqinisekiso ezifanayo zokhuseleko njengomsebenzi we [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // uluhlu olunqamlezayo lwazi ngokuthe ngqo ukuba mangaphi amaxesha anokuphindaphinda ngalo
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Eli bango lizikhusela ngokugqithileyo, kodwa lijonga ukungangenisi
        // iqinisekiswe yi-trait.
        // Ukuba le trait ibiyi-rust-yangaphakathi, singasebenzisa debug_assert !;assert_eq!iya kujonga konke ukuphunyezwa komsebenzisi we-Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Ibuyisa i `true` ukuba iterator ayinanto.
    ///
    /// Le ndlela inokumiliselwa okungagqibekanga usebenzisa i [`ExactSizeIterator::len()`], ke akukho mfuneko yokuba uyiphumeze ngokwakho.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}