//! Ukulungelelaniswa kwangaphandle.
//!
//! Ukuba ufumene ingqokelela yohlobo oluthile, kwaye kufuneka wenze umsebenzi kwizinto eziqokelelweyo, uya kukhawuleza ubalekele kwi 'iterators'.
//! Iterator zisetyenziswa kakhulu kwikhowudi ye-idiomatic Rust, ke kufanelekile ukuba uqhelane nazo.
//!
//! Ngaphambi kokuchaza ngakumbi, masithethe ngendlela eyakhiwe ngayo le modyuli:
//!
//! # Organization
//!
//! Le modyuli icwangciswe ikakhulu ngohlobo:
//!
//! * [Traits] elona candelo lingundoqo: ezi traits zichaza ukuba loluphi uhlobo lweeterator ezikhoyo kunye nento onokuyenza ngazo.Iindlela zezi traits kufanelekile ukubeka ixesha elongezelelweyo lokufunda.
//! * [Functions] bonelela ngeendlela eziluncedo zokwenza iiterators ezisisiseko.
//! * [Structs] zihlala ziindlela ezibuyayo zeendlela ezahlukeneyo kule modyuli ye traits.Uya kuhlala ufuna ukujonga indlela eyila i `struct`, endaweni ye `struct` uqobo.
//! Ngolwazi oluthe kratya malunga nokuba kutheni, bona '[Ukuphumeza Iterator](#ukumilisela-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Yiyo leyo!Masambe kwiiterators.
//!
//! # Iterator
//!
//! Intliziyo nomphefumlo wale modyuli yi [`Iterator`] trait.Isiseko se [`Iterator`] sijongeka njengoku:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! I-iterator inendlela, [`next`], ethi xa ibizwa, ibuyise [`Option`]`<Item>`.
//! [`next`] izakubuyisa i [`Some(Item)`] okoko nje kukho izinto, kwaye xa zigqitywe zonke, ziya kubuyisa i `None` ukubonisa ukuba ukulungiswa kugqityiwe.
//! Umntu ngamnye ongumlingisi unokukhetha ukuqala kwakhona, kwaye ke ukubiza i [`next`] kwakhona kungenza okanye kungagqibi ukuqala ukubuyisa i [`Some(Item)`] kwakhona kwindawo ethile (umzekelo, bona i [`TryIter`]).
//!
//!
//! [`Iterator`] Inkcazo epheleleyo ibandakanya inani lezinye iindlela, kodwa zizindlela ezingagqibekanga, ezakhiwe ngaphezulu kwe [`next`], kwaye ke uzifumana simahla.
//!
//! Iterator nazo zidityanisiwe, kwaye kuqhelekile ukuzidibanisa ukuze zenze iindlela ezintsonkothileyo zokuqhubekeka.Jonga icandelo le [Adapters](#adapters) elingezantsi ngolwazi oluthe kratya.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Iindlela ezintathu zokuzilolonga
//!
//! Zintathu iindlela eziqhelekileyo ezinokwenza iiterators ezivela kwingqokelela:
//!
//! * `iter()`, ehamba ngaphezulu kwe `&T`.
//! * `iter_mut()`, ehamba ngaphezulu kwe `&mut T`.
//! * `into_iter()`, ehamba ngaphezulu kwe `T`.
//!
//! Izinto ezahlukeneyo kwithala leencwadi eliqhelekileyo zinokumilisela enye okanye ezingaphezulu kwezi zintathu, apho kufanelekileyo.
//!
//! # Ukuphumeza Iterator
//!
//! Ukwenza i-iterator yakho kubandakanya amanyathelo amabini: ukwenza i-`struct` ukubamba imeko ye-iterator, kwaye emva koko usebenzise i-[`Iterator`] ye-`struct`.
//! Kungenxa yoko le nto kukho `izakhiwo ezininzi ezininzi kule modyuli: kukho iterator nganye kunye neadapter yesixhobo sayo.
//!
//! Masenze i-iterator egama lingu-`Counter` ebala ukusuka kwi-`1` ukuya kwi-`5`:
//!
//! ```
//! // Kuqala, ulwakhiwo:
//!
//! /// Iterator ebala ukusuka kwinto enye ukuya kwisihlanu
//! struct Counter {
//!     count: usize,
//! }
//!
//! // sifuna ukuba ukubala kwethu kuqalwe kube kanye, ke masongeze indlela ye new() yokunceda.
//! // Oku akuyomfuneko ngokungqongqo, kodwa kufanelekile.
//! // Qaphela ukuba siqala i-`count` kwi-zero, siza kubona ukuba kutheni kumiliselo lwe-`next()`'s apha ngezantsi.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Emva koko, sisebenzisa i `Iterator` kwi `Counter` yethu:
//!
//! impl Iterator for Counter {
//!     // siza kubala kunye nosize
//!     type Item = usize;
//!
//!     // next() kuphela kwendlela efunekayo
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Yandisa ukubala kwethu.Kungenxa yoko le nto siqale ngo-zero.
//!         self.count += 1;
//!
//!         // Jonga ukubona ukuba sigqibile ukubala okanye hayi.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Kwaye ngoku sinokuyisebenzisa!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Ukutsalela umnxeba i [`next`] ngale ndlela kuyaphinda.I-Rust inokwakha okunokubiza i-[`next`] kwi-iterator yakho, ide ifike kwi-`None`.Masihambe ngokulandelayo.
//!
//! Qaphela ukuba i `Iterator` ibonelela ngokusetyenziswa okungagungqiyo kweendlela ezinje nge `nth` kunye ne `fold` ezibiza i `next` ngaphakathi.
//! Nangona kunjalo, kunokwenzeka ukuba ubhale ukumiliselwa kwesiko kweendlela ezinje nge-`nth` kunye ne-`fold` ukuba i-iterator inokuzibala ngokufanelekileyo ngaphandle kokubiza i-`next`.
//!
//! # `for` ii-loops kunye ne-`IntoIterator`
//!
//! I-Rust's `for` loop syntax enyanisweni iswekile kwii-iterators zayo.Nanku umzekelo osisiseko we `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Oku kuyakuprinta amanani ukuya kwelinye, elinye nelinye kumgca walo.Kodwa uyakuqaphela into apha: asikaze sibize nantoni na kwi vector yethu ukuvelisa iterator.Yintoni enika?
//!
//! Kukho i trait kwilayibrari esemgangathweni yokuguqula into ibe yi-iterator: [`IntoIterator`].
//! Le trait inendlela enye, [`into_iter`], eguqula into isebenzise i [`IntoIterator`] kwi-iterator.
//! Masiqwalasele loo loop ye `for` kwakhona, kunye nokuba yintoni umhlanganisi ayiguqula ibeyi:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! I-Rust iswekile oku kwi:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Kuqala, sibiza i `into_iter()` ngexabiso.Emva koko, siyadibana kwi-iterator ebuyayo, ibiza i-[`next`] ngaphezulu nangaphezulu de sibone i-`None`.
//! Ngelo xesha, thina si-`break` ngaphandle kweluphu, kwaye sigqibile ukuyenza.
//!
//! Inye into ecekeceke apha: ilayibrari esemgangathweni iqulethe ukuphunyezwa okunomdla kwe [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Ngamanye amagama, zonke [`Iterator`] ziphumeza i [`IntoIterator`], ngokuzibuyisela ngokwazo.Oku kuthetha izinto ezimbini:
//!
//! 1. Ukuba ubhala i [`Iterator`], ungayisebenzisa nge-`for` loop.
//! 2. Ukuba uyila ingqokelela, ephumeza i [`IntoIterator`] yayo iya kuvumela ingqokelela yakho ukuba isetyenziswe kunye ne-`for` loop.
//!
//! # Ukwenza ngereferensi
//!
//! Kuba i [`into_iter()`] ithatha i `self` ngexabiso, isebenzisa iluphu ye `for` ukuyinyusa ngaphezulu kwengqokelela isebenzisa olo qokelelo.Rhoqo, unokufuna ukuphindisela ngaphezulu kwengqokelela ngaphandle kokuyisebenzisa.
//! Uninzi lweengqokelela zibonelela ngeendlela ezibonelela iiterator ngaphezulu kwesalathiso, esibizwa ngokuba yi `iter()` kunye ne `iter_mut()` ngokwahlukeneyo:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` isengowalo msebenzi.
//! ```
//!
//! Ukuba ingqokelela yohlobo `C` ibonelela nge-`iter()`, ihlala ikwasebenzisa i `IntoIterator` ye `&C`, ngofezekiso olubiza nje i `iter()`.
//! Kwangokunjalo, ingqokelela ye `C` ebonelela nge `iter_mut()` ngokubanzi isebenzisa i `IntoIterator` ye `&mut C` ngokudlulisela kwi `iter_mut()`.Oku kwenza ukuba kube lula ukushwankathela:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // ngokufanayo ne `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // ngokufanayo ne `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Ngelixa iingqokelela ezininzi zibonelela nge `iter()`, ayizizo zonke ezibonelela nge `iter_mut()`.
//! Umzekelo, ukutshintsha izitshixo ze-[`HashSet<T>`] okanye i-[`HashMap<K, V>`] kunokubeka ingqokelela kwimeko yokungahambelani ukuba isitshixo sikhawulezile ukutshintsha, ke ezi ngqokelela zibonelela nge `iter()` kuphela.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Imisebenzi ethatha i-[`Iterator`] kwaye ibuyisele enye i-[`Iterator`] ihlala ibizwa ngokuba yi-'iterator adapters ', njengoko ziluhlobo lwe' adaptha
//! pattern'.
//!
//! Iiadaptha eziqhelekileyo ze-iterator zibandakanya i [`map`], [`take`], kunye ne [`filter`].
//! Ngaphezulu, bona amaxwebhu abo.
//!
//! Ukuba iadaptha ye-iterator i-panics, i-iterator iya kuba kwimeko engachazwanga (kodwa imemori ikhuselekile).
//! Le meko ayiqinisekiswanga ukuba iza kuhlala ifana kwiinguqulelo ze-Rust, ke kuya kufuneka uphephe ukuxhomekeka kumaxabiso ngqo abuyiswe yi-iterator eyoyikisayo.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (kunye ne-iterator [adapters](#adapters)) * bayonqena. Oku kuthetha ukuba ukwenza i-iterator ayisiyi-_do_ ngokupheleleyo. Akukho nto iyenzekayo de ubize i-[`next`].
//! Ngamanye amaxesha kungumthombo wesiphithiphithi xa usenza i-iterator kuphela yeziphumo zayo.
//! Umzekelo, indlela ye [`map`] ibiza ukuvalwa kwento nganye ehamba ngayo:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Oku akuyi kuprinta nawaphi na amaxabiso, njengoko senze i-iterator kuphela, kunokuba siyisebenzise.Umhlanganisi uya kusilumkisa ngolu hlobo lokuziphatha:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Indlela ye-idiomatic yokubhala i-[`map`] yeziphumo zayo kukusebenzisa i-`for` loop okanye ubize indlela ye-[`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Enye indlela eqhelekileyo yokuvavanya i-iterator kukusebenzisa indlela ye [`collect`] ukuvelisa ingqokelela entsha.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! IiIterter akufuneki zigqitywe.Njengomzekelo, uluhlu oluvulekileyo luhlobo olungenasiphelo:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Kuqhelekile ukusebenzisa i-[`take`] iterator adaptha ukuguqula i-iterator engenasiphelo ibe yeyokugqibela:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Oku kuyakuprinta amanani i-`0` ukuya kwi-`4`, nganye kumgca wayo.
//!
//! Yikhumbule into yokuba iindlela ezikwiiterators ezingapheliyo, nkqu nezo zinokuthi zichazwe ngokwezibalo ngexesha elinokuphela, zisenokungapheli.
//! Ngokukodwa, iindlela ezinje nge [`min`], apho imeko ngokubanzi ifuna ukuwela yonke into kwiiterator, kunokwenzeka ukuba zingabuyeli ngempumelelo kuzo naziphi na iiterator ezingapheliyo.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh hayi!Isiphelo esingapheliyo!
//! // `ones.min()` ibangela iluphu engapheliyo, ke ngekhe sifikelele kweli nqanaba!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;