//! I `Clone` trait yeentlobo ezingenako 'ukukopishwa ngokupheleleyo'.
//!
//! Kwi-Rust, ezinye iintlobo ezilula zi-"implicitly copyable" kwaye xa uzabela okanye uzipasisa njengempikiswano, umamkeli uya kufumana ikopi, eshiya ixabiso lasekuqaleni endaweni.
//! Ezi ntlobo azifuni kolwabiwo ukuze zikope kwaye azinazo izinto zokugqibela (okt, azinazo iibhokisi ezizezabo okanye ukumiliselwa kwe [`Drop`]), ke umhlanganisi uzithatha njengexabiso eliphantsi kwaye zikhuselekile ukuba zingakotshwa.
//!
//! Olunye uhlobo lweekopi kufuneka lwenziwe ngokucacileyo, ngokuqhutywa kwe-[`Clone`] trait kunye nokubiza indlela ye [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Umzekelo osisiseko wokusetyenziswa:
//!
//! ```
//! let s = String::new(); // Umtya osebenzisa izixhobo Clone
//! let copy = s.clone(); // ukuze sikwazi ukuyibumba
//! ```
//!
//! Ukuphumeza ngokulula iClone trait, unokusebenzisa i `#[derive(Clone)]`.Umzekelo:
//!
//! ```
//! #[derive(Clone)] // songeza iClone trait kwiMorpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // kwaye ngoku sinokuyifumana!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// I-trait eqhelekileyo yesakhono sokuphinda phinda into.
///
/// Umahluko kwi-[`Copy`] kwi-[`Copy`] ayicacanga kwaye ayibizi kakhulu, ngelixa i-`Clone` ihlala icacile kwaye inokuba okanye ingabizi.
/// Ukunyanzelisa ezi mpawu, i-Rust ayikuvumeli ukuba uphinde uphinde uphinde usebenzise i-[`Copy`], kodwa unokuphinda uphinde uphinde uphinde usebenzise i-`Clone` kwaye usebenzise ikhowudi yokuchasana nomthetho.
///
/// Kuba i `Clone` ibanzi ngakumbi kune [`Copy`], unokwenza ngokuzenzekelayo nantoni na i [`Copy`] ibe yi `Clone` nayo.
///
/// ## Derivable
///
/// Le trait inokusetyenziswa kunye ne `#[derive]` ukuba onke amasimi yi `Clone`.Ukuphunyezwa `kwe-derive`d kwe [`Clone`] kubiza i [`clone`] kwicandelo ngalinye.
///
/// [`clone`]: Clone::clone
///
/// Kwimeko yesiqhelo, i `#[derive]` isebenzisa i `Clone` ngokwemeko ngokongeza i-`Clone` eboshwe kwiiparameter zohlobo oluqhelekileyo.
///
/// ```
/// // `derive` zisebenzisa iClone yokuFunda<T>xa iT Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ndingayisebenzisa njani i `Clone`?
///
/// Iindidi eziyi-[`Copy`] kufuneka zibe nokuphunyezwa okungenamsebenzi kwe `Clone`.Ngokusesikweni:
/// ukuba i `T: Copy`, `x: T`, kunye ne `y: &T`, emva koko i `let x = y.clone();` ilingana no `let x = *y;`.
/// Ukuphunyezwa kwesikhokelo kufuneka kulumkele ukuxhasa oku kungena rhoqo;Nangona kunjalo, ikhowudi engakhuselekanga akufuneki ixhomekeke kuyo ukuqinisekisa ukhuseleko lwenkumbulo.
///
/// Umzekelo ulwakhiwo oluqhelekileyo oluphethe isikhombisi somsebenzi.Kule meko, ukuphunyezwa kwe `Clone` akunakuba `derive`d, kodwa kunokumiliselwa njengo:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Abaphumezi abongezelelweyo
///
/// Ukongeza kwi-[implementors listed below][impls], ezi ndidi zilandelayo zikwaphumeza i-`Clone`:
///
/// * Iindidi zezinto zomsebenzi (okt, iindidi ezahlukileyo ezichazwe kumsebenzi ngamnye)
/// * Iindidi zesikhombisi somsebenzi (umzekelo, `fn() -> i32`)
/// * I-Array iintlobo, zazo zonke ubukhulu, ukuba uhlobo lwento nalo lusebenzisa i-`Clone` (umzekelo, `[i32; 123456]`)
/// * Iindidi zeTuple, ukuba icandelo ngalinye likwasebenzisa i `Clone` (umzekelo, `()`, `(i32, bool)`)
/// * Iindidi zokuvalwa, ukuba azifaki xabiso kwindalo esingqongileyo okanye ukuba onke amaxabiso afakiweyo azalisekisa i `Clone` ngokwazo.
///   Qaphela ukuba izinto eziguquguqukayo ezifakwe kwisalathiso ekwabelwana ngaso zihlala zisenza i-`Clone` (nokuba imeko ayichaphazeli), ngelixa izinto eziguquguqukayo ezithathwe sisalathiso esiguqukayo zingaze zisebenzise i `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Ibuyisa ikopi yexabiso.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str izixhobo Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Yenza ikopi-isabelo esivela kwi `source`.
    ///
    /// `a.clone_from(&b)` ilingana ne `a = b.clone()` ekusebenzeni, kodwa inokufakwa ngaphezulu ukusebenzisa kwakhona izixhobo ze `a` ukunqanda ulwabiwo olungeyomfuneko.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Ukufumana okuphezulu okuvelisa i-impl ye-trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): Olu lungelelwaniso lusetyenziswa kuphela ngu-#[derive] Ukuqinisekisa ukuba zonke izinto zoluhlobo zisebenzisa iClone okanye iKopi.
//
//
// Olu luhlu akufuneki lubonakale kwikhowudi yomsebenzisi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ukuphunyezwa kwe `Clone` yeentlobo zamandulo.
///
/// Ukuphunyezwa okungenakuchazwa kwi-Rust kwenziwa kwi-`traits::SelectionContext::copy_clone_conditions()` kwi-`rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Izalathiso ekwabelwana ngazo zinokwenziwa, kodwa izingqinisiso eziguqukayo *azinakho*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Izalathiso ekwabelwana ngazo zinokwenziwa, kodwa izingqinisiso eziguqukayo *azinakho*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}