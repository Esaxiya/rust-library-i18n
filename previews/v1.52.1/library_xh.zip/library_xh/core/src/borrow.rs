//! Imodyuli yokusebenza yedatha ebolekiweyo.

#![stable(feature = "rust1", since = "1.0.0")]

/// I-trait yokuboleka idatha.
///
/// Kwi-Rust, kuqhelekile ukubonelela ngeendlela ezahlukeneyo zohlobo lwamatyala okusetyenziswa ahlukeneyo.
/// Umzekelo, indawo yokugcina kunye nolawulo lwexabiso kunokukhethwa ngokukodwa njengokufanelekileyo kusetyenziso oluthile ngohlobo lwesikhombisi njenge [`Box<T>`] okanye [`Rc<T>`].
/// Ngaphaya kwezi wrappers zohlobo oluqhelekileyo ezinokusetyenziswa nangalo naluphi na uhlobo, ezinye iintlobo zibonelela ngamacandelo okukhetha ukubonelela ngokusebenza okunokubiza.
/// Umzekelo wohlobo olunje yi-[`String`] eyongeza amandla okwandisa umtya kwi-[`str`] esisiseko.
/// Oku kufuna ukugcina ulwazi olongezelelekileyo olungafunekiyo kumtya olula, ongenakuguquka.
///
/// Ezi ntlobo zibonelela ngokufikelela kulwazi oluphambili ngokubhekisa kudidi lwedatha leyo.Kuthiwa 'babolekwe' olo hlobo.
/// Umzekelo, i [`Box<T>`] inokubolekwa njenge `T` ngelixa i [`String`] inokubolekwa njenge `str`.
///
/// Iindidi zichaza ukuba zinokubolekwa njengohlobo oluthile lwe `T` ngokuphumeza i `Borrow<T>`, ukubonelela ngesalathiso kwi `T` kwindlela ye trait's [`borrow`].Uhlobo lukhululekile ukuboleka njengeentlobo ezahlukeneyo.
/// Ukuba inqwenela ukuboleka ngokuguqukayo njengoluhlobo-ukuvumela idatha esisiseko ukuba iguqulwe, inokuphumeza i [`BorrowMut<T>`].
///
/// Ngapha koko, xa kubonelelwa ngokusetyenziswa kwe-traits eyongezelelweyo, kuya kufuneka kuthathelwe ingqalelo ukuba ingaba kufuneka baziphathe ngokufanayo nalezo zohlobo olusisiseko njengesiphumo sokumelwa kolo hlobo lusisiseko.
/// Ikhowudi yohlobo oluqhelekileyo isebenzisa i `Borrow<T>` xa ixhomekeke kwindlela efanayo yokuziphatha kwezi trait ezongezelelweyo.
/// Ezi traits ziya kuvela njenge trait bound ezongezelelweyo.
///
/// Ngokukodwa i-`Eq`, i-`Ord` kunye ne-`Hash` kufuneka zilingane kumaxabiso abolekiweyo kunye namashishini: I-`x.borrow() == y.borrow()` kufuneka inike iziphumo ezifanayo njenge-`x == y`.
///
/// Ukuba ikhowudi yohlobo oluqhelekileyo ifuna ukusebenzela zonke iintlobo ezinokubonelela ngesalathiso kuhlobo `T` olunxulumene noko, kuhlala kungcono ukusebenzisa i [`AsRef<T>`] njengoko iintlobo ezininzi zinokuyisebenzisa ngokukhuselekileyo.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Njengokuqokelelwa kwedatha, i [`HashMap<K, V>`] inezitshixo kunye namaxabiso.Ukuba eyona datha isitshixo isongelwe kuhlobo lokulawula lohlobo oluthile, kuya kufuneka, nangona kunjalo, kusenokwenzeka ukukhangela ixabiso usebenzisa ireferensi kwidatha yesitshixo.
/// Umzekelo, ukuba isitshixo ngumtya, iya kuba igcinwe kunye nemephu ye-hash njenge-[`String`], ngelixa kufanelekile ukukhangela usebenzisa i-[`&str`][`str`].
/// Ke, i `insert` kufuneka isebenze kwi `String` ngelixa i `get` kufuneka ikwazi ukusebenzisa i `&str`.
///
/// Yenziwe lula kancinci, iinxalenye ezifanelekileyo ze `HashMap<K, V>` zijongeka ngoluhlobo:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // imihlaba ishiyiwe
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Yonke imephu ye-hash yenziwa ngohlobo oluphambili ku `K`.Kuba la maqhosha agcinwa kwimephu ye-hash, olu hlobo kufuneka lube lolwedatha yezitshixo.
/// Xa ufaka isibini sexabiso eliphambili, imephu inikwa i `K` enjalo kwaye kufuneka ifumane ibhakethi eyi-hash echanekileyo kwaye ujonge ukuba isitshixo sele sikhona ngokuxhomekeke kwi `K`.Ifuna i `K: Hash + Eq`.
///
/// Xa ujonga ixabiso kwimephu, nangona kunjalo, kufuneka unikeze isalathiso kwi `K` njengeqhosha lokukhangela elinokufuna ukusoloko usenza elo xabiso.
/// Kumaqhosha omtya, oku kuya kuthetha ukuba ixabiso le `String` kufuneka lenziwe kukhangelwa iimeko apho kukho i `str` kuphela.
///
/// Endaweni yokuba indlela ye `get` yenziwe ngohlobo oluthile lwedatha engundoqo, ebizwa ngokuba yi `Q` kwindlela yotyikityo engentla.Ithi i `K` iboleka njenge `Q` ngokufuna ukuba i `K: Borrow<Q>`.
/// Ngokudinga i-`Q: Hash + Eq`, isayina imfuno yokuba i-`K` kunye ne-`Q` ziphumeze i-`Hash` kunye ne-`Eq` traits ezivelisa iziphumo ezifanayo.
///
/// Ukuphunyezwa kwe `get` kuxhomekeke ngokukodwa kumiliselo olufanayo lwe `Hash` ngokumisela ibhakethi yesitshixo ngokubiza i `Hash::hash` kwixabiso le `Q` nangona ifake isitshixo esisekwe kwixabiso le-hash elibalwe kwixabiso le `K`.
///
///
/// Ngenxa yoko, imephu ye-hash iyaqhekeka ukuba i `K` isonga ixabiso le `Q` ivelisa i-hash eyahlukileyo kune `Q`.Umzekelo, cinga ukuba unoluhlobo olusonga umtya kodwa uthelekise oonobumba be-ASCII abatyeshela iimeko zabo:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Kuba amaxabiso amabini alinganayo kufuneka avelise ixabiso elifanayo le-hash, ukumiliselwa kwe `Hash` kufuna ukulihoya imeko ye-ASCII, nayo:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Ngaba i `CaseInsensitiveString` inokumilisela i `Borrow<str>`?Ngokuqinisekileyo inokubonelela ngesalathiso kumtya osikiweyo ngentambo yawo.
/// Kodwa kuba ukumiliselwa kwe `Hash` kwahlukile, kuziphatha ngendlela eyahlukileyo kwi `str` kwaye ke akufuneki ukuba, eneneni, kuphumeze i `Borrow<str>`.
/// Ukuba ifuna ukuvumela abanye ukuba bafikelele kwi-`str` engaphantsi, inokuyenza nge-`AsRef<str>` engafakwanga naziphi na iimfuno ezingaphezulu.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Ukuboleka ngokungazenzisiyo kwixabiso elilelakho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// I-trait yedatha yokuboleka ngokuguqukayo.
///
/// Njengeqabane kwi [`Borrow<T>`] le trait ivumela uhlobo ukuba luboleke njengohlobo olusisiseko ngokunika ireferensi enokuguquguquka.
/// Bona i [`Borrow<T>`] ngolwazi oluthe kratya malunga nokuboleka njengolunye uhlobo.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Ngokuqinisekileyo iboleka kwixabiso elilelakho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}