use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Ngelixa lo msebenzi usetyenziselwa indawo enye kunye nokuphunyezwa kwawo kunokungeniswa, iinzame zangaphambili zokwenza njalo zenze ukuba i rustc icothe:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Ubeko lwebhloko yememori.
///
/// Umzekelo we `Layout` uchaza ubume bememori ethile.
/// Wakha i `Layout` phezulu njengegalelo oza kulinika umabi.
///
/// Zonke izakhiwo zinobungakanani obudibeneyo kunye nolungelelwaniso lwamandla amabini.
///
/// (Qaphela ukuba ubeko *aludingeki* ukuba alunobungakanani be-zero, nangona i-`GlobalAlloc` ifuna ukuba zonke izicelo zememori zingabi zero ngobukhulu.
/// Umntu ofowunayo kufuneka aqinisekise ukuba iimeko ezinje ziyafezekiswa, sebenzisa ababoneleli abathile abaneemfuno ezikhululekileyo, okanye asebenzise isikhombisi esivumayo se `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ubungakanani bebhloko ebuyiselweyo yememori, elinganiswe ngee-byte.
    size_: usize,

    // ukulungelelaniswa kwebhloko yememori eceliweyo, elinganiswa ngee-byte.
    // Siyaqinisekisa ukuba oku kuhlala kungamandla amabini, kuba ii-API ezinje nge `posix_memalign` ziyayifuna kwaye sisinyanzelo esifanelekileyo sokunyanzelisa kubakhi beLayout.
    //
    //
    // (Nangona kunjalo, asifuni ngokufana `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Yakha i-`Layout` ukusuka kwi-`size` kunye ne-`align`, okanye ibuyise i-`LayoutError` ukuba nayiphi na le miqathango ilandelayo ayifezekiswa:
    ///
    /// * `align` mayingabi nguziro,
    ///
    /// * `align` kufuneka ube namandla amabini,
    ///
    /// * `size`, xa ujikelezwe kwelona nani likufutshane le-`align`, akufuneki uphuphume (okt, ixabiso elijikeleziweyo kufuneka libe ngaphantsi okanye lilingane no-`usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (Amandla-ezibini athetha ukungqinelana!=0.)

        // Ubungakanani obujikeleziweyo ngu:
        //   ubungakanani_bokujikeleza_up=(ubukhulu + ulungelelwaniso, 1)&! (lungelelanisa, 1);
        //
        // Siyazi ngaphezulu ukuba ulungelelwaniso!=0.
        // Ukuba ukongeza (ulungelelwaniso, 1) akuphuphume, ukusondeza kuya kulunga.
        //
        // Kwelinye icala,&-masking nge! (Align, 1) iya kususa kuphela ii-bits-oda ezisezantsi.
        // Ke ukuba ukuphuphuma kwenzeka ngesixa, i&-mask ayinakuthabatha ngokwaneleyo ukulungisa oko kuphuphuma.
        //
        //
        // Ngasentla kuthetha ukuba ukujonga isishwankathelo esiphuphumayo kuyimfuneko kwaye kwanele.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // UKHUSELEKO: iimeko ze `from_size_align_unchecked` bezikhona
        // kuhlolwe ngentla.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Yenza uyilo, ngokudlula kuzo zonke iitshekhi.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga njengoko ungaqinisekisi iimeko ezivela kwi [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // UKHUSELEKO: Umntu ofowunayo makaqinisekise ukuba i `align` ingaphezulu kweqanda.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ubuncinci besayizi kwii-byte zebhloko yememori yolu lwakhiwo.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Ubuncinci bokulungelelaniswa kwe-byte yebhloko yememori kolu lwakhiwo.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Yakha i `Layout` efanelekileyo yokugcina ixabiso lohlobo `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // UKHUSELEKO: ulungelelwaniso luqinisekiswe ngu Rust ukuba ube ligunya ezimbini kwaye
        // ubungakanani + bokulungelelanisa combo kuqinisekisiwe ukuba kufanelekile kwindawo yethu yedilesi.
        // Ngenxa yoko sebenzisa umakhi ongakhange akhangelwe apha ukunqanda ukufaka ikhowudi eyi-panics ukuba ayilungiswanga kakuhle ngokwaneleyo.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Uvelisa ubeko oluchaza irekhodi elinokusetyenziselwa ukwaba ubume benkxaso ye `T` (enokuthi ibe yi trait okanye olunye uhlobo olungacwangciswanga njengesilayidi).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // UKHUSELEKO: jonga izizathu kwi `new` yokuba kutheni le nto isebenzisa umahluko ongakhuselekanga
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Uvelisa ubeko oluchaza irekhodi elinokusetyenziselwa ukwaba ubume benkxaso ye `T` (enokuthi ibe yi trait okanye olunye uhlobo olungacwangciswanga njengesilayidi).
    ///
    /// # Safety
    ///
    /// Lo msebenzi ukhuselekile kuphela ukubiza ukuba le miqathango ilandelayo ibambe:
    ///
    /// - Ukuba i `T` yi `Sized`, lo msebenzi uhlala ukhuselekile ukubiza.
    /// - Ukuba umsila ongalinganiswanga we `T` ngu:
    ///     - i [slice], emva koko ubude bomsila wesilayidi kufuneka ube linani elipheleleyo, kunye nobungakanani bexabiso *elipheleleyo*(ubude bomsila obunamandla + isimaphambili sobungakanani ngokobalo) kufuneka lulingane kwi `isize`.
    ///     - i [trait object], emva koko icandelo lesixokelelwano sesikhombisi kufuneka likhombe kuhlobo olusebenzayo lohlobo `T` olufunyenwe ngokudityaniswa okungalinganiswanga, kunye nobungakanani bexabiso * elipheleleyo
    ///
    ///     - i (unstable) [extern type], emva koko lo msebenzi uhlala ukhuselekile ukubiza, kodwa anga panic okanye ngenye indlela ibuyise ixabiso elingalunganga, njengoko uhlobo lwangaphandle lungaziwa.
    ///     Oku kuziphatha okufanayo ne [`Layout::for_value`] kwireferensi yomsila wohlobo lwangaphandle.
    ///     - Ngaphandle koko, akuvumelekanga ukuba ubize lo msebenzi.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // UKHUSELEKO: sidlula kwiimfuno zala misebenzi kulowo ufowunayo
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // UKHUSELEKO: jonga izizathu kwi `new` yokuba kutheni le nto isebenzisa umahluko ongakhuselekanga
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Yenza i `NonNull` ejingayo, kodwa ilungelelaniswe kakuhle kolu Yilo.
    ///
    /// Qaphela ukuba ixabiso lesikhombisi linokubonisa isikhombisi esisemthethweni, oko kuthetha ukuba oku akufuneki kusetyenziswe njengexabiso le-"not yet initialized" ye-sentinel.
    /// Iindidi ezabileyo ngobuvila kufuneka zilandelele ukuqaliswa ngezinye iindlela.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // UKHUSELEKO: ukulungelelanisa kuqinisekisiwe ukuba akuyiyo zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Yenza uyilo oluchaza irekhodi elinokubamba ixabiso lolwakhiwo olufanayo ne `self`, kodwa ekwalungelelaniswe kulungelelwaniso `align` (kulinganiswa ngee-byte).
    ///
    ///
    /// Ukuba i `self` sele ihlangane nokulungelelaniswa okumiselweyo, emva koko ibuyise i `self`.
    ///
    /// Qaphela ukuba le ndlela ayongezi naluphi na uhlobo lokutshixa kubungakanani bayo, nokuba ubuyiso lubuyisiwe alungelelananga ngokwahlukileyo.
    /// Ngamanye amagama, ukuba i-`K` inobungakanani be-16, i-`K.align_to(32)` iya kuthi * isane-size 16.
    ///
    /// Ibuyisa impazamo ukuba indibaniselwano ye `self.size()` kunye ne `align` enikiweyo iphula iimeko ezidweliswe kwi [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Ibuyisa isixa semadlinganiso ekufuneka siyifakile emva kwe `self` ukuqinisekisa ukuba le dilesi ilandelayo iya kuyanelisa i `align` (ilinganiswe ngee-byte).
    ///
    /// Umzekelo, ukuba i-`self.size()` ingu-9, emva koko i-`self.padding_needed_for(4)` ibuyisela i-3, kuba lelona nani lincinci le-byte zokufaka padding efunekayo ukufumana idilesi engqamene no-4 (ucinga ukuba ibhloko yememori ehambelanayo iqala kwidilesi engqamene no-4).
    ///
    ///
    /// Ixabiso lokubuya kwalo msebenzi alinantsingiselo ukuba i `align` ayingamandla-amabini.
    ///
    /// Qaphela ukuba ukusetyenziswa kwexabiso elibuyiselweyo kufuna ukuba i-`align` ibe ngaphantsi okanye ilingane nokulungelelaniswa kwedilesi yokuqala kuyo yonke ibhloko yememori eyabelweyo.Enye indlela yokwanelisa esi sithintelo kukuqinisekisa i `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Ixabiso elijikeleziweyo yile:
        //   len_rounded_up=(len + align, 1)&! (lungelelanisa, 1);
        // kwaye emva koko sibuyisela umahluko wepadding: `len_rounded_up - len`.
        //
        // Sisebenzisa izibalo zemodyuli kuyo yonke:
        //
        // 1. ukulungelelanisa kuqinisekisiwe ukuba> 0, ke lungelelanisa, 1 uhlala esebenza.
        //
        // 2.
        // `len + align - 1` inokugcwala kakhulu nge-`align - 1`, ke i&-mask ene-`!(align - 1)` iya kuqinisekisa ukuba kwimeko yokugcwala, i-`len_rounded_up` ngokwayo iya kuba ngu-0.
        //
        //    Yiyo loo nto iphedi ebuyisiweyo, xa idityaniswe kwi `len`, ivelisa i-0, eyanelisa kancinci ulungelelwaniso lwe `align`.
        //
        // (Ewe kunjalo, iinzame zokwaba iibhloko zememori ezinobungakanani kunye nokugqobhoza okuphuphumayo ngale ndlela ingentla kunokubangela ukuba umabi abonelele ngempazamo.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Yenza uyilo ngokusondeza ubungakanani bolu hlobo ukuya kulungelelwaniso lobeko.
    ///
    ///
    /// Oku kuyalingana nokongeza iziphumo ze `padding_needed_for` kubungakanani bamanqanaba obeko.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Oku akunakuphuphuma.Ukucaphula kwi-Layout engabonakaliyo:
        // > `size`, xa usondezwa kwelona nani likufutshane le `align`,
        // > akufuneki iphuphume (okt, ixabiso elirhangqiweyo kufuneka libe ngaphantsi kwe
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Yenza uyilo oluchaza irekhodi le `n` yeziganeko ze `self`, ngesixa esifanelekileyo sokuhombisa phakathi kwento nganye ukuqinisekisa ukuba imeko nganye inikwa ubungakanani bayo kunye nolungelelwaniso.
    /// Kwimpumelelo, ubuyisela i `(k, offs)` apho i `k` lubeko lobungakanani kwaye i `offs` ngumgama ophakathi kokuqala kwento nganye kuluhlu.
    ///
    /// Kukuphuphuma kwezibalo, ibuyisela i `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Oku akunakuphuphuma.Ukucaphula kwi-Layout engabonakaliyo:
        // > `size`, xa usondezwa kwelona nani likufutshane le `align`,
        // > akufuneki iphuphume (okt, ixabiso elirhangqiweyo kufuneka libe ngaphantsi kwe
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // UKHUSELEKO: I self.align sele yaziwa njengevumelekile kwaye isabelo_size sele sikhona
        // iphawulwe kakade.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Yenza uyilo oluchaza irekhodi le-`self` lilandelwe yi-`next`, kubandakanya nayiphi na into efanelekileyo yokuncamathelisa ukuqinisekisa ukuba i-`next` iya kulungelelaniswa ngokufanelekileyo, kodwa *akukho ndlela yokulandelela*.
    ///
    /// Ukuze utshatise ubume bommelo C we-`repr(C)`, kuya kufuneka ubize i-`pad_to_align` emva kokwandisa ubume ngawo onke amabakala.
    /// (Akukho ndlela yokutshatisa ubume be-Rust emiyo `repr(Rust)`, as it is unspecified.)
    ///
    /// Qaphela ukuba ulungelelwaniso lobume obunokubangela luya kuba lolona luphezulu lwe-`self` kunye ne-`next`, ukuqinisekisa ulungelelwaniso lwamalungu omabini.
    ///
    /// Ibuyisa i-`Ok((k, offset))`, apho i-`k` iluluhlu lwerekhodi ehambelanayo kwaye i-`offset` yindawo ehambelana nayo, kwii-byte, zokuqala kwe `next` efakwe ngaphakathi kwerekhodi eqinisekisiweyo (ucinga ukuba irekhodi ngokwalo liqala ngokuseta 0).
    ///
    ///
    /// Kukuphuphuma kwezibalo, ibuyisela i `LayoutError`.
    ///
    /// # Examples
    ///
    /// Ukubala ubume besakhiwo se `#[repr(C)]` kunye nokususwa kwamasimi kubeko lwamasimi awo:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Khumbula ukugqibezela nge `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // vavanya ukuba iyasebenza
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Yenza uyilo oluchaza irekhodi le `n` yeziganeko ze `self`, kungekho padding phakathi kwemeko nganye.
    ///
    /// Qaphela ukuba, ngokungafaniyo ne `repeat`, i `repeat_packed` ayiqinisekisi ukuba iimeko eziphindaphindwayo ze `self` ziya kulungelelaniswa ngokufanelekileyo, nokuba imeko enikiweyo ye `self` ilungelelaniswe ngokufanelekileyo.
    /// Ngamanye amagama, ukuba ubeko olubuyiswe yi `repeat_packed` lusetyenziselwa ukwaba uluhlu, akuqinisekiswanga ukuba zonke izinto ezikoluhlu ziya kulungelelaniswa ngokufanelekileyo.
    ///
    /// Kukuphuphuma kwezibalo, ibuyisela i `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Yenza uyilo oluchaza irekhodi le `self` lilandelwe yi `next` ngaphandle kokongeza ngaphandle kwezi zimbini.
    /// Kuba akukho kufakelwa padding, ulungelelwaniso lwe `next` alunamsebenzi, kwaye alufakwanga *kwaphela* kulwakhiwo oluneziphumo.
    ///
    ///
    /// Kukuphuphuma kwezibalo, ibuyisela i `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Yenza uyilo oluchaza irekhodi le `[T; n]`.
    ///
    /// Kukuphuphuma kwezibalo, ibuyisela i `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Iiparameter ezinikwe i `Layout::from_size_align` okanye omnye umakhi we `Layout` akazonelisi imiqobo yakhe ebhaliweyo.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (siyayidinga le implantsi ye-trait Impazamo)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}