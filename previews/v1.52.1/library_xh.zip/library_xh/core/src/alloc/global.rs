use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Ulwabiwo lwenkumbulo olunokubhaliswa njengelimi eliqhelekileyo leencwadi ngokusebenzisa uphawu lwe `#[global_allocator]`.
///
/// Ezinye zeendlela zifuna ukuba ibhloko yenkumbulo *yabelwe ngoku* ngomnikezeli.Oku kuthetha ukuba:
///
/// * idilesi yokuqala yebhloko yenkumbulo ibibuyiselwe umnxeba wangaphambili kwindlela yolwabiwo efana ne `alloc`, kunye
///
/// * Ibhloko yememori khange ihanjiswe kamva, apho iibhloksi zihanjiswe nokuba zidluliselwe kwindlela yokuhambisa efana ne `dealloc` okanye ngokudluliselwa kwindlela yokwabiwa kwakhona ebuyisela isikhombisi esingasebenziyo.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// I `GlobalAlloc` trait yi `unsafe` trait ngezizathu ezininzi, kwaye abaphumezi kufuneka baqinisekise ukuba bayazithobela ezi mvumelwano:
///
/// * Ukuziphatha okungachazwanga ukuba ababi behlabathi baphumle.Olu thintelo lunokuphakanyiswa kwi-future, kodwa ngoku i-panic kuwo nawuphi na wale misebenzi inokukhokelela kwimemori yokungazithembi.
///
/// * `Layout` imibuzo kunye nokubala ngokubanzi kufuneka kuchaneke.Abafowunelwa le trait bavunyelwe ukuba bathembele kwizivumelwano ezichazwe kwindlela nganye, kwaye abaphumezi kufuneka baqinisekise ukuba ezo zivumelwano zihlala ziyinyani.
///
/// * Awunakuxhomekeka kulwabiwo olwenzekayo, nokuba kukho ulwabiwo olucacileyo kwimithombo yolwazi.
/// Isisebenzisi sinokufumana ulwabiwo olungasetyenziswanga olunokuthi luphelise ngokupheleleyo okanye lushenxise kwisitaki kwaye ngenxa yoko lungaze lubize umabi.
/// Isincedisi sinokuqhubeka nokuthatha ukuba ulwabiwo alunakuze lwenzeke, ke ikhowudi ebisoloko isilela ngenxa yokusilela kwesabelo ngoku inokusebenza ngequbuliso ngoba i-optimizer isebenze malunga nemfuno yolwabiwo.
/// Ngokuthe kratya, lo mzekelo wekhowudi ulandelayo awunangqiniseko, nokuba umniki-siko wakho uyakuvumela ukubala ukuba zingaphi izabelo ezenzekileyo.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Qaphela ukuba ulungiso olukhankanywe apha ngasentla ayisiyiyo kuphela intsebenzo enokusetyenziswa.Ngokuqhelekileyo ungaxhomekeki kulwabiwo lwemfumba olwenzekayo ukuba lunokususwa ngaphandle kokutshintsha indlela yokuziphatha.
///   Nokuba ulwabiwo luyenzeka okanye aluyonxalenye yenkqubo yokuziphatha, nokuba inokufunyanwa ngesabelo esilandelela ulwabiwo ngokuprinta okanye ngenye indlela ineziphumo ebezingalindelekanga.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Nika inkumbulo njengoko kuchaziwe kwi `layout`.
    ///
    /// Buyisela isikhombisi kwimemori esandula ukwabiwa, okanye ukungabinanto ukubonisa ukusilela kolwabiwo.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga kuba isimilo esingachazwanga sinokubangela ukuba umntu ofowunayo angaqinisekisi ukuba i-`layout` ayinasayizi.
    ///
    /// (Ulwandiso lwee-subtraits lunokunika imida ethe kratya kwindlela yokuziphatha, umzekelo, ukuqinisekisa idilesi ye-sentinel okanye isikhombisi esingasebenziyo ekuphenduleni kwisicelo esabiweyo sobungakanani.)
    ///
    /// Ibhloko ebekiweyo yenkumbulo inokuthi okanye ingaqaliswa.
    ///
    /// # Errors
    ///
    /// Ukubuyisa isikhombisi esingabalulekanga kubonisa ukuba inkumbulo iphelile okanye i `layout` ayihlangani nobungakanani bomnikezeli okanye imiqobo yolungelelwaniso.
    ///
    /// Ukuphunyezwa kuyakhuthazwa ukuba kubuyiswe kuludwe lwenkumbulo kunokuba kuphume isisu, kodwa ayisiyomfuneko engqongqo leyo.
    /// (Ngokukodwa: kusemthethweni * ukuphumeza le trait ngaphezulu kwelayibrari yolwabiwo lwendalo olusebenzisa ukudinwa kwememori.)
    ///
    /// Abathengi abanqwenela ukukhupha ikhompawundi ngokuphendula kwimpazamo yolwabiwo bayakhuthazwa ukuba babize umsebenzi we [`handle_alloc_error`], endaweni yokufaka ngqo i `panic!` okanye efanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Yahlula ibhloko yenkumbulo kwisikhombisi se `ptr` esinikwe i `layout`.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga kuba isimilo esingachazwanga sinokubangela ukuba umntu ofowunayo angaqinisekisi konke oku kulandelayo:
    ///
    ///
    /// * `ptr` kufuneka uchaze ibhloko yememori eyabelwe okwangoku ngalo mabi,
    ///
    /// * `layout` kufuneka ubeko olufanayo nolwalusetyenziselwa ukwaba ibhloko yenkumbulo.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Iziphatha njenge-`alloc`, kodwa ikwaqinisekisa ukuba imixholo isetelwe ku-zero ngaphambi kokuba ibuyiswe.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga ngenxa yezizathu ezifanayo eziyi-`alloc`.
    /// Nangona kunjalo ibhlokhi yenkumbulo eyabelweyo iqinisekisiwe ukuba iza kuqaliswa.
    ///
    /// # Errors
    ///
    /// Ukubuyisa isikhombisi esingabalulekanga kubonisa ukuba inkumbulo iphelile okanye i-`layout` ayihlangani nobungakanani bomnikezeli okanye iingxaki zokulungelelanisa, njengakwi `alloc`.
    ///
    /// Abathengi abanqwenela ukukhupha ikhompawundi ngokuphendula kwimpazamo yolwabiwo bayakhuthazwa ukuba babize umsebenzi we [`handle_alloc_error`], endaweni yokufaka ngqo i `panic!` okanye efanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // UKHUSELEKO: ikhontrakthi yokhuseleko ye `alloc` kufuneka igcinwe ngulowo ufowunayo.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // UKHUSELEKO: njengoko ulwabiwo luphumelele, ingingqi ukusuka kwi `ptr`
            // Ubungakanani be `size` buqinisekisiwe ukuba buyasebenza ekubhaleni.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Shwabanisa okanye ukhule ibhloko yememori kwi-`new_size` enikiweyo.
    /// Ibhlokhi ichazwa sisikhombisi se `ptr` kunye ne `layout`.
    ///
    /// Ukuba oku kubuyisela isikhombisi esingasebenziyo, ubunini bebhloko yememori ekubhekiswe kuyo yi `ptr` bugqithiselwe kulo sabelo.
    /// Imemori inokuthi ihanjiswe okanye ingakhange ihanjiswe, kwaye kufuneka ithathelwe ingqalelo njengengasetyenziswanga (ngaphandle kokuba idluliselwe kumnxeba kwakhona ngexabiso lokubuyisela le ndlela).
    /// Ibhloko entsha yememori yabelwe i `layout`, kodwa nge `size` ihlaziyiwe yaya kwi `new_size`.
    /// Olu lwakhiwo lutsha kufuneka lusetyenziswe xa kusasazwa ibhloko yememori entsha nge `dealloc`.
    /// Uluhlu lwe `0..min(layout.size(), new_size) `yeebhloko zememori ezintsha ziqinisekisiwe ukuba zinamaxabiso afanayo nebhloko yentsusa.
    ///
    /// Ukuba le ndlela ibuya ilize, ubunini bebhloko yememori abugqithiselwanga kulo mabi, kwaye imixholo yebhloko yememori ayitshintshwanga.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga kuba isimilo esingachazwanga sinokubangela ukuba umntu ofowunayo angaqinisekisi konke oku kulandelayo:
    ///
    /// * `ptr` kufuneka yabelwe ngoku ngokusebenzisa lo sabelo,
    ///
    /// * `layout` kufuneka ubeko olufanayo nolwalusetyenziselwa ukwaba ibhloko yememori,
    ///
    /// * `new_size` kufuneka ibe nkulu kuneqanda.
    ///
    /// * `new_size`, xa ujikelezwe kwelona nani likufutshane le-`layout.align()`, akufuneki uphuphume (okt, ixabiso elijikeleziweyo kufuneka libe ngaphantsi kwe `usize::MAX`).
    ///
    /// (Ulwandiso lwee-subtraits lunokunika imida ethe kratya kwindlela yokuziphatha, umzekelo, ukuqinisekisa idilesi ye-sentinel okanye isikhombisi esingasebenziyo ekuphenduleni kwisicelo esabiweyo sobungakanani.)
    ///
    /// # Errors
    ///
    /// Ibuyisa into engekhoyo ukuba ubeko olutsha aluhlangabezani nobungakanani kunye nezithintelo kulungelelwaniso lomnikezeli, okanye ukuba ulwabiwo ngokutsha aluphumelelanga.
    ///
    /// Ukuphunyezwa kuyakhuthazwa ukuba kubuyiselwe ukungakhathali kwimemori kunokuphaphazela okanye ukukhupha isisu, kodwa ayisiyomfuneko engqongqo leyo.
    /// (Ngokukodwa: kusemthethweni * ukuphumeza le trait ngaphezulu kwelayibrari yolwabiwo lwendalo olusebenzisa ukudinwa kwememori.)
    ///
    /// Abathengi abanqwenela ukukhupha isisombululo ekuphenduleni impazamo yokwabiwa kwakhona bayakhuthazwa ukuba babize umsebenzi we [`handle_alloc_error`], endaweni yokufaka ngqo i `panic!` okanye efanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // UKHUSELEKO: lowo ufowunayo makaqinisekise ukuba i `new_size` ayiphuphumi.
        // `layout.align()` ivela kwi `Layout` kwaye ke ngokuqinisekileyo iqinisekisiwe.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // UKHUSELEKO: Umntu ofowunayo makaqinisekise ukuba i `new_layout` ingaphezulu kweqanda.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // UKHUSELEKO: ibhlokhi ebikade yabiwa ayinakukwazi ukugqobhoza ibhloko esandula ukwabiwa.
            // Ikhontrakthi yokhuseleko ye `dealloc` kufuneka igcinwe ngulowo ufowunayo.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}