//! Ulwabiwo lwenkumbulo APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Impazamo ye `AllocError` ibonisa ukusilela kolwabiwo olunokubangelwa kukudinwa kwezixhobo okanye kwinto engalunganga xa kudityaniswa iimpikiswano ezinikiweyo kunye nolwabelo.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (siyayidinga le implantsi ye-trait Impazamo)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Ukuphunyezwa kwe `Allocator` kunokwaba, kukhule, kunciphise, kwaye kuhambise iibhloko zedatha echazwe nge [`Layout`][].
///
/// `Allocator` yenzelwe ukuba iphunyezwe kwii-ZSTs, izingqinisiso, okanye izikhombisi ezi-smart kuba ukuba nomnikezeli onje nge `MyAlloc([u8; N])` akunakususwa, ngaphandle kokuhlaziya izikhombisi kwimemori eyabelweyo.
///
/// Ngokungafaniyo ne-[`GlobalAlloc`][], ulwabiwo olulingeneyo aluvumelekanga kwi `Allocator`.
/// Ukuba isabelo esisisiseko asikuxhasi oku (njengejemalloc) okanye sibuyise isikhombisi esingasebenziyo (njenge `libc::malloc`), oku kufuneka kubanjwe ngophumezo.
///
/// ### Okwangoku inkumbulo eyabelweyo
///
/// Ezinye zeendlela zifuna ukuba ibhloko yenkumbulo *yabelwe ngoku* ngomnikezeli.Oku kuthetha ukuba:
///
/// * idilesi yokuqala yebhloko yememori ibuyiselwe ngaphambili yi [`allocate`], [`grow`], okanye [`shrink`], kunye
///
/// * ibhloko yememori khange ihanjiswe kamva, apho iibhloksi zihanjiswa ngokuthe ngqo ngokudluliselwa kwi [`deallocate`] okanye zatshintshwa ngokudluliselwa kwi [`grow`] okanye kwi [`shrink`] ebuyisa i `Ok`.
///
/// Ukuba i-`grow` okanye i-`shrink` ibuyisile i-`Err`, isikhombisi esidlulisiweyo sihlala sisasebenza.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Imemori ifanelekile
///
/// Ezinye zeendlela zifuna ukuba ubume *bufanele* ibhloko yememori.
/// Kuthetha ukuthini ukubekwa kwi-"fit" ibhloko yememori kuthetha (okanye ngokulinganayo, kwibhloko yememori ukuya kwi-"fit" ubeko) kukuba le miqathango ilandelayo kufuneka ibambe:
///
/// * Ibhloko kufuneka yabelwe ngolungelelwaniso olufanayo ne [`layout.align()`], kunye
///
/// * I-[`layout.size()`] ebonelelweyo kufuneka iwele kuluhlu lwe `min ..= max`, apho:
///   - `min` bubungakanani bobume obusetyenziswe kutshanje ekwabeni ibhloko, kwaye
///   - `max` bobona bungakanani bokwenyani babuya kwi [`allocate`], [`grow`], okanye [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Iibhloko zememori ezibuyiswe kumnikezeli kufuneka zalathe kwimemori esebenzayo kwaye zigcine ubunyani bazo kude kube yimeko kwaye zonke izinto ezikuyo zilahliwe,
///
/// * Ukubumbela okanye ukuhambisa umnikezeli makungasebenzi iibhloko zememori ezibuyiselwe kulo mabi.Ulwabiwo olwenziwe ngolwabiwo kufuneka luziphathe njengolwabayo, kwaye
///
/// * nasiphi na isikhombisi kwibhloko yememori eyi-[*currently allocated*] inokugqithiselwa nakweyiphi na indlela yomnikezeli.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Imizamo yokwaba ibhloko yememori.
    ///
    /// Kwimpumelelo, ubuyisela intlanganiso ye [`NonNull<[u8]>`][NonNull] ubungakanani kunye nokulungelelaniswa kweziqinisekiso ze `layout`.
    ///
    /// Ibhlokhi ebuyiselweyo inokuba nobukhulu obukhulu kunokuba ichaziwe ngu-`layout.size()`, kwaye inokuba okanye ingenakho ukuqala kwayo.
    ///
    /// # Errors
    ///
    /// Ukubuyisa i `Err` kubonisa ukuba inkumbulo iphelile okanye i `layout` ayihlangani nobungakanani bomnikezeli okanye iingxaki zokulungelelana.
    ///
    /// Ukuphunyezwa kuyakhuthazwa ukuba kubuyiswe i `Err` kwimemori yokudinwa kunokuxhalaba okanye ukukhupha isisu, kodwa oku akuyimfuneko engqongqo.
    /// (Ngokukodwa: kusemthethweni * ukuphumeza le trait ngaphezulu kwelayibrari yolwabiwo lwendalo olusebenzisa ukudinwa kwememori.)
    ///
    /// Abathengi abanqwenela ukukhupha ikhompawundi ngokuphendula kwimpazamo yolwabiwo bayakhuthazwa ukuba babize umsebenzi we [`handle_alloc_error`], endaweni yokufaka ngqo i `panic!` okanye efanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Iziphatha njenge-`allocate`, kodwa ikwaqinisekisa ukuba imemori ebuyisiweyo ayifakwanga zero.
    ///
    /// # Errors
    ///
    /// Ukubuyisa i `Err` kubonisa ukuba inkumbulo iphelile okanye i `layout` ayihlangani nobungakanani bomnikezeli okanye iingxaki zokulungelelana.
    ///
    /// Ukuphunyezwa kuyakhuthazwa ukuba kubuyiswe i `Err` kwimemori yokudinwa kunokuxhalaba okanye ukukhupha isisu, kodwa oku akuyimfuneko engqongqo.
    /// (Ngokukodwa: kusemthethweni * ukuphumeza le trait ngaphezulu kwelayibrari yolwabiwo lwendalo olusebenzisa ukudinwa kwememori.)
    ///
    /// Abathengi abanqwenela ukukhupha ikhompawundi ngokuphendula kwimpazamo yolwabiwo bayakhuthazwa ukuba babize umsebenzi we [`handle_alloc_error`], endaweni yokufaka ngqo i `panic!` okanye efanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // UKHUSELEKO: `alloc` ibuyisa inkumbulo esebenzayo
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Uhambisa kwakhona imemori ekubhekiswe kuyo kwi `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` Kufuneka uchaze ibhloko yememori [*currently allocated*] ngalo mabi, kwaye
    /// * `layout` kufuneka i [*fit*] ibhloko yememori.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Imizamo yokwandisa ibhloko yememori.
    ///
    /// Ibuyisa i [`NonNull<[u8]>`][NonNull] entsha enesikhombisi kunye nobukhulu boqobo bememori eyabelweyo.Isikhombisi sikulungele ukubamba idatha echazwe yi `new_layout`.
    /// Ukufezekisa oku, umnikezeli wolwabiwo angalwandisa ulwabiwo ekubhekiswe kulo kwi `ptr` ukuze ilingane uyilo olutsha.
    ///
    /// Ukuba oku kubuyisa i `Ok`, ubunini bebhloko yememori ekubhekiswe kuyo yi `ptr` budluliselwe kulo mabi.
    /// Inkumbulo inokuthi okanye ingakhululwa, kwaye kufuneka ithathelwe ingqalelo njengengasetyenziswanga ngaphandle kokuba ibuyiselwe kulowo ufowunayo kwakhona ngexabiso lokubuya lale ndlela.
    ///
    /// Ukuba le ndlela ibuyisa i `Err`, ubunini bebhloko yememori abugqithiselwanga kulo mabi, kwaye imixholo yebhloko yememori ayitshintshwanga.
    ///
    /// # Safety
    ///
    /// * `ptr` Kufuneka uchaze ibhloko yememori [*currently allocated*] ngalo mabi.
    /// * `old_layout` Kufuneka i [*fit*] ibhlokhi yenkumbulo (Ingxoxo ye `new_layout` ayiyifanelanga.).
    /// * `new_layout.size()` kufuneka ibengaphezulu okanye ilingane no-`old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ibuyisa i `Err` ukuba ubeko olutsha aluhlangabezani nobungakanani bomnikezeli kunye nezithintelo zolungelelwaniso zomnikezeli, okanye ukuba ukukhula ngenye indlela kuyasilela.
    ///
    /// Ukuphunyezwa kuyakhuthazwa ukuba kubuyiswe i `Err` kwimemori yokudinwa kunokuxhalaba okanye ukukhupha isisu, kodwa oku akuyimfuneko engqongqo.
    /// (Ngokukodwa: kusemthethweni * ukuphumeza le trait ngaphezulu kwelayibrari yolwabiwo lwendalo olusebenzisa ukudinwa kwememori.)
    ///
    /// Abathengi abanqwenela ukukhupha ikhompawundi ngokuphendula kwimpazamo yolwabiwo bayakhuthazwa ukuba babize umsebenzi we [`handle_alloc_error`], endaweni yokufaka ngqo i `panic!` okanye efanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // UKHUSELEKO: kuba i `new_layout.size()` kufuneka ibe nkulu okanye ilingane nayo
        // `old_layout.size()`, zombini ulwabiwo oludala kunye nolutsha lusemthethweni ngokufundwa kwaye lubhalela ii-`old_layout.size()` byte.
        // Kwakhona, ngenxa yokuba ulwabiwo oludala lwalungekasuswa, alunakudlula i `new_ptr`.
        // Ke, umnxeba oya kwi `copy_nonoverlapping` ukhuselekile.
        // Ikhontrakthi yokhuseleko ye `dealloc` kufuneka igcinwe ngulowo ufowunayo.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Iziphatha njenge-`grow`, kodwa ikwaqinisekisa ukuba imixholo emitsha isetelwe ku-zero ngaphambi kokuba ibuyiswe.
    ///
    /// Ibhloko yememori iya kuba neziqulatho zilandelayo emva kokuba umnxeba uphumelele
    /// `grow_zeroed`:
    ///   * Ii-Byte `0..old_layout.size()` zigciniwe kulwabiwo loqobo.
    ///   * Ii-Byte `old_layout.size()..old_size` ziya kugcinwa okanye zingabikho, kuxhomekeke kumiliselo lomnikezeli.
    ///   `old_size` ibhekisa kubungakanani bebhloko yememori ngaphambi komnxeba we `grow_zeroed`, onokuba mkhulu kunobungakanani obabuceliwe ekuqaleni xa wawubekelwe.
    ///   * Ii-Byte `old_size..new_size` zitsaliwe.I-`new_size` ibhekisa kubungakanani bebhloko yememori ebuyiswe ngumnxeba we `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` Kufuneka uchaze ibhloko yememori [*currently allocated*] ngalo mabi.
    /// * `old_layout` Kufuneka i [*fit*] ibhlokhi yenkumbulo (Ingxoxo ye `new_layout` ayiyifanelanga.).
    /// * `new_layout.size()` kufuneka ibengaphezulu okanye ilingane no-`old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ibuyisa i `Err` ukuba ubeko olutsha aluhlangabezani nobungakanani bomnikezeli kunye nezithintelo zolungelelwaniso zomnikezeli, okanye ukuba ukukhula ngenye indlela kuyasilela.
    ///
    /// Ukuphunyezwa kuyakhuthazwa ukuba kubuyiswe i `Err` kwimemori yokudinwa kunokuxhalaba okanye ukukhupha isisu, kodwa oku akuyimfuneko engqongqo.
    /// (Ngokukodwa: kusemthethweni * ukuphumeza le trait ngaphezulu kwelayibrari yolwabiwo lwendalo olusebenzisa ukudinwa kwememori.)
    ///
    /// Abathengi abanqwenela ukukhupha ikhompawundi ngokuphendula kwimpazamo yolwabiwo bayakhuthazwa ukuba babize umsebenzi we [`handle_alloc_error`], endaweni yokufaka ngqo i `panic!` okanye efanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // UKHUSELEKO: kuba i `new_layout.size()` kufuneka ibe nkulu okanye ilingane nayo
        // `old_layout.size()`, zombini ulwabiwo oludala kunye nolutsha lusemthethweni ngokufundwa kwaye lubhalela ii-`old_layout.size()` byte.
        // Kwakhona, ngenxa yokuba ulwabiwo oludala lwalungekasuswa, alunakudlula i `new_ptr`.
        // Ke, umnxeba oya kwi `copy_nonoverlapping` ukhuselekile.
        // Ikhontrakthi yokhuseleko ye `dealloc` kufuneka igcinwe ngulowo ufowunayo.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Imizamo yokunciphisa ibhloko yememori.
    ///
    /// Ibuyisa i [`NonNull<[u8]>`][NonNull] entsha enesikhombisi kunye nobukhulu boqobo bememori eyabelweyo.Isikhombisi sikulungele ukubamba idatha echazwe yi `new_layout`.
    /// Ukufezekisa oku, isabelo sinokuthi sinciphise ulwabiwo ekubhekiswe kulo kwi `ptr` ukulungela ubeko olutsha.
    ///
    /// Ukuba oku kubuyisa i `Ok`, ubunini bebhloko yememori ekubhekiswe kuyo yi `ptr` budluliselwe kulo mabi.
    /// Inkumbulo inokuthi okanye ingakhululwa, kwaye kufuneka ithathelwe ingqalelo njengengasetyenziswanga ngaphandle kokuba ibuyiselwe kulowo ufowunayo kwakhona ngexabiso lokubuya lale ndlela.
    ///
    /// Ukuba le ndlela ibuyisa i `Err`, ubunini bebhloko yememori abugqithiselwanga kulo mabi, kwaye imixholo yebhloko yememori ayitshintshwanga.
    ///
    /// # Safety
    ///
    /// * `ptr` Kufuneka uchaze ibhloko yememori [*currently allocated*] ngalo mabi.
    /// * `old_layout` Kufuneka i [*fit*] ibhlokhi yenkumbulo (Ingxoxo ye `new_layout` ayiyifanelanga.).
    /// * `new_layout.size()` kufuneka ibe ncinane kune okanye ilingane ne-`old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ibuyisa i `Err` ukuba ubeko olutsha aluhlangabezani nobungakanani bomnikezeli kunye nezithintelo zolungelelwaniso lomabi, okanye ukuba ukuncipha ngenye indlela kuyasilela.
    ///
    /// Ukuphunyezwa kuyakhuthazwa ukuba kubuyiswe i `Err` kwimemori yokudinwa kunokuxhalaba okanye ukukhupha isisu, kodwa oku akuyimfuneko engqongqo.
    /// (Ngokukodwa: kusemthethweni * ukuphumeza le trait ngaphezulu kwelayibrari yolwabiwo lwendalo olusebenzisa ukudinwa kwememori.)
    ///
    /// Abathengi abanqwenela ukukhupha ikhompawundi ngokuphendula kwimpazamo yolwabiwo bayakhuthazwa ukuba babize umsebenzi we [`handle_alloc_error`], endaweni yokufaka ngqo i `panic!` okanye efanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // UKHUSELEKO: kuba i `new_layout.size()` kufuneka ibe ngaphantsi okanye ilingane
        // `old_layout.size()`, zombini ulwabiwo oludala kunye nolutsha lusemthethweni ngokufundwa kwaye lubhalela ii-`new_layout.size()` byte.
        // Kwakhona, ngenxa yokuba ulwabiwo oludala lwalungekasuswa, alunakudlula i `new_ptr`.
        // Ke, umnxeba oya kwi `copy_nonoverlapping` ukhuselekile.
        // Ikhontrakthi yokhuseleko ye `dealloc` kufuneka igcinwe ngulowo ufowunayo.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Yenza iadaptha ye "by reference" ngalo mzekelo we `Allocator`.
    ///
    /// Iadaptha ebuyisiweyo ikwasebenzisa i `Allocator` kwaye iya kukuboleka ngokulula oku.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // UKHUSELEKO: ikhontrakthi yokhuseleko mayigcinwe ngulowo ufowunayo
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // UKHUSELEKO: ikhontrakthi yokhuseleko mayigcinwe ngulowo ufowunayo
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // UKHUSELEKO: ikhontrakthi yokhuseleko mayigcinwe ngulowo ufowunayo
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // UKHUSELEKO: ikhontrakthi yokhuseleko mayigcinwe ngulowo ufowunayo
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}