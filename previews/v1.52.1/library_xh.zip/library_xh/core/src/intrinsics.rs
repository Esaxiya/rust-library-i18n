//! Ikhomputha yangaphakathi.
//!
//! Iinkcazo ezihambelanayo zikwi `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Ukuphunyezwa kokuhambelana kwe-const kukwi `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # I-Const intrinsics
//!
//! Note: Naluphi na utshintsho kubunzulu be-intrinsics kufuneka kuxoxwe ngalo neqela leelwimi.
//! Oku kubandakanya utshintsho kuzinzo lobumbano.
//!
//! Ukuze wenze ukusetyenziswa kwangaphakathi ngexesha lokudityaniswa, umntu kufuneka akope ukumiliselwa ukusuka kwi-<https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ukuya kwi-`compiler/rustc_mir/src/interpret/intrinsics.rs` kwaye ongeze i-`#[rustc_const_unstable(feature = "foo", issue = "01234")]` kwi-intrinsic.
//!
//!
//! Ukuba i-intrinsic imele ukuba isetyenziswe ukusuka kwi-`const fn` nge-`rustc_const_stable` uphawu, uphawu lwangaphakathi kufuneka lube yi-`rustc_const_stable`, nayo.
//! Olo tshintsho alunakwenziwa ngaphandle kokubonisana ne-T-lang, kuba ibhaka inqaku kulwimi olungenakuphindwa kwikhowudi yomsebenzisi ngaphandle kwenkxaso yomhlanganisi.
//!
//! # Volatiles
//!
//! I-intrinsics eguqukayo ibonelela ngemisebenzi ejolise ekusebenzeni kwimemori ye-I/O, eqinisekisiweyo ukuba ayinakulungelelaniswa kwakhona ngumhlanganisi kwezinye i-intrinsics ezingazinzanga.Jonga amaxwebhu e-LLVM kwi [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! I-atomic intrinsics ibonelela ngokusebenza kweathom eqhelekileyo kumagama oomatshini, ngokulandelelana kwememori okunokwenzeka.Bathobela iisemantiki ezifanayo ne C++ 11.Jonga amaxwebhu e-LLVM kwi [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Ukuhlaziya ngokukhawuleza koku-odolwa kwememori:
//!
//! * Fumana, isithintelo ekufumaneni isitshixo.Ukufunda nokubhala okulandelayo kwenzeka emva kwesithintelo.
//! * Ukukhutshwa, isithintelo sokukhulula isitshixo.Ukufunda kwangaphambili nokubhala kwenzeka ngaphambi komqobo.
//! * Ukulandelelana ngokulandelelana, imisebenzi ngokulandelelana iyaqinisekiswa ukuba yenzeke ngokulandelelana.Le yimowudi esemgangathweni yokusebenza neentlobo zeatom kwaye ilingana neX0X ye Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Olu ngeniso lusetyenziselwa ukwenza lula unxibelelwano lwe-intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // UKHUSELEKO: yabona i `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Qaphela, ezi zinto zangaphakathi zithatha izikhombisi eziluhlaza kuba ziguqula inkumbulo ebekiweyo, engasebenziyo kwi `&` okanye kwi `&mut`.
    //

    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqu ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange` ngokudlula i [`Ordering::SeqCst`] njengazo zombini i `success` kunye ne `failure` parameter.
    ///
    /// Umzekelo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqu ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange` ngokudlula i [`Ordering::Acquire`] njengazo zombini i `success` kunye ne `failure` parameter.
    ///
    /// Umzekelo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange` ngokudlula i [`Ordering::Release`] njenge `success` kunye ne [`Ordering::Relaxed`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange` ngokudlula i [`Ordering::AcqRel`] njenge `success` kunye ne [`Ordering::Acquire`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqu ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange` ngokudlula i [`Ordering::Relaxed`] njengazo zombini i `success` kunye ne `failure` parameter.
    ///
    /// Umzekelo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange` ngokudlula i [`Ordering::SeqCst`] njenge `success` kunye ne [`Ordering::Relaxed`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange` ngokudlula i [`Ordering::SeqCst`] njenge `success` kunye ne [`Ordering::Acquire`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange` ngokudlula i [`Ordering::Acquire`] njenge `success` kunye ne [`Ordering::Relaxed`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange` ngokudlula i [`Ordering::AcqRel`] njenge `success` kunye ne [`Ordering::Relaxed`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqu ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange_weak` ngokudlula i [`Ordering::SeqCst`] njengazo zombini i `success` kunye ne `failure` parameter.
    ///
    /// Umzekelo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqu ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange_weak` ngokudlula i [`Ordering::Acquire`] njengazo zombini i `success` kunye ne `failure` parameter.
    ///
    /// Umzekelo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange_weak` ngokudlula i [`Ordering::Release`] njenge `success` kunye ne [`Ordering::Relaxed`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange_weak` ngokudlula i [`Ordering::AcqRel`] njenge `success` kunye ne [`Ordering::Acquire`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqu ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange_weak` ngokudlula i [`Ordering::Relaxed`] njengazo zombini i `success` kunye ne `failure` parameter.
    ///
    /// Umzekelo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange_weak` ngokudlula i [`Ordering::SeqCst`] njenge `success` kunye ne [`Ordering::Relaxed`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange_weak` ngokudlula i [`Ordering::SeqCst`] njenge `success` kunye ne [`Ordering::Acquire`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange_weak` ngokudlula i [`Ordering::Acquire`] njenge `success` kunye ne [`Ordering::Relaxed`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina ixabiso ukuba ixabiso langoku liyafana nexabiso le `old`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `compare_exchange_weak` ngokudlula i [`Ordering::AcqRel`] njenge `success` kunye ne [`Ordering::Relaxed`] njengeeparamitha ze `failure`.
    /// Umzekelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Ukulayisha ixabiso langoku lesikhombisi.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `load` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Ukulayisha ixabiso langoku lesikhombisi.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `load` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Ukulayisha ixabiso langoku lesikhombisi.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `load` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Igcina ixabiso kwindawo echaziweyo yememori.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `store` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Igcina ixabiso kwindawo echaziweyo yememori.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `store` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Igcina ixabiso kwindawo echaziweyo yememori.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `store` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Igcina ixabiso kwindawo echaziweyo yememori, ibuyise ixabiso elidala.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `swap` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Igcina ixabiso kwindawo echaziweyo yememori, ibuyise ixabiso elidala.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `swap` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Igcina ixabiso kwindawo echaziweyo yememori, ibuyise ixabiso elidala.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `swap` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Igcina ixabiso kwindawo echaziweyo yememori, ibuyise ixabiso elidala.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `swap` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Igcina ixabiso kwindawo echaziweyo yememori, ibuyise ixabiso elidala.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `swap` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Yongeza kwixabiso langoku, ubuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_add` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yongeza kwixabiso langoku, ubuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_add` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yongeza kwixabiso langoku, ubuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_add` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yongeza kwixabiso langoku, ubuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_add` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Yongeza kwixabiso langoku, ubuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_add` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Thabatha kwixabiso langoku, ubuyise ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_sub` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thabatha kwixabiso langoku, ubuyise ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_sub` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thabatha kwixabiso langoku, ubuyise ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_sub` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thabatha kwixabiso langoku, ubuyise ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_sub` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Thabatha kwixabiso langoku, ubuyise ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_sub` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ngokukhawuleza kunye nexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_and` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokukhawuleza kunye nexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_and` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokukhawuleza kunye nexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_and` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokukhawuleza kunye nexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_and` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokukhawuleza kunye nexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_and` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// I-Bitwise nand enexabiso langoku, ibuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kuhlobo lwe [`AtomicBool`] ngendlela ye `fetch_nand` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise nand enexabiso langoku, ibuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kuhlobo lwe [`AtomicBool`] ngendlela ye `fetch_nand` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise nand enexabiso langoku, ibuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kuhlobo lwe [`AtomicBool`] ngendlela ye `fetch_nand` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise nand enexabiso langoku, ibuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kuhlobo lwe [`AtomicBool`] ngendlela ye `fetch_nand` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise nand enexabiso langoku, ibuyisa ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kuhlobo lwe [`AtomicBool`] ngendlela ye `fetch_nand` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ngokukhawuleza okanye ngexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_or` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokukhawuleza okanye ngexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_or` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokukhawuleza okanye ngexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_or` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokukhawuleza okanye ngexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_or` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokukhawuleza okanye ngexabiso langoku, ukubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_or` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ngokucacileyo xor ngexabiso langoku, ubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_xor` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokucacileyo xor ngexabiso langoku, ubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_xor` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokucacileyo xor ngexabiso langoku, ubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_xor` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokucacileyo xor ngexabiso langoku, ubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_xor` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ngokucacileyo xor ngexabiso langoku, ubuyisela ixabiso langaphambili.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwiindidi ze [`atomic`] ngendlela ye `fetch_xor` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ubuninzi bexabiso langoku usebenzisa uthelekiso olusayiniweyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuninzi bexabiso langoku usebenzisa uthelekiso olusayiniweyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuninzi bexabiso langoku usebenzisa uthelekiso olusayiniweyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuninzi bexabiso langoku usebenzisa uthelekiso olusayiniweyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuninzi ngexabiso langoku.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olusayiniweyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olusayiniweyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olusayiniweyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olusayiniweyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olusayiniweyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] esayiniweyo yeenombolo ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncinci ngexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_min` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ubuninzi bexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuninzi bexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::Acquire`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuninzi bexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::Release`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuninzi bexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuninzi bexabiso langoku usebenzisa uthelekiso olungatyikitywanga.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi-[`atomic`] iindidi ezingabhaliswanga ezipheleleyo ngendlela ye `fetch_max` ngokudlula i [`Ordering::Relaxed`] njenge `order`.
    /// Umzekelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// I-`prefetch` intrinsic lucebiso kumvelisi wekhowudi ukufaka umyalelo wokuqala ukuba uyaxhaswa;Ngaphandle koko, akukho-op.
    /// Ukulandelelwa akunampembelelo kwindlela yokuziphatha yenkqubo kodwa kunokutshintsha ukusebenza kwayo.
    ///
    /// Ingxoxo ye `locality` kufuneka ibe yinani elipheleleyo kwaye yindawo yokucacisa yendawo ukusukela kwi (0), akukho ndawo, ukuya kwi (3), kugcinwa kakhulu kwindawo yokugcina izinto.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// I-`prefetch` intrinsic lucebiso kumvelisi wekhowudi ukufaka umyalelo wokuqala ukuba uyaxhaswa;Ngaphandle koko, akukho-op.
    /// Ukulandelelwa akunampembelelo kwindlela yokuziphatha yenkqubo kodwa kunokutshintsha ukusebenza kwayo.
    ///
    /// Ingxoxo ye `locality` kufuneka ibe yinani elipheleleyo kwaye yindawo yokucacisa yendawo ukusukela kwi (0), akukho ndawo, ukuya kwi (3), kugcinwa kakhulu kwindawo yokugcina izinto.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// I-`prefetch` intrinsic lucebiso kumvelisi wekhowudi ukufaka umyalelo wokuqala ukuba uyaxhaswa;Ngaphandle koko, akukho-op.
    /// Ukulandelelwa akunampembelelo kwindlela yokuziphatha yenkqubo kodwa kunokutshintsha ukusebenza kwayo.
    ///
    /// Ingxoxo ye `locality` kufuneka ibe yinani elipheleleyo kwaye yindawo yokucacisa yendawo ukusukela kwi (0), akukho ndawo, ukuya kwi (3), kugcinwa kakhulu kwindawo yokugcina izinto.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// I-`prefetch` intrinsic lucebiso kumvelisi wekhowudi ukufaka umyalelo wokuqala ukuba uyaxhaswa;Ngaphandle koko, akukho-op.
    /// Ukulandelelwa akunampembelelo kwindlela yokuziphatha yenkqubo kodwa kunokutshintsha ukusebenza kwayo.
    ///
    /// Ingxoxo ye `locality` kufuneka ibe yinani elipheleleyo kwaye yindawo yokucacisa yendawo ukusukela kwi (0), akukho ndawo, ukuya kwi (3), kugcinwa kakhulu kwindawo yokugcina izinto.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ucingo lweathom.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi [`atomic::fence`] ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Ucingo lweathom.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi [`atomic::fence`] ngokudlula i [`Ordering::Acquire`] njenge `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ucingo lweathom.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi [`atomic::fence`] ngokudlula i [`Ordering::Release`] njenge `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ucingo lweathom.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi [`atomic::fence`] ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Isithintelo sememori sokuhlanganisela kuphela.
    ///
    /// Ukufikelela kwimemori akusayi kuphinda kulungelelaniswe kulo mqobo ngumhlanganisi, kodwa akukho miyalelo iya kukhutshelwa yona.
    /// Oku kufanelekile ekusebenzeni kumsonto ofanayo onokuthi ungakhululwa, njengaxa unxibelelana nabaphathi beempawu.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi [`atomic::compiler_fence`] ngokudlula i [`Ordering::SeqCst`] njenge `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Isithintelo sememori sokuhlanganisela kuphela.
    ///
    /// Ukufikelela kwimemori akusayi kuphinda kulungelelaniswe kulo mqobo ngumhlanganisi, kodwa akukho miyalelo iya kukhutshelwa yona.
    /// Oku kufanelekile ekusebenzeni kumsonto ofanayo onokuthi ungakhululwa, njengaxa unxibelelana nabaphathi beempawu.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi [`atomic::compiler_fence`] ngokudlula i [`Ordering::Acquire`] njenge `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Isithintelo sememori sokuhlanganisela kuphela.
    ///
    /// Ukufikelela kwimemori akusayi kuphinda kulungelelaniswe kulo mqobo ngumhlanganisi, kodwa akukho miyalelo iya kukhutshelwa yona.
    /// Oku kufanelekile ekusebenzeni kumsonto ofanayo onokuthi ungakhululwa, njengaxa unxibelelana nabaphathi beempawu.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi [`atomic::compiler_fence`] ngokudlula i [`Ordering::Release`] njenge `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Isithintelo sememori sokuhlanganisela kuphela.
    ///
    /// Ukufikelela kwimemori akusayi kuphinda kulungelelaniswe kulo mqobo ngumhlanganisi, kodwa akukho miyalelo iya kukhutshelwa yona.
    /// Oku kufanelekile ekusebenzeni kumsonto ofanayo onokuthi ungakhululwa, njengaxa unxibelelana nabaphathi beempawu.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic iyafumaneka kwi [`atomic::compiler_fence`] ngokudlula i [`Ordering::AcqRel`] njenge `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Umlingo wangaphakathi ofumana intsingiselo yawo kwiimpawu eziqhotyoshelwe kulo msebenzi.
    ///
    /// Umzekelo, ukuhamba kwedatha kusetyenziswa oku ukufaka intsholongwane engqinelanayo ukuze i `rustc_peek(potentially_uninitialized)` iphinde ikhangele ukuba ukuhamba kwedatha kuyinyani ukuba ayifakwanga kwinqanaba lolawulo lokuhamba.
    ///
    ///
    /// Le intrinsic akufuneki isetyenziswe ngaphandle komhlanganisi.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Ihambisa ukwenziwa kwenkqubo.
    ///
    /// Uhlobo olusebenziseka lula kwaye luzinzile lwalo msebenzi yi [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Yazisa i-optimizer ukuba eli nqanaba lekhowudi alinakufikeleleka, lenze ukuba kube nakho ukwandiswa ngakumbi.
    ///
    /// Qaphela, oku kwahluke kakhulu kwi-`unreachable!()` macro: Ngokungafaniyo nemacro, ethi panics xa yenziwe, kukuziphatha okungachazwanga * ukufikelela kwikhowudi ephawulwe ngalo msebenzi.
    ///
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Yazisa i-optimizer ukuba imeko ihlala iyinyani.
    /// Ukuba imeko ibubuxoki, indlela yokuziphatha ayichazwanga.
    ///
    /// Akukho khowudi yenziweyo yangaphakathi, kodwa i-optimizer iya kuzama ukuyigcina (kunye nemeko yayo) phakathi kokupasa, okunokuphazamisa ukwenziwa kwekhowudi ejikeleze kunye nokunciphisa ukusebenza.
    /// Ayizukusetyenziswa ukuba umntu ongenayo unokufumana isilungisi sedwa, okanye ukuba asenzi nanye into esebenzayo.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Amacebo kumhlanganisi ukuba imeko ye branch inokuba iyinyani.
    /// Ibuyisa ixabiso elidluliselwe kuyo.
    ///
    /// Nakuphi na ukusetyenziswa ngaphandle kweengxelo ze `if` ngekhe kungabinampembelelo.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Amacebo kumhlanganisi ukuba imeko ye-branch inokuba ibubuxoki.
    /// Ibuyisa ixabiso elidluliselwe kuyo.
    ///
    /// Nakuphi na ukusetyenziswa ngaphandle kweengxelo ze `if` ngekhe kungabinampembelelo.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Yenza umgibe wokuqhekeka, ukuze uhlolwe yi-debugger.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn breakpoint();

    /// Ubungakanani bohlobo kwii-byte.
    ///
    /// Ngokukodwa, oku kukuseta kwi-byte phakathi kwezinto ezilandelanayo zohlobo olunye, kubandakanya ulungelelwaniso lokutshixa.
    ///
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Ubuncinci bokulungelelaniswa kohlobo.
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Ulungelelwaniso olukhethiweyo lodidi.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ubungakanani bexabiso elichaziweyo kwii-byte.
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ulungelelwaniso olufunekayo lwexabiso ekubhekiselwe kulo.
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Ifumana umtya wesilayidi esimileyo oqukethe igama lohlobo.
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Ifumana isazisi esahlukileyo kwihlabathi jikelele kuhlobo oluchaziweyo.
    /// Lo msebenzi uza kubuyisa ixabiso elifanayo kudidi nokuba yeyiphi na i crate ethe yangeniswa kuyo.
    ///
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Unogada wemisebenzi engakhuselekanga engenakuze yenziwe ukuba i `T` ayinabemi:
    /// Oku kuya kuba ngokwe panic, okanye ungenzi nto.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Unogada wemisebenzi engakhuselekanga engenakuze yenziwe ukuba i `T` ayikuvumeli ukuqalwa kwe-zero: Oku kuya kuba yi-panic, okanye ingenzi nto.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn assert_zero_valid<T>();

    /// Unogada wemisebenzi engakhuselekanga engenakuze yenziwe ukuba i `T` ineepateni ezingasebenziyo: Oku kuya kuba yi panic, okanye ungenzi nto.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn assert_uninit_valid<T>();

    /// Ifumana ireferensi kwi-static `Location` ebonisa apho ibizwa khona.
    ///
    /// Cinga ukusebenzisa i [`core::panic::Location::caller`](crate::panic::Location::caller) endaweni yoko.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Isusa ixabiso ngaphandle kwendawo ngaphandle kokusebenzisa iglu yokuyeka.
    ///
    /// Oku kwenzeka kuphela kwi [`mem::forget_unsized`];`forget` eqhelekileyo isebenzisa i `ManuallyDrop` endaweni yoko.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Iphinda itolike iibits zexabiso lolunye uhlobo njengolunye uhlobo.
    ///
    /// Zombini ezi ntlobo kufuneka zibe nobukhulu obulinganayo.
    /// Nokuba yeyantlandlolo, okanye iziphumo, ayinakuba yi [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` ngokwemeko ilingana nokuhamba kancinci kolunye uhlobo uye kolunye.Ikopa iibits ukusuka kwixabiso lomthombo kwixabiso lesiphelo, emva koko ilibale eyantlandlolo.
    /// Ilingana ne-C's `memcpy` phantsi kwe-hood, njenge-`transmute_copy`.
    ///
    /// Kuba i `transmute` ngumsebenzi wexabiso, ukulungelelaniswa kwexabiso *lokudluliselwa ngokwabo* ayisiyiyo inkxalabo.
    /// Njengawo nawuphi na omnye umsebenzi, umhlanganisi sele eqinisekisa ukuba zombini i-`T` kunye ne-`U` zilungelelaniswe ngokufanelekileyo.
    /// Nangona kunjalo, xa kugqithiswa amaxabiso *akhomba kwenye indawo*(njengezikhombisi, izingqinisiso, iibhokisi…), umfowunelwa kufuneka aqinisekise ukulungelelaniswa okufanelekileyo kwamaxabiso asalathiweyo.
    ///
    /// `transmute` ayikhuselekanga ngokumangalisayo **.Zininzi iindlela zokwenza i [undefined behavior][ub] ngalo msebenzi.I `transmute` kufuneka ibe yeyona ndlela yokugqibela.
    ///
    /// I [nomicon](../../nomicon/transmutes.html) inamaxwebhu ongezelelweyo.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Kukho izinto ezimbalwa i `transmute` eluncedo kuzo.
    ///
    /// Ukuguqula isikhombisi sibe sisikhombisi somsebenzi.Oku *akuphathwayo* koomatshini apho izikhombisi zomsebenzi kunye nezikhombisi zedatha zinobungakanani obahlukeneyo.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Ukwandisa ixesha lokuphila, okanye ukunciphisa ixesha lokuphila elingenasiphelo.Oku kuhambile, akukhuselekanga kakhulu i Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Sukuphelelwa lithemba: izinto ezininzi ezisetyenziswayo ze `transmute` zinokufezekiswa ngezinye iindlela.
    /// Apha ngezantsi kukho izicelo eziqhelekileyo ze `transmute` ezinokuthi zithathelwe indawo kukwakhiwa okukhuselekileyo.
    ///
    /// Ukuguqula i-bytes(`&[u8]`) eluhlaza ukuya kwi-`u32`, i-`f64`, njl.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // Sebenzisa i `u32::from_ne_bytes` endaweni yoko
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // okanye sebenzisa i `u32::from_le_bytes` okanye i `u32::from_be_bytes` ukukhankanya i-endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ukuguqula isikhombisi sibe yi-`usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Sebenzisa i-`as` cast endaweni yoko
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Ukuguqula i `*mut T` ibe yi `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Sebenzisa imali ebuyisiweyo endaweni yoko
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Ukuguqula i `&mut T` ibe yi `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ngoku, hlanganisa i-`as` kwaye uphinde uphinde uphinde uqaphele, qaphela ukudityaniswa kwe-`as` `as` akuyonto eguqukayo
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Ukuguqula i `&str` ibe yi `&[u8]`:
    ///
    /// ```
    /// // le ayisiyondlela ilungileyo yokwenza oku.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Unokusebenzisa i `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Okanye, sebenzisa nje umtya we-byte, ukuba unolawulo kumtya wokoqobo
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Ukuguqula i `Vec<&T>` ibe yi `Vec<Option<&T>>`.
    ///
    /// Ukuhambisa uhlobo lwangaphakathi lwesiqulatho, kufuneka uqiniseke ukuba awophuli nayiphi na into yesiqulatho.
    /// Kwi-`Vec`, oku kuthetha ukuba zombini ubukhulu *kunye nokulungelelaniswa* kweentlobo zangaphakathi kufuneka zingqinelane.
    /// Ezinye izikhongozeli zinokuxhomekeka kubungakanani bohlobo, ulungelelwaniso, okanye i `TypeId`, kwimeko apho ukuhambisa kungakhange kwenzeke kwaphela ngaphandle kokophula iziqulatho zekhonteyina.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone i-vector njengoko siza kuyisebenzisa kwakhona kamva
    /// let v_clone = v_orig.clone();
    ///
    /// // Sebenzisa ukuhambisa: oku kuxhomekeke kulwakhiwo lwedatha olungachazwanga lwe `Vec`, umbono olubi kwaye onokubangela Ukuziphatha okungachazwanga.
    /////
    /// // Nangona kunjalo, ayikho ikopi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Le yindlela ecetyiswayo nekhuselekileyo.
    /// // Ikopa yonke i vector, nangona kunjalo, kuluhlu olutsha.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Le yeyona kopi ifanelekileyo, indlela engakhuselekanga ye "transmuting" nge `Vec`, ngaphandle kokuxhomekeka kubeko lwedatha.
    /// // Endaweni yokubiza u-`transmute` ngokoqobo, senza isikhombisi, kodwa ngokubhekisele ekuguquleni uhlobo lwangaphakathi lwangaphakathi i (`&i32`) lube yi (`Option<&i32>`) entsha, konke oku kunemiqolomba efanayo.
    /////
    /// // Ngaphandle kolwazi olunikezwe apha ngasentla, nxibelelana noxwebhu lwe [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Hlaziya oku xa i-vec_into_raw_parts izinzisiwe.
    ///     // Qinisekisa ukuba i-vector yoqobo ayilahlwanga.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Ukuphumeza i `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Zininzi iindlela zokwenza oku, kwaye kukho iingxaki ezininzi ngale ndlela (transmute) ilandelayo.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // Okokuqala: ukuhambisa akululanga olukhuselekileyo;konke kujonga ukuba ngu-T kunye
    ///         // U zinobukhulu obulinganayo.
    ///         // Okwesibini, apha, uneereferensi ezimbini ezinokuguquguquka ezalatha kwimemori efanayo.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Oku kususa uhlobo lweengxaki zokhuseleko;I-`&mut *` iya* kukunika i-`&mut T` ukusuka kwi-`&mut T` okanye i-`*mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Nangona kunjalo, useneereferensi ezimbini ezinokuguquka zikhombe kwimemori efanayo.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Le yindlela elenziwa ngayo yithala leencwadi eliqhelekileyo.
    /// // Le yeyona ndlela ilungileyo, ukuba ufuna ukwenza into enje
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Oku ngoku kunereferensi ezintathu ezinokuguquguquka ezalatha kwimemori efanayo.I-`slice`, i-rvalue ret.0, kunye ne-rvalue ret.1.
    ///         // `slice` ayikaze isetyenziswe emva kwe `let ptr = ...`, kwaye ke umntu unokuyiphatha njenge-"dead", kwaye ke, unezilayi ezimbini zokwenyani eziguqukayo.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ngelixa oku kwenza ukuba i-intrinsic const izinzile, sinekhowudi ethile yesiqhelo kwi-const fn
    // ukukhangela okuthintela ukusetyenziswa kwayo ngaphakathi kwe `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Ibuyisa i `true` ukuba lolona hlobo lwanikiweyo njenge `T` lufuna ukuhla kweglu;ibuyisa i-`false` ukuba lolona hlobo lubonelelwe ngokusetyenziswa kwe `T` `Copy`.
    ///
    ///
    /// Ukuba olona hlobo aludingi kulahla iglu okanye ukusebenzisa i `Copy`, ixabiso lokubuyela kulo msebenzi alichazwanga.
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ibala isilinganisi esivela kwisikhombisi.
    ///
    /// Oku kuphunyezwa njenge-intrinsic ukunqanda ukuguqukela kwinani elipheleleyo, kuba uguquko luya kulahla ulwazi lokufumana ulwazi.
    ///
    /// # Safety
    ///
    /// Zombini isikhombisi sokuqala kunye nesiphumo kufuneka sibe kwimida okanye kwi-byte enye emva kokuphela kwento eyabelweyo.
    /// Ukuba isikhombisi siphuma ngaphandle kwemida okanye ukugcwala kwe-arithmetic kuya kwenzeka ke nakuphi na ukusetyenziswa kwakhona kwexabiso elibuyiselweyo kuya kukhokelela kukuziphatha okungachazwanga.
    ///
    ///
    /// Inguqulelo ezinzileyo yale intrinsic yi [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ibala isilinganisi esivela kwisikhombisi, ngokunokwenzeka sisongele.
    ///
    /// Oku kuphunyezwa njenge-intrinsic ukunqanda ukuguqukela kwinani elipheleleyo, kuba uguquko luthintela ukwenziwa okuthile.
    ///
    /// # Safety
    ///
    /// Ngokungafaniyo ne-`offset` intrinsic, le intrinsic ayithinteli isikhombisi esikhokelela kwisalathiso okanye kwi-byte enye edlulileyo ekupheleni kwento eyabelweyo, kwaye isonga ngokudibanisa izibalo ezibini.
    /// Ixabiso elisisiphumo alisebenzi ukuba lisetyenziselwe ukufikelela kwimemori.
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ukulingana kwi-`llvm.memcpy.p0i8.0i8.*` yangaphakathi, kunye nobukhulu be-`count`*`size_of::<T>()` kunye nokulungelelaniswa kwe
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ipharamitha eguqukayo isetelwe kwi `true`, ke ayizukulungiswa ngaphandle kokuba ubungakanani bulingana no-zero.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ilingana ne-`llvm.memmove.p0i8.0i8.*` yangaphakathi efanelekileyo, kunye nobungakanani be-`count* size_of::<T>()` kunye nokulungelelaniswa kwe
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ipharamitha eguqukayo isetelwe kwi `true`, ke ayizukulungiswa ngaphandle kokuba ubungakanani bulingana no-zero.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ilingana ne-`llvm.memset.p0i8.*` intrinsic efanelekileyo, enobungakanani be-`count* size_of::<T>()` kunye nokulungelelaniswa kwe `min_align_of::<T>()`.
    ///
    ///
    /// Ipharamitha eguqukayo isetelwe kwi `true`, ke ayizukulungiswa ngaphandle kokuba ubungakanani bulingana no-zero.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Yenza umthwalo oguqukayo kwisikhombisi se `src`.
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Yenza ivenkile eguqukayo kwisikhombisi se `dst`.
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Yenza umthwalo oguqukayo kwisikhombisi se `src` Isikhombisi akufuneki ukuba silungelelaniswe.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Yenza ivenkile eguqukayo kwisikhombisi se `dst`.
    /// Isikhombisi akufuneki ukuba silungelelaniswe.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Ibuyisa ingcambu yesikwere se `f32`
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Ibuyisa ingcambu yesikwere se `f64`
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Iphakamisa i `f32` kumanani apheleleyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Iphakamisa i `f64` kumanani apheleleyo.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Ibuyisa i-sine ye-`f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Ibuyisa i-sine ye-`f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Ibuyisa icosine ye `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Ibuyisa icosine ye `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Iphakamisa i `f32` ukuya kumandla we `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Iphakamisa i `f64` ukuya kumandla we `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Ibuyisa ukubonakaliswa kwe `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Ibuyisa ukubonakaliswa kwe `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Ibuyisa 2 ephakanyiswe kumandla e `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Ibuyisa 2 ephakanyiswe kumandla e `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Ibuyisa i-logarithm yendalo ye `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Ibuyisa i-logarithm yendalo ye `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Ibuyisela isiseko se-10 logarithm ye `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Ibuyisela isiseko se-10 logarithm ye `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Ibuyisela isiseko 2 logarithm ye `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Ibuyisela isiseko 2 logarithm ye `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Ibuyisa i `a * b + c` yamaxabiso e `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Ibuyisa i `a * b + c` yamaxabiso e `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Ibuyisa ixabiso elipheleleyo le `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Ibuyisa ixabiso elipheleleyo le `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Ibuyisa ubuncinci bexabiso lama-`f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Ibuyisa ubuncinci bexabiso lama-`f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Ibuyisa ubuninzi bexabiso le-`f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Ibuyisa ubuninzi bexabiso le-`f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Ikhuphela uphawu ukusuka kwi `y` ukuya kwi `x` ngamaxabiso e `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Ikhuphela uphawu ukusuka kwi `y` ukuya kwi `x` ngamaxabiso e `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Ibuyisa inani elipheleleyo elingaphantsi okanye elilingana no-`f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Ibuyisa inani elipheleleyo elingaphantsi okanye elilingana no-`f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Ibuyisela elona nani lincinci lincinci lingaphezulu okanye elilinganayo ne `f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Ibuyisela elona nani lincinci lincinci lingaphezulu okanye elilinganayo ne `f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Ibuyisa inani elipheleleyo le-`f32`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Ibuyisa inani elipheleleyo le-`f64`.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Ibuyisela inani elipheleleyo elikufutshane kwi `f32`.
    /// Ngamana ungaphakamisa indawo engadibaniyo nenqaku lokudada ukuba impikiswano ayisiyongamanani.
    pub fn rintf32(x: f32) -> f32;
    /// Ibuyisela inani elipheleleyo elikufutshane kwi `f64`.
    /// Ngamana ungaphakamisa indawo engadibaniyo nenqaku lokudada ukuba impikiswano ayisiyongamanani.
    pub fn rintf64(x: f64) -> f64;

    /// Ibuyisela inani elipheleleyo elikufutshane kwi `f32`.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Ibuyisela inani elipheleleyo elikufutshane kwi `f64`.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Ibuyisela inani elipheleleyo elikufutshane kwi `f32`.Ukujikeleza iimeko zecala lendlela kude neqanda.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Ibuyisela inani elipheleleyo elikufutshane kwi `f64`.Ukujikeleza iimeko zecala lendlela kude neqanda.
    ///
    /// Inguqulelo ezinzileyo yale intrinsic is
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Ukongezwa kokudada okuvumela ukwenziwa ngokusekwe kwimithetho yealgebra.
    /// Unokucinga ukuba igalelo ligqityiwe.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Ukuthabatha ukuntywila okuvumela ukwenziwa ngokusekwe kwimithetho yealgebra.
    /// Unokucinga ukuba igalelo ligqityiwe.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Ukuphindaphindwa kokudada okuvumela ukwandiswa ngokusekwe kwimithetho yealgebra.
    /// Unokucinga ukuba igalelo ligqityiwe.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Ulwahlulo lomkhumbi ovumela ukulungiswa ngokusekelwe kwimithetho ye-algebraic.
    /// Unokucinga ukuba igalelo ligqityiwe.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Intsalela yokuntywila evumela ukwenziwa ngokusekwe kwimithetho yealgebra.
    /// Unokucinga ukuba igalelo ligqityiwe.
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Guqula nge-XLX ye-LLVM, enokuthi ibuyisele undef kumaxabiso kuluhlu
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Ukuzinza njenge [`f32::to_int_unchecked`] kunye ne [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Ibuyisa inani leebits ezibekwe kuhlobo olupheleleyo lwe `T`
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`count_ones` ngendlela.
    /// Umzekelo,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Ibuyisela inani lezinto ezikhokelayo ezingacwangciswanga (zeroes) kuhlobo olupheleleyo lwe `T`.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`leading_zeros` ngendlela.
    /// Umzekelo,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// I `x` enexabiso `0` iya kubuyisa ububanzi be `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Njengo `ctlz`, kodwa engakhuselekanga ngokungakumbi njengoko ibuyisa i `undef` xa inikwe i `x` ngexabiso le `0`.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Ibuyisela inani lokulandela ngokungacwangciswanga iibits (zeroes) kuhlobo olupheleleyo `T`.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`trailing_zeros` ngendlela.
    /// Umzekelo,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// I `x` enexabiso `0` iya kubuyisa ububanzi be `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Njengo `cttz`, kodwa engakhuselekanga ngokungakumbi njengoko ibuyisa i `undef` xa inikwe i `x` ngexabiso le `0`.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Ukuguqula i-byte kuhlobo olupheleleyo lwe-`T`.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`swap_bytes` ngendlela.
    /// Umzekelo,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Ukuguqula iibits kuhlobo olupheleleyo lwe `T`.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`reverse_bits` ngendlela.
    /// Umzekelo,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Yenza ukongezwa kwenani elipheleleyo.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`overflowing_add` ngendlela.
    /// Umzekelo,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yenza ukukhangela inani elipheleleyo
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`overflowing_sub` ngendlela.
    /// Umzekelo,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yenza inani eliphindaphindwayo elihloliweyo
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`overflowing_mul` ngendlela.
    /// Umzekelo,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yenza ukwahlula ngokuthe ngqo, kukhokelela kukuziphatha okungachazwanga apho i-`x % y != 0` okanye i-`y == 0` okanye i-`x == T::MIN && y == -1`
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Yenza ukwahlula okungakhange kuhlolwe, kukhokelela kukuziphatha okungachazwanga apho i-`y == 0` okanye i-`x == T::MIN && y == -1`
    ///
    ///
    /// Izinto ezisongelayo ezikhuselekileyo zale intrinsic ziyafumaneka kwinani elipheleleyo lokuqala ngokusebenzisa indlela ye `checked_div`.
    /// Umzekelo,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Ibuyisa intsalela yokwahlulwa okungakhange kuhlolwe, okukhokelela kwisimilo esingachazwanga xa i-`y == 0` okanye i-`x == T::MIN && y == -1`
    ///
    ///
    /// Izinto ezisongelayo ezikhuselekileyo zale intrinsic ziyafumaneka kwinani elipheleleyo lokuqala ngokusebenzisa indlela ye `checked_rem`.
    /// Umzekelo,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Yenza utshintsho olungasetyenziswanga lwasekhohlo, olukhokelela kwindlela yokuziphatha engachazwanga xa i-`y < 0` okanye i-`y >= N`, apho uN bububanzi be-T kwiibitshi.
    ///
    ///
    /// Izinto ezisongelayo ezikhuselekileyo zale intrinsic ziyafumaneka kwinani elipheleleyo lokuqala ngokusebenzisa indlela ye `checked_shl`.
    /// Umzekelo,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Yenza utshintsho olungakhange luhlolwe, olukhokelela kwindlela yokuziphatha engachazwanga xa i-`y < 0` okanye i-`y >= N`, apho i-N ububanzi be-T kwiibitshi.
    ///
    ///
    /// Izinto ezisongelayo ezikhuselekileyo zale intrinsic ziyafumaneka kwinani elipheleleyo lokuqala ngokusebenzisa indlela ye `checked_shr`.
    /// Umzekelo,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Ibuyisa iziphumo zokongezwa okungakhange kuhlolwe, okukhokelela kwisimilo esingachazwanga xa i `x + y > T::MAX` okanye i `x + y < T::MIN`.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Ibuyisa isiphumo sokuthabatha okungakhange kuhlolwe, okukhokelela kwisimilo esingachazwanga xa i `x - y > T::MAX` okanye i `x - y < T::MIN`.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Ibuyisa isiphumo sokuphindaphindwa okungakhange kuhlolwe, okukhokelela kwisimilo esingachazwanga xa u-`x *y > T::MAX` okanye u-`x* y < T::MIN`.
    ///
    ///
    /// Le intrinsic ayinaye umlingani ozinzileyo.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Yenza ujikeleze ngasekhohlo.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`rotate_left` ngendlela.
    /// Umzekelo,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Yenza ukujikeleza ngokuchanekileyo.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`rotate_right` ngendlela.
    /// Umzekelo,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Buyisela (a + b) imowudi 2 <sup>N</sup>, apho uN bububanzi beT kwiibits.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`wrapping_add` ngendlela.
    /// Umzekelo,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returns (a, b) mod 2 <sup>N</sup>, apho N bububanzi beT kwiibits.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`wrapping_sub` ngendlela.
    /// Umzekelo,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returns (a * b) mod 2 <sup>N</sup>, apho N bububanzi beT kwiibits.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`wrapping_mul` ngendlela.
    /// Umzekelo,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Ikhompyuter ye `a + b`, igcwalisa kwimida yamanani.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`saturating_add` ngendlela.
    /// Umzekelo,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Ikhompyuter ye `a - b`, igcwalisa kwimida yamanani.
    ///
    /// Iinguqulelo ezizinzileyo zale intrinsic ziyafumaneka kwinani elipheleleyo le-`saturating_sub` ngendlela.
    /// Umzekelo,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Ibuyisa ixabiso lomkhethi wokwahluka kwi 'v';
    /// ukuba i `T` ayinamkhethe, ibuyisa i `0`.
    ///
    /// Inguqu ezinzileyo yale intrinsic yi [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Ibuyisa inani lokwahluka kohlobo `T` olwenziwe kwi `usize`;
    /// ukuba i `T` ayinantlukwano, ibuyisa i `0`.Izinto ezingafakwanga ndawo ziya kubalwa.
    ///
    /// Inguqulelo yokuzinziswa kwale intrinsic yi [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// I-Rust's "try catch" eyakha ebhengeza isikhombisi somsebenzi `try_fn` ngesikhombisi sedatha `data`.
    ///
    /// Ingxoxo yesithathu ngumsebenzi obizwa ngokuba yi-panic.
    /// Lo msebenzi uthatha isikhombisi sedatha kunye nesikhombisi esijolise kwinto ekujoliswe kuyo ethe yabanjwa.
    ///
    /// Ngolwazi oluthe kratya jonga umthombo womhlanganisi kunye nokuphunyezwa kokubanjwa kwe std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Ikhupha ivenkile ye `!nontemporal` ngokwe-LLVM (jonga amaxwebhu ayo).
    /// Mhlawumbi ngekhe uzinze.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Jonga amaxwebhu e `<*const T>::offset_from` ngeenkcukacha.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Jonga amaxwebhu e `<*const T>::guaranteed_eq` ngeenkcukacha.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Jonga amaxwebhu e `<*const T>::guaranteed_ne` ngeenkcukacha.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Nikezela ngexesha lokudityaniswa.Akufanele ubizwe ngexesha lokubaleka.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Eminye imisebenzi ichaziwe apha kuba ngengozi yenziwe yafumaneka kule modyuli izinzile.
// Jonga i <https://github.com/rust-lang/rust/issues/15702>.
// (I-`transmute` nayo iwela kolu luhlu, kodwa ayinakusongelwa ngenxa yokujonga ukuba i `T` kunye ne `U` zinobungakanani obulinganayo.)
//

/// Ijonga ukuba ngaba i `ptr` ilungelelaniswe ngokufanelekileyo ngokubhekisele kwi `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Iikopi ze-`count *size_of::<T>()` byte ukusuka kwi-`src` ukuya kwi-`dst`.Umthombo kunye nendawo ekuyiwa kuyo kufuneka* zingadluli.
///
/// Kwimimandla yememori enokuthi igqithe, sebenzisa i [`copy`] endaweni yoko.
///
/// `copy_nonoverlapping` ilingana ngokomlinganiso no-C's [`memcpy`], kodwa ngomyalelo wempikiswano otshintshiweyo.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `src` kufuneka ubengu-[valid] xa kufundwa ii-`count * size_of::<T>()` byte.
///
/// * `dst` kufuneka ubengu-[valid] xa ubhala ii-`count * size_of::<T>()` byte.
///
/// * Zombini i `src` kunye ne `dst` kufuneka zilungelelaniswe ngokufanelekileyo.
///
/// * Umda wenkumbulo oqala nge `src` ngobungakanani `count *
///   ubungakanani_of: :<T>() `byte may *not* overlap with the region of memory starting at `dst` with the same size.
///
/// Njengo [`read`], i `copy_nonoverlapping` yenza ikopi ethe xhaxhe ye `T`, nokuba i `T` yi [`Copy`].
/// Ukuba i-`T` ayisiyi-[`Copy`], kusetyenziswa zombini ezi zixabiso kummandla oqala kwi-`*src` kwaye ummandla oqala kwi-`* dst` unokuba yi-[violate memory safety][read-ownership].
///
///
/// Qaphela ukuba nokuba ubungakanani bekopi esebenzayo (`count * size_of: :<T>()`) yi-`0`, izikhombisi kufuneka zingabi ze-NULL kwaye zilungelelaniswe ngokufanelekileyo.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Yenza ngesandla i [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Ihambisa onke amanqaku e-`src` ukuya kwi-`dst`, ishiya i-`src` ingenanto.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Qinisekisa ukuba i `dst` inesikhundla esaneleyo sokubamba yonke i `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Umnxeba wokuseta uhlala ukhuselekile kuba i `Vec` ayinakuze yabele ngaphezulu kwe-`isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` ngaphandle kokulahla imixholo yayo.
///         // Senza oku kuqala, ukunqanda iingxaki xa kunokwenzeka into iqhubeke phantsi kwe panics.
///         src.set_len(0);
///
///         // Imimandla emibini ayinakudibana ngenxa yokuba izingqinisiso ezinokuguquguquka aziyi-alias, kwaye i vectors ezimbini ezahlukeneyo azinakuba nayo imemori efanayo.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Yazisa i `dst` ukuba ngoku ibambe imixholo ye `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Yenza oku kukhangela kuphela ngexesha lokubaleka
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ungoyiki ukugcina impembelelo ye-codegen incinci.
        abort();
    }*/

    // UKHUSELEKO: ikhontrakthi yokhuseleko ye `copy_nonoverlapping` kufuneka ibenjalo
    // igcinwe ngulowo ufowunayo.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Iikopi ze-`count * size_of::<T>()` byte ukusuka kwi-`src` ukuya kwi-`dst`.Umthombo kunye nendawo ekuyiwa kuyo isenokudibana.
///
/// Ukuba umthombo nendawo ekuyiwa kuyo ayinakuze igqithe, i [`copy_nonoverlapping`] inokusetyenziswa endaweni yoko.
///
/// `copy` ilingana ngokomlinganiso no-C's [`memmove`], kodwa ngomyalelo wempikiswano otshintshiweyo.
/// Ukukopa kwenzeka ngokungathi ii-byte zikhutshiwe ukusuka kwi-`src` ukuya kuluhlu lwexeshana emva koko zikhutshelwe ukusuka kuludwe oluya kwi-`dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `src` kufuneka ubengu-[valid] xa kufundwa ii-`count * size_of::<T>()` byte.
///
/// * `dst` kufuneka ubengu-[valid] xa ubhala ii-`count * size_of::<T>()` byte.
///
/// * Zombini i `src` kunye ne `dst` kufuneka zilungelelaniswe ngokufanelekileyo.
///
/// Njengo [`read`], i `copy` yenza ikopi ethe xhaxhe ye `T`, nokuba i `T` yi [`Copy`].
/// Ukuba i-`T` ayisiyi-[`Copy`], kusetyenziswa amaxabiso omabini kummandla oqala e-`*src` kwaye ummandla oqala kwi-`* dst` unokuba yi-[violate memory safety][read-ownership].
///
///
/// Qaphela ukuba nokuba ubungakanani bekopi esebenzayo (`count * size_of: :<T>()`) yi-`0`, izikhombisi kufuneka zingabi ze-NULL kwaye zilungelelaniswe ngokufanelekileyo.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ngokufanelekileyo yenza i-Rust vector kwisikhuseli esingakhuselekanga:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` kufuneka ilungelelaniswe ngokuchanekileyo kudidi lwayo kunye non-zero.
/// /// * `ptr` kufuneka isebenze ngokufundwayo kwezinto ze-`elts` ezinxulumene nohlobo `T`.
/// /// * Ezo zinto akufuneki zisetyenziswe emva kokubiza lo msebenzi ngaphandle kwe `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // UKHUSELEKO: Imimiselo yethu eqinisekisa ukuba umthombo ulungelelaniswe kwaye usebenza,
///     // kunye ne `Vec::with_capacity` iqinisekisa ukuba sinendawo efanelekileyo yokubhala.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // UKHUSELEKO: Siyilele ngale ndawo inamandla ngaphambili,
///     // kwaye i `copy` eyandulelayo iziqalisile ezi zinto.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Yenza oku kukhangela kuphela ngexesha lokubaleka
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ungoyiki ukugcina impembelelo ye-codegen incinci.
        abort();
    }*/

    // UKHUSELEKO: ikhontrakthi yokhuseleko ye `copy` kufuneka igcinwe ngulowo ufowunayo.
    unsafe { copy(src, dst, count) }
}

/// Cwangcisa i-`count * size_of::<T>()` byte zememori eziqala kwi-`dst` ukuya kwi-`val`.
///
/// `write_bytes` Iyafana ne-C's [`memset`], kodwa icwangcisa i-`count * size_of::<T>()` byte kwi-`val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Ukuziphatha akuchazwanga ukuba ngaba imeko nganye iyaphulwa:
///
/// * `dst` kufuneka ubengu-[valid] xa ubhala ii-`count * size_of::<T>()` byte.
///
/// * `dst` kufuneka zilungelelaniswe ngokufanelekileyo.
///
/// Ukongeza, umntu ofowunayo kufuneka aqinisekise ukuba ukubhala i-`count * size_of::<T>()` byte kwingingqi enikiweyo yeziphumo zeememori kwixabiso elifanelekileyo le `T`.
/// Sebenzisa ingingqi yenkumbulo echwethezwe njenge-`T` enexabiso elingalunganga le-`T` kukuziphatha okungachazwanga.
///
/// Qaphela ukuba nokuba ubungakanani bekopi esebenzayo (`count * size_of: :<T>()`) yi-`0`, isikhombisi kufuneka singabi se-NULL kwaye silungelelaniswe ngokufanelekileyo.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Usetyenziso olusisiseko:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Ukwenza ixabiso elingasasebenziyo:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Ukuvuza kwexabiso eligcinwe ngaphambili ngokubhala ngaphezulu kwe `Box<T>` ngesikhombisi esingasebenziyo.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Okwangoku, ukusebenzisa okanye ukulahla iziphumo ze-`v` kwindlela yokuziphatha engachazwanga.
/// // drop(v); // ERROR
///
/// // Nokuba ivuza i `v` "uses", yiyo loo nto ukungazichazi isimilo.
/// // mem::forget(v); // ERROR
///
/// // Ngapha koko, i `v` ayisebenzi ngokungqinelana nolwakhiwo lohlobo olusisiseko, ke * nawuphi na umsebenzi ochukumisa ukungazichazi.
/////
/// // Vumela v2 =v;//IPHUTHA
///
/// unsafe {
///     // Endaweni yoko masibeke ixabiso elifanelekileyo
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ngoku ibhokisi ilungile
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // UKHUSELEKO: ikhontrakthi yokhuseleko ye `write_bytes` kufuneka igcinwe ngulowo ufowunayo.
    unsafe { write_bytes(dst, val, count) }
}