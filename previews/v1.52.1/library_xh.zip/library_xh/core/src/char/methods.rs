//! impl char char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Elona nqaku liphezulu lekhowudi linokubakho i `char`.
    ///
    /// I-`char` yi-[Unicode Scalar Value], okuthetha ukuba yi-[Code Point], kodwa kuphela kuluhlu oluthile.
    /// `MAX` lelona nqaku liphezulu lekhowudi lisemthethweni elingu [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` I () isetyenziswa kwi-Unicode ukumela impazamo yokumisela.
    ///
    /// Inokwenzeka, umzekelo, xa unika ii-UTF-8 byte ezingalunganga kwi [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Inguqulelo ye [Unicode](http://www.unicode.org/) yokuba iinxalenye ze-Unicode zeendlela ze `char` kunye ne `str` zisekwe kuyo.
    ///
    /// Iinguqulelo ezintsha ze-Unicode zikhutshwa rhoqo kwaye emva koko zonke iindlela ezikwithala leencwadi eliqhelekileyo kuxhomekeke kwi-Unicode zihlaziywa.
    /// Ke ngoko indlela yokuziphatha kwezinye ze-`char` kunye ne-`str` iindlela kunye nexabiso lolu tshintsho rhoqo ekuhambeni kwexesha.
    /// Oku akuthathelwa ingqalelo njengotshintsho oluqhekezayo.
    ///
    /// Iskimu sokubala amanani sichaziwe kwi [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Yenza i-iterator ngaphezulu kwe-UTF-16 ekhowudi yekhowudi kwi-`iter`, ibuyise ii-surrogates ezingafakwanga njenge-Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// I-decoder yelahleko inokufunyanwa ngokutshintsha iziphumo ze-`Err` ngomlinganiswa otshintshayo:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Guqula i `u32` iye kwi `char`.
    ///
    /// Qaphela ukuba zonke ii-char`s zisemthethweni [`u32`] s, kwaye zinokuphoswa kwenye nge
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Nangona kunjalo, ukubuyela umva akuyonyani: ayizizo zonke ezisebenzayo [`u32`] s ziyasebenza`char`s.
    /// `from_u32()` izakubuyisa i `None` ukuba okokufaka akulilo ixabiso elifanelekileyo le `char`.
    ///
    /// Ngenguqulelo engakhuselekanga yalo msebenzi etyeshela olu tshekisho, bona i [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Ukubuyisa i `None` xa okokufaka kungeyiyo i `char` esemthethweni:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Iguqula i `u32` iye kwi `char`, ityeshele ubunyani.
    ///
    /// Qaphela ukuba zonke ii-char`s zisemthethweni [`u32`] s, kwaye zinokuphoswa kwenye nge
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Nangona kunjalo, ukubuyela umva akuyonyani: ayizizo zonke ezisebenzayo [`u32`] s ziyasebenza`char`s.
    /// `from_u32_unchecked()` ayizukuyihoya le nto, kwaye iphoselwe ngaphandle kwi `char`, ngokunokwenzeka idale enye engavumelekanga.
    ///
    ///
    /// # Safety
    ///
    /// Lo msebenzi awukhuselekanga, njengoko unokwakha amaxabiso e `char` angasebenziyo.
    ///
    /// Ukufumana ingxelo ekhuselekileyo yalo msebenzi, bona umsebenzi we [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // UKHUSELEKO: ikhontrakthi yokhuseleko mayigcinwe ngulowo ufowunayo.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Guqula idijithi kwi-radix enikiweyo ibe yi-`char`.
    ///
    /// I-'radix' apha ngamanye amaxesha ibizwa ngokuba yi-'base'.
    /// I-radix ezimbini zibonisa inani le-binary, i-radix yeshumi, i-decimal, kunye ne-radix yeshumi elinesithandathu, i-hexadecimal, ukunika amaxabiso aqhelekileyo.
    ///
    /// Iiradices ezingenangqondo ziyaxhaswa.
    ///
    /// `from_digit()` izakubuyisa i `None` ukuba igalelo ayilojiti kwiradix enikiweyo.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba inikwe i-radix enkulu kune-36.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Idesimali eli-11 linani elinye kwisiseko 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Ukubuyisa i `None` xa igalelo lingesilo idijithi:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Ukugqithisa i-radix enkulu, ebangela i-panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Jonga ukuba i `char` linani elikwi-radix enikiweyo.
    ///
    /// I-'radix' apha ngamanye amaxesha ibizwa ngokuba yi-'base'.
    /// I-radix ezimbini zibonisa inani le-binary, i-radix yeshumi, i-decimal, kunye ne-radix yeshumi elinesithandathu, i-hexadecimal, ukunika amaxabiso aqhelekileyo.
    ///
    /// Iiradices ezingenangqondo ziyaxhaswa.
    ///
    /// Xa kuthelekiswa ne-[`is_numeric()`], lo msebenzi uqaphela kuphela oonobumba `0-9`, `a-z` kunye ne `A-Z`.
    ///
    /// 'Digit' ichazwa njengabalinganiswa abalandelayo kuphela:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Ukuqonda ngokubanzi i 'digit', bona i [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// I-Panics ukuba inikwe i-radix enkulu kune-36.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Ukugqithisa i-radix enkulu, ebangela i-panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Guqula i `char` ibe yidijithi kwirediyo enikiweyo.
    ///
    /// I-'radix' apha ngamanye amaxesha ibizwa ngokuba yi-'base'.
    /// I-radix ezimbini zibonisa inani le-binary, i-radix yeshumi, i-decimal, kunye ne-radix yeshumi elinesithandathu, i-hexadecimal, ukunika amaxabiso aqhelekileyo.
    ///
    /// Iiradices ezingenangqondo ziyaxhaswa.
    ///
    /// 'Digit' ichazwa njengabalinganiswa abalandelayo kuphela:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Ibuyisa i-`None` ukuba i-`char` ayibhekiseli kwidijithi kwi-radix enikiweyo.
    ///
    /// # Panics
    ///
    /// I-Panics ukuba inikwe i-radix enkulu kune-36.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ukupasa iziphumo ezingezozamanani kukusilela:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Ukugqithisa i-radix enkulu, ebangela i-panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // ikhowudi yahlulwe apha ukuphucula isantya sokwenziwa kwamatyala apho i `radix` ihlala ihleli kwaye ili-10 okanye incinci
        //
        let val = if likely(radix <= 10) {
            // Ukuba ayilojiti, inani elikhulu kune-radix liyakwenziwa.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Ibuyisa iterator evelisa i-hexadecimal Unicode yokubaleka umlinganiswa njenge `char`s.
    ///
    /// Oku kuyakubaleka oonobumba nge-Rust syntax yefom `\u{NNNNNN}` apho i-`NNNNNN` imelwe yi-hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Njenge iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Zombini ziyalingana:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Sebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // okanye u-1 uqinisekisa ukuba nge-c==0 ikhowudi ikhangela ukuba inani elinye kufuneka liprintwe kwaye (ngokufanayo) kuthintela ukugcwala okungaphantsi (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // Isalathiso selona nani libalulekileyo lehex
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Inguqulelo eyandisiweyo ye `escape_debug` evumela ngokuzikhethela ukubaleka iikhowudi zeGrapheme ezongeziweyo.
    /// Oku kusivumela ukuba sifomathe abalinganiswa njengamanqaku angathathi sithuba ngcono xa besekuqaleni komtya.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Ibuyisa iterator evelisa ikhowudi yokuphuma yokoqobo yomlinganiswa njenge `char`s.
    ///
    /// Oku kuyakubaleka oonobumba abafanayo nokuphunyezwa kwe `Debug` kwe `str` okanye `char`.
    ///
    ///
    /// # Examples
    ///
    /// Njenge iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Zombini ziyalingana:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Sebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Ibuyisa iterator evelisa ikhowudi yokuphuma yokoqobo yomlinganiswa njenge `char`s.
    ///
    /// Okungagqibekanga kukhethwe ngokukhetha ukuvelisa uncwadi olusemthethweni kwiilwimi ezahlukeneyo, kubandakanya i C++ 11 kunye neelwimi ezifanayo ze-C.
    /// Imigaqo ngqo yile:
    ///
    /// * Isithuba sibalekile njenge `\t`.
    /// * Ukubuya kwenqwelomoya kuphuncukile njenge `\r`.
    /// * Ukutya komgca kuyasinda njenge-`\n`.
    /// * Isicatshulwa esinye sibalekile njenge-`\'`.
    /// * Isicatshulwa esiphindwe kabini siyasinda njenge `\"`.
    /// * Ukubuyela umva kuphunyukile njenge-`\\`.
    /// * Nawuphi na umlinganiswa okwoluhlu 'oluprintiweyo lwe-ASCII' `0x20` .. `0x7e` ebandakanyayo ayibalekanga.
    /// * Bonke abanye abalinganiswa banikwa i-hexadecimal Unicode yokubaleka;bona i [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Njenge iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Zombini ziyalingana:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Sebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Ibuyisa inani lee-byte le `char` liya kuyidinga xa kufakwe ikhowudi kwi-UTF-8.
    ///
    /// Elo nani lee-byte lihlala liphakathi kuka-1 no-4.
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Uhlobo lwe `&str` luqinisekisa ukuba imixholo yayo yi UTF-8, kwaye ke sinokubuthelekisa ubude obuya kuthatha ukuba ikhowudi nganye imelwe njenge `char` vs kwi `&str` uqobo:
    ///
    ///
    /// ```
    /// // njengemoto
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // Zombini zinokumelwa njengee-byte ezintathu
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // njenge-&str, ezi zimbini zifakwe kwi-UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // siyabona ukuba bathatha ii-byte ezintandathu zizonke ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... njenge &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Ibuyisa inani leeyunithi zekhowudi ezingama-16-bit ezi `char` ziya kufuna ukuba zifakwe kwi UTF-16.
    ///
    ///
    /// Jonga amaxwebhu e [`len_utf8()`] ngolwazi oluthe kratya kolu luvo.
    /// Lo msebenzi sisipili, kodwa ngowama-UTF-16 endaweni ye UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Khowudibanisa olu phawu njengo-UTF-8 kwisikhuseli se-byte esinikiweyo, kwaye emva koko ubuyisele isihlomelo se-buffer esineempawu ezifakiweyo.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i-buffer ayinkulu ngokwaneleyo.
    /// Ubungakanani besiphelo sobude bukhulu banele ngokwaneleyo ukuba bunokukhowuda nayiphi na i `char`.
    ///
    /// # Examples
    ///
    /// Kuyo yomibini le mizekelo, i 'ß' ithatha ii-byte ezimbini zokufaka ikhowudi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Isithambisi esincinci kakhulu:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // UKHUSELEKO: I-`char` ayisiyomntu obambeleyo, ke le iyinyani eyi UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ifaka lo mlinganiswa njengo UTF-16 kwisikhuseli se `u16` esinikiweyo, kwaye emva koko ibuyisele umrhumo wesikhuseli sesikhombi esiqulathe uphawu olufakelweyo.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics ukuba i-buffer ayinkulu ngokwaneleyo.
    /// Isilinganisi sobude obude 2 sikhulu ngokwaneleyo ukuba singafaka ikhowudi kwi `char`.
    ///
    /// # Examples
    ///
    /// Kuyo yomibini le mizekelo, i '𝕊' ithatha ii-u``s ezimbini zokufaka ikhowudi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Isithambisi esincinci kakhulu:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Ibuyisa i `true` ukuba le `char` inepropathi ye `Alphabetic`.
    ///
    /// `Alphabetic` Ichaziwe kwiSahluko 4 (Iimpawu zeMpawu) ze [Unicode Standard] kwaye ichazwe kwi [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // Uthando zininzi izinto, kodwa alufakwanga ngokwealfabhethi
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Ibuyisa i `true` ukuba le `char` inepropathi ye `Lowercase`.
    ///
    /// `Lowercase` Ichaziwe kwiSahluko 4 (Iimpawu zeMpawu) ze [Unicode Standard] kwaye ichazwe kwi [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Izikripthi ezahlukeneyo zaseTshayina kunye neziphumlisi azinatyala, kwaye ke:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Ibuyisa i `true` ukuba le `char` inepropathi ye `Uppercase`.
    ///
    /// `Uppercase` Ichaziwe kwiSahluko 4 (Iimpawu zeMpawu) ze [Unicode Standard] kwaye ichazwe kwi [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Izikripthi ezahlukeneyo zaseTshayina kunye neziphumlisi azinatyala, kwaye ke:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Ibuyisa i `true` ukuba le `char` inepropathi ye `White_Space`.
    ///
    /// `White_Space` icacisiwe kwi [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // indawo engaphuli
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Ibuyisa i `true` ukuba le `char` yanelisa i [`is_alphabetic()`] okanye i [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Ibuyisa i `true` ukuba le X01 inodidi ngokubanzi lweekhowudi zolawulo.
    ///
    /// Iikhowudi zolawulo (amanqaku ekhowudi kunye nodidi oluqhelekileyo lwe-`Cc`) zichazwe kwiSahluko 4 (Iimpawu zeMpawu) ze [Unicode Standard] kwaye zichazwe kwi [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// // U + 009C, STRING UMLAWULI
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Ibuyisa i `true` ukuba le `char` inepropathi ye `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` Ichaziwe kwi [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] kwaye ichazwe kwi [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Ibuyisa i `true` ukuba le X01 inenye yeendidi ngokubanzi zamanani.
    ///
    /// Iindidi ngokubanzi zamanani (i-`Nd` yamanani okugqibela, i-`Nl` yoonobumba abanjengonobumba, kunye ne-`No` ngamanye amanani) zichaziwe kwi-[Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Usetyenziso olusisiseko:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Ibuyisa iterator evelisa imephu engaphantsi yale `char` njengenye okanye nangaphezulu
    /// `char`s.
    ///
    /// Ukuba le `char` ayinayo imephu engaphantsi, iterator ivelisa i `char` efanayo.
    ///
    /// Ukuba le `char` inemephu emfutshane yokuya kwenye inikwe yi [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator ivelisa i `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ukuba le `char` ifuna ukuthathelwa ingqalelo okhethekileyo (umz. Ezininzi `iichar`s) iiterator ivelisa i`char` (s) ezinikezwe yi [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Lo msebenzi wenza imephu engenamiqathango ngaphandle kokulungiswa.Oko kukuthi, uguquko luzimele kwimeko kunye nolwimi.
    ///
    /// Kwi-[Unicode Standard], Isahluko 4 (Iimpawu zeMpawu zoBuntu) sixoxa ngemephu ngokubanzi kwaye iSahluko 3 (Conformance) sixoxa ngealgorithm emiselweyo yokuguqula imeko.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Njenge iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Zombini ziyalingana:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Sebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Ngamanye amaxesha iziphumo ziba ngaphezu komlinganiswa omnye:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Abalinganiswa abangenazo zombini oonobumba abakhulu kunye nabancinci baguqukele kubo.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Ibuyisa i-iterator evelisa imephu engaphezulu yale `char` njengenye okanye ezingaphezulu
    /// `char`s.
    ///
    /// Ukuba le `char` ayinayo imephu ephezulu, iterator ivelisa i `char` efanayo.
    ///
    /// Ukuba le `char` inemephu yoonobumba abakhulu abanikwa yi [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator ivelisa i `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ukuba le `char` ifuna ukuthathelwa ingqalelo okhethekileyo (umz. Ezininzi `iichar`s) iiterator ivelisa i`char` (s) ezinikezwe yi [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Lo msebenzi wenza imephu engenamiqathango ngaphandle kokulungiswa.Oko kukuthi, uguquko luzimele kwimeko kunye nolwimi.
    ///
    /// Kwi-[Unicode Standard], Isahluko 4 (Iimpawu zeMpawu zoBuntu) sixoxa ngemephu ngokubanzi kwaye iSahluko 3 (Conformance) sixoxa ngealgorithm emiselweyo yokuguqula imeko.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Njenge iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Zombini ziyalingana:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Sebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Ngamanye amaxesha iziphumo ziba ngaphezu komlinganiswa omnye:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Abalinganiswa abangenazo zombini oonobumba abakhulu kunye nabancinci baguqukele kubo.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Qaphela kwindawo
    ///
    /// KwisiTurkey, elingana ne 'i' ngesiLatin ineefom ezintlanu endaweni ezimbini:
    ///
    /// * 'Dotless': Ndi/ı, ngamanye amaxesha kubhalwa ï
    /// * 'Dotted': İ/i
    ///
    /// Qaphela ukuba unobumba omncinci onamachaphaza we 'i' uyafana nesiLatin.Ke ngoko:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Ixabiso le `upper_i` apha lixhomekeke kulwimi lokubhaliweyo: ukuba sikwi `en-US`, kufanele ukuba ibengu `"I"`, kodwa ukuba sikwi `tr_TR`, kufanele ukuba ibengu `"İ"`.
    /// `to_uppercase()` ayikuthatheli ngqalelo oku, kwaye ke:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// ibamba iilwimi.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Jonga ukuba ixabiso liphakathi kuluhlu lwe-ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Yenza ikopi yexabiso kwi ASCII ephezulu yecala elilinganayo.
    ///
    /// Iileta ze-ASCII 'a' ukuya kwi 'z' zimiselwe imephu ukuya kwi 'A' ukuya kwi 'Z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukunyusa ixabiso endaweni, sebenzisa i [`make_ascii_uppercase()`].
    ///
    /// Ukwenza oonobumba abakhulu be ASCII ukongeza koonobumba abanga-ASCII, sebenzisa i [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Yenza ikopi yexabiso kwi ASCII esezantsi kwetyala elilinganayo.
    ///
    /// Iileta ze-ASCII 'A' ukuya kwi 'Z' zimiselwe imephu ukuya kwi 'a' ukuya kwi 'z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukuthoba ixabiso lendawo, sebenzisa i [`make_ascii_lowercase()`].
    ///
    /// Ukuhlisa oonobumba be-ASCII ukongeza koonobumba abanga-ASCII, sebenzisa i [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Jonga ukuba amaxabiso amabini yi-ASCII kwimeko yokungakhathali.
    ///
    /// Ilingana ne `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Guqula olu hlobo lube kwi-ASCII ephezulu yamatyala alinganayo endaweni.
    ///
    /// Iileta ze-ASCII 'a' ukuya kwi 'z' zimiselwe imephu ukuya kwi 'A' ukuya kwi 'Z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukubuyisa ixabiso elitsha elingasetyenziswanga ngaphandle kokuguqula esele ikho, sebenzisa i [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Guqula olu hlobo lube kwi-ASCII yamatyala asezantsi alinganayo endaweni.
    ///
    /// Iileta ze-ASCII 'A' ukuya kwi 'Z' zimiselwe imephu ukuya kwi 'a' ukuya kwi 'z', kodwa iileta ezingezo-ASCII azitshintshanga.
    ///
    /// Ukubuyisa ixabiso elitsha elisezantsi ngaphandle kokuguqula esele ikho, sebenzisa i [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Ukujonga ukuba ixabiso liimpawu ze-ASCII zealfabhethi:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', okanye
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Jonga ukuba ixabiso liphawu ASCII eliphezulu:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Ukujonga ukuba ixabiso liimpawu ze-ASCII ezisezantsi:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Ikhangela ukuba ixabiso li-ASCII alphanumeric character:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', okanye
    /// - U + 0061 'a' ..=U + 007A 'z', okanye
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Ikhangela ukuba ixabiso linani ledesimali ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Ukujonga ukuba ixabiso lilungu le-ASCII hexadecimal digit:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', okanye
    /// - U + 0041 'A' ..=U + 0046 'F', okanye
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Ikhangela ukuba ixabiso limpawu ASCII yeziphumlisi:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, okanye
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, okanye
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, okanye
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Ikhangela ukuba ixabiso liimpawu zomzobo we-ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Ukujonga ukuba ixabiso liimpawu ze-ASCII ezimhlophe:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C IFOMU YOKUFUNDA, okanye U + 000D UKUTHUTHA UKUBUYELA.
    ///
    /// I-Rust isebenzisa i [definition of ASCII whitespace][infra-aw] ye-infra standard ye-infra.Kukho ezinye iinkcazo ekusetyenzisweni ngokubanzi.
    /// Umzekelo, i-[the POSIX locale][pct] ibandakanya u-U + 000B VERTICAL TAB kunye nabo bonke oonobumba abangasentla, kodwa-kwayeyona nkcukacha inye- [umthetho ongagqibekanga we-"field splitting" kwi-Bourne shell][bfs] ithathela ingqalelo * kuphela ISITHUBA, ISIQINISEKISO SOMSEBENZI, kunye UMGANGATHO WOKUGQIBELA njengendawo emhlophe.
    ///
    ///
    /// Ukuba ubhala inkqubo eza kuqwalasela ifomathi yefayile esele ikhona, jonga ukuba yeyiphi na inkcazo yefomathi yendawo emhlophe ngaphambi kokusebenzisa lo msebenzi.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Ikhangela ukuba ixabiso liimpawu zolawulo lwe-ASCII:
    /// U + 0000 NUL ..=U + 001F SEPARATOR, okanye U + 007F DELETE.
    /// Qaphela ukuba uninzi lwe-ASCII abamhlophe abalinganiswa ngabalinganiswa abalawulayo, kodwa i-SPACE ayikho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Ifaka ikhowudi ye u32 eluhlaza njenge UTF-8 kwisikhuseli se-byte esinikiweyo, kwaye emva koko ibuyisele i-subslice ye-buffer equlathe uphawu lwekhowudi.
///
///
/// Ngokungafaniyo ne `char::encode_utf8`, le ndlela ikwajongana neepodepoints kuluhlu lwesivumelwano.
/// (Ukwenza i-`char` kuluhlu lwesivumelwano yi-UB.) Iziphumo ziyasebenza [generalized UTF-8] kodwa ayisebenzi UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// I-Panics ukuba i-buffer ayinkulu ngokwaneleyo.
/// Ubungakanani besiphelo sobude bukhulu banele ngokwaneleyo ukuba bunokukhowuda nayiphi na i `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Ifaka ikhowudi ye u32 eluhlaza njenge UTF-16 kwisikhuseli se `u16` esinikiweyo, kwaye emva koko ibuyisele isihluzi sesikhuseli esiqulathe uphawu olufakiweyo.
///
///
/// Ngokungafaniyo ne `char::encode_utf16`, le ndlela ikwajongana neepodepoints kuluhlu lwesivumelwano.
/// (Ukwenza i-`char` kuluhlu lwesivumelwano yi-UB.)
///
/// # Panics
///
/// I-Panics ukuba i-buffer ayinkulu ngokwaneleyo.
/// Isilinganisi sobude obude 2 sikhulu ngokwaneleyo ukuba singafaka ikhowudi kwi `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // UKHUSELEKO: ingalo nganye ijonga ukuba ngaba kukho iibits ezaneleyo zokubhalela
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // I-BMP iyawa
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Iinqwelomoya ezongezelelweyo zigqobhoza ezinye.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}