use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Le ayizinzanga indawo engaphezulu, kodwa iyanceda ukugcina i `?` ngexabiso eliphantsi phakathi kwabo, nokuba i-LLVM ayinakuhlala iyisebenzisa ngoku.
    //
    // (Iziphumo eziLusizi kunye noKhetho azingqinelani, ke uLawuloFlow alunakuthelekiswa zombini.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}