# Igalelo ku-stdarch

I `stdarch` crate ingaphezulu kokuzimisela ukwamkela igalelo!Kuqala uya kufuna ukukhangela indawo yokugcina izinto kwaye uqiniseke ukuba iimvavanyo ziyadlula:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Apho i-`<your-target-arch>` iphindwe kathathu ekujoliswe kuyo njengoko isetyenziswa yi-`rustup`, umz. `x86_x64-unknown-linux-gnu` (ngaphandle kwe-`nightly-` eyandulelayo okanye efanayo).
Kwakhona khumbula ukuba le ndawo yogcino ifuna itshaneli yobusuku ye Rust!
Ezi mvavanyo zingasentla zifuna ukuba i rust yasebusuku ibe yinto engagqibekanga kwinkqubo yakho, ukuseta loo nto usebenzisa i `rustup default nightly` (kunye ne `rustup default stable` ukubuyela umva).

Ukuba naliphi na kula manyathelo angentla alisebenzi, [please let us know][new]!

Emva koko unokwenza i-[find an issue][issues] ukunceda, sikhethe ezimbalwa nge-[`help wanted`][help] kunye ne-[`impl-period`][impl] tag ezinokuthi zisebenzise ngakumbi uncedo. 
Unokuba nomdla kakhulu kwi [#40][vendor], uphumeza yonke into engaphakathi yomthengisi kwi x86.Lo mbandela unezikhombisi ezilungileyo malunga nokuba ungaqala phi!

Ukuba unemibuzo ngokubanzi zive ukhululekile ukuya kwi [join us on gitter][gitter] kwaye ubuze ujikeleze!Zive ukhululekile ukubamba@BurntSushi okanye@alexcrichton ngemibuzo.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Uyibhala njani imizekelo ye-stdarch intrinsics

Kukho izinto ezimbalwa ekufuneka zenziwe ukuba ungene ngaphakathi ukuze usebenze kakuhle kwaye umzekelo kufuneka uqhutywe kuphela yi `cargo test --doc` xa inqaku lixhaswa yi-CPU.

Ngenxa yoko, i-`fn main` emiselweyo eyenziwe yi-`rustdoc` ayizukusebenza (kwiimeko ezininzi).
Cinga ukusebenzisa oku njengesikhokelo sokuqinisekisa ukuba umzekelo wakho usebenza njengoko kulindelwe.

```rust
/// # // Sifuna i-cfg_target_feature yokuqinisekisa ukuba umzekelo kuphela
/// # // iqhutywa yi `cargo test --doc` xa i-CPU ixhasa inqaku
/// # #![feature(cfg_target_feature)]
/// # // Sifuna ithagethi_yokujolisa ekusebenziseni okungaphakathi
/// # #![feature(target_feature)]
/// #
/// # // i-rustdoc ngokungagqibekanga isebenzisa i `extern crate stdarch`, kodwa siyayifuna
/// # // `#[macro_use]`
/// # # [macro_use] ngaphandle crate stdarch;
/// #
/// # // Owona msebenzi uphambili
/// # fn main() {
/// #     // Qhuba oku kuphela ukuba i `<target feature>` iyaxhaswa
/// #     ukuba i-cfg_bonisa_yenziwe ukuba isebenze! ("<target feature>"){
/// #         // Yenza umsebenzi we `worker` oya kuqhutywa kuphela ukuba into ekujolise kuyo
/// #         // iyaxhaswa kwaye iqinisekiswe ukuba i `target_feature` yenziwe ukuba isebenze
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         engakhuselekanga fn worker() {
/// // Bhala umzekelo wakho apha.Faka izinto ezithile zangaphakathi eziza kusebenza apha!Yiya endle!
///
/// #         }
///
/// #         engakhuselekanga i { worker(); }
/// #     }
/// # }
```

Ukuba ezinye zezi syntax zilapha ngasentla azibonakali ziqhelekile, icandelo le [Documentation as tests] le [Rust Book] lichaza is syntax se `rustdoc` kakuhle.
Njengesiqhelo, zive ukhululekile ukuya kwi-[join us on gitter][gitter] kwaye usibuze ukuba ubethe naziphi na izikhonkwane, kwaye enkosi ngokunceda ukuphucula amaxwebhu e `stdarch`!

# Imiyalelo yokuvavanya enye indlela

Kucetyiswa ngokubanzi ukuba usebenzise i `ci/run.sh` ukwenza iimvavanyo.
Nangona kunjalo oku akunakusebenzela, umzekelo, ukuba uku-Windows.

Kwimeko apho ungabuyela umva ekusebenzeni kwe `cargo +nightly test` kunye ne `cargo +nightly test --release -p core_arch` yokuvavanya ukuveliswa kwekhowudi.
Qaphela ukuba ezi zinto zifuna ukuba izixhobo zasebusuku zifakwe kwaye i-`rustc` yazi malunga nethagethi yakho ekujoliswe kuyo kathathu kunye ne-CPU yayo.
Ngokukodwa kufuneka usete i-`TARGET` umahluko kwimeko-bume njengoko ubunokuyenza kwi `ci/run.sh`.
Ukongeza kufuneka usete i `RUSTCFLAGS` (ufuna i `C`) ukubonisa amanqaku ekujolise kuwo, umz `RUSTCFLAGS="-C -target-features=+avx2"`.
Unokuseta i `-C -target-cpu=native` ukuba uyi "just" xa usiya kwi-CPU yakho yangoku.

Lumkiswa ukuba xa usebenzisa le eminye imiyalelo, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], umz
iimvavanyo zokuvelisa ukufundisa zinokusilela ngenxa yokuba disassembler ibathiye ngokwahlukileyo, umzekelo
inokuvelisa i `vaesenc` endaweni yemiyalelo ye `aesenc` ngaphandle kokuba beziphethe ngokufanayo.
Kananjalo le miyalelo yenza uvavanyo oluncinci kunokuba bekunokwenziwa ngokwesiqhelo, musa ukumangaliswa kukuba xa ekugqibeleni utsala isicelo-sakho iimpazamo zinokubonisa iimvavanyo ezingagutyungelwanga apha.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






