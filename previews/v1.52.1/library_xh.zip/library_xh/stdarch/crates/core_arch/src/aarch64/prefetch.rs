#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Jonga i [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Jonga i [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Jonga i [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Jonga i [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Jonga i [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Jonga i [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Landa umgca we-cache oqukethe i-`p` usebenzisa i-`rw` kunye ne-`locality`.
///
/// I `rw` kufuneka ibe yenye ye:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): i-prefetch ilungiselela ukufundwa.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): i-prefetch ilungiselela ukubhala.
///
/// I `locality` kufuneka ibe yenye ye:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Ukusasaza okanye ukungabikho okwethutyana, kwidatha esetyenziswa kube kanye.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Ngenisa kwinqanaba le-3 cache.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Ngenisa kwinqanaba le-2 cache.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Ngenisa kwinqanaba le-1 cache.
///
/// Isalathiso semiyalelo yokukhumbula kwangaphambili kwinkqubo yememori enokufikelela kwimemori kwidilesi echaziweyo kunokwenzeka ukuba yenzeke kufutshane ne future.
/// Inkqubo yememori ingaphendula ngokuthatha amanyathelo alindelweyo ukukhawulezisa ukufikelela kwimemori xa zisenzeka, njengokufaka kwakhona idilesi echaziweyo kwindawo enye okanye nangaphezulu.
///
/// Kungenxa yokuba le miqondiso ngamacebo kuphela, iyasebenza kwi-CPU ethile ukunyanga nayiphi na okanye yonke imiyalelo yokulungiselela kwangaphambili njenge-NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Sisebenzisa i-`llvm.prefetch` instrinsic nge `cache type` =1 (idatha efihlakeleyo).
    // `rw` kunye ne `strategy` isekwe kwiiparameter zomsebenzi.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}