`core::arch` - I-Rust eyona nto iphambili yokwakha ithala leencwadi
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Imodyuli ye `core::arch` isebenzisa izixhobo ezixhomekeke kuyilo (umz.

# Usage 

`core::arch` iyafumaneka njengenxalenye ye `libcore` kwaye iphinda ithunyelwe kwelinye ilizwe yi `libstd`.Khetha ukusebenzisa i `core::arch` okanye i `std::arch` kunale crate.
Iimpawu ezingazinzanga zihlala zifumaneka ngobusuku be Rust nge `feature(stdsimd)`.

Sebenzisa i `core::arch` ngale crate kufuna i-Rust yasebusuku, kwaye iyakwazi (kwaye iyenze) yaphule rhoqo.Ityala kuphela apho kuya kufuneka uthathele ingqalelo ukusebenzisa le crate zezi:

* ukuba ufuna ukuphinda uziqokelelele i `core::arch` ngokwakho, umzekelo, izinto ezithile ekujoliswe kuzo ezinikwe amandla ezingavumelekanga kwi `libcore`/`libstd`.
Note: ukuba ufuna ukuphinda uyiqokelele kwithagethi engaqhelekanga, nceda ukhethe ukusebenzisa i `xargo` kwaye uphinde wenze i `libcore`/`libstd` ngokufanelekileyo endaweni yokusebenzisa le crate.
  
* usebenzisa ezinye izinto ezinokuthi zingafumaneki nasemva kweempawu ezingazinzanga ze Rust.Sizama ukuzigcina zincinci.
Ukuba ufuna ukusebenzisa ezinye zezi zinto, nceda uvule umba ukuze siwazi ukuwubeka ebusuku Rust kwaye unokuzisebenzisa ukusuka apho.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` isasazwa ikakhulu phantsi kwemigaqo yelayisensi ye-MIT kunye nelayisensi ye-Apache (inguqulelo 2.0), eneenxalenye ezikhutshwe ziilayisensi ezinjenge-BSD.

Bona LICENSE-APACHE, kunye LICENSE-MIT iinkcukacha.

# Contribution

Ngaphandle kokuba uchaze ngenye indlela, nawuphi na umrhumo ongeniswe ngabom ukuze ufakwe kwi `core_arch` nguwe, njengoko kuchaziwe kwilayisenisi ye Apache-2.0, iya kuba nelayisensi ezimbini njengasentla, ngaphandle kwemiqathango okanye iimeko ezongezelelweyo.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












