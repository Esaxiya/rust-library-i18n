use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Sa a se pa zòn ki estab, men ede kenbe `?` bon mache ant yo, menm si LLVM pa ka toujou pran avantaj de li kounye a.
    //
    // (Malerezman Rezilta ak Opsyon yo konsistan, se konsa ControlFlow pa ka matche ak tou de.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}