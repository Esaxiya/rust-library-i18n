//! Kontenè ki kapab pataje.
//!
//! Rust sekirite memwa baze sou règ sa a: Bay yon objè `T`, li posib sèlman pou gen youn nan bagay sa yo:
//!
//! - Èske w gen plizyè referans imuiabl (`&T`) objè a (ke yo rele tou **alyas**).
//! - Èske w gen yon sèl referans mutable (`&mut T`) nan objè a (ke yo rele tou **mutabilite**).
//!
//! Sa a se ranfòse pa du a Rust.Sepandan, gen sitiyasyon kote règ sa a pa fleksib ase.Pafwa li oblije gen referans miltip nan yon objè e ankò mitasyon li.
//!
//! Kontenè ki ka pataje ki egziste yo pèmèt pèmèt yo chanje nan yon fason kontwole, menm nan prezans alyas.Tou de [`Cell<T>`] ak [`RefCell<T>`] pèmèt fè sa nan yon fason yon sèl-Threaded.
//! Sepandan, ni `Cell<T>` ni `RefCell<T>` pa gen fil (yo pa aplike [`Sync`]).
//! Si ou bezwen fè alyasman ak mitasyon ant fil miltip li posib yo sèvi ak [`Mutex<T>`], [`RwLock<T>`] oswa [`atomic`] kalite.
//!
//! Valè kalite `Cell<T>` ak `RefCell<T>` yo ka mitasyon nan referans pataje (sètadi
//! kalite `&T` komen an), tandiske pifò kalite Rust yo kapab sèlman mitasyon nan referans inik (`&mut T`).
//! Nou di ke `Cell<T>` ak `RefCell<T>` bay 'enteryè mutabilite', nan kontra ak tipik tip Rust ki montre 'eritye mutabilite'.
//!
//! Kalite selil yo vini nan de gou: `Cell<T>` ak `RefCell<T>`.`Cell<T>` aplike mutabilite enteryè pa deplase valè nan ak soti nan `Cell<T>` la.
//! Pou itilize referans olye pou yo valè, youn dwe itilize kalite a `RefCell<T>`, trape yon seri ekri anvan mitasyon.`Cell<T>` bay metòd pou rekipere ak chanje valè enteryè aktyèl la:
//!
//!  - Pou kalite ki aplike [`Copy`], metòd [`get`](Cell::get) rekipere valè enteryè aktyèl la.
//!  - Pou kalite ki aplike [`Default`], metòd [`take`](Cell::take) ranplase valè enteryè aktyèl la ak [`Default::default()`] epi retounen valè ranplase a.
//!  - Pou tout kalite, metòd [`replace`](Cell::replace) ranplase valè enteryè aktyèl la epi li retounen valè ranplase a epi metòd [`into_inner`](Cell::into_inner) la konsome `Cell<T>` epi li retounen valè enteryè a.
//!  Anplis de sa, metòd la [`set`](Cell::set) ranplase valè enteryè a, jete valè a ranplase.
//!
//! `RefCell<T>` sèvi ak lavi Rust a aplike 'dinamik prete', yon pwosesis kote yon moun ka fè reklamasyon pou yon ti tan, san konte, mitab aksè a valè enteryè a.
//! Prete pou `RefCell<T>`s Suivi 'nan ègzekutabl', kontrèman ak kalite referans natif natal Rust a ki fè yo konplètman Suivi statik, nan tan konpile.
//! Paske `RefCell<T>` prete yo dinamik li posib eseye prete yon valè ki deja mityèlman prete;lè sa rive li rezilta nan fil panic.
//!
//! # Lè yo chwazi mutabilite enteryè
//!
//! Plis komen eritye mutabilite a, kote youn dwe gen aksè inik nan mitasyon yon valè, se youn nan eleman yo lang kle ki pèmèt Rust rezone fòtman sou alyas konsèy, estatik anpeche pinèz aksidan.
//! Poutèt sa, eritye mutabilite pi pito, ak mutabilite enteryè se yon bagay nan yon dènye rekou.
//! Depi kalite selil pèmèt mitasyon kote li ta otreman dwe refize menm si, gen okazyon lè mutabilite enteryè ta ka apwopriye, oswa menm *dwe* dwe itilize, egzanp
//!
//! * Entwodwi mutabilite 'inside' nan yon bagay imuiabl
//! * Detay Aplikasyon nan metòd lojikman imuiabl.
//! * Mitasyon aplikasyon [`Clone`].
//!
//! ## Entwodwi mutabilite 'inside' nan yon bagay imuiabl
//!
//! Anpil pataje kalite konsèy entelijan, ki gen ladan [`Rc<T>`] ak [`Arc<T>`], bay resipyan ki ka klone epi pataje ant plizyè pati yo.
//! Paske valè ki genyen yo ka miltipliye-alyas, yo ka sèlman prete ak `&`, pa `&mut`.
//! San yo pa selil li ta enposib mitasyon done andedan nan sa yo endikasyon entelijan nan tout.
//!
//! Li trè komen Lè sa a, yo mete yon `RefCell<T>` andedan pataje kalite konsèy pou reenstwodui mutabilite:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Kreye yon nouvo blòk limite sijè ki abòde lan prete dinamik la
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Remake byen ke si nou pa t 'kite prete anvan an nan kachèt la tonbe soti nan dimansyon Lè sa a, prete ki vin apre a ta lakòz yon fil dinamik panic.
//!     //
//!     // Sa a se pi gwo danje lè l sèvi avèk `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Remake byen ke egzanp sa a itilize `Rc<T>` epi yo pa `Arc<T>`.`RefCell<T>`s yo pou senaryo sèl-Threaded.Konsidere lè l sèvi avèk [`RwLock<T>`] oswa [`Mutex<T>`] si ou bezwen pataje mutabilite nan yon sitiyasyon milti-Threaded.
//!
//! ## Detay Aplikasyon nan metòd lojikman imuiabl
//!
//! Okazyonèlman li ka dezirab pa ekspoze nan yon API ke gen mitasyon k ap pase "under the hood".
//! Sa a pouvwa ap paske lojikman operasyon an se imuiabl, men egzanp, caching fòs aplikasyon an fè mitasyon;oswa paske ou dwe anplwaye mitasyon pou aplike yon metòd trait ki te orijinèlman defini pou pran `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Chè kalkil ale isit la
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mitasyon aplikasyon `Clone`
//!
//! Sa a se tou senpleman yon espesyal, men komen, ka nan anvan an: kache mutabilite pou operasyon ki parèt yo dwe imuiabl.
//! Metòd [`clone`](Clone::clone) espere pa chanje valè sous la, e li te deklare pou pran `&self`, pa `&mut self`.
//! Se poutèt sa, nenpòt mitasyon ki k ap pase nan metòd la `clone` dwe itilize kalite selil yo.
//! Pou egzanp, [`Rc<T>`] kenbe konte referans li yo nan yon `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Yon kote memwa mitab.
///
/// # Examples
///
/// Nan egzanp sa a, ou ka wè ke `Cell<T>` pèmèt mitasyon andedan yon struct imuiabl.
/// Nan lòt mo, li pèmèt "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERÈ: `my_struct` se imuiabl
/// // my_struct.regular_field =nouvo_valè;
///
/// // TRAVAY: byenke `my_struct` se imuiabl, `special_field` se yon `Cell`,
/// // ki ka toujou mitasyon
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Gade [module-level documentation](self) la pou plis.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Kreye yon `Cell<T>`, ak valè `Default` pou T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Kreye yon nouvo `Cell` ki gen valè yo bay la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Mete valè ki genyen an.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Echanj valè de selil yo.
    /// Diferans ak `std::mem::swap` se ke fonksyon sa a pa mande pou `&mut` referans.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SEKIRITE: Sa a ka riske si yo rele nan fil separe, men `Cell`
        // se `!Sync` konsa sa pap rive.
        // Sa a tou pa pral invalid okenn endikasyon depi `Cell` asire w ke pa gen anyen lòt bagay yo pral montre nan youn nan sa yo `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Ranplase valè ki genyen ak `val`, epi retounen ansyen valè ki genyen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SEKIRITE: Sa ka lakòz ras done si yo rele nan yon fil apa,
        // men `Cell` se `!Sync` konsa sa pap rive.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Dekouvwi valè a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Retounen yon kopi valè ki genyen an.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SEKIRITE: Sa ka lakòz ras done si yo rele nan yon fil apa,
        // men `Cell` se `!Sync` konsa sa pap rive.
        unsafe { *self.value.get() }
    }

    /// Mizajou valè ki genyen an lè l sèvi avèk yon fonksyon epi retounen nouvo valè a.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Retounen yon konsèy anvan tout koreksyon nan done ki kache nan selil sa a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Retounen yon referans ki ka chanje nan done ki kache yo.
    ///
    /// Apèl sa a prete `Cell` mutably (nan konpile-tan) ki garanti ke nou posede referans la sèlman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Retounen yon `&Cell<T>` ki sòti nan yon `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SEKIRITE: `&mut` asire aksè inik.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Pran valè selil la, kite `Default::default()` nan plas li.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Retounen yon `&[Cell<T>]` ki sòti nan yon `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SEKIRITE: `Cell<T>` gen menm layout memwa ak `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Yon kote memwa mitab ak règ dinamik tcheke prete
///
/// Gade [module-level documentation](self) la pou plis.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Yon erè retounen pa [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Yon erè retounen pa [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Valè pozitif reprezante kantite `Ref` aktif.Valè negatif reprezante kantite `RefMut` aktif.
// Miltip `RefMut`s kapab sèlman aktif nan yon moman si yo refere a distenk, nonoverlapping eleman nan yon `RefCell` (egzanp, chenn diferan nan yon tranch).
//
// `Ref` ak `RefMut` yo tou de se de mo nan gwosè, e konsa ap gen chans pou pa janm gen ase `Ref` oswa `RefMut`s nan egzistans debòde mwatye nan seri a `usize`.
// Se konsa, yon `BorrowFlag` ap pwobableman pa janm debòde oswa debòde.
// Sepandan, sa a se pa yon garanti, kòm yon pwogram pathologie te kapab repete kreye ak Lè sa a, mem::forget `Ref` oswa `RefMut`s.
// Se konsa, tout kòd dwe klèman tcheke pou debòde ak debòde yo nan lòd pou fè pou evite ensekirite, oswa omwen konpòte yo kòrèkteman nan evènman an ki debòde oswa debòde rive (egzanp, gade BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Kreye yon nouvo `RefCell` ki gen `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Konsome `RefCell` la, retounen valè a vlope.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Depi fonksyon sa a pran `self` (`RefCell` la) pa valè, du a statikman verifye ke li pa kounye a prete.
        //
        self.value.into_inner()
    }

    /// Ranplase valè a vlope ak yon nouvo, retounen valè a fin vye granmoun, san yo pa deinitializing swa youn.
    ///
    ///
    /// Fonksyon sa a koresponn ak [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics si valè a se kounye a prete.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Ranplase valè a vlope ak yon nouvo calculé soti nan `f`, retounen valè a fin vye granmoun, san yo pa deinitializing swa youn.
    ///
    ///
    /// # Panics
    ///
    /// Panics si valè a se kounye a prete.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Swaps valè a vlope nan `self` ak valè a vlope nan `other`, san yo pa deinitializing swa youn.
    ///
    ///
    /// Fonksyon sa a koresponn ak [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics si valè a nan swa `RefCell` se kounye a prete.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutable prete valè a vlope.
    ///
    /// Prete a dire jiskaske retounen `Ref` la sòti sijè ki abòde lan.
    /// Plizyè imuiabl prete ka pran an menm tan an.
    ///
    /// # Panics
    ///
    /// Panics si valè a se kounye a mityèlman prete.
    /// Pou yon Variant ki pa panike, sèvi ak [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Yon egzanp panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutableman prete valè a vlope, retounen yon erè si valè a se kounye a mutableman prete.
    ///
    ///
    /// Prete a dire jiskaske retounen `Ref` la sòti sijè ki abòde lan.
    /// Plizyè imuiabl prete ka pran an menm tan an.
    ///
    /// Sa a se Variant ki pa panike nan [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SEKIRITE: `BorrowRef` asire ke gen sèlman aksè imuiabl
            // valè a pandan y ap prete.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mityèlman prete valè a vlope.
    ///
    /// Prete a dire jiskaske `RefMut` a retounen oswa tout `RefMut` sòti nan li sòti dimansyon.
    ///
    /// Valè a pa ka prete pandan ke prete sa a aktif.
    ///
    /// # Panics
    ///
    /// Panics si valè a se kounye a prete.
    /// Pou yon Variant ki pa panike, sèvi ak [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Yon egzanp panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mityèlman prete valè a vlope, retounen yon erè si valè a se kounye a prete.
    ///
    ///
    /// Prete a dire jiskaske `RefMut` a retounen oswa tout `RefMut` sòti nan li sòti dimansyon.
    /// Valè a pa ka prete pandan ke prete sa a aktif.
    ///
    /// Sa a se Variant ki pa panike nan [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SEKIRITE: `BorrowRef` garanti aksè inik.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Retounen yon konsèy anvan tout koreksyon nan done ki kache nan selil sa a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Retounen yon referans ki ka chanje nan done ki kache yo.
    ///
    /// Apèl sa a prete `RefCell` mutably (nan konpile-tan) Se konsa, pa gen okenn bezwen pou chèk dinamik.
    ///
    /// Sepandan pran prekosyon: metòd sa a espere `self` yo ka chanje, ki se jeneralman pa ka a lè w ap itilize yon `RefCell`.
    ///
    /// Pran yon gade nan metòd la [`borrow_mut`] olye si `self` pa chanje.
    ///
    /// Epitou, tanpri dwe konnen ke metòd sa a se sèlman pou sikonstans espesyal epi anjeneral se pa sa ou vle.
    /// Nan ka dout, sèvi ak [`borrow_mut`] olye.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Defèt efè a nan fwit gad sou eta a prete nan `RefCell` la.
    ///
    /// Apèl sa a sanble ak [`get_mut`] men li pi espesyalize.
    /// Li prete `RefCell` mutably asire pa gen okenn prete egziste ak Lè sa a retabli swiv eta a pataje prete.
    /// Sa a enpòtan si kèk `Ref` oswa `RefMut` prete yo te fwit.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutableman prete valè a vlope, retounen yon erè si valè a se kounye a mutableman prete.
    ///
    /// # Safety
    ///
    /// Kontrèman ak `RefCell::borrow`, metòd sa a pa an sekirite paske li pa retounen yon `Ref`, kidonk kite drapo a prete intact.
    /// Mityèlman prete `RefCell` la pandan y ap referans la retounen pa metòd sa a vivan se konpòtman endefini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SEKIRITE: Nou tcheke ke pèsonn pa aktivman ekri kounye a, men se vre
            // responsablite moun kap rele a pou asire ke pèsonn pa ekri jiskaske referans retounen an pa itilize ankò.
            // Epitou, `self.value.get()` refere a valè posede pa `self` e konsa garanti yo valab pou tout lavi `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Pran valè a vlope, kite `Default::default()` nan plas li.
    ///
    /// # Panics
    ///
    /// Panics si valè a se kounye a prete.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics si valè a se kounye a mityèlman prete.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Kreye yon `RefCell<T>`, ak valè `Default` pou T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics si valè a nan swa `RefCell` se kounye a prete.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics si valè a nan swa `RefCell` se kounye a prete.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics si valè a nan swa `RefCell` se kounye a prete.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si valè a nan swa `RefCell` se kounye a prete.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si valè a nan swa `RefCell` se kounye a prete.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si valè a nan swa `RefCell` se kounye a prete.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics si valè a nan swa `RefCell` se kounye a prete.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Ogmante prete ka rezilta nan yon valè ki pa lekti (<=0) nan ka sa yo:
            // 1. Li te <0, sa vle di gen ekri prete, kidonk nou pa ka pèmèt yon li prete akòz referans alyozman Rust a règ
            // 2.
            // Li te isize::MAX (kantite lajan maksimòm nan lekti prete) epi li debòde nan isize::MIN (kantite lajan maksimòm nan ekri prete) pou nou pa ka pèmèt yon lekti anplis prete paske isize pa ka reprezante anpil li prete (sa ka rive sèlman si ou mem::forget plis pase yon ti kantite konstan nan `Ref`s, ki se pa bon pratik)
            //
            //
            //
            //
            None
        } else {
            // Ogmante prete ka rezilta nan yon valè lekti (> 0) nan ka sa yo:
            // 1. Li te=0, sa vle di li pa te prete, epi n ap pran premye li a prete
            // 2. Li te> 0 ak <isize::MAX, sa vle di
            // te gen prete li, ak isize se gwo ase yo reprezante gen yon sèl plis prete li
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Depi Ref sa a egziste, nou konnen drapo a prete se yon lekti prete.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Anpeche kontwa an prete debòde nan yon ekri prete.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Vlope yon referans prete nan yon valè nan yon bwat `RefCell`.
/// Yon kalite pakè pou yon valè immutableman prete ki sòti nan yon `RefCell<T>`.
///
/// Gade [module-level documentation](self) la pou plis.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopi yon `Ref`.
    ///
    /// `RefCell` la deja immutably prete, kidonk sa a pa ka febli.
    ///
    /// Sa a se yon fonksyon ki asosye ki bezwen itilize kòm `Ref::clone(...)`.
    /// Yon aplikasyon `Clone` oswa yon metòd ta entèfere ak itilizasyon toupatou nan `r.borrow().clone()` klonaj sa ki nan yon `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Fè yon nouvo `Ref` pou yon eleman nan done yo prete.
    ///
    /// `RefCell` la deja immutably prete, kidonk sa a pa ka febli.
    ///
    /// Sa a se yon fonksyon ki asosye ki bezwen itilize kòm `Ref::map(...)`.
    /// Yon metòd ta entèfere ak metòd an menm non yo sou sa ki nan yon `RefCell` itilize nan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Fè yon nouvo `Ref` pou yon eleman si ou vle nan done yo prete.
    /// Se gad orijinal la retounen kòm yon `Err(..)` si fèmti a retounen `None`.
    ///
    /// `RefCell` la deja immutably prete, kidonk sa a pa ka febli.
    ///
    /// Sa a se yon fonksyon ki asosye ki bezwen itilize kòm `Ref::filter_map(...)`.
    /// Yon metòd ta entèfere ak metòd an menm non yo sou sa ki nan yon `RefCell` itilize nan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Divize yon `Ref` nan plizyè `Ref`s pou eleman diferan nan done yo prete.
    ///
    /// `RefCell` la deja immutably prete, kidonk sa a pa ka febli.
    ///
    /// Sa a se yon fonksyon ki asosye ki bezwen itilize kòm `Ref::map_split(...)`.
    /// Yon metòd ta entèfere ak metòd an menm non yo sou sa ki nan yon `RefCell` itilize nan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Konvèti nan yon referans a done ki kache yo.
    ///
    /// Kache `RefCell` la pa janm ka mutableman prete nan men ankò epi li ap toujou parèt deja imuiablman prete.
    ///
    /// Li se pa yon bon lide yo koule plis pase yon nimewo konstan nan referans.
    /// `RefCell` la ka immutableman prete ankò si se sèlman yon pi piti kantite fwit ki te fèt nan total.
    ///
    /// Sa a se yon fonksyon ki asosye ki bezwen itilize kòm `Ref::leak(...)`.
    /// Yon metòd ta entèfere ak metòd an menm non yo sou sa ki nan yon `RefCell` itilize nan `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Pa bliye Ref sa a nou asire ke kontwa an prete nan RefCell a pa ka tounen nan UNUSED nan tout lavi `'b` la.
        // Reyajiste eta a swiv referans ta mande pou yon referans inik nan RefCell a prete.
        // Pa gen lòt referans ki ka chanje nan selil orijinal la.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Fè yon nouvo `RefMut` pou yon eleman nan done yo prete, egzanp, yon Variant enum.
    ///
    /// `RefCell` la deja mityèlman prete, kidonk sa pa ka febli.
    ///
    /// Sa a se yon fonksyon ki asosye ki bezwen itilize kòm `RefMut::map(...)`.
    /// Yon metòd ta entèfere ak metòd an menm non yo sou sa ki nan yon `RefCell` itilize nan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ranje prete-chèk la
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Fè yon nouvo `RefMut` pou yon eleman si ou vle nan done yo prete.
    /// Se gad orijinal la retounen kòm yon `Err(..)` si fèmti a retounen `None`.
    ///
    /// `RefCell` la deja mityèlman prete, kidonk sa pa ka febli.
    ///
    /// Sa a se yon fonksyon ki asosye ki bezwen itilize kòm `RefMut::filter_map(...)`.
    /// Yon metòd ta entèfere ak metòd an menm non yo sou sa ki nan yon `RefCell` itilize nan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ranje prete-chèk la
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SEKIRITE: fonksyon kenbe sou yon referans san konte pou dire a
        // nan apèl li yo nan `orig`, ak konsèy la se sèlman de-referans andedan nan apèl la fonksyon pa janm pèmèt referans a san konte yo sove.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SEKIRITE: menm jan ak pi wo a.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Divize yon `RefMut` nan plizyè `RefMut`s pou eleman diferan nan done yo prete.
    ///
    /// `RefCell` ki kache a ap rete mutably prete jiskaske tou de retounen `RefMut`s ale soti nan sijè ki abòde lan.
    ///
    /// `RefCell` la deja mityèlman prete, kidonk sa pa ka febli.
    ///
    /// Sa a se yon fonksyon ki asosye ki bezwen itilize kòm `RefMut::map_split(...)`.
    /// Yon metòd ta entèfere ak metòd an menm non yo sou sa ki nan yon `RefCell` itilize nan `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Konvèti nan yon referans mutable nan done ki kache.
    ///
    /// `RefCell` ki kache a pa ka prete nan men ankò epi li ap toujou parèt deja mityèlman prete, sa ki fè referans retounen an sèlman nan enteryè a.
    ///
    ///
    /// Sa a se yon fonksyon ki asosye ki bezwen itilize kòm `RefMut::leak(...)`.
    /// Yon metòd ta entèfere ak metòd an menm non yo sou sa ki nan yon `RefCell` itilize nan `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Pa bliye sa a BorrowRefMut nou asire ke kontè an prete nan RefCell a pa ka tounen nan inutilize nan tout lavi `'b` la.
        // Reyajiste eta a swiv referans ta mande pou yon referans inik nan RefCell a prete.
        // Pa gen okenn referans plis ka kreye nan selil orijinal la nan lavi sa a, ki fè aktyèl la prete referans a sèlman pou tout lavi ki rete a.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Kontrèman ak BorrowRefMut::clone, nouvo yo rele yo kreye inisyal la
        // referans mutable, e konsa dwe aktyèlman pa gen okenn referans ki egziste deja.
        // Se konsa, pandan y ap script ogmante refcount a mitab, isit la nou klèman pèmèt sèlman ale soti nan UNUSED a UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klon yon `BorrowRefMut`.
    //
    // Sa a valab sèlman si yo itilize chak `BorrowRefMut` pou swiv yon referans ki ka chanje nan yon seri distenk, ki pa sipèpoze nan objè orijinal la.
    //
    // Sa a se pa nan yon klonaj impl pou ke kòd pa rele sa a enplisitman.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Anpeche kontwa an prete soti nan underflowing.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Yon kalite anbalaj pou yon valè mityèlman prete ki sòti nan yon `RefCell<T>`.
///
/// Gade [module-level documentation](self) la pou plis.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Primitif debaz la pou mutabilite enteryè nan Rust.
///
/// Si ou gen yon `&T` referans, Lè sa a, nòmalman nan Rust du a fè optimize ki baze sou konesans ke `&T` pwen done imuiabl.Mitasyon done sa yo, pou egzanp atravè yon alyas oswa pa transmutasyon yon `&T` nan yon `&mut T`, konsidere kòm konpòtman endefini.
/// `UnsafeCell<T>` opts-soti nan garanti a imuiabilite pou `&T`: yon referans pataje `&UnsafeCell<T>` ka pwen nan done ke yo te mitasyon.Yo rele sa "interior mutability".
///
/// Tout lòt kalite ki pèmèt mutabilite entèn yo, tankou `Cell<T>` ak `RefCell<T>`, anndan itilize `UnsafeCell` pou vlope done yo.
///
/// Remake byen ke se sèlman garanti a imuiabilite pou referans pataje ki afekte nan `UnsafeCell`.Garanti singularité pou referans ki pa chanje yo pa afekte.Pa gen *okenn* fason legal pou jwenn alyas `&mut`, pa menm avèk `UnsafeCell<T>`.
///
/// `UnsafeCell` API nan tèt li se teknikman trè senp: [`.get()`] ba ou yon `*mut T` konsèy kri nan sa li yo.Li se jiska _you_ kòm designer nan distraksyon yo sèvi ak ki konsèy kri kòrèkteman.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Règ egzak Rust alyasman yo yon ti jan nan flux, men pwen prensipal yo pa kontwovèsyal:
///
/// - Si ou kreye yon referans san danje ak tout lavi `'a` (swa yon referans `&T` oswa `&mut T`) ki aksesib pa kòd san danje (pou egzanp, paske ou te retounen li), lè sa a ou pa dwe jwenn aksè nan done yo nan okenn fason ki kontredi referans sa a pou rès la. nan `'a`.
/// Pou egzanp, sa vle di ke si ou pran `*mut T` a soti nan yon `UnsafeCell<T>` ak jete li nan yon `&T`, Lè sa a, done yo nan `T` dwe rete imuiabl (modulo nenpòt done `UnsafeCell` yo te jwenn nan `T`, nan kou) jiskaske lavi referans sa a ekspire.
/// Menm jan an tou, si ou kreye yon referans `&mut T` ki lage nan kòd san danje, Lè sa a, ou pa dwe jwenn aksè nan done yo nan `UnsafeCell` la jiskaske referans sa a ekspire.
///
/// - Tout tan, ou dwe evite ras done.Si fil miltip gen aksè a `UnsafeCell` a menm, Lè sa a, nenpòt ki ekri dwe gen yon bon k ap pase-anvan relasyon ak tout lòt aksè (oswa itilize atomik).
///
/// Pou ede ak konsepsyon apwopriye, senaryo sa yo yo klèman deklare legal pou yon sèl-Threaded kòd:
///
/// 1. Yon referans `&T` ka lage nan kòd san danje epi gen li ka ko-egziste ak lòt referans `&T`, men se pa ak yon `&mut T`
///
/// 2. Yon referans `&mut T` ka lage nan kòd san danje bay ni lòt `&mut T` ni `&T` ko-egziste avèk li.Yon `&mut T` dwe toujou inik.
///
/// Remake byen ke tou mitasyon sa ki nan yon `&UnsafeCell<T>` (menm pandan ke lòt referans `&UnsafeCell<T>` alyas selil la) se ok (bay ou ranfòse envariants ki anwo yo kèk lòt fason), li toujou konpòtman endefini gen plizyè alyoz `&mut UnsafeCell<T>`.
/// Sa vle di, `UnsafeCell` se yon pakè ki fèt pou gen yon entèraksyon espesyal ak _shared_ accesses (_i.e._, atravè yon referans `&UnsafeCell<_>`);pa gen okenn maji tou lè w ap fè fas ak _exclusive_ accesses (_e.g._, atravè yon `&mut UnsafeCell<_>`): ni selil la, ni valè a vlope yo ka alyas pou dire a ki `&mut` prete.
///
/// Sa a se ekspoze pa accessor a [`.get_mut()`], ki se yon _safe_ getter ki bay yon `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Isit la se yon egzanp èkspoze ki jan yo sensèman mitasyon sa ki nan yon `UnsafeCell<_>` malgre gen plizyè referans alyas selil la:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Jwenn referans miltip/pataje nan menm `x` la.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SEKIRITE: nan sijè sa a pa gen okenn lòt referans sou sa "x" a,
///     // konsa nou efektivman inik.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- prete-+
///     *p1_exclusive += 27; // |
/// } // <---------- pa ka ale pi lwen pase pwen sa a -------------------+
///
/// unsafe {
///     // SEKIRITE: nan dimansyon sa a pèsonn pa espere gen aksè eksklizif a sa x,
///     // pou nou ka gen plizyè aksè pataje an menm tan.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Egzanp sa a montre lefèt ke aksè eksklizif nan yon `UnsafeCell<T>` implique aksè eksklizif nan `T` li yo:
///
/// ```rust
/// #![forbid(unsafe_code)] // ak aksè san konte,
///                         // `UnsafeCell` se yon vlope transparan pa gen okenn op, kidonk pa bezwen `unsafe` isit la.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Jwenn yon konpile-tan-tcheke referans inik nan `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Avèk yon referans san konte, nou ka mitasyon sa ki gratis.
/// *p_unique.get_mut() = 0;
/// // Oswa, ekivalan:
/// x = UnsafeCell::new(0);
///
/// // Lè nou posede valè a, nou ka ekstrè sa ki gratis.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Konstwi yon nouvo egzanp nan `UnsafeCell` ki pral vlope valè a espesifye.
    ///
    ///
    /// Tout aksè nan valè enteryè a nan metòd se `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Dekouvwi valè a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Jwenn yon konsèy mutable nan valè a vlope.
    ///
    /// Sa a ka jete nan yon konsèy nenpòt kalite.
    /// Asire ke aksè a se inik (pa gen okenn referans aktif, mitab oswa ou pa) lè Distribisyon nan `&mut T`, epi asire ke pa gen okenn mitasyon oswa alyas mutabl ale sou lè Distribisyon nan `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Nou ka jis jete konsèy la soti nan `UnsafeCell<T>` `T` paske nan #[repr(transparent)].
        // Sa a eksplwate estati espesyal libstd a, pa gen okenn garanti pou kòd itilizatè ke sa a ap travay nan vèsyon future nan du a!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Retounen yon referans ki ka chanje nan done ki kache yo.
    ///
    /// Apèl sa a prete `UnsafeCell` la mutably (nan konpile-tan) ki garanti ke nou posede referans la sèlman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Jwenn yon konsèy mutable nan valè a vlope.
    /// Diferans lan nan [`get`] se ke fonksyon sa a aksepte yon konsèy anvan tout koreksyon, ki se itil pou fè pou evite kreyasyon an referans tanporè.
    ///
    /// Rezilta a ka jete nan yon konsèy nenpòt kalite.
    /// Asire ke aksè a se inik (pa gen okenn referans aktif, mitab oswa ou pa) lè Distribisyon nan `&mut T`, epi asire ke pa gen okenn mitasyon oswa alyas mutabl ale sou lè Distribisyon nan `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Inisyalizasyon gradyèl nan yon `UnsafeCell` mande pou `raw_get`, menm jan rele `get` ta mande pou kreye yon referans a done inisyalize:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Nou ka jis jete konsèy la soti nan `UnsafeCell<T>` `T` paske nan #[repr(transparent)].
        // Sa a eksplwate estati espesyal libstd a, pa gen okenn garanti pou kòd itilizatè ke sa a ap travay nan vèsyon future nan du a!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Kreye yon `UnsafeCell`, ak valè `Default` pou T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}