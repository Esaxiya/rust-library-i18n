//! Fonksyonalite pou kòmann-nan ak konparezon.
//!
//! Modil sa a gen divès zouti pou kòmann-nan ak konpare valè.An rezime:
//!
//! * [`Eq`] ak [`PartialEq`] yo se traits ki pèmèt ou defini egalite total ak pasyèl ant valè, respektivman.
//! Aplike yo surcharge operatè yo `==` ak `!=`.
//! * [`Ord`] ak [`PartialOrd`] yo se traits ki pèmèt ou defini kòmann total ak pasyèl ant valè, respektivman.
//!
//! Aplike yo surcharge operatè yo `<`, `<=`, `>`, ak `>=`.
//! * [`Ordering`] se yon enum retounen pa fonksyon prensipal yo nan [`Ord`] ak [`PartialOrd`], epi dekri yon kòmann-nan.
//! * [`Reverse`] se yon struct ki pèmèt ou fasilman ranvèse yon kòmann-nan.
//! * [`max`] ak [`min`] yo se fonksyon ki bati nan [`Ord`] ak pèmèt ou jwenn maksimòm la oswa minimòm de valè.
//!
//! Pou plis detay, gade dokiman respektif chak atik nan lis la.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait pou konparezon egalite ki se [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// trait sa a pèmèt egalite pasyèl, pou kalite ki pa gen yon relasyon ekivalans konplè.
/// Pou egzanp, nan nimewo pwen k ap flote `NaN != NaN`, se konsa kalite pwen k ap flote aplike `PartialEq` men se pa [`trait@Eq`].
///
/// Fòmèlman, egalite a dwe (pou tout `a`, `b`, `c` nan kalite `A`, `B`, `C`):
///
/// - **Simetrik**: si `A: PartialEq<B>` ak `B: PartialEq<A>`, lè sa a **`a==b` implique`b==a`**;ak
///
/// - **Tranzitif**: si `A: PartialEq<B>` ak `B: PartialEq<C>` ak `A:
///   PartialEq<C>`, Lè sa a,**` a==b`ak `b == c` implique`a==c`**.
///
/// Remake byen ke `B: PartialEq<A>` (symmetric) ak `A: PartialEq<C>` (transitive) impls yo pa fòse yo egziste, men kondisyon sa yo aplike chak fwa yo egziste.
///
/// ## Derivable
///
/// trait sa a ka itilize ak `#[derive]`.Lè `derive`d sou structs, de ka yo egal si tout jaden yo egal, epi yo pa egal si nenpòt jaden yo pa egal.Lè `derive`d sou enums, chak Variant ki egal a tèt li epi li pa egal a lòt variantes yo.
///
/// ## Kouman mwen ka aplike `PartialEq`?
///
/// `PartialEq` sèlman mande pou metòd [`eq`] a aplike;[`ne`] defini an tèm de li pa default.Nenpòt aplikasyon manyèl nan [`ne`]*dwe* respekte règ la ki [`eq`] se yon envès strik nan [`ne`];se sa ki, `!(a == b)` si epi sèlman si `a != b`.
///
/// Aplikasyon `PartialEq`, [`PartialOrd`], ak [`Ord`]*dwe* dakò youn ak lòt.Li fasil pou aksidantèlman fè yo pa dakò pa sòti kèk nan traits la ak manyèlman aplike lòt moun.
///
/// Yon egzanp aplikasyon pou yon domèn nan ki de liv yo konsidere menm liv la si ISBN yo matche ak, menm si fòma yo diferan:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Kouman mwen ka konpare de diferan kalite?
///
/// Kalite ou ka konpare ak kontwole pa paramèt kalite `PartialEq`.
/// Pou egzanp, kite a ajiste kòd anvan nou yon ti jan:
///
/// ```
/// // Derive a aplike<BookFormat>==<BookFormat>konparezon
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Aplike<Book>==<BookFormat>konparezon
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Aplike<BookFormat>==<Book>konparezon
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Lè nou chanje `impl PartialEq for Book` pou `impl PartialEq<BookFormat> for Book`, nou pèmèt `BookFormat` yo konpare ak`Book`s.
///
/// Yon konparezon tankou yon sèl ki anwo a, ki inyore kèk jaden nan struct la, ka danjere.Li ka fasilman mennen nan yon vyolasyon entansyonel nan kondisyon yo pou yon relasyon ekivalans pasyèl.
/// Pou egzanp, si nou kenbe aplikasyon an pi wo a `PartialEq<Book>` pou `BookFormat` epi ajoute yon aplikasyon nan `PartialEq<Book>` pou `Book` (swa atravè yon `#[derive]` oswa atravè aplikasyon an manyèl soti nan premye egzanp lan) Lè sa a, rezilta a ta vyole transitivite:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Metòd sa a tès pou `self` ak `other` valè yo dwe egal, epi li se itilize pa `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Metòd sa a teste pou `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Rive macro génération yon impl nan trait `PartialEq` la.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait pou konparezon egalite ki se [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Sa vle di, nan adisyon a `a == b` ak `a != b` yo te envès strik, egalite a dwe (pou tout `a`, `b` ak `c`):
///
/// - reflexive: `a == a`;
/// - simetrik: `a == b` implique `b == a`;ak
/// - tranzitif: `a == b` ak `b == c` implique `a == c`.
///
/// Pwopriyete sa a pa ka tcheke pa du a, ak Se poutèt sa `Eq` implique [`PartialEq`], e li pa gen okenn metòd siplemantè.
///
/// ## Derivable
///
/// trait sa a ka itilize ak `#[derive]`.
/// Lè `derive`d, paske `Eq` pa gen okenn metòd siplemantè, li sèlman enfòme du a ke sa a se yon relasyon ekivalans olye ke yon relasyon ekivalans pasyèl.
///
/// Remake byen ke estrateji `derive` la mande pou tout jaden yo se `Eq`, ki pa toujou vle.
///
/// ## Kouman mwen ka aplike `Eq`?
///
/// Si ou pa kapab itilize estrateji `derive` la, presize ke kalite ou aplike `Eq`, ki pa gen okenn metòd:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // metòd sa a itilize sèlman pa#[derive] pou revandike ke chak eleman nan yon kalite aplike#[derive] tèt li, enfrastrikti aktyèl dérive vle di fè deklarasyon sa a san yo pa itilize yon metòd sou sa a trait se prèske enposib.
    //
    //
    // Sa pa ta dwe janm aplike alamen.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Rive macro génération yon impl nan trait `Eq` la.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: struct sa a itilize sèlman pa#[derive] to
// afime ke chak eleman nan yon kalite aplike ek.
//
// Struct sa a pa ta dwe janm parèt nan kòd itilizatè.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Yon `Ordering` se rezilta yon konparezon ant de valè.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Yon kòmann-nan kote yon valè konpare se mwens pase yon lòt.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Yon kòmann-nan kote yon valè konpare ki egal a yon lòt.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Yon kòmann-nan kote yon valè konpare pi gran pase yon lòt.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Retounen `true` si kòmann-nan se Variant `Equal` la.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Retounen `true` si kòmann-nan se pa Variant `Equal` la.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Retounen `true` si kòmann-nan se Variant `Less` la.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Retounen `true` si kòmann-nan se Variant `Greater` la.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Retounen `true` si kòmann-nan se swa Variant la `Less` oswa `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Retounen `true` si kòmann-nan se swa Variant la `Greater` oswa `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Ranvèse `Ordering` la.
    ///
    /// * `Less` vin `Greater`.
    /// * `Greater` vin `Less`.
    /// * `Equal` vin `Equal`.
    ///
    /// # Examples
    ///
    /// Konpòtman debaz:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Metòd sa a ka itilize pou ranvèse yon konparezon:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // sòt etalaj la soti nan pi gwo a pi piti.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Chenn de kòmandman.
    ///
    /// Retounen `self` lè li pa `Equal`.Sinon retounen `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Chenn kòmann-nan ak fonksyon yo bay la.
    ///
    /// Retounen `self` lè li pa `Equal`.
    /// Sinon apèl `f` epi retounen rezilta a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Yon struct ede pou kòmann-nan ranvèse.
///
/// Struct sa a se yon asistan pou itilize ak fonksyon tankou [`Vec::sort_by_key`] epi li ka itilize pou ranvèse lòd yon pati nan yon kle.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait pou kalite ki fòme yon [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Yon lòd se yon lòd total si li (pou tout `a`, `b` ak `c`):
///
/// - total ak asimetri: egzakteman youn nan `a < b`, `a == b` oswa `a > b` se vre;ak
/// - tranzitif, `a < b` ak `b < c` implique `a < c`.Menm bagay la tou dwe kenbe pou tou de `==` ak `>`.
///
/// ## Derivable
///
/// trait sa a ka itilize ak `#[derive]`.
/// Lè `derive`d sou structs, li pral pwodwi yon [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) kòmann-nan ki baze sou lòd la deklarasyon tèt-a-anba nan manm struct la.
///
/// Lè `derive`d sou enums, variantes yo te bay lòd pa tèt-a-anba lòd diskriminan yo.
///
/// ## Konparezon leksikografik
///
/// Konparezon leksikografik se yon operasyon ak pwopriyete sa yo:
///  - De sekans yo konpare eleman pa eleman.
///  - Premye eleman ki pa koresponn an defini ki sekans leksikografikman mwens oswa pi gran pase lòt la.
///  - Si yon sekans se yon prefiks nan yon lòt, sekans ki pi kout la leksikografikman mwens pase lòt la.
///  - Si de sekans gen eleman ekivalan epi yo gen menm longè, lè sa a sekans yo leksikografik egal.
///  - Yon sekans vid leksikografikman mwens pase nenpòt sekans ki pa vid.
///  - De sekans vid yo leksikografik egal.
///
/// ## Kouman mwen ka aplike `Ord`?
///
/// `Ord` mande pou kalite a tou dwe [`PartialOrd`] ak [`Eq`] (ki mande pou [`PartialEq`]).
///
/// Lè sa a, ou dwe defini yon aplikasyon pou [`cmp`].Ou ka jwenn li itil yo sèvi ak [`cmp`] sou jaden kalite ou a.
///
/// Aplikasyon [`PartialEq`], [`PartialOrd`], ak `Ord`*dwe* dakò youn ak lòt.
/// Sa vle di, `a.cmp(b) == Ordering::Equal` si e sèlman si `a == b` ak `Some(a.cmp(b)) == a.partial_cmp(b)` pou tout `a` ak `b`.
/// Li fasil pou aksidantèlman fè yo pa dakò pa sòti kèk nan traits la ak manyèlman aplike lòt moun.
///
/// Isit la nan yon egzanp kote ou vle sòt moun pa wotè sèlman, neglije `id` ak `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Metòd sa a retounen yon [`Ordering`] ant `self` ak `other`.
    ///
    /// Pa konvansyon, `self.cmp(&other)` retounen kòmann-nan matche ekspresyon an `self <operator> other` si vre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Konpare epi retounen maksimòm de valè.
    ///
    /// Retounen dezyèm agiman an si konparezon an detèmine yo egal.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Konpare epi retounen minimòm de valè yo.
    ///
    /// Retounen agiman an premye si konparezon an detèmine yo egal.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Mete restriksyon sou yon valè nan yon entèval sèten.
    ///
    /// Retounen `max` si `self` pi gran pase `max`, ak `min` si `self` pi piti pase `min`.
    /// Sinon sa retounen `self`.
    ///
    /// # Panics
    ///
    /// Panics si `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Rive macro génération yon impl nan trait `Ord` la.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait pou valè ki ka konpare pou yon sòt-lòd.
///
/// Konparezon an dwe satisfè, pou tout `a`, `b` ak `c`:
///
/// - asimetri: si `a < b` Lè sa a, `!(a > b)`, osi byen ke `a > b` qui `!(a < b)`;ak
/// - transitivite: `a < b` ak `b < c` implique `a < c`.Menm bagay la tou dwe kenbe pou tou de `==` ak `>`.
///
/// Remake byen ke kondisyon sa yo vle di ke trait nan tèt li dwe aplike simetrik ak transitively: si `T: PartialOrd<U>` ak `U: PartialOrd<V>` Lè sa a, `U: PartialOrd<T>` ak `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait sa a ka itilize ak `#[derive]`.Lè `derive`d sou structs, li pral pwodwi yon leksikografik kòmann-nan ki baze sou lòd la tèt-a-anba deklarasyon nan manm struct la.
/// Lè `derive`d sou enums, variantes yo te bay lòd pa tèt-a-anba lòd diskriminan yo.
///
/// ## Kouman mwen ka aplike `PartialOrd`?
///
/// `PartialOrd` sèlman mande pou aplikasyon nan metòd la [`partial_cmp`], ak lòt moun yo ki te pwodwi nan aplikasyon default.
///
/// Sepandan li rete posib aplike lòt moun yo separeman pou kalite ki pa gen yon lòd total.
/// Pou egzanp, pou nimewo pwen k ap flote, `NaN < 0 == false` ak `NaN >= 0 == false` (cf.
/// IEEE 754-2008 seksyon 5.11).
///
/// `PartialOrd` mande pou kalite ou yo dwe [`PartialEq`].
///
/// Aplikasyon [`PartialEq`], `PartialOrd`, ak [`Ord`]*dwe* dakò youn ak lòt.
/// Li fasil pou aksidantèlman fè yo pa dakò pa sòti kèk nan traits la ak manyèlman aplike lòt moun.
///
/// Si kalite ou se [`Ord`], ou ka aplike [`partial_cmp`] lè l sèvi avèk [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Ou ka jwenn li itil tou pou itilize [`partial_cmp`] sou jaden tip ou an.
/// Isit la se yon egzanp kalite `Person` ki gen yon pwen k ap flote `height` jaden ki se jaden an sèlman yo dwe itilize pou klasman:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Metòd sa a retounen yon kòmann-nan ant `self` ak `other` valè si yon sèl egziste.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Lè konparezon enposib:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Metòd sa a teste mwens pase (pou `self` ak `other`) epi li itilize pa operatè `<` la.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Metòd sa a teste mwens pase oswa egal a (pou `self` ak `other`) epi li itilize pa operatè `<=` la.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Metòd sa a teste pi gran pase (pou `self` ak `other`) epi li itilize pa operatè `>` la.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Metòd sa a teste pi gran pase oswa egal a (pou `self` ak `other`) epi li itilize pa operatè `>=` la.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Rive macro génération yon impl nan trait `PartialOrd` la.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Konpare epi retounen minimòm de valè yo.
///
/// Retounen agiman an premye si konparezon an detèmine yo egal.
///
/// Intern itilize yon alyas [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Retounen minimòm de valè ki gen rapò ak fonksyon konparezon espesifye a.
///
/// Retounen agiman an premye si konparezon an detèmine yo egal.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Retounen eleman ki bay valè minimòm nan fonksyon espesifye a.
///
/// Retounen agiman an premye si konparezon an detèmine yo egal.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Konpare epi retounen maksimòm de valè.
///
/// Retounen dezyèm agiman an si konparezon an detèmine yo egal.
///
/// Intern itilize yon alyas [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Retounen maksimòm de valè ki gen rapò ak fonksyon konparezon espesifye a.
///
/// Retounen dezyèm agiman an si konparezon an detèmine yo egal.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Retounen eleman ki bay valè maksimòm nan fonksyon espesifye a.
///
/// Retounen dezyèm agiman an si konparezon an detèmine yo egal.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Aplikasyon PartialEq, Eq, PartialOrd ak Ord pou kalite primitif yo
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Lòd la isit la enpòtan pou jenere plis asanble optimal.
                    // Gade <https://github.com/rust-lang/rust/issues/63758> pou plis enfòmasyon.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Distribisyon nan i8 a ak konvèti diferans lan nan yon kòmann-nan jenere plis asanble pi bon.
            //
            // Gade <https://github.com/rust-lang/rust/issues/66780> pou plis enfòmasyon.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SEKIRITE: bool kòm i8 retounen 0 oswa 1, kidonk diferans lan pa kapab yon lòt bagay
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &endikasyon

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}