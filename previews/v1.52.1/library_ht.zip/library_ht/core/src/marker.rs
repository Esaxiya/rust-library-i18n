//! Primitif traits ak kalite ki reprezante pwopriyete debaz nan kalite yo.
//!
//! Kalite Rust yo ka klase nan divès fason itil selon pwopriyete intrinsèques yo.
//! Klasifikasyon sa yo reprezante kòm traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Kalite ki ka transfere atravè limit fil yo.
///
/// trait sa a otomatikman aplike lè du a detèmine li apwopriye.
///
/// Yon egzanp yon kalite ki pa `Voye` se [`rc::Rc`][`Rc`] konsèy referans-konte a.
/// Si de fil eseye klone [`Rc`] ki montre menm valè referans-konte yo, yo ta ka eseye mete ajou referans konte an menm tan an, ki se [undefined behavior][ub] paske [`Rc`] pa sèvi ak operasyon atomik.
///
/// Kouzen li [`sync::Arc`][arc] sèvi ak operasyon atomik (antrene kèk anlè) e konsa se `Send`.
///
/// Gade [the Nomicon](../../nomicon/send-and-sync.html) pou plis detay.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Kalite ki gen yon gwosè konstan li te ye nan tan konpile.
///
/// Tout paramèt kalite gen yon mare enplisit nan `Sized`.Sentaks espesyal `?Sized` la ka itilize yo retire sa a mare si li pa apwopriye.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//erè: Gwosè pa aplike pou [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Yon sèl eksepsyon se kalite enplisit `Self` nan yon trait.
/// Yon trait pa gen yon `Sized` enplisit mare tankou sa a se enkonpatib ak [objè trait] kote, pa definisyon, trait a bezwen travay avèk tout enplemante posib, e konsa ta ka nenpòt ki gwosè.
///
///
/// Malgre ke Rust ap kite ou mare `Sized` nan yon trait, ou pa yo pral kapab sèvi ak li nan fòme yon objè trait pita:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // kite y: &dyn Bar= &Impl;//erè: trait `Bar` la pa ka fèt nan yon objè
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // pou Default, pou egzanp, ki egzije pou `[T]: !Default` evalyab
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Kalite ki ka "unsized" nan yon kalite dinamik ki menm gwosè ak.
///
/// Pou egzanp, gwosè etalaj kalite `[i8; 2]` a aplike `Unsize<[i8]>` ak `Unsize<dyn fmt::Debug>`.
///
/// Tout aplikasyon `Unsize` yo bay otomatikman pa du a.
///
/// `Unsize` aplike pou:
///
/// - `[T; N]` se `Unsize<[T]>`
/// - `T` se `Unsize<dyn Trait>` lè `T: Trait`
/// - `Foo<..., T, ...>` se `Unsize<Foo<..., U, ...>>` si:
///   - `T: Unsize<U>`
///   - Foo se yon struct
///   - Se sèlman dènye jaden `Foo` ki gen yon kalite ki enplike `T`
///   - `T` se pa yon pati nan kalite nenpòt lòt jaden
///   - `Bar<T>: Unsize<Bar<U>>`, si dènye jaden `Foo` gen kalite `Bar<T>`
///
/// `Unsize` yo itilize ansanm ak [`ops::CoerceUnsized`] pou pèmèt kontenè "user-defined" tankou [`Rc`] genyen kalite dinamik ki menm gwosè ak yo.
/// Gade [DST coercion RFC][RFC982] ak [the nomicon entry on coercion][nomicon-coerce] pou plis detay.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Obligatwa trait pou konstan yo itilize nan alimèt modèl.
///
/// Nenpòt kalite ki sòti `PartialEq` otomatikman aplike trait sa a, * kèlkeswa si wi ou non tip-paramèt aplike `Eq`.
///
/// Si yon atik `const` gen kèk kalite ki pa aplike sa a trait, Lè sa a, ki kalite swa (1.) pa aplike `PartialEq` (ki vle di konstan a pa pral bay ki metòd konparezon, ki jenerasyon kòd sipoze ki disponib), oswa (2.) li aplike *pwòp li yo* vèsyon `PartialEq` (ki nou sipoze pa konfòme li avèk yon konparezon estriktirèl-egalite).
///
///
/// Nan youn nan de senaryo ki anwo yo, nou rejte l 'tankou yon konstan nan yon match modèl.
///
/// Gade tou [structural match RFC][RFC1445] a, ak [issue 63438] ki motive migrasyon soti nan atribi ki baze sou konsepsyon sa a trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Obligatwa trait pou konstan yo itilize nan alimèt modèl.
///
/// Nenpòt kalite ki sòti `Eq` otomatikman aplike trait sa a, * kèlkeswa si wi ou non paramèt kalite li yo aplike `Eq`.
///
/// Sa a se yon Hack nan travay alantou yon limit nan sistèm kalite nou an.
///
/// # Background
///
/// Nou vle mande pou ke kalite konst yo itilize nan alimèt modèl gen `#[derive(PartialEq, Eq)]` a atribi.
///
/// Nan yon mond pi ideyal, nou ta ka tcheke egzijans sa a jis tcheke ke kalite yo bay la aplike tou de `StructuralPartialEq` trait *ak*`Eq` trait la.
/// Sepandan, ou ka gen ADTs ki *fè*`derive(PartialEq, Eq)`, epi yo dwe yon ka ke nou vle du a aksepte, e ankò kalite konstan an echwe aplike `Eq`.
///
/// Savwa, yon ka tankou sa a:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Pwoblèm ki nan kòd ki anwo a se ke `Wrap<fn(&())>` pa aplike `PartialEq`, ni `Eq`, paske `pou <'yon> fn(&'a _)` does not implement those traits.)
///
/// Se poutèt sa, nou pa ka konte sou chèk nayif pou `StructuralPartialEq` ak sèlman `Eq`.
///
/// Kòm yon Hack nan travay alantou sa a, nou itilize de separe traits sou fòm piki pa chak nan de yo sòti (`#[derive(PartialEq)]` ak `#[derive(Eq)]`) epi tcheke ke tou de nan yo prezan kòm yon pati nan tcheke estriktirèl-matche ak.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Kalite ki gen valè ka kopi tou senpleman pa kopye Bits.
///
/// Pa default, mare varyab gen 'deplase semantik.'Nan yon lòt sans:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` te deplase nan `y`, e konsa pa ka itilize
///
/// // println! ("{: ?}", x);//erè: sèvi ak valè deplase
/// ```
///
/// Sepandan, si yon kalite aplike `Copy`, li olye gen 'kopi semantik':
///
/// ```
/// // Nou ka dériver yon aplikasyon `Copy`.
/// // `Clone` se obligatwa tou, kòm li nan yon supertrait nan `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` se yon kopi `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Li enpòtan sonje ke nan de egzanp sa yo, sèl diferans lan se si wi ou non ou gen dwa jwenn aksè nan `x` apre plasman an.
/// Anba kapo a, tou de yon kopi ak yon mouvman ka rezilta nan Bits ke yo te kopye nan memwa, byenke sa a se pafwa optimize lwen.
///
/// ## Kouman mwen ka aplike `Copy`?
///
/// Gen de fason aplike `Copy` sou kalite ou.Pi senp la se sèvi ak `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Ou kapab tou aplike `Copy` ak `Clone` manyèlman:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Gen yon ti diferans ant de la: estrateji `derive` la pral mete tou yon `Copy` mare sou paramèt kalite, ki pa toujou vle.
///
/// ## Ki diferans ki genyen ant `Copy` ak `Clone`?
///
/// Kopi rive enplisitman, pou egzanp kòm yon pati nan yon devwa `y = x`.Konpòtman `Copy` pa twò chaje;li se toujou yon kopi senp ti jan ki gen bon konprann.
///
/// Klonaj se yon aksyon eksplisit, `x.clone()`.Aplikasyon [`Clone`] ka bay nenpòt konpòtman kalite espesifik ki nesesè pou kopi valè san danje.
/// Pou egzanp, aplikasyon an nan [`Clone`] pou [`String`] bezwen kopye pwent-a tanpon fisèl nan pil la.
/// Yon kopi senp bit de valè [`String`] ta senpleman kopi konsèy la, ki mennen ale nan yon doub gratis desann liy lan.
/// Pou rezon sa a, [`String`] se [`Clone`] men li pa `Copy`.
///
/// [`Clone`] se yon supertrait nan `Copy`, se konsa tout bagay ki se `Copy` dwe aplike tou [`Clone`].
/// Si yon kalite se `Copy` Lè sa a, aplikasyon [`Clone`] li yo sèlman bezwen retounen `*self` (al gade egzanp ki anwo a).
///
/// ## Kilè kalite mwen ka `Copy`?
///
/// Yon kalite ka aplike `Copy` si tout eleman li yo aplike `Copy`.Pou egzanp, struct sa a ka `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Yon struct ka `Copy`, ak [`i32`] se `Copy`, Se poutèt sa `Point` kalifye pou li `Copy`.
/// Kontrèman, konsidere
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struct `PointList` la pa ka aplike `Copy`, paske [`Vec<T>`] se pa `Copy`.Si nou eseye dériver yon aplikasyon `Copy`, nou pral jwenn yon erè:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Pataje referans (`&T`) yo tou `Copy`, se konsa yon kalite ka `Copy`, menm lè li kenbe referans pataje nan kalite `T` ki *pa*`Copy`.
/// Konsidere struct ki anba la a, ki ka aplike `Copy`, paske li sèlman kenbe yon *referans pataje* ki pa Peye-Kopye nou kalite `PointList` soti nan pi wo a:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Lè *pa ka* kalite mwen an dwe `Copy`?
///
/// Gen kèk kalite ki pa ka kopye san danje.Pou egzanp, kopye `&mut T` ta kreye yon referans alyab mutable.
/// Kopye [`String`] ta kopi responsablite pou jere tanpon [`fisèl la]], ki mennen nan yon doub gratis.
///
/// Jeneralize ka a lèt, nenpòt ki kalite aplike [`Drop`] pa ka `Copy`, paske li nan jere kèk resous san konte pwòp li yo [`size_of::<T>`] bytes.
///
/// Si ou eseye aplike `Copy` sou yon struct oswa enum ki gen done ki pa `Kopi`, ou pral jwenn [E0204] nan erè.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kilè *mwen ta dwe* kalite mwen an `Copy`?
///
/// Anjeneral pale, si kalite ou _can_ aplike `Copy`, li ta dwe.
/// Kenbe nan tèt ou, menm si, ke aplikasyon `Copy` se yon pati nan API piblik la nan kalite ou.
/// Si kalite a ta ka vin ki pa `Kopi` nan future a, li ta ka pridan pou w kite aplikasyon `Copy` kounye a, pou evite yon chanjman API kraze.
///
/// ## Enplemantè Lòt
///
/// Anplis de sa nan [implementors listed below][impls] la, kalite sa yo tou aplike `Copy`:
///
/// * Kalite atik fonksyon yo (sètadi, kalite diferan yo defini pou chak fonksyon)
/// * Fonksyon kalite konsèy (egzanp, `fn() -> i32`)
/// * Kalite etalaj, pou tout gwosè, si kalite atik la aplike tou `Copy` (egzanp, `[i32; 123456]`)
/// * Kalite tupl, si chak eleman tou aplike `Copy` (egzanp, `()`, `(i32, bool)`)
/// * Kalite fèmen, si yo pa pran okenn valè nan anviwònman an oswa si tout valè kaptire sa yo aplike `Copy` tèt yo.
///   Remake byen ke varyab kaptire pa referans pataje toujou aplike `Copy` (menm si referan a pa), pandan y ap varyab kaptire pa referans mutable pa janm aplike `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Sa pèmèt kopye yon kalite ki pa aplike `Copy` paske yo pa satisfè limit pou tout lavi (kopye `A<'_>` lè sèlman `A<'static>: Copy` ak `A<'_>: Clone`).
// Nou gen sa a atribi isit la pou kounye a sèlman paske gen byen yon kèk espesyalizasyon ki deja egziste sou `Copy` ki deja egziste nan bibliyotèk la estanda, e pa gen okenn fason yo san danje gen konpòtman sa a kounye a.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Rive macro génération yon impl nan trait `Copy` la.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Kalite pou ki li an sekirite yo pataje referans ant fil.
///
/// trait sa a otomatikman aplike lè du a detèmine li apwopriye.
///
/// Definisyon egzak la se: yon kalite `T` se [`Sync`] si epi sèlman si `&T` se [`Send`].
/// Nan lòt mo, si pa gen okenn posibilite pou [undefined behavior][ub] (ki gen ladan ras done) lè w ap pase `&T` referans ant fil.
///
/// Kòm yon sèl ta atann, kalite primitif tankou [`u8`] ak [`f64`] yo tout [`Sync`], e konsa yo se kalite senp total ki gen yo, tankou tuples, structs ak enums.
/// Plis egzanp nan kalite debaz [`Sync`] gen ladan kalite "immutable" tankou `&T`, ak moun ki gen mutabilite senp eritye, tankou [`Box<T>`][box], [`Vec<T>`][vec] ak pifò lòt kalite koleksyon.
///
/// (Paramèt jenerik bezwen [`Sync`] pou veso yo dwe [`senkro].)
///
/// Yon konsekans yon ti jan etone nan definisyon an se ke `&mut T` se `Sync` (si `T` se `Sync`) menm si li sanble tankou ki ta ka bay unsynchronized mitasyon.
/// Trick a se ke yon referans mutable dèyè yon referans pataje (se sa ki, `& &mut T`) vin li sèlman, tankou si li te yon `& &T`.
/// Pakonsekan pa gen okenn risk pou yon ras done.
///
/// Kalite ki pa `Sync` se moun ki gen "interior mutability" nan yon fòm ki pa fil-san danje, tankou [`Cell`][cell] ak [`RefCell`][refcell].
/// Kalite sa yo pèmèt pou mitasyon nan sa yo menm nan yon referans imuiabl, pataje.
/// Pou egzanp metòd la `set` sou [`Cell<T>`][cell] pran `&self`, kidonk li mande pou sèlman yon [`&Cell<T>`][cell] referans pataje.
/// Metòd la pa fè okenn senkronizasyon, konsa [`Cell`][cell] pa ka `Sync`.
///
/// Yon lòt egzanp nan yon kalite ki pa `Sync` se [`Rc`][rc] konsèy referans-konte a.
/// Bay nenpòt [`&Rc<T>`][rc] referans, ou ka script yon nouvo [`Rc<T>`][rc], modifye konte yo referans nan yon fason ki pa atomik.
///
/// Pou ka lè yon moun bezwen fil ki an sekirite mutabilite enteryè, Rust bay [atomic data types], osi byen ke bloke eksplisit via [`sync::Mutex`][mutex] ak [`sync::RwLock`][rwlock].
/// Kalite sa yo asire ke nenpòt mitasyon pa ka lakòz ras done, pakonsekan kalite yo se `Sync`.
/// Menm jan an tou, [`sync::Arc`][arc] bay yon analogique fil-san danje nan [`Rc`][rc].
///
/// Nenpòt kalite ki gen mutabilite enteryè dwe itilize tou pakè [`cell::UnsafeCell`][unsafecell] alantou value(s) la ki ka mitasyon nan yon referans pataje.
/// Echèk nan fè sa a se [undefined behavior][ub].
/// Pou egzanp, [`transmute`][transmute]-ing soti nan `&T` `&mut T` se valab.
///
/// Gade [the Nomicon][nomicon-send-and-sync] pou plis detay sou `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): yon fwa sipò yo ajoute nòt nan `rustc_on_unimplemented` tè nan beta, epi li te pwolonje yo tcheke si yon fèmti se nenpòt kote nan chèn lan egzijans, pwolonje li kòm (#48534) tankou:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zewo-gwosè kalite itilize yo ki make bagay ki "act like" yo posede yon `T`.
///
/// Ajoute yon jaden `PhantomData<T>` nan kalite ou di du a ke kalite ou aji tankou si li estoke yon valè de kalite `T`, menm si li pa reyèlman.
/// Enfòmasyon sa a itilize lè enfòmatik sèten pwopriyete sekirite.
///
/// Pou yon eksplikasyon plis apwofondi sou kouman yo sèvi ak `PhantomData<T>`, tanpri al gade [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Yon nòt efreyan 👻👻👻
///
/// Menm si yo tou de gen non pè, `PhantomData` ak 'kalite fantom' yo ki gen rapò, men se pa idantik.Yon paramèt kalite fantom se senpleman yon paramèt kalite ki pa janm itilize.
/// Nan Rust, sa a souvan lakòz du a pote plent, ak solisyon an se ajoute yon "dummy" itilize pa fason pou `PhantomData`.
///
/// # Examples
///
/// ## Paramèt pou tout lavi rès
///
/// Petèt ka a itilize pi komen pou `PhantomData` se yon struct ki gen yon paramèt pou tout lavi rès, tipikman kòm yon pati nan kèk kòd danjere.
/// Pou egzanp, isit la se yon `Slice` struct ki gen de endikasyon nan kalite `*const T`, prezimableman montre nan yon etalaj yon kote:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Entansyon an se ke done yo kache se sèlman valab pou tout lavi a `'a`, se konsa `Slice` pa ta dwe survivre `'a`.
/// Sepandan, entansyon sa a pa eksprime nan kòd la, depi pa gen okenn itilizasyon nan tout lavi `'a` yo e pakonsekan li pa klè ki done li aplike a.
/// Nou ka korije sa a lè nou di du a aji *tankou si*`Slice` struct la genyen yon referans `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Sa a tou nan vire mande pou `T: 'a` anotasyon, ki endike ke nenpòt referans nan `T` yo valab pandan tout lavi `'a` la.
///
/// Lè inisyalize yon `Slice` ou senpleman bay valè `PhantomData` pou jaden `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Paramèt kalite rès
///
/// Li pafwa rive ke ou gen paramèt kalite rès ki endike ki kalite done yon struct se "tied", menm si ke done yo pa aktyèlman yo te jwenn nan struct nan tèt li.
/// Isit la se yon egzanp kote sa rive ak [FFI].
/// Koòdone etranje a sèvi ak manch kalite `*mut ()` pou fè referans a valè Rust diferan kalite yo.
/// Nou swiv kalite a Rust lè l sèvi avèk yon paramèt kalite fantom sou `ExternalResource` struct la ki vlope yon manch.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Pwopriyetè ak chèk la gout
///
/// Ajoute yon jaden nan kalite `PhantomData<T>` endike ke kalite ou posede done nan kalite `T`.Sa a nan vire implique ke lè se kalite ou tonbe, li ka lage youn oswa plis ka nan kalite `T` la.
/// Sa a gen sou analiz [drop check] du Rust la.
///
/// Si struct ou pa an reyalite *posede* done yo nan kalite `T`, li se pi bon yo sèvi ak yon kalite referans, tankou `PhantomData<&'a T>` (ideally) oswa `PhantomData<*const T>` (si pa gen tout lavi aplike), se konsa yo pa endike an komen.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Konpilatè-entèn trait itilize pou endike kalite diskriminan enom yo.
///
/// trait sa a otomatikman aplike pou chak kalite epi li pa ajoute okenn garanti nan [`mem::Discriminant`].
/// Li se **konpòtman endefini** transmute ant `DiscriminantKind::Discriminant` ak `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Kalite diskriminan an, ki dwe satisfè trait bounds ki nesesè pa `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Konpilatè-entèn trait itilize detèmine si yon kalite gen nenpòt `UnsafeCell` intern, men se pa nan yon endireksyon.
///
/// Sa a afekte, pou egzanp, si wi ou non yon `static` ki kalite yo mete nan li sèlman-memwa estatik oswa ekri memwa estatik.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Kalite ki ka deplase san danje apre yo fin estime.
///
/// Rust tèt li pa gen okenn nosyon de kalite immobilier, epi li konsidere mouvman (egzanp, nan plasman oswa [`mem::replace`]) toujou an sekirite.
///
/// Kalite [`Pin`][Pin] la itilize olye pou anpeche mouvman nan sistèm tip lan.Pointeurs `P<T>` ki te anvlope nan pakè [`Pin<P<T>>`][Pin] pa ka deplase soti nan.
/// Gade dokiman [`pin` module] la pou plis enfòmasyon sou zepeng.
///
/// Aplike `Unpin` trait la pou `T` leve restriksyon yo nan epenglaj nan kalite a, ki Lè sa a, pèmèt deplase `T` soti nan [`Pin<P<T>>`][Pin] ak fonksyon tankou [`mem::replace`].
///
///
/// `Unpin` pa gen okenn konsekans ditou pou done ki pa estime.
/// An patikilye, [`mem::replace`] san pwoblèm mwen tap deplase done `!Unpin` (li travay pou nenpòt `&mut T`, pa sèlman lè `T: Unpin`).
/// Sepandan, ou pa ka itilize [`mem::replace`] sou done ki vlope andedan yon [`Pin<P<T>>`][Pin] paske ou pa ka jwenn `&mut T` ou bezwen pou sa, e *se* ki fè sistèm sa a mache.
///
/// Se konsa, sa a, pou egzanp, kapab fèt sèlman sou kalite aplikasyon `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Nou bezwen yon referans mutable yo rele `mem::replace`.
/// // Nou ka jwenn tankou yon referans pa (implicitly) envoke `Pin::deref_mut`, men sa se posib sèlman paske `String` aplike `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait sa a aplike otomatikman pou prèske tout kalite.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Yon kalite makè ki pa aplike `Unpin`.
///
/// Si yon kalite gen yon `PhantomPinned`, li pa pral aplike `Unpin` pa default.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Aplikasyon nan `Copy` pou kalite primitif.
///
/// Aplikasyon ki pa ka dekri nan Rust yo aplike nan `traits::SelectionContext::copy_clone_conditions()` nan `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Pataj referans yo ka kopye, men referans mityèl *pa kapab*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}