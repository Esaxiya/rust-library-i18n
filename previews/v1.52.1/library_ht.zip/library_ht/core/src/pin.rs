//! Kalite ki PIN done nan kote li yo nan memwa.
//!
//! Li se pafwa itil yo gen objè ki garanti yo pa deplase, nan sans ke plasman yo nan memwa pa chanje, epi yo ka konsa dwe konte sou.
//! Yon egzanp premye nan tankou yon senaryo ta dwe bati pwòp tèt ou-referans structs, kòm deplase yon objè ak endikasyon nan tèt li ap invalid yo, sa ki ka lakòz konpòtman endefini.
//!
//! Nan yon wo nivo, yon [`Pin<P>`] asire ke pointee nan nenpòt ki kalite konsèy `P` gen yon kote ki estab nan memwa, sa vle di li pa ka deplase yon lòt kote epi memwa li pa ka deallocated jiskaske li vin tonbe.Nou di ke pointee a se "pinned".Bagay sa yo vin pi sibtil lè w ap diskite sou kalite ki konbine estime ak done ki pa estime;[see below](#projections-and-structural-pinning) pou plis detay.
//!
//! Pa default, tout kalite nan Rust yo mobil.
//! Rust pèmèt pase tout kalite pa-valè, ak komen kalite entelijan-konsèy tankou [`Box<T>`] ak `&mut T` pèmèt ranplase ak deplase valè yo genyen: ou ka deplase soti nan yon [`Box<T>`], oswa ou ka itilize [`mem::swap`].
//! [`Pin<P>`] vlope yon kalite konsèy `P`, kidonk [`PIN`]`<`[`Box`] `<T>>`fonksyon tankou yon regilye
//!
//! [`Box<T>`]: when yon [`PIN`]`<`[`Box`] `<T>>`vin tonbe, se konsa fè sa li yo, ak memwa a vin
//!
//! deallocated.Menm jan an tou, [`Pin`]`<&mut T>`se yon anpil tankou `&mut T`.Sepandan, [`Pin<P>`] pa kite kliyan aktyèlman jwenn yon [`Box<T>`] oswa `&mut T` nan done estime, ki vle di ke ou pa ka itilize operasyon tankou [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` bezwen `&mut T`, men nou pa ka jwenn li.
//!     // Nou kole, nou pa ka swap sa ki nan referans sa yo.
//!     // Nou te kapab itilize `Pin::get_unchecked_mut`, men sa pa an sekirite pou yon rezon:
//!     // nou pa gen dwa sèvi ak li pou deplase bagay sa yo soti nan `Pin` la.
//! }
//! ```
//!
//! Li vo repete ke [`Pin<P>`]*pa* chanje lefèt ke yon du Rust konsidere tout kalite mobil.[`mem::swap`] rete rele pou nenpòt `T`.Olye de sa, [`Pin<P>`] anpeche sèten *valè*(pwente pa endikasyon vlope nan [`Pin<P>`]) nan men yo te deplase pa fè li enposib yo rele metòd ki mande pou `&mut T` sou yo (tankou [`mem::swap`]).
//!
//! [`Pin<P>`] ka itilize vlope nenpòt ki kalite konsèy `P`, ak jan sa li kominike avèk [`Deref`] ak [`DerefMut`].Yon [`Pin<P>`] kote `P: Deref` ta dwe konsidere kòm yon "`P`-style pointer" nan yon `P::Target` estime-se konsa, yon [`PIN`]`<`[`Box`] `<T>>`se yon konsèy posede nan yon `T` estime, ak yon [`PIN`] `<` [`Rc`]`<T>>`se yon konsèy referans-konte nan yon `T` estime.
//! Pou kòrèkte, [`Pin<P>`] konte sou aplikasyon yo nan [`Deref`] ak [`DerefMut`] pa pou avanse pou pi soti nan paramèt `self` yo, epi sèlman tout tan retounen yon konsèy nan done estime yo lè yo rele yo sou yon konsèy estime.
//!
//! # `Unpin`
//!
//! Anpil kalite yo toujou lib mobil, menm lè estime, paske yo pa konte sou gen yon adrès ki estab.Sa gen ladan tout kalite debaz yo (tankou [`bool`], [`i32`], ak referans) osi byen ke kalite ki gen ladan sèlman nan kalite sa yo.Kalite ki pa pran swen sou epenglaj aplike [`Unpin`] oto-trait a, ki anile efè [`Pin<P>`].
//! Pou `T: Unpin`, [`PIN`]`<`[`Box`] `<T>>`ak [`Box<T>`] fonksyon idantik, menm jan fè [`PIN`] `<&mut T>` ak `&mut T`.
//!
//! Remake byen ke epenglaj ak [`Unpin`] afekte sèlman pwente-a kalite `P::Target`, pa tip `P` nan konsèy tèt li ki te vlope nan [`Pin<P>`].Pou egzanp, si wi ou non [`Box<T>`] se [`Unpin`] pa gen okenn efè sou konpòtman an nan [`PIN`]`<`[`Box`] `<T>>`(isit la, `T` se kalite a pwente).
//!
//! # Egzanp: struct oto-referansyèl
//!
//! Anvan nou ale nan plis detay yo eksplike garanti yo ak chwa ki asosye ak `Pin<T>`, nou diskite sou kèk egzanp sou fason li ta ka itilize.
//! Ou lib pou [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Sa a se yon struct pwòp tèt ou-referansyèl paske jaden yo tranch pwen nan jaden an done.
//! // Nou pa ka enfòme du a sou sa ak yon referans nòmal, tankou modèl sa a pa ka dekri ak règleman yo dabitid prete.
//! //
//! // Olye de sa nou itilize yon konsèy anvan tout koreksyon, menm si yon sèl ki se konnen yo pa nil, kòm nou konnen li nan montre nan fisèl la.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Pou asire done yo pa deplase lè fonksyon an retounen, nou mete l 'nan pil la kote li pral rete pou tout lavi a nan objè a, ak wout la sèlman nan aksè a li ta dwe nan yon konsèy sou li.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // nou sèlman kreye konsèy la yon fwa done yo nan plas otreman li pral te deja deplase anvan nou menm te kòmanse
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // nou konnen sa a san danje paske modifye yon jaden pa deplase struct an antye
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Konsèy la ta dwe lonje dwèt sou kote ki kòrèk la, toutotan struct la pa deplase.
//! //
//! // Pandan se tan, nou lib pou avanse pou pi konsèy la alantou.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Depi kalite nou an pa aplike Unpin, sa a pral fail konpile:
//! // kite mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Egzanp: pèsistan lis doub-lye
//!
//! Nan yon lis pèsistan double-lye, koleksyon an pa aktyèlman asiyen memwa a pou eleman yo tèt li.
//! Se Alokasyon kontwole pa kliyan yo, ak eleman ka viv sou yon ankadreman chemine ki viv pi kout pase koleksyon an fè.
//!
//! Pou fè travay sa a, chak eleman gen endikasyon predesesè li yo ak siksesè nan lis la.Eleman yo ka sèlman ajoute lè yo estime, paske deplase eleman yo ozalantou ta invalid pwent yo.Anplis, aplikasyon [`Drop`] nan yon eleman lis lye pral plak endikasyon nan predesesè li yo ak siksesè yo retire tèt li nan lis la.
//!
//! Absoliman, nou dwe kapab konte sou [`drop`] ke yo te rele.Si yon eleman ta ka deallocated oswa otreman valide san yo pa rele [`drop`], endikasyon yo nan li soti nan eleman vwazen li yo ta vin envalid, ki ta kraze estrikti a done.
//!
//! Se poutèt sa, epenglaj vini tou ak yon [`gout`] ki gen rapò ak garanti.
//!
//! # `Drop` guarantee
//!
//! Objektif la nan epenglaj se pou kapab konte sou plasman an nan kèk done nan memwa.
//! Pou fè travay sa a, se pa sèlman deplase done yo restriksyon;se repati, repurposing, oswa otreman invalid memwa a itilize nan magazen done yo restriksyon, tou.
//! Konkrètman, pou done estime ou oblije kenbe envariant la ki *memwa li pa pral jwenn invalid oswa repurposed soti nan moman sa a li vin estime jouk lè yo rele [`drop`]*.Se sèlman yon fwa [`drop`] retounen oswa panics, memwa a ka reyitilize.
//!
//! Memwa ka "invalidated" pa deallocation, men tou, pa ranplase yon [`Some(v)`] pa [`None`], oswa rele [`Vec::set_len`] "kill" kèk eleman koupe nan yon vector.Li ka repurposed lè l sèvi avèk [`ptr::write`] recouvrir li san yo pa rele destriktè a an premye.Okenn nan sa a pa pèmèt pou estime done san yo pa rele [`drop`].
//!
//! Sa a se egzakteman ki kalite garanti ke lis la entrizyon lye nan seksyon anvan an bezwen fonksyone kòrèkteman.
//!
//! Remake ke garanti sa a *pa* vle di ke memwa pa koule!Li toujou konplètman oke pa janm rele [`drop`] sou yon eleman estime (egzanp, ou ka toujou rele [`mem::forget`] sou yon [`PIN`]`<`[`Box`] `<T>>`).Nan egzanp lan nan lis la doubl-lye, ki eleman ta jis rete nan lis la.Sepandan ou ka pa libere oswa reutilize depo a *san ou pa rele [`gout`]*.
//!
//! # `Drop` implementation
//!
//! Si kalite ou itilize epenglaj (tankou de egzanp ki anwo yo), ou dwe fè atansyon lè w ap aplike [`Drop`].Fonksyon [`drop`] la pran `&mut self`, men yo rele sa *menm si tip ou te deja estime*!Li se tankou si du a otomatikman rele [`Pin::get_unchecked_mut`].
//!
//! Sa a pa janm ka lakòz yon pwoblèm nan kòd san danje paske mete ann aplikasyon yon kalite ki depann sou epenglaj mande pou kòd ki an sekirite, men ou dwe konnen ke n ap deside fè pou sèvi ak epenglaj nan kalite ou a (pou egzanp pa aplike kèk operasyon sou [`PIN`]`<&Self>`oswa [`Pin`] `<&mut Self>`) gen konsekans pou aplikasyon [`Drop`] ou tou: si yon eleman nan kalite ou te ka estime, ou dwe trete [`Drop`] kòm enplisitman pran [`PIN`]`<&mut Oto>`.
//!
//!
//! Pou egzanp, ou ta ka aplike `Drop` jan sa a:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` se oke paske nou konnen valè sa a pa janm itilize ankò apre yo te fin tonbe.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Kòd gout aktyèl ale isit la.
//!         }
//!     }
//! }
//! ```
//!
//! Fonksyon `inner_drop` la gen kalite ke [`drop`]*ta dwe* genyen, kidonk sa asire w ke ou pa aksidantèlman itilize `self`/`this` nan yon fason ki an konfli ak epenglaj.
//!
//! Anplis, si kalite ou se `#[repr(packed)]`, du a ap otomatikman deplase jaden alantou pou kapab lage yo.Li ta ka menm fè sa pou jaden ki rive ase aliyen.Kòm yon konsekans, ou pa ka itilize epenglaj ak yon kalite `#[repr(packed)]`.
//!
//! # Pwojeksyon ak estriktirèl epenglaj
//!
//! Lè w ap travay ak estrikti estime, kesyon an rive ki jan yon moun ka jwenn aksè nan jaden yo nan ki struct nan yon metòd ki pran jis [`PIN`]`<&mut Struct>`.
//! Apwòch abityèl la se ekri metòd èd (sa yo rele *projections*) ki vire [`PIN`]`<&mut Struct>`nan yon referans nan jaden an, men ki kalite referans sa a ta dwe genyen?Èske li [`Pin`]`<&mut Field>`oswa `&mut Field`?
//! Kesyon an menm rive ak jaden yo nan yon `enum`, epi tou lè w ap konsidere kalite container/wrapper tankou [`Vec<T>`], [`Box<T>`], oswa [`RefCell<T>`].
//! (Kesyon sa a aplike a tou de referans mityèl ak pataje, nou jis itilize ka a pi komen nan referans mityèl isit la pou ilistrasyon.)
//!
//! Li sanble ke li se aktyèlman jiska otè a nan estrikti a done deside si pwojeksyon an estime pou yon jaden an patikilye vire [`PIN`]`<&mut Struct>`nan [`PIN`] `<&mut Field>` oswa `&mut Field`.Gen kèk kontrent menm si, ak kontrent ki pi enpòtan an se *konsistans*:
//! ka chak jaden dwe *swa* projetée nan yon referans estime,*oswa* gen pinning retire kòm yon pati nan pwojeksyon an.
//! Si tou de yo fè pou jaden an menm, ki pral gen anpil chans dwe solid!
//!
//! Kòm otè a nan yon estrikti done ou jwenn yo deside pou chak jaden si pinning "propagates" nan jaden sa a oswa ou pa.
//! Pinning ki pwopaje yo te rele tou "structural", paske li swiv estrikti a nan kalite la.
//! Nan paragraf sa yo, nou dekri konsiderasyon ki dwe fèt pou swa chwa yo.
//!
//! ## Pinning *se pa* estriktirèl pou `field`
//!
//! Li ka sanble counter-entwisyon ke jaden an nan yon estrikti estime pa ta ka estime, men sa se aktyèlman chwa ki pi fasil: si yon [`PIN`]`<&mut Field>`pa janm kreye, pa gen anyen ka ale mal!Se konsa, si ou deside ke kèk jaden pa gen estriktirèl epenglaj, tout sa ou dwe asire se ke ou pa janm kreye yon referans estime nan jaden sa a.
//!
//! Jaden san epenglaj estriktirèl ka gen yon metòd pwojeksyon ki vire [`PIN`]`<&mut Struct>`nan `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Sa a oke paske `field` pa janm konsidere kòm estime.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Ou kapab tou `impl Unpin for Struct`*menm si* ki kalite `field` se pa [`Unpin`].Ki sa ki kalite panse sou epenglaj se pa enpòtan lè pa gen okenn [`PIN`]`<&mut Field>`janm kreye.
//!
//! ## Pinning *se* estriktirèl pou `field`
//!
//! Opsyon nan lòt se deside ke epenglaj se "structural" pou `field`, sa vle di ke si struct la estime Lè sa a, se konsa jaden an.
//!
//! Sa pèmèt ekri yon pwojeksyon ki kreye yon [`Pin`]`<&mut Field>`, konsa temwen ke jaden an estime:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Sa a se oke paske `field` se estime lè `self` se.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Sepandan, epenglaj estriktirèl vini ak kèk kondisyon siplemantè:
//!
//! 1. Struct la dwe sèlman [`Unpin`] si tout jaden estriktirèl yo [`Unpin`].Sa a se default la, men [`Unpin`] se yon trait san danje, se konsa kòm otè a nan struct la se responsablite ou *pa* ajoute yon bagay tankou `impl<T> Unpin for Struct<T>`.
//! (Remake ke ajoute yon operasyon pwojeksyon mande pou kòd danjere, se konsa lefèt ke [`Unpin`] se yon trait san danje pa kraze prensip la ke ou sèlman gen enkyete sou nenpòt nan sa a si ou itilize `danjere '.)
//! 2. Destriktè a nan struct la pa dwe deplase jaden estriktirèl soti nan agiman li yo.Sa a se pwen egzak la ki te leve soti vivan nan [previous section][drop-impl] la: `drop` pran `&mut self`, men struct la (yo e pakonsekan jaden li yo) ta ka te estime anvan.
//!     Ou dwe garanti ke ou pa deplase yon jaden andedan aplikasyon [`Drop`] ou.
//!     An patikilye, jan yo eksplike sa deja, sa vle di ke struct ou dwe *pa* dwe `#[repr(packed)]`.
//!     Gade seksyon sa a pou kòman yo ekri [`drop`] nan yon fason ke du a ka ede w pa aksidantèlman kraze epenglaj.
//! 3. Ou dwe asire w ke ou defann [`Drop` guarantee][drop-guarantee] la:
//!     yon fwa struct ou estime, memwa a ki gen kontni an pa ranplase oswa deallocated san yo pa rele destriktè kontni an.
//!     Sa a ka difisil, jan temwen pa [`VecDeque<T>`]: destriktè a nan [`VecDeque<T>`] ka fail rele [`drop`] sou tout eleman si youn nan destriktè yo panics.Sa a vyole garanti a [`Drop`], paske li ka mennen nan eleman yo te deallocated san yo pa destriktè yo te rele.([`VecDeque<T>`] pa gen okenn pwojeksyon epenglaj, kidonk sa a pa lakòz ensolans.)
//! 4. Ou pa dwe ofri okenn lòt operasyon ki ta ka mennen nan done yo te deplase soti nan jaden yo estriktirèl lè se kalite ou estime.Pou egzanp, si struct la gen yon [`Option<T>`] epi gen yon "pran" ki tankou operasyon ak kalite `fn(Pin<&mut Struct<T>>) -> Option<T>`, ki ka operasyon dwe itilize pou avanse pou pi yon `T` soti nan yon `Struct<T>` estime-ki vle di epenglaj pa ka estriktirèl pou jaden an kenbe sa a done.
//!
//!     Pou yon egzanp pi konplèks nan k ap deplase done soti nan yon kalite estime, imajine si [`RefCell<T>`] te gen yon metòd `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Lè sa a, nou te kapab fè bagay sa yo:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Sa a se katastwofik, sa vle di nou ka premye PIN kontni an nan [`RefCell<T>`] a (lè l sèvi avèk `RefCell::get_pin_mut`) ak Lè sa a deplase kontni sa a lè l sèvi avèk referans a mutabl nou te resevwa pita.
//!
//! ## Examples
//!
//! Pou yon kalite tankou [`Vec<T>`], tou de posiblite (estriktirèl epenglaj oswa ou pa) fè sans.
//! Yon [`Vec<T>`] ki gen estrikti estriktirèl te kapab gen metòd `get_pin`/`get_pin_mut` pou jwenn referans estime sou eleman yo.Sepandan, li te kapab *pa* pèmèt rele [`pop`][Vec::pop] sou yon [`Vec<T>`] estime paske sa ta deplase sa ki (estriktirèl estime) sa!Ni li pa t 'kapab pèmèt [`push`][Vec::push], ki ta ka reasigne epi konsa tou deplase sa ki nan liv la.
//!
//! Yon [`Vec<T>`] san epenglaj estriktirèl ta ka `impl<T> Unpin for Vec<T>`, paske sa ki pa janm estime ak [`Vec<T>`] nan tèt li se amann ak yo te deplase tou.
//! Nan pwen sa epenglaj jis pa gen okenn efè sou vector la nan tout.
//!
//! Nan bibliyotèk la estanda, kalite konsèy jeneralman pa gen estriktirèl epenglaj, e konsa yo pa ofri pwojeksyon epenglaj.Se poutèt sa `Box<T>: Unpin` kenbe pou tout `T`.
//! Li fè sans nan fè sa pou kalite konsèy, paske deplase `Box<T>` la pa aktyèlman deplase `T` la: [`Box<T>`] la ka lib mobil (aka `Unpin`) menm si `T` la se pa.An reyalite, menm [`PIN`]`<`[`Box`] `<T>>`ak [`PIN`] `<&mut T>` yo toujou [`Unpin`] tèt yo, pou menm rezon an: sa ki ladan yo (`T`) yo estime, men pwent yo tèt yo ka deplase san yo pa deplase done yo estime.
//! Pou tou de [`Box<T>`] ak [`PIN`]`<`[`Box`] `<T>>`, si kontni an estime se antyèman endepandan de si konsèy la estime, sa vle di epenglaj *pa* estriktirèl.
//!
//! Lè w ap aplike yon [`Future`] combinator, ou pral anjeneral bezwen estriktirèl epenglaj pou enbrike futures a, menm jan ou bezwen jwenn referans estime yo rele [`poll`].
//! Men, si konbinezon ou a gen nenpòt lòt done ki pa bezwen estime, ou ka fè jaden sa yo pa estriktirèl yo e pakonsekan aksè lib yo ak yon referans mutable menm lè ou jis gen [`PIN`]`<&mut Self>`(tankou tankou nan pwòp aplikasyon [`poll`] ou).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Yon konsèy estime.
///
/// Sa a se yon pakè alantou yon kalite konsèy ki fè ke konsèy "pin" valè li yo nan plas, anpeche valè a referans pa ki konsèy soti nan ke yo te deplase sof si li aplike [`Unpin`].
///
///
/// *Gade dokiman [`pin` module] la pou yon eksplikasyon sou zepeng.*
///
/// [`pin` module]: self
///
// Note: `Clone` a dériver anba a lakòz unsoundness kòm li posib aplike
// `Clone` pou referans mutable.
// Gade <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> pou plis detay.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Aplikasyon sa yo pa sòti nan lòd pou fè pou evite pwoblèm solidite.
// `&self.pointer` pa ta dwe aksesib a aplikasyon trait ki pa gen konfyans.
//
// Gade <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> pou plis detay.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Konstwi yon nouvo `Pin<P>` alantou yon konsèy nan kèk done nan yon kalite ki aplike [`Unpin`].
    ///
    /// Kontrèman ak `Pin::new_unchecked`, metòd sa a an sekirite paske konsèy la `P` dereferences nan yon kalite [`Unpin`], ki anile garanti yo epenglaj.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SEKIRITE: valè a pwente a se `Unpin`, e konsa pa gen okenn kondisyon
        // alantou epenglaj.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Déblotché sa a `Pin<P>` retounen konsèy la kache.
    ///
    /// Sa mande pou done ki andedan `Pin` sa a se [`Unpin`] pou nou ka inyore envariants yo epenglaj lè anvlope li.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstwi yon nouvo `Pin<P>` alantou yon referans a kèk done nan yon kalite ki ka oswa ka pa aplike `Unpin`.
    ///
    /// Si `pointer` dereferans nan yon kalite `Unpin`, `Pin::new` ta dwe itilize olye.
    ///
    /// # Safety
    ///
    /// Konstriktè sa a pa an sekirite paske nou pa ka garanti ke done yo pwente pa `pointer` yo estime, sa vle di ke done yo pa pral deplase oswa depo li yo invalid jouk li vin tonbe.
    /// Si `Pin<P>` konstwi a pa garanti ke done `P` pwen yo estime, se yon vyolasyon kontra API a epi yo ka mennen nan konpòtman endefini nan operasyon (safe) pita.
    ///
    /// Lè l sèvi avèk metòd sa a, w ap fè yon promise sou aplikasyon yo `P::Deref` ak `P::DerefMut`, si yo egziste.
    /// Sa ki pi enpòtan yo, yo pa dwe deplase soti nan agiman `self` yo: `Pin::as_mut` ak `Pin::as_ref` ap rele `DerefMut::deref_mut` ak `Deref::deref`*sou konsèy la estime* epi yo atann metòd sa yo kenbe envariant yo epenglaj.
    /// Anplis, lè w rele metòd sa a ou promise ke referans `P` dereferans yo pa pral deplase soti nan ankò;an patikilye, li pa dwe posib pou jwenn yon `&mut P::Target` ak Lè sa a, deplase soti nan referans sa a (lè l sèvi avèk, pou egzanp [`mem::swap`]).
    ///
    ///
    /// Pou egzanp, rele `Pin::new_unchecked` sou yon `&'a mut T` se an sekirite paske pandan ke ou kapab PIN li pou tout lavi a bay `'a`, ou pa gen okenn kontwòl sou si wi ou non li kenbe estime yon fwa `'a` fini:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Sa ta dwe vle di pointee `a` la pa janm ka deplase ankò.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adrès la nan `a` chanje nan plas chemine `b` a, se konsa `a` te deplase menm si nou te deja estime li!Nou te vyole kontra a epeng API.
    /////
    /// }
    /// ```
    ///
    /// Yon valè, yon fwa estime, dwe rete estime pou tout tan (sòf si kalite li aplike `Unpin`).
    ///
    /// Menm jan an tou, rele `Pin::new_unchecked` sou yon `Rc<T>` pa an sekirite paske ta ka gen alyas nan menm done yo ki pa sijè a restriksyon yo epenglaj:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Sa ta dwe vle di pointee a pa janm ka deplase ankò.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Koulye a, si `x` te referans a sèlman, nou gen yon referans mutable nan done ke nou estime pi wo a, ki nou ta ka itilize pou avanse pou pi li jan nou te wè nan egzanp anvan an.
    ///     // Nou te vyole kontra a epeng API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Jwenn yon referans estime pataje soti nan konsèy sa a estime.
    ///
    /// Sa a se yon metòd jenerik yo ale nan `&Pin<Pointer<T>>` `Pin<&T>`.
    /// Li an sekirite paske, kòm yon pati nan kontra a nan `Pin::new_unchecked`, pointee a pa ka deplase apre `Pin<Pointer<T>>` te kreye.
    ///
    /// "Malicious" aplikasyon nan `Pointer::Deref` yo menm jan an tou regle pa kontra a nan `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SEKIRITE: gade dokiman sou fonksyon sa a
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Déblotché sa a `Pin<P>` retounen konsèy la kache.
    ///
    /// # Safety
    ///
    /// Fonksyon sa a pa an sekirite.Ou dwe garanti ke ou pral kontinye trete `P` konsèy la kòm estime apre ou fin rele fonksyon sa a, pou envariants yo sou kalite `Pin` la ka konfime.
    /// Si kòd la lè l sèvi avèk `P` a ki kapab lakòz pa kontinye kenbe envariants yo epenglaj ki se yon vyolasyon kontra a API ak pouvwa mennen nan konpòtman endefini nan pita (safe) operasyon yo.
    ///
    ///
    /// Si done yo kache se [`Unpin`], [`Pin::into_inner`] yo ta dwe itilize olye.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Jwenn yon estime referans mutable soti nan konsèy sa a estime.
    ///
    /// Sa a se yon metòd jenerik yo ale nan `&mut Pin<Pointer<T>>` `Pin<&mut T>`.
    /// Li an sekirite paske, kòm yon pati nan kontra a nan `Pin::new_unchecked`, pointee a pa ka deplase apre `Pin<Pointer<T>>` te kreye.
    ///
    /// "Malicious" aplikasyon nan `Pointer::DerefMut` yo menm jan an tou regle pa kontra a nan `Pin::new_unchecked`.
    ///
    /// Metòd sa a itil lè w ap fè apèl miltip nan fonksyon ki konsome kalite a estime.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // fè yon bagay
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` konsome `self`, se konsa reborrow `Pin<&mut Self>` la atravè `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SEKIRITE: gade dokiman sou fonksyon sa a
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Bay yon nouvo valè nan memwa a dèyè referans la estime.
    ///
    /// Sa a ranplase done estime, men sa se oke: destriktè li vin kouri anvan yo te ranplase, kidonk pa gen okenn garanti pinning vyole.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstwi yon PIN nouvo pa kat valè enteryè a.
    ///
    /// Pou egzanp, si ou te vle jwenn yon `Pin` nan yon jaden nan yon bagay, ou ta ka itilize sa a jwenn aksè nan jaden sa a nan yon sèl liy nan kòd.
    /// Sepandan, gen plizyè gotchas ak "pinning projections" sa yo;
    /// al gade dokiman [`pin` module] la pou plis detay sou sijè sa a.
    ///
    /// # Safety
    ///
    /// Fonksyon sa a pa an sekirite.
    /// Ou dwe garanti ke done ou retounen yo pa pral deplase toutotan valè agiman an pa deplase (pa egzanp, paske li se youn nan jaden ki gen valè sa a), epi tou ke ou pa deplase soti nan agiman ou resevwa nan fonksyon enteryè a.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SEKIRITE: kontra sekirite pou `new_unchecked` dwe
        // konfime pa moun kap rele a.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Jwenn yon referans pataje soti nan yon PIN.
    ///
    /// Sa a san danje paske li pa posib pou avanse pou pi soti nan yon referans pataje.
    /// Li ka sanble tankou gen yon pwoblèm isit la ak mutabilite enteryè: an reyalite, li *se* posib pou avanse pou pi yon `T` soti nan yon `&RefCell<T>`.
    /// Sepandan, sa a se pa yon pwoblèm osi lontan ke gen pa egziste tou yon `Pin<&T>` montre nan done yo menm, ak `RefCell<T>` pa kite ou kreye yon referans estime nan sa li yo.
    ///
    /// Gade diskisyon sou ["pinning projections"] pou plis detay.
    ///
    /// Note: `Pin` tou aplike `Deref` nan sib la, ki ka itilize jwenn aksè nan valè enteryè a.
    /// Sepandan, `Deref` sèlman bay yon referans ki ap viv pou osi lontan ke prete nan `Pin` a, pa tout lavi a nan `Pin` nan tèt li.
    /// Metòd sa a pèmèt vire `Pin` la nan yon referans ak tout lavi a menm jan ak `Pin` orijinal la.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konvèti `Pin<&mut T>` sa a nan yon `Pin<&T>` ak menm lavi a.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Jwenn yon referans mutable nan done yo andedan sa a `Pin`.
    ///
    /// Sa mande pou done ki andedan `Pin` sa a se `Unpin`.
    ///
    /// Note: `Pin` tou aplike `DerefMut` nan done yo, ki ka itilize jwenn aksè nan valè enteryè a.
    /// Sepandan, `DerefMut` sèlman bay yon referans ki ap viv pou osi lontan ke prete nan `Pin` a, pa tout lavi a nan `Pin` nan tèt li.
    ///
    /// Metòd sa a pèmèt vire `Pin` la nan yon referans ak tout lavi a menm jan ak `Pin` orijinal la.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Jwenn yon referans mutable nan done yo andedan sa a `Pin`.
    ///
    /// # Safety
    ///
    /// Fonksyon sa a pa an sekirite.
    /// Ou dwe garanti ke ou pa janm ap deplase done yo soti nan referans a mutab ou resevwa lè ou rele fonksyon sa a, se konsa ke envariant yo sou kalite `Pin` la ka konfime.
    ///
    ///
    /// Si done yo kache se `Unpin`, `Pin::get_mut` yo ta dwe itilize olye.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Konstwi yon PIN nouvo pa kat valè enteryè a.
    ///
    /// Pou egzanp, si ou te vle jwenn yon `Pin` nan yon jaden nan yon bagay, ou ta ka itilize sa a jwenn aksè nan jaden sa a nan yon sèl liy nan kòd.
    /// Sepandan, gen plizyè gotchas ak "pinning projections" sa yo;
    /// al gade dokiman [`pin` module] la pou plis detay sou sijè sa a.
    ///
    /// # Safety
    ///
    /// Fonksyon sa a pa an sekirite.
    /// Ou dwe garanti ke done ou retounen yo pa pral deplase toutotan valè agiman an pa deplase (pa egzanp, paske li se youn nan jaden ki gen valè sa a), epi tou ke ou pa deplase soti nan agiman ou resevwa nan fonksyon enteryè a.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SEKIRITE: moun kap rele a responsab pou li pa deplase
        // valè soti nan referans sa a.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SEKIRITE: kòm valè `this` garanti pa genyen
        // te deplase soti, apèl sa a `new_unchecked` san danje.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Jwenn yon referans estime soti nan yon referans estatik.
    ///
    /// Sa a san danje, paske `T` prete pou tout lavi `'static`, ki pa janm fini.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SEKIRITE: 'Estatik prete garanti done yo pa pral
        // moved/invalidated jiskaske li vin tonbe (ki pa janm).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Jwenn yon estime referans mutable ki sòti nan yon referans estatik mutable.
    ///
    /// Sa a san danje, paske `T` prete pou tout lavi `'static`, ki pa janm fini.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SEKIRITE: 'Estatik prete garanti done yo pa pral
        // moved/invalidated jiskaske li vin tonbe (ki pa janm).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: sa vle di ke nenpòt impl nan `CoerceUnsized` ki pèmèt kontrent soti nan
// yon kalite ki enplike `Deref<Target=impl !Unpin>` nan yon kalite ki enplike `Deref<Target=Unpin>` pa solid.
// Nenpòt ki impl ta pwobableman dwe solid pou lòt rezon, menm si, se konsa nou jis bezwen pran swen pa pèmèt impls sa yo nan peyi nan std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}