//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Pi gwo pwen kòd valab yon `char` ka genyen.
    ///
    /// Yon `char` se yon [Unicode Scalar Value], ki vle di ke li se yon [Code Point], men se yo menm sèlman nan yon seri sèten.
    /// `MAX` se pi gwo pwen kòd valab ki se yon [Unicode Scalar Value] valab.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () yo itilize nan Unicode pou reprezante yon erè dekodaj.
    ///
    /// Li ka rive, pou egzanp, lè bay malad-fòme UTF-8 bytes [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Vèsyon an nan [Unicode](http://www.unicode.org/) ki pati yo Unicode nan `char` ak `str` metòd yo baze sou.
    ///
    /// Nouvo vèsyon Unicode yo lage regilyèman epi imedyatman tout metòd nan bibliyotèk estanda a depann sou Unicode yo mete ajou.
    /// Se poutèt sa, konpòtman an nan kèk `char` ak `str` metòd ak valè sa a chanje konstan sou tan.
    /// Sa a se *pa* konsidere yo dwe yon chanjman kraze.
    ///
    /// Se konplo a nimero vèsyon eksplike nan [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Kreye yon iteratè sou UTF-16 pwen yo kòd kode nan `iter`, retounen ranplasan unpaired kòm `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Ou ka jwenn yon dekodaj lossy pa ranplase rezilta `Err` ak karaktè ranplasman an:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Konvèti yon `u32` nan yon `char`.
    ///
    /// Remake byen ke tout `char` yo valab [`u32`] s, epi yo ka jete nan yon sèl ak
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Sepandan, ranvèse a pa vre: se pa tout valab [`u32`] ki valab`char`s.
    /// `from_u32()` ap retounen `None` si opinyon an se pa yon valè ki valab pou yon `char`.
    ///
    /// Pou yon vèsyon danjere nan fonksyon sa a ki inyore chèk sa yo, gade [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Retounen `None` lè opinyon an se pa yon `char` valab:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Konvèti yon `u32` nan yon `char`, inyore validite.
    ///
    /// Remake byen ke tout `char` yo valab [`u32`] s, epi yo ka jete nan yon sèl ak
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Sepandan, ranvèse a pa vre: se pa tout valab [`u32`] ki valab`char`s.
    /// `from_u32_unchecked()` pral inyore sa a, ak je fèmen jete nan `char`, pètèt kreye yon yon sèl envalid.
    ///
    ///
    /// # Safety
    ///
    /// Fonksyon sa a an sekirite, menm jan li ka konstwi valè `char` envalid.
    ///
    /// Pou yon vèsyon san danje nan fonksyon sa a, gade fonksyon [`from_u32`] la.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SEKIRITE: kontra sekirite a dwe konfime pa moun kap rele a.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Konvèti yon chif nan radix yo bay nan yon `char`.
    ///
    /// Yon 'radix' isit la pafwa yo rele tou yon 'base'.
    /// Yon radix de endike yon nimewo binè, yon radix dis, desimal, ak yon radix sèz, hexadecimal, pou bay kèk valè komen.
    ///
    /// Radis abitrè yo sipòte.
    ///
    /// `from_digit()` ap retounen `None` si opinyon an se pa yon chif nan radix yo bay la.
    ///
    /// # Panics
    ///
    /// Panics si yo bay yon radix pi gwo pase 36.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Dezimal 11 se yon chif sèl nan baz 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Retounen `None` lè opinyon an se pa yon chif:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Pase yon gwo radix, sa ki lakòz yon panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Tcheke si yon `char` se yon chif nan radix yo bay la.
    ///
    /// Yon 'radix' isit la pafwa yo rele tou yon 'base'.
    /// Yon radix de endike yon nimewo binè, yon radix dis, desimal, ak yon radix sèz, hexadecimal, pou bay kèk valè komen.
    ///
    /// Radis abitrè yo sipòte.
    ///
    /// Konpare ak [`is_numeric()`], fonksyon sa a sèlman rekonèt karaktè `0-9`, `a-z` ak `A-Z`.
    ///
    /// 'Digit' se defini yo dwe sèlman karaktè sa yo:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Pou yon konpreyansyon pi konplè sou 'digit', gade [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics si yo bay yon radix pi gwo pase 36.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Pase yon gwo radix, sa ki lakòz yon panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Konvèti yon `char` nan yon chif nan radix yo bay la.
    ///
    /// Yon 'radix' isit la pafwa yo rele tou yon 'base'.
    /// Yon radix de endike yon nimewo binè, yon radix dis, desimal, ak yon radix sèz, hexadecimal, pou bay kèk valè komen.
    ///
    /// Radis abitrè yo sipòte.
    ///
    /// 'Digit' se defini yo dwe sèlman karaktè sa yo:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Retounen `None` si `char` pa refere a yon chif nan radix yo bay la.
    ///
    /// # Panics
    ///
    /// Panics si yo bay yon radix pi gwo pase 36.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Pase yon rezilta ki pa gen chif nan echèk:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Pase yon gwo radix, sa ki lakòz yon panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // se kòd la fann isit la amelyore vitès ekzekisyon pou ka kote `radix` a se konstan ak 10 oswa pi piti
        //
        let val = if likely(radix <= 10) {
            // Si se pa yon chif, yo pral kreye yon nimewo ki pi gran pase radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Retounen yon iterasyon ki bay egzadecimal chape Unicode yon karaktè kòm `char`s.
    ///
    /// Sa a pral chape karaktè ak sentaks la Rust nan fòm lan `\u{NNNNNN}` kote `NNNNNN` se yon reprezantasyon egzadesimal.
    ///
    ///
    /// # Examples
    ///
    /// Kòm yon iteratè:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sèvi ak `println!` dirèkteman:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Tou de yo ekivalan a:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Sèvi ak `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // oswa-ing 1 asire ke pou c==0 kòd la kalkile ke yon chif yo ta dwe enprime ak (ki se menm bagay la) evite (31, 32) debòde a
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // endèks chif chif hex ki pi enpòtan an
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Yon vèsyon pwolonje nan `escape_debug` ki opsyonèlman pèmèt chape pwolonje grafèm pwen kod.
    /// Sa a pèmèt nou fòma karaktè tankou mak nonspacing pi bon lè yo ap nan kòmansman an nan yon fisèl.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Retounen yon iteratè ki bay kòd la sove literal nan yon karaktè kòm `char`s.
    ///
    /// Sa a pral chape karaktè yo menm jan ak aplikasyon yo `Debug` nan `str` oswa `char`.
    ///
    ///
    /// # Examples
    ///
    /// Kòm yon iteratè:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sèvi ak `println!` dirèkteman:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Tou de yo ekivalan a:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Sèvi ak `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Retounen yon iteratè ki bay kòd la sove literal nan yon karaktè kòm `char`s.
    ///
    /// Se default la chwazi ak yon patipri nan direksyon pou pwodwi literal ki legal nan yon varyete lang, ki gen ladan C++ 11 ak menm jan C-fanmi lang yo.
    /// Règ yo egzak yo se:
    ///
    /// * Tab sove tankou `\t`.
    /// * Retounen cha chape tankou `\r`.
    /// * Liy manje chape kòm `\n`.
    /// * Se yon sèl quote chape kòm `\'`.
    /// * Se doub quote chape kòm `\"`.
    /// * Backslash chape kòm `\\`.
    /// * Nenpòt karaktè nan seri 'printable ASCII' `0x20` .. `0x7e` enklizif pa chape.
    /// * Tout lòt karaktè yo bay ègzadimal Unicode chape;gade [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Kòm yon iteratè:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sèvi ak `println!` dirèkteman:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Tou de yo ekivalan a:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Sèvi ak `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Retounen kantite bytes `char` sa a ta bezwen si kode nan UTF-8.
    ///
    /// Nimewo sa a nan bytes se toujou ant 1 ak 4, enklizif.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Kalite `&str` garanti ke sa li yo se UTF-8, e konsa nou ka konpare longè li ta pran si chak pwen kòd te reprezante kòm yon `char` vs nan `&str` tèt li:
    ///
    ///
    /// ```
    /// // kòm karaktè
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // tou de ka reprezante kòm twa bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // kòm yon &str, de sa yo kode nan UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // nou ka wè ke yo pran sis bytes total ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... jis tankou &str la
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Retounen kantite inite kòd 16-bit `char` sa a ta bezwen si kode nan UTF-16.
    ///
    ///
    /// Gade dokiman pou [`len_utf8()`] pou plis eksplikasyon sou konsèp sa a.
    /// Fonksyon sa a se yon glas, men pou UTF-16 olye pou yo UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Kodifye karaktè sa a kòm UTF-8 nan tanpon byte yo bay la, epi retounen subslice tanpon an ki gen karaktè kode a.
    ///
    ///
    /// # Panics
    ///
    /// Panics si pezib la pa gwo ase.
    /// Yon tanpon nan longè kat se gwo ase yo ankode nenpòt `char`.
    ///
    /// # Examples
    ///
    /// Nan tou de egzanp sa yo, 'ß' pran de octets pou encoder.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Yon tanpon ki twò piti:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SEKIRITE: `char` se pa yon ranplasan, kidonk sa a valab UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Kodifye karaktè sa a kòm UTF-16 nan tanpon `u16` yo bay la, epi retounen subslice tanpon an ki gen karaktè kode a.
    ///
    ///
    /// # Panics
    ///
    /// Panics si pezib la pa gwo ase.
    /// Yon tanpon longè 2 gwo ase pou kode nenpòt `char`.
    ///
    /// # Examples
    ///
    /// Nan tou de egzanp sa yo, '𝕊' pran de `u16`s pou kode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Yon tanpon ki twò piti:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Retounen `true` si `char` sa a gen pwopriyete `Alphabetic`.
    ///
    /// `Alphabetic` ki dekri nan Chapit 4 (Pwopriyete karaktè) nan [Unicode Standard] la ak espesifye nan [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] la.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // lanmou se anpil bagay, men li pa alfabetik
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Retounen `true` si `char` sa a gen pwopriyete `Lowercase`.
    ///
    /// `Lowercase` ki dekri nan Chapit 4 (Pwopriyete karaktè) nan [Unicode Standard] la ak espesifye nan [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] la.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Plizyè Scripts Chinwa yo ak ponktiyasyon pa gen ka, e konsa:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Retounen `true` si `char` sa a gen pwopriyete `Uppercase`.
    ///
    /// `Uppercase` ki dekri nan Chapit 4 (Pwopriyete karaktè) nan [Unicode Standard] la ak espesifye nan [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] la.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Plizyè Scripts Chinwa yo ak ponktiyasyon pa gen ka, e konsa:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Retounen `true` si `char` sa a gen pwopriyete `White_Space`.
    ///
    /// `White_Space` espesifye nan [Unicode Character Database][ucd] [`PropList.txt`] la.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // yon espas ki pa kraze
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Retounen `true` si `char` sa a satisfè swa [`is_alphabetic()`] oswa [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Retounen `true` si `char` sa a gen kategori jeneral pou kòd kontwòl.
    ///
    /// Kòd kontwòl (pwen kòd ak kategori jeneral nan `Cc`) yo dekri nan Chapit 4 (Pwopriyete karaktè) nan [Unicode Standard] la ak espesifye nan [Unicode Character Database][ucd] [`UnicodeData.txt`] la.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// // U + 009C, chèn TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Retounen `true` si `char` sa a gen pwopriyete `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` ki dekri nan [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ak espesifye nan [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] la.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Retounen `true` si `char` sa a gen youn nan kategori jeneral pou chif yo.
    ///
    /// Kategori jeneral pou chif (`Nd` pou chif desimal, `Nl` pou lèt ki tankou karaktè nimerik, ak `No` pou lòt karaktè nimerik) yo espesifye nan [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Retounen yon iteratè ki bay kat miniskil `char` sa a kòm youn oswa plis
    /// `char`s.
    ///
    /// Si `char` sa a pa gen yon kat miniskil, iteratè a bay menm `char` la.
    ///
    /// Si `char` sa a gen yon kat miniskil yon sèl-a-yon sèl bay pa [Unicode Character Database][ucd] [`UnicodeData.txt`] a, iteratè a bay `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Si sa a `char` mande pou konsiderasyon espesyal (egzanp miltip `char`s) iteratè a bay`char` (yo) yo bay nan [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Operasyon sa a fè yon kat enkondisyonèl san yo pa adapte.Sa vle di, konvèsyon an endepandan de kontèks ak langaj.
    ///
    /// Nan [Unicode Standard] la, Chapit 4 (Pwopriyete karaktè) diskite sou kat ka an jeneral epi Chapit 3 (Conformance) diskite sou algorithm default pou konvèsyon ka a.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kòm yon iteratè:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sèvi ak `println!` dirèkteman:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Tou de yo ekivalan a:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Sèvi ak `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Pafwa rezilta a se plis pase yon karaktè:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Karaktè ki pa gen ni majiskil ni miniskil konvèti nan tèt yo.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Retounen yon iteratè ki bay kat majiskil `char` sa a kòm youn oswa plis
    /// `char`s.
    ///
    /// Si `char` sa a pa gen yon kat majuskul, iteratè a bay menm `char` la.
    ///
    /// Si `char` sa a gen yon kat majiskil yon sèl-a-yon sèl bay pa [Unicode Character Database][ucd] [`UnicodeData.txt`] a, iteratè a bay sa `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Si sa a `char` mande pou konsiderasyon espesyal (egzanp miltip `char`s) iteratè a bay`char` (yo) yo bay nan [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Operasyon sa a fè yon kat enkondisyonèl san yo pa adapte.Sa vle di, konvèsyon an endepandan de kontèks ak langaj.
    ///
    /// Nan [Unicode Standard] la, Chapit 4 (Pwopriyete karaktè) diskite sou kat ka an jeneral epi Chapit 3 (Conformance) diskite sou algorithm default pou konvèsyon ka a.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kòm yon iteratè:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sèvi ak `println!` dirèkteman:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Tou de yo ekivalan a:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Sèvi ak `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Pafwa rezilta a se plis pase yon karaktè:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Karaktè ki pa gen ni majiskil ni miniskil konvèti nan tèt yo.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Remak sou lokalite
    ///
    /// Nan Tik, ekivalan a nan 'i' nan Latin gen senk fòm olye pou yo de:
    ///
    /// * 'Dotless': I/ı, pafwa ekri ï
    /// * 'Dotted': İ/mwen
    ///
    /// Remake byen ke miniskil pwentiye an 'i' se menm bagay la kòm Latin lan.Se poutèt sa:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Valè `upper_i` isit la konte sou lang tèks la: si nou nan `en-US`, li ta dwe `"I"`, men si nou nan `tr_TR`, li ta dwe `"İ"`.
    /// `to_uppercase()` pa pran sa an kont, e konsa:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// kenbe atravè lang yo.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Tcheke si valè a nan ranje ASCII la.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Fè yon kopi valè a nan ekivalan ASCII majuskul li yo.
    ///
    /// Lèt ASCII 'a' a 'z' yo trase nan 'A' a 'Z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou majiskil valè a nan plas, sèvi ak [`make_ascii_uppercase()`].
    ///
    /// Pou majiskil karaktè ASCII nan adisyon a karaktè ki pa ASCII, sèvi ak [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Fè yon kopi valè a nan ASCII miniskil ekivalan li yo.
    ///
    /// Lèt ASCII 'A' a 'Z' yo trase nan 'a' a 'z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou miniskil valè an plas, sèvi ak [`make_ascii_lowercase()`].
    ///
    /// Pou miniskil karaktè ASCII nan adisyon a karaktè ki pa ASCII, sèvi ak [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Chèk ke de valè yo se yon ASCII ka-sansib matche ak.
    ///
    /// Ekivalan a `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Konvèti kalite sa a nan ASCII majiskil ekivalan an ka an plas.
    ///
    /// Lèt ASCII 'a' a 'z' yo trase nan 'A' a 'Z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou retounen yon nouvo valè majiskil san ou pa modifye yon sèl ki deja egziste a, sèvi ak [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Konvèti kalite sa a nan ASCII miniskil ekivalan li yo an plas.
    ///
    /// Lèt ASCII 'A' a 'Z' yo trase nan 'a' a 'z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou retounen yon nouvo valè miniskil san ou pa modifye yon sèl ki deja egziste a, sèvi ak [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Tcheke si valè a se yon karaktè alfabetik ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', oswa
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Tcheke si valè a se yon karaktè majiskil ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Chèk si valè a se yon karaktè miniskil ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Tcheke si valè a se yon karaktè ASCII alfanumerik:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', oswa
    /// - U + 0061 'a' ..=U + 007A 'z', oswa
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Chèk si valè a se yon chif ASCII desimal:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Tcheke si valè a se yon chif ekzasimal ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', oswa
    /// - U + 0041 'A' ..=U + 0046 'F', oswa
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Tcheke si valè a se yon karaktè ponktiyasyon ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, oswa
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, oswa
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, oswa
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Chèk si valè a se yon karaktè ASCII grafik:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Tcheke si valè a se yon karaktè espas blan ASCII:
    /// U + 0020 ESPAS, U + 0009 TAB ORIZONTAL, U + 000A LIY ALIMENTASYON, U + 000C FMM ALIMENTASYON, oswa U + 000D RETOUNEN.
    ///
    /// Rust itilize WhatWG Infra Creole a [definition of ASCII whitespace][infra-aw].Gen plizyè lòt definisyon nan itilizasyon lajè.
    /// Pou egzanp, [the POSIX locale][pct] gen ladan U + 000B VÈTIKAL TAB osi byen ke tout karaktè ki anwo yo, men-soti nan spesifikasyon la trè menm-[règ la default pou "field splitting" nan Bourne shell la][bfs] konsidere *sèlman* ESPAS, orizontal TAB, ak LIY FEED kòm espas blan.
    ///
    ///
    /// Si w ap ekri yon pwogram ki pral travay sou yon fòma dosye ki deja egziste, tcheke ki sa definisyon fòma a nan espas blan anvan ou sèvi ak fonksyon sa a.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Chèk si valè a se yon karaktè kontwòl ASCII:
    /// U + 0000 NUL ..=U + 001F SEPARATÈ INITE, oswa U + 007F efase.
    /// Remake byen ke pifò karaktè espas ASCII yo se karaktè kontwòl, men espas se pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Kodifye yon valè u32 anvan tout koreksyon kòm UTF-8 nan tanpon byte yo bay la, ak Lè sa a retounen subslice nan pezib la ki gen karaktè a kode.
///
///
/// Kontrèman ak `char::encode_utf8`, metòd sa a tou okipe pwen kod nan seri ranplasan an.
/// (Kreye yon `char` nan seri ranplasan an se UB.) Rezilta a valab [generalized UTF-8] men li pa valab UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics si pezib la pa gwo ase.
/// Yon tanpon nan longè kat se gwo ase yo ankode nenpòt `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Kodifye yon valè u32 anvan tout koreksyon kòm UTF-16 nan tanpon `u16` yo bay la, ak Lè sa a retounen subslice nan pezib la ki gen karaktè a kode.
///
///
/// Kontrèman ak `char::encode_utf16`, metòd sa a tou okipe pwen kod nan seri ranplasan an.
/// (Kreye yon `char` nan seri ranplasan an se UB.)
///
/// # Panics
///
/// Panics si pezib la pa gwo ase.
/// Yon tanpon longè 2 gwo ase pou kode nenpòt `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SEKIRITE: chak bra tcheke si gen ase Bits ekri nan
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP a tonbe nan
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Avyon siplemantè kraze nan ranplasan.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}