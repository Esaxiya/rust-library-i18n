//! Panic sipò pou libcore
//!
//! Bibliyotèk debaz la pa ka defini panike, men li *deklare* panike.
//! Sa vle di ke fonksyon yo andedan libcore yo pèmèt yo panic, men yo dwe itil yon en crate dwe defini panik pou libcore yo itilize.
//! Koòdone aktyèl la pou panike se:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Definisyon sa a pèmèt pou panike ak nenpòt mesaj jeneral, men li pa pèmèt pou li pap resevwa ak yon valè `Box<Any>`.
//! (`PanicInfo` jis gen yon `&(dyn Any + Send)`, pou ki nou ranpli nan yon valè egare nan `PanicInfo: : internal_constructor`.) Rezon ki fè la pou sa a se ke libcore pa gen dwa asiyen.
//!
//!
//! Modil sa a gen kèk lòt fonksyon panik, men sa yo se jis atik lang nesesè pou du a.Tout panics yo anvlope nan yon sèl fonksyon sa a.
//! Se senbòl aktyèl la deklare nan atribi `#[panic_handler]` la.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Aplikasyon an kache nan `panic!` macro libcore a lè pa gen okenn fòma yo itilize.
#[cold]
// pa janm aliye sof si panic_immediate_abort pou fè pou evite kòd gonfle nan sit sa yo apèl otank posib
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ki nesesè pa codegen pou panic sou debòde ak lòt `Assert` MIR terminatè
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Sèvi ak Arguments::new_v1 olye de format_args! ("{}", Expr) pou potansyèlman diminye gwosè anlè.
    // Format_args yo!macro sèvi ak Display trait str a ekri expr, ki rele Formatter::pad, ki dwe akomode tronkonik fisèl ak padding (menm si pa gen okenn itilize isit la).
    //
    // Sèvi ak Arguments::new_v1 ka pèmèt du a oblije Formatter::pad soti nan pwodiksyon an binè, ekonomize jiska yon kilobytes kèk.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // nesesè pou konst-evalye panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // ki nesesè pa codegen pou panic sou OOB array/slice aksè
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Aplikasyon an kache nan `panic!` macro libcore a lè fòma yo itilize.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // REMAK Fonksyon sa a pa janm travèse fwontyè a FFI;li nan yon apèl Rust-a-Rust ki vin rezoud nan fonksyon an `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SEKIRITE: `panic_impl` defini nan kòd Rust san danje e konsa san danje pou rele.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Fonksyon entèn pou `assert_eq!` ak `assert_ne!` makro
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}