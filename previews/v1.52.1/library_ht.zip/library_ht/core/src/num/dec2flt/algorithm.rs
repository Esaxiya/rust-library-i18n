//! Algoritm yo divès kalite soti nan papye a.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Kantite Bits siyifikatif nan Fp
const P: u32 = 64;

// Nou tou senpleman estoke apwoksimasyon ki pi bon pou *tout* ekspozan, se konsa varyab "h" la ak kondisyon ki asosye yo ka omisyon.
// Sa a echanj pèfòmans pou yon kilo kilobit nan espas.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Nan pifò achitekti, operasyon pwen k ap flote gen yon gwosè ti jan eksplisit, Se poutèt sa se presizyon nan kalkil la detèmine sou yon baz pou chak-operasyon.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Sou x86, x87 FPU a itilize pou operasyon flote si ekstansyon SSE/SSE2 yo pa disponib.
// x87 FPU a opere ak 80 Bits nan presizyon pa default, ki vle di ke operasyon yo pral awondi a 80 Bits sa ki lakòz doub awondi rive lè valè yo evantyèlman reprezante kòm
//
// 32/64 ti jan valè flote.Simonte sa a, mo kontwòl FPU a ka mete pou ke kalkil yo fèt nan presizyon yo vle.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Yon estrikti ki itilize pou prezève valè orijinal mo kontwòl FPU a, pou li ka retabli lè estrikti a tonbe.
    ///
    ///
    /// x87 FPU a se yon 16-Bits enskri ki gen jaden yo jan sa a:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokimantasyon pou tout jaden yo disponib nan Manyèl IA-32 Architectures Software Developer a (Volim 1).
    ///
    /// Sèl jaden ki enpòtan pou kòd sa a se PC, Kontwòl Precision.
    /// Jaden sa a detèmine presizyon nan operasyon yo fèt pa FPU la.
    /// Li ka mete nan:
    ///  - 0b00, yon sèl presizyon sa vle di, 32-Bits
    ///  - 0b10, doub presizyon sa vle di, 64-Bits
    ///  - 0b11, doub pwolonje presizyon sa vle di, 80-Bits (eta default) Valè 0b01 la rezève epi yo pa ta dwe itilize.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SEKIRITE: enstriksyon `fldcw` la te kontrole pou kapab travay kòrèkteman avèk li
        // nenpòt `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Nou ap itilize sentaks ATT pou sipòte LLVM 8 ak LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Mete jaden an presizyon nan FPU a `T` epi retounen yon `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Kalkile valè pou jaden kontwòl presizyon ki apwopriye pou `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 Bits
            8 => 0x0200, // 64 Bits
            _ => 0x0300, // default, 80 Bits
        };

        // Jwenn valè orijinal la nan mo kontwòl la retabli li pita, lè estrikti a `FPUControlWord` tonbe SEKIRITE: enstriksyon an `fnstcw` te verifye pou kapab travay kòrèkteman ak nenpòt `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Nou ap itilize sentaks ATT pou sipòte LLVM 8 ak LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Mete mo kontwòl la presizyon ou vle a.
        // Sa a se reyalize pa maskin lwen presizyon nan fin vye granmoun (Bits 8 ak 9, 0x300) ak ranplase li ak drapo a presizyon kalkile pi wo a.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Chemen an vit nan Bellerophon lè l sèvi avèk antye antye machin ki menm gwosè ak flote.
///
/// Sa a se ekstrè nan yon fonksyon separe pou ke li ka eseye anvan yo konstwi yon bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Nou konpare valè egzak la nan MAX_SIG tou pre fen a, sa a se jis yon rapid, rejè bon mache (epi tou li libere rès la nan kòd la soti nan mangonmen sou debòde).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Chemen an vit absoliman depann sou aritmetik ke yo te awondi nan nimewo ki kòrèk la nan Bits san yo pa nenpòt enteryè enteryè.
    // Sou x86 (san SSE oswa SSE2) sa mande pou presizyon nan pil x87 FPU a chanje pou li dirèkteman jij 64/32 ti jan.
    // Fonksyon `set_precision` la pran swen nan mete presizyon an sou achitekti ki mande pou mete li pa chanje eta mondyal la (tankou mo kontwòl la nan x87 FPU la).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ka a <0 pa ka pliye nan lòt branch la.
    // Pouvwa negatif rezilta nan yon pati repete fraksyon nan binè, ki fè yo awondi, ki lakòz reyèl (epi detanzantan byen enpòtan!) Erè nan rezilta final la.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritm Bellerophon se kòd trivial jistifye pa analiz nimerik ki pa trivial.
///
/// Li jij "f" nan yon flote ak 64 ti jan siyifikatif ak miltipliye li pa apwoksimasyon ki pi bon nan `10^e` (nan menm fòma pwen k ap flote).Sa a se souvan ase yo ka resevwa rezilta ki kòrèk la.
/// Sepandan, lè rezilta a fèmen nan mwatye wout ant de flote (ordinary) adjasan, erè awondi konpoze soti nan miltipliye de apwoksimasyon vle di rezilta a ka koupe pa yon Bits kèk.
/// Lè sa rive, Algoritm iteratif R ranje bagay yo.
///
/// Men-tranble "close to halfway" la te fè egzak pa analiz nimerik nan papye a.
/// Nan mo Clinger:
///
/// > Slop, ki eksprime nan inite nan ti jan pi piti a enpòtan, se yon enklizif mare pou erè a
/// > akimile pandan kalkil la pwen k ap flote nan apwoksimasyon nan f * 10 ^ e.(Slop se
/// > pa yon limit pou erè a vre, men limit diferans ki genyen ant apwoksimasyon z ak
/// > meyè apwoksimasyon posib ki sèvi ak p moso nan siyifikasyon.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Ka abs(e) <log5(2^N) yo nan fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Èske pant lan gwo ase pou fè yon diferans lè awondi nan n Bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Yon algorithm iteratif ki amelyore yon apwoksimasyon pwen k ap flote nan `f * 10^e`.
///
/// Chak iterasyon vin yon sèl inite nan dènye plas la pi pre, ki nan kou pran fò anpil tan konvèje si `z0` se menm léjèrman koupe.
/// Chans, lè yo itilize kòm fallback pou Bellerophon, apwoksimasyon an kòmanse se pa nan pi yon sèl ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Jwenn nonb antye relatif pozitif `x`, `y` tankou `x / y` se egzakteman `(f *10^e) / (m* 2^k)`.
        // Sa a pa sèlman evite fè fas ak siy `e` ak `k`, nou menm tou nou elimine pouvwa a nan de komen nan `10^e` ak `2^k` fè nimewo yo pi piti.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Sa a se ekri yon ti jan gòch paske bignums nou yo pa sipòte nimewo negatif, se konsa nou itilize valè a absoli + enfòmasyon siy.
        // Miltiplikasyon ak m_digits pa ka debòde.
        // Si `x` oswa `y` yo ase gwo ke nou bezwen enkyete sou debòde, Lè sa a, yo menm tou yo gwo ase ke `make_ratio` te redwi fraksyon an pa yon faktè de 2 ^ 64 oswa plis.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Pa bezwen x ankò, sove yon clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Toujou bezwen y, fè yon kopi.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Etandone `x = f` ak `y = m` kote `f` reprezante chif desimal kòm dabitid epi `m` se siyifikasyon yon apwoksimasyon pwen k ap flote, fè rapò `x / y` egal a `(f *10^e) / (m* 2^k)`, petèt redwi pa yon pouvwa de tou de gen an komen.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, eksepte ke nou diminye fraksyon an pa kèk pouvwa de.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Sa pa ka debòde paske li mande pou `e` pozitif ak `k` negatif, ki ka rive sèlman pou valè ki trè pre 1, ki vle di ke `e` ak `k` pral relativman ti.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Sa pa ka debòde tou, gade anwo a.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), ankò diminye pa yon pouvwa komen nan de.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Conceptual, Algoritm M se fason ki pi senp pou konvèti yon desimal nan yon flote.
///
/// Nou fòme yon rapò ki egal a `f * 10^e`, Lè sa a, voye nan pouvwa nan de jiskaske li bay yon siyifik valab flote.
/// Ekspozan binè `k` se kantite fwa nou miltipliye nimeratè oswa denominatè pa de, sa vle di, nan tout tan `f *10^e` egal `(u / v)* 2^k`.
/// Lè nou te jwenn soti siyifikasyon, nou sèlman bezwen wonn pa enspekte rès la nan divizyon an, ki se fè nan fonksyon k'ap ede pi lwen anba a.
///
///
/// Algoritm sa a super dousman, menm avèk optimize ki dekri nan `quick_start()`.
/// Sepandan, li pi senp nan algoritm yo pou adapte pou debòde, debòde, ak rezilta subnormal.
/// Aplikasyon sa a pran plis pase lè Bellerophon ak Algorithm R yo akable.
/// Detekte debòde ak debòde fasil: Rapò a toujou se pa yon siyifikasyon nan-ranje, ankò ekspozan minimum/maximum la te rive jwenn.
/// Nan ka debòde, nou tou senpleman retounen Infinity.
///
/// Manyen debòde ak subnormals se pi difisil.
/// Yon gwo pwoblèm se ke, ak ekspozan minimòm lan, rapò a ta ka toujou twò gwo pou yon siyifikasyon.
/// Gade underflow() pou plis detay.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME posib optimize: jeneralize big_to_fp pou nou ka fè ekivalan a fp_to_float(big_to_fp(u)) isit la, sèlman san yo pa doub awondi la.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Nou dwe kanpe nan ekspozan minimòm lan, si nou rete tann jiskaske `k < T::MIN_EXP_INT`, Lè sa a, nou ta dwe koupe pa yon faktè de.
            // Malerezman sa vle di nou dwe espesyal-ka nimewo nòmal ak ekspozan minimòm lan.
            // FIXME jwenn yon fòmilasyon pi elegant, men kouri tès la `tiny-pow10` asire w ke li aktyèlman kòrèk!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Sote sou pifò algorithm M iterasyon pa tcheke longè a ti jan.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Longè a ti jan se yon estimasyon de baz la de logaritm, ak log(u / v) = log(u), log(v).
    // Estimasyon an se koupe pa nan pifò 1, men toujou yon under-estimasyon, se konsa erè a sou log(u) ak log(v) yo nan menm siy la ak anile soti (si tou de yo gwo).
    // Se poutèt sa, erè a pou log(u / v) se nan pi yon sèl kòm byen.
    // Rapò sib la se youn kote u/v se nan yon siyifikasyon nan-ranje.Se konsa, kondisyon revokasyon nou an se log2(u / v) ke yo te Bits yo significand, plus/minus yon sèl.
    // FIXME Gade nan ti jan an dezyèm te kapab amelyore estimasyon an, epi evite kèk divizyon plis.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow oswa subnormal.Kite li nan fonksyon prensipal la.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Debòde.Kite li nan fonksyon prensipal la.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Pwopòsyon se pa yon siyifikasyon nan-ranje ak ekspozan minimòm lan, kidonk nou bezwen awondi Bits depase epi ajiste ekspozan an kòmsadwa.
    // Valè reyèl la kounye a sanble tankou sa a:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(reprezante pa rem)
    //
    // Se poutèt sa, lè Bits yo awondi-off yo!= 0.5 ULP, yo deside awondi a sou pwòp yo.
    // Lè yo egal ak rès la ki pa zewo, valè a toujou bezwen awondi.
    // Se sèlman lè awondi Bits yo 1/2 ak rès la se zewo, nou gen yon sitiyasyon demi-a-menm.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Rounddinè wonn-a-menm, toufe pa gen wonn ki baze sou rès la nan yon divizyon.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}