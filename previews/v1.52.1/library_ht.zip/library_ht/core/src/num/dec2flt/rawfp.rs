//! Bit jwe sou pozitif IEEE 754 flote.Nimewo negatif yo pa bezwen epi yo pa bezwen okipe yo.
//! Nimewo nòmal pwen k ap flote gen yon reprezantasyon kanonik tankou (frac, exp) tankou valè a se 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) kote N se kantite Bits.
//!
//! Subnormals yo se yon ti kras diferan ak etranj, men prensip la menm aplike.
//!
//! Isit la, sepandan, nou reprezante yo kòm (sig, k) ak f pozitif, tankou valè a se f *
//! 2 <sup>e</sup> .Anplis fè "hidden bit" la eksplisit, sa chanje ekspozan an pa sa yo rele chanjman mantissa la.
//!
//! Mete yon lòt fason, nòmalman flote yo ekri kòm (1) men isit la yo ekri kòm (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Nou rele (1)**reprezantasyon an fraksyon** ak (2)**reprezantasyon an entegral**.
//!
//! Anpil fonksyon nan modil sa a sèlman okipe nimewo nòmal.Woutin yo dec2flt konsèvativman pran chemen an inivèsèl-kòrèk ralanti (Algoritm M) pou anpil ti ak anpil gwo nimewo.
//! Sa algorithm bezwen sèlman next_float() ki fè fas ak subnormals ak zewo.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Yon trait k'ap vin ede pou evite kopi fondamantalman tout kòd konvèsyon pou `f32` ak `f64`.
///
/// Gade kòmantè doc modil paran an poukisa sa nesesè.
///
/// Ta dwe **pa janm janm** dwe aplike pou lòt kalite oswa yo dwe itilize deyò modil la dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Kalite itilize pa `to_bits` ak `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Fè yon transmutasyon anvan tout koreksyon nan yon nonb antye relatif.
    fn to_bits(self) -> Self::Bits;

    /// Fè yon transmutasyon anvan tout koreksyon ki sòti nan yon nonb antye relatif.
    fn from_bits(v: Self::Bits) -> Self;

    /// Retounen kategori nimewo sa a tonbe nan.
    fn classify(self) -> FpCategory;

    /// Retounen mantissa, ekspozan ak siy kòm nonm antye relatif.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dekode flote la.
    fn unpack(self) -> Unpacked;

    /// Distribisyon ki sòti nan yon nonb antye relatif ki ka reprezante egzakteman.
    /// Panic si nonb antye relatif la pa ka reprezante, lòt kòd la nan modil sa a asire w ke ou pa janm kite sa rive.
    fn from_int(x: u64) -> Self;

    /// Jwenn valè a 10 <sup>e</sup> soti nan yon tab pre-calculée.
    /// Panics pou `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ki sa ki non an di.
    /// Li pi fasil pou kòd difisil pase jungle intrinsèques ak espwa LLVM konstan pliye li.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Yon konsèvatif mare sou chif yo desimal nan entrain ki pa ka pwodwi debòde oswa zewo oswa
    /// subnormal.Pwobableman ekspozan desimal valè maksimòm nòmal la, pakonsekan non an.
    const MAX_NORMAL_DIGITS: usize;

    /// Lè chif desimal ki pi enpòtan an gen yon valè plas ki pi gran pase sa a, nimewo a sètènman awondi a Infini.
    ///
    const INF_CUTOFF: i64;

    /// Lè chif desimal ki pi enpòtan an gen yon valè plas mwens pase sa a, nimewo a sètènman awondi a zewo.
    ///
    const ZERO_CUTOFF: i64;

    /// Nimewo a nan Bits nan ekspozan an.
    const EXP_BITS: u8;

    /// Nimewo a nan Bits nan siyifikasyon an,*ki gen ladan* ti jan an kache.
    const SIG_BITS: u8;

    /// Nimewo a nan Bits nan siyifikasyon an,*eksepte* ti jan an kache.
    const EXPLICIT_SIG_BITS: u8;

    /// Ekspozan maksimòm legal la nan reprezantasyon fraksyon.
    const MAX_EXP: i16;

    /// Eksponan legal la minimòm nan reprezantasyon fraksyon, eksepte subnormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` pou reprezantasyon entegral, sa vle di, ak chanjman an aplike.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kode (sa vle di, ak konpanse patipri)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` pou reprezantasyon entegral, sa vle di, ak chanjman an aplike.
    const MIN_EXP_INT: i16;

    /// Maksimòm normaland siyifikasyon nan reprezantasyon entegral.
    const MAX_SIG: u64;

    /// Minimize normaland siyifikasyon nan reprezantasyon entegral.
    const MIN_SIG: u64;
}

// Sitou yon solisyon pou #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Retounen mantissa, ekspozan ak siy kòm nonm antye relatif.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Ekspozan patipri + mantissa chanjman
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ensèten si `as` jij kòrèkteman sou tout tribin.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Retounen mantissa, ekspozan ak siy kòm nonm antye relatif.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Ekspozan patipri + mantissa chanjman
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ensèten si `as` jij kòrèkteman sou tout tribin.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konvèti yon `Fp` nan kalite ki pi pre machin flote.
/// Pa okipe rezilta subnormal.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f se 64 ti jan, se konsa xe gen yon chanjman mantissa nan 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Awondi siyifikasyon an 64-bit T::SIG_BITS Bits ak demi-a-menm.
/// Pa okipe debòde ekspozan.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ajiste chanjman mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Envès nan `RawFloat::unpack()` pou nimewo nòmalize.
/// Panics si siyifikasyon an oswa ekspozan yo pa valab pou nimewo nòmalize yo.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Retire ti jan kache a
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ajiste ekspozan an pou patipri ekspozan ak chanjman mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Kite ti jan siy nan 0 ("+"), nimewo nou yo tout pozitif
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstwi yon subnormal.Yon mantissa nan 0 pèmèt ak konstwi zewo.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Ekspozan kode se 0, ti jan an siy se 0, se konsa nou jis gen reentèrprete Bits yo.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Apeprè yon bignum ak yon Fp.Wonn nan 0.5 ULP ak demi-a-menm.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Nou koupe tout Bits anvan endèks la `start`, sa vle di, nou efektivman dwa-chanjman pa yon kantite lajan nan `start`, kidonk sa a se tou ekspozan a nou bezwen.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) depann sou Bits yo tronkonik.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Jwenn pi gwo nimewo pwen k ap flote estrikteman pi piti pase agiman an.
/// Pa okipe subnormals, zewo, oswa ekspozan debòde.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Jwenn nimewo ki pi piti pwen k ap flote estrikteman pi gwo pase agiman an.
// Operasyon sa a satire, sa vle di, next_float(inf) ==inf.
// Kontrèman ak pifò kòd nan modil sa a, fonksyon sa a okipe zewo, subnormals, ak enfini.
// Sepandan, tankou tout lòt kòd isit la, li pa fè fas ak NaN ak nimewo negatif.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Sa sanble twò bon pou se ta laverite, men li mache.
        // 0.0 se kode kòm pawòl Bondye a tout-zewo.Subnormals yo 0x000m ... m kote m se mantissa la.
        // An patikilye, subnormal ki pi piti a se 0x0 ... 01 ak pi gwo a se 0x000F ... F.
        // Pi piti nimewo nòmal la se 0x0010 ... 0, kidonk ka kwen sa a mache tou.
        // Si enkreman an debòde mantissa a, ti jan pote a ogmante ekspozan a jan nou vle, ak bit mantissa yo vin zewo.
        // Paske nan konvansyon an ti jan kache, sa a tou se egzakteman sa nou vle!
        // Finalman, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}