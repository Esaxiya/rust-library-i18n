//! Valide ak dekonpoze yon fisèl desimal nan fòm lan:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Nan lòt mo, estanda sentaks k ap flote-pwen, ak de eksepsyon: Pa gen siy, e pa gen okenn manyen nan "inf" ak "NaN".Sa yo se manyen pa fonksyon chofè (super::dec2flt) la.
//!
//! Malgre ke rekonèt opinyon valab se relativman fasil, modil sa a tou te rejte inonbrabl varyasyon yo envalid, pa janm panic, ak fè chèk anpil ki modil yo lòt konte sou yo pa panic (oswa debòde) nan vire.
//!
//! Pou fè zafè vin pi mal, tout sa k ap pase nan yon pas sèl sou opinyon an.
//! Se konsa, fè atansyon lè w ap modifye anyen, epi tcheke doub ak modil yo ak lòt.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Pati ki enteresan nan yon fisèl desimal.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Ekspozan desimal la, garanti li gen mwens pase 18 chif desimal.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Tcheke si fisèl la opinyon se yon nimewo valab pwen k ap flote epi si se konsa, jwenn pati entegral la, pati nan fraksyon, ak ekspozan a nan li.
/// Pa okipe siy.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Pa gen chif anvan 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Nou mande pou omwen yon chif sèl anvan oswa apre pwen an.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Fin tenten apre pati fraksyon
            }
        }
        _ => Invalid, // Fin tenten apre premye chif fisèl
    }
}

/// Dekoupe chif desimal jiska premye karaktè ki pa chif.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Ekstraksyon eleman ak tcheke erè.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Fin tenten apre ekspozan
    }
    if number.is_empty() {
        return Invalid; // Ekspozan vid
    }
    // Nan pwen sa a, nou sètènman gen yon fisèl ki valab nan chif.Li ka twò lontan yo mete nan yon `i64`, men si li nan ki gwo, opinyon an se sètènman zewo oswa Infinity.
    // Depi chak zewo nan chif desimal yo sèlman ajiste ekspozan an pa +/-1, nan exp=10 ^ 18 opinyon an ta dwe 17 exabyte (!) nan zewo yo ka resevwa menm adistans fèmen nan yo te fini.
    //
    // Sa a se pa egzakteman yon ka itilize nou bezwen founi yo.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}