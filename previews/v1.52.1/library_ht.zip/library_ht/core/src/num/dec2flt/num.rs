//! Fonksyon sèvis piblik pou bignums ki pa fè twòp sans pou tounen metòd.

// FIXME Non modil sa a se yon ti jan malere, depi lòt modil tou enpòte `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Teste si tronke tout Bits mwens enpòtan pase `ones_place` entwodui yon erè relatif mwens, egal, oswa pi gran pase 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Si tout Bits ki rete yo se zewo, li nan= 0.5 ULP, otreman> 0.5 Si pa gen okenn Bits plis (half_bit==0), anba a tou kòrèkteman retounen egal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Konvèti yon fisèl ASCII ki gen sèlman chif desimal nan yon `u64`.
///
/// Pa fè chèk pou debòde oswa karaktè envalid, kidonk si moun kap rele a pa pran prekosyon, rezilta a se fos epi yo ka panic (menm si li pa pral `unsafe`).
/// Anplis de sa, fisèl vid yo trete kòm zewo.
/// Fonksyon sa a egziste paske
///
/// 1. lè l sèvi avèk `FromStr` sou `&[u8]` mande pou `from_utf8_unchecked`, ki se move, ak
/// 2. piecing ansanm rezilta yo nan `integral.parse()` ak `fractional.parse()` se pi konplike pase fonksyon sa a tout antye.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Konvèti yon fisèl chif ASCII nan yon bignum.
///
/// Tankou `from_str_unchecked`, fonksyon sa a depann sou analyser a raje soti ki pa gen chif.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Déblotché yon bignum nan yon nonb antye relatif 64 ti jan.Panics si nimewo a twò gwo.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Ekstrè yon seri de Bits.

/// Endèks 0 se ti jan ki pi piti a ak seri a demi-louvri kòm dabitid.
/// Panics si yo mande yo ekstrè Bits plis pase anfòm nan kalite a retounen.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}