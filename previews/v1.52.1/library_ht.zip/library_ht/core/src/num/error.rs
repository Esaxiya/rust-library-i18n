//! Kalite Erè pou konvèsyon nan kalite entegral.

use crate::convert::Infallible;
use crate::fmt;

/// Kalite erè a retounen lè yon konvèsyon kalite entegral tcheke echwe.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Koresponn ak olye ke fòse asire ke kòd tankou `From<Infallible> for TryFromIntError` pi wo a ap kontinye travay lè `Infallible` vin tounen yon alyas `!`.
        //
        //
        match never {}
    }
}

/// Yon erè ki ka retounen lè analize yon nonb antye relatif.
///
/// Sa a se erè itilize kòm kalite a erè pou fonksyon yo `from_str_radix()` sou kalite yo nonb antye relatif primitif, tankou [`i8::from_str_radix`].
///
/// # Kòz potansyèl yo
///
/// Pami lòt kòz, `ParseIntError` ka jete paske nan dirijan oswa blanch espas nan fisèl la egzanp, lè li se jwenn nan opinyon an estanda.
///
/// Lè l sèvi avèk metòd la [`str::trim()`] asire ke pa gen okenn espas blan rete anvan par.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum nan magazen divès kalite erè ki ka lakòz analize yon nonb antye relatif echwe.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Valè analize a vid.
    ///
    /// Pami lòt kòz, yo pral Variant sa a ap konstwi lè analize yon fisèl vid.
    Empty,
    /// Gen yon chif ki pa valab nan kontèks li.
    ///
    /// Pami lòt kòz, yo pral Variant sa a ap konstwi lè analize yon fisèl ki gen yon char ki pa ASCII.
    ///
    /// Variant sa a konstwi tou lè se yon `+` oswa `-` ki deplace nan yon fisèl swa sou pwòp li yo oswa nan mitan yon nimewo.
    ///
    ///
    InvalidDigit,
    /// Nonb antye relatif twò gwo nan magazen nan kalite antye sib.
    PosOverflow,
    /// Nonb antye relatif la twò piti nan magazen nan kalite antye sib.
    NegOverflow,
    /// Valè te zewo
    ///
    /// Variant sa a pral emèt lè fisèl la analiz gen yon valè de zewo, ki ta ilegal pou kalite ki pa zewo.
    ///
    Zero,
}

impl ParseIntError {
    /// Rezilta kòz detaye sou analiz yon nonb antye relatif echwe.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}