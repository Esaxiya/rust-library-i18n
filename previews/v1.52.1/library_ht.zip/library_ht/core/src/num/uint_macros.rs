macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Valè ki pi piti a ki ka reprezante pa kalite nonb antye relatif la.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Pi gwo valè ki ka reprezante pa kalite nonb antye relatif la.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Gwosè a nan kalite sa a nonb antye relatif an Bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konvèti yon tranch fisèl nan yon baz yo bay nan yon nonb antye relatif.
        ///
        /// Fisèl la espere yon siy si ou vle `+` ki te swiv pa chif.
        ///
        /// Dirijan ak blanch espas reprezante yon erè.
        /// Chif yo se yon sou nan karaktè sa yo, tou depann de `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Fonksyon sa a panics si `radix` pa nan seri de 2 a 36.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Retounen kantite moun ki nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Retounen kantite zewo nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Retounen kantite zewo dirijan nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Retounen kantite zewo final nan reprezantasyon binè `self`.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Retounen kantite dirijan nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Retounen kantite moun ki fin nan reprezantasyon binè `self`.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Chanje Bits yo sou bò gòch la pa yon kantite lajan espesifye, `n`, anbalaj Bits yo tronke nan fen antye relatif la ki kapab lakòz.
        ///
        ///
        /// Tanpri sonje sa a se pa operasyon an menm jan ak operatè a déplacement `<<`!
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Chanje Bits yo sou bò dwat la pa yon kantite lajan espesifye, `n`, vlope Bits yo tronke nan konmansman an nan antye relatif la ki kapab lakòz.
        ///
        ///
        /// Tanpri sonje sa a se pa operasyon an menm jan ak operatè a déplacement `>>`!
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Ranvèse lòd byte nan nonb antye relatif la.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// kite m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Ranvèse lòd Bits nan nonb antye relatif la.
        /// Ti jan ki pi piti a vin ti bit ki pi enpòtan an, dezyèm ti bit ki pi enpòtan an vin dezyèm ti bit ki pi enpòtan an, elatriye.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// kite m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Konvèti yon nonb antye relatif ki soti nan endian gwo endianness sib la.
        ///
        /// Sou Endian gwo sa a se yon pa gen okenn-op.
        /// Sou ti endian bytes yo échanges.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } lòt bagay {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konvèti yon nonb antye relatif ki soti nan ti endian nan endianness sib la.
        ///
        /// Sou ti endian sa a se yon pa gen okenn-op.
        /// Sou gwo endian bytes yo échanges.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } lòt bagay {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Konvèti `self` an gwo endian soti nan endianness sib la.
        ///
        /// Sou Endian gwo sa a se yon pa gen okenn-op.
        /// Sou ti endian bytes yo échanges.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } Lòt bagay { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // oswa ou pa dwe?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Konvèti `self` an ti endian soti nan endianness sib la.
        ///
        /// Sou ti endian sa a se yon pa gen okenn-op.
        /// Sou gwo endian bytes yo échanges.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } Lòt bagay { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Tcheke adisyon antye relatif.
        /// Kalkile `self + rhs`, retounen `None` si debòde ki te fèt.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Anplis de sa non antye relatif.Kalkile `self + rhs`, an konsideran debòde pa ka rive.
        /// Sa rezilta nan konpòtman endefini lè
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Tcheke soustraksyon antye antye.
        /// Kalkile `self - rhs`, retounen `None` si debòde ki te fèt.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Soustraksyon non antye relatif.Kalkile `self - rhs`, an konsideran debòde pa ka rive.
        /// Sa rezilta nan konpòtman endefini lè
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Tcheke miltiplikasyon antye relatif.
        /// Kalkile `self * rhs`, retounen `None` si debòde ki te fèt.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Miltiplikasyon nonb antye relatif.Kalkile `self * rhs`, an konsideran debòde pa ka rive.
        /// Sa rezilta nan konpòtman endefini lè
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Tcheke divizyon nonm antye relatif.
        /// Kalkile `self / rhs`, retounen `None` si `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SEKIRITE: div pa zewo te tcheke pi wo a ak kalite non pa gen lòt
                // echèk mòd pou divizyon
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Tcheke divizyon eklidyen.
        /// Kalkile `self.div_euclid(rhs)`, retounen `None` si `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Tcheke rès nonb antye relatif.
        /// Kalkile `self % rhs`, retounen `None` si `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SEKIRITE: div pa zewo te tcheke pi wo a ak kalite non pa gen lòt
                // echèk mòd pou divizyon
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Tcheke modil Euclidean.
        /// Kalkile `self.rem_euclid(rhs)`, retounen `None` si `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Tcheke negasyon.Kalkile `-self`, retounen `None` sof si `pwòp tèt ou==
        /// 0`.
        ///
        /// Remake byen ke negasyon nenpòt ki antye relatif pozitif pral debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tcheke chanjman agoch.
        /// Kalkile `self << rhs`, retounen `None` si `rhs` pi gwo pase oswa egal a kantite Bits nan `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tcheke chanjman dwat.
        /// Kalkile `self >> rhs`, retounen `None` si `rhs` pi gwo pase oswa egal a kantite Bits nan `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tcheke eksponansyasyon.
        /// Kalkile `self.pow(exp)`, retounen `None` si debòde ki te fèt.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // depi exp!=0, finalman exp la dwe 1.
            // Fè fas ak ti jan final la nan ekspozan a separeman, depi kare baz la apre sa pa nesesè epi yo ka lakòz yon debòde initil.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturation adisyon antye relatif.
        /// Kalkile `self + rhs`, satire nan limit nimerik olye pou yo debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Saturation soustraksyon antye antye.
        /// Kalkile `self - rhs`, satire nan limit nimerik olye pou yo debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Saturation miltiplikasyon antye relatif.
        /// Kalkile `self * rhs`, satire nan limit nimerik olye pou yo debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Eksponansyasyon antye relatif satire.
        /// Kalkile `self.pow(exp)`, satire nan limit nimerik olye pou yo debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Anbalaj (modular) adisyon.
        /// Kalkile `self + rhs`, anbalaj nan fwontyè kalite a.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Anbalaj (modular) soustraksyon.
        /// Kalkile `self - rhs`, anbalaj nan fwontyè kalite a.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Anbalaj miltiplikasyon (modular).
        /// Kalkile `self * rhs`, anbalaj nan fwontyè kalite a.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// Tanpri sonje ke egzanp sa a pataje ant kalite nonb antye relatif.
        /// Ki eksplike poukisa `u8` yo itilize isit la.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Anbalaj (modular) divizyon.Kalkile `self / rhs`.
        /// Vlope divizyon sou kalite non se jis divizyon nòmal.
        /// Pa gen okenn fason anbalaj ka janm rive.
        /// Fonksyon sa a egziste, se konsa ke tout operasyon yo matirite pou nan operasyon yo anbalaj.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Anbalaj divizyon eklidyen.Kalkile `self.div_euclid(rhs)`.
        /// Vlope divizyon sou kalite non se jis divizyon nòmal.
        /// Pa gen okenn fason anbalaj ka janm rive.
        /// Fonksyon sa a egziste, se konsa ke tout operasyon yo matirite pou nan operasyon yo anbalaj.
        /// Depi, pou nonm antye relatif yo pozitif, tout definisyon komen nan divizyon yo egal, sa a se egzakteman egal a `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Vlope (modular) rès.Kalkile `self % rhs`.
        /// Vlope kalkil rès sou kalite ki pa siyen se jis kalkil rès regilye a.
        ///
        /// Pa gen okenn fason anbalaj ka janm rive.
        /// Fonksyon sa a egziste, se konsa ke tout operasyon yo matirite pou nan operasyon yo anbalaj.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Anbalaj modil Euclidean.Kalkile `self.rem_euclid(rhs)`.
        /// Vlope kalkil modulo sou kalite ki pa siyen se jis kalkil rès regilye a.
        /// Pa gen okenn fason anbalaj ka janm rive.
        /// Fonksyon sa a egziste, se konsa ke tout operasyon yo matirite pou nan operasyon yo anbalaj.
        /// Depi, pou nonm antye relatif yo pozitif, tout definisyon komen nan divizyon yo egal, sa a se egzakteman egal a `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Anbalaj (modular) negasyon.
        /// Kalkile `-self`, anbalaj nan fwontyè kalite a.
        ///
        /// Depi kalite non pa gen ekivalan negatif tout aplikasyon nan fonksyon sa a pral vlope (eksepte pou `-0`).
        /// Pou valè ki pi piti pase maksimòm ki koresponn lan siyen rezilta a se menm bagay la kòm depoze valè ki koresponn lan siyen.
        ///
        /// Nenpòt pi gwo valè yo ekivalan a `MAX + 1 - (val - MAX - 1)` kote `MAX` se maksimòm ki koresponn lan siyen an.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// Tanpri sonje ke egzanp sa a pataje ant kalite nonb antye relatif.
        /// Ki eksplike poukisa `i8` yo itilize isit la.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-gratis bit-gòch;
        /// pwodiksyon `self << mask(rhs)`, kote `mask` retire nenpòt Bits-wo lòd nan `rhs` ki ta lakòz chanjman nan depase Pleasant nan kalite la.
        ///
        /// Remake byen ke sa a se *pa* menm jan ak yon Thorne-bò gòch;se RHS la nan yon anbalaj chanjman-gòch restriksyon nan seri a nan kalite a, olye ke Bits yo deplase soti nan LHS la ke yo te retounen nan fen a lòt.
        /// Kalite antye relatif yo primitif tout aplike yon fonksyon [`rotate_left`](Self::rotate_left), ki ka sa ou vle olye.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SEKIRITE: maskin la pa bitsize nan kalite a asire ke nou pa chanjman
            // soti nan limit
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-gratis bitwise chanjman-dwa;
        /// pwodiksyon `self >> mask(rhs)`, kote `mask` retire nenpòt Bits-wo lòd nan `rhs` ki ta lakòz chanjman nan depase Pleasant nan kalite la.
        ///
        /// Remake byen ke sa a se *pa* menm jan ak yon Thorne-dwa;se RHS nan yon vlope chanjman-dwa restriksyon nan seri a nan kalite a, olye ke Bits yo deplase soti nan LHS la ke yo te retounen nan fen a lòt.
        /// Kalite antye relatif yo primitif tout aplike yon fonksyon [`rotate_right`](Self::rotate_right), ki ka sa ou vle olye.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SEKIRITE: maskin la pa bitsize nan kalite a asire ke nou pa chanjman
            // soti nan limit
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Anbalaj eksponansyasyon (modular).
        /// Kalkile `self.pow(exp)`, anbalaj nan fwontyè kalite a.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // depi exp!=0, finalman exp la dwe 1.
            // Fè fas ak ti jan final la nan ekspozan a separeman, depi kare baz la apre sa pa nesesè epi yo ka lakòz yon debòde initil.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Kalkile `self` + `rhs`
        ///
        /// Retounen yon tupl nan adisyon a ansanm ak yon Boolean ki endike si yon debòde aritmetik ta rive.
        /// Si ta gen yon debòde ki te fèt Lè sa a, valè a vlope retounen.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz yo
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kalkile `self`, `rhs`
        ///
        /// Retounen yon tuplè soustraksyon a ansanm ak yon boolean ki endike si yon debòde aritmetik ta rive.
        /// Si ta gen yon debòde ki te fèt Lè sa a, valè a vlope retounen.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz yo
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kalkile miltiplikasyon `self` ak `rhs`.
        ///
        /// Retounen yon tuplikasyon miltiplikasyon ansanm ak yon boolean ki endike si yon debòde aritmetik ta rive.
        /// Si ta gen yon debòde ki te fèt Lè sa a, valè a vlope retounen.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// Tanpri sonje ke egzanp sa a pataje ant kalite nonb antye relatif.
        /// Ki eksplike poukisa `u32` yo itilize isit la.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kalkile divizè a lè `self` divize pa `rhs`.
        ///
        /// Retounen yon tuplè divizè a ansanm ak yon boolean ki endike si yon debòde aritmetik ta rive.
        /// Remake byen ke pou nonb antye relatif non siyen pa janm rive, se konsa dezyèm valè a se toujou `false`.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz yo
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Kalkile kosyan nan divizyon eklidyen `self.div_euclid(rhs)`.
        ///
        /// Retounen yon tuplè divizè a ansanm ak yon boolean ki endike si yon debòde aritmetik ta rive.
        /// Remake byen ke pou nonb antye relatif non siyen pa janm rive, se konsa dezyèm valè a se toujou `false`.
        /// Depi, pou nonm antye relatif yo pozitif, tout definisyon komen nan divizyon yo egal, sa a se egzakteman egal a `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz yo
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Kalkile rès la lè `self` divize pa `rhs`.
        ///
        /// Retounen yon tupl nan rès la apre divize ansanm ak yon Boolean ki endike si yon debòde aritmetik ta rive.
        /// Remake byen ke pou nonb antye relatif non siyen pa janm rive, se konsa dezyèm valè a se toujou `false`.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz yo
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Kalkile rès `self.rem_euclid(rhs)` tankou si pa divizyon eklidyen.
        ///
        /// Retounen yon tupl nan modulo a apre divize ansanm ak yon boolean ki endike si yon debòde aritmetik ta rive.
        /// Remake byen ke pou nonb antye relatif non siyen pa janm rive, se konsa dezyèm valè a se toujou `false`.
        /// Depi, pou nonb antye relatif yo pozitif, tout definisyon komen nan divizyon yo egal, operasyon sa a egzakteman egal a `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz yo
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negate pwòp tèt ou nan yon mòd debòde.
        ///
        /// Retounen `!self + 1` lè l sèvi avèk operasyon anbalaj retounen valè a ki reprezante negasyon an nan valè sa a siyen.
        /// Remake byen ke pou valè pozitif siyen debòde toujou fèt, men negatif 0 pa debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz yo
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Chanjman pwòp tèt ou kite pa `rhs` Bits.
        ///
        /// Retounen yon tupl nan vèsyon an deplase nan pwòp tèt ou ansanm ak yon boolean ki endike si valè a chanjman te pi gwo pase oswa egal a kantite Bits.
        /// Si valè chanjman an twò gwo, lè sa a valè maske (N-1) kote N se kantite Bits, epi valè sa a itilize pou fè chanjman an.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz yo
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Chanjman pwòp tèt ou dwa pa `rhs` Bits.
        ///
        /// Retounen yon tupl nan vèsyon an deplase nan pwòp tèt ou ansanm ak yon boolean ki endike si valè a chanjman te pi gwo pase oswa egal a kantite Bits.
        /// Si valè chanjman an twò gwo, lè sa a valè maske (N-1) kote N se kantite Bits, epi valè sa a itilize pou fè chanjman an.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz yo
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Ogmante pwòp tèt ou sou pouvwa a nan `exp`, lè l sèvi avèk eksponans pa kare.
        ///
        /// Retounen yon tupl nan eksponansyasyon an ansanm ak yon bool ki endike si yon debòde rive.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, vre));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Grate espas pou estoke rezilta debòde_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // depi exp!=0, finalman exp la dwe 1.
            // Fè fas ak ti jan final la nan ekspozan a separeman, depi kare baz la apre sa pa nesesè epi yo ka lakòz yon debòde initil.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Ogmante pwòp tèt ou sou pouvwa a nan `exp`, lè l sèvi avèk eksponans pa kare.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // depi exp!=0, finalman exp la dwe 1.
            // Fè fas ak ti jan final la nan ekspozan a separeman, depi kare baz la apre sa pa nesesè epi yo ka lakòz yon debòde initil.
            //
            //
            acc * base
        }

        /// Fè divizyon eklidyen.
        ///
        /// Depi, pou nonm antye relatif yo pozitif, tout definisyon komen nan divizyon yo egal, sa a se egzakteman egal a `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Kalkile rès la piti nan `self (mod rhs)`.
        ///
        /// Depi, pou nonm antye relatif yo pozitif, tout definisyon komen nan divizyon yo egal, sa a se egzakteman egal a `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Retounen `true` si e sèlman si `self == 2^k` pou kèk `k`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Retounen yon mwens pase pwochen pouvwa de.
        // (Pou 8u8 pwochen pouvwa nan de se 8u8 ak pou 6u8 li se 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Metòd sa a pa ka debòde, tankou nan ka debòde `next_power_of_two` li olye fini retounen valè maksimòm kalite a, epi li ka retounen 0 pou 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SEKIRITE: Paske `p > 0`, li pa ka konpoze antyèman de dirijan zewo.
            // Sa vle di chanjman an toujou nan-limit, ak kèk processeurs (tankou intel pre-haswell) gen pi efikas ctlz intrinsèques lè agiman an se ki pa zewo.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Retounen pouvwa a pi piti nan de pi gran pase oswa egal a `self`.
        ///
        /// Lè valè retou debòde (sa vle di, `self > (1 << (N-1))` pou kalite `uN`), li panics nan mòd debug ak valè retounen vlope a 0 nan mòd lage (sitiyasyon an sèlman nan ki metòd ka retounen 0).
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Retounen pouvwa a pi piti nan de pi gran pase oswa egal a `n`.
        /// Si pwochen pouvwa a nan de pi gran pase valè maksimòm kalite a, `None` retounen, otreman pouvwa a nan de vlope nan `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Retounen pouvwa a pi piti nan de pi gran pase oswa egal a `n`.
        /// Si pwochen pouvwa a nan de se pi gran pase valè maksimòm kalite a, se valè a retounen vlope nan `0`.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Retounen reprezantasyon memwa sa a antye antye kòm yon etalaj byte nan gwo-endian (network) lòd byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Retounen reprezantasyon an memwa nan nonb antye relatif kòm yon etalaj byte nan ti-endian lòd byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Retounen reprezantasyon an memwa nan nonb antye relatif kòm yon etalaj byte nan lòd byte natif natal.
        ///
        /// Kòm endianness natif natal platfòm sib la itilize, kòd pòtab ta dwe itilize [`to_be_bytes`] oswa [`to_le_bytes`], jan sa apwopriye, olye.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, si cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } lòt bagay {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEKIRITE: konstan son paske nonm antye relatif yo se plenn datatypes fin vye granmoun pou nou ka toujou
        // transmute yo nan ranje bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SEKIRITE: nonb antye relatif yo se plenn datatypes fin vye granmoun pou nou ka toujou transmute yo nan
            // etalaj bytes
            unsafe { mem::transmute(self) }
        }

        /// Retounen reprezantasyon an memwa nan nonb antye relatif kòm yon etalaj byte nan lòd byte natif natal.
        ///
        ///
        /// [`to_ne_bytes`] ta dwe pi pito sou sa a chak fwa sa posib.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// kite bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, si cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } lòt bagay {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SEKIRITE: nonb antye relatif yo se plenn datatypes fin vye granmoun pou nou ka toujou transmute yo nan
            // etalaj bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Kreye yon valè antye endian natif natal ki soti nan reprezantasyon li yo kòm yon etalaj byte nan gwo endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// itilize std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * opinyon=rès;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Kreye yon valè antye endian natif natal ki soti nan reprezantasyon li kòm yon etalaj byte nan ti endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// itilize std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * opinyon=rès;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Kreye yon valè antye endian natif natal nan reprezantasyon memwa li yo kòm yon etalaj byte nan endianness natif natal.
        ///
        /// Kòm endianness natif natal platfòm sib la itilize, kòd pòtab gen anpil chans vle sèvi ak [`from_be_bytes`] oswa [`from_le_bytes`], jan sa apwopriye olye.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } lòt bagay {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// itilize std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * opinyon=rès;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEKIRITE: konstan son paske nonm antye relatif yo se plenn datatypes fin vye granmoun pou nou ka toujou
        // transmute yo
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SEKIRITE: nonb antye relatif yo se plenn kalite done fin vye granmoun pou nou ka toujou transmute yo
            unsafe { mem::transmute(bytes) }
        }

        /// Nouvo kòd ta dwe prefere itilize
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Retounen valè ki pi piti a ki ka reprezante pa kalite nonb antye relatif la.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Nouvo kòd ta dwe prefere itilize
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Retounen pi gwo valè ki ka reprezante pa kalite nonb antye relatif la.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}