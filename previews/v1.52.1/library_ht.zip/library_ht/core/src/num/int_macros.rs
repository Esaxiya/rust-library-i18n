macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Valè ki pi piti a ki ka reprezante pa kalite nonb antye relatif la.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Pi gwo valè ki ka reprezante pa kalite nonb antye relatif la.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Gwosè a nan kalite sa a nonb antye relatif an Bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konvèti yon tranch fisèl nan yon baz yo bay nan yon nonb antye relatif.
        ///
        /// Fisèl la espere yo dwe yon si ou vle `+` oswa `-` siy ki te swiv pa chif.
        /// Dirijan ak blanch espas reprezante yon erè.
        /// Chif yo se yon sou nan karaktè sa yo, tou depann de `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Fonksyon sa a panics si `radix` pa nan seri de 2 a 36.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Retounen kantite moun ki nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Retounen kantite zewo nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Retounen kantite zewo dirijan nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Retounen kantite zewo final nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Retounen kantite dirijan nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Retounen kantite moun ki fin nan reprezantasyon binè `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Chanje Bits yo sou bò gòch la pa yon kantite lajan espesifye, `n`, anbalaj Bits yo tronke nan fen antye relatif la ki kapab lakòz.
        ///
        ///
        /// Tanpri sonje sa a se pa operasyon an menm jan ak operatè a déplacement `<<`!
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Chanje Bits yo sou bò dwat la pa yon kantite lajan espesifye, `n`, vlope Bits yo tronke nan konmansman an nan antye relatif la ki kapab lakòz.
        ///
        ///
        /// Tanpri sonje sa a se pa operasyon an menm jan ak operatè a déplacement `>>`!
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Ranvèse lòd byte nan nonb antye relatif la.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// kite m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Ranvèse lòd Bits nan nonb antye relatif la.
        /// Ti jan ki pi piti a vin ti bit ki pi enpòtan an, dezyèm ti bit ki pi enpòtan an vin dezyèm ti bit ki pi enpòtan an, elatriye.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// kite m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Konvèti yon nonb antye relatif ki soti nan endian gwo endianness sib la.
        ///
        /// Sou Endian gwo sa a se yon pa gen okenn-op.Sou ti endian bytes yo échanges.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } lòt bagay {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konvèti yon nonb antye relatif ki soti nan ti endian nan endianness sib la.
        ///
        /// Sou ti endian sa a se yon pa gen okenn-op.Sou gwo endian bytes yo échanges.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } lòt bagay {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Konvèti `self` an gwo endian soti nan endianness sib la.
        ///
        /// Sou Endian gwo sa a se yon pa gen okenn-op.Sou ti endian bytes yo échanges.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } Lòt bagay { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // oswa ou pa dwe?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Konvèti `self` an ti endian soti nan endianness sib la.
        ///
        /// Sou ti endian sa a se yon pa gen okenn-op.Sou gwo endian bytes yo échanges.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// si cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } Lòt bagay { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Tcheke adisyon antye relatif.
        /// Kalkile `self + rhs`, retounen `None` si debòde ki te fèt.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Anplis de sa non antye relatif.Kalkile `self + rhs`, an konsideran debòde pa ka rive.
        /// Sa rezilta nan konpòtman endefini lè
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Tcheke soustraksyon antye antye.
        /// Kalkile `self - rhs`, retounen `None` si debòde ki te fèt.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Soustraksyon non antye relatif.Kalkile `self - rhs`, an konsideran debòde pa ka rive.
        /// Sa rezilta nan konpòtman endefini lè
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Tcheke miltiplikasyon antye relatif.
        /// Kalkile `self * rhs`, retounen `None` si debòde ki te fèt.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Miltiplikasyon nonb antye relatif.Kalkile `self * rhs`, an konsideran debòde pa ka rive.
        /// Sa rezilta nan konpòtman endefini lè
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Tcheke divizyon nonm antye relatif.
        /// Kalkile `self / rhs`, retounen `None` si `rhs == 0` oswa rezilta divizyon an nan debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SEKIRITE: div pa zewo ak pa INT_MIN yo te tcheke pi wo a
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Tcheke divizyon eklidyen.
        /// Kalkile `self.div_euclid(rhs)`, retounen `None` si `rhs == 0` oswa rezilta divizyon an nan debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Tcheke rès nonb antye relatif.
        /// Kalkile `self % rhs`, retounen `None` si `rhs == 0` oswa rezilta divizyon an nan debòde.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SEKIRITE: div pa zewo ak pa INT_MIN yo te tcheke pi wo a
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Tcheke rès Euclidean.
        /// Kalkile `self.rem_euclid(rhs)`, retounen `None` si `rhs == 0` oswa rezilta divizyon an nan debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Tcheke negasyon.
        /// Kalkile `-self`, retounen `None` si `self == MIN`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tcheke chanjman agoch.
        /// Kalkile `self << rhs`, retounen `None` si `rhs` pi gwo pase oswa egal a kantite Bits nan `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tcheke chanjman dwat.
        /// Kalkile `self >> rhs`, retounen `None` si `rhs` pi gwo pase oswa egal a kantite Bits nan `self`.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tcheke valè absoli.
        /// Kalkile `self.abs()`, retounen `None` si `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Tcheke eksponansyasyon.
        /// Kalkile `self.pow(exp)`, retounen `None` si debòde ki te fèt.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // depi exp!=0, finalman exp la dwe 1.
            // Fè fas ak ti jan final la nan ekspozan a separeman, depi kare baz la apre sa pa nesesè epi yo ka lakòz yon debòde initil.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturation adisyon antye relatif.
        /// Kalkile `self + rhs`, satire nan limit nimerik olye pou yo debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Saturation soustraksyon antye antye.
        /// Kalkile `self - rhs`, satire nan limit nimerik olye pou yo debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Saturation negasyon nonb antye relatif.
        /// Kalkile `-self`, retounen `MAX` si `self == MIN` olye pou yo debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Satire valè absoli.
        /// Kalkile `self.abs()`, retounen `MAX` si `self == MIN` olye pou yo debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Saturation miltiplikasyon antye relatif.
        /// Kalkile `self * rhs`, satire nan limit nimerik olye pou yo debòde.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Eksponansyasyon antye relatif satire.
        /// Kalkile `self.pow(exp)`, satire nan limit nimerik olye pou yo debòde.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Anbalaj (modular) adisyon.
        /// Kalkile `self + rhs`, anbalaj nan fwontyè kalite a.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Anbalaj (modular) soustraksyon.
        /// Kalkile `self - rhs`, anbalaj nan fwontyè kalite a.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Anbalaj miltiplikasyon (modular).
        /// Kalkile `self * rhs`, anbalaj nan fwontyè kalite a.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Anbalaj (modular) divizyon.Kalkile `self / rhs`, anbalaj nan fwontyè kalite a.
        ///
        /// Sèl ka kote anbalaj sa yo ka rive se lè yon moun divize `MIN / -1` sou yon kalite siyen (kote `MIN` se valè minimòm negatif pou kalite a);sa ekivalan a `-MIN`, yon valè pozitif ki twò gwo pou reprezante nan kalite a.
        /// Nan ka sa a, fonksyon sa a retounen `MIN` tèt li.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Anbalaj divizyon eklidyen.
        /// Kalkile `self.div_euclid(rhs)`, anbalaj nan fwontyè kalite a.
        ///
        /// Anbalaj pral fèt sèlman nan `MIN / -1` sou yon kalite siyen (kote `MIN` se valè minimòm negatif pou kalite a).
        /// Sa a ekivalan a `-MIN`, yon valè pozitif ki twò gwo pou reprezante nan kalite a.
        /// Nan ka sa a, metòd sa a retounen `MIN` tèt li.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Vlope (modular) rès.Kalkile `self % rhs`, anbalaj nan fwontyè kalite a.
        ///
        /// Sa yo vlope-alantou pa janm aktyèlman rive matematikman;zafè aplikasyon fè `x % y` valab pou `MIN / -1` sou yon kalite siyen (kote `MIN` se valè minimòm negatif la).
        ///
        /// Nan ka sa a, fonksyon sa a retounen `0`.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Anbalaj rès eklidyen.Kalkile `self.rem_euclid(rhs)`, anbalaj nan fwontyè kalite a.
        ///
        /// Anbalaj pral fèt sèlman nan `MIN % -1` sou yon kalite siyen (kote `MIN` se valè minimòm negatif pou kalite a).
        /// Nan ka sa a, metòd sa a retounen 0.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Anbalaj (modular) negasyon.Kalkile `-self`, anbalaj nan fwontyè kalite a.
        ///
        /// Sèl ka kote anbalaj sa yo ka rive se lè youn negate `MIN` sou yon kalite siyen (kote `MIN` se valè minimòm negatif pou kalite a);sa a se yon valè pozitif ki twò gwo pou reprezante nan kalite a.
        /// Nan ka sa a, fonksyon sa a retounen `MIN` tèt li.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-gratis bit-gòch;pwodiksyon `self << mask(rhs)`, kote `mask` retire nenpòt Bits-wo lòd nan `rhs` ki ta lakòz chanjman nan depase Pleasant nan kalite la.
        ///
        /// Remake byen ke sa a se *pa* menm jan ak yon Thorne-bò gòch;se RHS la nan yon anbalaj chanjman-gòch restriksyon nan seri a nan kalite a, olye ke Bits yo deplase soti nan LHS la ke yo te retounen nan fen a lòt.
        ///
        /// Kalite antye relatif yo primitif tout aplike yon fonksyon [`rotate_left`](Self::rotate_left), ki ka sa ou vle olye.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SEKIRITE: maskin la pa bitsize nan kalite a asire ke nou pa chanjman
            // soti nan limit
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-gratis bitwise chanjman-dwa;pwodiksyon `self >> mask(rhs)`, kote `mask` retire nenpòt Bits-wo lòd nan `rhs` ki ta lakòz chanjman nan depase Pleasant nan kalite la.
        ///
        /// Remake byen ke sa a se *pa* menm jan ak yon Thorne-dwa;se RHS nan yon vlope chanjman-dwa restriksyon nan seri a nan kalite a, olye ke Bits yo deplase soti nan LHS la ke yo te retounen nan fen a lòt.
        ///
        /// Kalite antye relatif yo primitif tout aplike yon fonksyon [`rotate_right`](Self::rotate_right), ki ka sa ou vle olye.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SEKIRITE: maskin la pa bitsize nan kalite a asire ke nou pa chanjman
            // soti nan limit
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Anbalaj (modular) valè absoli.Kalkile `self.abs()`, anbalaj nan fwontyè kalite a.
        ///
        /// Sèl ka kote anbalaj sa yo ka rive se lè yon moun pran valè absoli valè minimòm negatif pou kalite a;sa a se yon valè pozitif ki twò gwo pou reprezante nan kalite a.
        /// Nan ka sa a, fonksyon sa a retounen `MIN` tèt li.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Kalkile valè absoli `self` san okenn anbalaj oswa panik.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Anbalaj eksponansyasyon (modular).
        /// Kalkile `self.pow(exp)`, anbalaj nan fwontyè kalite a.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // depi exp!=0, finalman exp la dwe 1.
            // Fè fas ak ti jan final la nan ekspozan a separeman, depi kare baz la apre sa pa nesesè epi yo ka lakòz yon debòde initil.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Kalkile `self` + `rhs`
        ///
        /// Retounen yon tupl nan adisyon a ansanm ak yon Boolean ki endike si yon debòde aritmetik ta rive.
        /// Si ta gen yon debòde ki te fèt Lè sa a, valè a vlope retounen.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kalkile `self`, `rhs`
        ///
        /// Retounen yon tuplè soustraksyon a ansanm ak yon boolean ki endike si yon debòde aritmetik ta rive.
        /// Si ta gen yon debòde ki te fèt Lè sa a, valè a vlope retounen.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kalkile miltiplikasyon `self` ak `rhs`.
        ///
        /// Retounen yon tuplikasyon miltiplikasyon ansanm ak yon boolean ki endike si yon debòde aritmetik ta rive.
        /// Si ta gen yon debòde ki te fèt Lè sa a, valè a vlope retounen.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, vre));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kalkile divizè a lè `self` divize pa `rhs`.
        ///
        /// Retounen yon tuplè divizè a ansanm ak yon boolean ki endike si yon debòde aritmetik ta rive.
        /// Si yon debòde ta rive lè sa a pwòp tèt ou retounen.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Kalkile kosyan nan divizyon eklidyen `self.div_euclid(rhs)`.
        ///
        /// Retounen yon tuplè divizè a ansanm ak yon boolean ki endike si yon debòde aritmetik ta rive.
        /// Si yon debòde ta rive Lè sa a, `self` retounen.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Kalkile rès la lè `self` divize pa `rhs`.
        ///
        /// Retounen yon tupl nan rès la apre divize ansanm ak yon Boolean ki endike si yon debòde aritmetik ta rive.
        /// Si yon debòde ta rive lè sa a 0 retounen.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Debòde rès eklidyen.Kalkile `self.rem_euclid(rhs)`.
        ///
        /// Retounen yon tupl nan rès la apre divize ansanm ak yon Boolean ki endike si yon debòde aritmetik ta rive.
        /// Si yon debòde ta rive lè sa a 0 retounen.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negate pwòp tèt ou, debòde si sa a egal a valè minimòm lan.
        ///
        /// Retounen yon tupl nan vèsyon an negasyon nan pwòp tèt ou ansanm ak yon boolean ki endike si yon debòde rive.
        /// Si `self` se valè minimòm lan (pa egzanp, `i32::MIN` pou valè kalite `i32`), lè sa a valè minimòm lan ap retounen ankò epi `true` pral retounen pou yon debòde k ap pase.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Chanjman pwòp tèt ou kite pa `rhs` Bits.
        ///
        /// Retounen yon tupl nan vèsyon an deplase nan pwòp tèt ou ansanm ak yon boolean ki endike si valè a chanjman te pi gwo pase oswa egal a kantite Bits.
        /// Si valè chanjman an twò gwo, lè sa a valè maske (N-1) kote N se kantite Bits, epi valè sa a itilize pou fè chanjman an.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, vre));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Chanjman pwòp tèt ou dwa pa `rhs` Bits.
        ///
        /// Retounen yon tupl nan vèsyon an deplase nan pwòp tèt ou ansanm ak yon boolean ki endike si valè a chanjman te pi gwo pase oswa egal a kantite Bits.
        /// Si valè chanjman an twò gwo, lè sa a valè maske (N-1) kote N se kantite Bits, epi valè sa a itilize pou fè chanjman an.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, vre));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Kalkile valè absoli `self`.
        ///
        /// Retounen yon tupl nan vèsyon absoli nan pwòp tèt ou ansanm ak yon boolean ki endike si yon debòde rive.
        /// Si pwòp tèt ou se valè minimòm lan
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// Lè sa a, valè minimòm lan pral retounen ankò e vre yo pral retounen pou yon debòde k ap pase.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Ogmante pwòp tèt ou sou pouvwa a nan `exp`, lè l sèvi avèk eksponans pa kare.
        ///
        /// Retounen yon tupl nan eksponansyasyon an ansanm ak yon bool ki endike si yon debòde rive.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, vre));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Grate espas pou estoke rezilta debòde_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // depi exp!=0, finalman exp la dwe 1.
            // Fè fas ak ti jan final la nan ekspozan a separeman, depi kare baz la apre sa pa nesesè epi yo ka lakòz yon debòde initil.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Ogmante pwòp tèt ou sou pouvwa a nan `exp`, lè l sèvi avèk eksponans pa kare.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // depi exp!=0, finalman exp la dwe 1.
            // Fè fas ak ti jan final la nan ekspozan a separeman, depi kare baz la apre sa pa nesesè epi yo ka lakòz yon debòde initil.
            //
            //
            acc * base
        }

        /// Kalkile kosyan nan divizyon eklidyen nan `self` pa `rhs`.
        ///
        /// Sa a kalkile nonb antye relatif la `n` sa yo ki `self = n * rhs + self.rem_euclid(rhs)`, ak `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Nan lòt mo, rezilta a se `self / rhs` awondi nan nonb antye relatif la `n` sa yo ki `self >= n * rhs`.
        /// Si `self > 0`, sa a egal a wonn nan direksyon pou zewo (default la nan Rust);
        /// si `self < 0`, sa a egal a wonn nan direksyon pou +/-Infinity.
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0 oswa rezilta yo divizyon nan debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// kite b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Kalkile rès ki pi negatif nan `self (mod rhs)`.
        ///
        /// Sa a se fè tankou si pa algorithm nan divizyon Euclidean-bay `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, ak `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Fonksyon sa a pral panic si `rhs` se 0 oswa rezilta yo divizyon nan debòde.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// kite b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Kalkile valè absoli `self`.
        ///
        /// # Konpòtman debòde
        ///
        /// Valè absoli nan
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// pa ka reprezante kòm yon
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// epi eseye kalkile li pral lakòz yon debòde.
        /// Sa vle di ke kòd nan mòd debug pral deklanche yon panic sou ka sa a ak kòd optimize ap retounen
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// san yon panic.
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Remake byen ke#[aliye] anwo a vle di ke semantik debòde soustraksyon an depann de crate ke nou ap enskri nan.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Retounen yon nimewo ki reprezante siy `self`.
        ///
        ///  - `0` si nimewo a se zewo
        ///  - `1` si nimewo a pozitif
        ///  - `-1` si nimewo a negatif
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Retounen `true` si `self` pozitif ak `false` si nimewo a zewo oswa negatif.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Retounen `true` si `self` negatif ak `false` si nimewo a zewo oswa pozitif.
        ///
        ///
        /// # Examples
        ///
        /// Itilizasyon debaz:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Retounen reprezantasyon memwa sa a antye antye kòm yon etalaj byte nan gwo-endian (network) lòd byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Retounen reprezantasyon an memwa nan nonb antye relatif kòm yon etalaj byte nan ti-endian lòd byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Retounen reprezantasyon an memwa nan nonb antye relatif kòm yon etalaj byte nan lòd byte natif natal.
        ///
        /// Kòm endianness natif natal platfòm sib la itilize, kòd pòtab ta dwe itilize [`to_be_bytes`] oswa [`to_le_bytes`], jan sa apwopriye, olye.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, si cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } lòt bagay {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEKIRITE: konstan son paske nonm antye relatif yo se plenn datatypes fin vye granmoun pou nou ka toujou
        // transmute yo nan ranje bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SEKIRITE: nonb antye relatif yo se plenn datatypes fin vye granmoun pou nou ka toujou transmute yo nan
            // etalaj bytes
            unsafe { mem::transmute(self) }
        }

        /// Retounen reprezantasyon an memwa nan nonb antye relatif kòm yon etalaj byte nan lòd byte natif natal.
        ///
        ///
        /// [`to_ne_bytes`] ta dwe pi pito sou sa a chak fwa sa posib.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// kite bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, si cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } lòt bagay {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SEKIRITE: nonb antye relatif yo se plenn datatypes fin vye granmoun pou nou ka toujou transmute yo nan
            // etalaj bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Kreye yon valè nonb antye relatif ki soti nan reprezantasyon li yo kòm yon etalaj byte nan Endian gwo.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// itilize std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * opinyon=rès;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Kreye yon valè nonb antye relatif nan reprezantasyon li yo kòm yon etalaj byte nan ti endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// itilize std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * opinyon=rès;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Kreye yon valè nonb antye relatif soti nan reprezantasyon memwa li yo kòm yon etalaj byte nan endianness natif natal.
        ///
        /// Kòm endianness natif natal platfòm sib la itilize, kòd pòtab gen anpil chans vle sèvi ak [`from_be_bytes`] oswa [`from_le_bytes`], jan sa apwopriye olye.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } lòt bagay {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// itilize std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * opinyon=rès;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SEKIRITE: konstan son paske nonm antye relatif yo se plenn datatypes fin vye granmoun pou nou ka toujou
        // transmute yo
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SEKIRITE: nonb antye relatif yo se plenn kalite done fin vye granmoun pou nou ka toujou transmute yo
            unsafe { mem::transmute(bytes) }
        }

        /// Nouvo kòd ta dwe prefere itilize
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Retounen valè ki pi piti a ki ka reprezante pa kalite nonb antye relatif la.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Nouvo kòd ta dwe prefere itilize
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Retounen pi gwo valè ki ka reprezante pa kalite nonb antye relatif la.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}