//! Konstan pou kalite nonb antye relatif 128-bit la.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Nouvo kòd ta dwe itilize konstan ki asosye yo dirèkteman sou kalite primitif la.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }