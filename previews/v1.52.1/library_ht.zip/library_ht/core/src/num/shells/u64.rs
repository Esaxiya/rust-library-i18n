//! Konstan pou kalite nonb antye relatif 64-ti non.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Nouvo kòd ta dwe itilize konstan ki asosye yo dirèkteman sou kalite primitif la.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }