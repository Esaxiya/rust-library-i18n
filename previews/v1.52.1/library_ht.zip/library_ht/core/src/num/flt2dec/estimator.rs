//! Estimatè ekspozan an.

/// Jwenn `k_0` tankou `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Sa a se itilize apwoksimatif `k = ceil(log_10 (mant * 2^exp))`;
/// vre `k` la se swa `k_0` oswa `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits si mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) Se poutèt sa sa a toujou souzèstime (oswa se egzak), men se pa anpil.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}