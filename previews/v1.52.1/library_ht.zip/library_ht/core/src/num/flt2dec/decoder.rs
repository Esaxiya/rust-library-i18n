//! Dekode yon valè k ap flote-pwen nan pati endividyèl ak chenn erè.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekode non siy valè fini, tankou ke:
///
/// - Valè orijinal la egal a `mant * 2^exp`.
///
/// - Nenpòt nimewo soti nan `(mant - minus)*2^exp` `(mant + plus)* 2^exp` ap awondi nan valè orijinal la.
/// Ranje a se enklizif sèlman lè `inclusive` se `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantissa a echèl.
    pub mant: u64,
    /// Ranje a erè pi ba yo.
    pub minus: u64,
    /// Ranje a erè anwo.
    pub plus: u64,
    /// Ekspozan an pataje nan baz 2.
    pub exp: i16,
    /// Vrè lè ranje erè a enklizif.
    ///
    /// Nan IEEE 754, sa a se vre lè mantissa orijinal la te menm.
    pub inclusive: bool,
}

/// Dekode valè siyen.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, swa pozitif oswa negatif.
    Infinite,
    /// Zewo, swa pozitif oswa negatif.
    Zero,
    /// Nimewo fini ak jaden plis dekode.
    Finite(Decoded),
}

/// Yon kalite pwen k ap flote ki ka `dekode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Valè minimòm pozitif nòmalize a.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Retounen yon siy (vre lè negatif) ak `FullDecoded` valè ki soti nan nimewo pwen k ap flote.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // vwazen: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode toujou prezève ekspozan a, se konsa mantissa a scaled pou subnormals.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // vwazen: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // kote maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // vwazen: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}