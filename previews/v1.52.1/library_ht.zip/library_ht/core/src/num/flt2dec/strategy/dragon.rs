//! Prèske dirèk (men yon ti kras optimize) tradiksyon Rust nan Figi 3 nan "Enprime nimewo k ap flote byen vit ak presizyon" [^ 1].
//!
//!
//! [^1]: Burger, RG ak Dybvig, RK 1996. Enprime nimewo k ap flote-pwen
//!   byen vit epi avèk presizyon.SIGPLAN Pa.31, 5 (Me. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// ranje kalkile nan `Digit`s pou 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// sèlman ka itilize lè `x < 16 * scale`;`scaleN` ta dwe `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Aplikasyon ki pi kout mòd pou dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // se nimewo `v` a fòma li te ye yo dwe:
    // - egal a `mant * 2^exp`;
    // - anvan pa `(mant - 2 *minus)* 2^exp` nan kalite orijinal la;ak
    // - ki te swiv pa `(mant + 2 *plus)* 2^exp` nan kalite orijinal la.
    //
    // evidamman, `minus` ak `plus` pa kapab zewo.(pou enfini, nou itilize valè andeyò ranje.) tou nou asime ke omwen yon chif pwodwi, sa vle di, `mant` pa ka zewo tou.
    //
    // sa vle di tou ke nenpòt ki nimewo ant `low = (mant - minus)*2^exp` ak `high = (mant + plus)* 2^exp` ap kat sa a egzak nimewo pwen k ap flote, ak limit enkli lè mantissa orijinal la te menm (sa vle di, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` se `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // estime `k_0` soti nan entrain orijinal ki satisfè `10^(k_0-1) < high <= 10^(k_0+1)`.
    // sere mare `k` satisfè `10^(k-1) < high <= 10^k` la kalkile pita.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // konvèti `{mant, plus, minus} * 2^exp` nan fòm fraksyon pou ke:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // divize `mant` pa `10^k`.kounye a `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // fixup lè `mant + plus > scale` (oswa `>=`).
    // nou pa aktyèlman modifye `scale`, depi nou ka sote miltiplikasyon inisyal la olye.
    // kounye a `scale < mant + plus <= scale * 10` e nou pare pou jenere chif.
    //
    // sonje ke `d[0]`*ka* zewo, lè `scale - plus < mant < scale`.
    // an ka sa a awondi-up kondisyon (`up` anba a) pral deklanche imedyatman.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // ekivalan a dekale `scale` pa 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // kachèt `(2, 4, 8) * scale` pou jenerasyon chif.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // envariants, kote `d[0..n-1]` se chif ki te pwodwi byen lwen tèlman:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (konsa `mant / scale < 10`) kote `d[i..j]` se yon stenografi pou `d [mwen] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // jenere yon chif: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // sa a se yon deskripsyon senplifye nan algorithm nan dragon modifye.
        // anpil dérivations entèmedyè ak agiman konplè yo omisyon pou konvenyans.
        //
        // kòmanse ak envariants modifye, menm jan nou te mete ajou `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // asime ke `d[0..n-1]` se reprezantasyon ki pi kout la ant `low` ak `high`, sa vle di, `d[0..n-1]` satisfè tou de sa ki annapre yo, men `d[0..n-2]` pa:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijektivite: chif wonn nan `v`);ak
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (dènye chif la kòrèk).
        //
        // dezyèm kondisyon an senplifye `2 * mant <= scale`.
        // rezoud envariants an tèm de `mant`, `low` ak `high` bay yon vèsyon ki pi senp nan kondisyon an premye: `-plus < mant < minus`.
        // depi `-plus < 0 <= mant`, nou gen reprezantasyon ki pi kout ki kòrèk la lè `mant < minus` ak `2 * mant <= scale`.
        // (ansyen an vin `mant <= minus` lè mantissa orijinal la se menm.)
        //
        // lè dezyèm lan pa kenbe (`2 * mant> echèl`), nou bezwen ogmante dènye chif la.
        // sa a ase pou retabli kondisyon sa a: nou deja konnen ke jenerasyon chif la garanti `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // an ka sa a, kondisyon an premye vin `-plus < mant - scale < minus`.
        // depi `mant < scale` apre jenerasyon an, nou gen `scale < mant + plus`.
        // (ankò, sa a vin `scale <= mant + plus` lè mantissa orijinal la se menm.)
        //
        // an rezime:
        // - sispann ak wonn `down` (kenbe chif tankou se) lè `mant < minus` (oswa `<=`).
        // - sispann ak wonn `up` (ogmante dènye chif la) lè `scale < mant + plus` (oswa `<=`).
        // - kenbe génération otreman.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // nou gen reprezantasyon ki pi kout la, kontinye nan awondi la

        // retabli envariants yo.
        // sa fè algorithm la toujou mete fen: `minus` ak `plus` toujou ogmante, men `mant` se koupe modulo `scale` ak `scale` fiks.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // awondi moute k ap pase lè mwen) se sèlman kondisyon an awondi-up te deklanche, oswa ii) tou de kondisyon yo te deklanche ak menm kantite vòt kraze pwefere awondi moute.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // si awondi moute longè a, ekspozan an ta dwe chanje tou.
        // li sanble ke kondisyon sa a trè difisil pou satisfè (pètèt enposib), men nou jis ke yo te san danje epi ki konsistan isit la.
        //
        // SEKIRITE: nou inisyalize memwa sa a pi wo a.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SEKIRITE: nou inisyalize memwa sa a pi wo a.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Aplikasyon an mòd egzak ak fiks pou dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // estime `k_0` soti nan entrain orijinal ki satisfè `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // divize `mant` pa `10^k`.kounye a `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup lè `mant + plus >= scale`, kote `plus / scale = 10^-buf.len() / 2`.
    // yo nan lòd yo kenbe gwosè a fiks, nou aktyèlman itilize `mant + floor(plus) >= scale`.
    // nou pa aktyèlman modifye `scale`, depi nou ka sote miltiplikasyon inisyal la olye.
    // ankò ak algorithm ki pi kout la, `d[0]` ka zewo, men yo pral evantyèlman awondi yo.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // ekivalan a dekale `scale` pa 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // si nou ap travay ak limit la dènye chif, nou bezwen diminye tanpon la anvan rann aktyèl la yo nan lòd pou fè pou evite doub awondi.
    //
    // sonje ke nou gen elaji pezib la ankò lè awondi moute rive!
    let mut len = if k < limit {
        // oops, nou pa menm ka pwodwi *yon sèl* chif.
        // sa a posib lè, di, nou te gen yon bagay tankou 9.5 epi li te awondi a 10.
        // nou retounen yon tanpon vid, ak yon eksepsyon nan ka a pita awondi-up ki rive lè `k == limit` e li gen yo pwodwi egzakteman yon chif.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // kachèt `(2, 4, 8) * scale` pou jenerasyon chif.
        // (sa a ka koute chè, kidonk pa kalkile yo lè pezib la vid.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // chif sa yo se tout zewo, nou sispann isit la *pa* eseye fè awondi!pitou, ranpli chif ki rete yo.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SEKIRITE: nou inisyalize memwa sa a pi wo a.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // awondi si nou sispann nan mitan chif si chif sa yo egzakteman 5000 ..., tcheke chif anvan an epi eseye awondi menm (sètadi, evite awondi lè chif anvan an se menm).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SEKIRITE: `buf[len-1]` inisyalize.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // si awondi moute longè a, ekspozan an ta dwe chanje tou.
        // men nou te mande yon nimewo fiks de chif, kidonk pa chanje pezib la ...
        // SEKIRITE: nou inisyalize memwa sa a pi wo a.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... sof si nou te mande presizyon an fiks olye.
            // nou menm tou nou bezwen tcheke ke, si tanpon orijinal la te vid, chif adisyonèl la ka sèlman ajoute lè `k == limit` (ka edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SEKIRITE: nou inisyalize memwa sa a pi wo a.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}