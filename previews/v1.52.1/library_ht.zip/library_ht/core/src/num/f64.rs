//! Konstant espesifik nan `f64` doub-presizyon kalite pwen k ap flote.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Nimewo matematik enpòtan yo bay nan sub-modil la `consts`.
//!
//! Pou konstan yo defini dirèkteman nan modil sa a (tankou diferan de sa yo defini nan sub-modil la `consts`), nouvo kòd yo ta dwe olye pou yo itilize konstan asosye yo defini dirèkteman sou kalite `f64` la.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radix la oswa baz nan reprezantasyon entèn la nan `f64`.
/// Sèvi ak [`f64::RADIX`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // fason gen entansyon
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Kantite chif enpòtan nan baz 2.
/// Sèvi ak [`f64::MANTISSA_DIGITS`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // fason gen entansyon
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Kantite apwoksimatif chif enpòtan nan baz 10.
/// Sèvi ak [`f64::DIGITS`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // fason gen entansyon
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] valè pou `f64`.
/// Sèvi ak [`f64::EPSILON`] olye.
///
/// Sa a se diferans ki genyen ant `1.0` ak pwochen pi gwo nimewo a reprezantab.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // fason gen entansyon
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Pi piti valè `f64` fini.
/// Sèvi ak [`f64::MIN`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // fason gen entansyon
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Pi piti pozitif nòmal `f64` valè.
/// Sèvi ak [`f64::MIN_POSITIVE`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // fason gen entansyon
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Pi gwo valè `f64` fini.
/// Sèvi ak [`f64::MAX`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // fason gen entansyon
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Youn pi gran pase minimòm pouvwa nòmal nòmal 2 ekspozan an.
/// Sèvi ak [`f64::MIN_EXP`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // fason gen entansyon
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Maksimòm pouvwa posib nan 2 ekspozan.
/// Sèvi ak [`f64::MAX_EXP`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // fason gen entansyon
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Minimòm posib pouvwa nòmal nan 10 ekspozan.
/// Sèvi ak [`f64::MIN_10_EXP`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // fason gen entansyon
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Maksimòm pouvwa posib nan 10 ekspozan.
/// Sèvi ak [`f64::MAX_10_EXP`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // fason gen entansyon
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Se pa yon nimewo (NaN).
/// Sèvi ak [`f64::NAN`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // fason gen entansyon
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infini (∞).
/// Sèvi ak [`f64::INFINITY`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // fason gen entansyon
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Negatif infini (−∞).
/// Sèvi ak [`f64::NEG_INFINITY`] olye.
///
/// # Examples
///
/// ```rust
/// // deprecated fason
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // fason gen entansyon
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// De baz konstan matematik.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ranplase ak konstan matematik ki soti nan cmath.

    /// (π) konstan Archimedes la
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Tout sèk konstan (τ) la
    ///
    /// Egal a 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Nimewo Euler a (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// Radix la oswa baz nan reprezantasyon entèn la nan `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Kantite chif enpòtan nan baz 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Kantite apwoksimatif chif enpòtan nan baz 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] valè pou `f64`.
    ///
    /// Sa a se diferans ki genyen ant `1.0` ak pwochen pi gwo nimewo a reprezantab.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Pi piti valè `f64` fini.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Pi piti pozitif nòmal `f64` valè.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Pi gwo valè `f64` fini.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Youn pi gran pase minimòm pouvwa nòmal nòmal 2 ekspozan an.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Maksimòm pouvwa posib nan 2 ekspozan.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Minimòm posib pouvwa nòmal nan 10 ekspozan.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Maksimòm pouvwa posib nan 10 ekspozan.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Se pa yon nimewo (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infini (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Negatif infini (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Retounen `true` si valè sa a se `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` se piblikman disponib nan libcore akòz enkyetid sou Transparans, se konsa aplikasyon sa a se pou itilizasyon prive andedan.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Retounen `true` si valè sa a se enfinite pozitif oswa enfinite negatif, ak `false` otreman.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Retounen `true` si nimewo sa a pa enfini ni `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Pa gen okenn bezwen okipe NaN separeman: si pwòp tèt ou se NaN, konparezon a se pa vre, egzakteman jan yo vle.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Retounen `true` si nimewo a se [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Valè ant `0` ak `min` yo se nòmal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Retounen `true` si nimewo a pa ni zewo, enfini, [subnormal], oswa `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Valè ant `0` ak `min` yo se nòmal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Retounen kategori pwen k ap flote nan nimewo a.
    /// Si se sèlman yon pwopriyete ki pral teste, li jeneralman pi vit pou itilize predikatif espesifik lan olye.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Retounen `true` si `self` gen yon siy pozitif, ki gen ladan `+0.0`, `NaN`s ak ti jan siy pozitif ak Infinity pozitif.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Retounen `true` si `self` gen yon siy negatif, ki gen ladan `-0.0`, `NaN`s ak ti jan siy negatif ak enfinite negatif.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Pran (inverse) resipwòk yon nimewo, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Konvèti radyan an degre.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Divizyon an isit la kòrèkteman awondi ki gen rapò ak valè a vre nan 180/π.
        // (Sa a diferan de f32, kote yo dwe itilize yon konstan pou asire yon rezilta kòrèkteman awondi.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Konvèti degre nan radyan.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Retounen maksimòm de chif yo.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Si youn nan agiman yo se NaN, lè sa a se lòt agiman an retounen.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Retounen minimòm de chif yo.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Si youn nan agiman yo se NaN, lè sa a se lòt agiman an retounen.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Wonn nan direksyon zewo ak konvèti nan nenpòt ki kalite antye relatif primitif, an konsideran ke valè a se fini ak adapte nan ki kalite.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Valè a dwe:
    ///
    /// * Pa dwe `NaN`
    /// * Pa enfini
    /// * Fè reprezantab nan kalite retou `Int` la, apre yo fin koupe pati fraksyon li yo
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Raw transmutasyon `u64`.
    ///
    /// Sa a se kounye a ki idantik ak `transmute::<f64, u64>(self)` sou tout tribin.
    ///
    /// Gade `from_bits` pou kèk diskisyon sou Transparans nan operasyon sa a (gen prèske pa gen okenn pwoblèm).
    ///
    /// Remake byen ke fonksyon sa a distenk de `as` Distribisyon, ki eseye prezève valè a *nimerik*, epi yo pa valè a bit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() se pa Distribisyon!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // SEKIRITE: `u64` se yon plenn datatype fin vye granmoun pou nou ka toujou transmute li
        unsafe { mem::transmute(self) }
    }

    /// Raw transmutasyon soti nan `u64`.
    ///
    /// Sa a se kounye a ki idantik ak `transmute::<u64, f64>(v)` sou tout tribin.
    /// Li sanble ke sa a se ekstrèmman pòtab, pou de rezon:
    ///
    /// * Flote ak Ints gen endianness a menm sou tout tribin sipòte.
    /// * IEEE-754 trè jisteman presize Layout nan ti jan nan flote.
    ///
    /// Sepandan gen yon sèl opozisyon: anvan vèsyon an 2008 nan IEEE-754, ki jan yo entèprete ti jan an siyal NaN pa te aktyèlman espesifye.
    /// Pifò tribin (miyò x86 ak ARM) te chwazi entèpretasyon ki te finalman ofisyèl nan 2008, men kèk pa t '(miyò MIPS).
    /// Kòm yon rezilta, tout NaNs siyal sou MIPS yo NaNs trankil sou x86, ak vis-vèrsa.
    ///
    /// Olye ke eseye prezève siyal-ness kwa-platfòm, aplikasyon sa a favorize prezève Bits yo egzak.
    /// Sa vle di ke nenpòt ki charj kode nan NaNs yo pral konsève menm si se rezilta metòd sa a voye sou rezo a soti nan yon machin x86 nan yon MIPS yon sèl.
    ///
    ///
    /// Si rezilta yo nan metòd sa a yo, se sèlman manipile pa achitekti a menm ki pwodwi yo, Lè sa a, pa gen okenn enkyetid Transparans.
    ///
    /// Si opinyon an se pa NaN, Lè sa a, pa gen okenn enkyetid Transparans.
    ///
    /// Si ou pa pran swen sou siyal-ness (trè chans), Lè sa a, pa gen okenn enkyetid Transparans.
    ///
    /// Remake byen ke fonksyon sa a distenk de `as` Distribisyon, ki eseye prezève valè a *nimerik*, epi yo pa valè a bit.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // SEKIRITE: `u64` se yon plenn datatype fin vye granmoun pou nou ka toujou transmute soti nan li
        // Li sanble pwoblèm sekirite yo ak sNaN te anbale!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Retounen reprezantasyon memwa nimewo pwen k ap flote sa a kòm yon etalaj byte nan gwo-endian (network) lòd byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Retounen reprezantasyon memwa nimewo pwen k ap flote sa a kòm yon etalaj byte nan ti lòd endyte byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Retounen reprezantasyon memwa nimewo pwen sa a k ap flote kòm yon etalaj byte nan lòd byte natif natal.
    ///
    /// Kòm endianness natif natal platfòm sib la itilize, kòd pòtab ta dwe itilize [`to_be_bytes`] oswa [`to_le_bytes`], jan sa apwopriye, olye.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Retounen reprezantasyon memwa nimewo pwen sa a k ap flote kòm yon etalaj byte nan lòd byte natif natal.
    ///
    ///
    /// [`to_ne_bytes`] ta dwe pi pito sou sa a chak fwa sa posib.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // SEKIRITE: `f64` se yon plenn datatype fin vye granmoun pou nou ka toujou transmute li
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Kreye yon valè pwen k ap flote soti nan reprezantasyon li yo kòm yon etalaj byte nan Endian gwo.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Kreye yon valè pwen k ap flote soti nan reprezantasyon li yo kòm yon etalaj byte nan ti endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Kreye yon valè pwen k ap flote soti nan reprezantasyon li yo kòm yon etalaj byte nan endian natif natal.
    ///
    /// Kòm endianness natif natal platfòm sib la itilize, kòd pòtab gen anpil chans vle sèvi ak [`from_be_bytes`] oswa [`from_le_bytes`], jan sa apwopriye olye.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Retounen yon kòmann ant valè pwòp tèt ou ak lòt.
    /// Kontrèman ak konparezon an pati pasyèl ant nimewo pwen k ap flote, konparezon sa a toujou pwodui yon kòmann-nan an akò ak total la lòd predi jan sa defini nan IEEE 754 (2008 revizyon) estanda pwen k ap flote.
    /// Valè yo te bay lòd nan lòd sa yo:
    /// - Negatif trankil NaN
    /// - Siyal negatif NaN
    /// - Infinite negatif
    /// - Nimewo negatif
    /// - Nimewo negatif subnormal
    /// - Zewo negatif
    /// - Pozitif zewo
    /// - Nimewo pozitif subnormal
    /// - Nimewo pozitif
    /// - Enfinite pozitif
    /// - Siyal pozitif NaN
    /// - Pozitif trankil NaN
    ///
    /// Remake byen ke fonksyon sa a pa toujou dakò ak aplikasyon yo [`PartialOrd`] ak [`PartialEq`] nan `f64`.An patikilye, yo konsidere zewo negatif ak pozitif kòm egal, pandan y ap `total_cmp` pa fè sa.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Nan ka negatif, baskile tout Bits yo eksepte siyen an reyalize yon Layout menm jan ak nonb antye relatif konpleman de la
        //
        // Poukisa sa a travay?IEEE 754 flote konpoze de twa jaden:
        // Siyen ti jan, ekspozan ak mantissa.Ansanm nan jaden ekspozan ak mantissa kòm yon antye gen pwopriyete ke lòd bit yo egal a mayitid nimerik kote mayitid la defini.
        // Grandè a pa nòmalman defini sou valè NaN, men IEEE 754 totalOrder defini valè NaN yo tou pou swiv lòd bit.Sa a mennen nan lòd eksplike nan kòmantè a doc.
        // Sepandan, reprezantasyon nan grandè se menm bagay la pou nimewo negatif ak pozitif-se sèlman ti jan an siy diferan.
        // Pou fasilman konpare flote yo kòm nonm antye ki siyen, nou bezwen baskile ekspozan ak manti mantissa yo nan ka ta gen chif negatif.
        // Nou efektivman konvèti chif yo nan fòm "two's complement".
        //
        // Pou fè ranvèrsan an, nou konstwi yon mask ak XOR kont li.
        // Nou branchlessly kalkile yon mask "all-ones except for the sign bit" soti nan valè negatif-siyen: dwa déplacement siy-pwolonje nonb antye relatif la, se konsa nou "fill" mask la ak Bits siy, ak Lè sa a konvèti nan non siyen pouse yon ti kras plis zewo.
        //
        // Sou valè pozitif, mask la se tout zewo, kidonk li nan yon pa gen okenn-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Mete restriksyon sou yon valè nan yon entèval sèten sof si li se NaN.
    ///
    /// Retounen `max` si `self` pi gran pase `max`, ak `min` si `self` pi piti pase `min`.
    /// Sinon sa retounen `self`.
    ///
    /// Remake byen ke fonksyon sa a retounen NaN si valè inisyal la te NaN tou.
    ///
    /// # Panics
    ///
    /// Panics si `min > max`, `min` se NaN, oswa `max` se NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}