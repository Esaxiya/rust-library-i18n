//! # Bibliyotèk Nwayo Rust la
//!
//! Bibliyotèk Nwayo Rust la se depandans-gratis [^ gratis] fondasyon [The Rust Standard Library](../std/index.html).
//! Li se lakòl la pòtab ant lang lan ak bibliyotèk li yo, defini blòk yo intrinsèques ak primitif nan tout kòd Rust.
//!
//! Li lye a pa gen okenn bibliyotèk en, pa gen okenn bibliyotèk sistèm, e pa gen libc.
//!
//! [^free]: Strictly pale, gen kèk senbòl ki nesesè men
//!          yo pa toujou nesesè.
//!
//! Bibliyotèk debaz la se *minimòm*: li pa menm okouran de alokasyon pil, ni li bay konkourans oswa I/O.
//! Bagay sa yo mande pou entegrasyon platfòm, ak bibliyotèk sa a se platfòm-agnostik.
//!
//! # Kouman yo itilize bibliyotèk debaz la
//!
//! Tanpri sonje ke tout detay sa yo kounye a pa konsidere kòm ki estab.
//!
//!
//!
// FIXME: Ranpli m 'ak plis detay lè koòdone nan rezoud
//! Bibliyotèk sa a bati sou sipozisyon kèk senbòl ki egziste deja:
//!
//! * `memcpy`, `memcmp`, `memset`, Sa yo se woutin memwa debaz ki souvan pwodwi pa LLVM.
//! Anplis de sa, bibliyotèk sa a ka fè apèl eksplisit nan fonksyon sa yo.
//! Siyati yo se menm bagay la kòm yo te jwenn nan C.
//!   Fonksyon sa yo souvan bay nan sistèm libc la, men yo ka bay yo tou pa [compiler-builtins crate](https://crates.io/crates/compiler_builtins) la.
//!
//!
//! * `rust_begin_panic` - Fonksyon sa a pran kat agiman, yon `fmt::Arguments`, yon `&'static str`, ak de `u32`.
//! Kat agiman sa yo dikte mesaj panic, dosye kote panic te envoke, ak liy ak kolòn andedan dosye a.
//! Li se jiska konsomatè nan bibliyotèk debaz sa a defini fonksyon sa a panic;li oblije pa janm retounen.
//! Sa mande pou yon atribi `lang` yo te rele `panic_impl`.
//!
//! * `rust_eh_personality` - se itilize pa mekanis yo echèk nan du la.
//! Sa a souvan trase nan fonksyon pèsonalite GCC a, men crates ki pa deklanche yon panic ka asire ke fonksyon sa a pa janm rele.
//! Se atribi `lang` la ki rele `eh_personality`.
//!
//!
//!

// Depi libcore defini anpil atik lang fondamantal, tout tès yo ap viv nan yon crate apa, libcoretest, pou fè pou evite pwoblèm ra.
//
// Isit la nou klèman#[cfg]-out sa a crate antye lè tès la.
// Si nou pa fè sa, tou de asosye tès la pwodwi ak libtest la lye (ki transitively gen ladan libcore) pral tou de defini seri a menm nan atik lang, ak sa a ap lakòz E0152 "found duplicate lang item" erè a.
//
// Gade diskisyon nan #50466 pou plis detay.
//
// CFG sa a pa pral afekte tès doktè yo.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // Gade #65860
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: pa bezwen piblik
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// Rale `core_arch` crate la dirèkteman nan libcore.Sa ki nan `core_arch` yo nan yon depo diferan: rust-lang/stdarch.
//
// `core_arch` depann de libcore, men sa ki nan modil sa a yo mete kanpe nan yon fason ke dirèkteman rale li isit la travay sa yo ki crate a sèvi ak sa a crate kòm libcore li yo.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: Anotasyon sa a ta dwe deplase nan rust-lang/stdarch apre clashing_extern_declarations se
// fusionné.Li kounye a pa kapab paske demaraj echwe kòm lint la pa te defini ankò.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;