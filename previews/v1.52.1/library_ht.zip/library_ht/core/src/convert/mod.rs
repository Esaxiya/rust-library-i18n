//! Traits pou konvèsyon ant kalite yo.
//!
//! traits nan modil sa a bay yon fason pou konvèti de yon kalite a yon lòt kalite.
//! Chak trait sèvi yon objektif diferan:
//!
//! - Aplike [`AsRef`] trait la pou bon mache referans referans a referans
//! - Aplike [`AsMut`] trait a pou bon mache konvèsyon ki ka chanje
//! - Aplike [`From`] trait la pou konsome valè-a-valè konvèsyon
//! - Aplike [`Into`] trait la pou konsome valè-a-valè konvèsyon nan kalite deyò crate aktyèl la.
//! - [`TryFrom`] ak [`TryInto`] traits konpòte yo tankou [`From`] ak [`Into`], men yo ta dwe aplike lè konvèsyon an ka febli.
//!
//! traits nan modil sa a yo souvan itilize kòm trait bounds pou fonksyon jenerik sa yo ki nan agiman nan kalite miltip yo sipòte.Gade dokiman chak trait pou egzanp.
//!
//! Kòm yon otè bibliyotèk, ou ta dwe toujou prefere mete ann aplikasyon [`From<T>`][`From`] oswa [`TryFrom<T>`][`TryFrom`] olye ke [`Into<U>`][`Into`] oswa [`TryInto<U>`][`TryInto`], menm jan [`From`] ak [`TryFrom`] bay pi gwo fleksibilite epi yo ofri ekivalan [`Into`] oswa [`TryInto`] aplikasyon pou gratis, gras a yon aplikasyon dra nan bibliyotèk la estanda.
//! Lè vize yon vèsyon anvan Rust 1.41, li ka nesesè pou aplike [`Into`] oswa [`TryInto`] dirèkteman lè wap konvèti nan yon kalite andeyò crate aktyèl la.
//!
//! # Aplikasyon jenerik
//!
//! - [`AsRef`] ak [`AsMut`] oto-dereference si kalite enteryè a se yon referans
//! - [`Soti nan`]`<U>pou T` implique [`Nan`]`</u><T><U>pou U`</u>
//! - [`TryFrom`]`<U>pou T` implique [`TryInto`]`</u><T><U>pou U`</u>
//! - [`From`] ak [`Into`] yo se refleksif, ki vle di ke tout kalite ka `into` tèt yo ak `from` tèt yo
//!
//! Gade chak trait pou egzanp itilizasyon.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Fonksyon idantite a.
///
/// De bagay yo enpòtan sonje sou fonksyon sa a:
///
/// - Li pa toujou ekivalan a yon fèmti tankou `|x| x`, depi fèmti a ka fòse `x` nan yon kalite diferan.
///
/// - Li deplase opinyon `x` la pase nan fonksyon an.
///
/// Pandan ke li ta ka sanble etranj gen yon fonksyon ki jis retounen tounen opinyon an, gen kèk itilizasyon enteresan.
///
///
/// # Examples
///
/// Lè l sèvi avèk `identity` fè anyen nan yon sekans nan lòt, enteresan, fonksyon:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ann pran pòz ajoute yon sèl se yon fonksyon enteresan.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Sèvi ak `identity` kòm yon ka baz "do nothing" nan yon kondisyonèl:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Fè plis bagay enteresan ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Sèvi ak `identity` kenbe variantes `Some` nan yon iteratè nan `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Itilize fè yon konvèsyon referans bon mache.
///
/// trait sa a sanble ak [`AsMut`] ki itilize pou konvèti ant referans ki ka chanje.
/// Si ou bezwen fè yon konvèsyon koute chè li pi bon aplike [`From`] ak kalite `&T` oswa ekri yon fonksyon koutim.
///
/// `AsRef` gen menm siyati ak [`Borrow`], men [`Borrow`] diferan nan kèk aspè:
///
/// - Kontrèman ak `AsRef`, [`Borrow`] gen yon kouvèti lenn pou nenpòt ki `T`, epi li ka itilize pou aksepte swa yon referans oswa yon valè.
/// - [`Borrow`] egzije tou ke [`Hash`], [`Eq`] ak [`Ord`] pou valè prete yo ekivalan ak sa yo ki gen valè posede.
/// Pou rezon sa a, si ou vle prete sèlman yon sèl jaden nan yon struct ou ka aplike `AsRef`, men se pa [`Borrow`].
///
/// **Note: trait sa a pa dwe febli **.Si konvèsyon an ka febli, sèvi ak yon metòd devwe ki retounen yon [`Option<T>`] oswa yon [`Result<T, E>`].
///
/// # Aplikasyon jenerik
///
/// - `AsRef` oto-referans si kalite enteryè a se yon referans oswa yon referans ki ka chanje (egzanp: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Lè l sèvi avèk trait bounds nou ka aksepte agiman nan diferan kalite osi lontan ke yo ka konvèti nan kalite a espesifye `T`.
///
/// Pou egzanp: Pa kreye yon fonksyon jenerik ki pran yon `AsRef<str>` nou eksprime ke nou vle aksepte tout referans ki ka konvèti nan [`&str`] kòm yon agiman.
/// Depi tou de [`String`] ak [`&str`] aplike `AsRef<str>` nou ka aksepte tou de kòm agiman opinyon.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Fè konvèsyon an.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Itilize pou fè yon bon mache konvèsyon referans ki ka chanje.
///
/// trait sa a sanble ak [`AsRef`] men li itilize pou konvèti ant referans ki ka chanje.
/// Si ou bezwen fè yon konvèsyon koute chè li pi bon aplike [`From`] ak kalite `&mut T` oswa ekri yon fonksyon koutim.
///
/// **Note: trait sa a pa dwe febli **.Si konvèsyon an ka febli, sèvi ak yon metòd devwe ki retounen yon [`Option<T>`] oswa yon [`Result<T, E>`].
///
/// # Aplikasyon jenerik
///
/// - `AsMut` oto-referans si kalite enteryè a se yon referans ki ka chanje (egzanp: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Sèvi ak `AsMut` kòm trait bound pou yon fonksyon jenerik nou ka aksepte tout referans mutable ki ka konvèti nan kalite `&mut T`.
/// Paske [`Box<T>`] aplike `AsMut<T>` nou ka ekri yon fonksyon `add_one` ki pran tout agiman ki ka konvèti nan `&mut u64`.
/// Paske [`Box<T>`] aplike `AsMut<T>`, `add_one` aksepte agiman kalite `&mut Box<u64>` tou:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Fè konvèsyon an.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Yon konvèsyon valè ki konsome valè opinyon an.Opoze a nan [`From`].
///
/// Youn ta dwe evite mete ann aplikasyon [`Into`] epi aplike [`From`] pito.
/// Aplike [`From`] otomatikman bay yon sèl ak yon aplikasyon nan [`Into`] gras a aplikasyon an dra nan bibliyotèk la estanda.
///
/// Prefere lè l sèvi avèk [`Into`] sou [`From`] lè ou presize trait bounds sou yon fonksyon jenerik asire ke kalite ki sèlman aplike [`Into`] ka itilize tou.
///
/// **Note: trait sa a pa dwe febli **.Si konvèsyon an ka febli, itilize [`TryInto`].
///
/// # Aplikasyon jenerik
///
/// - [`Soti nan`]`<T>pou U` implique `Into<U> for T`
/// - [`Into`] se refleksif, ki vle di ke `Into<T> for T` aplike
///
/// # Aplike [`Into`] pou konvèsyon nan kalite ekstèn nan vèsyon fin vye granmoun nan Rust
///
/// Anvan Rust 1.41, si kalite destinasyon an pa te fè pati crate aktyèl la lè sa a ou pa t 'kapab aplike [`From`] dirèkteman.
/// Pou egzanp, pran kòd sa a:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Sa a pral fail konpile nan vèsyon ki pi gran nan lang lan paske règ òfelen Rust a itilize yo dwe yon ti jan pi strik.
/// Pou kontoune sa a, ou ta ka aplike [`Into`] dirèkteman:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Li enpòtan pou konprann ke [`Into`] pa bay yon aplikasyon [`From`] (menm jan [`From`] fè ak [`Into`]).
/// Se poutèt sa, ou ta dwe toujou eseye aplike [`From`] ak Lè sa a, tonbe tounen nan [`Into`] si [`From`] pa ka aplike.
///
/// # Examples
///
/// [`String`] aplike [`Nan`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Yo nan lòd yo eksprime ke nou vle yon fonksyon jenerik yo pran tout agiman ki ka konvèti nan yon kalite espesifye `T`, nou ka itilize yon trait bound nan [`Nan`]`<T>`.
///
/// Pou egzanp: Fonksyon `is_hello` a pran tout agiman ki ka konvèti nan yon [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Fè konvèsyon an.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Itilize fè valè-a-valè konvèsyon pandan y ap konsome valè a opinyon.Li se resipwòk la nan [`Into`].
///
/// Youn ta dwe toujou prefere mete ann aplikasyon `From` sou [`Into`] paske mete ann aplikasyon `From` otomatikman bay youn ak yon aplikasyon [`Into`] gras a aplikasyon dra nan bibliyotèk estanda a.
///
///
/// Sèlman aplike [`Into`] lè vize yon vèsyon anvan Rust 1.41 ak konvèti nan yon kalite deyò crate aktyèl la.
/// `From` pa t 'kapab fè sa yo kalite konvèsyon nan vèsyon pi bonè paske nan règleman òfelen Rust la.
/// Gade [`Into`] pou plis detay.
///
/// Prefere lè l sèvi avèk [`Into`] sou lè l sèvi avèk `From` lè ou presize trait bounds sou yon fonksyon jenerik.
/// Fason sa a, kalite ki dirèkteman aplike [`Into`] ka itilize kòm agiman tou.
///
/// `From` la se tou trè itil lè fè manyen erè.Lè w ap konstwi yon fonksyon ki kapab echwe, kalite retou a pral jeneralman nan fòm `Result<T, E>`.
/// `From` trait la senplifye manyen erè lè li pèmèt yon fonksyon retounen yon kalite erè sèl ki enkapsulasyon kalite erè miltip.Gade seksyon "Examples" ak [the book][book] pou plis detay.
///
/// **Note: trait sa a pa dwe febli **.Si konvèsyon an ka febli, itilize [`TryFrom`].
///
/// # Aplikasyon jenerik
///
/// - `From<T> for U` implique [`Nan`]`<U>pou T`</u>
/// - `From` se refleksif, ki vle di ke `From<T> for T` aplike
///
/// # Examples
///
/// [`String`] aplike `From<&str>`:
///
/// Yon konvèsyon eksplisit soti nan yon `&str` nan yon fisèl fè jan sa a:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Pandan y ap fè manyen erè li souvan itil aplike `From` pou kalite erè pwòp ou yo.
/// Pa konvèti kalite erè kache nan pwòp kalite erè koutim nou an ki enkapsule kalite erè kache a, nou ka retounen yon kalite erè sèl san nou pa pèdi enfòmasyon sou kòz ki kache.
/// Operatè a '?' otomatikman konvèti kalite erè kache nan kalite erè koutim nou an lè w rele `Into<CliError>::into` ki otomatikman bay lè w ap aplike `From`.
/// Konpilatè a Lè sa a, dedwi ki aplikasyon `Into` yo ta dwe itilize.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Fè konvèsyon an.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Yon tantativ konvèsyon ki konsome `self`, ki ka oswa pa ka chè.
///
/// Otè Bibliyotèk yo pa ta dwe anjeneral aplike dirèkteman trait sa a, men yo ta dwe prefere aplike [`TryFrom`] trait, ki ofri pi gwo fleksibilite epi ki bay yon ekivalan `TryInto` aplikasyon pou gratis, gras a yon aplikasyon dra nan bibliyotèk la estanda.
/// Pou plis enfòmasyon sou sa, gade dokiman pou [`Into`].
///
/// # Aplike `TryInto`
///
/// Sa a soufri menm restriksyon yo ak rezònman kòm aplike [`Into`], gade la pou plis detay.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Kalite a retounen nan evènman an nan yon erè konvèsyon.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Fè konvèsyon an.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Konvèsyon kalite senp epi san danje ki ka echwe nan yon fason kontwole nan kèk sikonstans.Li se resipwòk la nan [`TryInto`].
///
/// Sa a itil lè w ap fè yon konvèsyon kalite ki ka trivialman reyisi men li ka bezwen tou manyen espesyal.
/// Pou egzanp, pa gen okenn fason konvèti yon [`i64`] nan yon [`i32`] lè l sèvi avèk [`From`] trait a, paske yon [`i64`] ka gen ladan yon valè ke yon [`i32`] pa ka reprezante e konsa konvèsyon an ta pèdi done.
///
/// Sa a ta ka okipe pa koupe [`i64`] nan yon [`i32`] (esansyèlman bay [`i64`] valè modulo [`i32::MAX`] a) oswa pa senpleman retounen [`i32::MAX`], oswa pa kèk lòt metòd.
/// [`From`] trait la fèt pou konvèsyon pafè, kidonk `TryFrom` trait enfòme pwogramè a lè yon konvèsyon kalite ta ka ale move epi li pèmèt yo deside ki jan yo okipe li.
///
/// # Aplikasyon jenerik
///
/// - `TryFrom<T> for U` implique [`TryInto`]`<U>pou T`</u>
/// - [`try_from`] se refleksif, ki vle di ke `TryFrom<T> for T` aplike epi yo pa ka febli-kalite ki asosye `Error` pou rele `T::try_from()` sou yon valè de kalite `T` se [`Infallible`].
/// Lè kalite [`!`] la estabilize [`Infallible`] ak [`!`] pral ekivalan.
///
/// `TryFrom<T>` kapab aplike jan sa a:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Jan sa dekri, [`i32`] aplike `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // An silans tronkonik `big_number`, mande pou detekte ak manyen tronkonik la apre reyalite a.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Retounen yon erè paske `big_number` twò gwo pou anfòm nan yon `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Retounen `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Kalite a retounen nan evènman an nan yon erè konvèsyon.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Fè konvèsyon an.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS JENERIK
////////////////////////////////////////////////////////////////////////////////

// Kòm asanseur sou&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Kòm asanseur sou &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ranplase pi wo a impls pou&/&mut ak sa ki pi jeneral la:
// // Kòm asanseur sou Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Gwosè> AsRef <U>pou D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut asanseur sou &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ranplase pi wo a impl pou &mut ak sa ki pi jeneral la:
// // AsMut asanseur sou DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Gwosè> AsMut <U>pou D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Soti nan implique nan
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Soti nan (e konsa nan) se refleksyon
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Remak estabilite:** Impl sa a poko egziste, men nou se "reserving space" pou ajoute li nan future la.
/// Gade [rust-lang/rust#64715][#64715] pou plis detay.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): fè yon ranje prensip olye.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implique TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Konvèsyon enfayib yo se semantik ekivalan a konvèsyon fayib ak yon kalite erè dezole.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS KONKRÈT
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// TIP ERÈ NON-ERÈ
////////////////////////////////////////////////////////////////////////////////

/// Kalite erè pou erè ki pa janm ka rive.
///
/// Depi enum sa a pa gen okenn Variant, yon valè de kalite sa a pa janm ka egziste aktyèlman.
/// Sa a ka itil pou API jenerik ki itilize [`Result`] ak paramètize kalite erè a, pou endike ke rezilta a toujou [`Ok`].
///
/// Pou egzanp, [`TryFrom`] trait a (konvèsyon ki retounen yon [`Result`]) gen yon aplikasyon dra pou tout kalite kote yon aplikasyon ranvèse [`Into`] egziste.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future konpatibilite
///
/// Enum sa a gen menm wòl ak [the `!`“never”type][never], ki enstab nan vèsyon sa a nan Rust.
/// Lè `!` estabilize, nou fè plan pou fè `Infallible` yon alyas kalite li:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ak evantyèlman deprecate `Infallible`.
///
/// Sepandan gen yon ka kote sentaks `!` ka itilize anvan `!` estabilize kòm yon kalite plen véritable: nan pozisyon kalite retou fonksyon an.
/// Espesyalman, li posib aplikasyon pou de kalite diferan konsèy fonksyon:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Avèk `Infallible` ke yo te yon enum, kòd sa a valab.
/// Sepandan lè `Infallible` vin tounen yon alyas pou never type a, de `impl` yo pral kòmanse sipèpoze ak Se poutèt sa yo pral ranvwaye pa règleman koerans lang lan trait la.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}