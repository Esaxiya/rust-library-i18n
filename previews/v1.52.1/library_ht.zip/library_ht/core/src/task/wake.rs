#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Yon `RawWaker` pèmèt implementor nan yon ègzèkuteur travay yo kreye yon [`Waker`] ki bay konpòtman reveye Customized.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Li konsiste de yon konsèy done ak yon [virtual function pointer table (vtable)][vtable] ki Customizes konpòtman an nan `RawWaker` la.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Yon konsèy done, ki ka itilize pou estoke done abitrè jan egzekitè a egzije sa.
    /// Sa a ta ka egzanp
    /// yon konsèy tip-efase nan yon `Arc` ki asosye ak travay la.
    /// Valè a nan jaden sa a vin pase nan tout fonksyon ki fè pati vtable a kòm paramèt an premye.
    ///
    data: *const (),
    /// Virtual tablo konsèy konsèy ki Customize konpòtman sa a waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Kreye yon nouvo `RawWaker` soti nan konsèy la bay `data` ak `vtable`.
    ///
    /// Ka konsèy la `data` dwe itilize nan magazen done abitrè jan sa nesesè pa ègzèkutor la.Sa a ta ka egzanp
    /// yon konsèy tip-efase nan yon `Arc` ki asosye ak travay la.
    /// Valè sa a konsèy ap jwenn pase nan tout fonksyon ki fè pati `vtable` la kòm paramèt an premye.
    ///
    /// `vtable` la Customize konpòtman yon `Waker` ki vin kreye nan yon `RawWaker`.
    /// Pou chak operasyon sou `Waker` la, yo pral rele fonksyon ki asosye nan `vtable` nan kache `RawWaker` la.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Yon tab vityèl konsèy konsèy (vtable) ki presize konpòtman yon [`RawWaker`].
///
/// Konsèy la pase nan tout fonksyon andedan vtable la se konsèy `data` ki soti nan objè ki fèmen [`RawWaker`] la.
///
/// Fonksyon yo andedan struct sa a yo fèt sèlman yo dwe rele sou konsèy la `data` nan yon objè byen konstwi [`RawWaker`] soti nan andedan aplikasyon an [`RawWaker`].
/// Rele youn nan fonksyon ki genyen yo lè l sèvi avèk nenpòt lòt konsèy `data` ap lakòz konpòtman endefini.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Fonksyon sa a pral rele lè [`RawWaker`] a vin klone, egzanp lè [`Waker`] la nan ki [`RawWaker`] a ki estoke vin klone.
    ///
    /// Aplikasyon fonksyon sa a dwe kenbe tout resous ki nesesè pou egzanp sa a anplis nan yon [`RawWaker`] ak travay ki asosye.
    /// Rele `wake` sou [`RawWaker`] ki kapab lakòz la ta dwe lakòz yon reveye nan menm travay la ki ta te reveye pa [`RawWaker`] orijinal la.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Fonksyon sa a pral rele lè `wake` yo rele sou [`Waker`] la.
    /// Li dwe reveye travay la ki asosye ak [`RawWaker`] sa a.
    ///
    /// Aplikasyon an nan fonksyon sa a dwe asire w ke ou lage nenpòt resous ki asosye ak sa a egzanp nan yon [`RawWaker`] ak travay ki asosye yo.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Fonksyon sa a pral rele lè `wake_by_ref` yo rele sou [`Waker`] la.
    /// Li dwe reveye travay la ki asosye ak [`RawWaker`] sa a.
    ///
    /// Fonksyon sa a sanble ak `wake`, men li pa dwe konsome konsèy done yo bay la.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Fonksyon sa a rele lè yon [`RawWaker`] vin tonbe.
    ///
    /// Aplikasyon an nan fonksyon sa a dwe asire w ke ou lage nenpòt resous ki asosye ak sa a egzanp nan yon [`RawWaker`] ak travay ki asosye yo.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Kreye yon nouvo `RawWakerVTable` soti nan fonksyon yo bay `clone`, `wake`, `wake_by_ref`, ak `drop`.
    ///
    /// # `clone`
    ///
    /// Fonksyon sa a pral rele lè [`RawWaker`] a vin klone, egzanp lè [`Waker`] la nan ki [`RawWaker`] a ki estoke vin klone.
    ///
    /// Aplikasyon fonksyon sa a dwe kenbe tout resous ki nesesè pou egzanp sa a anplis nan yon [`RawWaker`] ak travay ki asosye.
    /// Rele `wake` sou [`RawWaker`] ki kapab lakòz la ta dwe lakòz yon reveye nan menm travay la ki ta te reveye pa [`RawWaker`] orijinal la.
    ///
    /// # `wake`
    ///
    /// Fonksyon sa a pral rele lè `wake` yo rele sou [`Waker`] la.
    /// Li dwe reveye travay la ki asosye ak [`RawWaker`] sa a.
    ///
    /// Aplikasyon an nan fonksyon sa a dwe asire w ke ou lage nenpòt resous ki asosye ak sa a egzanp nan yon [`RawWaker`] ak travay ki asosye yo.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Fonksyon sa a pral rele lè `wake_by_ref` yo rele sou [`Waker`] la.
    /// Li dwe reveye travay la ki asosye ak [`RawWaker`] sa a.
    ///
    /// Fonksyon sa a sanble ak `wake`, men li pa dwe konsome konsèy done yo bay la.
    ///
    /// # `drop`
    ///
    /// Fonksyon sa a rele lè yon [`RawWaker`] vin tonbe.
    ///
    /// Aplikasyon an nan fonksyon sa a dwe asire w ke ou lage nenpòt resous ki asosye ak sa a egzanp nan yon [`RawWaker`] ak travay ki asosye yo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` nan yon travay asenkron.
///
/// Kounye a, `Context` sèvi sèlman pou bay aksè a yon `&Waker` ki ka itilize pou reveye travay aktyèl la.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Asire nou future-prèv kont chanjman divèjans pa fòse tout lavi a yo dwe invariant (agiman-pozisyon vi yo contravariant pandan y ap retounen-pozisyon vi yo covariant).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Kreye yon nouvo `Context` ki sòti nan yon `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Retounen yon referans a `Waker` pou travay aktyèl la.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Yon `Waker` se yon manch pou reveye yon travay pa avize ègzekuteur li yo ke li se pare yo dwe kouri.
///
/// Manch sa a enkapsule yon egzanp [`RawWaker`], ki defini konpòtman reveye ègzèkuteur-espesifik la.
///
///
/// Aplike [`Clone`], [`Send`], ak [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Reveye travay la ki asosye ak `Waker` sa a.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Se apèl la reveye aktyèl delege nan yon apèl fonksyon vityèl nan aplikasyon an ki se defini pa ègzèkutor la.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Pa rele `drop`-waker la pral boule nan `wake`.
        crate::mem::forget(self);

        // SEKIRITE: Sa a an sekirite paske `Waker::from_raw` se yon fason a sèlman
        // inisyalize `wake` ak `data` ki egzije pou itilizatè a rekonèt ke kontra `RawWaker` la konfime.
        //
        unsafe { (wake)(data) };
    }

    /// Reveye travay la ki asosye ak sa a `Waker` san yo pa konsome `Waker` la.
    ///
    /// Sa a se menm jan ak `wake`, men li ka yon ti kras mwens efikas nan ka a kote yon posede `Waker` ki disponib.
    /// Metòd sa a ta dwe pi pito ke yo rele `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Se apèl la reveye aktyèl delege nan yon apèl fonksyon vityèl nan aplikasyon an ki se defini pa ègzèkutor la.
        //

        // SEKIRITE: gade `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Retounen `true` si `Waker` sa a ak yon lòt `Waker` te reveye menm travay la.
    ///
    /// Fonksyon sa a ap travay sou yon baz pi bon efò, epi yo ka retounen fo menm lè `Waker la ta reveye menm travay la.
    /// Sepandan, si fonksyon sa a retounen `true`, li garanti ke `Waker` yo pral reveye menm travay la.
    ///
    /// Fonksyon sa a sitou itilize pou rezon optimize.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Kreye yon nouvo `Waker` soti nan [`RawWaker`].
    ///
    /// Konpòtman `Waker` retounen an pa defini si kontra a defini nan dokiman [`RawWaker`] ak [`RawWakerVTable`] pa konfime.
    ///
    /// Se poutèt sa, metòd sa a an sekirite.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SEKIRITE: Sa a an sekirite paske `Waker::from_raw` se yon fason a sèlman
            // inisyalize `clone` ak `data` ki egzije pou itilizatè a rekonèt ke kontra [`RawWaker`] la konfime.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SEKIRITE: Sa a an sekirite paske `Waker::from_raw` se yon fason a sèlman
        // inisyalize `drop` ak `data` ki egzije pou itilizatè a rekonèt ke kontra `RawWaker` la konfime.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}