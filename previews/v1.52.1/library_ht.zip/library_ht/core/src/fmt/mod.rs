//! Itilite pou fòma ak enprime fisèl.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Aliman posib retounen pa `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Endikasyon ke sa yo ta dwe kite-aliyen.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Endikasyon ke sa yo ta dwe dwat-aliyen.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Endikasyon ke sa yo ta dwe sant-aliyen.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Kalite a retounen pa metòd fòma.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Kalite erè ki retounen nan fòma yon mesaj nan yon kouran.
///
/// Kalite sa a pa sipòte transmisyon nan yon erè lòt pase ke yon erè ki te fèt.
/// Nenpòt enfòmasyon siplemantè dwe ranje yo dwe transmèt nan kèk lòt mwayen.
///
/// Yon bagay enpòtan yo sonje se ke kalite a `fmt::Error` pa ta dwe konfonn ak [`std::io::Error`] oswa [`std::error::Error`], ki ou ka genyen tou nan sijè ki abòde lan.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Yon trait pou ekri oswa fòma nan tanpon Unicode-aksepte oswa kouran.
///
/// trait sa a sèlman aksepte done UTF-8-kode epi li pa [flushable].
/// Si ou sèlman vle aksepte Unicode epi ou pa bezwen flòch, ou ta dwe aplike trait sa a;
/// otreman ou ta dwe aplike [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Ekri yon tranch fisèl nan ekriven sa a, retounen si wi ou non ekri a reyisi.
    ///
    /// Metòd sa a kapab sèlman reyisi si tranch la fisèl tout te avèk siksè ekri, ak metòd sa a pa pral retounen jiskaske tout done yo te ekri oswa yon erè rive.
    ///
    ///
    /// # Errors
    ///
    /// Fonksyon sa a pral retounen yon egzanp [`Error`] sou erè.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Ekri yon [`char`] nan ekriven sa a, retounen si wi ou non ekri a reyisi.
    ///
    /// Yon sèl [`char`] ka kode kòm plis pase yon octet.
    /// Metòd sa a ka sèlman reyisi si tout sekans byte a te ekri avèk siksè, epi metòd sa a pa pral retounen jiskaske tout done yo te ekri oswa yon erè rive.
    ///
    ///
    /// # Errors
    ///
    /// Fonksyon sa a pral retounen yon egzanp [`Error`] sou erè.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Lakòl pou itilizasyon macro [`write!`] la ak enplemante sa a trait.
    ///
    /// Metòd sa a ta dwe jeneralman pa dwe envoke manyèlman, men pito nan [`write!`] macro nan tèt li.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Konfigirasyon pou fòma.
///
/// Yon `Formatter` reprezante divès opsyon ki gen rapò ak fòma.
/// Itilizatè yo pa konstwi `Formatter` dirèkteman;se yon referans mutable nan yon sèl pase nan metòd la `fmt` nan tout fòma traits, tankou [`Debug`] ak [`Display`].
///
///
/// Pou kominike avèk yon `Formatter`, ou pral rele divès metòd pou chanje divès opsyon ki gen rapò ak fòma.
/// Pou egzanp, tanpri al gade dokiman ki nan metòd yo defini sou `Formatter` anba a.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Agiman se esansyèlman yon optimize pasyèlman aplike fonksyon fòma, ekivalan a `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Struct sa a reprezante "argument" jenerik ki pran pa fanmi fonksyon Xprintf.Li gen yon fonksyon fòma valè yo bay la.
/// Nan tan konpile li asire ke fonksyon an ak valè a gen kalite ki kòrèk yo, ak Lè sa a, struct sa a itilize kanonize agiman nan yon sèl kalite.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Sa a garanti yon sèl valè ki estab pou konsèy la fonksyon ki asosye ak indices/counts nan enfrastrikti nan fòma.
//
// Remake byen ke yon fonksyon defini tankou sa yo pa ta dwe kòrèk kòm fonksyon yo toujou atenn unnamed_addr ak aktyèl la bese nan LLVM IR, se konsa adrès yo pa konsidere kòm enpòtan nan LLVM ak jan sa yo ka jete nan as_usize yo te mal konpile.
//
// Nan pratik, nou pa janm rele as_usize sou done ki pa usize ki gen ladan (kòm yon kesyon de jenerasyon estatik nan agiman yo fòma), kidonk sa a se senpleman yon chèk adisyonèl.
//
// Nou sitou vle asire ke konsèy la fonksyon nan `USIZE_MARKER` gen yon adrès ki koresponn *sèlman* nan fonksyon ki tou pran `&usize` kòm agiman premye yo.
// Read_volatile a isit la asire ke nou ka san danje pare soti yon usize soti nan referans la pase e ke adrès sa a pa pwen nan yon fonksyon ki pa Peye-usize pran.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // SEKIRITE: ptr se yon referans
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // SEKIRITE: `mem::transmute(x)` an sekirite paske
        //     1. `&'b T` kenbe tout lavi li soti ak `'b` (konsa tankou pa gen yon lavi san limit)
        //     2.
        //     `&'b T` ak `&'b Opaque` gen menm layout memwa a (lè `T` se `Sized`, menm jan li isit la) `mem::transmute(f)` an sekirite depi `fn(&T, &mut Formatter<'_>) -> Result` ak `fn(&Opaque, &mut Formatter<'_>) -> Result` gen menm ABI a (toutotan `T` se `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // SEKIRITE: se jaden `formatter` la sèlman mete nan USIZE_MARKER si
            // valè a se yon usize, kidonk sa a san danje
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// drapo ki disponib nan fòma v1 nan format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Lè w ap itilize format_args la! () Macro, yo itilize fonksyon sa a pou jenere estrikti Agiman yo.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Fonksyon sa a itilize pou presize paramèt fòma ki pa estanda.
    /// Etalaj `pieces` la dwe omwen osi lontan ke `fmt` pou konstwi yon estrikti Agiman valab.
    /// Epitou, nenpòt `Count` nan `fmt` ki se `CountIsParam` oswa `CountIsNextParam` gen nan pwen nan yon agiman ki te kreye ak `argumentusize`.
    ///
    /// Sepandan, li pap fè sa pa lakòz sekirite, men li pral inyore envalid.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Estime longè tèks fòma a.
    ///
    /// Sa a fèt pou itilize pou mete premye kapasite `String` lè w ap itilize `format!`.
    /// Note: sa a pa ni anba ni anba a.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Si fisèl la fòma kòmanse ak yon agiman, pa prealokate anyen, sof si longè moso yo enpòtan.
            //
            //
            0
        } else {
            // Gen kèk agiman, se konsa nenpòt pouse adisyonèl pral reasigne fil la.
            //
            // Pou evite sa, nou ap "pre-doubling" kapasite isit la.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Estrikti sa a reprezante yon vèsyon precompiled san danje nan yon kòd fòma ak agiman li yo.
/// Sa a pa ka pwodwi nan ègzekutabl paske li pa ka san danje dwe fè, kidonk pa gen okenn konstriktè yo bay ak jaden yo prive yo anpeche modifikasyon.
///
///
/// Macro [`format_args!`] la pral kreye san danje yon egzanp nan estrikti sa a.
/// Macro a valide fisèl la fòma nan konpile-tan pou l 'nan fonksyon yo [`write()`] ak [`format()`] ka san danje fèt.
///
/// Ou ka itilize `Arguments<'a>` la ki [`format_args!`] retounen nan kontèks `Debug` ak `Display` jan yo wè anba a.
/// Egzanp lan montre ke fòma `Debug` ak `Display` menm bagay la tou: fisèl fòma entèpolasyon nan `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Fòma moso fisèl pou enprime.
    pieces: &'a [&'static str],

    // Espas Placeholder, oswa `None` si tout karakteristik yo default (tankou nan "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Agiman dinamik pou entèpolasyon, yo dwe interleaved ak moso fisèl.
    // (Chak agiman anvan pa yon moso fisèl.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Jwenn fisèl la fòma, si li pa gen okenn agiman yo dwe fòma.
    ///
    /// Sa a ka itilize pou fè pou evite alokasyon nan ka ki pi trivial.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` ta dwe fòma pwodiksyon an nan yon pwogramè-fè fas a, kontèks debogaj.
///
/// Anjeneral pale, ou ta dwe jis `derive` yon aplikasyon `Debug`.
///
/// Lè yo itilize li ak lòt fòma espesifik `#?` la, pwodiksyon an trè-enprime.
///
/// Pou plis enfòmasyon sou fòma, gade [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// trait sa a ka itilize ak `#[derive]` si tout jaden aplike `Debug`.
/// Lè `derive`d pou structs, li pral sèvi ak non an nan `struct` a, Lè sa a, `{`, Lè sa a, yon lis vigil-separe nan non chak jaden an ak valè `Debug`, Lè sa a, `}`.
/// Pou `enum`s, li pral sèvi ak non an nan Variant a, epi, si sa aplikab, `(`, Lè sa a, valè yo `Debug` nan jaden yo, Lè sa a, `)`.
///
/// # Stability
///
/// Fòme `Debug` sòti yo pa estab, e konsa ka chanje avèk vèsyon future Rust.
/// Anplis de sa, aplikasyon `Debug` nan kalite ki ofri nan bibliyotèk la estanda (`libstd`, `libcore`, `liballoc`, elatriye) yo pa estab, epi yo ka chanje tou ak vèsyon future Rust.
///
///
/// # Examples
///
/// Dérivé yon aplikasyon:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Manyèlman mete ann aplikasyon:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Gen yon kantite metòd pou ede sou struct [`Formatter`] la pou ede ou avèk aplikasyon manyèl, tankou [`debug_struct`].
///
/// `Debug` aplikasyon lè l sèvi avèk swa `derive` oswa debug mason API la sou [`Formatter`] sipò bèl-enprime lè l sèvi avèk drapo a altène: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Joli-enprime ak `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Fòma valè a lè l sèvi avèk fòma yo bay la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Separe modil pou reexport macro `Debug` la soti nan prelude san trait `Debug` la.
pub(crate) mod macros {
    /// Rive macro génération yon impl nan trait `Debug` la.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Fòma trait pou yon fòma vid, `{}`.
///
/// `Display` se menm jan ak [`Debug`], men `Display` se pou itilizatè-fè fas a pwodiksyon, e konsa pa ka sòti.
///
///
/// Pou plis enfòmasyon sou fòma, gade [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Aplike `Display` sou yon kalite:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Fòma valè a lè l sèvi avèk fòma yo bay la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait a ta dwe fòma pwodiksyon li kòm yon nimewo nan base-8.
///
/// Pou nonm antye relatif siyen primitif (`i8` a `i128`, ak `isize`), valè negatif yo fòma kòm reprezantasyon konpleman de la.
///
///
/// Drapo altènatif la, `#`, ajoute yon `0o` devan pwodiksyon an.
///
/// Pou plis enfòmasyon sou fòma, gade [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Itilizasyon debaz ak `i32`:
///
/// ```
/// let x = 42; // 42 se '52' nan oktal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Aplike `Octal` sou yon kalite:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // delege nan aplikasyon i32 la
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Fòma valè a lè l sèvi avèk fòma yo bay la.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait a ta dwe fòma pwodiksyon li kòm yon nimewo nan binè.
///
/// Pou nonm antye relatif siyen primitif ([`i8`] a [`i128`], ak [`isize`]), valè negatif yo fòma kòm reprezantasyon konpleman de la.
///
///
/// Drapo altènatif la, `#`, ajoute yon `0b` devan pwodiksyon an.
///
/// Pou plis enfòmasyon sou fòma, gade [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Itilizasyon debaz ak [`i32`]:
///
/// ```
/// let x = 42; // 42 se '101010' nan binè
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Aplike `Binary` sou yon kalite:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // delege nan aplikasyon i32 la
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Fòma valè a lè l sèvi avèk fòma yo bay la.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait a ta dwe fòma pwodiksyon li kòm yon nimewo nan ekzadesimal, ak `a` jiska `f` nan miniskil.
///
/// Pou nonm antye relatif siyen primitif (`i8` a `i128`, ak `isize`), valè negatif yo fòma kòm reprezantasyon konpleman de la.
///
///
/// Drapo altènatif la, `#`, ajoute yon `0x` devan pwodiksyon an.
///
/// Pou plis enfòmasyon sou fòma, gade [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Itilizasyon debaz ak `i32`:
///
/// ```
/// let x = 42; // 42 se '2a' nan hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Aplike `LowerHex` sou yon kalite:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // delege nan aplikasyon i32 la
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Fòma valè a lè l sèvi avèk fòma yo bay la.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait a ta dwe fòma pwodiksyon li kòm yon nimewo nan ekzadesimal, ak `A` jiska `F` nan majiskil.
///
/// Pou nonm antye relatif siyen primitif (`i8` a `i128`, ak `isize`), valè negatif yo fòma kòm reprezantasyon konpleman de la.
///
///
/// Drapo altènatif la, `#`, ajoute yon `0x` devan pwodiksyon an.
///
/// Pou plis enfòmasyon sou fòma, gade [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Itilizasyon debaz ak `i32`:
///
/// ```
/// let x = 42; // 42 se '2A' nan hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Aplike `UpperHex` sou yon kalite:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // delege nan aplikasyon i32 la
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Fòma valè a lè l sèvi avèk fòma yo bay la.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait a ta dwe fòma pwodiksyon li kòm yon kote memwa.
/// Sa a se souvan prezante kòm ekzadesimal.
///
/// Pou plis enfòmasyon sou fòma, gade [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Itilizasyon debaz ak `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // sa pwodui yon bagay tankou '0x7f06092ac6d0'
/// ```
///
/// Aplike `Pointer` sou yon kalite:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // sèvi ak `as` konvèti nan yon `*const T`, ki aplike Pointer, ke nou ka itilize
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Fòma valè a lè l sèvi avèk fòma yo bay la.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait a ta dwe fòma pwodiksyon li yo nan notasyon syantifik ak yon `e` miniskil.
///
/// Pou plis enfòmasyon sou fòma, gade [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Itilizasyon debaz ak `f64`:
///
/// ```
/// let x = 42.0; // 42.0 se '4.2e1' nan notasyon syantifik
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Aplike `LowerExp` sou yon kalite:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // delege nan aplikasyon f64 la
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Fòma valè a lè l sèvi avèk fòma yo bay la.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait a ta dwe fòma pwodiksyon li yo nan notasyon syantifik ak yon `E` majiskil.
///
/// Pou plis enfòmasyon sou fòma, gade [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Itilizasyon debaz ak `f64`:
///
/// ```
/// let x = 42.0; // 42.0 se '4.2E1' nan notasyon syantifik
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Aplike `UpperExp` sou yon kalite:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // delege nan aplikasyon f64 la
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Fòma valè a lè l sèvi avèk fòma yo bay la.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Fonksyon `write` a pran yon kouran pwodiksyon, ak yon struct `Arguments` ki ka precompiled ak macro la `format_args!`.
///
///
/// Agiman yo pral fòma selon fisèl la fòma espesifye nan kouran an pwodiksyon yo bay yo.
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Tanpri sonje ke lè l sèvi avèk [`write!`] ta ka pi preferab.Egzanp:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Nou ka itilize paramèt fòma default pou tout agiman.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Chak espèk gen yon agiman korespondan ki anvan pa yon moso fisèl.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // SEKIRITE: arg ak args.args soti nan Agiman yo menm,
                // ki garanti endis yo toujou nan limit.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Kapab genyen sèlman yon sèl moso fisèl ki rete.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // SEKIRITE: arg ak arg soti nan Agiman yo menm,
    // ki garanti endis yo toujou nan limit.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Ekstrè agiman ki kòrèk la
    debug_assert!(arg.position < args.len());
    // SEKIRITE: arg ak arg soti nan Agiman yo menm,
    // ki garanti endèks li se toujou nan limit.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Lè sa a, aktyèlman fè kèk enprime
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // SEKIRITE: cnt ak args soti nan Agiman yo menm,
            // ki garanti endèks sa a toujou nan limit.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Matlasye apre fen yon bagay.Retounen pa `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Ekri sa a ranpli padding.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Nou vle chanje sa
            buf: wrap(self.buf),

            // Epi prezève sa yo
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Metòd Èd yo itilize pou padding ak pwosesis agiman fòma ke tout fòma traits ka itilize.
    //

    /// Fè padding ki kòrèk la pou yon nonb antye relatif ki te deja emèt nan yon str.
    /// Str la ta dwe *pa* gen ladan siy pou nonb antye relatif la, ke yo pral ajoute pa metòd sa a.
    ///
    /// # Arguments
    ///
    /// * is_negegative, si nonb antye relatif orijinal la te swa pozitif oswa zewo.
    /// * prefiks, si yo bay karaktè '#' (Alternate) la, sa a se prefiks pou mete devan nimewo a.
    ///
    /// * buf, etalaj la byte ke nimewo a te fòma nan
    ///
    /// Fonksyon sa a pral kòrèkteman kont pou drapo yo bay kòm byen ke lajè minimòm lan.
    /// Li pa pral pran presizyon an kont.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Nou bezwen retire "-" soti nan pwodiksyon an nimewo.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Ekri siy la si li egziste, ak Lè sa a, prefiks la si li te mande
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Jaden `width` se plis pase yon paramèt `min-width` nan pwen sa a.
        match self.width {
            // Si pa gen okenn kondisyon longè minimòm Lè sa a, nou ka jis ekri bytes yo.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Tcheke si nou sou lajè minimòm lan, si se konsa Lè sa a, nou ka tou jis ekri bytes yo.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Siy la ak prefiks ale anvan padding la si karaktè ranpli a se zewo
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Sinon, siy la ak prefiks ale apre padding la
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Fonksyon sa a pran yon tranch fisèl ak emèt li nan tanpon entèn la apre ou fin aplike drapo ki enpòtan fòma espesifye.
    /// Drapo yo rekonèt pou strings jenerik yo se:
    ///
    /// * lajè, lajè minimòm de sa yo emèt
    /// * fill/align - ki sa yo emèt ak ki kote yo emèt li si fisèl la bay bezwen Matlasye
    /// * presizyon, longè a maksimòm emèt, se fisèl la koupe si li pi long pase longè sa a
    ///
    /// Miyò fonksyon sa a inyore paramèt `flag` yo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Asire w ke gen yon chemen vit devan
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Ka jaden an `precision` dwe entèprete kòm yon `max-width` pou fisèl la ke yo te fòma.
        //
        let s = if let Some(max) = self.precision {
            // Si fisèl nou an pi long ke presizyon an, Lè sa a, nou dwe gen koupe.
            // Sepandan lòt drapo tankou `fill`, `width` ak `align` dwe aji kòm toujou.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM isit la pa ka pwouve ke `..i` pa pral panic `&s[..i]`, men nou konnen ke li pa kapab panic.
                // Sèvi ak `get` + `unwrap_or` pou fè pou evite `unsafe` ak otreman pa emèt okenn kòd ki gen rapò ak panic isit la.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Jaden `width` se plis pase yon paramèt `min-width` nan pwen sa a.
        match self.width {
            // Si nou anba longè maksimòm lan, epi pa gen okenn kondisyon longè minimòm, lè sa a nou ka jis emèt fisèl la
            //
            None => self.buf.write_str(s),
            // Si nou anba lajè maksimòm lan, tcheke si nou sou lajè minimòm lan, si se konsa li fasil tankou jis emèt fisèl la.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Si nou anba tou de maksimòm ak lajè minimòm lan, lè sa a ranpli lajè minimòm lan avèk fisèl la espesifye + kèk aliyman.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Ekri pre-padding la epi retounen pòs-padding la pa ekri.
    /// Moun kap rele yo responsab pou asire pòs-padding ekri apre bagay la ke yo te Matlasye.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Pran pati yo fòma ak aplike padding la.
    /// Sipoze ke moun kap rele a te deja rann pati yo ak presizyon obligatwa, se konsa ke `self.precision` ka inyore.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // pou siy-okouran zewo padding la, nou rann siy lan an premye epi konpòte nou tankou si nou pa te gen okenn siy depi nan konmansman an.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // yon siy toujou ale an premye
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // retire siy lan nan pati yo fòma
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // pati ki rete ale nan pwosesis la padding òdinè.
            let len = formatted.len();
            let ret = if width <= len {
                // pa gen okenn padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // sa a se ka a komen epi nou pran yon chemen kout
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // SEKIRITE: Sa a se itilize pou `flt2dec::Part::Num` ak `flt2dec::Part::Copy`.
            // Li san danje pou itilize pou `flt2dec::Part::Num` depi chak `c` char ant `b'0'` ak `b'9'`, ki vle di `s` valab UTF-8.
            // Li la tou pwobableman an sekirite nan pratik yo itilize pou `flt2dec::Part::Copy(buf)` depi `buf` yo ta dwe ASCII plenn, men li posib pou yon moun pase nan yon valè move pou `buf` nan `flt2dec::to_shortest_str` depi li se yon fonksyon piblik.
            //
            // FIXME: Detèmine si sa ka lakòz UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 zewo
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Ekri kèk done nan tanpon kache ki genyen nan fòmatè sa a.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Sa ekivalan a:
    ///         // ekri! (fòma, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Ekri kèk enfòmasyon fòma nan egzanp sa a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Drapo pou fòma
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Karaktè itilize kòm 'fill' chak fwa gen aliyman.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Nou mete aliyman sou bò dwat la ak ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Drapo ki endike ki fòm aliyman yo te mande.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Si ou vle espesifye lajè nonb antye relatif ki pwodiksyon an ta dwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Si nou te resevwa yon lajè, nou itilize li
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Sinon nou pa fè anyen espesyal
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Si ou vle espesifye presizyon pou kalite nimerik.
    /// Altènativman, lajè a maksimòm pou kalite fisèl.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Si nou te resevwa yon presizyon, nou itilize li.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Sinon nou default a 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Detèmine si drapo `+` la te espesifye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Detèmine si drapo `-` la te espesifye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Ou vle yon siy mwens?Gen youn!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Detèmine si drapo `#` la te espesifye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Detèmine si drapo `0` la te espesifye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Nou inyore opsyon fòmatè a.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Deside ki API piblik nou vle pou de drapo sa yo.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Kreye yon mason [`DebugStruct`] ki fèt pou ede avèk kreyasyon aplikasyon [`fmt::Debug`] pou structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Kreye yon mason `DebugTuple` ki fèt pou ede ak kreyasyon aplikasyon `fmt::Debug` pou struct tupl.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Kreye yon mason `DebugList` ki fèt pou ede avèk kreyasyon enplemantasyon `fmt::Debug` pou lis tankou estrikti.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Kreye yon mason `DebugSet` ki fèt pou ede avèk kreyasyon enplemantasyon `fmt::Debug` pou mete tankou estrikti.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Nan egzanp sa a pi konplèks, nou itilize [`format_args!`] ak `.debug_set()` pou konstwi yon lis bra matche ak:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Kreye yon mason `DebugMap` ki fèt pou ede avèk kreyasyon enplemantasyon `fmt::Debug` pou estrikti kat ki tankou.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Aplikasyon nan fòma debaz la traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Si char bezwen chape, kole reta jiskaprezan epi ekri, lòt moun sote
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Drapo altènatif la deja trete pa LowerHex kòm espesyal-li vle di si wi ou non prefiks ak 0x.
        // Nou itilize li nan travay sou si wi ou non a zewo pwolonje, ak Lè sa a san kondisyon mete l 'yo ka resevwa prefiks la.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Aplikasyon nan Display/Debug pou kalite debaz divès kalite

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell la se mutableman prete pou nou pa ka gade nan valè li yo isit la.
                // Montre yon kontni plas.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Si ou espere tès yo dwe isit la, gade olye nan dosye a core/tests/fmt.rs, li nan yon anpil pi fasil pase kreye tout estrikti yo rt::Piece isit la.
//
// Genyen tou tès nan crate a alloc, pou moun ki bezwen alokasyon yo.