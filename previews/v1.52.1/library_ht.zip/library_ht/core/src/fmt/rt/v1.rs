//! Sa a se yon modil entèn itilize pa ifmt la!ègzekutabl.Estrikti sa yo emèt nan ranje estatik precompile strings fòma devan yo nan tan.
//!
//! Definisyon sa yo sanble ak ekivalan `ct` yo, men diferan nan sa yo ka estatikman resevwa lajan epi yo yon ti kras optimize pou ègzekutabl la
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Aliman posib ki ka mande kòm yon pati nan yon direktiv fòma.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Endikasyon ke sa yo ta dwe kite-aliyen.
    Left,
    /// Endikasyon ke sa yo ta dwe dwat-aliyen.
    Right,
    /// Endikasyon ke sa yo ta dwe sant-aliyen.
    Center,
    /// Yo pa mande okenn aliyman.
    Unknown,
}

/// Itilize pa [width](https://doc.rust-lang.org/std/fmt/#width) ak [precision](https://doc.rust-lang.org/std/fmt/#precision) spécificateurs.
#[derive(Copy, Clone)]
pub enum Count {
    /// Espesifye ak yon nimewo literal, magazen valè a
    Is(usize),
    /// Espesifye lè l sèvi avèk sentaks `$` ak `*`, magazen endèks la nan `args`
    Param(usize),
    /// Pa espesifye
    Implied,
}