//! Composable iterasyon asenkron.
//!
//! Si futures yo se valè asenkron, Lè sa a, kouran yo se iterateur asenkron.
//! Si ou te jwenn tèt ou ak yon koleksyon asenkron nan kèk kalite, ak bezwen fè yon operasyon sou eleman ki nan di koleksyon, ou pral byen vit kouri antre nan 'streams'.
//! Kouran yo lou itilize nan idiomatic asenkron Rust kòd, kidonk li la vo vin abitye avèk yo.
//!
//! Anvan ou eksplike plis, kite a pale sou ki jan modil sa a estriktire:
//!
//! # Organization
//!
//! Modil sa a lajman òganize pa kalite:
//!
//! * [Traits] yo se pòsyon debaz la: sa yo traits defini ki kalite kouran egziste ak sa ou ka fè avèk yo.Metòd sa yo traits yo vo mete kèk tan etid siplemantè nan.
//! * Fonksyon bay kèk fason itil yo kreye kèk sous dlo debaz yo.
//! * Structs yo souvan kalite yo retounen nan divès kalite metòd sa a sou traits modil la.Ou pral anjeneral vle gade nan metòd la ki kreye `struct` a, olye ke `struct` nan tèt li.
//! Pou plis detay sou rezon ki fè, gade '[Aplike kouran](#aplikasyon-kouran)'.
//!
//! [Traits]: #traits
//!
//! Sa a li!Ann fouye nan ravin yo.
//!
//! # Stream
//!
//! Kè ak nanm modil sa a se [`Stream`] trait.Nwayo a nan [`Stream`] sanble tankou sa a:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Kontrèman ak `Iterator`, `Stream` fè yon distenksyon ant metòd [`poll_next`] ki itilize lè y ap aplike yon `Stream`, ak yon metòd (to-be-implemented) `next` ki itilize lè konsome yon kouran.
//!
//! Konsomatè nan `Stream` sèlman bezwen konsidere `next`, ki lè yo rele, retounen yon future ki bay `Option<Stream::Item>`.
//!
//! future la retounen pa `next` pral sede `Some(Item)` osi lontan ke gen eleman, epi yon fwa yo te tout fin itilize, yo pral sede `None` ki endike ke iterasyon fini.
//! Si nou ap tann sou yon bagay asenkron rezoud, future a ap rete tann jiskaske kouran an se pare yo sede ankò.
//!
//! Kouran endividyèl yo ka chwazi rekòmanse iterasyon, e konsa rele `next` ankò ka oswa pa ka evantyèlman sede `Some(Item)` ankò nan kèk pwen.
//!
//! Definisyon konplè [`Stream`] a gen ladan yon kantite lòt metòd tou, men yo se metòd default, bati sou tèt [`poll_next`], e konsa ou jwenn yo pou gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Aplike Stream
//!
//! Kreye yon kouran pwòp ou a enplike nan de etap: kreye yon `struct` yo kenbe eta kouran an, ak Lè sa a mete ann aplikasyon [`Stream`] pou sa `struct`.
//!
//! Ann fè yon kouran yo te rele `Counter` ki konte soti nan `1` rive `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Premyèman, struct la:
//!
//! /// Yon kouran ki konte soti nan youn a senk
//! struct Counter {
//!     count: usize,
//! }
//!
//! // nou vle konte nou yo kòmanse nan yon sèl, se konsa kite a ajoute yon metòd new() ede.
//! // Sa a pa estrikteman nesesè, men li pratik.
//! // Remake byen ke nou kòmanse `count` nan zewo, nou pral wè poukisa nan aplikasyon `poll_next()`'s anba a.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Lè sa a, nou aplike `Stream` pou `Counter` nou an:
//!
//! impl Stream for Counter {
//!     // nou pral konte ak usize
//!     type Item = usize;
//!
//!     // poll_next() se sèl metòd obligatwa
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Ogmante konte nou an.Se poutèt sa nou te kòmanse nan zewo.
//!         self.count += 1;
//!
//!         // Tcheke pou wè si nou fini konte oswa ou pa.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Flux yo *parese*.Sa vle di ke jis kreye yon kouran pa _do_ yon anpil antye.Pa gen anyen reyèlman rive jiskaske ou rele `next`.
//! Sa a se pafwa yon sous konfizyon lè kreye yon kouran sèlman pou efè segondè li yo.
//! Konpilatè a pral avèti nou sou kalite konpòtman sa a:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;