use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Yon koòdone pou fè fas ak iterateur asenkron.
///
/// Sa a se trait kouran prensipal la.
/// Pou plis enfòmasyon sou konsèp nan kouran jeneralman, tanpri al gade [module-level documentation] la.
/// An patikilye, ou ka vle konnen ki jan yo [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Kalite atik yo bay nan kouran an.
    type Item;

    /// Eseye rale pwochen valè kouran sa a, enskri travay aktyèl la pou reveye si valè a poko disponib, epi retounen `None` si kouran an fin itilize.
    ///
    /// # Retounen valè
    ///
    /// Gen plizyè valè retounen posib, chak endike yon eta kouran distenk:
    ///
    /// - `Poll::Pending` vle di ke pwochen valè kouran sa a poko pare.Aplikasyon pral asire ke travay aktyèl la ap avèti lè pwochen valè a ka pare.
    ///
    /// - `Poll::Ready(Some(val))` vle di ke te kouran an avèk siksè pwodwi yon valè, `val`, epi yo ka pwodwi plis valè sou apèl `poll_next` ki vin apre.
    ///
    /// - `Poll::Ready(None)` vle di ke kouran an te sispann, ak `poll_next` pa ta dwe envoke ankò.
    ///
    /// # Panics
    ///
    /// Yon fwa yon kouran fini (retounen `Ready(None)` from `poll_next`), rele metòd `poll_next` li yo ankò pouvwa panic, bloke pou tout tan, oswa lakòz lòt kalite pwoblèm; `Stream` trait a pa mete okenn kondisyon sou efè yo nan tankou yon apèl.
    ///
    /// Sepandan, kòm metòd `poll_next` la pa make `unsafe`, règ abityèl Rust yo aplike: apèl pa dwe janm lakòz konpòtman endefini (koripsyon memwa, itilizasyon kòrèk nan fonksyon `unsafe`, oswa renmen an), kèlkeswa eta kouran an.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Retounen limit yo sou longè ki rete nan kouran an.
    ///
    /// Espesyalman, `size_hint()` retounen yon tuplè kote eleman an premye se limit la pi ba yo, ak dezyèm eleman an se limit la anwo yo.
    ///
    /// Dezyèm mwatye nan tupl la ki retounen se yon [`Opsyon`]`<`[`usize`] `>`.
    /// Yon [`None`] isit la vle di ke swa pa gen limit siperyè li te ye, oswa limit siperyè a pi gwo pase [`usize`].
    ///
    /// # Nòt aplikasyon yo
    ///
    /// Li pa ranfòse ke yon aplikasyon kouran pwodiksyon an deklare kantite eleman yo.Yon kouran buggy ka bay mwens pase limit ki pi ba a oswa plis pase limit la anwo nan eleman yo.
    ///
    /// `size_hint()` se prensipalman gen entansyon itilize pou optimize tankou rezève espas pou eleman yo nan kouran an, men yo pa dwe fè konfyans nan egzanp, kite chèk limit nan kòd ki pa an sekirite.
    /// Yon aplikasyon kòrèk nan `size_hint()` pa ta dwe mennen nan vyolasyon sekirite memwa.
    ///
    /// Sa te di, aplikasyon an ta dwe bay yon estimasyon kòrèk, paske otreman li ta yon vyolasyon pwotokòl trait la.
    ///
    /// Aplikasyon an default retounen `(0,` [`Okenn`]`)`ki kòrèk pou nenpòt ki kouran.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}