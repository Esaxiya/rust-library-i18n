use crate::{iter::FusedIterator, ops::Try};

/// Yon iteratè ki repete infiniman.
///
/// Sa a se `struct` kreye pa metòd la [`cycle`] sou [`Iterator`].
/// Gade dokiman li yo pou plis.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // iteratè sik la se swa vid oswa enfini
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // konplètman repete iteratè aktyèl la.
        // sa nesesè paske `self.iter` ka vid menm lè `self.orig` pa
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // ranpli yon sik konplè, kenbe tras nan si iteratè a sikle se vid oswa ou pa.
        // nou bezwen retounen bonè nan ka ta gen yon iteratè vid pou anpeche yon bouk enfini
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Pa gen `fold` pase sou desizyon, paske `fold` pa fè anpil sans pou `Cycle`, epi nou pa ka fè anyen pi bon pase default la.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}