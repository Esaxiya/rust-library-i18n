use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Yon iteratè ak yon `peek()` ki retounen yon referans si ou vle eleman kap vini an.
///
///
/// Sa a se `struct` kreye pa metòd la [`peekable`] sou [`Iterator`].
/// Gade dokiman li yo pou plis.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Sonje yon valè peeked, menm si li te Okenn.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable dwe sonje si yon Okenn te wè nan metòd `.peek()` la.
// Li asire ke `.peek();.peek();` oswa `.peek();.next();` sèlman avanse iteratè ki kache nan pifò yon fwa.
// Sa a pa pou kont li fè iteratè a kole.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Retounen yon referans a valè next() san li pa avanse iteratè a.
    ///
    /// Tankou [`next`], si gen yon valè, li vlope nan yon `Some(T)`.
    /// Men, si iterasyon an fini, `None` retounen.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Paske `peek()` retounen yon referans, ak anpil iterasyon repete sou referans, ka gen yon sitiyasyon petèt konfizyon kote valè a retounen se yon referans doub.
    /// Ou ka wè efè sa a nan egzanp ki anba yo.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() pèmèt nou wè nan future la
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Iteratè a pa avanse menm si nou `peek` plizyè fwa
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Apre iteratè a fini, se konsa `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Retounen yon referans ki ka chanje nan valè next() san li pa avanse iteratè a.
    ///
    /// Tankou [`next`], si gen yon valè, li vlope nan yon `Some(T)`.
    /// Men, si iterasyon an fini, `None` retounen.
    ///
    /// Paske `peek_mut()` retounen yon referans, ak anpil iterasyon repete sou referans, ka gen yon sitiyasyon petèt konfizyon kote valè a retounen se yon referans doub.
    /// Ou ka wè efè sa a nan egzanp ki anba yo.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Tankou ak `peek()`, nou ka wè nan future la san nou pa avanse iteratè a.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Gade nan iteratè a epi mete valè dèyè referans ki ka chanje a.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Valè a nou mete nan reaparisyon kòm iterateur la ap kontinye.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Konsome epi retounen pwochen valè iteratè sa a si yon kondisyon vre.
    /// Si `func` retounen `true` pou pwochen valè iteratè sa a, konsome epi retounen li.
    /// Sinon, retounen `None`.
    /// # Examples
    /// Konsome yon nimewo si li egal a 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Premye atik iteratè a se 0;konsome li.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Pwochen atik retounen an se kounye a 1, kidonk `consume` ap retounen `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` sove valè pwochen atik la si li pa egal a `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Konsome nenpòt ki nimewo mwens pase 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Konsome tout nimewo mwens pase 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Valè nan pwochen retounen yo pral 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Depi nou rele `self.next()`, nou boule `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Konsome epi retounen atik kap vini an si li egal a `expected`.
    /// # Example
    /// Konsome yon nimewo si li egal a 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Premye atik iteratè a se 0;konsome li.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Pwochen atik retounen an se kounye a 1, kidonk `consume` ap retounen `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` sove valè pwochen atik la si li pa egal a `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // SEKIRITE: an sekirite fonksyon transfere nan fonksyon an sekirite ak menm kondisyon yo
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}