use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Sa a trait bay aksè tranzitif nan sous-etap nan yon tiyo entèaktè-adaptè anba kondisyon yo ki
/// * iterasyon sous `S` nan tèt li aplike `SourceIter<Source = S>`
/// * gen yon aplikasyon delege nan sa a trait pou chak adaptè nan tiyo ki genyen ant sous la ak konsomatè a tiyo.
///
/// Lè sous la se yon struct iteratè posede (souvan yo rele `IntoIter`) Lè sa a, sa a kapab itil pou espesyalize aplikasyon [`FromIterator`] oswa rekipere eleman ki rete yo apre yon iteratè te pasyèlman fin itilize.
///
///
/// Remake byen ke enplemantasyon pa nesesèman oblije bay aksè a sous ki pi enteryè nan yon tiyo.Yon adaptè entèmedyè leta ta ka prese evalye yon pati nan tiyo a epi ekspoze depo entèn li yo kòm sous.
///
/// trait la pa an sekirite paske moun k ap aplike yo dwe kenbe pwopriyete sekirite anplis.
/// Gade [`as_inner`] pou plis detay.
///
/// # Examples
///
/// Rekipere yon sous ki pasyèlman boule:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Yon etap sous nan yon tiyo iteratè.
    type Source: Iterator;

    /// Rekipere sous la nan yon tiyo iterateur.
    ///
    /// # Safety
    ///
    /// Aplikasyon nan dwe retounen menm referans a mutable pou tout lavi yo, sof si ranplase pa yon moun kap rele.
    /// Moun kap rele yo ka sèlman ranplase referans lan lè yo sispann iterasyon epi lage tiyo iteratè a apre ekstrè sous la.
    ///
    /// Sa vle di cartes iteratè ka konte sou sous la pa chanje pandan iterasyon men yo pa ka konte sou li nan aplikasyon Drop yo.
    ///
    /// Aplike metòd sa a vle di cartes abandone aksè prive-sèlman nan sous yo epi yo ka sèlman konte sou garanti te fè ki baze sou kalite reseptè metòd.
    /// Mank aksè restriksyon egzije tou ke cartes yo dwe defann API piblik sous la menm lè yo gen aksè a entèn li yo.
    ///
    /// Moun kap rele yo dwe atann sous la nan nenpòt eta ki konsistan avèk API piblik li yo depi cartes ki chita ant li ak sous la gen menm aksè.
    /// An patikilye yon adaptè ka te konsome plis eleman pase sa nesesè.
    ///
    /// Objektif la an jeneral nan kondisyon sa yo se kite konsomatè a nan yon tiyo itilize
    /// * tou sa ki rete nan sous la apre iterasyon te sispann
    /// * memwa a ki te vin rès pa avanse yon iteratè konsome
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Yon adaptè iteratè ki pwodui pwodiksyon osi lontan ke iteratè kache a pwodui valè `Result::Ok`.
///
///
/// Si yon erè rankontre, iteratè a sispann epi li se erè a ki estoke.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Pwosesis iteratè yo bay la kòm si li sede yon `T` olye pou yo yon `Result<T, _>`.
/// Nenpòt erè ap sispann iteratè enteryè a ak rezilta jeneral la pral yon erè.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}