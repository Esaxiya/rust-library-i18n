/// Yon iteratè ki konnen longè egzak li yo.
///
/// Anpil [`iteratè`] pa konnen konbyen fwa yo pral repete, men gen kèk ki fè sa.
/// Si yon iteratè konnen konbyen fwa li ka repete, bay aksè a enfòmasyon sa a ka itil.
/// Pou egzanp, si ou vle repete bak, yon bon kòmanse se konnen ki kote fen a se.
///
/// Lè w ap aplike yon `ExactSizeIterator`, ou dwe aplike tou [`Iterator`].
/// Lè w ap fè sa, aplikasyon an nan [`Iterator::size_hint`]*dwe* retounen gwosè egzak la nan iteratè la.
///
/// Metòd [`len`] la gen yon aplikasyon default, kidonk anjeneral ou pa ta dwe aplike li.
/// Sepandan, ou ka anmezi pou bay yon aplikasyon ki pi pèfòman pase default la, kidonk anile li nan ka sa a fè sans.
///
///
/// Remake byen ke trait sa a se yon trait san danje e jan sa fè *pa* e *pa ka* garanti ke longè retounen an kòrèk.
/// Sa vle di ke kòd `unsafe`**pa dwe** konte sou jistès [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait enstab ak danjere bay garanti adisyonèl sa a.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// // yon seri fini konnen egzakteman konbyen fwa li pral repete
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Nan [module-level docs] a, nou aplike yon [`Iterator`], `Counter`.
/// Ann aplike `ExactSizeIterator` pou li tou:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Nou ka fasilman kalkile kantite ki rete nan iterasyon.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Epi, koulye a nou ka itilize li!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Retounen longè egzak iteratè a.
    ///
    /// Aplikasyon an asire ke iteratè a ap retounen egzakteman `len()` plis fwa yon valè [`Some(T)`], anvan yo retounen [`None`].
    ///
    /// Metòd sa a gen yon aplikasyon default, kidonk, anjeneral ou pa ta dwe aplike li dirèkteman.
    /// Sepandan, si ou ka bay yon aplikasyon pi efikas, ou ka fè sa.
    /// Gade dokiman [trait-level] yo pou yon egzanp.
    ///
    /// Fonksyon sa a gen menm garanti sekirite tankou fonksyon [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// // yon seri fini konnen egzakteman konbyen fwa li pral repete
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Afimasyon sa a twò defansiv, men li tcheke envaryan an
        // garanti pa trait la.
        // Si trait sa a te rust-entèn, nou ta ka itilize debug_assert !;assert_eq!pral tcheke tout aplikasyon itilizatè Rust tou.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Retounen `true` si iteratè a vid.
    ///
    /// Metòd sa a gen yon aplikasyon default lè l sèvi avèk [`ExactSizeIterator::len()`], kidonk, ou pa bezwen aplike li tèt ou.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}