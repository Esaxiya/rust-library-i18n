/// Konvèsyon soti nan yon [`Iterator`].
///
/// Lè w aplike `FromIterator` pou yon kalite, ou defini kijan li pral kreye nan yon iteratè.
/// Sa a se komen pou kalite ki dekri yon koleksyon kèk kalite.
///
/// [`FromIterator::from_iter()`] se raman yo rele klèman, epi li se olye itilize nan [`Iterator::collect()`] metòd.
///
/// Gade dokiman [`Iterator::collect()`]'s pou plis egzanp.
///
/// Gade tou: [`IntoIterator`].
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Sèvi ak [`Iterator::collect()`] pou enplisitman itilize `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Aplike `FromIterator` pou kalite ou:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Yon koleksyon echantiyon, ki nan jis yon pakè sou Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ann bay li kèk metòd pou nou ka kreye yon sèl epi ajoute bagay pou li.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // epi nou pral aplike FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Koulye a, nou ka fè yon nouvo iteratè ...
/// let iter = (0..5).into_iter();
///
/// // ... epi fè yon MyCollection soti nan li
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // kolekte travay tou!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Kreye yon valè ki sòti nan yon iteratè.
    ///
    /// Gade [module-level documentation] la pou plis.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konvèsyon nan yon [`Iterator`].
///
/// Lè w aplike `IntoIterator` pou yon kalite, ou defini kijan li pral konvèti nan yon iteratè.
/// Sa a se komen pou kalite ki dekri yon koleksyon kèk kalite.
///
/// Yon benefis nan mete ann aplikasyon `IntoIterator` se ke kalite ou pral [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Gade tou: [`FromIterator`].
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Aplike `IntoIterator` pou kalite ou:
///
/// ```
/// // Yon koleksyon echantiyon, ki nan jis yon pakè sou Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ann bay li kèk metòd pou nou ka kreye yon sèl epi ajoute bagay pou li.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // epi nou pral aplike IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Koulye a, nou ka fè yon nouvo koleksyon ...
/// let mut c = MyCollection::new();
///
/// // ... ajoute kèk bagay nan li ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ak Lè sa a, vire l 'nan yon iteratè:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Li komen pou itilize `IntoIterator` kòm yon trait bound.Sa pèmèt kalite koleksyon opinyon an chanje, toutotan li toujou yon iteratè.
/// Lòt limit ka espesifye pa mete restriksyon sou
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Kalite eleman yo te repete.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Ki kalite iteratè nou vire sa a?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Kreye yon iteratè ki soti nan yon valè.
    ///
    /// Gade [module-level documentation] la pou plis.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Pwolonje yon koleksyon ak sa ki nan yon iteratè.
///
/// Iteratè pwodwi yon seri de valè, ak koleksyon kapab tou gen pou panse a kòm yon seri de valè.
/// `Extend` trait a pon espas sa a, ki pèmèt ou pwolonje yon koleksyon pa ki gen ladan sa ki nan iteratè sa a.
/// Lè pwolonje yon koleksyon ak yon kle ki deja egziste, ki antre mete ajou oswa, nan ka a nan koleksyon ki pèmèt antre miltip ak kle egal, ki antre se eleman.
///
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// // Ou ka pwolonje yon fisèl ak kèk karaktè:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Aplike `Extend`:
///
/// ```
/// // Yon koleksyon echantiyon, ki nan jis yon pakè sou Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ann bay li kèk metòd pou nou ka kreye yon sèl epi ajoute bagay pou li.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // depi MyCollection gen yon lis i32s, nou aplike Pwolonje pou i32
/// impl Extend<i32> for MyCollection {
///
///     // Sa a se yon ti jan pi senp ak siyati ki kalite konkrè: nou ka rele pwolonje sou nenpòt bagay ki ka tounen yon iteratè ki ban nou i32s.
///     // Paske nou bezwen i32s yo mete nan MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Aplikasyon an se trè dwat: bouk nan iteratè a, ak add() chak eleman nan tèt nou.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // kite a pwolonje koleksyon nou an ak twa nimewo plis
/// c.extend(vec![1, 2, 3]);
///
/// // nou te ajoute eleman sa yo sou fen an
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Pwolonje yon koleksyon ak sa ki nan yon iteratè.
    ///
    /// Kòm se sèl metòd obligatwa pou trait sa a, dokiman [trait-level] yo gen plis detay.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// // Ou ka pwolonje yon fisèl ak kèk karaktè:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Pwolonje yon koleksyon ak egzakteman yon sèl eleman.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Rezève kapasite nan yon koleksyon pou kantite bay eleman adisyonèl.
    ///
    /// Aplikasyon an default pa fè anyen.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}