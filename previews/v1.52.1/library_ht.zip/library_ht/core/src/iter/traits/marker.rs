/// Yon iteratè ki toujou kontinye sede `None` lè fin itilize.
///
/// Rele pwochen sou yon iterateur kole ki te retounen `None` yon fwa garanti pou retounen [`None`] ankò.
/// trait sa a ta dwe aplike pa tout iteratè ki konpòte yo konsa paske li pèmèt optimize [`Iterator::fuse()`].
///
///
/// Note: An jeneral, ou pa ta dwe itilize `FusedIterator` nan limit jenerik si ou bezwen yon iteratè kole.
/// Olye de sa, ou ta dwe jis rele [`Iterator::fuse()`] sou iteratè la.
/// Si iteratè a deja kole, anplis [`Fuse`] anbalaj la pral yon pa gen okenn op ki pa gen okenn penalite pèfòmans.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Yon iteratè ki rapòte yon longè egzat lè l sèvi avèk size_hint.
///
/// Iteratè a rapòte yon allusion gwosè kote li se swa egzak (pi ba mare ki egal a anwo mare), oswa anwo limit la se [`None`].
///
/// Anlè anwo a dwe sèlman [`None`] si longè iteratè aktyèl la pi gwo pase [`usize::MAX`].
/// Nan ka sa a, limit la pi ba yo dwe [`usize::MAX`], sa ki lakòz yon [`Iterator::size_hint()`] nan `(usize::MAX, None)`.
///
/// Iteratè a dwe pwodwi egzakteman kantite eleman li rapòte oswa divèje anvan li rive nan fen an.
///
/// # Safety
///
/// trait sa a dwe aplike sèlman lè kontra a konfime.
/// Konsomatè sa a trait dwe enspekte [`Iterator::size_hint()`]’s anwo mare.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Yon iteratè ki lè bay yon atik yo pral pran omwen yon eleman nan kache [`SourceIter`] li yo.
///
/// Rele nenpòt metòd ki avanse iteratè a, egzanp
/// [`next()`] oswa [`try_fold()`], garanti ke pou chak etap omwen yon valè nan sous kache iteratè a te deplase deyò epi yo ka rezilta chèn iteratè a ap antre nan plas li, an konsideran kontrent estriktirèl nan sous la pèmèt tankou yon ensèsyon.
///
/// Nan lòt mo sa a trait endike ke yon tiyo iterateur ka kolekte an plas.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}