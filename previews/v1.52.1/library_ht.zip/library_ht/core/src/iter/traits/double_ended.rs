use crate::ops::{ControlFlow, Try};

/// Yon iteratè kapab sede eleman ki soti nan tou de bout.
///
/// Yon bagay ki aplike `DoubleEndedIterator` gen yon sèl kapasite siplemantè sou yon bagay ki aplike [`Iterator`]: kapasite nan pran tou `Item`s soti nan do a, menm jan tou devan an.
///
///
/// Li enpòtan sonje ke tou de retounen ak lide travay sou seri a menm, epi yo pa travèse: iterasyon se sou lè yo rankontre nan mitan an.
///
/// Nan yon mòd menm jan ak pwotokòl la [`Iterator`], yon fwa yon `DoubleEndedIterator` retounen [`None`] soti nan yon [`next_back()`], rele li ankò pouvwa oswa pa janm ka retounen [`Some`] ankò.
/// [`next()`] ak [`next_back()`] yo ka ranplase pou objektif sa a.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Retire epi retounen yon eleman nan fen iteratè a.
    ///
    /// Retounen `None` lè pa gen eleman plis.
    ///
    /// Dokiman [trait-level] yo gen plis detay.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Eleman ki bay pa metòd `DoubleEndedIterator` yo ka diferan de sa yo bay pa metòd [`Iterator`] yo:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Avanse iteratè a soti nan do a pa eleman `n`.
    ///
    /// `advance_back_by` se vèsyon an ranvèse nan [`advance_by`].Metòd sa a pral prese sote eleman `n` kòmanse nan do a lè w rele [`next_back`] jiska `n` fwa jiskaske [`None`] rankontre.
    ///
    /// `advance_back_by(n)` ap retounen [`Ok(())`] si iteratè a avèk siksè avanse pa eleman `n`, oswa [`Err(k)`] si [`None`] rankontre, kote `k` se kantite eleman iteratè a avanse pa anvan ou kouri soti nan eleman (sa vle di
    /// longè iteratè a).
    /// Remake byen ke `k` se toujou mwens pase `n`.
    ///
    /// Rele `advance_back_by(0)` pa konsome okenn eleman ak toujou retounen [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // sèlman `&3` te sote
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Retounen `n`th eleman ki soti nan fen iteratè a.
    ///
    /// Sa a se esansyèlman vèsyon an ranvèse nan [`Iterator::nth()`].
    /// Malgre ke tankou pifò operasyon Indexing, konte a kòmanse soti nan zewo, se konsa `nth_back(0)` retounen valè an premye soti nan fen a, `nth_back(1)` dezyèm lan, ak sou sa.
    ///
    ///
    /// Remake byen ke tout eleman ant fen a ak eleman ki retounen yo pral boule, ki gen ladan eleman ki retounen an.
    /// Sa vle di tou ke rele `nth_back(0)` plizyè fwa sou menm iteratè a ap retounen eleman diferan.
    ///
    /// `nth_back()` ap retounen [`None`] si `n` pi gran pase oswa egal a longè iteratè a.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Rele `nth_back()` plizyè fwa pa remonte iteratè a:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Retounen `None` si gen mwens pase eleman `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Sa a se vèsyon an ranvèse nan [`Iterator::try_fold()`]: li pran eleman kòmanse nan do a nan iteratè la.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Paske li kout sikwi, eleman ki rete yo toujou disponib nan iterateur la.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Yon metòd iteratè ki diminye eleman iteratè a nan yon sèl valè final, apati de do.
    ///
    /// Sa a se vèsyon an ranvèse nan [`Iterator::fold()`]: li pran eleman kòmanse nan do a nan iteratè la.
    ///
    /// `rfold()` pran de agiman: yon valè inisyal, ak yon fèmti ak de agiman: yon 'accumulator', ak yon eleman.
    /// Fèmti a retounen valè akimilatè a ta dwe genyen pou iterasyon kap vini an.
    ///
    /// Valè inisyal la se valè akimilatè a ap genyen nan premye apèl la.
    ///
    /// Apre ou fin aplike fèmen sa a nan chak eleman nan iteratè a, `rfold()` retounen akimilatè a.
    ///
    /// Operasyon sa a pafwa yo rele 'reduce' oswa 'inject'.
    ///
    /// Folding se itil chak fwa ou gen yon koleksyon yon bagay, epi ou vle pwodwi yon valè sèl soti nan li.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // sòm total tout eleman yon
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Egzanp sa a bati yon fisèl, kòmanse ak yon valè inisyal epi kontinye ak chak eleman ki soti nan do a jouk devan an:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Rechèch pou yon eleman nan yon iteratè soti nan do a ki satisfè yon predike.
    ///
    /// `rfind()` pran yon fèmti ki retounen `true` oswa `false`.
    /// Li aplike fèmen sa a nan chak eleman nan iteratè a, kòmanse nan fen a, epi si nenpòt nan yo retounen `true`, Lè sa a, `rfind()` retounen [`Some(element)`].
    /// Si yo tout retounen `false`, li retounen [`None`].
    ///
    /// `rfind()` se kout kous;nan lòt mo, li pral sispann pwosesis le pli vit ke fèmti a retounen `true`.
    ///
    /// Paske `rfind()` pran yon referans, ak anpil iterasyon repete sou referans, sa a mennen nan yon sitiyasyon petèt konfizyon kote agiman an se yon referans doub.
    ///
    /// Ou ka wè efè sa a nan egzanp ki anba yo, ak `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Sispann nan premye `true` la:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // nou ka toujou itilize `iter`, kòm gen plis eleman.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}