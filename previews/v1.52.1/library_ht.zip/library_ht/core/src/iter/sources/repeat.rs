use crate::iter::{FusedIterator, TrustedLen};

/// Kreye yon iteratè nouvo ki infiniman repete yon eleman sèl.
///
/// Fonksyon `repeat()` repete yon sèl valè sou yo ak sou ankò.
///
/// Iteratè enfini tankou `repeat()` yo souvan itilize ak cartes tankou [`Iterator::take()`], yo nan lòd yo fè yo fini.
///
/// Si kalite eleman iteratè ou bezwen an pa aplike `Clone`, oswa si ou pa vle kenbe eleman ki repete nan memwa, ou ka olye sèvi ak fonksyon [`repeat_with()`] la.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::iter;
///
/// // nimewo kat 4ever la:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // wi, toujou kat
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Ale fini ak [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // dènye egzanp sa a te twòp kat.Se pou nou sèlman gen kat four.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... e kounye a nou fini
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Yon iteratè ki repete yon eleman infiniman.
///
/// Sa a `struct` kreye pa fonksyon [`repeat()`] la.Gade dokiman li yo pou plis.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}