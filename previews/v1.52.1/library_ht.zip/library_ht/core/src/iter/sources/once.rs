use crate::iter::{FusedIterator, TrustedLen};

/// Kreye yon iteratè ki bay yon eleman egzakteman yon fwa.
///
/// Sa a se souvan itilize adapte yon valè sèl nan yon [`chain()`] nan lòt kalite iterasyon.
/// Petèt ou gen yon iteratè ki kouvri prèske tout bagay, men ou bezwen yon ka siplemantè espesyal.
/// Petèt ou gen yon fonksyon ki travay sou iterateur, men ou sèlman bezwen travay sou yon sèl valè.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::iter;
///
/// // youn se nimewo ki pi solitèr la
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // yon sèl, se tout sa nou jwenn
/// assert_eq!(None, one.next());
/// ```
///
/// Chèn ansanm ak yon lòt iteratè.
/// Ann di ke nou vle repete sou chak dosye nan anyè a `.foo`, men tou, yon dosye konfigirasyon,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // nou bezwen konvèti soti nan yon iteratè nan DirEntry-s nan yon iteratè nan PathBufs, se konsa nou itilize kat jeyografik
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // kounye a, iteratè nou an jis pou dosye konfigirasyon nou an
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // chèn de iteratè yo ansanm nan yon sèl iteratè gwo
/// let files = dirs.chain(config);
///
/// // sa ap ban nou tout dosye yo nan .foo osi byen ke .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Yon iteratè ki bay yon eleman egzakteman yon fwa.
///
/// Sa a `struct` kreye pa fonksyon [`once()`] la.Gade dokiman li yo pou plis.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}