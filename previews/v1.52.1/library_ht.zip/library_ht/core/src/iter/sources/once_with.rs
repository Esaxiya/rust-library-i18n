use crate::iter::{FusedIterator, TrustedLen};

/// Kreye yon iteratè ki parese jenere yon valè egzakteman yon fwa pa envoke fèmti yo bay la.
///
/// Sa a se souvan itilize adapte yon dèlko valè sèl nan yon [`chain()`] nan lòt kalite iterasyon.
/// Petèt ou gen yon iteratè ki kouvri prèske tout bagay, men ou bezwen yon ka siplemantè espesyal.
/// Petèt ou gen yon fonksyon ki travay sou iterateur, men ou sèlman bezwen travay sou yon sèl valè.
///
/// Kontrèman ak [`once()`], fonksyon sa a pral parese jenere valè a sou demann.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::iter;
///
/// // youn se nimewo ki pi solitèr la
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // yon sèl, se tout sa nou jwenn
/// assert_eq!(None, one.next());
/// ```
///
/// Chèn ansanm ak yon lòt iteratè.
/// Ann di ke nou vle repete sou chak dosye nan anyè a `.foo`, men tou, yon dosye konfigirasyon,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // nou bezwen konvèti soti nan yon iteratè nan DirEntry-s nan yon iteratè nan PathBufs, se konsa nou itilize kat jeyografik
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // kounye a, iteratè nou an jis pou dosye konfigirasyon nou an
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // chèn de iteratè yo ansanm nan yon sèl iteratè gwo
/// let files = dirs.chain(config);
///
/// // sa ap ban nou tout dosye yo nan .foo osi byen ke .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Yon iterasyon ki bay yon eleman sèl nan kalite `A` pa aplike fèmen `F: FnOnce() -> A` yo bay la.
///
///
/// Sa a `struct` kreye pa fonksyon [`once_with()`] la.
/// Gade dokiman li yo pou plis.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}