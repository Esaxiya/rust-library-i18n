use crate::fmt;

/// Kreye yon iterateur nouvo kote chak iterasyon rele `F: FnMut() -> Option<T>` fèmen yo bay la.
///
/// Sa a pèmèt kreye yon iteratè koutim ak nenpòt konpòtman san yo pa itilize sentaks la plis verbose nan kreye yon kalite dedye ak mete ann aplikasyon [`Iterator`] trait la pou li.
///
/// Remake byen ke iteratè a `FromFn` pa fè sipozisyon sou konpòtman an nan fèmti a, ak Se poutèt sa konsèvativman pa aplike [`FusedIterator`], oswa pase sou desizyon [`Iterator::size_hint()`] soti nan `(0, None)` default li yo.
///
///
/// Fèmti a ka itilize kaptire ak anviwònman li yo pou swiv eta atravè iterasyon yo.Tou depan de kijan iteratè a itilize, sa ka mande pou espesifye mo kle [`move`] la sou fèmti a.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ann re-aplike iteratè a vann san preskripsyon soti nan [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Ogmante konte nou an.Se poutèt sa nou te kòmanse nan zewo.
///     count += 1;
///
///     // Tcheke pou wè si nou fini konte oswa ou pa.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Yon iterasyon kote chak iterasyon rele `F: FnMut() -> Option<T>` fèmti yo bay la.
///
/// Sa a `struct` kreye pa fonksyon [`iter::from_fn()`] la.
/// Gade dokiman li yo pou plis.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}