use crate::iter::{FusedIterator, TrustedLen};

/// Kreye yon iterateur nouvo ki repete eleman nan kalite `A` infiniman pa aplike fèmti yo bay la, repeteur a, `F: FnMut() -> A`.
///
/// Fonksyon `repeat_with()` a rele repeteur a sou yo ak sou ankò.
///
/// Iteratè enfini tankou `repeat_with()` yo souvan itilize ak cartes tankou [`Iterator::take()`], yo nan lòd yo fè yo fini.
///
/// Si kalite eleman iteratè a ou bezwen aplike [`Clone`], epi li OK pou kenbe eleman sous la nan memwa, ou ta dwe olye sèvi ak fonksyon [`repeat()`] la.
///
///
/// Yon iteratè ki te pwodwi pa `repeat_with()` se pa yon [`DoubleEndedIterator`].
/// Si ou bezwen `repeat_with()` retounen yon [`DoubleEndedIterator`], tanpri louvri yon pwoblèm GitHub eksplike ka itilize ou.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::iter;
///
/// // kite a asime nou gen kèk valè de yon kalite ki pa `Clone` oswa ki pa vle gen nan memwa jis ankò paske li se chè:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // yon valè patikilye pou tout tan:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Sèvi ak mitasyon ak ale fini:
///
/// ```rust
/// use std::iter;
///
/// // Soti nan zeroth nan twazyèm pouvwa a nan de:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... e kounye a nou fini
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Yon iterasyon ki repete eleman nan kalite `A` infiniman pa aplike `F: FnMut() -> A` fèmen yo bay la.
///
///
/// Sa a `struct` kreye pa fonksyon [`repeat_with()`] la.
/// Gade dokiman li yo pou plis.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}