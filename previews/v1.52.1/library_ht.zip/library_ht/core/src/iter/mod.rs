//! Composable iterasyon ekstèn.
//!
//! Si ou te jwenn tèt ou ak yon koleksyon kèk kalite, ak bezwen fè yon operasyon sou eleman ki nan di koleksyon, ou pral byen vit kouri antre nan 'iterators'.
//! Iteratè yo lou itilize nan kòd Rust idyomatik, kidonk li vo vin abitye avèk yo.
//!
//! Anvan ou eksplike plis, kite a pale sou ki jan modil sa a estriktire:
//!
//! # Organization
//!
//! Modil sa a lajman òganize pa kalite:
//!
//! * [Traits] yo se pòsyon debaz la: sa yo traits defini ki kalite iteratè egziste ak sa ou ka fè avèk yo.Metòd sa yo traits yo vo mete kèk tan etid siplemantè nan.
//! * [Functions] bay kèk fason itil yo kreye kèk iteratè debaz yo.
//! * [Structs] yo souvan kalite yo retounen nan divès kalite metòd sa a sou traits modil la.Ou pral anjeneral vle gade nan metòd la ki kreye `struct` a, olye ke `struct` nan tèt li.
//! Pou plis detay sou rezon ki fè, gade '[Aplike iteratè](#aplikasyon-iteratè)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Sa a li!Ann fouye nan iteratè yo.
//!
//! # Iterator
//!
//! Kè ak nanm modil sa a se [`Iterator`] trait.Nwayo a nan [`Iterator`] sanble tankou sa a:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Yon iteratè gen yon metòd, [`next`], ki lè yo rele li, retounen yon [`Opsyon`]`<Item>`.
//! [`next`] ap retounen [`Some(Item)`] osi lontan ke gen eleman, epi yon fwa yo te fin itilize, yo pral retounen `None` pou endike ke iterasyon an fini.
//! Iteratè endividyèl yo ka chwazi reprann iterasyon, e konsa rele [`next`] ankò ka oswa pa ka evantyèlman kòmanse retounen [`Some(Item)`] ankò nan kèk pwen (pou egzanp, gade [`TryIter`]).
//!
//!
//! Definisyon konplè [`Iterator`] gen ladan yon kantite lòt metòd tou, men yo se metòd default, bati sou tèt [`next`], epi konsa ou jwenn yo pou gratis.
//!
//! Iteratè yo tou composable, epi li komen nan chenn yo ansanm fè fòm pi konplèks nan pwosesis.Gade seksyon [Adapters](#adapters) ki anba a pou plis detay.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Twa fòm iterasyon yo
//!
//! Gen twa metòd komen ki ka kreye iteratè nan yon koleksyon:
//!
//! * `iter()`, ki repete sou `&T`.
//! * `iter_mut()`, ki repete sou `&mut T`.
//! * `into_iter()`, ki repete sou `T`.
//!
//! Divès bagay nan bibliyotèk la estanda ka aplike youn oswa plis nan twa a, kote ki apwopriye.
//!
//! # Aplike iteratè
//!
//! Kreye yon iteratè nan pwòp ou a enplike nan de etap: kreye yon `struct` yo kenbe eta iteratè a, ak Lè sa a mete ann aplikasyon [`Iterator`] pou sa `struct`.
//! Se poutèt sa gen anpil `struct`s nan modil sa a: gen yon sèl pou chak iteratè ak iteratè adaptè.
//!
//! Ann fè yon iteratè yo te rele `Counter` ki konte soti nan `1` rive `5`:
//!
//! ```
//! // Premyèman, struct la:
//!
//! /// Yon iteratè ki konte soti nan youn a senk
//! struct Counter {
//!     count: usize,
//! }
//!
//! // nou vle konte nou yo kòmanse nan yon sèl, se konsa kite a ajoute yon metòd new() ede.
//! // Sa a pa estrikteman nesesè, men li pratik.
//! // Remake byen ke nou kòmanse `count` nan zewo, nou pral wè poukisa nan aplikasyon `next()`'s anba a.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Lè sa a, nou aplike `Iterator` pou `Counter` nou an:
//!
//! impl Iterator for Counter {
//!     // nou pral konte ak usize
//!     type Item = usize;
//!
//!     // next() se sèl metòd obligatwa
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Ogmante konte nou an.Se poutèt sa nou te kòmanse nan zewo.
//!         self.count += 1;
//!
//!         // Tcheke pou wè si nou fini konte oswa ou pa.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Epi, koulye a nou ka itilize li!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Rele [`next`] fason sa a vin repetitif.Rust gen yon konstwi ki ka rele [`next`] sou iteratè ou, jiskaske li rive nan `None`.Ann ale sou sa kap vini an.
//!
//! Epitou sonje ke `Iterator` bay yon aplikasyon default nan metòd tankou `nth` ak `fold` ki rele `next` intern.
//! Sepandan, li posib tou pou ekri yon aplikasyon koutim nan metòd tankou `nth` ak `fold` si yon iteratè ka kalkile yo pi efikasman san yo pa rele `next`.
//!
//! # `for` pasan ak `IntoIterator`
//!
//! Sentaks bouk `for` Rust a se aktyèlman sik pou iteratè.Isit la nan yon egzanp debaz nan `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Sa a pral enprime nimewo yo youn a senk, yo chak sou liy pwòp yo.Men, ou pral remake yon bagay isit la: nou pa janm rele anyen sou vector nou yo pwodwi yon iteratè.Ki sa ki bay?
//!
//! Genyen yon trait nan bibliyotèk la estanda pou konvèti yon bagay nan yon iteratè: [`IntoIterator`].
//! trait sa a gen yon sèl metòd, [`into_iter`], ki konvèti bagay ki aplike [`IntoIterator`] an yon iteratè.
//! Ann pran yon gade nan ki `for` bouk ankò, ak sa ki du a konvèti l 'nan:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sik sa a nan:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Premyèman, nou rele `into_iter()` sou valè a.Lè sa a, nou matche ak sou iteratè a ki retounen, rele [`next`] sou yo ak sou jiskaske nou wè yon `None`.
//! Nan pwen sa a, nou `break` soti nan bouk la, epi nou ap fè iterasyon.
//!
//! Genyen yon ti jan plis sibtil isit la: bibliyotèk la estanda gen yon aplikasyon enteresan nan [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Nan lòt mo, tout [`iterateur`] s aplike [`IntoIterator`], pa jis retounen tèt yo.Sa vle di de bagay:
//!
//! 1. Si w ap ekri yon [`Iterator`], ou ka itilize li ak yon bouk `for`.
//! 2. Si w ap kreye yon koleksyon, aplike [`IntoIterator`] pou li pral pèmèt koleksyon ou yo dwe itilize ak bouk la `for`.
//!
//! # Repete pa referans
//!
//! Depi [`into_iter()`] pran `self` pa valè, lè l sèvi avèk yon bouk `for` repete sou yon koleksyon manje koleksyon sa a.Souvan, ou ka vle repete sou yon koleksyon san ou pa konsome li.
//! Anpil koleksyon ofri metòd ki bay iterateur sou referans, konvansyonèl yo rele `iter()` ak `iter_mut()` respektivman:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` se toujou posede pa fonksyon sa a.
//! ```
//!
//! Si yon kalite koleksyon `C` bay `iter()`, anjeneral li aplike tou `IntoIterator` pou `&C`, ak yon aplikasyon ki jis rele `iter()`.
//! Menm jan an tou, yon koleksyon `C` ki bay `iter_mut()` jeneralman aplike `IntoIterator` pou `&mut C` pa delege nan `iter_mut()`.Sa pèmèt yon steno pratik:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // menm jan ak `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // menm jan ak `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Pandan ke anpil koleksyon ofri `iter()`, se pa tout ki ofri `iter_mut()`.
//! Pou egzanp, mitasyon kle yo nan yon [`HashSet<T>`] oswa [`HashMap<K, V>`] ta ka mete koleksyon an nan yon eta konsistan si kle a chanje, kidonk koleksyon sa yo ofri sèlman `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Fonksyon ki pran yon [`Iterator`] epi retounen yon lòt [`Iterator`] yo souvan rele 'iterateur cartes', menm jan yo ap yon fòm nan 'adaptè a
//! pattern'.
//!
//! Cartes iteratè komen yo enkli [`map`], [`take`], ak [`filter`].
//! Pou plis, gade dokiman yo.
//!
//! Si yon iteratè adaptè panics, iteratè a pral nan yon eta ki pa espesifye (men ki an sekirite).
//! Eta sa a tou pa garanti yo rete menm bagay la tou atravè vèsyon an Rust, kidonk, ou ta dwe evite repoze sou valè yo egzak retounen pa yon iteratè ki panike.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratè (ak iteratè [adapters](#adapters)) yo *parese*. Sa vle di ke jis kreye yon iteratè pa _do_ yon anpil antye. Pa gen anyen reyèlman rive jiskaske ou rele [`next`].
//! Sa a se pafwa yon sous konfizyon lè kreye yon iteratè sèlman pou efè segondè li yo.
//! Pou egzanp, metòd la [`map`] rele yon fèmti sou chak eleman li repete sou:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Sa a pa pral enprime nenpòt valè, menm jan nou sèlman kreye yon iteratè, olye ke itilize li.Konpilatè a pral avèti nou sou kalite konpòtman sa a:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Fason idiomatik pou ekri yon [`map`] pou efè segondè li yo se sèvi ak yon bouk `for` oswa rele metòd [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Yon lòt fason komen pou evalye yon iteratè se sèvi ak metòd [`collect`] pou pwodwi yon nouvo koleksyon.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratè pa dwe fini.Kòm yon egzanp, yon seri ouvè se yon iteratè enfini:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Li komen pou itilize adaptè iteratè [`take`] pou vire yon iteratè enfini nan yon sèl fini:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Sa a pral enprime nimewo yo `0` jiska `4`, yo chak sou liy pwòp yo.
//!
//! Kenbe nan tèt ou ke metòd sou iteratè enfini, menm sa yo pou ki ka yon rezilta dwe detèmine matematik nan tan fini, pa pouvwa mete fen.
//! Espesyalman, metòd tankou [`min`], ki nan ka jeneral la mande pou travèse chak eleman nan iteratè a, gen anpil chans pa retounen avèk siksè pou nenpòt ki iteratè enfini.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh non!Yon bouk enfini!
//! // `ones.min()` lakòz yon bouk enfini, kidonk nou pa pral rive nan pwen sa a!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;