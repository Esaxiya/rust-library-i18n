use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Objè ki gen yon nosyon de *siksesè* ak *predesesè* operasyon yo.
///
/// *Siksesyon* operasyon an deplase nan direksyon pou valè ki konpare pi gran.
/// Operasyon an *predesesè* deplase nan direksyon pou valè ki konpare pi piti.
///
/// # Safety
///
/// trait sa a se `unsafe` paske aplikasyon li yo dwe kòrèk pou sekirite nan aplikasyon `unsafe trait TrustedLen`, ak rezilta yo nan lè l sèvi avèk sa a trait ka otreman dwe fè konfyans pa `unsafe` kòd yo dwe kòrèk epi ranpli obligasyon yo ki nan lis la.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Retounen kantite etap * siksesè yo oblije jwenn nan `start` rive `end`.
    ///
    /// Retounen `None` si kantite etap ta debòde `usize` (oswa enfini, oswa si `end` pa ta janm rive jwenn).
    ///
    ///
    /// # Invariants
    ///
    /// Pou nenpòt `a`, `b`, ak `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` si epi sèlman si `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` si epi sèlman si `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` sèlman si `a <= b`
    ///   * Kowolè: `steps_between(&a, &b) == Some(0)` si e sèlman si `a == b`
    ///   * Remake byen ke `a <= b` fè _not_ vle di `steps_between(&a, &b) != None`;
    ///     sa a se ka a lè li ta mande pou plis pase `usize::MAX` etap pou li ale nan `b`
    /// * `steps_between(&a, &b) == None` si `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Retounen valè ki ta jwenn nan pran *siksesè*`self` `count` fwa.
    ///
    /// Si sa ta debòde ranje valè ki te sipòte pa `Self`, retounen `None`.
    ///
    /// # Invariants
    ///
    /// Pou nenpòt `a`, `n`, ak `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Pou nenpòt `a`, `n`, ak `m` kote `n + m` pa debòde:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Pou nenpòt `a` ak `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Retounen valè ki ta jwenn nan pran *siksesè*`self` `count` fwa.
    ///
    /// Si sa ta debòde ranje valè ki te sipòte pa `Self`, fonksyon sa a pèmèt panic, vlope, oswa boure.
    ///
    /// Konpòtman an sijere se panic lè afimasyon debug yo pèmèt, ak vlope oswa boure otreman.
    ///
    /// Kòd ensekirite pa ta dwe konte sou jistès nan konpòtman apre debòde.
    ///
    /// # Invariants
    ///
    /// Pou nenpòt `a`, `n`, ak `m`, kote pa gen okenn debòde rive:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Pou nenpòt `a` ak `n`, kote pa gen okenn debòde rive:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Retounen valè ki ta jwenn nan pran *siksesè*`self` `count` fwa.
    ///
    /// # Safety
    ///
    /// Li se konpòtman endefini pou operasyon sa a debòde seri a nan valè sipòte pa `Self`.
    /// Si ou pa ka garanti ke sa a pa pral debòde, sèvi ak `forward` oswa `forward_checked` olye.
    ///
    /// # Invariants
    ///
    /// Pou nenpòt `a`:
    ///
    /// * si gen `b` tankou `b > a`, li an sekirite pou rele `Step::forward_unchecked(a, 1)`
    /// * si gen `b`, `n` tankou `steps_between(&a, &b) == Some(n)`, li an sekirite pou rele `Step::forward_unchecked(a, m)` pou nenpòt `m <= n`.
    ///
    ///
    /// Pou nenpòt `a` ak `n`, kote pa gen okenn debòde rive:
    ///
    /// * `Step::forward_unchecked(a, n)` ekivalan a `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Retounen valè ki ta ka jwenn nan pran *predesesè*`self` `count` fwa.
    ///
    /// Si sa ta debòde ranje valè ki te sipòte pa `Self`, retounen `None`.
    ///
    /// # Invariants
    ///
    /// Pou nenpòt `a`, `n`, ak `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Pou nenpòt `a` ak `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Retounen valè ki ta ka jwenn nan pran *predesesè*`self` `count` fwa.
    ///
    /// Si sa ta debòde ranje valè ki te sipòte pa `Self`, fonksyon sa a pèmèt panic, vlope, oswa boure.
    ///
    /// Konpòtman an sijere se panic lè afimasyon debug yo pèmèt, ak vlope oswa boure otreman.
    ///
    /// Kòd ensekirite pa ta dwe konte sou jistès nan konpòtman apre debòde.
    ///
    /// # Invariants
    ///
    /// Pou nenpòt `a`, `n`, ak `m`, kote pa gen okenn debòde rive:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Pou nenpòt `a` ak `n`, kote pa gen okenn debòde rive:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Retounen valè ki ta ka jwenn nan pran *predesesè*`self` `count` fwa.
    ///
    /// # Safety
    ///
    /// Li se konpòtman endefini pou operasyon sa a debòde seri a nan valè sipòte pa `Self`.
    /// Si ou pa ka garanti ke sa a pa pral debòde, sèvi ak `backward` oswa `backward_checked` olye.
    ///
    /// # Invariants
    ///
    /// Pou nenpòt `a`:
    ///
    /// * si gen `b` tankou `b < a`, li an sekirite pou rele `Step::backward_unchecked(a, 1)`
    /// * si gen `b`, `n` tankou `steps_between(&b, &a) == Some(n)`, li an sekirite pou rele `Step::backward_unchecked(a, m)` pou nenpòt `m <= n`.
    ///
    ///
    /// Pou nenpòt `a` ak `n`, kote pa gen okenn debòde rive:
    ///
    /// * `Step::backward_unchecked(a, n)` ekivalan a `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Sa yo toujou macro-pwodwi paske literal nonb antye relatif yo rezoud diferan kalite.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SEKIRITE: moun kap rele a gen garanti ke `start + n` pa debòde.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // SEKIRITE: moun kap rele a gen garanti ke `start - n` pa debòde.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Nan debug bati, deklanche yon panic sou debòde.
            // Sa a ta dwe optimize konplètman soti nan lage bati.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Fè matematik anbalaj pou pèmèt egzanp `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Nan debug bati, deklanche yon panic sou debòde.
            // Sa a ta dwe optimize konplètman soti nan lage bati.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Fè matematik anbalaj pou pèmèt egzanp `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Sa a depann sou $u_narrower <=itilize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // si n soti nan ranje, `unsigned_start + n` tou
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // si n soti nan ranje, `unsigned_start - n` tou
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Sa a depann sou $i_narrower <=itilize
                        //
                        // Distribisyon isize pwolonje lajè a men prezève siy lan.
                        // Sèvi ak wrapping_sub nan espas isize ak jete yo itilize kalkile diferans lan ki pa ka anfòm andedan seri a nan isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Vlope manch ka tankou `Step::forward(-120_i8, 200) == Some(80_i8)`, menm si 200 se soti nan ranje pou i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Adisyon debòde
                            }
                        }
                        // Si n se soti nan seri de egzanp
                        // u8, Lè sa a, li pi gwo pase seri a tout antye pou i8 se lajè konsa `any_i8 + n` nesesèman debòde i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Vlope manch ka tankou `Step::forward(-120_i8, 200) == Some(80_i8)`, menm si 200 se soti nan ranje pou i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Soustraksyon debòde
                            }
                        }
                        // Si n se soti nan seri de egzanp
                        // u8, Lè sa a, li pi gwo pase seri a tout antye pou i8 se lajè konsa `any_i8 - n` nesesèman debòde i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Si diferans lan twò gwo pou egzanp
                            // i128, li la tou pral twò gwo pou usize ak mwens Bits.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SEKIRITE: res se yon skalè valab Unicode
            // (anba 0x110000 epi yo pa nan 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SEKIRITE: res se yon skalè valab Unicode
        // (anba 0x110000 epi yo pa nan 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SEKIRITE: moun kap rele a dwe garanti ke sa pa debòde
        // seri a nan valè pou yon Char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SEKIRITE: moun kap rele a dwe garanti ke sa pa debòde
            // seri a nan valè pou yon Char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // SEKIRITE: paske nan kontra anvan an, sa garanti
        // pa moun kap rele a yo dwe yon Char ki valab.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SEKIRITE: moun kap rele a dwe garanti ke sa pa debòde
        // seri a nan valè pou yon Char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SEKIRITE: moun kap rele a dwe garanti ke sa pa debòde
            // seri a nan valè pou yon Char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // SEKIRITE: paske nan kontra anvan an, sa garanti
        // pa moun kap rele a yo dwe yon Char ki valab.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SEKIRITE: jis tcheke prekondisyon
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SEKIRITE: jis tcheke prekondisyon
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Macro sa yo jenere `ExactSizeIterator` impls pou divès kalite seri.
//
// * `ExactSizeIterator::len` oblije toujou retounen yon `usize` egzak, kidonk pa gen ranje ki ka pi long pase `usize::MAX`.
//
// * Pou kalite nonb antye relatif nan `Range<_>` sa a se ka a pou kalite ki pi etwat pase oswa lajè tankou `usize`.
//   Pou kalite nonb antye relatif nan `RangeInclusive<_>` sa a se ka a pou kalite *estrikteman etwat* pase `usize` depi egzanp
//   `(0..=u64::MAX).len()` ta dwe `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Sa yo se enkòrèk pou rezònman ki anwo a, men retire yo ta dwe yon chanjman kraze jan yo te estabilize nan Rust 1.0.0.
    // Se konsa, egzanp
    // `(0..66_000_u32).len()` pou egzanp pral konpile san yo pa erè oswa avètisman sou tribin 16-ti jan, men kontinye bay yon rezilta mal.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Sa yo se enkòrèk pou chak rezònman ki anwo a, men retire yo ta dwe yon chanjman kraze jan yo te estabilize nan Rust 1.26.0.
    // Se konsa, egzanp
    // `(0..=u16::MAX).len()` pou egzanp pral konpile san yo pa erè oswa avètisman sou tribin 16-ti jan, men kontinye bay yon rezilta mal.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SEKIRITE: jis tcheke prekondisyon
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SEKIRITE: jis tcheke prekondisyon
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SEKIRITE: jis tcheke prekondisyon
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SEKIRITE: jis tcheke prekondisyon
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SEKIRITE: jis tcheke prekondisyon
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SEKIRITE: jis tcheke prekondisyon
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}