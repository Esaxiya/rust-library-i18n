#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Elaji nan swa `$crate::panic::panic_2015` oswa `$crate::panic::panic_2021` depann sou edisyon an nan moun kap rele a.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Afime ke de ekspresyon yo egal youn ak lòt (lè l sèvi avèk [`PartialEq`]).
///
/// Sou panic, macro sa a pral enprime valè ekspresyon yo ak reprezantasyon debug yo.
///
///
/// Tankou [`assert!`], macro sa a gen yon dezyèm fòm, kote yo ka bay yon mesaj panic koutim.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Reborrows ki anba yo entansyonèl.
                    // San yo, se plas la chemine pou prete a inisyalize menm anvan valè yo konpare, ki mennen nan yon ralanti aparan.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Reborrows ki anba yo entansyonèl.
                    // San yo, se plas la chemine pou prete a inisyalize menm anvan valè yo konpare, ki mennen nan yon ralanti aparan.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afime ke de ekspresyon yo pa egal youn ak lòt (lè l sèvi avèk [`PartialEq`]).
///
/// Sou panic, macro sa a pral enprime valè ekspresyon yo ak reprezantasyon debug yo.
///
///
/// Tankou [`assert!`], macro sa a gen yon dezyèm fòm, kote yo ka bay yon mesaj panic koutim.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Reborrows ki anba yo entansyonèl.
                    // San yo, se plas la chemine pou prete a inisyalize menm anvan valè yo konpare, ki mennen nan yon ralanti aparan.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Reborrows ki anba yo entansyonèl.
                    // San yo, se plas la chemine pou prete a inisyalize menm anvan valè yo konpare, ki mennen nan yon ralanti aparan.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afime ke yon ekspresyon boolean se `true` nan ègzekutabl.
///
/// Sa a pral envoke macro la [`panic!`] si ekspresyon yo bay la pa ka evalye a `true` nan ègzekutabl.
///
/// Tankou [`assert!`], macro sa a tou te gen yon dezyèm vèsyon, kote yo ka bay yon mesaj koutim panic.
///
/// # Uses
///
/// Kontrèman ak [`assert!`], deklarasyon `debug_assert!` yo sèlman pèmèt nan bati ki pa optimize pa default.
/// Yon bati optimize pa pral egzekite deklarasyon `debug_assert!` sof si `-C debug-assertions` pase nan du a.
/// Sa fè `debug_assert!` itil pou chèk ki twò chè pou prezan nan yon bilding lage men ki ka itil pandan devlopman.
/// Se rezilta nan agrandi `debug_assert!` toujou kalite tcheke.
///
/// Yon deklarasyon san kontwòl pèmèt yon pwogram nan yon eta konsistan kenbe kouri, ki ta ka gen konsekans inatandi, men li pa prezante sekirite osi lontan ke sa rive sèlman nan kòd ki an sekirite.
///
/// Pri a pèfòmans nan deklarasyon, sepandan, se pa mezirab an jeneral.
/// Ranplase [`assert!`] ak `debug_assert!` se konsa sèlman ankouraje apre pwofil apwofondi, epi pi enpòtan, sèlman nan kòd san danje!
///
/// # Examples
///
/// ```
/// // mesaj panic pou deklarasyon sa yo se valè stringifye ekspresyon yo bay la.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // yon fonksyon trè senp
/// debug_assert!(some_expensive_computation());
///
/// // afime ak yon mesaj koutim
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Afime ke de ekspresyon yo egal youn ak lòt.
///
/// Sou panic, macro sa a pral enprime valè ekspresyon yo ak reprezantasyon debug yo.
///
/// Kontrèman ak [`assert_eq!`], deklarasyon `debug_assert_eq!` yo sèlman pèmèt nan bati ki pa optimize pa default.
/// Yon bati optimize pa pral egzekite deklarasyon `debug_assert_eq!` sof si `-C debug-assertions` pase nan du a.
/// Sa fè `debug_assert_eq!` itil pou chèk ki twò chè pou prezan nan yon bilding lage men ki ka itil pandan devlopman.
///
/// Se rezilta nan agrandi `debug_assert_eq!` toujou kalite tcheke.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Afime ke de ekspresyon yo pa egal youn ak lòt.
///
/// Sou panic, macro sa a pral enprime valè ekspresyon yo ak reprezantasyon debug yo.
///
/// Kontrèman ak [`assert_ne!`], deklarasyon `debug_assert_ne!` yo sèlman pèmèt nan bati ki pa optimize pa default.
/// Yon bati optimize pa pral egzekite deklarasyon `debug_assert_ne!` sof si `-C debug-assertions` pase nan du a.
/// Sa fè `debug_assert_ne!` itil pou chèk ki twò chè pou prezan nan yon bilding lage men ki ka itil pandan devlopman.
///
/// Se rezilta nan agrandi `debug_assert_ne!` toujou kalite tcheke.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Retounen si wi ou non ekspresyon yo bay la matche ak nenpòt nan modèl yo bay yo.
///
/// Tankou nan yon ekspresyon `match`, modèl la ka opsyonèlman swiv pa `if` ak yon ekspresyon gad ki gen aksè a non mare pa modèl la.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Dekouvwi yon rezilta oswa pwopaje erè li yo.
///
/// Operatè `?` la te ajoute pou ranplase `try!` e yo ta dwe itilize olye de sa.
/// Anplis de sa, `try` se yon mo rezève nan Rust 2018, kidonk si ou dwe itilize li, ou pral bezwen sèvi ak [raw-identifier syntax][ris] la: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` matche ak [`Result`] yo bay la.Nan ka Variant `Ok` la, ekspresyon an gen valè valè vlope a.
///
/// Nan ka Variant `Err` la, li rekipere erè enteryè a.`try!` Lè sa a, fè konvèsyon lè l sèvi avèk `From`.
/// Sa a bay konvèsyon otomatik ant erè espesyalize ak sa yo ki pi jeneral.
/// Erè a ki kapab lakòz se Lè sa a, imedyatman retounen.
///
/// Paske nan retou a byen bonè, `try!` ka itilize sèlman nan fonksyon ki retounen [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Metòd la pi pito nan Erè retounen rapid
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Metòd la anvan yo retounen rapid Erè
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Sa ekivalan a:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Ekri done fòma nan yon pezib.
///
/// Macro sa a aksepte yon 'writer', yon fisèl fòma, ak yon lis agiman.
/// Agiman yo pral fòma selon fisèl la fòma espesifye ak rezilta a pral pase bay ekriven an.
/// Ekriven an pouvwa gen nenpòt valè ak yon metòd `write_fmt`;jeneralman sa soti nan yon aplikasyon swa [`fmt::Write`] oswa [`io::Write`] trait.
/// Macro a retounen tou sa metòd la `write_fmt` retounen;souvan yon [`fmt::Result`], oswa yon [`io::Result`].
///
/// Gade [`std::fmt`] pou plis enfòmasyon sou sentaks la fisèl fòma.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Yon modil ka enpòte tou de `std::fmt::Write` ak `std::io::Write` epi rele `write!` sou objè ki aplike swa, kòm objè pa tipikman aplike tou de.
///
/// Sepandan, modil la dwe enpòte traits ki kalifye pou non yo pa konfli:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // itilize fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // itilize io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Macro sa a ka itilize nan konfigirasyon `no_std` tou.
/// Nan yon konfigirasyon `no_std` ou responsab pou detay aplikasyon eleman yo.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Ekri fòma done nan yon pezib, ak yon newline ajoute.
///
/// Sou tout tribin, newline a se karaktè LINE FEED karaktè (`\n`/`U+000A`) pou kont li (pa gen okenn retou CHARIAGE adisyonèl (`\r`/`U+000D`).
///
/// Pou plis enfòmasyon, gade [`write!`].Pou enfòmasyon sou sentaks la fòma fisèl, gade [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Yon modil ka enpòte tou de `std::fmt::Write` ak `std::io::Write` epi rele `write!` sou objè ki aplike swa, kòm objè pa tipikman aplike tou de.
/// Sepandan, modil la dwe enpòte traits ki kalifye pou non yo pa konfli:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // itilize fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // itilize io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Endike kòd irealizabl.
///
/// Sa a se itil nenpòt ki lè ke du a pa ka detèmine ke kèk kòd se unreachable.Pa egzanp:
///
/// * Match bra ak kondisyon gad.
/// * Loops ki dinamik mete fen.
/// * Iteratè ki dinamik mete fen.
///
/// Si detèminasyon ki di ke kòd la pa rive jwenn pwouve kòrèk, pwogram nan imedyatman fini ak yon [`panic!`].
///
/// Kontrepati an danjere nan macro sa a se fonksyon [`unreachable_unchecked`], ki pral lakòz konpòtman endefini si yo rive jwenn kòd la.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Sa a ap toujou [`panic!`].
///
/// # Examples
///
/// Match bra:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // konpile erè si kòmante soti
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // youn nan aplikasyon ki pi pòv nan x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Endike kòd enplemante pa panike ak yon mesaj nan "not implemented".
///
/// Sa a pèmèt kòd ou a tape-tcheke, ki se itil si w ap pwototip oswa aplike yon trait ki mande pou plizyè metòd ke ou pa fè plan pou yo sèvi ak tout.
///
/// Diferans ki genyen ant `unimplemented!` ak [`todo!`] se ke pandan ke `todo!` transmèt yon entansyon pou aplike fonksyonalite a pita ak mesaj la se "not yet implemented", `unimplemented!` pa fè okenn reklamasyon sa yo.
/// Mesaj li se "not implemented".
/// Epitou kèk IDE pral make `todo!` S.
///
/// # Panics
///
/// Sa a ap toujou [`panic!`] paske `unimplemented!` se jis yon steno pou `panic!` ak yon mesaj fiks, espesifik.
///
/// Tankou `panic!`, macro sa a gen yon dezyèm fòm pou montre valè koutim.
///
/// # Examples
///
/// Di nou gen yon trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Nou vle aplike `Foo` pou 'MyStruct', men pou kèk rezon li sèlman fè sans pou aplike fonksyon `bar()` la.
/// `baz()` ak `qux()` ap toujou bezwen defini nan aplikasyon nou an `Foo`, men nou ka itilize `unimplemented!` nan definisyon yo pou pèmèt kòd nou an konpile.
///
/// Nou toujou vle fè pwogram nou an sispann kouri si metòd yo aplike pa rive.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Li pa fè okenn sans pou `baz` yon `MyStruct`, kidonk nou pa gen okenn lojik isit ditou.
/////
///         // Sa a pral montre "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Nou gen kèk lojik isit la, Nou ka ajoute yon mesaj pou enplemante!yo montre omisyon nou an.
///         // Sa a pral montre: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Endike kòd fini.
///
/// Sa a ka itil si w ap pwototip epi yo jis kap gen typecheck kòd ou a.
///
/// Diferans ki genyen ant [`unimplemented!`] ak `todo!` se ke pandan ke `todo!` transmèt yon entansyon pou aplike fonksyonalite a pita ak mesaj la se "not yet implemented", `unimplemented!` pa fè okenn reklamasyon sa yo.
/// Mesaj li se "not implemented".
/// Epitou kèk IDE pral make `todo!` S.
///
/// # Panics
///
/// Sa a ap toujou [`panic!`].
///
/// # Examples
///
/// Isit la nan yon egzanp sou kèk kòd nan-pwogrè.Nou gen yon trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Nou vle aplike `Foo` sou youn nan kalite nou yo, men nou menm tou nou vle travay sou jis `bar()` an premye.Nan lòd pou kòd nou an konpile, nou bezwen aplike `baz()`, pou nou ka itilize `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // aplikasyon ale isit la
///     }
///
///     fn baz(&self) {
///         // kite a pa enkyete sou mete ann aplikasyon baz() pou kounye a
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nou pa menm lè l sèvi avèk baz(), se konsa sa a se amann.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definisyon bati-an makro.
///
/// Pifò nan pwopriyete yo macro (estabilite, vizibilite, elatriye) yo te pran nan kòd la sous isit la, ak eksepsyon de fonksyon ekspansyon transfòme entrain macro nan rezilta, fonksyon sa yo ki ofri pa du a.
///
///
pub(crate) mod builtin {

    /// Kòz konpilasyon echwe ak mesaj la erè bay lè rankontre.
    ///
    /// Macro sa a ta dwe itilize lè yon crate itilize yon estrateji konpilasyon kondisyonèl pou bay pi bon mesaj erè pou kondisyon inègza.
    ///
    /// Li nan fòm nan nivo du [`panic!`], men emèt yon erè pandan *konpilasyon* olye ke nan *ègzekutabl*.
    ///
    /// # Examples
    ///
    /// De egzanp sa yo se makro ak anviwònman `#[cfg]`.
    ///
    /// Emèt pi bon erè du si se yon macro pase valè envalid.
    /// San yo pa branch final la, du a ta toujou emèt yon erè, men mesaj erè a pa ta mansyone de valè ki valab yo.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emèt erè du si youn nan yon kantite karakteristik pa disponib.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstwi paramèt pou lòt makro yo fisèl-fòma.
    ///
    /// Sa a macro fonksyon pa pran yon fisèl literal fòma ki gen `{}` pou chak agiman adisyonèl pase.
    /// `format_args!` prepare paramèt adisyonèl yo pou asire pwodiksyon an ka entèprete kòm yon fisèl ak canonicalizes agiman yo nan yon kalite sèl.
    /// Nenpòt valè ki aplike [`Display`] trait la ka pase nan `format_args!`, menm jan nenpòt aplikasyon [`Debug`] ka pase nan yon `{:?}` nan fisèl fòma a.
    ///
    ///
    /// Macro sa a pwodui yon valè kalite [`fmt::Arguments`].Valè sa a ka pase nan makro yo nan [`std::fmt`] pou fè redireksyon itil.
    /// Tout lòt makro fòma ([`fòma!`], [`write!`], [`println!`], elatriye) yo proxy nan yon sèl sa a.
    /// `format_args!`, kontrèman ak macros sòti li yo, evite alokasyon pil.
    ///
    /// Ou ka itilize valè [`fmt::Arguments`] ke `format_args!` retounen nan kontèks `Debug` ak `Display` jan yo wè anba a.
    /// Egzanp lan montre ke fòma `Debug` ak `Display` menm bagay la tou: fisèl fòma entèpolasyon nan `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Pou plis enfòmasyon, gade dokiman ki nan [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Menm jan ak `format_args`, men ajoute yon newline nan fen an.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Enspekte yon varyab anviwònman nan tan konpile.
    ///
    /// Sa a macro pral elaji nan valè a nan varyab la anviwònman yo te rele nan tan konpile, ki bay yon ekspresyon de kalite `&'static str`.
    ///
    ///
    /// Si varyab anviwònman an pa defini, lè sa a yo pral emèt yon erè konpilasyon.
    /// Pou pa emèt yon erè konpile, sèvi ak macro [`option_env!`] la pito.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Ou ka Customize mesaj la erè pa pase yon fisèl kòm dezyèm paramèt la:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Si varyab anviwònman `documentation` la pa defini, ou pral jwenn erè sa a:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Si ou vle enspekte yon varyab anviwònman nan tan konpile.
    ///
    /// Si varyab anviwònman an yo te prezan nan tan konpile, sa a pral elaji nan yon ekspresyon de kalite `Option<&'static str>` ki gen valè se `Some` nan valè varyab anviwònman an.
    /// Si varyab anviwònman an pa prezan, lè sa a sa a pral elaji nan `None`.
    /// Gade [`Option<T>`][Option] pou plis enfòmasyon sou kalite sa a.
    ///
    /// Yon erè tan konpile pa janm emèt lè w ap itilize sa a macro kèlkeswa si wi ou non varyab anviwònman an prezan oswa ou pa.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konkaten idantifyan nan yon sèl idantifyan.
    ///
    /// Macro sa a pran nenpòt ki kantite idantifyan vigil-separe, ak anchene yo tout nan yon sèl, ki bay yon ekspresyon ki se yon nouvo idantifikasyon.
    /// Remake byen ke ijyèn fè li tankou ke macro sa a pa ka pran varyab lokal yo.
    /// Epitou, tankou yon règ jeneral, makro yo sèlman pèmèt nan atik, deklarasyon oswa pozisyon ekspresyon.
    /// Sa vle di pandan ke ou ka itilize sa a macro pou refere li a varyab ki egziste deja, fonksyon oswa modil elatriye, ou pa ka defini yon nouvo avèk li.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nouvo, plezi, non) { }//pa ka itilize nan fason sa a!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konkaten literal nan yon tranch fisik estatik.
    ///
    /// Macro sa a pran nenpòt ki kantite literal vigil-separe, ki bay yon ekspresyon de kalite `&'static str` ki reprezante tout literal yo mete de gòch a dwat.
    ///
    ///
    /// Nonb antye relatif ak literal pwen k ap flote yo stringifye yo nan lòd yo dwe ankonbre.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ogmante nan nimewo liy lan sou ki li te envoke.
    ///
    /// Avèk [`column!`] ak [`file!`], makro sa yo bay enfòmasyon debogaj pou devlopè sou kote a nan sous la.
    ///
    /// Ekspresyon an elaji gen kalite `u32` epi li se 1 ki baze sou, se konsa liy lan premye nan chak dosye evalye a 1, dezyèm lan a 2, elatriye.
    /// Sa a se ki konsistan avèk mesaj erè pa konpilateur komen oswa editè popilè.
    /// Liy ki retounen an se *pa nesesèman* liy envokasyon `line!` li menm, men pito premye envokasyon macro ki mennen jiska envokasyon makro `line!` la.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ogmante nan nimewo kolòn kote li te envoke a.
    ///
    /// Avèk [`line!`] ak [`file!`], makro sa yo bay enfòmasyon debogaj pou devlopè sou kote a nan sous la.
    ///
    /// Ekspresyon an elaji gen kalite `u32` epi li se 1 ki baze sou, se konsa kolòn nan premye nan chak liy evalye a 1, dezyèm lan a 2, elatriye.
    /// Sa a se ki konsistan avèk mesaj erè pa konpilateur komen oswa editè popilè.
    /// Kolòn nan retounen se *pa nesesèman* liy lan nan envokasyon an `column!` tèt li, men pito premye envokasyon an macro ki mennen jiska envokasyon an nan macro la `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Ogmante nan non an dosye kote li te envoke.
    ///
    /// Avèk [`line!`] ak [`column!`], makro sa yo bay enfòmasyon debogaj pou devlopè sou kote a nan sous la.
    ///
    /// Ekspresyon an elaji gen kalite `&'static str`, ak dosye a retounen se pa envokasyon nan macro la `file!` tèt li, men pito premye envokasyon an macro ki mennen jiska envokasyon an nan macro la `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifye agiman li yo.
    ///
    /// Macro sa a pral bay yon ekspresyon de kalite `&'static str` ki se strifikasyon tout tokens ki te pase nan macro la.
    /// Pa gen restriksyon yo mete sou sentaks la nan envokasyon an macro tèt li.
    ///
    /// Remake byen ke rezilta yo elaji nan opinyon tokens la ka chanje nan future la.Ou ta dwe fè atansyon si ou konte sou pwodiksyon an.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Gen ladan yon dosye kode UTF-8 kòm yon fisèl.
    ///
    /// Dosye a sitiye relatif nan dosye aktyèl la (menm jan ak jan yo jwenn modil yo).
    /// Se chemen yo bay la entèprete nan yon fason platfòm-espesifik nan tan konpile.
    /// Se konsa, pou egzanp, yon envokasyon ak yon chemen Windows ki gen backslashes `\` pa ta konpile kòrèkteman sou Unix.
    ///
    ///
    /// Macro sa a pral bay yon ekspresyon nan kalite `&'static str` ki se sa ki nan dosye a.
    ///
    /// # Examples
    ///
    /// Sipoze gen de dosye nan menm anyè a ak sa ki annapre yo:
    ///
    /// Dosye 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Dosye 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Konpile 'main.rs' ak kouri binè a ki kapab lakòz pral enprime "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Gen ladan yon dosye kòm yon referans a yon etalaj byte.
    ///
    /// Dosye a sitiye relatif nan dosye aktyèl la (menm jan ak jan yo jwenn modil yo).
    /// Se chemen yo bay la entèprete nan yon fason platfòm-espesifik nan tan konpile.
    /// Se konsa, pou egzanp, yon envokasyon ak yon chemen Windows ki gen backslashes `\` pa ta konpile kòrèkteman sou Unix.
    ///
    ///
    /// Macro sa a pral bay yon ekspresyon nan kalite `&'static [u8; N]` ki se sa ki nan dosye a.
    ///
    /// # Examples
    ///
    /// Sipoze gen de dosye nan menm anyè a ak sa ki annapre yo:
    ///
    /// Dosye 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Dosye 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Konpile 'main.rs' ak kouri binè a ki kapab lakòz pral enprime "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Elaji nan yon fisèl ki reprezante chemen modil aktyèl la.
    ///
    /// Chemen modil aktyèl la ka panse a kòm yerachi a nan modil ki mennen tounen jiska crate root la.
    /// Eleman nan premye nan chemen an retounen se non an nan crate a kounye a ke yo te konpile.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evalye konbinezon boolean nan drapo konfigirasyon nan konpile-tan.
    ///
    /// Anplis atribi `#[cfg]` la, macro sa a bay pou pèmèt evalyasyon ekspresyon boolean nan konfigirasyon drapo yo.
    /// Sa a souvan mennen nan mwens kopi kòd.
    ///
    /// Sentaks yo bay sa a macro se sentaks la menm jan ak atribi [`cfg`] la.
    ///
    /// `cfg!`, kontrèman ak `#[cfg]`, pa retire okenn kòd epi sèlman evalye vre oswa fo.
    /// Pou egzanp, tout blòk nan yon ekspresyon if/else bezwen valab lè yo itilize `cfg!` pou kondisyon an, kèlkeswa sa `cfg!` ap evalye.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analize yon dosye kòm yon ekspresyon oswa yon atik selon kontèks la.
    ///
    /// Dosye a sitiye relatif nan dosye aktyèl la (menm jan ak jan yo jwenn modil yo).Se chemen yo bay la entèprete nan yon fason platfòm-espesifik nan tan konpile.
    /// Se konsa, pou egzanp, yon envokasyon ak yon chemen Windows ki gen backslashes `\` pa ta konpile kòrèkteman sou Unix.
    ///
    /// Sèvi ak macro sa a se souvan yon move lide, paske si dosye a analize kòm yon ekspresyon, li pral mete nan kòd ki antoure a san ijyenik.
    /// Sa ka lakòz varyab oswa fonksyon yo diferan de sa dosye a espere si gen varyab oswa fonksyon ki gen menm non nan dosye aktyèl la.
    ///
    ///
    /// # Examples
    ///
    /// Sipoze gen de dosye nan menm anyè a ak sa ki annapre yo:
    ///
    /// Dosye 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Dosye 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Konpile 'main.rs' ak kouri binè a ki kapab lakòz pral enprime "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Afime ke yon ekspresyon boolean se `true` nan ègzekutabl.
    ///
    /// Sa a pral envoke macro la [`panic!`] si ekspresyon yo bay la pa ka evalye a `true` nan ègzekutabl.
    ///
    /// # Uses
    ///
    /// Afimasyon yo toujou tcheke nan tou de debug ak lage bati, epi yo pa ka enfim.
    /// Al gade nan [`debug_assert!`] pou deklarasyon ki pa pèmèt nan lage bati pa default.
    ///
    /// Kòd ensekirite ka konte sou `assert!` pou ranfòse invariants kouri-tan ke, si vyole ta ka mennen nan ensekirite.
    ///
    /// Lòt ka itilize nan `assert!` gen ladan tès ak ranfòse invariants kouri-tan nan kòd ki an sekirite (ki gen vyolasyon pa ka rezilta nan sekirite).
    ///
    ///
    /// # Mesaj Custom
    ///
    /// Macro sa a gen yon dezyèm fòm, kote yon mesaj koutim panic ka bay avèk oswa san agiman pou fòma.
    /// Gade [`std::fmt`] pou sentaks pou fòm sa a.
    /// Ekspresyon yo itilize kòm agiman fòma yo pral sèlman evalye si deklarasyon an echwe.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // mesaj panic pou deklarasyon sa yo se valè stringifye ekspresyon yo bay la.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // yon fonksyon trè senp
    ///
    /// assert!(some_computation());
    ///
    /// // afime ak yon mesaj koutim
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Asanble aliye.
    ///
    /// Li [unstable book] la pou itilizasyon an.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-style asanble aliye.
    ///
    /// Li [unstable book] la pou itilizasyon an.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modil-nivo asanble aliye.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Impressions pase tokens nan pwodiksyon estanda a.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Pèmèt oswa enfim fonctionnalités trase itilize pou debogaj lòt makro.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Atribi macro itilize pou aplike dériver makro.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Atribi macro aplike nan yon fonksyon yo vire l 'nan yon tès inite.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Atribi macro aplike nan yon fonksyon yo vire l 'nan yon tès referans.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Yon detay aplikasyon makro `#[test]` ak `#[bench]` yo.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Atribi macro aplike nan yon estatik yo enskri li kòm yon allocator mondyal.
    ///
    /// Gade tou [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Kenbe atik la li aplike a si chemen ki pase a aksesib, epi li retire li otreman.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Elaji tout atribi `#[cfg]` ak `#[cfg_attr]` nan fragman kòd li aplike a.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Enstab aplikasyon detay nan `rustc` du a, pa sèvi ak yo.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Enstab aplikasyon detay nan `rustc` du a, pa sèvi ak yo.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}