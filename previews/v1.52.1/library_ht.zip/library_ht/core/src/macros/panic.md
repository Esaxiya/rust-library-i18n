Panics fil aktyèl la.

Sa pèmèt yon pwogram mete fen imedyatman epi bay fidbak moun kap rele pwogram lan.
`panic!` ta dwe itilize lè yon pwogram rive nan yon eta irevokabl.

Macro sa a se yon fason pafè pou revandike kondisyon nan kòd egzanp ak nan tès yo.
`panic!` se byen mare ak metòd la `unwrap` nan tou de [`Option`][ounwrap] ak [`Result`][runwrap] enums.
Tou de aplikasyon yo rele `panic!` lè yo mete yo nan [`None`] oswa [`Err`] variantes.

Lè w ap itilize `panic!()` ou ka presize yon chaj fisèl, ki bati lè l sèvi avèk sentaks la [`format!`].
Sa se chaj itilize lè enjekte panic a nan fil Rust a rele, sa ki lakòz fil la panic antyèman.

Konpòtman default `std` hook la, sa vle di
kòd la ki kouri dirèkteman apre yo fin envoke panic a, se enprime chaj la mesaj `stderr` ansanm ak enfòmasyon an file/line/column nan apèl la `panic!()`.

Ou ka pase sou desizyon panic hook la lè l sèvi avèk [`std::panic::set_hook()`].
Anndan hook yon panic ka jwenn aksè kòm yon `&dyn Any + Send`, ki gen swa yon `&str` oswa `String` pou envokasyon regilye `panic!()`.
Pou panic ak yon valè de yon lòt kalite, [`panic_any`] ka itilize.

[`Result`] enum se souvan yon solisyon pi bon pou rekipere li de erè pase lè l sèvi avèk `panic!` macro la.
Macro sa a ta dwe itilize pou fè pou evite pwosedi lè l sèvi avèk valè kòrèk, tankou soti nan sous ekstèn.
Enfòmasyon detaye sou manyen erè yo jwenn nan [book] la.

Gade tou macro [`compile_error!`] la, pou ogmante erè pandan konpilasyon.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Kouran aplikasyon

Si fil prensipal panics la li pral mete fen nan tout fil ou yo epi fini pwogram ou an ak kòd `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





