#![stable(feature = "core_hint", since = "1.27.0")]

//! Sijesyon sou du ki afekte ki jan kòd yo ta dwe emèt oswa optimize.
//! Sijesyon yo ka konpile tan oswa ègzekutabl.

use crate::intrinsics;

/// Enfòme du a ke pwen sa a nan kòd la pa rive, sa ki pèmèt plis optimize.
///
/// # Safety
///
/// Rive nan fonksyon sa a se konplètman *endefini konpòtman*(UB).An patikilye, du a sipoze ke tout UB pa dwe janm rive, ak Se poutèt sa pral elimine tout branch ki rive nan yon apèl nan `unreachable_unchecked()`.
///
/// Tankou tout sikonstans UB, si sipozisyon sa a vire soti nan sa ki mal, sa vle di, apèl la `unreachable_unchecked()` se aktyèlman atenn nan mitan tout koule kontwòl posib, du a pral aplike estrateji nan optimize sa ki mal, epi yo ka pafwa menm fin pouri kòd w pèdi gen rapò, sa ki lakòz difisil-pwoblèm debogaj.
///
///
/// Sèvi ak fonksyon sa a sèlman lè ou ka pwouve ke kòd la pap janm rele li.
/// Sinon, konsidere lè l sèvi avèk macro la [`unreachable!`], ki pa pèmèt optimize men yo pral panic lè egzekite.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` se toujou pozitif (pa zewo), kon sa `checked_div` pa janm ap retounen `None`.
/////
///     // Se poutèt sa, branch a lòt moun se unreachable.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SEKIRITE: kontra sekirite pou `intrinsics::unreachable` dwe
    // dwe konfime pa moun kap rele a.
    unsafe { intrinsics::unreachable() }
}

/// Emèt yon enstriksyon machin siyal processeur a ke li ap kouri nan yon okipe-rete tann vire-bouk ("vire fèmen").
///
/// Lè yo fin resevwa siyal la vire-bouk processeur a ka optimize konpòtman li pa, pou egzanp, ekonomize pouvwa oswa oblije chanje hyper-fil.
///
/// Fonksyon sa a diferan de [`thread::yield_now`] ki dirèkteman bay orè sistèm lan, tandiske `spin_loop` pa kominike avèk sistèm operasyon an.
///
/// Yon ka itilizasyon komen pou `spin_loop` ap aplike bòne optimis k ap vire nan yon bouk CAS nan primitif senkronizasyon.
/// Pou evite pwoblèm tankou envèsyon priyorite, li rekòmande ke se bouk la vire sispann apre yon kantite lajan fini nan iterasyon ak yon syscall bloke ki apwopriye fèt.
///
///
/// **Remak**: Sou tribin ki pa sipòte resevwa sijesyon vire-bouk fonksyon sa a pa fè anyen ditou.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Yon valè atomik pataje ke fil yo pral itilize pou kowòdone
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Nan yon fil background nou pral evantyèlman mete valè a
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Fè kèk travay, Lè sa a, fè valè a ap viv la
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Retounen sou fil aktyèl nou an, nou rete tann pou valè a yo dwe mete
/// while !live.load(Ordering::Acquire) {
///     // Bouk la vire se yon allusion CPU a ke nou ap tann, men pwobableman pa pou anpil tan
/////
///     hint::spin_loop();
/// }
///
/// // Valè a kounye a mete
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SEKIRITE: `cfg` attr la asire ke nou sèlman egzekite sa a sou objektif x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SEKIRITE: `cfg` attr la asire ke nou sèlman egzekite sa a sou objektif x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SEKIRITE: `cfg` attr la asire ke nou sèlman egzekite sa a sou objektif aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SEKIRITE: `cfg` attr la asire ke nou sèlman egzekite sa a sou objektif bra
            // ak sipò pou karakteristik v6 la.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Yon fonksyon idantite ki *__ sijesyon __* nan du a yo dwe maksimòm pesimism sou sa `black_box` te kapab fè.
///
/// Kontrèman ak [`std::convert::identity`], se yon du Rust ankouraje yo asime ke `black_box` ka itilize `dummy` nan nenpòt fason posib valab ke Rust kòd pèmèt san yo pa entwodwi konpòtman endefini nan kòd la rele.
///
/// Pwopriyete sa a fè `black_box` itil pou ekri kòd kote sèten optimizasyon pa vle, tankou referans.
///
/// Remake sepandan, ke `black_box` se sèlman (epi yo ka sèlman) bay sou yon baz "best-effort".Nan ki pwen li ka bloke optimize ka varye depann sou platfòm la ak kòd-gen backend itilize.
/// Pwogram yo pa ka konte sou `black_box` pou *kòrèkteman* nan okenn fason.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Nou bezwen "use" agiman an nan kèk fason LLVM pa ka entrospèkte, ak sou objektif ki sipòte li nou ka tipikman ogmante asanble inline fè sa.
    // Entèpretasyon LLVM nan asanble aliye se ke li, byen, yon bwat nwa.
    // Sa a se pa aplikasyon an pi gran depi li pwobableman deoptimizes plis pase nou vle, men li la byen lwen tèlman bon ase.
    //
    //

    #[cfg(not(miri))] // Sa a se jis yon allusion, kidonk li se amann sote nan Miri.
    // SEKIRITE: asanble a aliye se yon pa gen okenn-op.
    unsafe {
        // FIXME: Pa ka itilize `asm!` paske li pa sipòte MIPS ak lòt achitekti.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}