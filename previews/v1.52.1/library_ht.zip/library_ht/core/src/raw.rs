#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Gen definisyon struct pou Layout a nan kalite bati-an du.
//!
//! Yo ka itilize yo kòm sib transmutasyon nan kòd ki pa an sekirite pou manipile reprezantasyon kri yo dirèkteman.
//!
//!
//! Definisyon yo ta dwe toujou matche ak ABI ki defini nan `rustc_middle::ty::layout`.
//!

/// Reprezantasyon yon objè trait tankou `&dyn SomeTrait`.
///
/// Struct sa a gen Layout a menm jan ak kalite tankou `&dyn SomeTrait` ak `Box<dyn AnotherTrait>`.
///
/// `TraitObject` garanti matche ak kouman, men se pa kalite objè trait (pa egzanp, jaden yo pa aksesib dirèkteman sou yon `&dyn SomeTrait`) ni li pa kontwole layout sa a (chanje definisyon an pap chanje kouman yon `&dyn SomeTrait`).
///
/// Li fèt sèlman pou itilize pa kòd danjere ki bezwen manipile detay ki ba yo.
///
/// Pa gen okenn fason pou al gade nan tout objè trait jenerikman, kidonk sèl fason pou kreye valè kalite sa a se avèk fonksyon tankou [`std::mem::transmute`][transmute].
/// Menm jan an tou, yon fason a sèlman yo kreye yon objè vre trait ki sòti nan yon valè `TraitObject` se ak `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sentèz yon objè trait ak kalite mismatched-yon sèl kote vtable a pa koresponn ak ki kalite valè a ki pwen yo pwen done-trè chans pou mennen nan konpòtman endefini.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // yon egzanp trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // kite du a fè yon objè trait
/// let object: &dyn Foo = &value;
///
/// // gade nan reprezantasyon an anvan tout koreksyon
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // konsèy done a se adrès `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // konstwi yon nouvo objè, montre nan yon `i32` diferan, yo te atansyon yo sèvi ak `i32` vtable a soti nan `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // li ta dwe travay menm jan ak si nou te konstwi yon objè trait soti nan `other_value` dirèkteman
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}