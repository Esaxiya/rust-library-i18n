//! `Clone` trait la pou kalite ki pa ka 'enplisitman kopye'.
//!
//! Nan Rust, kèk kalite senp yo se "implicitly copyable" ak lè ou asiyen yo oswa pase yo kòm agiman, reseptè a pral jwenn yon kopi, kite valè orijinal la an plas.
//! Kalite sa yo pa mande pou alokasyon pou kopye epi yo pa gen finalizè (sètadi, yo pa gen bwat posede oswa aplike [`Drop`]), kidonk du a konsidere yo bon mache epi san danje pou kopye.
//!
//! Pou lòt kalite kopi yo dwe fèt klèman, pa konvansyon mete ann aplikasyon [`Clone`] trait la epi rele metòd [`clone`] la.
//!
//! [`clone`]: Clone::clone
//!
//! Egzanp itilizasyon debaz:
//!
//! ```
//! let s = String::new(); // Kalite fisèl aplike klonaj
//! let copy = s.clone(); // pou nou ka klone li
//! ```
//!
//! Pou fasilman aplike klonaj trait a, ou ka itilize `#[derive(Clone)]` tou.Egzanp:
//!
//! ```
//! #[derive(Clone)] // nou ajoute klonaj trait nan Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // e kounye a, nou ka script li!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Yon trait komen pou kapasite pou klèman kopi yon objè.
///
/// Diferan de [`Copy`] nan ki [`Copy`] se enplisit ak trè chè, pandan y ap `Clone` se toujou eksplisit epi yo ka oswa yo ka pa chè.
/// Yo nan lòd yo ranfòse karakteristik sa yo, Rust pa pèmèt ou reimplement [`Copy`], men ou ka reimplement `Clone` ak kouri kòd abitrè.
///
/// Depi `Clone` se pi jeneral pase [`Copy`], ou ka otomatikman fè anyen [`Copy`] dwe `Clone` tou.
///
/// ## Derivable
///
/// trait sa a ka itilize ak `#[derive]` si tout jaden yo `Clone`.`Derive`d aplikasyon [`Clone`] apèl [`clone`] sou chak jaden.
///
/// [`clone`]: Clone::clone
///
/// Pou yon struct jenerik, `#[derive]` aplike `Clone` kondisyon pa ajoute mare `Clone` sou paramèt jenerik.
///
/// ```
/// // `derive` aplike klonaj pou lekti<T>lè T se klonaj.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kouman mwen ka aplike `Clone`?
///
/// Kalite ki [`Copy`] ta dwe gen yon aplikasyon trivial nan `Clone`.Plis fòmèlman:
/// si `T: Copy`, `x: T`, ak `y: &T`, lè sa a `let x = y.clone();` ekivalan a `let x = *y;`.
/// Aplikasyon Manyèl yo ta dwe pran prekosyon pou defann envariant sa a;sepandan, kòd ensekirite pa dwe konte sou li pou asire sekirite memwa.
///
/// Yon egzanp se yon struct jenerik kenbe yon konsèy fonksyon.Nan ka sa a, aplikasyon an nan `Clone` pa ka `derive`d, men yo ka aplike kòm:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Enplemantè Lòt
///
/// Anplis de sa nan [implementors listed below][impls] la, kalite sa yo tou aplike `Clone`:
///
/// * Kalite atik fonksyon yo (sètadi, kalite diferan yo defini pou chak fonksyon)
/// * Fonksyon kalite konsèy (egzanp, `fn() -> i32`)
/// * Kalite etalaj, pou tout gwosè, si kalite atik la aplike tou `Clone` (egzanp, `[i32; 123456]`)
/// * Kalite tupl, si chak eleman tou aplike `Clone` (egzanp, `()`, `(i32, bool)`)
/// * Kalite fèmen, si yo pa pran okenn valè nan anviwònman an oswa si tout valè kaptire sa yo aplike `Clone` tèt yo.
///   Remake byen ke varyab kaptire pa referans pataje toujou aplike `Clone` (menm si referan a pa), pandan y ap varyab kaptire pa referans mutable pa janm aplike `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Retounen yon kopi valè a.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str aplike klonaj
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Fè kopi-plasman nan `source`.
    ///
    /// `a.clone_from(&b)` ki ekivalan a `a = b.clone()` nan fonctionnalités, men yo ka anile yo reutilize resous yo nan `a` pou fè pou evite alokasyon nesesè.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Rive macro génération yon impl nan trait `Clone` la.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): structs sa yo yo te itilize sèlman pa#[dériver] revandike ke chak eleman nan yon kalite aplike klonaj oswa kopi.
//
//
// Structs sa yo pa ta dwe janm parèt nan kòd itilizatè.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Aplikasyon nan `Clone` pou kalite primitif.
///
/// Aplikasyon ki pa ka dekri nan Rust yo aplike nan `traits::SelectionContext::copy_clone_conditions()` nan `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Pataje referans yo ka klone, men referans mityèl *pa kapab*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Pataje referans yo ka klone, men referans mityèl *pa kapab*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}