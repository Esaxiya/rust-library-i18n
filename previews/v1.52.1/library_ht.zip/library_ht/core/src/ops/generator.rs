use crate::marker::Unpin;
use crate::pin::Pin;

/// Rezilta a nan yon reouvè dèlko.
///
/// Sa a se Enum retounen soti nan metòd la `Generator::resume` ak endike valè yo retounen posib pou yon dèlko.
/// Kounye a sa koresponn ak swa yon pwen sispansyon (`Yielded`) oswa yon pwen revokasyon (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Dèlko a sispann ak yon valè.
    ///
    /// Eta sa a endike ke yon dèlko te sispann, epi tipikman koresponn ak yon deklarasyon `yield`.
    /// Valè yo bay nan sa a Variant koresponn ak ekspresyon ki te pase nan `yield` ak pèmèt dèlko bay yon valè chak fwa yo sede.
    ///
    ///
    Yielded(Y),

    /// Dèlko a ranpli ak yon valè retou.
    ///
    /// Eta sa a endike ke yon dèlko fini ekzekisyon ak valè yo bay la.
    /// Yon fwa ke yon dèlko retounen `Complete` li konsidere kòm yon erè pwogramè pou rele `resume` ankò.
    ///
    Complete(R),
}

/// trait aplike pa tip dèlko entegre.
///
/// Dèlko, tou souvan refere yo kòm koroutin, yo kounye a se yon karakteristik lang eksperimantal nan Rust.
/// Te ajoute nan [RFC 2033] dèlko yo kounye a gen entansyon prensipalman bay yon blòk bilding pou sentaks async/await men ap gen anpil chans pwolonje nan bay tou yon definisyon ergonomic pou iteratè ak lòt primitif.
///
///
/// Sentaks la ak semantik pou dèlko se enstab epi yo pral mande pou yon RFC plis pou estabilizasyon.Nan moman sa a, menm si, sentaks la se fèmen-tankou:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Plis dokiman nan dèlko ka jwenn nan liv la enstab.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Kalite valè dèlko sa a bay.
    ///
    /// Kalite asosye sa a koresponn ak ekspresyon `yield` ak valè ki pèmèt yo retounen chak fwa yon dèlko sede.
    ///
    /// Pou egzanp yon iteratè-tankou-yon-dèlko ta gen anpil chans gen kalite sa a kòm `T`, kalite a ke yo te repete sou.
    ///
    type Yield;

    /// Kalite valè dèlko sa a retounen.
    ///
    /// Sa a koresponn ak kalite a tounen soti nan yon dèlko swa ak yon deklarasyon `return` oswa enplisitman kòm ekspresyon ki sot pase a nan yon dèlko literal.
    /// Pou egzanp futures ta sèvi ak sa a kòm `Result<T, E>` kòm li reprezante yon future ranpli.
    ///
    ///
    type Return;

    /// Rekòmanse ekzekisyon dèlko sa a.
    ///
    /// Fonksyon sa a pral rekòmanse ekzekisyon dèlko a oswa kòmanse ekzekisyon si li pa deja.
    /// Apèl sa a ap retounen tounen nan dènye pwen sispansyon dèlko a, rekòmanse ekzekisyon nan dènye `yield` la.
    /// Dèlko a ap kontinye egzekite jiskaske li swa sede oswa retounen, nan ki pwen fonksyon sa a ap retounen.
    ///
    /// # Retounen valè
    ///
    /// `GeneratorState` enum retounen nan fonksyon sa a endike nan ki eta dèlko a ye lè li retounen.
    /// Si yo retounen Variant `Yielded` la lè sa a dèlko a te rive nan yon pwen sispansyon ak yon valè ki te sede soti.
    /// Dèlko nan eta sa a disponib pou reouvè nan yon pwen pita.
    ///
    /// Si `Complete` retounen lè sa a dèlko a fini nèt ak valè yo bay la.Li pa valab pou dèlko a rekòmanse ankò.
    ///
    /// # Panics
    ///
    /// Fonksyon sa a ka panic si li rele apre Variant `Complete` la te retounen deja.
    /// Pandan ke literal dèlko nan lang lan garanti panic sou rekòmanse apre `Complete`, sa pa garanti pou tout aplikasyon `Generator` trait la.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}