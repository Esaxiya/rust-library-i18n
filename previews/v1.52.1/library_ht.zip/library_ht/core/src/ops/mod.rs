//! Operatè surcharjabl.
//!
//! Aplike sa yo traits pèmèt ou Surcharge operatè sèten.
//!
//! Gen kèk nan traits sa yo ki enpòte pa prelude a, se konsa yo disponib nan chak pwogram Rust.Se sèlman operatè ki te sipòte pa traits ki ka twò chaje.
//! Pou egzanp, operatè adisyon (`+`) la ka twò chaje nan [`Add`] trait, men depi (`=`) operatè plasman an pa gen okenn trait fè bak, pa gen okenn fason pou twòp chaj semantik li yo.
//! Anplis de sa, modil sa a pa bay okenn mekanis pou kreye nouvo operatè yo.
//! Si Surcharge traitless oswa operatè koutim yo gen obligasyon, ou ta dwe gade nan direksyon makro oswa grefon du pou yon ekstansyon pou sentaks Rust la.
//!
//! Aplikasyon de traits operatè yo ta dwe etone nan kontèks respektif yo, kenbe nan tèt ou siyifikasyon abityèl yo ak [operator precedence].
//! Pou egzanp, lè w ap aplike [`Mul`], operasyon an ta dwe gen kèk resanblans ak miltiplikasyon (ak pataje pwopriyete espere tankou asosyativite).
//!
//! Remake byen ke operatè yo `&&` ak `||` kout sikwi, sa vle di, yo sèlman evalye dezyèm operasyon yo si li kontribye nan rezilta a.Depi konpòtman sa a pa aplikab pa traits, `&&` ak `||` yo pa sipòte kòm operatè surcharjabl.
//!
//! Anpil nan operatè yo pran operasyon yo pa valè.Nan kontèks ki pa jenerik ki enplike kalite bati, anjeneral se pa yon pwoblèm.
//! Sepandan, lè l sèvi avèk operatè sa yo nan kòd jenerik, mande pou kèk atansyon si valè yo dwe reyitilize kòm opoze a kite operatè yo konsome yo.Yon opsyon se detanzantan itilize [`clone`].
//! Yon lòt opsyon se konte sou kalite yo ki enplike bay aplikasyon operatè adisyonèl pou referans.
//! Pou egzanp, pou yon `T` itilizatè defini ki sipoze sipòte adisyon, li se pwobableman yon bon lide yo gen tou de `T` ak `&T` aplike traits [`Add<T>`][`Add`] a ak [`Add<&T>`][`Add`] pou ke jenerik kòd ka ekri san klonaj nesesè.
//!
//!
//! # Examples
//!
//! Egzanp sa a kreye yon struct `Point` ki aplike [`Add`] ak [`Sub`], ak Lè sa a demontre ajoute ak soustraksyon de `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Gade dokiman pou chak trait pou yon egzanp aplikasyon.
//!
//! [`Fn`], [`FnMut`], ak [`FnOnce`] traits yo aplike pa kalite ki ka envoke tankou fonksyon.Remake byen ke [`Fn`] pran `&self`, [`FnMut`] pran `&mut self` ak [`FnOnce`] pran `self`.
//! Sa yo koresponn ak twa kalite metòd ki ka envoke sou yon egzanp: rele-pa-referans, rele-pa-mutable-referans, ak rele-pa-valè.
//! Itilizasyon ki pi komen nan traits sa yo se aji kòm limit nan pi wo nivo fonksyon ki pran fonksyon oswa fèmti kòm agiman.
//!
//! Lè w ap pran yon [`Fn`] kòm yon paramèt:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Lè w ap pran yon [`FnMut`] kòm yon paramèt:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Lè w ap pran yon [`FnOnce`] kòm yon paramèt:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` konsome varyab kaptire li yo, kidonk li pa ka kouri plis pase yon fwa
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Eseye envoke `func()` ankò ap voye yon erè `use of moved value` pou `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` pa kapab envoke ankò nan pwen sa a
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;