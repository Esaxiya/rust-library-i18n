/// Vèsyon an nan operatè a apèl ki pran yon reseptè imuiabl.
///
/// Ka nan `Fn` ka rele repete san yo pa mitasyon eta a.
///
/// *trait (`Fn`) sa a pa dwe konfonn ak [function pointers] (`fn`).*
///
/// `Fn` se aplike otomatikman pa fèmti ki sèlman pran referans imuiabl nan varyab kaptire oswa pa pran anyen nan tout, menm jan tou (safe) [function pointers] (ak kèk opozisyon, al gade dokiman yo pou plis detay).
///
/// Anplis de sa, pou nenpòt ki kalite `F` ki aplike `Fn`, `&F` aplike `Fn`, tou.
///
/// Depi tou de [`FnMut`] ak [`FnOnce`] yo supèrtretit nan `Fn`, nenpòt egzanp nan `Fn` ka itilize kòm yon paramèt kote yon [`FnMut`] oswa [`FnOnce`] espere.
///
/// Sèvi ak `Fn` kòm yon mare lè ou vle aksepte yon paramèt nan kalite ki tankou fonksyon ak bezwen rele li repete ak san yo pa mitasyon eta (egzanp, lè w rele li an menm tan).
/// Si ou pa bezwen tankou kondisyon strik, sèvi ak [`FnMut`] oswa [`FnOnce`] kòm limit.
///
/// Gade [chapter on closures in *The Rust Programming Language*][book] la pou kèk plis enfòmasyon sou sijè sa a.
///
/// Epitou nan nòt se sentaks espesyal la pou `Fn` traits (egzanp
/// `Fn(usize, bool) -> usize`).Moun ki enterese nan detay teknik sa ka al gade [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Rele yon fèmti
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Sèvi ak yon paramèt `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // pou regex ka konte sou `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Fè operasyon an apèl.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Vèsyon an nan operatè a apèl ki pran yon reseptè mutable.
///
/// Ka nan `FnMut` ka rele repete epi yo ka mitasyon eta a.
///
/// `FnMut` se aplike otomatikman pa fèmti ki pran referans mityèl ak varyab kaptire, osi byen ke tout kalite ki aplike [`Fn`], egzanp, (safe) [function pointers] (depi `FnMut` se yon supertrait nan [`Fn`]).
/// Anplis de sa, pou nenpòt ki kalite `F` ki aplike `FnMut`, `&mut F` aplike `FnMut`, tou.
///
/// Depi [`FnOnce`] se yon supertrait nan `FnMut`, ka nenpòt egzanp nan `FnMut` dwe itilize kote yon [`FnOnce`] espere, e depi [`Fn`] se yon subtrait nan `FnMut`, nenpòt ki egzanp nan [`Fn`] ka itilize kote `FnMut` espere.
///
/// Sèvi ak `FnMut` kòm yon mare lè ou vle aksepte yon paramèt nan kalite fonksyon-tankou ak bezwen rele li repete, pandan y ap pèmèt li nan mitasyon eta a.
/// Si ou pa vle paramèt la mitasyon eta, sèvi ak [`Fn`] kòm yon mare;si ou pa bezwen rele li repete, sèvi ak [`FnOnce`].
///
/// Gade [chapter on closures in *The Rust Programming Language*][book] la pou kèk plis enfòmasyon sou sijè sa a.
///
/// Epitou nan nòt se sentaks espesyal la pou `Fn` traits (egzanp
/// `Fn(usize, bool) -> usize`).Moun ki enterese nan detay teknik sa ka al gade [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Rele yon fèmen mutably kaptire
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Sèvi ak yon paramèt `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // pou regex ka konte sou `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Fè operasyon an apèl.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Vèsyon an nan operatè a apèl ki pran yon reseptè pa-valè.
///
/// Ka nan `FnOnce` ka rele, men li pa ta ka rele plizyè fwa.Poutèt sa, si bagay la sèlman li te ye sou yon kalite se ke li aplike `FnOnce`, li ka rele sèlman yon fwa.
///
/// `FnOnce` se aplike otomatikman pa fèmen ki ta ka konsome varyab kaptire, osi byen ke tout kalite ki aplike [`FnMut`], egzanp, (safe) [function pointers] (depi `FnOnce` se yon supertrait nan [`FnMut`]).
///
///
/// Depi tou de [`Fn`] ak [`FnMut`] yo se subtraits nan `FnOnce`, nenpòt egzanp nan [`Fn`] oswa [`FnMut`] ka itilize kote yon `FnOnce` espere.
///
/// Sèvi ak `FnOnce` kòm yon mare lè ou vle aksepte yon paramèt nan kalite fonksyon-tankou epi sèlman bezwen rele li yon fwa.
/// Si ou bezwen rele paramèt la repete, sèvi ak [`FnMut`] kòm yon mare;si ou bezwen li tou pa mitasyon leta, sèvi ak [`Fn`].
///
/// Gade [chapter on closures in *The Rust Programming Language*][book] la pou kèk plis enfòmasyon sou sijè sa a.
///
/// Epitou nan nòt se sentaks espesyal la pou `Fn` traits (egzanp
/// `Fn(usize, bool) -> usize`).Moun ki enterese nan detay teknik sa ka al gade [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Sèvi ak yon paramèt `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` konsome varyab kaptire li yo, kidonk li pa ka kouri plis pase yon fwa.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Eseye envoke `func()` ankò ap voye yon erè `use of moved value` pou `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` pa kapab envoke ankò nan pwen sa a
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // pou regex ka konte sou `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Kalite a retounen apre yo fin itilize operatè a apèl.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Fè operasyon an apèl.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}