/// Itilize pou operasyon dereferansyabl imuiabl, tankou `*v`.
///
/// Anplis de sa ke yo te itilize pou operasyon eksplozif dereferencing ak operatè a (unary) `*` nan kontèks imuiabl, `Deref` se tou itilize enplisitman pa du a nan anpil sikonstans.
/// Mekanis sa a rele ['`Deref` coercion'][more].
/// Nan kontèks ki ka chanje, yo itilize [`DerefMut`].
///
/// Aplike `Deref` pou endikasyon entelijan fè aksè done yo dèyè yo pratik, ki se poukisa yo aplike `Deref`.
/// Nan lòt men an, règleman yo konsènan `Deref` ak [`DerefMut`] yo te fèt espesyalman pou akomode pwent entelijan.
/// Poutèt sa,**`Deref` ta dwe aplike sèlman pou endikasyon entelijan** pou evite konfizyon.
///
/// Pou rezon ki sanble,**sa a trait pa ta dwe janm febli**.Echèk pandan dereferencing ka trè konfizyon lè `Deref` envoke enplisitman.
///
/// # Plis sou kontrent `Deref`
///
/// Si `T` aplike `Deref<Target = U>`, ak `x` se yon valè de kalite `T`, lè sa a:
///
/// * Nan kontèks imuiabl, `*x` (kote `T` pa ni yon referans ni yon konsèy kri) ki ekivalan a `* Deref::deref(&x)`.
/// * Valè kalite `&T` yo fòse ak valè kalite `&U`
/// * `T` enplisitman aplike tout metòd yo (immutable) nan kalite `U` la.
///
/// Pou plis detay, vizite [the chapter in *The Rust Programming Language*][book] osi byen ke seksyon referans sou [the dereference operator][ref-deref-op], [method resolution] ak [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Yon struct ak yon jaden sèl ki aksesib pa dereferencing struct la.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Kalite a ki kapab lakòz apre dereferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferans valè a.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Itilize pou operasyon dereferansyasyon mitab, tankou nan `*v = 1;`.
///
/// Anplis de sa ke yo te itilize pou operasyon eksplozif dereferencing ak operatè a (unary) `*` nan kontèks mutabl, `DerefMut` se tou itilize enplisitman pa du a nan anpil sikonstans.
/// Mekanis sa a rele ['`Deref` coercion'][more].
/// Nan kontèks imuiabl, [`Deref`] yo itilize.
///
/// Aplike `DerefMut` pou endikasyon entelijan fè mitasyon done yo dèyè yo pratik, ki se poukisa yo aplike `DerefMut`.
/// Nan lòt men an, règleman yo konsènan [`Deref`] ak `DerefMut` yo te fèt espesyalman pou akomode pwent entelijan.
/// Poutèt sa,**`DerefMut` ta dwe aplike sèlman pou endikasyon entelijan** pou evite konfizyon.
///
/// Pou rezon ki sanble,**sa a trait pa ta dwe janm febli**.Echèk pandan dereferencing ka trè konfizyon lè `DerefMut` envoke enplisitman.
///
/// # Plis sou kontrent `Deref`
///
/// Si `T` aplike `DerefMut<Target = U>`, ak `x` se yon valè de kalite `T`, lè sa a:
///
/// * Nan kontèks ki ka chanje, `*x` (kote `T` pa ni yon referans ni yon konsèy kri) ekivalan a `* DerefMut::deref_mut(&mut x)`.
/// * Valè kalite `&mut T` yo fòse ak valè kalite `&mut U`
/// * `T` enplisitman aplike tout metòd yo (mutable) nan kalite `U` la.
///
/// Pou plis detay, vizite [the chapter in *The Rust Programming Language*][book] osi byen ke seksyon referans sou [the dereference operator][ref-deref-op], [method resolution] ak [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Yon struct ak yon jaden sèl ki se modifye pa dereferencing struct la.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Mityèlman dereferans valè an.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Endike ke yon struct ka itilize kòm yon reseptè metòd, san yo pa karakteristik nan `arbitrary_self_types`.
///
/// Sa a se aplike pa stdlib kalite konsèy tankou `Box<T>`, `Rc<T>`, `&T`, ak `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}