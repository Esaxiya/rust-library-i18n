/// Kòd Custom nan destriktè a.
///
/// Lè yon valè pa nesesè ankò, Rust pral kouri yon "destructor" sou valè sa a.
/// Fason ki pi komen ke yon valè pa nesesè ankò se lè li ale soti nan sijè ki abòde lan.Destriktè ka toujou kouri nan lòt sikonstans, men nou pral konsantre sou sijè ki abòde pou egzanp yo isit la.
/// Pou aprann sou kèk nan lòt ka sa yo, tanpri gade [the reference] seksyon sou destriktè.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Destriktè sa a konsiste de de eleman:
/// - Yon apèl nan `Drop::drop` pou valè sa a, si espesyal sa a `Drop` trait aplike pou kalite li yo.
/// - "drop glue" a otomatikman pwodwi ki rekursivman rele destriktè yo nan tout jaden ki gen valè sa a.
///
/// Kòm Rust otomatikman rele destriktè yo nan tout jaden ki genyen, ou pa bezwen aplike `Drop` nan pifò ka yo.
/// Men, gen kèk ka kote li itil, pou egzanp pou kalite ki dirèkteman jere yon resous.
/// Resous sa a ka memwa, li ka yon deskriptè dosye, li ka yon priz rezo.
/// Yon fwa ke yon valè de kalite sa a pa pral itilize, li ta dwe "clean up" resous li yo pa libere memwa a oswa fèmen dosye a oswa priz.
/// Sa a se travay la nan yon destriktè, ak Se poutèt sa travay la nan `Drop::drop`.
///
/// ## Examples
///
/// Pou wè destriktè nan aksyon, kite a pran yon gade nan pwogram sa a:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust pral premye rele `Drop::drop` pou `_x` ak Lè sa a, pou tou de `_x.one` ak `_x.two`, sa vle di ke kouri sa a pral enprime
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Menm si nou retire aplikasyon an nan `Drop` pou `HasTwoDrop`, destriktè yo nan jaden li yo yo toujou rele.
/// Sa a ta rezilta nan
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Ou pa ka rele `Drop::drop` tèt ou
///
/// Paske `Drop::drop` yo itilize pou netwaye yon valè, li ka danjere pou itilize valè sa a apre metòd la te rele.
/// Kòm `Drop::drop` pa pran an komen nan opinyon li yo, Rust anpeche move itilizasyon pa pèmèt ou rele `Drop::drop` dirèkteman.
///
/// Nan lòt mo, si ou te eseye klèman rele `Drop::drop` nan egzanp ki anwo a, ou ta jwenn yon erè du.
///
/// Si ou ta renmen klèman rele destriktè a nan yon valè, [`mem::drop`] ka itilize olye.
///
/// [`mem::drop`]: drop
///
/// ## Drop lòd
///
/// Kilès nan de `HasDrop` nou an gout premye, menm si?Pou structs, li nan lòd la menm ke yo ap deklare: premye `one`, Lè sa a, `two`.
/// Si ou ta renmen eseye sa a tèt ou, ou ka modifye `HasDrop` pi wo a genyen kèk done, tankou yon nonb antye relatif, ak Lè sa a, sèvi ak li nan `println!` a andedan nan `Drop`.
/// Konpòtman sa garanti lang lan.
///
/// Kontrèman ak pou structs, varyab lokal yo tonbe nan lòd ranvèse:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Sa a pral enprime
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Tanpri gade [the reference] pou règleman konplè yo.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` ak `Drop` yo san konte
///
/// Ou pa ka aplike tou de [`Copy`] ak `Drop` sou menm kalite a.Kalite ki se `Copy` jwenn enplisitman double pa du a, ki fè li trè difisil predi lè, ak konbyen fwa destriktè yo pral egzekite.
///
/// Kòm sa yo, kalite sa yo pa ka gen destriktè.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Egzekite destriktè a pou kalite sa a.
    ///
    /// Metòd sa a yo rele enplisitman lè valè a soti nan sijè ki abòde lan, epi yo pa ka rele li klèman (sa a se [E0040] erè du).
    /// Sepandan, yo ka itilize fonksyon [`mem::drop`] nan prelude pou rele aplikasyon `Drop` agiman an.
    ///
    /// Lè yo te rele metòd sa a, `self` poko te distribye.
    /// Sa sèlman rive apre metòd la fini.
    /// Si sa a pa t 'ka a, `self` ta dwe yon referans pendant.
    ///
    /// # Panics
    ///
    /// Etandone ke yon [`panic!`] pral rele `drop` jan li detant, nenpòt [`panic!`] nan yon aplikasyon `drop` ap gen chans pou avòtman.
    ///
    /// Remake byen ke menm si sa a panics, valè a konsidere yo dwe tonbe;
    /// ou pa dwe lakòz yo rele `drop` ankò.
    /// Sa a se nòmalman otomatikman okipe pa du a, men lè w ap itilize kòd danjere, ka pafwa rive envolontèman, patikilyèman lè w ap itilize [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}