use crate::marker::Unsize;

/// Trait ki endike ke sa a se yon konsèy oswa yon pakè pou yon sèl, kote redimensionman ka fèt sou pointee la.
///
/// Gade [DST coercion RFC][dst-coerce] ak [the nomicon entry on coercion][nomicon-coerce] pou plis detay.
///
/// Pou kalite konsèy entegre, endikasyon `T` ap fòse endikasyon `U` si `T: Unsize<U>` pa konvèti soti nan yon konsèy mens nan yon konsèy grès.
///
/// Pou kalite koutim, kontrent la isit la travay pa fòse `Foo<T>` `Foo<U>` bay yon impl nan `CoerceUnsized<Foo<U>> for Foo<T>` egziste.
/// Tankou yon impl ka ekri sèlman si `Foo<T>` gen sèlman yon sèl jaden ki pa phantomdata ki enplike `T`.
/// Si kalite jaden sa a se `Bar<T>`, yon aplikasyon `CoerceUnsized<Bar<U>> for Bar<T>` dwe egziste.
/// Kòse a ap travay pa fòse jaden an `Bar<T>` nan `Bar<U>` ak ranpli nan rès la nan jaden yo soti nan `Foo<T>` yo kreye yon `Foo<U>`.
/// Sa a pral efektivman fè egzèsis desann nan yon jaden konsèy ak contrainte sa.
///
/// Anjeneral, pou endikasyon entelijan ou pral aplike `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, ak yon si ou vle `?Sized` mare sou `T` tèt li.
/// Pou kalite pakè ki dirèkteman entegre `T` tankou `Cell<T>` ak `RefCell<T>`, ou ka dirèkteman aplike `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Sa a pral kite fòse nan kalite tankou `Cell<Box<T>>` travay.
///
/// [`Unsize`][unsize] se itilize yo ki make kalite ki ka kontrent DSTs si dèyè endikasyon.Li aplike otomatikman pa du a.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Sa a se itilize pou sekirite objè, yo tcheke ke kalite reseptè yon metòd la ka voye sou.
///
/// Yon egzanp aplikasyon nan trait la:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}