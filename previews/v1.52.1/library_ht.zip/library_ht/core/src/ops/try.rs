/// Yon trait pou Customize konpòtman operatè `?` la.
///
/// Yon kalite aplikasyon `Try` se youn ki gen yon fason kanonik pou wè li an tèm de yon dikotomi success/failure.
/// Sa a trait pèmèt tou de èkstraksyon sa yo valè siksè oswa echèk soti nan yon egzanp ki egziste deja ak kreye yon egzanp nouvo soti nan yon siksè oswa echèk valè.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ki kalite valè sa a lè yo wè li kòm siksè.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ki kalite valè sa a lè yo wè li kòm echwe.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Aplike operatè a "?".Yon retou nan `Ok(t)` vle di ke ekzekisyon an ta dwe kontinye nòmalman, ak rezilta a nan `?` se valè `t` la.
    /// Yon retou nan `Err(e)` vle di ke ekzekisyon yo ta dwe branch nan `catch` anndan anvlòp la, oswa retounen nan fonksyon an.
    ///
    /// Si yo retounen yon rezilta `Err(e)`, valè `e` la pral "wrapped" nan kalite retou sijè ki abòde lan (ki dwe aplike tèt li `Try`).
    ///
    /// Espesyalman, valè `X::from_error(From::from(e))` la retounen, kote `X` se kalite retou fonksyon ki fèmen a.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Vlope yon valè erè yo konstwi rezilta a konpoze.
    /// Pou egzanp, `Result::Err(x)` ak `Result::from_error(x)` yo ekivalan.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Vlope yon valè OK yo konstwi rezilta a konpoze.
    /// Pou egzanp, `Result::Ok(x)` ak `Result::from_ok(x)` yo ekivalan.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}