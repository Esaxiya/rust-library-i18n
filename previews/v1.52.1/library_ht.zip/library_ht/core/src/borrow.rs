//! Yon modil pou travay ak done prete.

#![stable(feature = "rust1", since = "1.0.0")]

/// Yon trait pou done prete.
///
/// Nan Rust, li komen pou bay reprezantasyon diferan nan yon kalite pou ka itilizasyon diferan.
/// Pou egzanp, kote depo ak jesyon pou yon valè yo ka espesyalman chwazi kòm apwopriye pou yon itilizasyon patikilye atravè kalite konsèy tankou [`Box<T>`] oswa [`Rc<T>`].
/// Beyond sa yo anbalaj jenerik ki ka itilize ak nenpòt ki kalite, kèk kalite bay aspè si ou vle bay fonctionnalités ki kapab koute chè.
/// Yon egzanp pou tankou yon kalite se [`String`] ki ajoute kapasite pou yon ekstansyon pou yon fisèl nan [`str`] debaz la.
/// Sa mande pou kenbe plis enfòmasyon nesesè pou yon senp, imuiabl fisèl.
///
/// Kalite sa yo bay aksè a done yo kache nan referans a ki kalite done sa yo.Yo di yo dwe 'prete kòm' ki kalite.
/// Pou egzanp, yon [`Box<T>`] ka prete kòm `T` pandan y ap yon [`String`] ka prete kòm `str`.
///
/// Kalite eksprime ke yo ka prete kòm kèk kalite `T` pa aplike `Borrow<T>`, bay yon referans a yon `T` nan metòd [`borrow`] trait la.Yon kalite se gratis prete kòm plizyè kalite diferan.
/// Si li vle mityèlman prete kòm kalite a-sa ki pèmèt done yo kache yo dwe modifye, li ka Anplis de sa aplike [`BorrowMut<T>`].
///
/// Pli lwen, lè yo bay aplikasyon pou traits adisyonèl, li bezwen yo dwe konsidere si yo ta dwe konpòte yo idantik ak sa yo ki nan kalite ki kache kòm yon konsekans aji kòm yon reprezantasyon nan ki kalite kache.
/// Kòd jenerik tipikman itilize `Borrow<T>` lè li konte sou konpòtman ki idantik nan aplikasyon sa yo trait adisyonèl.
/// traits sa yo ap sanble parèt tankou trait bounds anplis.
///
/// An patikilye `Eq`, `Ord` ak `Hash` dwe ekivalan pou valè prete ak posede: `x.borrow() == y.borrow()` ta dwe bay menm rezilta ak `x == y`.
///
/// Si kòd jenerik senpleman bezwen travay pou tout kalite ki ka bay yon referans a kalite ki gen rapò `T`, li se souvan pi bon yo sèvi ak [`AsRef<T>`] kòm plis kalite ka san danje aplike li.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Kòm yon koleksyon done, [`HashMap<K, V>`] posede tou de kle ak valè.Si aktyèl done kle a vlope nan yon kalite jere kèk kalite, li ta dwe, sepandan, toujou posib pou fè rechèch pou yon valè lè l sèvi avèk yon referans a done kle a.
/// Pou egzanp, si kle a se yon fisèl, Lè sa a, li gen anpil chans ki estoke ak kat la hash kòm yon [`String`], pandan ke li ta dwe posib nan rechèch lè l sèvi avèk yon [`&str`][`str`].
/// Se konsa, `insert` bezwen opere sou yon `String` pandan y ap `get` bezwen pou kapab sèvi ak yon `&str`.
///
/// Yon ti kras senplifye, pati ki enpòtan nan `HashMap<K, V>` sanble tankou sa a:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // jaden omisyon
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Kat jeyografik la tout antye se jenerik sou yon kalite kle `K`.Paske kle sa yo estoke ak kat hash la, kalite sa a dwe posede done kle a.
/// Lè ou mete yon pè kle-valè, yo bay kat la tankou yon `K` epi li bezwen jwenn bokit kòrèk la epi tcheke si kle a deja prezan ki baze sou `K` sa a.Se poutèt sa mande pou `K: Hash + Eq`.
///
/// Lè w ap chèche yon valè nan kat la, sepandan, li te bay yon referans a yon `K` kòm kle a pou fè rechèch pou ta mande pou toujou kreye tankou yon valè posede.
/// Pou kle fisèl, sa ta vle di yon valè `String` bezwen yo dwe kreye jis pou rechèch la pou ka kote sèlman yon `str` ki disponib.
///
/// Olye de sa, metòd `get` la jenerik sou kalite done kle ki kache yo, ki rele `Q` nan siyati metòd ki anwo a.Li deklare ke `K` prete kòm yon `Q` pa egzije sa `K: Borrow<Q>`.
/// Pa Anplis ki egzije `Q: Hash + Eq`, li siyal egzijans ki `K` ak `Q` gen aplikasyon nan `Hash` a ak `Eq` traits ki pwodwi rezilta ki idantik.
///
/// Aplikasyon an nan `get` depann an patikilye sou aplikasyon ki idantik nan `Hash` pa detèmine bokit hash kle a lè w rele `Hash::hash` sou valè a `Q` menm si li eleman kle a ki baze sou valè a hash kalkile soti nan valè a `K`.
///
///
/// Kòm yon konsekans, kat la hash kraze si yon `K` vlope yon valè `Q` pwodui yon hash diferan pase `Q`.Pou egzanp, imajine ou gen yon kalite ki vlope yon fisèl men konpare lèt ASCII inyore ka yo:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Paske de valè egal bezwen pwodwi menm valè a hash, aplikasyon an nan `Hash` bezwen inyore ASCII ka, tou:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Èske `CaseInsensitiveString` aplike `Borrow<str>`?Li sètènman ka bay yon referans a yon tranch fisèl atravè ki genyen fisèl posede li yo.
/// Men, paske aplikasyon `Hash` li yo diferan, li konpòte li diferan de `str` ak Se poutèt sa pa dwe, an reyalite, aplike `Borrow<str>`.
/// Si li vle pèmèt lòt moun aksè nan kache `str` la, li ka fè sa atravè `AsRef<str>` ki pa pote okenn kondisyon siplemantè.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Immutableman prete nan yon valè posede.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Yon trait pou done mityèlman prete.
///
/// Kòm yon konpayon [`Borrow<T>`] sa a trait pèmèt yon kalite prete kòm yon kalite kache pa bay yon referans mutable.
/// Gade [`Borrow<T>`] pou plis enfòmasyon sou prete kòm yon lòt kalite.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mityèlman prete nan yon valè posede.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}