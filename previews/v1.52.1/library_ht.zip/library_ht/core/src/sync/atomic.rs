//! Kalite atomik
//!
//! Kalite atomik bay kominikasyon primitif pataje-memwa ant fil, epi yo se blòk bilding lòt kalite konkouran yo.
//!
//! Modil sa a defini vèsyon atomik nan yon kantite chwazi nan kalite primitif, ki gen ladan [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], elatriye.
//! Kalite atomik prezante operasyon ki, lè yo itilize kòrèkteman, senkroniz dènye enfòmasyon ant fil yo.
//!
//! Chak metòd pran yon [`Ordering`] ki reprezante fòs baryè memwa pou operasyon sa.Kòmann sa yo se menm ak [C++20 atomic orderings][1] la.Pou plis enfòmasyon gade [nomicon][2] la.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Varyab atomik yo san danje yo pataje ant fil (yo aplike [`Sync`]) men yo pa bay tèt yo mekanis pou pataje epi swiv [threading model](../../../std/thread/index.html#the-threading-model) nan Rust.
//!
//! Fason ki pi komen yo pataje yon varyab atomik se mete l 'nan yon [`Arc`][arc] (yon konsèy atomik-referans-konte pataje).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Kalite atomik yo ka estoke nan varyab estatik, inisyalize lè l sèvi avèk inisyalizatè yo konstan tankou [`AtomicBool::new`].Statik atomik yo souvan itilize pou parese inisyalizasyon mondyal la.
//!
//! # Portability
//!
//! Tout kalite atomik nan modil sa a garanti yo dwe [lock-free] si yo disponib.Sa vle di yo pa intern jwenn yon mutex mondyal.Kalite atomik ak operasyon yo pa garanti yo dwe rete tann-gratis.
//! Sa vle di ke operasyon tankou `fetch_or` ka aplike ak yon bouk konpare-ak-swap.
//!
//! Operasyon atomik yo ka aplike nan kouch enstriksyon ak pi gwo gwosè atomik.Pou egzanp kèk tribin sèvi ak 4-byte enstriksyon atomik aplike `AtomicI8`.
//! Remake byen ke emulation sa a pa ta dwe gen yon enpak sou Correct nan kòd, li nan jis yon bagay yo dwe okouran de.
//!
//! Kalite atomik nan modil sa a pa ka disponib sou tout tribin yo.Kalite atomik yo isit la yo tout lajman disponib, sepandan, epi yo ka jeneralman konte sou ki deja egziste.Kèk eksepsyon remakab yo se:
//!
//! * PowerPC ak MIPS tribin ak 32-ti jan endikasyon pa gen kalite `AtomicU64` oswa `AtomicI64`.
//! * ARM platfòm tankou `armv5te` ki pa pou Linux sèlman bay operasyon `load` ak `store`, epi yo pa sipòte Konpare ak Boukante operasyon (CAS), tankou `swap`, `fetch_add`, elatriye.
//! Anplis de sa sou Linux, operasyon CAS sa yo aplike atravè [operating system support], ki ka vini ak yon penalite pèfòmans.
//! * ARM objektif ak `thumbv6m` sèlman bay operasyon `load` ak `store`, epi yo pa sipòte Konpare ak Boukante operasyon (CAS), tankou `swap`, `fetch_add`, elatriye.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Remake byen ke tribin future ka ajoute ke tou pa gen sipò pou kèk operasyon atomik.Kòd maksimòm pòtab pral vle fè atansyon sou ki kalite atomik yo te itilize.
//! `AtomicUsize` ak `AtomicIsize` yo jeneralman pi pòtab la, men menm lè sa a yo pa disponib toupatou.
//! Pou referans, bibliyotèk la `std` mande pou atomik ki menm gwosè ak konsèy, byenke `core` pa fè sa.
//!
//! Kounye a ou pral bezwen sèvi ak `#[cfg(target_arch)]` premyèman nan kondisyon konpile nan kòd ak atomik.Gen yon enstab `#[cfg(target_has_atomic)]` kòm byen ki ka estabilize nan future la.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Yon spinlock senp:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Rete tann pou lòt fil la lage seri a
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Kenbe yon konte mondyal nan fil ap viv:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Yon kalite boolean ki ka san danje pataje ant fil.
///
/// Kalite sa a gen menm reprezantasyon nan memwa tankou yon [`bool`].
///
/// **Remak**: Kalite sa a disponib sèlman sou tribin ki sipòte charj atomik ak magazen `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Kreye yon `AtomicBool` inisyalize nan `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Voye enplisitman aplike pou AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Yon kalite konsèy kri ki ka san danje pataje ant fil.
///
/// Kalite sa a gen menm reprezantasyon nan memwa tankou yon `*mut T`.
///
/// **Remak**: Kalite sa a disponib sèlman sou tribin ki sipòte charj atomik ak magazen endikasyon.
/// Gwosè li depann de gwosè konsèy sib la.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Kreye yon `AtomicPtr<T>` nil.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Kòmandman memwa atomik
///
/// Kòmann memwa presize fason operasyon atomik yo senkronize memwa.
/// Nan pi fèb [`Ordering::Relaxed`] li yo, se sèlman memwa a dirèkteman manyen pa operasyon an senkronize.
/// Nan lòt men an, yon pè magazen-chaj nan operasyon [`Ordering::SeqCst`] senkroniz lòt memwa pandan y ap Anplis de sa prezève yon lòd total de operasyon sa yo atravè tout fil.
///
///
/// Kòmannman memwa Rust yo se [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Pou plis enfòmasyon gade [nomicon] la.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Pa gen kontrent kòmann-nan, se sèlman operasyon atomik.
    ///
    /// Koresponn ak [`memory_order_relaxed`] nan C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Lè makonnen ak yon magazen, tout operasyon anvan yo te vin bay lòd anvan nenpòt chaj ki gen valè sa a ak [`Acquire`] (oswa pi fò) kòmann-nan.
    ///
    /// An patikilye, tout ekri anvan yo vin vizib nan tout fil ki fè yon chaj [`Acquire`] (oswa pi fò) ki gen valè sa a.
    ///
    /// Remake ke lè l sèvi avèk kòmann-nan sa a pou yon operasyon ki konbine charj ak magazen mennen nan yon operasyon chaj [`Relaxed`]!
    ///
    /// Kòmann sa a aplikab sèlman pou operasyon ki ka fè yon magazen.
    ///
    /// Koresponn ak [`memory_order_release`] nan C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Lè makonnen ak yon chaj, si valè a chaje te ekri pa yon operasyon magazen ak [`Release`] (oswa pi fò) kòmann-nan, Lè sa a, tout operasyon ki vin apre vin bay lòd apre magazen sa a.
    /// An patikilye, tout charj ki vin apre yo pral wè done ekri anvan magazen an.
    ///
    /// Remake ke lè l sèvi avèk kòmann-nan sa a pou yon operasyon ki konbine charj ak magazen mennen nan yon operasyon magazen [`Relaxed`]!
    ///
    /// Sa a kòmann-nan se sèlman aplikab pou operasyon ki ka fè yon chaj.
    ///
    /// Koresponn ak [`memory_order_acquire`] nan C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Gen efè tou de [`Acquire`] ak [`Release`] ansanm:
    /// Pou charj li itilize [`Acquire`] kòmann-nan.Pou magazen li itilize kòmann-nan [`Release`].
    ///
    /// Remake ke nan ka `compare_and_swap`, li posib ke operasyon an fini pa fè okenn magazen yo e pakonsekan li gen jis [`Acquire`] kòmann-nan.
    ///
    /// Sepandan, `AcqRel` pap janm fè aksè [`Relaxed`].
    ///
    /// Sa a kòmann-nan se sèlman aplikab pou operasyon ki konbine tou de charj ak magazen yo.
    ///
    /// Koresponn ak [`memory_order_acq_rel`] nan C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Tankou [`Acquire`]/[`Release`]/[`AcqRel`](pou chaj, magazen, ak operasyon chaj-ak-magazen, respektivman) ak garanti a adisyonèl ke tout fil wè tout operasyon sekans ki konsistan nan menm lòd la .
    ///
    ///
    /// Koresponn ak [`memory_order_seq_cst`] nan C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Yon [`AtomicBool`] inisyalize nan `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Kreye yon nouvo `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Retounen yon referans mutable nan kache [`bool`] la.
    ///
    /// Sa a san danje paske referans a mutable garanti ke pa gen okenn lòt fil yo anmenmtan aksè done atomik yo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SEKIRITE: referans a mutable garanti an komen inik.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Jwenn aksè atomik nan yon `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SEKIRITE: referans a mutable garanti an komen inik, ak
        // aliyman nan tou de `bool` ak `Self` se 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Konsome atomik la epi retounen valè ki genyen an.
    ///
    /// Sa a san danje paske pase `self` pa valè garanti ke pa gen okenn lòt fil yo anmenmtan aksè done atomik yo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Chaj yon valè ki soti nan bool la.
    ///
    /// `load` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.
    /// Valè posib yo se [`SeqCst`], [`Acquire`] ak [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics si `order` se [`Release`] oswa [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SEKIRITE: nenpòt ras done yo anpeche pa atomik intrinsèques ak anvan tout koreksyon an
        // konsèy pase nan valab paske nou te resevwa li nan yon referans.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Magazen yon valè nan bool la.
    ///
    /// `store` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.
    /// Valè posib yo se [`SeqCst`], [`Release`] ak [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics si `order` se [`Acquire`] oswa [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SEKIRITE: nenpòt ras done yo anpeche pa atomik intrinsèques ak anvan tout koreksyon an
        // konsèy pase nan valab paske nou te resevwa li nan yon referans.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Magazen yon valè nan bool a, retounen valè anvan an.
    ///
    /// `swap` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
    /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
    ///
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Magazen yon valè nan [`bool`] la si valè aktyèl la se menm bagay la kòm valè `current` la.
    ///
    /// Valè a retounen se toujou valè a anvan yo.Si li egal a `current`, Lè sa a, valè a te mete ajou.
    ///
    /// `compare_and_swap` tou pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.
    /// Remake ke menm lè w ap itilize [`AcqRel`], operasyon an ta ka febli yo e pakonsekan jis fè yon chaj `Acquire`, men se pa gen `Release` semantik.
    /// Sèvi ak [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`] si li rive, ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou `u8`.
    ///
    /// # Migrasyon nan `compare_exchange` ak `compare_exchange_weak`
    ///
    /// `compare_and_swap` ki ekivalan a `compare_exchange` ak kat sa a pou lòd memwa:
    ///
    /// Orijinal |Siksè |Echèk
    /// -------- | ------- | -------
    /// Rilaks |Rilaks |Dekontrakte Akeri |Jwenn |Jwenn Release |Lage |Detann AcqRel |AcqRel |Jwenn SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` pèmèt yo echwe spuriously menm lè konparezon an reyisi, ki pèmèt du a jenere pi bon kòd asanble lè yo konpare a ak swap yo itilize nan yon bouk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Magazen yon valè nan [`bool`] la si valè aktyèl la se menm bagay la kòm valè `current` la.
    ///
    /// Valè retou a se yon rezilta ki endike si nouvo valè a te ekri epi ki gen valè anvan an.
    /// Sou siksè sa a valè garanti yo dwe egal a `current`.
    ///
    /// `compare_exchange` pran de agiman [`Ordering`] pou dekri kòmann-nan memwa nan operasyon sa a.
    /// `success` dekri kòmann-nan obligatwa pou operasyon an li-modifye-ekri ki pran plas si konparezon a ak `current` reyisi.
    /// `failure` dekri kòmann-nan obligatwa pou operasyon an chaj ki pran plas lè konparezon an echwe.
    /// Sèvi ak [`Acquire`] kòm siksè kòmann-nan fè pati magazen an nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè siksè chay la [`Relaxed`].
    ///
    /// Echèk kòmann-nan kapab sèlman [`SeqCst`], [`Acquire`] oswa [`Relaxed`] epi yo dwe ekivalan a oswa pi fèb pase kòmann-nan siksè.
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Magazen yon valè nan [`bool`] la si valè aktyèl la se menm bagay la kòm valè `current` la.
    ///
    /// Kontrèman ak [`AtomicBool::compare_exchange`], fonksyon sa a pèmèt yo spuriously echwe menm lè konparezon an reyisi, sa ki ka rezilta nan kòd pi efikas sou kèk tribin.
    ///
    /// Valè retou a se yon rezilta ki endike si nouvo valè a te ekri epi ki gen valè anvan an.
    ///
    /// `compare_exchange_weak` pran de agiman [`Ordering`] pou dekri kòmann-nan memwa nan operasyon sa a.
    /// `success` dekri kòmann-nan obligatwa pou operasyon an li-modifye-ekri ki pran plas si konparezon a ak `current` reyisi.
    /// `failure` dekri kòmann-nan obligatwa pou operasyon an chaj ki pran plas lè konparezon an echwe.
    /// Sèvi ak [`Acquire`] kòm siksè kòmann-nan fè pati magazen an nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè siksè chay la [`Relaxed`].
    /// Echèk kòmann-nan kapab sèlman [`SeqCst`], [`Acquire`] oswa [`Relaxed`] epi yo dwe ekivalan a oswa pi fèb pase kòmann-nan siksè.
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Lojik "and" ak yon valè boolean.
    ///
    /// Fè yon operasyon lojik "and" sou valè aktyèl la ak agiman `val` la, epi li mete nouvo valè a nan rezilta a.
    ///
    /// Retounen valè anvan an.
    ///
    /// `fetch_and` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
    /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
    ///
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Lojik "nand" ak yon valè boolean.
    ///
    /// Fè yon operasyon lojik "nand" sou valè aktyèl la ak agiman `val` la, epi li mete nouvo valè a nan rezilta a.
    ///
    /// Retounen valè anvan an.
    ///
    /// `fetch_nand` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
    /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
    ///
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Nou pa ka itilize atomic_nand isit la paske li ka lakòz yon bool ak yon valè envalid.
        // Sa rive paske se operasyon atomik la fè ak yon nonb antye relatif 8-ti jan intern, ki ta mete anwo 7 Bits yo.
        //
        // Se konsa, nou jis itilize fetch_xor oswa swap olye.
        if val {
            // ! (x&vre)== !x Nou dwe ranvèse bool la.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&fo)==vre Nou dwe mete bool la vre.
            //
            self.swap(true, order)
        }
    }

    /// Lojik "or" ak yon valè boolean.
    ///
    /// Fè yon operasyon lojik "or" sou valè aktyèl la ak agiman `val` la, epi li mete nouvo valè a nan rezilta a.
    ///
    /// Retounen valè anvan an.
    ///
    /// `fetch_or` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
    /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
    ///
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Lojik "xor" ak yon valè boolean.
    ///
    /// Fè yon operasyon lojik "xor" sou valè aktyèl la ak agiman `val` la, epi li mete nouvo valè a nan rezilta a.
    ///
    /// Retounen valè anvan an.
    ///
    /// `fetch_xor` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
    /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
    ///
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Retounen yon konsèy mutable nan kache [`bool`] la.
    ///
    /// Lè w fè lekti ki pa atomik ak ekri sou nonb antye relatif la ki kapab lakòz yon ras done.
    /// Metòd sa a sitou itil pou FFI, kote siyati fonksyon an ka itilize `*mut bool` olye de `&AtomicBool`.
    ///
    /// Retounen yon konsèy `*mut` ki sòti nan yon referans pataje atomik sa a san danje paske kalite atomik yo travay avèk mutabilite enteryè.
    /// Tout modifikasyon nan yon atomik chanje valè a atravè yon referans pataje, epi yo ka fè sa san danje osi lontan ke yo itilize operasyon atomik.
    /// Nenpòt itilizasyon konsèy la retounen anvan tout koreksyon mande pou yon blòk `unsafe` epi li toujou gen defann restriksyon an menm: operasyon sou li dwe atomik.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Fetches valè a, epi aplike yon fonksyon nan li ki retounen yon opsyonèl nouvo valè.Retounen yon `Result` nan `Ok(previous_value)` si fonksyon an retounen `Some(_)`, lòt moun `Err(previous_value)`.
    ///
    /// Note: Sa a ka rele fonksyon an plizyè fwa si valè a te chanje soti nan lòt fil nan entre-temps la, osi lontan ke fonksyon an retounen `Some(_)`, men yo pral fonksyon an yo te aplike yon sèl fwa nan valè a ki estoke.
    ///
    ///
    /// `fetch_update` pran de agiman [`Ordering`] pou dekri kòmann-nan memwa nan operasyon sa a.
    /// Premye a dekri kòmann-nan obligatwa pou lè operasyon an finalman reyisi pandan ke dezyèm lan dekri kòmann-nan obligatwa pou charj.
    /// Sa yo koresponn ak siksè ak echèk kòmandman yo nan [`AtomicBool::compare_exchange`] respektivman.
    ///
    /// Sèvi ak [`Acquire`] kòm siksè kòmann-nan fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè final la [`Relaxed`] chaj siksè.
    /// Kòmann nan chaj (failed) ka sèlman [`SeqCst`], [`Acquire`] oswa [`Relaxed`] epi yo dwe ekivalan a oswa pi fèb pase kòmann-nan siksè.
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Kreye yon nouvo `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Retounen yon referans mutable nan konsèy ki kache.
    ///
    /// Sa a san danje paske referans a mutable garanti ke pa gen okenn lòt fil yo anmenmtan aksè done atomik yo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Jwenn aksè atomik nan yon konsèy.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - referans a mutabl garanti an komen inik.
        //  - aliyman an nan `*mut T` ak `Self` se menm bagay la sou tout tribin sipòte pa rust, jan yo verifye pi wo a.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Konsome atomik la epi retounen valè ki genyen an.
    ///
    /// Sa a san danje paske pase `self` pa valè garanti ke pa gen okenn lòt fil yo anmenmtan aksè done atomik yo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Chaj yon valè soti nan konsèy la.
    ///
    /// `load` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.
    /// Valè posib yo se [`SeqCst`], [`Acquire`] ak [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics si `order` se [`Release`] oswa [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Magazen yon valè nan konsèy la.
    ///
    /// `store` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.
    /// Valè posib yo se [`SeqCst`], [`Release`] ak [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics si `order` se [`Acquire`] oswa [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Magazen yon valè nan konsèy la, retounen valè anvan an.
    ///
    /// `swap` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
    /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
    ///
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou endikasyon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Estoke yon valè nan konsèy la si valè aktyèl la se menm bagay la kòm valè `current` la.
    ///
    /// Valè a retounen se toujou valè a anvan yo.Si li egal a `current`, Lè sa a, valè a te mete ajou.
    ///
    /// `compare_and_swap` tou pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.
    /// Remake ke menm lè w ap itilize [`AcqRel`], operasyon an ta ka febli yo e pakonsekan jis fè yon chaj `Acquire`, men se pa gen `Release` semantik.
    /// Sèvi ak [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`] si li rive, ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou endikasyon.
    ///
    /// # Migrasyon nan `compare_exchange` ak `compare_exchange_weak`
    ///
    /// `compare_and_swap` ki ekivalan a `compare_exchange` ak kat sa a pou lòd memwa:
    ///
    /// Orijinal |Siksè |Echèk
    /// -------- | ------- | -------
    /// Rilaks |Rilaks |Dekontrakte Akeri |Jwenn |Jwenn Release |Lage |Detann AcqRel |AcqRel |Jwenn SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` pèmèt yo echwe spuriously menm lè konparezon an reyisi, ki pèmèt du a jenere pi bon kòd asanble lè yo konpare a ak swap yo itilize nan yon bouk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Estoke yon valè nan konsèy la si valè aktyèl la se menm bagay la kòm valè `current` la.
    ///
    /// Valè retou a se yon rezilta ki endike si nouvo valè a te ekri epi ki gen valè anvan an.
    /// Sou siksè sa a valè garanti yo dwe egal a `current`.
    ///
    /// `compare_exchange` pran de agiman [`Ordering`] pou dekri kòmann-nan memwa nan operasyon sa a.
    /// `success` dekri kòmann-nan obligatwa pou operasyon an li-modifye-ekri ki pran plas si konparezon a ak `current` reyisi.
    /// `failure` dekri kòmann-nan obligatwa pou operasyon an chaj ki pran plas lè konparezon an echwe.
    /// Sèvi ak [`Acquire`] kòm siksè kòmann-nan fè pati magazen an nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè siksè chay la [`Relaxed`].
    ///
    /// Echèk kòmann-nan kapab sèlman [`SeqCst`], [`Acquire`] oswa [`Relaxed`] epi yo dwe ekivalan a oswa pi fèb pase kòmann-nan siksè.
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou endikasyon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Estoke yon valè nan konsèy la si valè aktyèl la se menm bagay la kòm valè `current` la.
    ///
    /// Kontrèman ak [`AtomicPtr::compare_exchange`], fonksyon sa a pèmèt yo spuriously echwe menm lè konparezon an reyisi, sa ki ka rezilta nan kòd pi efikas sou kèk tribin.
    ///
    /// Valè retou a se yon rezilta ki endike si nouvo valè a te ekri epi ki gen valè anvan an.
    ///
    /// `compare_exchange_weak` pran de agiman [`Ordering`] pou dekri kòmann-nan memwa nan operasyon sa a.
    /// `success` dekri kòmann-nan obligatwa pou operasyon an li-modifye-ekri ki pran plas si konparezon a ak `current` reyisi.
    /// `failure` dekri kòmann-nan obligatwa pou operasyon an chaj ki pran plas lè konparezon an echwe.
    /// Sèvi ak [`Acquire`] kòm siksè kòmann-nan fè pati magazen an nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè siksè chay la [`Relaxed`].
    /// Echèk kòmann-nan kapab sèlman [`SeqCst`], [`Acquire`] oswa [`Relaxed`] epi yo dwe ekivalan a oswa pi fèb pase kòmann-nan siksè.
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou endikasyon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SEKIRITE: Sa a intrinsèques se danjere paske li opere sou yon konsèy anvan tout koreksyon
        // men nou konnen pou asire w ke konsèy la valab (nou jis te resevwa li nan yon `UnsafeCell` ke nou gen pa referans) ak operasyon atomik nan tèt li pèmèt nou san danje mitasyon sa ki `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Fetches valè a, epi aplike yon fonksyon nan li ki retounen yon opsyonèl nouvo valè.Retounen yon `Result` nan `Ok(previous_value)` si fonksyon an retounen `Some(_)`, lòt moun `Err(previous_value)`.
    ///
    /// Note: Sa a ka rele fonksyon an plizyè fwa si valè a te chanje soti nan lòt fil nan entre-temps la, osi lontan ke fonksyon an retounen `Some(_)`, men yo pral fonksyon an yo te aplike yon sèl fwa nan valè a ki estoke.
    ///
    ///
    /// `fetch_update` pran de agiman [`Ordering`] pou dekri kòmann-nan memwa nan operasyon sa a.
    /// Premye a dekri kòmann-nan obligatwa pou lè operasyon an finalman reyisi pandan ke dezyèm lan dekri kòmann-nan obligatwa pou charj.
    /// Sa yo koresponn ak siksè ak echèk kòmandman yo nan [`AtomicPtr::compare_exchange`] respektivman.
    ///
    /// Sèvi ak [`Acquire`] kòm siksè kòmann-nan fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè final la [`Relaxed`] chaj siksè.
    /// Kòmann nan chaj (failed) ka sèlman [`SeqCst`], [`Acquire`] oswa [`Relaxed`] epi yo dwe ekivalan a oswa pi fèb pase kòmann-nan siksè.
    ///
    /// **Note:** Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou endikasyon.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Konvèti yon `bool` nan yon `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Macro sa a fini ke yo pa itilize sou kèk achitekti.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Yon kalite antye ki ka san danje pataje ant fil.
        ///
        /// Kalite sa a gen menm reprezantasyon nan memwa ak kalite antye ki kache, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Pou plis enfòmasyon sou diferans ki genyen ant kalite atomik ak kalite ki pa atomik kòm byen ke enfòmasyon sou Transparans nan kalite sa a, tanpri al gade [module-level documentation] la.
        ///
        ///
        /// **Note:** Kalite sa a disponib sèlman sou tribin ki sipòte charj atomik ak magazen nan [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Yon nonb antye relatif atomik inisyalize a `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Voye enplisitman aplike.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Kreye yon nouvo nonb antye relatif atomik.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Retounen yon referans ki ka chanje nan nonb antye relatif la kache.
            ///
            /// Sa a san danje paske referans a mutable garanti ke pa gen okenn lòt fil yo anmenmtan aksè done atomik yo.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// kite mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - referans a mutabl garanti an komen inik.
                //  - aliyman nan `$int_type` ak `Self` se menm bagay la, jan yo te pwomèt pa $cfg_align ak verifye pi wo a.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Konsome atomik la epi retounen valè ki genyen an.
            ///
            /// Sa a san danje paske pase `self` pa valè garanti ke pa gen okenn lòt fil yo anmenmtan aksè done atomik yo.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Chaj yon valè ki soti nan nonb antye relatif atomik la.
            ///
            /// `load` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.
            /// Valè posib yo se [`SeqCst`], [`Acquire`] ak [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics si `order` se [`Release`] oswa [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Estoke yon valè nan nonb antye relatif atomik la.
            ///
            /// `store` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.
            ///  Valè posib yo se [`SeqCst`], [`Release`] ak [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics si `order` se [`Acquire`] oswa [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Estoke yon valè nan nonb antye relatif atomik la, retounen valè anvan an.
            ///
            /// `swap` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
            /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Estoke yon valè nan nonb antye relatif la atomik si valè aktyèl la se menm bagay la kòm valè a `current`.
            ///
            /// Valè a retounen se toujou valè a anvan yo.Si li egal a `current`, Lè sa a, valè a te mete ajou.
            ///
            /// `compare_and_swap` tou pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.
            /// Remake ke menm lè w ap itilize [`AcqRel`], operasyon an ta ka febli yo e pakonsekan jis fè yon chaj `Acquire`, men se pa gen `Release` semantik.
            ///
            /// Sèvi ak [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`] si li rive, ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrasyon nan `compare_exchange` ak `compare_exchange_weak`
            ///
            /// `compare_and_swap` ki ekivalan a `compare_exchange` ak kat sa a pou lòd memwa:
            ///
            /// Orijinal |Siksè |Echèk
            /// -------- | ------- | -------
            /// Rilaks |Rilaks |Dekontrakte Akeri |Jwenn |Jwenn Release |Lage |Detann AcqRel |AcqRel |Jwenn SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` pèmèt yo echwe spuriously menm lè konparezon an reyisi, ki pèmèt du a jenere pi bon kòd asanble lè yo konpare a ak swap yo itilize nan yon bouk.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Estoke yon valè nan nonb antye relatif la atomik si valè aktyèl la se menm bagay la kòm valè a `current`.
            ///
            /// Valè retou a se yon rezilta ki endike si nouvo valè a te ekri epi ki gen valè anvan an.
            /// Sou siksè sa a valè garanti yo dwe egal a `current`.
            ///
            /// `compare_exchange` pran de agiman [`Ordering`] pou dekri kòmann-nan memwa nan operasyon sa a.
            /// `success` dekri kòmann-nan obligatwa pou operasyon an li-modifye-ekri ki pran plas si konparezon a ak `current` reyisi.
            /// `failure` dekri kòmann-nan obligatwa pou operasyon an chaj ki pran plas lè konparezon an echwe.
            /// Sèvi ak [`Acquire`] kòm siksè kòmann-nan fè pati magazen an nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè siksè chay la [`Relaxed`].
            ///
            /// Echèk kòmann-nan kapab sèlman [`SeqCst`], [`Acquire`] oswa [`Relaxed`] epi yo dwe ekivalan a oswa pi fèb pase kòmann-nan siksè.
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Estoke yon valè nan nonb antye relatif la atomik si valè aktyèl la se menm bagay la kòm valè a `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// fonksyon sa a pèmèt yo spuriously echwe menm lè konparezon an reyisi, sa ki ka rezilta nan kòd pi efikas sou kèk tribin.
            /// Valè retou a se yon rezilta ki endike si nouvo valè a te ekri epi ki gen valè anvan an.
            ///
            /// `compare_exchange_weak` pran de agiman [`Ordering`] pou dekri kòmann-nan memwa nan operasyon sa a.
            /// `success` dekri kòmann-nan obligatwa pou operasyon an li-modifye-ekri ki pran plas si konparezon a ak `current` reyisi.
            /// `failure` dekri kòmann-nan obligatwa pou operasyon an chaj ki pran plas lè konparezon an echwe.
            /// Sèvi ak [`Acquire`] kòm siksè kòmann-nan fè pati magazen an nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè siksè chay la [`Relaxed`].
            ///
            /// Echèk kòmann-nan kapab sèlman [`SeqCst`], [`Acquire`] oswa [`Relaxed`] epi yo dwe ekivalan a oswa pi fèb pase kòmann-nan siksè.
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// kite mut fin vye granmoun= val.load(Ordering::Relaxed);
            /// bouk {kite nouvo=ansyen * 2;
            ///     matche ak val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Ajoute valè aktyèl la, retounen valè anvan an.
            ///
            /// Operasyon sa a vlope toutotou sou debòde.
            ///
            /// `fetch_add` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
            /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Soustrè nan valè aktyèl la, retounen valè anvan an.
            ///
            /// Operasyon sa a vlope toutotou sou debòde.
            ///
            /// `fetch_sub` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
            /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" ak valè aktyèl la.
            ///
            /// Fè yon operasyon "and" bitwise sou valè aktyèl la ak agiman `val` a, epi li mete nouvo valè a nan rezilta a.
            ///
            /// Retounen valè anvan an.
            ///
            /// `fetch_and` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
            /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" ak valè aktyèl la.
            ///
            /// Fè yon operasyon "nand" bitwise sou valè aktyèl la ak agiman `val` a, epi li mete nouvo valè a nan rezilta a.
            ///
            /// Retounen valè anvan an.
            ///
            /// `fetch_nand` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
            /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" ak valè aktyèl la.
            ///
            /// Fè yon operasyon "or" bitwise sou valè aktyèl la ak agiman `val` a, epi li mete nouvo valè a nan rezilta a.
            ///
            /// Retounen valè anvan an.
            ///
            /// `fetch_or` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
            /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" ak valè aktyèl la.
            ///
            /// Fè yon operasyon "xor" bitwise sou valè aktyèl la ak agiman `val` a, epi li mete nouvo valè a nan rezilta a.
            ///
            /// Retounen valè anvan an.
            ///
            /// `fetch_xor` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
            /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Fetches valè a, epi aplike yon fonksyon nan li ki retounen yon opsyonèl nouvo valè.Retounen yon `Result` nan `Ok(previous_value)` si fonksyon an retounen `Some(_)`, lòt moun `Err(previous_value)`.
            ///
            /// Note: Sa a ka rele fonksyon an plizyè fwa si valè a te chanje soti nan lòt fil nan entre-temps la, osi lontan ke fonksyon an retounen `Some(_)`, men yo pral fonksyon an yo te aplike yon sèl fwa nan valè a ki estoke.
            ///
            ///
            /// `fetch_update` pran de agiman [`Ordering`] pou dekri kòmann-nan memwa nan operasyon sa a.
            /// Premye a dekri kòmann-nan obligatwa pou lè operasyon an finalman reyisi pandan ke dezyèm lan dekri kòmann-nan obligatwa pou charj.Sa yo koresponn ak siksè ak echèk lòd nan
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Sèvi ak [`Acquire`] kòm siksè kòmann-nan fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè final la [`Relaxed`] chaj siksè.
            /// Kòmann nan chaj (failed) ka sèlman [`SeqCst`], [`Acquire`] oswa [`Relaxed`] epi yo dwe ekivalan a oswa pi fèb pase kòmann-nan siksè.
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Lòd: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Lòd: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maksimòm ak valè aktyèl la.
            ///
            /// Jwenn maksimòm valè aktyèl la ak agiman `val`, epi li mete nouvo valè a nan rezilta a.
            ///
            /// Retounen valè anvan an.
            ///
            /// `fetch_max` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
            /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// kite ba=42;
            /// kite max_foo=foo.fetch_max (ba, Ordering::SeqCst).max(bar);
            /// afime! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimòm ak valè aktyèl la.
            ///
            /// Jwenn minimòm valè aktyèl la ak agiman `val`, epi li mete nouvo valè a nan rezilta a.
            ///
            /// Retounen valè anvan an.
            ///
            /// `fetch_min` pran yon agiman [`Ordering`] ki dekri kòmann-nan memwa nan operasyon sa a.Tout mòd kòmann yo posib.
            /// Remake byen ke lè l sèvi avèk [`Acquire`] fè magazen an pati nan operasyon sa a [`Relaxed`], ak lè l sèvi avèk [`Release`] fè pati nan chaj [`Relaxed`].
            ///
            ///
            /// **Remak**: Metòd sa a disponib sèlman sou tribin ki sipòte operasyon atomik sou yo
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// kite ba=12;
            /// kite min_foo=foo.fetch_min (ba, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SEKIRITE: ras done yo anpeche pa intrinsèques atomik.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Retounen yon konsèy mutable nan nonb antye relatif la kache.
            ///
            /// Lè w fè lekti ki pa atomik ak ekri sou nonb antye relatif la ki kapab lakòz yon ras done.
            /// Metòd sa a sitou itil pou FFI, kote siyati fonksyon an ka itilize
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Retounen yon konsèy `*mut` ki sòti nan yon referans pataje atomik sa a san danje paske kalite atomik yo travay avèk mutabilite enteryè.
            /// Tout modifikasyon nan yon atomik chanje valè a atravè yon referans pataje, epi yo ka fè sa san danje osi lontan ke yo itilize operasyon atomik.
            /// Nenpòt itilizasyon konsèy la retounen anvan tout koreksyon mande pou yon blòk `unsafe` epi li toujou gen defann restriksyon an menm: operasyon sou li dwe atomik.
            ///
            ///
            /// # Examples
            ///
            /// "" inyore (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ekstèn "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SEKIRITE: Safe osi lontan ke `my_atomic_op` se atomik.
            /// ensekirite {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Retounen valè anvan an (tankou __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Retounen valè anvan an (tankou __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// retounen valè max la (siyen konparezon)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// retounen valè min (siyen konparezon)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// retounen valè a max (konparezon siyen)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// retounen valè min (konparezon siyen)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Yon kloti atomik.
///
/// Tou depan de lòd la espesifye, yon kloti anpeche du a ak CPU soti nan reòdone sèten kalite operasyon memwa bò kote l '.
/// Sa kreye senkroniz-ak relasyon ant li ak operasyon atomik oswa kloti nan lòt fil.
///
/// Yon kloti 'A' ki gen (omwen) [`Release`] kòmann-nan semantik, senkroniz ak yon kloti 'B' ak (omwen) [`Acquire`] semantik, si epi sèlman si gen operasyon X ak Y, tou de opere sou kèk 'M' objè atomik tankou ke A se sekans anvan X, Y se senkronize anvan B ak Y obsève chanjman nan M.
/// Sa a bay yon k ap pase-anvan depandans ant A ak B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Operasyon atomik ak [`Release`] oswa [`Acquire`] semantik kapab tou senkroniz ak yon kloti.
///
/// Yon kloti ki gen [`SeqCst`] kòmann-nan, nan adisyon a gen tou de [`Acquire`] ak [`Release`] semantik, patisipe nan lòd nan pwogram mondyal nan lòt operasyon yo [`SeqCst`] ak/oswa kloti.
///
/// Aksepte [`Acquire`], [`Release`], [`AcqRel`] ak [`SeqCst`] kòmann-nan.
///
/// # Panics
///
/// Panics si `order` se [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Yon eksklizyon mityèl primitif ki baze sou spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Rete tann jiskaske valè a fin vye granmoun se `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Kloti sa a senkroniz-ak magazen nan `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SEKIRITE: lè l sèvi avèk yon kloti atomik san danje.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Yon kloti memwa du.
///
/// `compiler_fence` pa emèt okenn kòd machin, men mete restriksyon sou kalite memwa yo re-kòmande du a pèmèt yo fè.Espesyalman, tou depann de semantik [`Ordering`] yo bay la, yo ka anpeche du a soti nan deplase li oswa ekri depi anvan oswa apre apèl la nan lòt bò a nan apèl la `compiler_fence`.Remake byen ke li **pa** anpeche *pyès ki nan konpitè* nan fè tankou re-kòmann-nan.
///
/// Sa a se pa yon pwoblèm nan yon sèl-Threaded, kontèks ekzekisyon, men lè lòt fil ka modifye memwa an menm tan an, pi fò primitif senkronizasyon tankou [`fence`] yo mande yo.
///
/// Re-kòmann-nan anpeche pa semantik la kòmann-nan diferan yo se:
///
///  - ak [`SeqCst`], pa gen okenn re-kòmann-nan li ak ekri atravè pwen sa a pèmèt.
///  - ak [`Release`], li anvan ak ekri pa ka deplase sot pase ekri ki vin apre.
///  - ak [`Acquire`], li ki vin apre ak ekri pa ka deplase devan yo nan li anvan yo.
///  - ak [`AcqRel`], tou de nan règleman ki anwo yo ranfòse.
///
/// `compiler_fence` se jeneralman sèlman itil pou anpeche yon fil soti nan kous *ak tèt li*.Sa vle di, si yon fil bay egzekite yon sèl moso nan kòd, epi li Lè sa a, koupe, ak kòmanse egzekite kòd yon lòt kote (pandan y ap toujou nan menm fil la, ak concept toujou sou menm nwayo a).Nan pwogram tradisyonèl yo, sa ka fèt sèlman lè yo anrejistre yon moun k ap okipe siyal.
/// Nan plis kòd ki ba nivo, sitiyasyon sa yo ka leve tou lè yo manyen entèwonp, lè y ap aplike fil vèt ak pre-emption, elatriye.
/// Lektè kirye yo ankouraje li diskisyon Linux Kernel la nan [memory barriers].
///
/// # Panics
///
/// Panics si `order` se [`Relaxed`].
///
/// # Examples
///
/// San `compiler_fence`, `assert_eq!` nan kòd sa yo *pa* garanti yo reyisi, malgre tout bagay k ap pase nan yon fil sèl.
/// Pou wè poukisa, sonje ke du a gratis swap magazen yo nan `IMPORTANT_VARIABLE` ak `IS_READ` depi yo tou de `Ordering::Relaxed`.Si li fè sa, epi moun k ap okipe siyal la envoke touswit aprè `IS_READY` mete ajou, lè sa a moun k ap okipe siyal la pral wè `IS_READY=1`, men `IMPORTANT_VARIABLE=0`.
/// Sèvi ak yon `compiler_fence` remèd sitiyasyon sa a.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // anpeche ekri pi bonè yo te deplase pi lwen pase pwen sa a
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SEKIRITE: lè l sèvi avèk yon kloti atomik san danje.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Siyal processeur a ke li se andedan yon okipe-rete tann vire-bouk ("vire fèmen").
///
/// Fonksyon sa a obsolèt an favè [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}