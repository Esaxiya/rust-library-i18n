#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Yon future reprezante yon kalkil asenkron.
///
/// Yon future se yon valè ki ka pa fini enfòmatik ankò.
/// Sa a kalite "asynchronous value" fè li posib pou yon fil kontinye fè travay itil pandan ke li ap tann pou valè a vin disponib.
///
///
/// # Metòd `poll` la
///
/// Metòd debaz future, `poll`,*tantativ* pou rezoud future nan yon valè final.
/// Metòd sa a pa bloke si valè a pa pare.
/// Olye de sa, se travay aktyèl la pwograme yo dwe reveye lè li posib fè plis pwogrè pa `biwo vòt`ing ankò.
/// `context` la pase nan metòd `poll` la ka bay yon [`Waker`], ki se yon manch pou reveye travay aktyèl la.
///
/// Lè w ap itilize yon future, ou jeneralman pa pral rele `poll` dirèkteman, men olye `.await` valè an.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Kalite valè ki pwodui lè yo fini.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Eseye rezoud future a nan yon valè final, enskri travay aktyèl la pou reveye si valè a poko disponib.
    ///
    /// # Retounen valè
    ///
    /// Fonksyon sa a retounen:
    ///
    /// - [`Poll::Pending`] si future la poko pare
    /// - [`Poll::Ready(val)`] ak rezilta `val` sa a future si li fini avèk siksè.
    ///
    /// Yon fwa ke yon future fini, kliyan pa ta dwe `poll` li ankò.
    ///
    /// Lè yon future poko pare, `poll` retounen `Poll::Pending` epi estoke yon script [`Waker`] kopye nan [`Context`] aktyèl la.
    /// [`Waker`] sa a se lè sa a reveye yon fwa future la ka fè pwogrè.
    /// Pou egzanp, yon future ap tann pou yon priz yo vin lizib ta rele `.clone()` sou [`Waker`] la ak magazen li.
    /// Lè yon siyal rive yon lòt kote ki endike ke priz la lizib, yo rele [`Waker::wake`] epi yo pran priz future la.
    /// Yon fwa yo te reveye yon travay, li ta dwe eseye `poll` future la ankò, ki ka oswa pa ka pwodwi yon valè final la.
    ///
    /// Remake byen ke sou apèl miltip nan `poll`, sèlman [`Waker`] la soti nan [`Context`] la pase nan apèl ki pi resan yo ta dwe pwograme yo resevwa yon reveye.
    ///
    /// # Karakteristik ègzekutabl
    ///
    /// Futures pou kont yo *inèt*;yo dwe *aktivman*"biwo vòt" pou fè pwogrè, sa vle di ke chak fwa travay aktyèl la reveye, li ta dwe aktivman re-polye annatant futures ke li toujou gen yon enterè nan.
    ///
    /// Fonksyon `poll` la pa rele repete nan yon bouk sere-olye de sa, li ta dwe rele sèlman lè future endike ke li pare pou fè pwogrè (lè w rele `wake()`).
    /// Si ou abitye avèk syscalls yo `poll(2)` oswa `select(2)` sou Unix li la vo anyen ki futures tipikman *pa* soufri menm pwoblèm yo nan "all wakeups must poll all events";yo plis tankou `epoll(4)`.
    ///
    /// Yon aplikasyon nan `poll` ta dwe fè efò retounen byen vit, epi yo pa ta dwe bloke.Retounen byen vit anpeche san nesesite bouche fil oswa evènman pasan.
    /// Si li konnen devan yo nan tan ke yon apèl nan `poll` ka fini pran yon ti tan, yo ta dwe travay la dechaje nan yon pisin fil (oswa yon bagay ki sanble) asire ke `poll` ka retounen byen vit.
    ///
    /// # Panics
    ///
    /// Yon fwa yon future fin ranpli (retounen `Ready` soti nan `poll`), rele metòd `poll` li yo ankò pouvwa panic, bloke pou tout tan, oswa lakòz lòt kalite pwoblèm;`Future` trait a pa mete okenn kondisyon sou efè yo nan tankou yon apèl.
    /// Sepandan, kòm metòd la `poll` pa make `unsafe`, règ abityèl Rust a aplike: apèl pa dwe janm lakòz konpòtman endefini (koripsyon memwa, sèvi ak kòrèk nan fonksyon `unsafe`, oswa renmen an), kèlkeswa eta future la.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}