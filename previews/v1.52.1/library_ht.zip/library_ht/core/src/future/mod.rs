#![stable(feature = "futures_api", since = "1.36.0")]

//! Valè asenkron.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Kalite sa a nesesè paske:
///
/// a) Dèlko pa ka aplike `for<'a, 'b> Generator<&'a mut Context<'b>>`, kidonk nou bezwen pase yon konsèy kri (gade <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) endikasyon kri ak `NonNull` yo pa `Send` oswa `Sync`, se konsa ki ta fè chak sèl future non-Send/Sync kòm byen, epi nou pa vle sa.
///
/// Li tou senplifye HIR bese `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Vlope yon dèlko nan yon future.
///
/// Fonksyon sa a retounen yon `GenFuture` anba, men li kache nan `impl Trait` pou bay pi bon mesaj erè (`impl Future` olye ke `GenFuture<[closure.....]>`).
///
// Sa a se `const` pou fè pou evite erè siplemantè apre nou fin refè soti nan `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Nou konte sou lefèt ke async/await futures yo immobilier yo nan lòd yo kreye pwòp tèt ou-referansyèl prete nan dèlko a kache.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SEKIRITE: Safe paske nou se !Unpin + !Drop, e sa se jis yon pwojeksyon jaden.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Rekòmanse dèlko a, vire `&mut Context` la nan yon konsèy `NonNull` anvan tout koreksyon.
            // `.await` bese a pral san danje jete ki tounen nan yon `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SEKIRITE: moun kap rele a dwe garanti ke `cx.0` se yon konsèy valab
    // ki satisfè tout kondisyon yo pou yon referans mutable.
    unsafe { &mut *cx.0.as_ptr().cast() }
}