//! Manipilasyon fisèl.
//!
//! Pou plis detay, gade modil la [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. soti nan limit
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. kòmanse <=fini
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. fwontyè karaktè
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // jwenn pèsonaj la
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` dwe mwens pase len ak yon fwontyè char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Retounen longè `self`.
    ///
    /// Longè sa a se an bytes, pa [`char`] s oswa grafèm.
    /// Nan lòt mo, li ka pa sa yon moun konsidere longè fisèl la.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // anpenpan f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Retounen `true` si `self` gen yon longè zewo bytes.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Chèk ke `endèks`-th octet se premye octet nan yon sekans pwen kòd UTF-8 oswa nan fen fisèl la.
    ///
    ///
    /// Kòmansman ak fen fisèl la (lè `endèks== self.len()`) yo konsidere kòm limit.
    ///
    /// Retounen `false` si `index` pi gran pase `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // kòmansman `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // dezyèm octet nan `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // twazyèm byte `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ak len yo toujou ok.
        // Tès pou 0 klèman pou ke li ka optimize soti chèk la fasil epi sote lekti done fisèl pou ka sa.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Sa a se ti jan majik ekivalan a: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Konvèti yon tranch fisèl nan yon tranch byte.
    /// Pou konvèti tranch byte a tounen nan yon tranch fisèl, sèvi ak fonksyon [`from_utf8`] la.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SEKIRITE: konstan son paske nou transmute de kalite ak Layout a menm
        unsafe { mem::transmute(self) }
    }

    /// Konvèti yon tranch fisèl mutabl nan yon tranch bit mutab.
    ///
    /// # Safety
    ///
    /// Moun kap rele a dwe asire ke kontni an nan tranch la valab UTF-8 anvan prete a fini epi li sèvi ak kache `str` la.
    ///
    ///
    /// Sèvi ak yon `str` ki gen sa ki pa valab UTF-8 se konpòtman endefini.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SEKIRITE: jete ki soti nan `&str` a `&[u8]` an sekirite depi `str`
        // gen menm layout ak `&[u8]` (sèlman libstd ka fè garanti sa a).
        // Dereferans lan konsèy san danje depi li soti nan yon referans mutable ki garanti yo dwe valab pou ekri.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Konvèti yon tranch fisèl nan yon konsèy anvan tout koreksyon.
    ///
    /// Kòm tranch fisèl yo se yon tranch bytes, konsèy la anvan tout koreksyon pwen nan yon [`u8`].
    /// Konsèy sa a pral montre premye byte nan tranch la fisèl.
    ///
    /// Moun kap rele a dwe asire ke konsèy la retounen pa janm ekri.
    /// Si ou bezwen mitasyon sa ki nan tranch la fisèl, sèvi ak [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Konvèti yon tranch fisèl mutabl nan yon konsèy anvan tout koreksyon.
    ///
    /// Kòm tranch fisèl yo se yon tranch bytes, konsèy la anvan tout koreksyon pwen nan yon [`u8`].
    /// Konsèy sa a pral montre premye byte nan tranch la fisèl.
    ///
    /// Se responsablite ou a asire w ke tranch la fisèl sèlman vin modifye nan yon fason ke li rete valab UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Retounen yon subslice nan `str`.
    ///
    /// Sa a se altènatif la ki pa panike nan Indexing `str` la.
    /// Retounen [`None`] chak fwa ekivalan operasyon Indexing ta panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // endis pa sou limit sekans UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // soti nan limit
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Retounen yon subslice mutable nan `str`.
    ///
    /// Sa a se altènatif la ki pa panike nan Indexing `str` la.
    /// Retounen [`None`] chak fwa ekivalan operasyon Indexing ta panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // longè kòrèk
    /// assert!(v.get_mut(0..5).is_some());
    /// // soti nan limit
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Retounen yon subslice san kontwòl nan `str`.
    ///
    /// Sa a se altènatif la san limit nan Indexing `str` la.
    ///
    /// # Safety
    ///
    /// Moun kap rele nan fonksyon sa a yo responsab ke kondisyon sa yo satisfè:
    ///
    /// * Endèks la kòmanse pa dwe depase endèks la fini;
    /// * Endèks yo dwe nan limit tranch orijinal la;
    /// * Endèks yo dwe kouche sou limit sekans UTF-8.
    ///
    /// Si li pa, tranch la fisèl retounen ka referans memwa envalib oswa vyole envariant yo kominike pa kalite a `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `get_unchecked`;
        // tranch la se dereferencable paske `self` se yon referans san danje.
        // Konsèy la retounen an sekirite paske impls nan `SliceIndex` gen garanti ke li se.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Retounen yon mutable, subslice san limit nan `str`.
    ///
    /// Sa a se altènatif la san limit nan Indexing `str` la.
    ///
    /// # Safety
    ///
    /// Moun kap rele nan fonksyon sa a yo responsab ke kondisyon sa yo satisfè:
    ///
    /// * Endèks la kòmanse pa dwe depase endèks la fini;
    /// * Endèks yo dwe nan limit tranch orijinal la;
    /// * Endèks yo dwe kouche sou limit sekans UTF-8.
    ///
    /// Si li pa, tranch la fisèl retounen ka referans memwa envalib oswa vyole envariant yo kominike pa kalite a `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `get_unchecked_mut`;
        // tranch la se dereferencable paske `self` se yon referans san danje.
        // Konsèy la retounen an sekirite paske impls nan `SliceIndex` gen garanti ke li se.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Kreye yon tranch fisèl soti nan yon lòt tranch fisèl, contournement chèk sekirite.
    ///
    /// Sa jeneralman pa rekòmande, itilize avèk prekosyon!Pou yon altènativ ki an sekirite al gade [`str`] ak [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Sa a nouvo tranch ale soti nan `begin` `end`, ki gen ladan `begin` men eksepte `end`.
    ///
    /// Pou jwenn yon tranch fisèl mitab olye de sa, gade metòd [`slice_mut_unchecked`] la.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Moun kap rele nan fonksyon sa a yo responsab ke twa kondisyon sa yo satisfè:
    ///
    /// * `begin` pa dwe depase `end`.
    /// * `begin` ak `end` dwe pozisyon byte nan tranch la fisèl.
    /// * `begin` ak `end` dwe kouche sou limit sekans UTF-8.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `get_unchecked`;
        // tranch la se dereferencable paske `self` se yon referans san danje.
        // Konsèy la retounen an sekirite paske impls nan `SliceIndex` gen garanti ke li se.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Kreye yon tranch fisèl soti nan yon lòt tranch fisèl, contournement chèk sekirite.
    /// Sa jeneralman pa rekòmande, itilize avèk prekosyon!Pou yon altènatif ki an sekirite al gade [`str`] ak [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Sa a nouvo tranch ale soti nan `begin` `end`, ki gen ladan `begin` men eksepte `end`.
    ///
    /// Pou jwenn yon tranch fisèl imuiabl olye, al gade metòd la [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Moun kap rele nan fonksyon sa a yo responsab ke twa kondisyon sa yo satisfè:
    ///
    /// * `begin` pa dwe depase `end`.
    /// * `begin` ak `end` dwe pozisyon byte nan tranch la fisèl.
    /// * `begin` ak `end` dwe kouche sou limit sekans UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `get_unchecked_mut`;
        // tranch la se dereferencable paske `self` se yon referans san danje.
        // Konsèy la retounen an sekirite paske impls nan `SliceIndex` gen garanti ke li se.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Divize yon sèl tranch fisèl an de nan yon endèks.
    ///
    /// Agiman an, `mid`, yo ta dwe yon byte konpanse depi nan konmansman an nan fisèl la.
    /// Li dwe tou sou fwontyè yon pwen kòd UTF-8.
    ///
    /// De tranch yo retounen ale depi nan konmansman an nan tranch la fisèl `mid`, ak nan `mid` nan fen tranch la fisèl.
    ///
    /// Pou jwenn tranch fisèl mityèl olye de sa, gade metòd [`split_at_mut`] la.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics si `mid` pa sou yon fwontyè pwen kòd UTF-8, oswa si li sot pase nan fen dènye pwen kòd la nan tranch la fisèl.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary chèk endèks la se nan [0, .len()]
        if self.is_char_boundary(mid) {
            // SEKIRITE: jis tcheke ke `mid` se sou yon fwontyè char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Divize yon sèl tranch fisèl mutab an de nan yon endèks.
    ///
    /// Agiman an, `mid`, yo ta dwe yon byte konpanse depi nan konmansman an nan fisèl la.
    /// Li dwe tou sou fwontyè yon pwen kòd UTF-8.
    ///
    /// De tranch yo retounen ale depi nan konmansman an nan tranch la fisèl `mid`, ak nan `mid` nan fen tranch la fisèl.
    ///
    /// Pou jwenn tranch fisèl imuiabl olye, al gade metòd la [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics si `mid` pa sou yon fwontyè pwen kòd UTF-8, oswa si li sot pase nan fen dènye pwen kòd la nan tranch la fisèl.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary chèk endèks la se nan [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SEKIRITE: jis tcheke ke `mid` se sou yon fwontyè char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Retounen yon iteratè sou [`char`] yo nan yon tranch fisèl.
    ///
    /// Kòm yon tranch fisèl konsiste de UTF-8 valab, nou ka repete nan yon tranch fisèl pa [`char`].
    /// Metòd sa a retounen tankou yon iteratè.
    ///
    /// Li enpòtan sonje ke [`char`] reprezante yon valè Unicode Scalar, epi li ka pa matche ak lide ou sou sa ki yon 'character' se.
    ///
    /// Iterasyon sou grap grap ka sa ou vle aktyèlman.
    /// Fonksyonalite sa a pa bay nan bibliyotèk estanda Rust a, tcheke crates.io pito.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Sonje byen, [`char`] s pa ka matche ak entwisyon ou sou karaktè:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // pa 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Retounen yon iteratè sou [`char`] yo nan yon tranch fisèl, ak pozisyon yo.
    ///
    /// Kòm yon tranch fisèl konsiste de UTF-8 valab, nou ka repete nan yon tranch fisèl pa [`char`].
    /// Metòd sa a retounen yon iteratè tou de sa yo [`char`] s, osi byen ke pozisyon byte yo.
    ///
    /// Iteratè a bay tuples.Pozisyon an se premye, [`char`] la se dezyèm lan.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Sonje byen, [`char`] s pa ka matche ak entwisyon ou sou karaktè:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // pa (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // sonje 3 a isit la, karaktè ki sot pase a te pran de bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Yon iteratè sou bytes yo nan yon tranch fisèl.
    ///
    /// Kòm yon tranch fisèl konsiste de yon sekans bytes, nou ka repete nan yon tranch fisèl pa byte.
    /// Metòd sa a retounen tankou yon iteratè.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Divize yon tranch fisèl pa espas blan.
    ///
    /// Iteratè a retounen ap retounen tranch fisèl ki se sub-tranch nan tranch fisèl orijinal la, separe pa nenpòt ki kantite espas vid.
    ///
    ///
    /// 'Whitespace' se defini dapre kondisyon ki nan Unicode Derive Nwayo `White_Space` Pwopriyete a.
    /// Si ou vle sèlman fann sou espas ASCII pito, sèvi ak [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Tout kalite espas blan yo konsidere kòm:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Divize yon tranch fisèl pa espas ASCII.
    ///
    /// Iteratè a retounen ap retounen tranch fisèl ki se sub-tranch nan tranch orijinal la fisèl, separe pa nenpòt ki kantite ASCII espas blan.
    ///
    ///
    /// Pou fann pa Unicode `Whitespace` olye de sa, itilize [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Tout kalite ASCII espas blan yo konsidere kòm:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Yon iteratè sou liy ki nan yon fisèl, tankou tranch fisèl.
    ///
    /// Liy yo te fini ak swa yon newline (`\n`) oswa yon retounen cha ak yon liy manje (`\r\n`).
    ///
    /// Liy final la fini si ou vle.
    /// Yon fisèl ki fini ak yon liy final fini ap retounen liy yo menm jan ak yon fisèl otreman idantik san yo pa yon liy final fini.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Liy final la pa obligatwa:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Yon iterateur sou liy ki nan yon fisèl.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Retounen yon iteratè nan `u16` sou fisèl la kode kòm UTF-16.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Retounen `true` si modèl yo bay la matche ak yon sub-tranch nan tranch fisèl sa a.
    ///
    /// Retounen `false` si li pa fè sa.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Retounen `true` si modèl yo bay la matche ak yon prefiks nan tranch fisèl sa a.
    ///
    /// Retounen `false` si li pa fè sa.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Retounen `true` si modèl yo bay la matche ak yon sifiks nan tranch fisèl sa a.
    ///
    /// Retounen `false` si li pa fè sa.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Retounen endèks la byte nan karaktè an premye nan sa a tranch fisèl ki matche ak modèl la.
    ///
    /// Retounen [`None`] si modèl la pa matche.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modèl senp:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Modèl pi konplèks lè l sèvi avèk style pwen-gratis ak fèmti:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Pa jwenn modèl la:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Retounen endèks la byte pou karaktè an premye nan matche ak nan dwa nan modèl la nan sa a tranch fisèl.
    ///
    /// Retounen [`None`] si modèl la pa matche.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modèl senp:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Modèl pi konplèks ak fèmti:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Pa jwenn modèl la:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Yon iteratè sou substrings sa a tranch fisèl, separe pa karaktè matche pa yon modèl.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè retounen an pral yon [`DoubleEndedIterator`] si modèl la pèmèt yon rechèch ranvèse ak rechèch forward/reverse bay menm eleman yo.
    /// Sa a se vre pou, egzanp, [`char`], men se pa pou `&str`.
    ///
    /// Si modèl la pèmèt yon rechèch ranvèse men rezilta li yo ta ka diferan de yon rechèch pi devan, yo ka itilize metòd [`rsplit`] la.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Modèl senp:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Si modèl la se yon tranch nan Chars, fann sou chak ensidan nan nenpòt nan karaktè yo:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Yon modèl pi konplèks, lè l sèvi avèk yon fèmti:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Si yon fisèl gen plizyè separatè vwazen, ou pral fini ak fisèl vid nan pwodiksyon an:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Separatè vwazen yo separe pa fisèl la vid.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Separateur nan kòmansman oswa nan fen yon fisèl vwazen pa fisèl vid.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Lè yo itilize fisèl vid la kòm yon séparation, li separe chak karaktè nan fisèl la, ansanm ak kòmansman ak fen fisèl la.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Separatè vwazen ka mennen nan konpòtman pètèt etone lè yo itilize espas blan kòm separateur la.Kòd sa a kòrèk:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Li fè _not_ ba ou:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Sèvi ak [`split_whitespace`] pou konpòtman sa a.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Yon iteratè sou substrings sa a tranch fisèl, separe pa karaktè matche pa yon modèl.
    /// Diferan soti nan iteratè a ki te pwodwi pa `split` nan ki `split_inclusive` kite pati a matche kòm tèminatè a nan substring la.
    ///
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Si se eleman ki sot pase a nan fisèl la matche, yo pral konsidere kòm eleman sa a Terminator nan substring la anvan yo.
    /// Substring sa a pral dènye atik ke iteratè a retounen.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Yon iteratè sou substrings nan tranch la fisèl yo bay, separe pa karaktè matche pa yon modèl ak sede nan lòd ranvèse.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè a retounen mande pou modèl la sipòte yon rechèch ranvèse, epi li pral yon [`DoubleEndedIterator`] si yon rechèch forward/reverse sede eleman yo menm.
    ///
    ///
    /// Pou itere soti nan devan an, ka metòd la [`split`] dwe itilize.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Modèl senp:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Yon modèl pi konplèks, lè l sèvi avèk yon fèmti:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Yon iteratè sou substrings nan tranch la fisèl bay, separe pa karaktè matche pa yon modèl.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekivalan a [`split`], eksepte ke se substring la fin sote si vid.
    ///
    /// [`split`]: str::split
    ///
    /// Metòd sa a ka itilize pou done fisèl ki se _terminated_, olye ke _separated_ pa yon modèl.
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè retounen an pral yon [`DoubleEndedIterator`] si modèl la pèmèt yon rechèch ranvèse ak rechèch forward/reverse bay menm eleman yo.
    /// Sa a se vre pou, egzanp, [`char`], men se pa pou `&str`.
    ///
    /// Si modèl la pèmèt yon rechèch ranvèse men rezilta li yo ta ka diferan de yon rechèch pi devan, yo ka itilize metòd [`rsplit_terminator`] la.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Yon iteratè sou substrings nan `self`, separe pa karaktè matche pa yon modèl ak sede nan lòd ranvèse.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekivalan a [`split`], eksepte ke se substring la fin sote si vid.
    ///
    /// [`split`]: str::split
    ///
    /// Metòd sa a ka itilize pou done fisèl ki se _terminated_, olye ke _separated_ pa yon modèl.
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè a retounen mande pou modèl la sipòte yon rechèch ranvèse, epi li pral doub te fini si yon rechèch forward/reverse sede eleman yo menm.
    ///
    ///
    /// Pou itere soti nan devan an, ka metòd la [`split_terminator`] dwe itilize.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Yon iteratè sou substrings nan tranch la fisèl bay, separe pa yon modèl, restriksyon nan retounen nan pifò atik `n`.
    ///
    /// Si retou `n` yo retounen, dènye kòd la (`n`th substring la) ap gen rès fisèl la.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè retounen an pap double fini, paske li pa efikas pou sipòte.
    ///
    /// Si modèl la pèmèt yon rechèch ranvèse, yo ka itilize metòd [`rsplitn`] la.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Modèl senp:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Yon modèl pi konplèks, lè l sèvi avèk yon fèmti:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Yon iteratè sou substrings sa a tranch fisèl, separe pa yon modèl, kòmanse nan fen fisèl la, restriksyon nan retounen nan pifò atik `n`.
    ///
    ///
    /// Si retou `n` yo retounen, dènye kòd la (`n`th substring la) ap gen rès fisèl la.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè retounen an pap double fini, paske li pa efikas pou sipòte.
    ///
    /// Pou divize soti nan devan an, yo ka itilize metòd [`splitn`] la.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Modèl senp:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Yon modèl pi konplèks, lè l sèvi avèk yon fèmti:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Divize fisèl la sou ensidan an premye nan delimiter la espesifye epi retounen prefiks anvan delimiter ak sifiks apre delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Divize fisèl la sou dènye ensidan nan delimiter la espesifye epi retounen prefiks anvan delimiter ak sifiks apre delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Yon iteratè sou alimèt yo disjonksyon nan yon modèl nan tranch la fisèl bay yo.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè retounen an pral yon [`DoubleEndedIterator`] si modèl la pèmèt yon rechèch ranvèse ak rechèch forward/reverse bay menm eleman yo.
    /// Sa a se vre pou, egzanp, [`char`], men se pa pou `&str`.
    ///
    /// Si modèl la pèmèt yon rechèch ranvèse men rezilta li yo ta ka diferan de yon rechèch pi devan, yo ka itilize metòd [`rmatches`] la.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Yon iteratè sou alimèt yo disjonksyon nan yon modèl nan sa a tranch fisèl, sede nan lòd ranvèse.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè a retounen mande pou modèl la sipòte yon rechèch ranvèse, epi li pral yon [`DoubleEndedIterator`] si yon rechèch forward/reverse sede eleman yo menm.
    ///
    ///
    /// Pou itere soti nan devan an, ka metòd la [`matches`] dwe itilize.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Yon iteratè sou alimèt yo disjonksyon nan yon modèl nan sa a tranch fisèl kòm byen ke endèks la ki matche ak nan kòmanse nan.
    ///
    /// Pou alimèt `pat` nan `self` ki sipèpoze, se sèlman endis ki koresponn ak premye match la retounen.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè retounen an pral yon [`DoubleEndedIterator`] si modèl la pèmèt yon rechèch ranvèse ak rechèch forward/reverse bay menm eleman yo.
    /// Sa a se vre pou, egzanp, [`char`], men se pa pou `&str`.
    ///
    /// Si modèl la pèmèt yon rechèch ranvèse men rezilta li yo ta ka diferan de yon rechèch pi devan, yo ka itilize metòd [`rmatch_indices`] la.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // sèlman premye `aba` la
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Yon iteratè sou alimèt yo disjonksyon nan yon modèl nan `self`, sede nan lòd ranvèse ansanm ak endèks la nan match la.
    ///
    /// Pou alimèt `pat` nan `self` ki sipèpoze, se sèlman endis ki koresponn ak dènye match la retounen.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Konpòtman iteratè
    ///
    /// Iteratè a retounen mande pou modèl la sipòte yon rechèch ranvèse, epi li pral yon [`DoubleEndedIterator`] si yon rechèch forward/reverse sede eleman yo menm.
    ///
    ///
    /// Pou itere soti nan devan an, ka metòd la [`match_indices`] dwe itilize.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // sèlman dènye `aba` la
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Retounen yon tranch fisèl ak dirijan ak fin blan retire.
    ///
    /// 'Whitespace' se defini dapre kondisyon ki nan Unicode Derive Nwayo `White_Space` Pwopriyete a.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Retounen yon tranch fisèl ak dirijan espas retire.
    ///
    /// 'Whitespace' se defini dapre kondisyon ki nan Unicode Derive Nwayo `White_Space` Pwopriyete a.
    ///
    /// # Tèks direksyon
    ///
    /// Yon fisèl se yon sekans bytes.
    /// `start` nan kontèks sa a vle di premye pozisyon nan ki fisèl byte;pou yon lang gòch a dwat tankou angle oswa Ris, sa a pral bò gòch, ak pou dwa a gòch lang tankou arab oswa ebre, sa a pral bò dwat la.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Retounen yon tranch fisèl ak espas blan yo retire.
    ///
    /// 'Whitespace' se defini dapre kondisyon ki nan Unicode Derive Nwayo `White_Space` Pwopriyete a.
    ///
    /// # Tèks direksyon
    ///
    /// Yon fisèl se yon sekans bytes.
    /// `end` nan kontèks sa a vle di pozisyon ki sot pase a ki fisèl byte;pou yon lang goch a dwat tankou angle oswa Ris, sa a pral bò dwat, ak pou dwa a gòch lang tankou arab oswa ebre, sa a pral bò gòch la.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Retounen yon tranch fisèl ak dirijan espas retire.
    ///
    /// 'Whitespace' se defini dapre kondisyon ki nan Unicode Derive Nwayo `White_Space` Pwopriyete a.
    ///
    /// # Tèks direksyon
    ///
    /// Yon fisèl se yon sekans bytes.
    /// 'Left' nan kontèks sa a vle di premye pozisyon nan ki fisèl byte;pou yon lang tankou arab oswa ebre ki 'dwa a goch' olye ke 'kite a dwat', sa a pral bò _right_, pa bò gòch la.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Retounen yon tranch fisèl ak espas blan yo retire.
    ///
    /// 'Whitespace' se defini dapre kondisyon ki nan Unicode Derive Nwayo `White_Space` Pwopriyete a.
    ///
    /// # Tèks direksyon
    ///
    /// Yon fisèl se yon sekans bytes.
    /// 'Right' nan kontèks sa a vle di pozisyon ki sot pase a ki fisèl byte;pou yon lang tankou arab oswa ebre ki 'dwa a goch' olye ke 'kite a dwat', sa a pral bò _left_, pa dwa.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Retounen yon tranch fisèl ak tout prefiks ak sifiks ki matche ak yon modèl repete retire.
    ///
    /// [pattern] la kapab yon [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modèl senp:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Yon modèl pi konplèks, lè l sèvi avèk yon fèmti:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Sonje pi bonè matche ak li te ye, korije li anba a si
            // dènye match diferan
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SEKIRITE: `Searcher` konnen pou retounen endis valab.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Retounen yon tranch fisèl ak tout prefiks ki matche ak yon modèl repete retire.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tèks direksyon
    ///
    /// Yon fisèl se yon sekans bytes.
    /// `start` nan kontèks sa a vle di premye pozisyon nan ki fisèl byte;pou yon lang gòch a dwat tankou angle oswa Ris, sa a pral bò gòch, ak pou dwa a gòch lang tankou arab oswa ebre, sa a pral bò dwat la.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SEKIRITE: `Searcher` konnen pou retounen endis valab.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Retounen yon tranch fisèl ak prefiks la retire.
    ///
    /// Si fisèl la kòmanse ak modèl la `prefix`, retounen chèn apre prefiks la, vlope nan `Some`.
    /// Kontrèman ak `trim_start_matches`, metòd sa a retire prefiks la egzakteman yon fwa.
    ///
    /// Si fisèl la pa kòmanse ak `prefix`, retounen `None`.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Retounen yon tranch fisèl ak sifiks la retire.
    ///
    /// Si fisèl la fini ak modèl la `suffix`, retounen chèn lan anvan sifiks la, vlope nan `Some`.
    /// Kontrèman ak `trim_end_matches`, metòd sa a retire sifiks la egzakteman yon fwa.
    ///
    /// Si fisèl la pa fini ak `suffix`, retounen `None`.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Retounen yon tranch fisèl ak tout sifiks ki matche ak yon modèl repete retire.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tèks direksyon
    ///
    /// Yon fisèl se yon sekans bytes.
    /// `end` nan kontèks sa a vle di pozisyon ki sot pase a ki fisèl byte;pou yon lang goch a dwat tankou angle oswa Ris, sa a pral bò dwat, ak pou dwa a gòch lang tankou arab oswa ebre, sa a pral bò gòch la.
    ///
    ///
    /// # Examples
    ///
    /// Modèl senp:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Yon modèl pi konplèks, lè l sèvi avèk yon fèmti:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SEKIRITE: `Searcher` konnen pou retounen endis valab.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Retounen yon tranch fisèl ak tout prefiks ki matche ak yon modèl repete retire.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tèks direksyon
    ///
    /// Yon fisèl se yon sekans bytes.
    /// 'Left' nan kontèks sa a vle di premye pozisyon nan ki fisèl byte;pou yon lang tankou arab oswa ebre ki 'dwa a goch' olye ke 'kite a dwat', sa a pral bò _right_, pa bò gòch la.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Retounen yon tranch fisèl ak tout sifiks ki matche ak yon modèl repete retire.
    ///
    /// [pattern] la kapab yon `&str`, [`char`], yon tranch [`char`] s, oswa yon fonksyon oswa fèmti ki detèmine si yon karaktè alimèt.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tèks direksyon
    ///
    /// Yon fisèl se yon sekans bytes.
    /// 'Right' nan kontèks sa a vle di pozisyon ki sot pase a ki fisèl byte;pou yon lang tankou arab oswa ebre ki 'dwa a goch' olye ke 'kite a dwat', sa a pral bò _left_, pa dwa.
    ///
    ///
    /// # Examples
    ///
    /// Modèl senp:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Yon modèl pi konplèks, lè l sèvi avèk yon fèmti:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Analize sa a tranch fisèl nan yon lòt kalite.
    ///
    /// Paske `parse` se konsa jeneral, li ka lakòz pwoblèm ak kalite enferans.
    /// Kòm sa yo, `parse` se youn nan fwa yo kèk ou pral wè sentaks la tandreman li te ye tankou 'turbofish' la: `::<>`.
    ///
    /// Sa a ede algorithm nan enferans konprann espesyalman ki kalite w ap eseye analize nan.
    ///
    /// `parse` ka analize nan nenpòt kalite ki aplike [`FromStr`] trait la.
    ///

    /// # Errors
    ///
    /// Ap retounen [`Err`] si li pa posib analize sa a tranch fisèl nan kalite a vle.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz yo
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Sèvi ak 'turbofish' a olye pou yo anote `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Si w pa analize:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Tcheke si tout karaktè nan fisèl sa a nan ranje ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Nou ka trete chak octets kòm karaktè isit la: tout caractères multibyte kòmanse avèk yon octets ki pa nan gam ascii a, se konsa nou pral kanpe la deja.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Chèk ke de strings yo se yon ASCII ka-sansib matche ak.
    ///
    /// Menm jan ak `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, men san yo pa asiyen ak kopye tanporè.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Konvèti fisèl sa a nan ASCII majiskil ekivalan an ka an plas.
    ///
    /// Lèt ASCII 'a' a 'z' yo trase nan 'A' a 'Z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou retounen yon nouvo valè majiskil san ou pa modifye yon sèl ki deja egziste a, sèvi ak [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SEKIRITE: san danje paske nou transmute de kalite ak Layout la menm.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Konvèti fisèl sa a nan ASCII ekivalan miniskil li yo an plas.
    ///
    /// Lèt ASCII 'A' a 'Z' yo trase nan 'a' a 'z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou retounen yon nouvo valè miniskil san ou pa modifye yon sèl ki deja egziste a, sèvi ak [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SEKIRITE: san danje paske nou transmute de kalite ak Layout la menm.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Retounen yon iteratè ki sove chak char nan `self` ak [`char::escape_debug`].
    ///
    ///
    /// Note: sèlman pwen pwolonje grafèm pwolonje ki kòmanse fisèl la pral chape.
    ///
    /// # Examples
    ///
    /// Kòm yon iteratè:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sèvi ak `println!` dirèkteman:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Tou de yo ekivalan a:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Sèvi ak `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Retounen yon iteratè ki sove chak char nan `self` ak [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Kòm yon iteratè:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sèvi ak `println!` dirèkteman:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Tou de yo ekivalan a:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Sèvi ak `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Retounen yon iteratè ki sove chak char nan `self` ak [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Kòm yon iteratè:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Sèvi ak `println!` dirèkteman:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Tou de yo ekivalan a:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Sèvi ak `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Kreye yon str vid
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Kreye yon str mutable vid
    #[inline]
    fn default() -> Self {
        // SEKIRITE: fisèl vid la valab UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Yon nonmen, klonabl kalite fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SEKIRITE: pa an sekirite
        unsafe { from_utf8_unchecked(bytes) }
    };
}