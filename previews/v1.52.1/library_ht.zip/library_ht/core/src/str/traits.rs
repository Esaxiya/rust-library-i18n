//! Trait aplikasyon pou `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Aplike kòmann-nan fisèl.
///
/// Fisèl yo te bay lòd [lexicographically](Ord#lexicographical-comparison) pa valè byte yo.
/// Sa a bay lòd kòd Unicode ki baze sou pozisyon yo nan tablo yo kòd.
/// Sa a se pa nesesèman menm jan ak lòd "alphabetical", ki varye selon lang ak lokalite.
/// Triye strings selon estanda aksepte kiltirèlman egzije pou done lokal-espesifik ki deyò sijè ki abòde lan nan kalite `str` la.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Aplike operasyon konparezon sou strings.
///
/// Fisèl yo konpare [lexicographically](Ord#lexicographical-comparison) pa valè byte yo.
/// Sa konpare pwen kòd Unicode ki baze sou pozisyon yo nan tablo kòd yo.
/// Sa a se pa nesesèman menm jan ak lòd "alphabetical", ki varye selon lang ak lokalite.
/// Konpare strings selon estanda aksepte kiltirèlman egzije pou done lokal ki espesifik ki deyò sijè ki abòde lan nan kalite `str` la.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Aplike tranch substring ak sentaks `&self[..]` oswa `&mut self[..]`.
///
/// Retounen yon tranch nan tout fisèl la, sa vle di, retounen `&self` oswa `&mut self`.Ekivalan a `&pwòp tèt ou [0 ..
/// len] `oswa`&mut self [0 ..
/// len]`.
/// Kontrèman ak lòt operasyon Indexing, sa pa janm ka panic.
///
/// Operasyon sa a se *O*(1).
///
/// Anvan 1.20.0, operasyon endèks sa yo te toujou sipòte pa aplikasyon dirèk nan `Index` ak `IndexMut`.
///
/// Ekivalan a `&self[0 .. len]` oswa `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Aplike tranch substring ak sentaks `&self[begin .. end]` oswa `&mut self[begin .. end]`.
///
/// Retounen yon tranch nan fisèl la bay nan seri a byte [`kòmanse`, `end`).
///
/// Operasyon sa a se *O*(1).
///
/// Anvan 1.20.0, operasyon endèks sa yo te toujou sipòte pa aplikasyon dirèk nan `Index` ak `IndexMut`.
///
/// # Panics
///
/// Panics si `begin` oswa `end` pa lonje dwèt sou octets la kòmanse konpanse nan yon karaktè (jan sa defini nan `is_char_boundary`), si `begin > end`, oswa si `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // sa yo pral panic:
/// // octet 2 se nan `ö`:
/// // &s [2 ..3];
///
/// // byte 8 manti nan `老`&s [1 ..
/// // 8];
///
/// // byte 100 se deyò fisèl la&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEKIRITE: jis tcheke ke `start` ak `end` yo sou yon fwontyè char,
            // epi nou ap pase nan yon referans ki an sekirite, se konsa valè a retounen pral tou yon sèl.
            // Nou menm tou nou tcheke limit char, se konsa sa a valab UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEKIRITE: jis tcheke ke `start` ak `end` yo sou yon fwontyè char.
            // Nou konnen konsèy la inik paske nou te resevwa li nan `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEKIRITE: moun kap rele a garanti ke `self` se nan limit `slice`
        // ki satisfè tout kondisyon yo pou `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEKIRITE: gade kòmantè pou `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary chèk endèks la se nan [0, .len()] pa ka réutiliser `get` tankou CI-dessus, paske NLL pwoblèm
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEKIRITE: jis tcheke ke `start` ak `end` yo sou yon fwontyè char,
            // epi nou ap pase nan yon referans ki an sekirite, se konsa valè a retounen pral tou yon sèl.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Aplike tranch substring ak sentaks `&self[.. end]` oswa `&mut self[.. end]`.
///
/// Retounen yon tranch nan fisèl la bay nan seri a byte [`0`, `end`).
/// Ekivalan a `&self[0 .. end]` oswa `&mut self[0 .. end]`.
///
/// Operasyon sa a se *O*(1).
///
/// Anvan 1.20.0, operasyon endèks sa yo te toujou sipòte pa aplikasyon dirèk nan `Index` ak `IndexMut`.
///
/// # Panics
///
/// Panics si `end` pa lonje dwèt sou offset nan kòmanse karaktè nan yon karaktè (jan sa defini nan `is_char_boundary`), oswa si `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEKIRITE: jis tcheke ke `end` se sou yon fwontyè char,
            // epi nou ap pase nan yon referans ki an sekirite, se konsa valè a retounen pral tou yon sèl.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEKIRITE: jis tcheke ke `end` se sou yon fwontyè char,
            // epi nou ap pase nan yon referans ki an sekirite, se konsa valè a retounen pral tou yon sèl.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SEKIRITE: jis tcheke ke `end` se sou yon fwontyè char,
            // epi nou ap pase nan yon referans ki an sekirite, se konsa valè a retounen pral tou yon sèl.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Aplike tranch substring ak sentaks `&self[begin ..]` oswa `&mut self[begin ..]`.
///
/// Retounen yon tranch nan fisèl la bay nan seri a byte [`kòmanse`, `len`).Ekivalan a `&pwòp tèt ou [kòmanse ..
/// len] `or`&mut self [begin ..
/// len]`.
///
/// Operasyon sa a se *O*(1).
///
/// Anvan 1.20.0, operasyon endèks sa yo te toujou sipòte pa aplikasyon dirèk nan `Index` ak `IndexMut`.
///
/// # Panics
///
/// Panics si `begin` pa lonje dwèt sou offset nan kòmanse karaktè nan yon karaktè (jan sa defini nan `is_char_boundary`), oswa si `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEKIRITE: jis tcheke ke `start` se sou yon fwontyè char,
            // epi nou ap pase nan yon referans ki an sekirite, se konsa valè a retounen pral tou yon sèl.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEKIRITE: jis tcheke ke `start` se sou yon fwontyè char,
            // epi nou ap pase nan yon referans ki an sekirite, se konsa valè a retounen pral tou yon sèl.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEKIRITE: moun kap rele a garanti ke `self` se nan limit `slice`
        // ki satisfè tout kondisyon yo pou `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEKIRITE: ki idantik ak `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SEKIRITE: jis tcheke ke `start` se sou yon fwontyè char,
            // epi nou ap pase nan yon referans ki an sekirite, se konsa valè a retounen pral tou yon sèl.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Aplike tranch substring ak sentaks `&self[begin ..= end]` oswa `&mut self[begin ..= end]`.
///
/// Retounen yon tranch nan fisèl la bay nan seri a byte [`begin`, `end`].Ekivalan a `&self [begin .. end + 1]` oswa `&mut self[begin .. end + 1]`, eksepte si `end` gen valè maksimòm pou `usize`.
///
/// Operasyon sa a se *O*(1).
///
/// # Panics
///
/// Panics si `begin` pa lonje dwèt sou offset nan kòmanse karaktè nan yon karaktè (jan sa defini nan `is_char_boundary`), si `end` pa lonje dwèt sou konpanse nan byte nan fen nan yon karaktè (`end + 1` se swa yon offset kòmanse oswa egal a `len`), si `begin > end`, oswa si `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Aplike tranch substring ak sentaks `&self[..= end]` oswa `&mut self[..= end]`.
///
/// Retounen yon tranch nan fisèl yo bay la nan seri a byte [0, `end`].
/// Ekivalan a `&self [0 .. end + 1]`, eksepte si `end` gen valè maksimòm pou `usize`.
///
/// Operasyon sa a se *O*(1).
///
/// # Panics
///
/// Panics si `end` pa lonje dwèt sou konpansasyon byte fini nan yon karaktè (`end + 1` se swa yon offset kòmanse kòm defini nan `is_char_boundary`, oswa egal a `len`), oswa si `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analize yon valè ki soti nan yon fisèl
///
/// Metòd [`from_str`] `FromStr` souvan itilize implicite, atravè metòd [`parse`] [[str`] a.
/// Gade dokiman [`analize`] pou egzanp.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` pa gen yon paramèt pou tout lavi, e konsa ou ka sèlman analize kalite ki pa gen yon paramèt pou tout lavi tèt yo.
///
/// Nan lòt mo, ou ka analize yon `i32` ak `FromStr`, men se pa yon `&i32`.
/// Ou ka analize yon struct ki gen yon `i32`, men se pa youn ki gen yon `&i32`.
///
/// # Examples
///
/// Aplikasyon debaz nan `FromStr` sou yon egzanp `Point` kalite:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Erè ki asosye ki ka retounen nan analiz.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analize yon kòd `s` retounen yon valè de kalite sa a.
    ///
    /// Si analiz reyisi, retounen valè a andedan [`Ok`], otreman lè fisèl la malad-fòma retounen yon erè espesifik nan [`Err`] anndan an.
    /// Kalite erè a espesifik pou aplikasyon trait la.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz ak [`i32`], yon kalite ki aplike `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analize yon `bool` ki soti nan yon fisèl.
    ///
    /// Sede yon `Result<bool, ParseBoolError>`, paske `s` ka oswa pa aktyèlman ka analize.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Remake byen, nan anpil ka, metòd la `.parse()` sou `str` se pi plis apwopriye.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}