//! Fason yo kreye yon `str` soti nan bytes tranch.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konvèti yon tranch bytes nan yon tranch fisèl.
///
/// Yon tranch fisèl ([`&str`]) se te fè nan bytes ([`u8`]), ak yon tranch byte ([`&[u8]`][byteslice]) se te fè nan bytes, se konsa fonksyon sa a konvèti ant de la.
/// Se pa tout tranch byte ki tranch fisèl valab, sepandan: [`&str`] mande pou li valab UTF-8.
/// `from_utf8()` chèk pou asire ke bytes yo valab UTF-8, epi fè konvèsyon an.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Si ou sèten ke tranch byte a valab UTF-8, epi ou pa vle antrene anlè chèk validite a, gen yon vèsyon danjere nan fonksyon sa a, [`from_utf8_unchecked`], ki gen menm konpòtman an, men li sote chèk la.
///
///
/// Si ou bezwen yon `String` olye de yon `&str`, konsidere [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Paske ou ka chemine-asiyen yon `[u8; N]`, epi ou ka pran yon [`&[u8]`][byteslice] nan li, fonksyon sa a se yon fason gen yon fisèl chemine-resevwa lajan.Gen yon egzanp sa a nan seksyon egzanp ki anba a.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Retounen `Err` si tranch la se pa UTF-8 ak yon deskripsyon sou rezon ki fè tranch yo bay la se pa UTF-8.
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::str;
///
/// // kèk bytes, nan yon vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Nou konnen bytes sa yo valab, kidonk jis itilize `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Okte kòrèk:
///
/// ```
/// use std::str;
///
/// // kèk octets envalab, nan yon vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Gade dokiman yo pou [`Utf8Error`] pou plis detay sou kalite erè ki ka retounen.
///
/// Yon "stack allocated string":
///
/// ```
/// use std::str;
///
/// // kèk bytes, nan yon etalaj chemine-atribye ba
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Nou konnen bytes sa yo valab, kidonk jis itilize `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEKIRITE: Jis kouri validation.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konvèti yon tranch mutable nan bytes nan yon tranch fisèl mutable.
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" kòm yon vector mutable
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Kòm nou konnen bytes sa yo valab, nou ka itilize `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Okte kòrèk:
///
/// ```
/// use std::str;
///
/// // Kèk octets valab nan yon vector ki ka chanje
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Gade dokiman yo pou [`Utf8Error`] pou plis detay sou kalite erè ki ka retounen.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEKIRITE: Jis kouri validation.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konvèti yon tranch bytes nan yon tranch fisèl san tcheke si fisèl la gen UTF-8 valab.
///
/// Gade vèsyon an san danje, [`from_utf8`], pou plis enfòmasyon.
///
/// # Safety
///
/// Fonksyon sa a pa an sekirite paske li pa tcheke ke bytes yo pase ba li yo valab UTF-8.
/// Si se kontrent sa a vyole, rezilta konpòtman endefini, menm jan rès la nan Rust sipoze ke [`&str`] s yo valab UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::str;
///
/// // kèk bytes, nan yon vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SEKIRITE: moun kap rele a dwe garanti ke bytes `v` yo valab UTF-8.
    // Epitou konte sou `&str` ak `&[u8]` ki gen menm Layout la.
    unsafe { mem::transmute(v) }
}

/// Konvèti yon tranch bytes nan yon tranch fisèl san yo pa tcheke ke fisèl la gen UTF-8 valab;vèsyon mutable.
///
///
/// Gade vèsyon imuiabl la, [`from_utf8_unchecked()`] pou plis enfòmasyon.
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SEKIRITE: moun kap rele a dwe garanti ke byte `v` yo
    // yo valab UTF-8, konsa jete nan `*mut str` an sekirite.
    // Epitou, dereferans nan konsèy yo san danje paske konsèy sa a soti nan yon referans ki garanti pou valab pou ekri.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}