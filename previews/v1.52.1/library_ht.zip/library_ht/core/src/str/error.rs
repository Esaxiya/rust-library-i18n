//! Defini kalite erè utf8.

use crate::fmt;

/// Erè ki ka rive lè yo ap eseye entèprete yon sekans [`u8`] kòm yon fisèl.
///
/// Kòm sa yo, fanmi an `from_utf8` nan fonksyon ak metòd pou tou de [`String`] s ak [`&str`] s fè pou sèvi ak erè sa a, pou egzanp.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Metòd kalite erè sa a ka itilize pou kreye fonctionnalités menm jan ak `String::from_utf8_lossy` san yo pa asiyen memwa pil:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Retounen endèks la nan fisèl la bay ki te verifye UTF-8 valab.
    ///
    /// Li se endèks la maksimòm sa yo ki `from_utf8(&input[..index])` ta retounen `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::str;
    ///
    /// // kèk octets envalab, nan yon vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 retounen yon Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // dezyèm octet la valab isit la
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Bay plis enfòmasyon sou echèk la:
    ///
    /// * `None`: nan fen opinyon an te rive san atann.
    ///   `self.valid_up_to()` se 1 a 3 bytes soti nan fen opinyon an.
    ///   Si se yon kouran byte (tankou yon dosye oswa yon priz rezo) ke yo te dekode incrémentielle, sa a ta ka yon `char` ki valab ki gen UTF-8 sekans byte se spanning fragman miltip.
    ///
    ///
    /// * `Some(len)`: yon byte inatandi te rankontre.
    ///   Longè yo bay la se sa ki nan sekans byte envalid ki kòmanse nan endèks yo bay nan `valid_up_to()`.
    ///   Dekodaj ta dwe rekòmanse apre sekans sa a (apre ou fin mete yon [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) nan ka dekodaj pèdi.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Yon erè retounen lè analize yon `bool` lè l sèvi avèk [`from_str`] echwe
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}