//! Fisèl Modèl API la.
//!
//! API Modèl la bay yon mekanis jenerik pou itilize diferan kalite modèl lè wap chache nan yon fisèl.
//!
//! Pou plis detay, gade traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], ak [`DoubleEndedSearcher`].
//!
//! Malgre ke API sa a enstab, li ekspoze atravè API ki estab sou kalite [`str`].
//!
//! # Examples
//!
//! [`Pattern`] se [implemented][pattern-impls] nan API ki estab pou [`&str`][`str`], [`char`], tranch [`char`], ak fonksyon ak fèmti aplike `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // modèl char
//! assert_eq!(s.find('n'), Some(2));
//! // tranch nan modèl Chars
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // modèl fèmen
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Yon modèl fisèl.
///
/// Yon `Pattern<'a>` eksprime ke kalite aplikasyon an ka itilize kòm yon modèl fisèl pou chèche nan yon [`&'a str`][str].
///
/// Pou egzanp, tou de `'a'` ak `"aa"` yo se modèl ki ta matche ak nan endèks `1` nan fisèl la `"baaaab"`.
///
/// trait nan tèt li aji kòm yon mason pou yon kalite [`Searcher`] ki asosye, ki fè travay aktyèl la nan jwenn ensidan nan modèl la nan yon fisèl.
///
///
/// Tou depan de ki kalite modèl la, konpòtman metòd tankou [`str::find`] ak [`str::contains`] ka chanje.
/// Tablo ki anba a dekri kèk nan konpòtman sa yo.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Chèche ki asosye pou modèl sa a
    type Searcher: Searcher<'a>;

    /// Konstwi rechèch la ki asosye soti nan `self` ak `haystack` nan rechèch nan.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Tcheke si wi ou non modèl la matche ak nenpòt kote nan gwo pile zèb la
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Tcheke si wi ou non modèl la matche ak devan gwo pile zèb la
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Tcheke si wi ou non modèl la matche ak nan dèyè gwo pile zèb la
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Retire modèl la soti nan devan gwo pile zèb, si li matche ak.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SEKIRITE: `Searcher` konnen pou retounen endis valab.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Retire modèl la soti nan do a nan gwo pile zèb, si li matche ak.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SEKIRITE: `Searcher` konnen pou retounen endis valab.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Rezilta pou rele [`Searcher::next()`] oswa [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Eksprime ke yon match nan modèl la te jwenn nan `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Eksprime ke `haystack[a..b]` te rejte kòm yon match posib nan modèl la.
    ///
    /// Remake byen ke ta ka gen plis pase yon `Reject` ant de `Match`es, pa gen okenn kondisyon pou yo konbine an yon sèl.
    ///
    ///
    Reject(usize, usize),
    /// Eksprime ke chak octet gwo pile zèb la te vizite, ki fini iterasyon an.
    ///
    Done,
}

/// Yon rechèch pou yon modèl fisèl.
///
/// trait sa a bay metòd pou chèche alimèt ki pa sipèpoze nan yon modèl kòmanse nan (left) devan yon fisèl.
///
/// Li pral aplike pa kalite `Searcher` ki asosye nan [`Pattern`] trait la.
///
/// trait la make an sekirite paske endis yo retounen pa metòd [`next()`][Searcher::next] yo oblije kouche sou limit utf8 ki valab nan gwo pile zèb la.
/// Sa pèmèt konsomatè sa a trait tranch gwo pile zèb la san chèk ègzekutabl adisyonèl.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter pou fisèl la kache yo dwe fouye nan
    ///
    /// Ap toujou retounen menm [`&str`][str] la.
    fn haystack(&self) -> &'a str;

    /// Fè etap rechèch kap vini an kòmanse soti nan devan an.
    ///
    /// - Retounen [`Match(a, b)`][SearchStep::Match] si `haystack[a..b]` matche ak modèl la.
    /// - Retounen [`Reject(a, b)`][SearchStep::Reject] si `haystack[a..b]` pa ka matche ak modèl la, menm pasyèlman.
    /// - Retounen [`Done`][SearchStep::Done] si yo te vizite chak byte nan gwo pile zèb la.
    ///
    /// Kouran nan [`Match`][SearchStep::Match] ak [`Reject`][SearchStep::Reject] valè jiska yon [`Done`][SearchStep::Done] ap gen ladan chenn endèks ki adjasan, ki pa sipèpoze, ki kouvri gwo pile zèb an antye, ak tap mete sou limit utf8.
    ///
    ///
    /// Yon rezilta [`Match`][SearchStep::Match] bezwen genyen tout modèl matche a, sepandan rezilta [`Reject`][SearchStep::Reject] yo ka divize an anpil fragman adjasan.Tou de chenn yo ka gen zewo longè.
    ///
    /// Kòm yon egzanp, modèl la `"aaa"` ak gwo pile zèb la `"cbaaaaab"` ta ka pwodwi kouran an
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Jwenn pwochen rezilta [`Match`][SearchStep::Match] la.Gade [`next()`][Searcher::next].
    ///
    /// Kontrèman ak [`next()`][Searcher::next], pa gen okenn garanti ke chenn yo retounen nan sa a ak [`next_reject`][Searcher::next_reject] pral sipèpoze.
    /// Sa a pral retounen `(start_match, end_match)`, kote start_match se endèks la nan kote match la kòmanse, ak end_match se endèks la apre fen match la.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Jwenn pwochen rezilta [`Reject`][SearchStep::Reject] la.Gade [`next()`][Searcher::next] ak [`next_match()`][Searcher::next_match].
    ///
    /// Kontrèman ak [`next()`][Searcher::next], pa gen okenn garanti ke chenn yo retounen nan sa a ak [`next_match`][Searcher::next_match] pral sipèpoze.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Yon rechèch inverse pou yon modèl fisèl.
///
/// trait sa a bay metòd pou chèche alimèt ki pa sipèpoze nan yon modèl kòmanse nan (right) dèyè yon fisèl.
///
/// Li pral aplike pa kalite [`Searcher`] ki asosye nan [`Pattern`] trait si modèl la sipòte pou chèche li nan do a.
///
///
/// Chenn endèks retounen pa trait sa a pa oblije egzakteman matche ak sa yo nan rechèch la pi devan nan do.
///
/// Pou rezon ki fè trait sa a make danjere, gade yo paran trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Fè etap rechèch kap vini an kòmanse nan do a.
    ///
    /// - Retounen [`Match(a, b)`][SearchStep::Match] si `haystack[a..b]` matche ak modèl la.
    /// - Retounen [`Reject(a, b)`][SearchStep::Reject] si `haystack[a..b]` pa ka matche ak modèl la, menm pasyèlman.
    /// - Retounen [`Done`][SearchStep::Done] si yo te vizite chak byte nan gwo pile zèb la
    ///
    /// Kouran nan [`Match`][SearchStep::Match] ak [`Reject`][SearchStep::Reject] valè jiska yon [`Done`][SearchStep::Done] ap gen ladan chenn endèks ki adjasan, ki pa sipèpoze, ki kouvri gwo pile zèb an antye, ak tap mete sou limit utf8.
    ///
    ///
    /// Yon rezilta [`Match`][SearchStep::Match] bezwen genyen tout modèl matche a, sepandan rezilta [`Reject`][SearchStep::Reject] yo ka divize an anpil fragman adjasan.Tou de chenn yo ka gen zewo longè.
    ///
    /// Kòm yon egzanp, modèl la `"aaa"` ak gwo pileuz la `"cbaaaaab"` ta ka pwodwi `[Reject(7, 8) nan kouran, Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Jwenn pwochen rezilta [`Match`][SearchStep::Match] la.
    /// Gade [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Jwenn pwochen rezilta [`Reject`][SearchStep::Reject] la.
    /// Gade [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Yon makè trait pou eksprime ke yon [`ReverseSearcher`] ka itilize pou yon aplikasyon [`DoubleEndedIterator`].
///
/// Pou sa, impl nan [`Searcher`] ak [`ReverseSearcher`] bezwen swiv kondisyon sa yo:
///
/// - Tout rezilta `next()` bezwen idantik ak rezilta `next_back()` yo nan lòd ranvèse.
/// - `next()` ak `next_back()` bezwen konpòte yo kòm de bout yo nan yon seri de valè, se sa ki yo pa ka "walk past each other".
///
/// # Examples
///
/// `char::Searcher` se yon `DoubleEndedSearcher` paske chache yon [`char`] sèlman mande pou gade youn nan yon moman, ki konpòte li menm bagay la tou de nan tou de bout.
///
/// `(&str)::Searcher` se pa yon `DoubleEndedSearcher` paske modèl la `"aa"` nan gwo pileuz la `"aaa"` alimèt kòm swa `"[aa]a"` oswa `"a[aa]"`, tou depann de ki bò li se fouye.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl pou Char
/////////////////////////////////////////////////////////////////////////////

/// Kalite ki asosye pou `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariant sekirite: `finger`/`finger_back` dwe yon endèks ki valab utf8 byte nan `haystack` Envariant sa a ka kase *nan* next_match ak next_match_back, sepandan yo dwe sòti ak dwèt sou limit pwen kòd valab.
    //
    //
    /// `finger` se endèks byte aktyèl rechèch pi devan an.
    /// Imajine ke li egziste anvan byte a nan endèks li yo, sa vle di
    /// `haystack[finger]` se premye octet nan tranch la nou dwe enspekte pandan chache pi devan
    ///
    finger: usize,
    /// `finger_back` se endèks byte aktyèl la nan rechèch ranvèse a.
    /// Imajine ke li egziste apre byte a nan endèks li yo, sa vle di
    /// gwo pile zèb [finger_back, 1] se dènye octet nan tranch nou dwe enspekte pandan rechèch pi devan (e konsa premye octet yo enspekte lè w rele next_back()).
    ///
    finger_back: usize,
    /// Yo te fouye karaktè a
    needle: char,

    // envariant sekirite: `utf8_size` dwe mwens pase 5
    /// Nimewo a nan bytes `needle` pran moute lè kode nan utf8.
    utf8_size: usize,
    /// Yon kopi utf8 kode `needle` la
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SEKIRITE: 1-4 garanti sekirite `get_unchecked`
        // 1. `self.finger` ak `self.finger_back` yo kenbe sou limit Unicode (sa a envaryabl)
        // 2. `self.finger >= 0` depi li kòmanse nan 0 ak sèlman ogmante
        // 3. `self.finger < self.finger_back` paske otreman Char `iter` la ta retounen `SearchStep::Done`
        // 4.
        // `self.finger` vini anvan nan fen gwo pile zèb la paske `self.finger_back` kòmanse nan fen a epi sèlman diminye
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // ajoute byte konpanse nan karaktè aktyèl san yo pa re-kodaj kòm utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // jwenn gwo pile zèb la apre dènye karaktè yo te jwenn lan
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // byte ki sot pase a nan utf8 kode zegwi a SEKIRITE: nou gen yon envariant ki `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Dwèt nan nouvo se endèks la nan byte a nou te jwenn, plis yon sèl, depi nou memchr'd pou byte ki sot pase a nan karaktè la.
                //
                // Remake byen ke sa a pa toujou ban nou yon dwèt sou yon fwontyè UTF8.
                // Si nou *pa t '* jwenn karaktè nou, nou ka endiske nan ki pa dènye byte nan yon karaktè 3-byte oswa 4-byte.
                // Nou pa ka jis sote nan pwochen octet la valid valab paske yon karaktè tankou ꁁ (U + A041 YI silab PA), utf-8 `EA 81 81` ap gen nou toujou jwenn dezyèm octet la lè pou chèche twazyèm lan.
                //
                //
                // Sepandan, sa a se totalman oke.
                // Pandan ke nou gen envariant a ki self.finger se sou yon fwontyè UTF8, envariant sa a pa konte sou nan metòd sa a (li se konte sou nan CharSearcher::next()).
                //
                // Nou sèlman sòti metòd sa a lè nou rive nan fen fisèl la, oswa si nou jwenn yon bagay.Lè nou jwenn yon bagay `finger` a pral mete nan yon fwontyè UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // jwenn anyen, sòti
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // kite next_reject itilize aplikasyon an default soti nan Searcher trait la
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SEKIRITE: gade kòmantè pou next() pi wo a
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // soustraksyon byte konpanse nan karaktè aktyèl san yo pa re-kodaj kòm utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // jwenn gwo pile zèb la jiska men pa enkli karaktè ki sot pase a fouye
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // byte ki sot pase a nan utf8 kode zegwi a SEKIRITE: nou gen yon envariant ki `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // nou fouye yon tranch ki te konpanse nan self.finger, ajoute self.finger rekipere endèks orijinal la
                //
                let index = self.finger + index;
                // memrchr ap retounen endèks la nan byte a nou ta vle jwenn.
                // Nan ka yon karaktè ASCII, sa a se vre yo te nou swete nouvo dwèt nou yo dwe ("after" char la yo te jwenn nan paradigm nan iterasyon ranvèse).
                //
                // Pou Char multibyte nou bezwen sote desann nan kantite plis bytes yo genyen pase ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // deplase dwèt anvan karaktè yo te jwenn (sa vle di, nan endèks kòmansman li yo)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Nou pa ka itilize finger_back=endèks, gwosè + 1 isit la.
                // Si nou te jwenn dènye char nan yon karaktè diferan ki menm gwosè ak (oswa byte nan mitan yon karaktè diferan) nou bezwen frape finger_back la desann nan `index`.
                // Sa a menm jan an fè `finger_back` gen potansyèl la pa gen okenn ankò sou yon fwontyè, men sa a se OK depi nou sèlman sòti fonksyon sa a sou yon fwontyè oswa lè gwo pile zèb la te fouye konplètman.
                //
                //
                // Kontrèman ak next_match sa a pa gen pwoblèm lan nan repete bytes nan utf-8 paske nou ap chèche pou dènye a, epi nou ka sèlman yo te jwenn dènye a lè w ap chèche nan do.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // jwenn anyen, sòti
                return None;
            }
        }
    }

    // kite next_reject_back sèvi ak aplikasyon an default soti nan trait la Searcher
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Rechèch pou Chars ki egal a yon [`char`] bay yo.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl pou yon pakè MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Konpare longè iteratè tranch entèn la pou jwenn longè char aktyèl la
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Konpare longè iteratè tranch entèn la pou jwenn longè char aktyèl la
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl pou&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Chanje/Retire akòz anbigwite nan siyifikasyon.

/// Kalite ki asosye pou `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Rechèch pou karaktè ki egal a nenpòt nan [`kar`] nan tranch la.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pou F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Kalite ki asosye pou `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Rechèch pou [`char`] s ki matche ak predikatif yo bay la.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pou&&str
/////////////////////////////////////////////////////////////////////////////

/// Delege nan `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pou &str
/////////////////////////////////////////////////////////////////////////////

/// Ki pa Peye-alokasyon rechèch sou chèn.
///
/// Ap okipe modèl la `""` kòm retounen alimèt vid nan chak fwontyè karaktè.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Tcheke si wi ou non modèl la matche ak devan gwo pile zèb la.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Retire modèl la soti nan devan gwo pile zèb, si li matche ak.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SEKIRITE: prefiks te jis verifye pou egziste.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Tcheke si wi ou non modèl la matche ak nan dèyè gwo pile zèb la.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Retire modèl la soti nan do a nan gwo pile zèb, si li matche ak.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SEKIRITE: sifiks te jis verifye pou egziste.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// De fason chèrch substring
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Kalite ki asosye pou `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // zegwi vid rejte chak Char ak matche ak chak fisèl vid ant yo
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher pwodui endis ki valab *Koresponn ak* ki divize nan limit char osi lontan ke li kòrèk matche ak ki gwo pile zèb ak zegwi yo valab UTF-8 *Rejte* soti nan algorithm la ka tonbe sou nenpòt ki endis, men nou pral mache yo manyèlman nan limit la karaktè kap vini an, Se konsa, yo ke yo utf-8 san danje.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // sote nan pwochen fwontyè char
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // ekri `true` ak `false` ka ankouraje du a espesyalize de ka yo apa.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // sote nan pwochen fwontyè char
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // ekri `true` ak `false`, tankou `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Eta a entèn nan de-fason algorithm rechèch la chèn.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// endèks faktè kritik
    crit_pos: usize,
    /// endèks faktè kritik pou zegwi ranvèse
    crit_pos_back: usize,
    period: usize,
    /// `byteset` se yon ekstansyon (pa yon pati nan algorithm nan de fason);
    /// li nan yon "fingerprint" 64-bit kote chak seri `j` ti jan koresponn ak yon (byte&63)==j prezan nan zegwi a.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// endèks nan zegwi anvan nou te deja matche
    memory: usize,
    /// endèks nan zegwi apre sa nou te deja matche
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Ou ka jwenn yon eksplikasyon patikilyèman lizib sou sa k ap pase isit la nan liv "Text Algorithms" Crochemore ak Rytter a, ch 13.
        // Espesyalman wè kòd la pou "Algorithm CP" sou p.
        // 323.
        //
        // Kisa k ap pase a se nou gen kèk faktè kritik (u, v) nan zegwi a, epi nou vle detèmine si u se yon sifiks nan&v [.. peryòd].
        // Si se, nou itilize "Algorithm CP1".
        // Sinon nou itilize "Algorithm CP2", ki optimize pou lè peryòd zegwi a gwo.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // ka kout peryòd-peryòd la se egzak kalkile yon faktè separe kritik pou zegwi a ranvèse x=u 'v' kote | v '|<period(x).
            //
            // Sa a se akselere pa peryòd la ke yo te li te ye deja.
            // Remake byen ke yon ka tankou x= "acba" ka faktè egzakteman anvwa (crit_pos=1, peryòd=3) pandan ke yo te faktè ak peryòd apwoksimatif nan do (crit_pos=2, peryòd=2).
            // Nou itilize faktorizasyon ranvèse yo bay la men kenbe peryòd egzak la.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // long peryòd ka-nou gen yon apwoksimasyon nan peryòd aktyèl la, epi yo pa itilize memorizasyon.
            //
            //
            // Apeprè peryòd la pa pi ba mare max(|u|, |v|) + 1.
            // Faktirizasyon kritik la efikas pou itilize pou tou de rechèch pi devan ak ranvèse.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Valè enbesil vle di ke peryòd la se long
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Youn nan lide prensipal yo nan De-Way se ke nou dekonpoze de zegwi a nan de mwatye, (u, v), epi kòmanse ap eseye jwenn v nan gwo pile zèb la pa optik gòch a dwat.
    // Si v matche ak, nou eseye matche ak u pa optik dwa a goch.
    // Ki distans nou ka sote lè nou rankontre yon dezekilib se tout ki baze sou lefèt ke (u, v) se yon faktè kritik pou zegwi a.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` itilize `self.position` kòm kurseur li yo
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Tcheke ke nou gen plas nan rechèch nan pozisyon + needle_last pa ka debòde si nou asime tranch yo bòne pa ranje isize la.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Byen vit sote pa pòsyon gwo ki pa gen rapò ak substring nou an
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Gade si pati dwat zegwi a matche
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Gade si pati goch zegwi a matche
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Nou jwenn yon match!
            let match_pos = self.position;

            // Note: ajoute self.period olye pou yo needle.len() gen alimèt sipèpoze
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // mete nan needle.len(), self.period pou alimèt sipèpoze
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Swiv lide yo nan `next()`.
    //
    // Definisyon yo simetrik, ak period(x) = period(reverse(x)) ak local_period(u, v) = local_period(reverse(v), reverse(u)), kidonk si (u, v) se yon faktè kritik, se konsa (reverse(v), reverse(u)).
    //
    //
    // Pou ka ranvèse a, nou te kalkile yon faktè kritik x=u 'v' (jaden `crit_pos_back`).Nou bezwen | u |<period(x) pou ka a pi devan e konsa | v '|<period(x) pou ranvèse a.
    //
    // Pou fè rechèch nan ranvèse nan gwo pile zèb la, nou rechèch pi devan nan yon gwo pile zèb ranvèse ak yon zegwi ranvèse, matche premye u 'ak Lè sa a, v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` itilize `self.end` kòm kurseur li yo-pou ke `next()` ak `next_back()` yo endepandan.
        //
        let old_end = self.end;
        'search: loop {
            // Tcheke ke nou gen plas nan rechèch nan fen, needle.len() pral vlope alantou lè pa gen okenn plas plis, men akòz limit longè tranch li pa janm ka vlope tout wout la tounen nan longè a nan gwo pile zèb.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Byen vit sote pa pòsyon gwo ki pa gen rapò ak substring nou an
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Gade si pati goch zegwi a matche
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Gade si pati dwat zegwi a matche
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Nou jwenn yon match!
            let match_pos = self.end - needle.len();
            // Note: sub self.period olye pou yo needle.len() gen alimèt sipèpoze
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Kalkile sifiks maksimòm `arr` la.
    //
    // Sifiks maksimòm lan se yon faktè posib kritik (u, v) nan `arr`.
    //
    // Retounen (`i`, `p`) kote `i` se endèks la kòmanse nan v ak `p` se peryòd la nan v.
    //
    // `order_greater` detèmine si lòd leksikal se `<` oswa `>`.
    // Tou de lòd yo dwe kalkile-kòmann-nan ak pi gwo `i` a bay yon faktè kritik.
    //
    //
    // Pou ka peryòd long, peryòd la ki kapab lakòz se pa egzak (li twò kout).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Koresponn ak mwen nan papye a
        let mut right = 1; // Koresponn ak j nan papye a
        let mut offset = 0; // Koresponn ak k nan papye a, men kòmanse nan 0
        // matche ak 0 ki baze sou Indexing.
        let mut period = 1; // Koresponn ak p nan papye a

        while let Some(&a) = arr.get(right + offset) {
            // `left` yo pral antre lè `right` se.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Sifiks pi piti, peryòd se tout prefiks twò lwen.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avanse nan repetisyon nan peryòd aktyèl la.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Sifiks pi gwo, kòmanse sou kote aktyèl la.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Kalkile sifiks maksimòm nan do `arr`.
    //
    // Sifiks maksimòm lan se yon faktè posib kritik (u ', v') nan `arr`.
    //
    // Retounen `i` kote `i` se endèks la kòmanse nan v ', ki soti nan do a;
    // retounen imedyatman lè yo rive nan yon peryòd `known_period`.
    //
    // `order_greater` detèmine si lòd leksikal se `<` oswa `>`.
    // Tou de lòd yo dwe kalkile-kòmann-nan ak pi gwo `i` a bay yon faktè kritik.
    //
    //
    // Pou ka peryòd long, peryòd la ki kapab lakòz se pa egzak (li twò kout).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Koresponn ak mwen nan papye a
        let mut right = 1; // Koresponn ak j nan papye a
        let mut offset = 0; // Koresponn ak k nan papye a, men kòmanse nan 0
        // matche ak 0 ki baze sou Indexing.
        let mut period = 1; // Koresponn ak p nan papye a
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Sifiks pi piti, peryòd se tout prefiks twò lwen.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avanse nan repetisyon nan peryòd aktyèl la.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Sifiks pi gwo, kòmanse sou kote aktyèl la.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy pèmèt algorithm nan swa sote ki pa alimèt kòm byen vit ke posib, oswa nan travay nan yon mòd kote li emèt Rejte relativman byen vit.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Ale nan entèval matche ak pi vit ke posib
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emèt rejte regilyèman
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}