use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Yon alokatè memwa ki ka anrejistre kòm default bibliyotèk estanda a nan atribi `#[global_allocator]` la.
///
/// Gen kèk nan metòd yo mande pou yon blòk memwa dwe *kounye a resevwa lajan* atravè yon allocator.Sa vle di ke:
///
/// * te adrès la kòmanse pou ki blòk memwa deja retounen pa yon apèl anvan yo yon metòd alokasyon tankou `alloc`, ak
///
/// * blòk la memwa pa te imedyatman deallocated, kote blòk yo deallocated swa pa ke yo te pase nan yon metòd deallocation tankou `dealloc` oswa lè yo te pase nan yon metòd alokasyon ki retounen yon konsèy ki pa nil.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait a se yon `unsafe` trait pou yon kantite rezon, ak enplemante yo dwe asire yo ke yo respekte kontra sa yo:
///
/// * Li nan konpòtman endefini si allocators mondyal detant.Ka restriksyon sa a ap leve nan future a, men kounye a yon panic nan nenpòt nan fonksyon sa yo ka mennen nan ensekirite memwa.
///
/// * `Layout` demann ak kalkil an jeneral dwe kòrèk.Moun kap rele trait sa a gen dwa konte sou kontra yo defini sou chak metòd, epi moun k ap aplike yo dwe asire kontra sa yo rete vre.
///
/// * Ou pa ka konte sou alokasyon aktyèlman k ap pase, menm si gen alokasyon pil eksplisit nan sous la.
/// Optimizeur a ka detekte alokasyon rès ke li ka swa elimine antyèman oswa deplase nan chemine a epi konsa pa janm envoke allocator la.
/// Optimiseur a ka plis sipoze ke alokasyon se enfayib, se konsa kòd ki itilize echwe akòz echèk allocator ka kounye a toudenkou travay paske optimizeur a te travay alantou bezwen an pou yon alokasyon.
/// Plis konkrè, egzanp kòd sa a pa solid, endepandaman de si wi ou non alokatè koutim ou pèmèt konte konbyen alokasyon ki te pase.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Remake byen ke optimize yo mansyone pi wo a yo pa optimize a sèlman ki ka aplike.Ou ka jeneralman pa konte sou alokasyon pil k ap pase si yo ka retire san yo pa chanje konpòtman pwogram lan.
///   Si alokasyon rive oswa ou pa se yon pati nan konpòtman pwogram lan, menm si li ta ka detekte atravè yon alokatè ki swiv alokasyon pa enprime oswa otreman gen efè segondè.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Distribye memwa jan sa dekri nan `layout` yo bay la.
    ///
    /// Retounen yon konsèy nan memwa ki fèk resevwa lajan, oswa nil pou endike echèk alokasyon an.
    ///
    /// # Safety
    ///
    /// Fonksyon sa a an sekirite paske konpòtman endefini ka lakòz si moun kap rele a pa asire ke `layout` gen gwosè ki pa zewo.
    ///
    /// (Subtraits ekstansyon ta ka bay limit plis espesifik sou konpòtman, egzanp, garanti yon adrès santinèl oswa yon konsèy nil an repons a yon demann alokasyon zewo-gwosè.)
    ///
    /// Blòk la resevwa lajan nan memwa pouvwa oswa ka pa dwe inisyalize.
    ///
    /// # Errors
    ///
    /// Retounen yon konsèy nil endike ke swa memwa fin itilize oswa `layout` pa satisfè gwosè alokatè a oswa kontrent aliyman.
    ///
    /// Aplikasyon yo ankouraje yo retounen nil sou fatig memwa olye ke avòtman, men sa a se pa yon kondisyon strik.
    /// (Espesyalman: li se *legal* aplike sa a trait anlè yon bibliyotèk alokasyon kache natif natal ki avòtman sou fatig memwa.)
    ///
    /// Kliyan ki vle avòtman kalkil an repons a yon erè alokasyon yo ankouraje yo rele fonksyon an [`handle_alloc_error`], olye ke dirèkteman envoke `panic!` oswa menm jan an.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Deallocate blòk la nan memwa nan konsèy la bay `ptr` ak `layout` yo bay la.
    ///
    /// # Safety
    ///
    /// Fonksyon sa a an sekirite paske konpòtman endefini ka lakòz si moun kap rele a pa asire tout bagay sa yo:
    ///
    ///
    /// * `ptr` dwe endike yon blòk nan memwa kounye a resevwa lajan atravè allocator sa a,
    ///
    /// * `layout` dwe menm Layout ki te itilize pou asiyen blòk memwa sa a.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Konpòte li tankou `alloc`, men tou asire ke sa yo mete a zewo anvan yo te retounen.
    ///
    /// # Safety
    ///
    /// Fonksyon sa a an sekirite pou menm rezon ke `alloc` se.
    /// Sepandan blòk la resevwa lajan nan memwa garanti yo dwe inisyalize.
    ///
    /// # Errors
    ///
    /// Retounen yon konsèy nil endike ke swa memwa fin itilize oswa `layout` pa satisfè gwosè alokatè a oswa kontrent aliyman, menm jan nan `alloc`.
    ///
    /// Kliyan ki vle avòtman kalkil an repons a yon erè alokasyon yo ankouraje yo rele fonksyon an [`handle_alloc_error`], olye ke dirèkteman envoke `panic!` oswa menm jan an.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SEKIRITE: kontra a sekirite pou `alloc` dwe konfime pa moun kap rele a.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SEKIRITE: kòm alokasyon reyisi, rejyon an soti nan `ptr`
            // nan gwosè `size` garanti yo dwe valab pou ekri.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Retresi oswa grandi yon blòk nan memwa bay `new_size` la.
    /// Blòk la dekri nan konsèy `ptr` yo bay la ak `layout`.
    ///
    /// Si sa a retounen yon konsèy ki pa nil, Lè sa a, an komen nan blòk la memwa referansye pa `ptr` te transfere nan sa a allocator.
    /// Memwa a ka oswa yo ka pa te deallocated, epi yo ta dwe konsidere kòm ka itilize (sòf si nan kou li te transfere tounen nan moun kap rele a ankò atravè valè a retounen nan metòd sa a).
    /// Blòk memwa nan nouvo resevwa lajan ak `layout`, men ak `size` mete ajou nan `new_size`.
    /// Nouvo Layout sa a ta dwe itilize lè deallocating blòk la memwa nouvo ak `dealloc`.
    /// Ranje a `0..min(layout.size(), new_size) `nan blòk la memwa nouvo garanti gen valè yo menm jan ak blòk orijinal la.
    ///
    /// Si metòd sa a retounen nil, Lè sa a, an komen nan blòk la memwa pa te transfere nan sa a allocator, ak sa ki nan blòk la memwa yo chanje.
    ///
    /// # Safety
    ///
    /// Fonksyon sa a an sekirite paske konpòtman endefini ka lakòz si moun kap rele a pa asire tout bagay sa yo:
    ///
    /// * `ptr` dwe kounye a resevwa lajan atravè allocator sa a,
    ///
    /// * `layout` dwe menm Layout ki te itilize pou asiyen blòk memwa sa,
    ///
    /// * `new_size` dwe pi gran pase zewo.
    ///
    /// * `new_size`, lè awondi jiska miltip ki pi pre `layout.align()` la, li pa dwe debòde (sètadi, valè awondi a dwe mwens pase `usize::MAX`).
    ///
    /// (Subtraits ekstansyon ta ka bay limit plis espesifik sou konpòtman, egzanp, garanti yon adrès santinèl oswa yon konsèy nil an repons a yon demann alokasyon zewo-gwosè.)
    ///
    /// # Errors
    ///
    /// Retounen nil si Layout nan nouvo pa satisfè gwosè a ak kontrent aliyman nan allocator a, oswa si alokasyon otreman echwe.
    ///
    /// Aplikasyon yo ankouraje yo retounen nil sou fatig memwa olye ke panike oswa avòtman, men sa a se pa yon kondisyon strik.
    /// (Espesyalman: li se *legal* aplike sa a trait anlè yon bibliyotèk alokasyon kache natif natal ki avòtman sou fatig memwa.)
    ///
    /// Kliyan ki vle avòtman kalkil an repons a yon erè alokasyon yo ankouraje yo rele fonksyon an [`handle_alloc_error`], olye ke dirèkteman envoke `panic!` oswa menm jan an.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SEKIRITE: moun kap rele a dwe asire ke `new_size` la pa debòde.
        // `layout.align()` soti nan yon `Layout` e konsa garanti yo valab.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SEKIRITE: moun kap rele a dwe asire ke `new_layout` pi gran pase zewo.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SEKIRITE: blòk ki deja resevwa lajan an pa ka sipèpoze blòk ki fèk resevwa lajan an.
            // Kontra a pou `dealloc` dwe konfime pa moun kap rele a.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}