//! APIs alokasyon memwa

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Erè a `AllocError` endike yon echèk alokasyon ki ka akòz fatig resous oswa nan yon bagay ki mal lè konbine agiman yo opinyon bay ak sa a allocator.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (nou bezwen sa a pou en impl nan trait Erè)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Yon aplikasyon nan `Allocator` ka asiyen, grandi, retresi, ak deallocate blòk abitrè nan done ki dekri via [`Layout`][].
///
/// `Allocator` se fèt yo dwe aplike sou ZSTs, referans, oswa endikasyon entelijan paske gen yon allocator tankou `MyAlloc([u8; N])` pa ka deplase, san yo pa mete ajou endikasyon yo nan memwa a resevwa lajan.
///
/// Kontrèman ak [`GlobalAlloc`][], alokasyon zewo ki menm gwosè ak yo pèmèt nan `Allocator`.
/// Si yon alokatè kache pa sipòte sa a (tankou jemalloc) oswa retounen yon konsèy nil (tankou `libc::malloc`), sa a dwe kenbe pa aplikasyon an.
///
/// ### Kounye a resevwa memwa
///
/// Gen kèk nan metòd yo mande pou yon blòk memwa dwe *kounye a resevwa lajan* atravè yon allocator.Sa vle di ke:
///
/// * te adrès la kòmanse pou ki blòk memwa deja retounen pa [`allocate`], [`grow`], oswa [`shrink`], ak
///
/// * blòk memwa a pa te imedyatman deallocated, kote blòk yo se swa deallocated dirèkteman pa ke yo te pase nan [`deallocate`] oswa yo te chanje pa ke yo te pase nan [`grow`] oswa [`shrink`] ki retounen `Ok`.
///
/// Si `grow` oswa `shrink` te retounen `Err`, konsèy ki pase a rete valab.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Fitting memwa
///
/// Kèk nan metòd yo mande pou yon Layout *anfòm* yon blòk memwa.
/// Ki sa sa vle di pou yon Layout "fit" yon blòk memwa vle di (oswa ekivalan, pou yon blòk memwa "fit" yon Layout) se ke kondisyon sa yo dwe kenbe:
///
/// * Blòk la dwe resevwa lajan ak menm aliyman ak [`layout.align()`], ak
///
/// * [`layout.size()`] yo bay la dwe tonbe nan seri `min ..= max`, kote:
///   - `min` se gwosè a nan layout ki pi resamman itilize asiyen blòk la, ak
///   - `max` se dènye gwosè aktyèl la retounen nan [`allocate`], [`grow`], oswa [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Blòk memwa retounen nan yon alokatè dwe lonje dwèt sou memwa ki valab epi konsève validite yo jiskaske egzanp lan ak tout klon li yo tonbe,
///
/// * klonaj oswa deplase alokatè a pa dwe invalid blòk memwa retounen soti nan alokatè sa a.Yon alokatè klone dwe konpòte li tankou alokatè a menm, ak
///
/// * nenpòt konsèy nan yon blòk memwa ki se [*currently allocated*] ka pase nan nenpòt ki lòt metòd nan allocator la.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Eseye asiyen yon blòk nan memwa.
    ///
    /// Sou siksè, retounen yon [`NonNull<[u8]>`][NonNull] reyinyon gwosè ak aliyman garanti `layout`.
    ///
    /// Blòk la retounen ka gen yon gwosè pi gwo pase sa espesifye nan `layout.size()`, epi yo ka oswa li pa ka gen sa li inisyalize.
    ///
    /// # Errors
    ///
    /// Retounen `Err` endike ke swa memwa fin itilize oswa `layout` pa satisfè gwosè alokatè a oswa kontrent aliyman.
    ///
    /// Aplikasyon yo ankouraje yo retounen `Err` sou fatig memwa olye ke panike oswa avòtman, men sa a se pa yon kondisyon strik.
    /// (Espesyalman: li se *legal* aplike sa a trait anlè yon bibliyotèk alokasyon kache natif natal ki avòtman sou fatig memwa.)
    ///
    /// Kliyan ki vle avòtman kalkil an repons a yon erè alokasyon yo ankouraje yo rele fonksyon an [`handle_alloc_error`], olye ke dirèkteman envoke `panic!` oswa menm jan an.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Konpòte li tankou `allocate`, men tou asire ke memwa a retounen se zewo-inisyalize.
    ///
    /// # Errors
    ///
    /// Retounen `Err` endike ke swa memwa fin itilize oswa `layout` pa satisfè gwosè alokatè a oswa kontrent aliyman.
    ///
    /// Aplikasyon yo ankouraje yo retounen `Err` sou fatig memwa olye ke panike oswa avòtman, men sa a se pa yon kondisyon strik.
    /// (Espesyalman: li se *legal* aplike sa a trait anlè yon bibliyotèk alokasyon kache natif natal ki avòtman sou fatig memwa.)
    ///
    /// Kliyan ki vle avòtman kalkil an repons a yon erè alokasyon yo ankouraje yo rele fonksyon an [`handle_alloc_error`], olye ke dirèkteman envoke `panic!` oswa menm jan an.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SEKIRITE: `alloc` retounen yon blòk memwa valab
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates memwa a referansye pa `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` dwe endike yon blòk nan memwa [*currently allocated*] atravè sa a allocator, ak
    /// * `layout` dwe [*fit*] ki blòk memwa.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Tantativ pou yon ekstansyon pou blòk la memwa.
    ///
    /// Retounen yon nouvo [`NonNull<[u8]>`][NonNull] ki gen yon konsèy ak gwosè aktyèl la nan memwa a resevwa lajan.Pointer la apwopriye pou kenbe done ki dekri nan `new_layout`.
    /// Pou akonpli sa, alokatè a ka pwolonje alokasyon referans pa `ptr` pou anfòm nouvo Layout la.
    ///
    /// Si sa a retounen `Ok`, Lè sa a, an komen nan blòk la memwa referansye pa `ptr` te transfere nan sa a allocator.
    /// Memwa a ka oswa yo ka pa te libere, epi yo ta dwe konsidere kòm inutilizabl sof si li te transfere tounen nan moun kap rele a ankò atravè valè a retounen nan metòd sa a.
    ///
    /// Si metòd sa a retounen `Err`, Lè sa a, an komen nan blòk la memwa pa te transfere nan sa a allocator, ak sa ki nan blòk la memwa yo chanje.
    ///
    /// # Safety
    ///
    /// * `ptr` dwe endike yon blòk nan memwa [*currently allocated*] atravè sa a allocator.
    /// * `old_layout` dwe [*fit*] ki blòk nan memwa (agiman an `new_layout` pa bezwen anfòm li.).
    /// * `new_layout.size()` dwe pi gran pase oswa egal a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retounen `Err` si Layout nan nouvo pa satisfè gwosè alokatè a ak kontrent aliyman nan alokatè a, oswa si ap grandi otreman echwe.
    ///
    /// Aplikasyon yo ankouraje yo retounen `Err` sou fatig memwa olye ke panike oswa avòtman, men sa a se pa yon kondisyon strik.
    /// (Espesyalman: li se *legal* aplike sa a trait anlè yon bibliyotèk alokasyon kache natif natal ki avòtman sou fatig memwa.)
    ///
    /// Kliyan ki vle avòtman kalkil an repons a yon erè alokasyon yo ankouraje yo rele fonksyon an [`handle_alloc_error`], olye ke dirèkteman envoke `panic!` oswa menm jan an.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEKIRITE: paske `new_layout.size()` dwe pi gran pase oswa egal a
        // `old_layout.size()`, tou de ansyen ak nouvo alokasyon memwa yo valab pou li ak ekri pou `old_layout.size()` bytes.
        // Epitou, paske alokasyon an fin vye granmoun pa t 'ankò deallocated, li pa ka sipèpoze `new_ptr`.
        // Se konsa, apèl la nan `copy_nonoverlapping` an sekirite.
        // Kontra a pou `dealloc` dwe konfime pa moun kap rele a.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Konpòte li tankou `grow`, men tou asire ke sa ki nouvo yo mete a zewo anvan yo te retounen.
    ///
    /// Blòk memwa a ap gen ladan sa ki annapre yo apre yon apèl siksè nan
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` yo konsève nan alokasyon orijinal la.
    ///   * Bytes `old_layout.size()..old_size` ap swa konsève oswa zero, tou depann de aplikasyon an allocator.
    ///   `old_size` refere a gwosè a nan blòk la memwa anvan apèl la `grow_zeroed`, ki ka pi gwo pase gwosè a ki te orijinèlman mande lè li te resevwa lajan.
    ///   * Bytes `old_size..new_size` yo mete zero.`new_size` refere a gwosè a nan blòk la memwa retounen nan apèl la `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` dwe endike yon blòk nan memwa [*currently allocated*] atravè sa a allocator.
    /// * `old_layout` dwe [*fit*] ki blòk nan memwa (agiman an `new_layout` pa bezwen anfòm li.).
    /// * `new_layout.size()` dwe pi gran pase oswa egal a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retounen `Err` si Layout nan nouvo pa satisfè gwosè alokatè a ak kontrent aliyman nan alokatè a, oswa si ap grandi otreman echwe.
    ///
    /// Aplikasyon yo ankouraje yo retounen `Err` sou fatig memwa olye ke panike oswa avòtman, men sa a se pa yon kondisyon strik.
    /// (Espesyalman: li se *legal* aplike sa a trait anlè yon bibliyotèk alokasyon kache natif natal ki avòtman sou fatig memwa.)
    ///
    /// Kliyan ki vle avòtman kalkil an repons a yon erè alokasyon yo ankouraje yo rele fonksyon an [`handle_alloc_error`], olye ke dirèkteman envoke `panic!` oswa menm jan an.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SEKIRITE: paske `new_layout.size()` dwe pi gran pase oswa egal a
        // `old_layout.size()`, tou de ansyen ak nouvo alokasyon memwa yo valab pou li ak ekri pou `old_layout.size()` bytes.
        // Epitou, paske alokasyon an fin vye granmoun pa t 'ankò deallocated, li pa ka sipèpoze `new_ptr`.
        // Se konsa, apèl la nan `copy_nonoverlapping` an sekirite.
        // Kontra a pou `dealloc` dwe konfime pa moun kap rele a.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Eseye retresi blòk memwa a.
    ///
    /// Retounen yon nouvo [`NonNull<[u8]>`][NonNull] ki gen yon konsèy ak gwosè aktyèl la nan memwa a resevwa lajan.Pointer la apwopriye pou kenbe done ki dekri nan `new_layout`.
    /// Pou akonpli sa, alokatè a ka retresi alokasyon referansye pa `ptr` pou anfòm nouvo Layout la.
    ///
    /// Si sa a retounen `Ok`, Lè sa a, an komen nan blòk la memwa referansye pa `ptr` te transfere nan sa a allocator.
    /// Memwa a ka oswa yo ka pa te libere, epi yo ta dwe konsidere kòm inutilizabl sof si li te transfere tounen nan moun kap rele a ankò atravè valè a retounen nan metòd sa a.
    ///
    /// Si metòd sa a retounen `Err`, Lè sa a, an komen nan blòk la memwa pa te transfere nan sa a allocator, ak sa ki nan blòk la memwa yo chanje.
    ///
    /// # Safety
    ///
    /// * `ptr` dwe endike yon blòk nan memwa [*currently allocated*] atravè sa a allocator.
    /// * `old_layout` dwe [*fit*] ki blòk nan memwa (agiman an `new_layout` pa bezwen anfòm li.).
    /// * `new_layout.size()` dwe pi piti pase oswa egal a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retounen `Err` si nouvo Layout a pa satisfè gwosè alokatè a ak kontrent aliyman alokatè a, oswa si réduction otreman echwe.
    ///
    /// Aplikasyon yo ankouraje yo retounen `Err` sou fatig memwa olye ke panike oswa avòtman, men sa a se pa yon kondisyon strik.
    /// (Espesyalman: li se *legal* aplike sa a trait anlè yon bibliyotèk alokasyon kache natif natal ki avòtman sou fatig memwa.)
    ///
    /// Kliyan ki vle avòtman kalkil an repons a yon erè alokasyon yo ankouraje yo rele fonksyon an [`handle_alloc_error`], olye ke dirèkteman envoke `panic!` oswa menm jan an.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEKIRITE: paske `new_layout.size()` dwe pi ba pase oswa egal a
        // `old_layout.size()`, tou de ansyen ak nouvo alokasyon memwa yo valab pou li ak ekri pou `new_layout.size()` bytes.
        // Epitou, paske alokasyon an fin vye granmoun pa t 'ankò deallocated, li pa ka sipèpoze `new_ptr`.
        // Se konsa, apèl la nan `copy_nonoverlapping` an sekirite.
        // Kontra a pou `dealloc` dwe konfime pa moun kap rele a.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Kreye yon adaptè "by reference" pou egzanp sa a nan `Allocator`.
    ///
    /// Adaptè a retounen tou aplike `Allocator` epi yo pral tou senpleman prete sa a.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SEKIRITE: kontra sekirite a dwe konfime pa moun kap rele a
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEKIRITE: kontra sekirite a dwe konfime pa moun kap rele a
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEKIRITE: kontra sekirite a dwe konfime pa moun kap rele a
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEKIRITE: kontra sekirite a dwe konfime pa moun kap rele a
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}