//! Konpilatè intrinsèques.
//!
//! Definisyon ki koresponn yo nan `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Aplikasyon yo korespondan const yo nan `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsèques
//!
//! Note: nenpòt chanjman nan konstans nan intrinsèques yo ta dwe diskite avèk ekip lang lan.
//! Sa gen ladann chanjman nan estabilite konstans la.
//!
//! Yo nan lòd yo fè yon intrinsèques ka itilize nan konpile-tan, yon sèl bezwen kopye aplikasyon an soti nan <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> `compiler/rustc_mir/src/interpret/intrinsics.rs` epi ajoute yon `#[rustc_const_unstable(feature = "foo", issue = "01234")]` intrinsèques la.
//!
//!
//! Si yon intrinsèques sipoze itilize nan yon `const fn` ak yon atribi `rustc_const_stable`, atribi intrinsèques a dwe `rustc_const_stable`, tou.
//! Tankou yon chanjman pa ta dwe fè san konsiltasyon T-lang, paske li kwit yon karakteristik nan lang lan ki pa ka repwodwi nan kòd itilizatè san sipò du.
//!
//! # Volatiles
//!
//! Intrinsèks temèt yo bay operasyon ki gen entansyon aji sou memwa I/O, ki garanti yo pa dwe reòdone pa du a atravè lòt entresèk temèt.Gade dokiman LLVM sou [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Intrinsics atomik yo bay operasyon atomik komen sou mo machin, ak plizyè lòd posib memwa.Yo obeyi menm semantik ak C++ 11.Gade dokiman LLVM sou [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Yon resiklaj rapid sou kòmann-nan memwa:
//!
//! * Jwenn, yon baryè pou trape yon seri.Li apre ak ekri pran plas apre baryè a.
//! * Lage, yon baryè pou divilge yon seri.Li anvan ak ekri pran plas anvan baryè a.
//! * Sekans ki konsistan, sekans ki konsistan operasyon yo garanti yo rive nan lòd.Sa a se mòd nan estanda pou travay ak kalite atomik ak ki ekivalan a `volatile` Java la.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Sa yo enpòtasyon yo te itilize pou senplifye lyen intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SEKIRITE: gade `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, sa yo intrinsèques pran endikasyon anvan tout koreksyon paske yo mitasyon memwa alyas, ki pa valab pou swa `&` oswa `&mut`.
    //

    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange` pa pase [`Ordering::SeqCst`] kòm tou de paramèt yo `success` ak `failure`.
    ///
    /// Pa egzanp, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange` pa pase [`Ordering::Acquire`] kòm tou de paramèt yo `success` ak `failure`.
    ///
    /// Pa egzanp, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange` pa pase [`Ordering::Release`] kòm `success` la ak [`Ordering::Relaxed`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange` pa pase [`Ordering::AcqRel`] kòm `success` la ak [`Ordering::Acquire`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange` pa pase [`Ordering::Relaxed`] kòm tou de paramèt yo `success` ak `failure`.
    ///
    /// Pa egzanp, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange` pa pase [`Ordering::SeqCst`] kòm `success` la ak [`Ordering::Relaxed`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange` pa pase [`Ordering::SeqCst`] kòm `success` la ak [`Ordering::Acquire`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange` pa pase [`Ordering::Acquire`] kòm `success` la ak [`Ordering::Relaxed`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange` pa pase [`Ordering::AcqRel`] kòm `success` la ak [`Ordering::Relaxed`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange_weak` pa pase [`Ordering::SeqCst`] kòm tou de paramèt yo `success` ak `failure`.
    ///
    /// Pa egzanp, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange_weak` pa pase [`Ordering::Acquire`] kòm tou de paramèt yo `success` ak `failure`.
    ///
    /// Pa egzanp, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange_weak` pa pase [`Ordering::Release`] kòm `success` la ak [`Ordering::Relaxed`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange_weak` pa pase [`Ordering::AcqRel`] kòm `success` la ak [`Ordering::Acquire`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange_weak` pa pase [`Ordering::Relaxed`] kòm tou de paramèt yo `success` ak `failure`.
    ///
    /// Pa egzanp, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange_weak` pa pase [`Ordering::SeqCst`] kòm `success` la ak [`Ordering::Relaxed`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange_weak` pa pase [`Ordering::SeqCst`] kòm `success` la ak [`Ordering::Acquire`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange_weak` pa pase [`Ordering::Acquire`] kòm `success` la ak [`Ordering::Relaxed`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Sere yon valè si valè aktyèl la se menm valè `old`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `compare_exchange_weak` pa pase [`Ordering::AcqRel`] kòm `success` la ak [`Ordering::Relaxed`] kòm paramèt yo `failure`.
    /// Pa egzanp, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Chaj valè aktyèl la nan konsèy la.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `load` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Chaj valè aktyèl la nan konsèy la.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `load` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Chaj valè aktyèl la nan konsèy la.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `load` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Estoke valè a nan kote memwa espesifye a.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `store` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Estoke valè a nan kote memwa espesifye a.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `store` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Estoke valè a nan kote memwa espesifye a.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `store` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Estoke valè a nan kote memwa espesifye a, retounen valè a fin vye granmoun.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `swap` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Estoke valè a nan kote memwa espesifye a, retounen valè a fin vye granmoun.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `swap` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Estoke valè a nan kote memwa espesifye a, retounen valè a fin vye granmoun.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `swap` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Estoke valè a nan kote memwa espesifye a, retounen valè a fin vye granmoun.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `swap` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Estoke valè a nan kote memwa espesifye a, retounen valè a fin vye granmoun.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `swap` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ajoute valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_add` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ajoute valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_add` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ajoute valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_add` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ajoute valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_add` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ajoute valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_add` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Fè soustraksyon nan valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_sub` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fè soustraksyon nan valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_sub` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fè soustraksyon nan valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_sub` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fè soustraksyon nan valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_sub` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fè soustraksyon nan valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_sub` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_and` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_and` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_and` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_and` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_and` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitand nand ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite a [`AtomicBool`] atravè metòd la `fetch_nand` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite a [`AtomicBool`] atravè metòd la `fetch_nand` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite a [`AtomicBool`] atravè metòd la `fetch_nand` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite a [`AtomicBool`] atravè metòd la `fetch_nand` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite a [`AtomicBool`] atravè metòd la `fetch_nand` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise oswa avèk valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_or` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise oswa avèk valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_or` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise oswa avèk valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_or` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise oswa avèk valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_or` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise oswa avèk valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_or` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_xor` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_xor` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_xor` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_xor` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ak valè aktyèl la, retounen valè anvan an.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo [`atomic`] atravè metòd la `fetch_xor` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimòm ak valè aktyèl la lè l sèvi avèk yon konparezon siyen.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_max` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimòm ak valè aktyèl la lè l sèvi avèk yon konparezon siyen.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_max` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimòm ak valè aktyèl la lè l sèvi avèk yon konparezon siyen.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_max` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimòm ak valè aktyèl la lè l sèvi avèk yon konparezon siyen.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_max` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimòm ak valè aktyèl la.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_max` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon siyen.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_min` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon siyen.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_min` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon siyen.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_min` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon siyen.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_min` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon siyen.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo antye antye siyen [`atomic`] atravè metòd la `fetch_min` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen via metòd la `fetch_min` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen atravè metòd la `fetch_min` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen atravè metòd la `fetch_min` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen via metòd la `fetch_min` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen atravè metòd la `fetch_min` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen atravè metòd la `fetch_max` pa pase [`Ordering::SeqCst`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen atravè metòd la `fetch_max` pa pase [`Ordering::Acquire`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen atravè metòd la `fetch_max` pa pase [`Ordering::Release`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen atravè metòd la `fetch_max` pa pase [`Ordering::AcqRel`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimòm ak valè aktyèl la lè l sèvi avèk yon konparezon non.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib sou kalite yo nonb antye relatif [`atomic`] siyen atravè metòd la `fetch_max` pa pase [`Ordering::Relaxed`] kòm `order` la.
    /// Pa egzanp, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Intrinsèks la `prefetch` se yon allusion nan dèlko a kòd insert yon enstriksyon prefetch si sipòte;otreman, li se yon pa gen okenn-op.
    /// Prefetches pa gen okenn efè sou konpòtman pwogram lan, men yo ka chanje karakteristik pèfòmans li yo.
    ///
    /// Agiman `locality` la dwe yon nonb antye relatif konstan e li se yon espesifik lokalite tanporèl sòti nan (0), pa gen okenn lokalite, nan (3), trè lokal kenbe nan kachèt.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Intrinsèks la `prefetch` se yon allusion nan dèlko a kòd insert yon enstriksyon prefetch si sipòte;otreman, li se yon pa gen okenn-op.
    /// Prefetches pa gen okenn efè sou konpòtman pwogram lan, men yo ka chanje karakteristik pèfòmans li yo.
    ///
    /// Agiman `locality` la dwe yon nonb antye relatif konstan e li se yon espesifik lokalite tanporèl sòti nan (0), pa gen okenn lokalite, nan (3), trè lokal kenbe nan kachèt.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Intrinsèks la `prefetch` se yon allusion nan dèlko a kòd insert yon enstriksyon prefetch si sipòte;otreman, li se yon pa gen okenn-op.
    /// Prefetches pa gen okenn efè sou konpòtman pwogram lan, men yo ka chanje karakteristik pèfòmans li yo.
    ///
    /// Agiman `locality` la dwe yon nonb antye relatif konstan e li se yon espesifik lokalite tanporèl sòti nan (0), pa gen okenn lokalite, nan (3), trè lokal kenbe nan kachèt.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Intrinsèks la `prefetch` se yon allusion nan dèlko a kòd insert yon enstriksyon prefetch si sipòte;otreman, li se yon pa gen okenn-op.
    /// Prefetches pa gen okenn efè sou konpòtman pwogram lan, men yo ka chanje karakteristik pèfòmans li yo.
    ///
    /// Agiman `locality` la dwe yon nonb antye relatif konstan e li se yon espesifik lokalite tanporèl sòti nan (0), pa gen okenn lokalite, nan (3), trè lokal kenbe nan kachèt.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Yon kloti atomik.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib nan [`atomic::fence`] pa pase [`Ordering::SeqCst`] kòm `order` la.
    ///
    ///
    pub fn atomic_fence();
    /// Yon kloti atomik.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib nan [`atomic::fence`] pa pase [`Ordering::Acquire`] kòm `order` la.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Yon kloti atomik.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib nan [`atomic::fence`] pa pase [`Ordering::Release`] kòm `order` la.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Yon kloti atomik.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib nan [`atomic::fence`] pa pase [`Ordering::AcqRel`] kòm `order` la.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Yon baryè memwa du sèlman.
    ///
    /// Memwa aksè pa janm yo pral reordered atravè baryè sa a pa du a, men pa gen okenn enstriksyon yo pral emèt pou li.
    /// Sa a apwopriye pou operasyon sou menm fil la ki ka anpeche, tankou lè kominike avèk moun ki gen siyal.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib nan [`atomic::compiler_fence`] pa pase [`Ordering::SeqCst`] kòm `order` la.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Yon baryè memwa du sèlman.
    ///
    /// Memwa aksè pa janm yo pral reordered atravè baryè sa a pa du a, men pa gen okenn enstriksyon yo pral emèt pou li.
    /// Sa a apwopriye pou operasyon sou menm fil la ki ka anpeche, tankou lè kominike avèk moun ki gen siyal.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib nan [`atomic::compiler_fence`] pa pase [`Ordering::Acquire`] kòm `order` la.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Yon baryè memwa du sèlman.
    ///
    /// Memwa aksè pa janm yo pral reordered atravè baryè sa a pa du a, men pa gen okenn enstriksyon yo pral emèt pou li.
    /// Sa a apwopriye pou operasyon sou menm fil la ki ka anpeche, tankou lè kominike avèk moun ki gen siyal.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib nan [`atomic::compiler_fence`] pa pase [`Ordering::Release`] kòm `order` la.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Yon baryè memwa du sèlman.
    ///
    /// Memwa aksè pa janm yo pral reordered atravè baryè sa a pa du a, men pa gen okenn enstriksyon yo pral emèt pou li.
    /// Sa a apwopriye pou operasyon sou menm fil la ki ka anpeche, tankou lè kominike avèk moun ki gen siyal.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques ki disponib nan [`atomic::compiler_fence`] pa pase [`Ordering::AcqRel`] kòm `order` la.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Majik intrinsèques ki sòti siyifikasyon li nan atribi tache ak fonksyon an.
    ///
    /// Pou egzanp, dataflow itilize sa a enjekte deklarasyon estatik pou ke `rustc_peek(potentially_uninitialized)` ta aktyèlman doub-tcheke ke dataflow te tout bon kalkile ke li se uninitialized nan pwen sa a nan koule nan kontwòl.
    ///
    ///
    /// Sa a intrinsèques pa ta dwe itilize deyò nan du la.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Avort ekzekisyon pwosesis la.
    ///
    /// Yon vèsyon plis itilizatè-zanmitay ak ki estab nan operasyon sa a se [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Enfòme optimizeur la ke pwen sa a nan kòd la pa atenn, sa ki pèmèt plis optimize.
    ///
    /// NB, sa trè diferan de makro `unreachable!()` la: Kontrèman ak makro, ki panics lè li egzekite, li se *konpòtman endefini* yo rive jwenn kòd ki make ak fonksyon sa a.
    ///
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Enfòme optimizeur a ke yon kondisyon toujou vre.
    /// Si kondisyon an fo, konpòtman an endefini.
    ///
    /// Pa gen okenn kòd ki pwodwi pou sa a intrinsèques, men optimizeur a ap eseye prezève li (ak kondisyon li yo) ant pas, ki ka entèfere ak optimize nan ki antoure kòd ak diminye pèfòmans.
    /// Li pa ta dwe itilize si envariant la ka dekouvri pa optimizeur a sou pwòp li yo, oswa si li pa pèmèt nenpòt ki optimizasyon enpòtan.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Sijesyon sou du a ki kondisyon branch gen anpil chans yo dwe vre.
    /// Retounen valè ki pase nan li.
    ///
    /// Nenpòt itilizasyon lòt pase ak deklarasyon `if` pwobableman pa pral gen yon efè.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Sijesyon sou du a ki kondisyon branch gen chans rive nan fo.
    /// Retounen valè ki pase nan li.
    ///
    /// Nenpòt itilizasyon lòt pase ak deklarasyon `if` pwobableman pa pral gen yon efè.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Egzekite yon pèlen breakpoint, pou enspeksyon pa yon debugger.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn breakpoint();

    /// Gwosè a nan yon kalite nan bytes.
    ///
    /// Plis espesyalman, sa a se konpanse nan bytes ant atik siksesif nan menm kalite a, ki gen ladan padding aliyman.
    ///
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Aliyman minimòm yon kalite.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Aliman an pi pito nan yon kalite.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Gwosè a nan valè a referansye nan bytes.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Aliyman ki nesesè nan valè a referansye.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Jwenn yon tranch fisik estatik ki gen non yon kalite.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Jwenn yon idantifyan ki se globalman inik nan kalite a espesifye.
    /// Fonksyon sa a ap retounen menm valè a pou yon kalite kèlkeswa kèlkeswa sa ki crate li envoke nan.
    ///
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Yon gad pou fonksyon danjere ki pa janm ka egzekite si `T` se dezole:
    /// Sa a pral statikman swa panic, oswa pa fè anyen.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Yon gad pou fonksyon danjere ki pa janm ka egzekite si `T` pa pèmèt zewo-inisyalizasyon: Sa a pral statikman swa panic, oswa pa fè anyen.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn assert_zero_valid<T>();

    /// Yon gad pou fonksyon danjere ki pa janm ka egzekite si `T` gen modèl ti jan envalib: Sa a pral statikman swa panic, oswa pa fè anyen.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn assert_uninit_valid<T>();

    /// Jwenn yon referans a yon `Location` estatik ki endike kote li te rele.
    ///
    /// Konsidere itilize [`core::panic::Location::caller`](crate::panic::Location::caller) olye.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Deplase yon valè soti nan sijè ki abòde san yo pa kouri lakòl gout.
    ///
    /// Sa a egziste sèlman pou [`mem::forget_unsized`];nòmal `forget` itilize `ManuallyDrop` olye.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reentèrprèt Bits yo nan yon valè de yon kalite kòm yon lòt kalite.
    ///
    /// Tou de kalite yo dwe gen menm gwosè.
    /// Ni orijinal la, ni rezilta a, ka yon [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` se semantik ekivalan a yon mouvman bit de yon kalite nan yon lòt.Li kopye Bits yo soti nan valè sous la nan valè destinasyon an, lè sa a bliye orijinal la.
    /// Li ekivalan a `memcpy` C a anba kapo machin lan, menm jan ak `transmute_copy`.
    ///
    /// Paske `transmute` se yon operasyon pa valè, aliyman nan *transmute valè tèt yo* se pa yon enkyetid.
    /// Menm jan ak nenpòt lòt fonksyon, du a deja asire tou de `T` ak `U` yo byen aliyen.
    /// Sepandan, lè transmute valè ki *pwen yon lòt kote*(tankou endikasyon, referans, bwat ...), moun kap rele a gen asire bon aliyman nan valè yo pwente-a.
    ///
    /// `transmute` se **ekstrèmman** danjere.Gen yon nimewo vas nan fason yo lakòz [undefined behavior][ub] ak fonksyon sa a.`transmute` ta dwe dènye rekou absoli.
    ///
    /// [nomicon](../../nomicon/transmutes.html) la gen lòt dokiman.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Gen kèk bagay ki `transmute` se reyèlman itil pou.
    ///
    /// Vire yon konsèy nan yon konsèy fonksyon.Sa a se *pa* pòtab nan machin kote endikasyon fonksyon ak endikasyon done gen diferan gwosè.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Pwolonje yon lavi, oswa mantèg yon lavi envariant.Sa a se avanse, trè danjere Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Pa dezespere: anpil itilizasyon `transmute` ka reyalize nan lòt mwayen.
    /// Anba la a se aplikasyon komen nan `transmute` ki ka ranplase ak konstwi pi an sekirite.
    ///
    /// Vire bytes(`&[u8]`) anvan tout koreksyon `u32`, `f64`, elatriye:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // sèvi ak `u32::from_ne_bytes` olye
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // oswa itilize `u32::from_le_bytes` oswa `u32::from_be_bytes` pou presize endianness la
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Vire yon konsèy nan yon `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Sèvi ak yon jete `as` olye
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Vire yon `*mut T` nan yon `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Sèvi ak yon reborrow olye
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Vire yon `&mut T` nan yon `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Koulye a, mete ansanm `as` ak reborrowing, sonje chenn nan `as` `as` se pa tranzitif
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Vire yon `&str` nan yon `&[u8]`:
    ///
    /// ```
    /// // sa a se pa yon bon fason yo fè sa.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ou ta ka itilize `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Oswa, jis itilize yon fisèl byte, si ou gen kontwòl sou fisèl la literal
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Vire yon `Vec<&T>` nan yon `Vec<Option<&T>>`.
    ///
    /// Pou transmute kalite enteryè a nan sa ki nan yon veso, ou dwe asire w ke ou pa vyole nenpòt nan envariant kontenè a.
    /// Pou `Vec`, sa vle di ke tou de gwosè a *ak aliyman* nan kalite enteryè yo gen matche ak.
    /// Lòt resipyan ta ka konte sou gwosè a nan kalite a, aliyman, oswa menm `TypeId` a, nan ka sa a transmutasyon pa ta posib nan tout san yo pa vyole envariant yo veso.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // script vector la jan nou pral reutilize yo pita
    /// let v_clone = v_orig.clone();
    ///
    /// // Sèvi ak transmute: sa a depann sou Layout nan done ki pa espesifye nan `Vec`, ki se yon move lide epi yo ka lakòz Konpòtman Endefini.
    /////
    /// // Sepandan, li pa gen kopi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Sa a se sijere, fason ki an sekirite.
    /// // Li fè kopi vector a tout antye, menm si, nan yon nouvo etalaj.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Sa a se bon pa gen kopi, fason ki an sekirite nan "transmuting" yon `Vec`, san yo pa repoze sou Layout nan done.
    /// // Olye pou yo literalman rele `transmute`, nou fè yon jete konsèy, men an tèm de konvèti orijinal kalite enteryè (`&i32`) a nouvo (`Option<&i32>`) a, sa a gen tout opozisyon yo menm.
    /////
    /// // Anplis enfòmasyon yo bay pi wo a, konsilte tou dokiman [`from_raw_parts`] la.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Mete ajou sa a lè vec_into_raw_parts estabilize.
    ///     // Asire vector orijinal la pa tonbe.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Aplike `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Gen plizyè fason pou fè sa, e gen plizyè pwoblèm ak fason (transmute) sa a.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // premye: transmute se pa kalite ki an sekirite;tout li chèk se ke T ak
    ///         // U yo nan menm gwosè a.
    ///         // Dezyèmman, dwa isit la, ou gen de referans mutable montre nan memwa a menm.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Sa a debarase m de pwoblèm sa yo sekirite kalite;`&mut *` ap* sèlman *ba ou yon `&mut T` ki sòti nan yon `&mut T` oswa `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // sepandan, ou toujou gen de referans mutable montre nan memwa a menm.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Sa a se ki jan bibliyotèk la estanda fè li.
    /// // Sa a se metòd ki pi bon, si ou bezwen fè yon bagay tankou sa a
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Sa a kounye a gen twa referans mutable montre nan memwa a menm.`slice`, valè ret.0, ak valè ret.1.
    ///         // `slice` pa janm itilize apre `let ptr = ...`, e konsa yon moun ka trete li kòm "dead", ak Se poutèt sa, ou gen sèlman de tranch reyèl mutable.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Pandan ke sa a fè konstan nan intrinsèques ki estab, nou gen kèk kòd koutim nan konst fn
    // chèk ki anpeche itilize li nan `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Retounen `true` si kalite aktyèl la bay kòm `T` mande pou lakòl gout;retounen `false` si kalite aktyèl la bay pou `T` aplike `Copy`.
    ///
    ///
    /// Si kalite aktyèl la pa egzije gout lakòl ni aplike `Copy`, Lè sa a, valè a retounen nan fonksyon sa a se unspecified.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Kalkile konpanse ki soti nan yon konsèy.
    ///
    /// Sa a se aplike kòm yon intrinsèques pou fè pou evite konvèti nan ak pou soti nan yon nonb antye relatif, depi konvèsyon an ta jete enfòmasyon alyasman.
    ///
    /// # Safety
    ///
    /// Tou de konsèy la kòmanse ak ki kapab lakòz yo dwe swa nan limit oswa yon sèl byte sot pase yo nan fen yon objè atribye ba.
    /// Si swa konsèy se soti nan limit oswa debòde aritmetik rive Lè sa a, nenpòt ki sèvi ak plis nan valè a retounen sa pral lakòz nan konpòtman endefini.
    ///
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Kalkile konpanse ki soti nan yon konsèy, potansyèlman anbalaj.
    ///
    /// Sa a se aplike kòm yon intrinsèques pou fè pou evite konvèti nan ak pou soti nan yon nonb antye relatif, depi konvèsyon an inibit optimize sèten.
    ///
    /// # Safety
    ///
    /// Kontrèman ak `offset` intrinsèques la, sa a intrinsèques pa mete restriksyon sou konsèy la ki kapab lakòz nan pwen nan oswa yon sèl byte sot pase yo nan fen yon objè atribye ba, epi li vlope ak aritmetik konpleman de la.
    /// Valè a ki kapab lakòz se pa nesesèman valab yo dwe itilize aktyèlman aksè memwa.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ekivalan a apwopriye `llvm.memcpy.p0i8.0i8.*` intrinsèques, ak yon gwosè `count`*`size_of::<T>()` ak yon aliyman nan
    ///
    /// `min_align_of::<T>()`
    ///
    /// Se paramèt la temèt mete nan `true`, kidonk li pa pral optimize soti sof si gwosè ki egal a zewo.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekivalan a apwopriye `llvm.memmove.p0i8.0i8.*` intrinsèques, ak yon gwosè `count* size_of::<T>()` ak yon aliyman nan
    ///
    /// `min_align_of::<T>()`
    ///
    /// Se paramèt la temèt mete nan `true`, kidonk li pa pral optimize soti sof si gwosè ki egal a zewo.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekivalan a apwopriye `llvm.memset.p0i8.*` intrinsèques, ak yon gwosè `count* size_of::<T>()` ak yon aliyman nan `min_align_of::<T>()`.
    ///
    ///
    /// Se paramèt la temèt mete nan `true`, kidonk li pa pral optimize soti sof si gwosè ki egal a zewo.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Fè yon chaj temèt soti nan konsèy la `src`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Fè yon magazen temèt konsèy `dst` la.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Fè yon chaj temèt soti nan konsèy la `src` konsèy la pa oblije aliyen.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Fè yon magazen temèt konsèy `dst` la.
    /// Konsèy la pa oblije aliyen.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Retounen rasin kare yon `f32`
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Retounen rasin kare yon `f64`
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Ogmante yon `f32` nan yon pouvwa nonb antye relatif.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Ogmante yon `f64` nan yon pouvwa nonb antye relatif.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Retounen sinis la nan yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Retounen sinis la nan yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Retounen kosinin nan yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Retounen kosinin nan yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Ogmante yon `f32` nan yon pouvwa `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Ogmante yon `f64` nan yon pouvwa `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Retounen eksponansyèl nan yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Retounen eksponansyèl nan yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Retounen 2 leve soti vivan sou pouvwa a nan yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Retounen 2 leve soti vivan sou pouvwa a nan yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Retounen logaritm natirèl la nan yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Retounen logaritm natirèl la nan yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Retounen baz 10 logaritm yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Retounen baz 10 logaritm yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Retounen baz 2 logaritm yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Retounen baz 2 logaritm yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Retounen `a * b + c` pou valè `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Retounen `a * b + c` pou valè `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Retounen valè absoli yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Retounen valè absoli yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Retounen minimòm de valè `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Retounen minimòm de valè `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Retounen maksimòm de valè `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Retounen maksimòm de valè `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopi siy ki soti nan `y` a `x` pou valè `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopi siy ki soti nan `y` a `x` pou valè `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Retounen pi gwo nonb antye relatif la mwens pase oswa egal a yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Retounen pi gwo nonb antye relatif la mwens pase oswa egal a yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Retounen nonb antye relatif ki pi piti a pi gran pase oswa egal a yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Retounen nonb antye relatif ki pi piti a pi gran pase oswa egal a yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Retounen pati nonb antye relatif nan yon `f32`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Retounen pati nonb antye relatif nan yon `f64`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Retounen nonb antye relatif ki pi pre a nan yon `f32`.
    /// Ka ogmante yon eksepsyon eksepsyonèl pwen k ap flote si agiman an se pa yon nonb antye relatif.
    pub fn rintf32(x: f32) -> f32;
    /// Retounen nonb antye relatif ki pi pre a nan yon `f64`.
    /// Ka ogmante yon eksepsyon eksepsyonèl pwen k ap flote si agiman an se pa yon nonb antye relatif.
    pub fn rintf64(x: f64) -> f64;

    /// Retounen nonb antye relatif ki pi pre a nan yon `f32`.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Retounen nonb antye relatif ki pi pre a nan yon `f64`.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Retounen nonb antye relatif ki pi pre a nan yon `f32`.Wonn ka demi-fason lwen zewo.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Retounen nonb antye relatif ki pi pre a nan yon `f64`.Wonn ka demi-fason lwen zewo.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Flote Anplis de sa ki pèmèt optimize ki baze sou règ aljebrik.
    /// Ka asime entrain yo fini.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Soustraksyon flote ki pèmèt optimize ki baze sou règ aljebrik.
    /// Ka asime entrain yo fini.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Miltiplikasyon flote ki pèmèt optimize ki baze sou règ aljebrik.
    /// Ka asime entrain yo fini.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Flote divizyon ki pèmèt optimize ki baze sou règ aljebrik.
    /// Ka asime entrain yo fini.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Flote rès ki pèmèt optimize ki baze sou règ aljebrik.
    /// Ka asime entrain yo fini.
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvèti ak LLVM a fptoui/fptosi, ki ka retounen undef pou valè soti nan ranje
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Estabilize kòm [`f32::to_int_unchecked`] ak [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Retounen kantite Bits yo mete nan yon kalite nonb antye relatif `T`
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `count_ones`.
    /// Pa egzanp,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Retounen kantite dirijan Bits unset (zeroes) nan yon kalite nonb antye relatif `T`.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `leading_zeros`.
    /// Pa egzanp,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Yon `x` ak valè `0` ap retounen lajè ti jan nan `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Tankou `ctlz`, men siplemantè-danjere jan li retounen `undef` lè yo bay yon `x` ak valè `0`.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Retounen kantite Bits fin enstale (zeroes) nan yon kalite nonb antye relatif `T`.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `trailing_zeros`.
    /// Pa egzanp,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Yon `x` ak valè `0` ap retounen lajè ti jan nan `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Tankou `cttz`, men siplemantè-danjere jan li retounen `undef` lè yo bay yon `x` ak valè `0`.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Ranvèse bytes yo nan yon kalite nonb antye relatif `T`.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `swap_bytes`.
    /// Pa egzanp,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Ranvèse Bits yo nan yon kalite antye relatif `T`.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `reverse_bits`.
    /// Pa egzanp,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Fè adisyon antye ki tcheke tcheke.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `overflowing_add`.
    /// Pa egzanp,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Fè soustraksyon antye ki tcheke tcheke
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `overflowing_sub`.
    /// Pa egzanp,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Fè miltiplikasyon antye ki tcheke tcheke
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `overflowing_mul`.
    /// Pa egzanp,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Fè yon divizyon egzak, sa ki lakòz konpòtman endefini kote `x % y != 0` oswa `y == 0` oswa `x == T::MIN && y == -1`
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Fè yon divizyon san kontwòl, sa ki lakòz konpòtman endefini kote `y == 0` oswa `x == T::MIN && y == -1`
    ///
    ///
    /// Anbalaj san danje pou sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `checked_div`.
    /// Pa egzanp,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Retounen rès la nan yon divizyon san kontwòl, sa ki lakòz konpòtman endefini lè `y == 0` oswa `x == T::MIN && y == -1`
    ///
    ///
    /// Anbalaj san danje pou sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `checked_rem`.
    /// Pa egzanp,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Fè yon chanjman gòch san kontwòl, sa ki lakòz konpòtman endefini lè `y < 0` oswa `y >= N`, kote N se lajè T nan Bits.
    ///
    ///
    /// Anbalaj san danje pou sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `checked_shl`.
    /// Pa egzanp,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Fè yon chanjman dwat san kontwòl, sa ki lakòz konpòtman endefini lè `y < 0` oswa `y >= N`, kote N se lajè T an Bits.
    ///
    ///
    /// Anbalaj san danje pou sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `checked_shr`.
    /// Pa egzanp,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Retounen rezilta a nan yon adisyon san limit, sa ki lakòz konpòtman endefini lè `x + y > T::MAX` oswa `x + y < T::MIN`.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Retounen rezilta a nan yon soustraksyon san kontwòl, sa ki lakòz konpòtman endefini lè `x - y > T::MAX` oswa `x - y < T::MIN`.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Retounen rezilta yon miltiplikasyon san kontwòl, sa ki lakòz konpòtman endefini lè `x *y > T::MAX` oswa `x* y < T::MIN`.
    ///
    ///
    /// Sa a intrinsèques pa gen yon kontrepati ki estab.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Fè Thorne gòch.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `rotate_left`.
    /// Pa egzanp,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Fè Thorne adwat.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `rotate_right`.
    /// Pa egzanp,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Retounen (a + b) mod 2 <sup>N</sup>, kote N se lajè T an Bits.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `wrapping_add`.
    /// Pa egzanp,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Retounen (a, b) mod 2 <sup>N</sup>, kote N se lajè T an Bits.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `wrapping_sub`.
    /// Pa egzanp,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Retounen (a * b) mod 2 <sup>N</sup>, kote N se lajè T an Bits.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `wrapping_mul`.
    /// Pa egzanp,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Kalkile `a + b`, satire nan limit nimerik.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `saturating_add`.
    /// Pa egzanp,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Kalkile `a - b`, satire nan limit nimerik.
    ///
    /// Vèsyon yo estabilize nan sa a intrinsèques yo disponib sou primitif yo nonb antye relatif atravè metòd la `saturating_sub`.
    /// Pa egzanp,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Retounen valè diskriminan an pou Variant la nan 'v';
    /// si `T` pa gen okenn diskriminan, retounen `0`.
    ///
    /// Vèsyon an estabilize nan sa a intrinsèques se [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Retounen kantite varyant nan kalite `T` jete nan yon `usize`;
    /// si `T` pa gen okenn variantes, retounen `0`.Variant dezole yo pral konte.
    ///
    /// Vèsyon an ki dwe estabilize nan sa a intrinsèques se [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// "try catch" Rust a konstwi ki envoke `try_fn` konsèy konsèy la ak `data` konsèy done a.
    ///
    /// Twazyèm agiman an se yon fonksyon ki rele si yon panic rive.
    /// Fonksyon sa a pran konsèy la done ak yon konsèy nan objè a sib-espesifik eksepsyon ki te kenbe.
    ///
    /// Pou plis enfòmasyon gade sous du a kòm byen ke aplikasyon trape std la.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emèt yon magazen `!nontemporal` dapre LLVM (al gade doktè yo).
    /// Pwobableman pa janm ap vin estab.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Gade dokiman `<*const T>::offset_from` pou plis detay.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Gade dokiman `<*const T>::guaranteed_eq` pou plis detay.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Gade dokiman `<*const T>::guaranteed_ne` pou plis detay.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Asiyen nan tan konpile.Pa ta dwe rele nan ègzekutabl.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Gen kèk fonksyon yo defini isit la paske yo aksidantèlman te vin disponib nan modil sa a sou ki estab.
// Gade <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` tou tonbe nan kategori sa a, men li pa ka vlope akòz chèk la ke `T` ak `U` gen menm gwosè a.)
//

/// Tcheke si wi ou non `ptr` byen aliyen ki gen rapò ak `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopi `count *size_of::<T>()` bytes soti nan `src` rive `dst`.Sous la ak destinasyon an dwe* pa * sipèpoze.
///
/// Pou rejyon memwa ki ta ka sipèpoze, sèvi ak [`copy`] olye.
///
/// `copy_nonoverlapping` se semantik ekivalan a [`memcpy`] C a, men avèk lòd agiman an échanjé.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `src` dwe [valid] pou li nan `count * size_of::<T>()` bytes.
///
/// * `dst` dwe [valid] pou ekri nan `count * size_of::<T>()` bytes.
///
/// * Tou de `src` ak `dst` dwe byen aliyen.
///
/// * Rejyon an nan memwa kòmanse nan `src` ak yon gwosè nan `konte *
///   size_of: :<T>() `bytes dwe *pa* sipèpoze ak rejyon an nan memwa kòmanse nan `dst` ak menm gwosè a.
///
/// Tankou [`read`], `copy_nonoverlapping` kreye yon kopi bit de `T`, kèlkeswa si `T` se [`Copy`].
/// Si `T` se pa [`Copy`], lè l sèvi avèk *tou de* valè yo nan rejyon an kòmanse nan `*src` ak rejyon an kòmanse nan `* dst` ka [violate memory safety][read-ownership].
///
///
/// Remake byen ke menm si gwosè a efektivman kopye (`konte * size_of: :<T>()`) se `0`, endikasyon yo dwe ki pa NULL ak byen aliyen.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manyèlman aplike [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Deplase tout eleman yo nan `src` nan `dst`, kite `src` vid.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Asire ke `dst` gen ase kapasite pou kenbe tout `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Rele nan konpanse se toujou an sekirite paske `Vec` pa janm pral asiyen plis pase `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Koupe `src` san yo pa jete sa li yo.
///         // Nou fè sa an premye, pou fè pou evite pwoblèm nan ka yon bagay pi lwen desann panics.
///         src.set_len(0);
///
///         // De rejyon yo pa ka sipèpoze paske referans mutable pa alyas, ak de diferan vectors pa ka posede memwa a menm.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Notifye `dst` ke li kounye a kenbe sa ki nan `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Fè chèk sa yo sèlman nan tan kouri
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Pa panike kenbe enpak codegen ki pi piti.
        abort();
    }*/

    // SEKIRITE: kontra sekirite pou `copy_nonoverlapping` dwe
    // konfime pa moun kap rele a.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopi `count * size_of::<T>()` bytes soti nan `src` rive `dst`.Sous la ak destinasyon ka sipèpoze.
///
/// Si sous la ak destinasyon ap *pa janm* sipèpoze, [`copy_nonoverlapping`] ka itilize olye.
///
/// `copy` se semantik ekivalan a [`memmove`] C a, men avèk lòd agiman an échanjé.
/// Kopye pran plas tankou si bytes yo te kopye soti nan `src` nan yon etalaj tanporè ak Lè sa a kopye soti nan etalaj la `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `src` dwe [valid] pou li nan `count * size_of::<T>()` bytes.
///
/// * `dst` dwe [valid] pou ekri nan `count * size_of::<T>()` bytes.
///
/// * Tou de `src` ak `dst` dwe byen aliyen.
///
/// Tankou [`read`], `copy` kreye yon kopi bit de `T`, kèlkeswa si `T` se [`Copy`].
/// Si `T` se pa [`Copy`], lè l sèvi avèk tou de valè yo nan rejyon an kòmanse nan `*src` ak rejyon an kòmanse nan `* dst` ka [violate memory safety][read-ownership].
///
///
/// Remake byen ke menm si gwosè a efektivman kopye (`konte * size_of: :<T>()`) se `0`, endikasyon yo dwe ki pa NULL ak byen aliyen.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Avèk efikasite kreye yon Rust vector ki sòti nan yon tanpon an sekirite:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` dwe kòrèkteman aliyen pou kalite li yo ak ki pa zewo.
/// /// * `ptr` dwe valab pou li nan `elts` eleman vwazen nan kalite `T`.
/// /// * Moun sa yo ki eleman yo pa dwe itilize apre yo fin rele fonksyon sa a sof si `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SEKIRITE: Kondisyon nou an asire sous la aliyen ak valab,
///     // ak `Vec::with_capacity` asire ke nou gen espas ka itilize yo ekri yo.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SEKIRITE: Nou kreye li ak anpil kapasite sa a pi bonè,
///     // ak `copy` anvan an te inisyalize eleman sa yo.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Fè chèk sa yo sèlman nan tan kouri
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Pa panike kenbe enpak codegen ki pi piti.
        abort();
    }*/

    // SEKIRITE: kontra a sekirite pou `copy` dwe konfime pa moun kap rele a.
    unsafe { copy(src, dst, count) }
}

/// Ansanm `count * size_of::<T>()` bytes nan memwa kòmanse nan `dst` `val`.
///
/// `write_bytes` se menm jan ak [`memset`] C a, men kouche `count * size_of::<T>()` bytes `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `dst` dwe [valid] pou ekri nan `count * size_of::<T>()` bytes.
///
/// * `dst` dwe byen aliyen.
///
/// Anplis de sa, moun kap rele a dwe asire ke ekri `count * size_of::<T>()` bytes nan rejyon yo bay nan rezilta memwa nan yon valè ki valab nan `T`.
/// Sèvi ak yon rejyon nan memwa tape kòm yon `T` ki gen yon valè envalid nan `T` se konpòtman endefini.
///
/// Remake byen ke menm si gwosè a efektivman kopye (`konte * size_of: :<T>()`) se `0`, konsèy la dwe ki pa NIL epi byen aliyen.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Kreye yon valè envalid:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Fwit valè ki te deja fèt pa recouvrir `Box<T>` la ak yon konsèy nil.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Nan pwen sa a, lè l sèvi avèk oswa jete rezilta `v` nan konpòtman endefini.
/// // drop(v); // ERROR
///
/// // Menm koule `v` "uses" li, e pakonsekan se konpòtman endefini.
/// // mem::forget(v); // ERROR
///
/// // Anfèt, `v` pa valab selon invariants de baz jan de kouman yo dispoze, se konsa *nenpòt operasyon* manyen l 'se konpòtman endefini.
/////
/// // kite v2 =v;//ERÈ
///
/// unsafe {
///     // Se pou nou olye pou mete nan yon valè ki valab
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Koulye a, bwat la se amann
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SEKIRITE: kontra a sekirite pou `write_bytes` dwe konfime pa moun kap rele a.
    unsafe { write_bytes(dst, val, count) }
}