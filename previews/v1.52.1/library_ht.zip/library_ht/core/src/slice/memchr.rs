// Aplikasyon orijinal yo te pran nan men rust-memchr.
// Copyright 2015 Andre Gallant, bluss ak Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Sèvi ak tronkonik.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Retounen `true` si `x` gen nenpòt byte zewo.
///
/// Soti nan *zafè enfòmatik*, J. Arndt:
///
/// "Lide a se soustraksyon youn nan chak nan bytes yo ak Lè sa a, gade pou bytes kote prete a miltiplikasyon tout wout la nan siyifikatif ki pi
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Retounen premye endèks la ki matche ak byte `x` nan `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Vit chemen pou ti tranch
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Fè enspeksyon pou yon valè byte sèl pa li de mo `usize` nan yon moman.
    //
    // Fann `text` an twa pati
    // - premye pati ki pa aliyen, anvan premye mo ki aliyen nan tèks la
    // - kò, eskane pa 2 mo nan yon moman
    // - dènye pati ki rete a, <2 mo gwosè

    // rechèch jiska yon fwontyè ki aliyen
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // fouye kò tèks la
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SEKIRITE: predikatè pandan ke a garanti yon distans omwen 2 * usize_bytes
        // ant konpanse a ak nan fen tranch la.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // kraze si gen yon byte matche
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Jwenn byte a apre pwen bouk kò a sispann.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Retounen dènye endèks ki matche ak byte `x` nan `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Fè enspeksyon pou yon valè byte sèl pa li de mo `usize` nan yon moman.
    //
    // Fann `text` an twa pati:
    // - ke ki pa aliyen, apre dènye mo ki aliyen nan adrès nan tèks la,
    // - kò, tcheke pa 2 mo nan yon moman,
    // - premye octets ki rete yo, <2 mo gwosè.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Nou rele sa jis jwenn longè prefiks ak sifiks.
        // Nan mitan an nou toujou travay sou de moso nan yon fwa.
        // SEKIRITE: transmutasyon `[u8]` a `[usize]` an sekirite eksepte pou diferans gwosè ki ap okipe pa `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Rechèch kò a nan tèks la, asire w ke nou pa travèse min_aligned_offset.
    // konpanse toujou aliyen, se konsa jis tès `>` se ase epi evite posib debòde.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SEKIRITE: konpanse kòmanse nan len, suffix.len(), osi lontan ke li pi gran pase
        // min_aligned_offset (prefix.len()) distans ki rete a se omwen 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Kase si gen yon byte matche.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Jwenn byte a anvan pwen bouk kò a sispann.
    text[..offset].iter().rposition(|elt| *elt == x)
}