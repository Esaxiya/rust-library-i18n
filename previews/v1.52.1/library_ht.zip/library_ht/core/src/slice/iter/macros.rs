//! Makro itilize pa iteratè nan tranch.

// Inlining is_empty ak len fè yon gwo pèfòmans diferans
macro_rules! is_empty {
    // Fason nou kode longè yon iteratè ZST, sa travay tou de pou ZST ak ki pa ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Debarase m de kèk limit chèk (gade `position`), nou kalkile longè a nan yon fason yon ti jan inatandi.
// (Teste pa `codegen/tranch-pozisyon-limit-chèk`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // nou pafwa yo itilize nan yon blòk danjere

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ sa a sèvi ak `unchecked_sub` paske nou depann de anbalaj pou reprezante longè iteratè tranch long ZST yo.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Nou konnen ke `start <= end`, se konsa ka fè pi bon pase `offset_from`, ki bezwen fè fas nan siyen.
            // Pa mete drapo ki apwopriye isit la nou ka di LLVM sa a, ki ede li retire limit chèk yo.
            // SEKIRITE: Pa kalite a envariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Pa di tou LLVM ke endikasyon yo apa pa yon miltip egzak nan gwosè a kalite, li ka optimize `len() == 0` desann nan `start == end` olye pou yo `(end - start) < size`.
            //
            // SEKIRITE: Pa kalite envariant la, endikasyon yo aliyen konsa
            //         distans ant yo dwe yon miltip nan gwosè pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Pataje definisyon iteratè `Iter` ak `IterMut` yo
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Retounen premye eleman an epi li deplase kòmansman iteratè anvwa pa 1.
        // Anpil amelyore pèfòmans konpare ak yon fonksyon aliyen.
        // Iteratè a pa dwe vid.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Retounen dènye eleman an epi deplase fen iteratè a pa 1.
        // Anpil amelyore pèfòmans konpare ak yon fonksyon aliyen.
        // Iteratè a pa dwe vid.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Réduit iteratè a lè T se yon ZST, lè li deplase fen iteratè a pa `n`.
        // `n` pa dwe depase `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Fonksyon Èd pou kreye yon tranch soti nan iteratè la.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SEKIRITE: iteratè a te kreye nan yon tranch ak konsèy
                // `self.ptr` ak longè `len!(self)`.
                // Sa garanti ke tout kondisyon pou `from_raw_parts` yo rive vre.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Fonksyon Èd pou deplase kòmansman iteratè anvwa pa eleman `offset`, retounen kòmansman an fin vye granmoun.
            //
            // Ensekirite paske konpanse a pa dwe depase `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SEKIRITE: moun kap rele a garanti ke `offset` pa depase `self.len()`,
                    // kidonk nouvo konsèy sa a anndan `self` e konsa garanti li pa nil.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Fonksyon Èd pou deplase nan fen iteratè a pa eleman `offset`, retounen fen nan nouvo.
            //
            // Ensekirite paske konpanse a pa dwe depase `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SEKIRITE: moun kap rele a garanti ke `offset` pa depase `self.len()`,
                    // ki garanti pa debòde yon `isize`.
                    // Epitou, konsèy la ki kapab lakòz se nan limit `slice`, ki satisfè lòt kondisyon yo pou `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // te kapab aplike ak tranch, men sa a evite limit chèk yo

                // SEKIRITE: apèl `assume` yo san danje depi konsèy yon tranch kòmanse
                // dwe ki pa nil, ak tranch sou ki pa ZSTs dwe genyen tou yon konsèy fen ki pa nil.
                // Rele nan `next_unchecked!` an sekirite depi nou tcheke si iteratè a vid an premye.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iteratè sa a vid kounye a.
                    if mem::size_of::<T>() == 0 {
                        // Nou dwe fè li fason sa a kòm `ptr` pa janm ka 0, men `end` ta ka (akòz vlope).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SEKIRITE: fen pa ka 0 si T se pa ZST paske ptr pa 0 epi fini>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SEKIRITE: Nou nan limit.`post_inc_start` fè sa ki dwat menm pou ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Nou ranplase aplikasyon an default, ki itilize `try_fold`, paske aplikasyon sa a ki senp jenere mwens LLVM IR ak se pi vit konpile.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Nou ranplase aplikasyon an default, ki itilize `try_fold`, paske aplikasyon sa a ki senp jenere mwens LLVM IR ak se pi vit konpile.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Nou ranplase aplikasyon an default, ki itilize `try_fold`, paske aplikasyon sa a ki senp jenere mwens LLVM IR ak se pi vit konpile.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Nou ranplase aplikasyon an default, ki itilize `try_fold`, paske aplikasyon sa a ki senp jenere mwens LLVM IR ak se pi vit konpile.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Nou ranplase aplikasyon an default, ki itilize `try_fold`, paske aplikasyon sa a ki senp jenere mwens LLVM IR ak se pi vit konpile.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Nou ranplase aplikasyon an default, ki itilize `try_fold`, paske aplikasyon sa a ki senp jenere mwens LLVM IR ak se pi vit konpile.
            // Epitou, `assume` la evite yon chèk limit.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SEKIRITE: nou garanti yo dwe nan limit pa envariant nan bouk:
                        // lè `i >= n`, `self.next()` retounen `None` ak bouk la kraze.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Nou ranplase aplikasyon an default, ki itilize `try_fold`, paske aplikasyon sa a ki senp jenere mwens LLVM IR ak se pi vit konpile.
            // Epitou, `assume` la evite yon chèk limit.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SEKIRITE: `i` dwe pi ba pase `n` depi li kòmanse nan `n`
                        // epi li sèlman diminye.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SEKIRITE: moun kap rele a dwe garanti ke `i` se nan limit
                // tranch la kache, se konsa `i` pa ka debòde yon `isize`, ak referans yo retounen garanti yo al gade nan yon eleman nan tranch la e konsa garanti yo dwe valab.
                //
                // Epitou sonje ke moun kap rele a tou garanti ke nou pa janm ap rele ak endèks la menm ankò, e ke pa gen okenn lòt metòd ki pral jwenn aksè nan subplis sa a yo rele, kidonk li valab pou referans la retounen yo dwe mitab nan ka a nan
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // te kapab aplike ak tranch, men sa a evite limit chèk yo

                // SEKIRITE: apèl `assume` yo san danje depi konsèy yon tranch kòmanse dwe ki pa nil,
                // ak tranch sou ki pa ZSTs dwe gen tou yon konsèy fen ki pa nil.
                // Rele nan `next_back_unchecked!` an sekirite depi nou tcheke si iteratè a vid an premye.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iteratè sa a vid kounye a.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SEKIRITE: Nou nan limit.`pre_dec_end` fè sa ki dwat menm pou ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}