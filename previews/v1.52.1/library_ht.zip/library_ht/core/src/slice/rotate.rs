// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Wotasyon seri `[mid-left, mid+right)` la tankou eleman ki nan `mid` vin premye eleman an.Ekivalan, wotasyon seri a `left` eleman sou bò gòch la oswa `right` eleman sou bò dwat la.
///
/// # Safety
///
/// Ranje a espesifye dwe valab pou lekti ak ekri.
///
/// # Algorithm
///
/// Algoritm 1 yo itilize pou ti valè `left + right` oswa pou gwo `T`.
/// Eleman yo demenaje ale rete nan pozisyon final yo youn nan yon moman kòmanse nan `mid - left` ak avanse pa `right` etap modulo `left + right`, tankou ke se sèlman yon sèl tanporè ki nesesè.
/// Evantyèlman, nou rive tounen nan `mid - left`.
/// Sepandan, si `gcd(left + right, right)` se pa 1, etap ki anwo yo sote sou eleman yo.
/// Pa egzanp:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Erezman, kantite sote sou eleman ant eleman final yo toujou egal, pou nou ka jis konpanse pozisyon kòmanse nou yo ak fè plis jij (kantite total jij se `gcd(left + right, right)` value) la.
///
/// Rezilta final la se ke tout eleman yo fini yon sèl fwa epi yon sèl fwa.
///
/// Algoritm 2 yo itilize si `left + right` se gwo men `min(left, right)` se ti ase yo anfòm sou yon tanpon chemine.
/// Eleman `min(left, right)` yo kopye sou pezib la, `memmove` aplike pou lòt moun yo, epi yo menm ki sou pezib yo deplase tounen nan twou a sou bò opoze kote yo soti.
///
/// Algoritm ki ka vektè depase pi wo a yon fwa `left + right` vin gwo ase.
/// Algoritm 1 ka vektè pa chunking ak fè jij anpil nan yon fwa, men gen twò kèk jij an mwayèn jiskaske `left + right` se menmen, ak ka ki pi mal la nan yon wonn sèl se toujou la.
/// Olye de sa, algorithm 3 itilize repete échanjé nan eleman `min(left, right)` jiskaske yon pi piti wotasyon pwoblèm kite.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// lè `left < right` echanj la k ap pase sou bò gòch la olye.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algoritm ki anba yo ka febli si ka sa yo pa tcheke
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritm 1 Microbenchmarks endike ke pèfòmans an mwayèn pou orè o aza se pi bon tout wout la jouk sou `left + right == 32`, men pèfòmans nan ka pi move kraze menm alantou 16.
            // 24 te chwazi kòm tè presegondè.
            // Si gwosè a nan `T` se pi gwo pase 4 `usize`s, algorithm sa a tou pèfòme lòt algoritm.
            //
            //
            let x = unsafe { mid.sub(left) };
            // kòmansman premye tou
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` ka jwenn anvan men pa kalkile `gcd(left + right, right)`, men li se pi vit fè yon sèl bouk ki kalkile gcd a kòm yon efè segondè, Lè sa a, fè rès la nan moso nan
            //
            //
            let mut gcd = right;
            // referans revele ke li se pi vit swap tanporè tout wout la olye pou yo li yon sèl tanporè yon fwa, kopye bak, ak Lè sa a, ekri ki tanporè nan fen anpil.
            // Sa a se petèt akòz lefèt ke échanjé oswa ranplase tanporè sèvi ak yon sèl adrès memwa nan bouk la olye pou yo bezwen jere de.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // olye pou yo enkreman `i` ak Lè sa a, tcheke si li se deyò limit yo, nou tcheke si `i` pral ale deyò limit yo sou pwochen ogmantasyon an.
                // Sa a anpeche nenpòt anbalaj nan endikasyon oswa `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // fen premye tou
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // kondisyonèl sa a dwe isit la si `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // fini moso ki gen plis jij
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` se pa yon kalite zewo-gwosè, kidonk li nan oke divize pa gwosè li yo.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritm 2 `[T; 0]` la isit la se asire ke sa a apwopriye aliyen pou T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritm 3 Gen yon fason altène nan échanjé ki enplike nan jwenn ki kote swap nan dènye sa a algorithm ta dwe, ak échanjé lè l sèvi avèk ki dènye moso olye pou yo échanjé moso adjasan tankou sa a algorithm ap fè, men fason sa a se toujou pi vit.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}