//! Operasyon sou ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Chèk si tout bytes nan tranch sa a yo nan ranje ASCII la.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Chèk ke de tranch yo se yon match ASCII ka-sansib matche ak.
    ///
    /// Menm jan ak `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, men san yo pa asiyen ak kopye tanporè.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konvèti tranch sa a nan ASCII ekivalan majiskil li yo an plas.
    ///
    /// Lèt ASCII 'a' a 'z' yo trase nan 'A' a 'Z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou retounen yon nouvo valè majiskil san ou pa modifye yon sèl ki deja egziste a, sèvi ak [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konvèti tranch sa a nan ekivalan ASCII miniskil li yo an plas.
    ///
    /// Lèt ASCII 'A' a 'Z' yo trase nan 'a' a 'z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou retounen yon nouvo valè miniskil san ou pa modifye yon sèl ki deja egziste a, sèvi ak [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Retounen `true` si nenpòt byte nan mo `v` la se nonascii (>=128).
/// Snarfed soti nan `../str/mod.rs`, ki fè yon bagay ki sanble pou utf8 validation.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimize tès ASCII ki pral itilize operasyon usize-a-yon-tan olye pou yo operasyon byte-a-yon-tan (lè sa posib).
///
/// Algoritm nou itilize isit la trè senp.Si `s` twò kout, nou jis tcheke chak byte epi fè avèk li.Sinon:
///
/// - Li premye mo a ak yon chaj san aliyen.
/// - Aliman konsèy la, li mo ki vin apre jiskaske fini ak charj aliyen yo.
/// - Li `usize` ki sot pase a soti nan `s` ak yon chaj san aliyen.
///
/// Si nenpòt nan charj sa yo pwodui yon bagay pou ki `contains_nonascii` (above) retounen vre, Lè sa a, nou konnen repons lan se fo.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Si nou pa ta jwenn anyen nan mo-a-yon-tan aplikasyon an, tonbe tounen nan yon bouk scalar.
    //
    // Nou fè sa tou pou achitekti kote `size_of::<usize>()` pa ase aliyman pou `usize`, paske li nan yon ka etranj edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Nou toujou li premye mo a san aliyen, ki vle di `align_offset` se
    // 0, nou ta li menm valè a ankò pou li a aliyen.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SEKIRITE: Nou verifye `len < USIZE_SIZE` pi wo a.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Nou tcheke sa a pi wo a, yon ti jan enplisitman.
    // Remake byen ke `offset_to_aligned` se swa `align_offset` oswa `USIZE_SIZE`, tou de nan yo klèman tcheke pi wo a.
    //
    debug_assert!(offset_to_aligned <= len);

    // SEKIRITE: word_ptr se (byen aliyen) ustr ptr nou itilize pou li a
    // mitan moso nan tranch la.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` se endèks la byte nan `word_ptr`, yo itilize pou chèk fen bouk.
    let mut byte_pos = offset_to_aligned;

    // Paranoia tcheke sou aliyman, depi nou ap sou yo fè yon pakèt moun sou charj san aliyen.
    // Nan pratik sa ta dwe enposib anpeche yon ensèk nan `align_offset` menm si.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Li mo ki vin apre jiskaske dènye mo ki aliyen an, eksepte dènye mo ki aliyen an poukont li pou fè nan ke tcheke pita, pou asire ke ke se toujou yon sèl `usize` nan pi plis a branch `byte_pos == len` siplemantè.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Saniti tcheke ke li a se nan limit
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // E ke sipozisyon nou yo sou `byte_pos` kenbe.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SEKIRITE: Nou konnen `word_ptr` byen aliyen (paske nan
        // `align_offset`), epi nou konnen ke nou gen ase bytes ant `word_ptr` ak fen an
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SEKIRITE: Nou konnen ke `byte_pos <= len - USIZE_SIZE`, ki vle di sa
        // apre `add` sa a, `word_ptr` pral pi plis pase yon fen.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanite tcheke pou asire ke gen yon sèl `usize` ki rete.
    // Sa ta dwe garanti pa kondisyon bouk nou an.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SEKIRITE: Sa a depann sou `len >= USIZE_SIZE`, ki nou tcheke nan kòmansman an.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}