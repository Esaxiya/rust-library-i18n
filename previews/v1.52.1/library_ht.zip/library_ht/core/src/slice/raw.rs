//! Fonksyon gratis pou kreye `&[T]` ak `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Fòme yon tranch ki soti nan yon konsèy ak yon longè.
///
/// Agiman `len` la se kantite **eleman**, se pa kantite bytes.
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `data` dwe [valid] pou li pou `len * mem::size_of::<T>()` anpil bytes, epi li dwe byen aliyen.Sa vle di an patikilye:
///
///     * Ranje a memwa tout nan sa a tranch dwe genyen nan yo nan yon sèl objè atribye ba!
///       Tranch pa janm ka span atravè plizyè objè resevwa lajan.Gade [below](#incorrect-usage) pou yon egzanp mal pa pran sa an kont.
///     * `data` dwe ki pa nil ak aliyen menm pou tranch zewo-longè.
///     Youn nan rezon pou sa a se ke optimize layout enum ka konte sou referans (ki gen ladan tranch nan nenpòt ki longè) yo te aliyen ak ki pa nil yo fè distenksyon ant yo soti nan lòt done.
///     Ou ka jwenn yon konsèy ki ka itilize kòm `data` pou tranch zewo-longè lè l sèvi avèk [`NonNull::dangling()`].
///
/// * `data` dwe lonje dwèt sou `len` youn apre lòt valè byen inisyalize nan kalite `T`.
///
/// * Memwa a referansye pa tranch la retounen pa dwe mitasyon pou dire a nan tout lavi `'a`, eksepte andedan yon `UnsafeCell`.
///
/// * Gwosè total `len * mem::size_of::<T>()` nan tranch la pa dwe pi gwo pase `isize::MAX`.
///   Gade dokiman sekirite [`pointer::offset`] la.
///
/// # Caveat
///
/// Se tout lavi a pou tranch la retounen dedwi nan l 'li yo.
/// Pou anpeche move itilizasyon aksidan, li sijere pou mare tout lavi a kèlkeswa sa ki sous lavi a san danje nan kontèks la, tankou lè yo bay yon fonksyon ede pran tout lavi yon valè lame pou tranch la, oswa pa anotasyon eksplisit.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifeste yon tranch pou yon eleman sèl
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Itilizasyon ki pa kòrèk
///
/// Fonksyon `join_slices` sa a se **san sans** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Deklarasyon ki anwo a asire `fst` ak `snd` yo vwazen, men yo ta ka toujou genyen nan _different allocated objects_, nan ka sa a kreye tranch sa a se konpòtman endefini.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ak `b` yo diferan objè atribye ba ...
///     let a = 42;
///     let b = 27;
///     // ... ki ka kanmenm mete deyò vwazin nan memwa: |yon |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Fè menm fonctionnalités a kòm [`from_raw_parts`], eksepte ke se yon tranch mutable retounen.
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `data` dwe [valid] pou tou de li ak ekri pou `len * mem::size_of::<T>()` anpil bytes, epi li dwe byen aliyen.Sa vle di an patikilye:
///
///     * Ranje a memwa tout nan sa a tranch dwe genyen nan yo nan yon sèl objè atribye ba!
///       Tranch pa janm ka span atravè plizyè objè resevwa lajan.
///     * `data` dwe ki pa nil ak aliyen menm pou tranch zewo-longè.
///     Youn nan rezon pou sa a se ke optimize layout enum ka konte sou referans (ki gen ladan tranch nan nenpòt ki longè) yo te aliyen ak ki pa nil yo fè distenksyon ant yo soti nan lòt done.
///
///     Ou ka jwenn yon konsèy ki ka itilize kòm `data` pou tranch zewo-longè lè l sèvi avèk [`NonNull::dangling()`].
///
/// * `data` dwe lonje dwèt sou `len` youn apre lòt valè byen inisyalize nan kalite `T`.
///
/// * Memwa a referansye pa tranch la retounen pa dwe jwenn aksè nan nenpòt lòt konsèy (pa sòti nan valè a retounen) pou dire a nan tout lavi `'a`.
///   Tou de li ak ekri aksè yo entèdi.
///
/// * Gwosè total `len * mem::size_of::<T>()` nan tranch la pa dwe pi gwo pase `isize::MAX`.
///   Gade dokiman sekirite [`pointer::offset`] la.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Konvèti yon referans a T an yon tranch longè 1 (san kopye).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Konvèti yon referans a T an yon tranch longè 1 (san kopye).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}