// ignore-tidy-filelength

//! Tranch jesyon ak manipilasyon.
//!
//! Pou plis detay gade [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Pi rust aplikasyon memchr, yo te pran nan men rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Fonksyon sa a se piblik sèlman paske pa gen okenn lòt fason nan tès inite heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Retounen kantite eleman ki nan tranch la.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SEKIRITE: son konst paske nou transmute soti jaden an longè kòm yon usize (ki li dwe)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEKIRITE: sa a san danje paske `&[T]` ak `FatPtr<T>` gen menm Layout la.
            // Se sèlman `std` ki ka fè garanti sa a.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Ranplase ak `crate::ptr::metadata(self)` lè sa konstab.
            // Kòm nan sa a ekri sa a lakòz yon erè "Const-stable functions can only call other const-stable functions".
            //

            // SEKIRITE: Aksè valè ki soti nan sendika `PtrRepr` la an sekirite depi * konst T
            // ak PtrComponents<T>gen kouman memwa yo menm.
            // Se sèlman std ki ka fè garanti sa a.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Retounen `true` si tranch la gen yon longè 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Retounen premye eleman tranch la, oswa `None` si li vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Retounen yon konsèy mutable nan premye eleman nan tranch la, oswa `None` si li vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Retounen premye a ak tout rès eleman nan tranch la, oswa `None` si li vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Retounen premye a ak tout rès eleman nan tranch la, oswa `None` si li vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Retounen dènye a ak tout rès eleman nan tranch la, oswa `None` si li vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Retounen dènye a ak tout rès eleman nan tranch la, oswa `None` si li vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Retounen dènye eleman tranch la, oswa `None` si li vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Retounen yon konsèy mutable nan dènye atik la nan tranch la.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Retounen yon referans a yon eleman oswa yon subdiksyon depann sou kalite endèks la.
    ///
    /// - Si yo bay yon pozisyon, retounen yon referans a eleman nan pozisyon sa a oswa `None` si soti nan limit.
    ///
    /// - Si yo bay yon seri, retounen subslice ki koresponn a ranje sa a, oswa `None` si soti nan limit.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Retounen yon referans ki ka chanje nan yon eleman oswa yon subdiksyon depann sou kalite endèks la (gade [`get`]) oswa `None` si endèks la soti nan limit.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Retounen yon referans a yon eleman oswa yon subplis, san yo pa fè limit tcheke.
    ///
    /// Pou yon altènativ ki an sekirite al gade [`get`].
    ///
    /// # Safety
    ///
    /// Rele metòd sa a ak yon endèks ki soti nan limit se *[konpòtman endefini]* menm si referans ki kapab lakòz la pa itilize.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEKIRITE: moun kap rele a dwe kenbe pi fò nan kondisyon sekirite pou `get_unchecked`;
        // tranch la se dereferencable paske `self` se yon referans san danje.
        // Konsèy la retounen an sekirite paske impls nan `SliceIndex` gen garanti ke li se.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Retounen yon referans ki ka chanje nan yon eleman oswa yon subplis, san yo pa fè limit tcheke.
    ///
    /// Pou yon altènativ ki an sekirite al gade [`get_mut`].
    ///
    /// # Safety
    ///
    /// Rele metòd sa a ak yon endèks ki soti nan limit se *[konpòtman endefini]* menm si referans ki kapab lakòz la pa itilize.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEKIRITE: moun kap rele a dwe defann kondisyon sekirite pou `get_unchecked_mut`;
        // tranch la se dereferencable paske `self` se yon referans san danje.
        // Konsèy la retounen an sekirite paske impls nan `SliceIndex` gen garanti ke li se.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Retounen yon konsèy anvan tout koreksyon nan tanpon tranch la.
    ///
    /// Moun kap rele a dwe asire ke tranch la surviv konsèy la fonksyon sa a retounen, oswa lòt moun li pral fini montre fatra.
    ///
    /// Moun kap rele a dwe asire tou ke memwa pwen (non-transitively) pwen yo pa janm ekri (eksepte andedan yon `UnsafeCell`) lè l sèvi avèk konsèy sa a oswa nenpòt konsèy ki soti nan li.
    /// Si ou bezwen mitasyon sa ki nan tranch la, sèvi ak [`as_mut_ptr`].
    ///
    /// Modifye veso a referansye pa tranch sa a ka lakòz tanpon li yo dwe réaffectés, ki ta tou fè nenpòt ki endikasyon li envalid.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Retounen yon konsèy danjere san danje nan pezib tranch la.
    ///
    /// Moun kap rele a dwe asire ke tranch la surviv konsèy la fonksyon sa a retounen, oswa lòt moun li pral fini montre fatra.
    ///
    /// Modifye veso a referansye pa tranch sa a ka lakòz tanpon li yo dwe réaffectés, ki ta tou fè nenpòt ki endikasyon li envalid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Retounen de endikasyon yo anvan tout koreksyon spanning tranch la.
    ///
    /// Ranje a retounen se demi-louvri, ki vle di ke pwen yo fen pwen *yon sèl sot pase yo* eleman ki sot pase a nan tranch la.
    /// Fason sa a, se yon tranch vid reprezante pa de endikasyon egal, ak diferans ki genyen ant de endikasyon yo reprezante gwosè a nan tranch la.
    ///
    /// Gade [`as_ptr`] pou avètisman sou lè l sèvi avèk endikasyon sa yo.Konsèy la fen mande pou prekosyon siplemantè, menm jan li pa lonje dwèt sou yon eleman ki valab nan tranch la.
    ///
    /// Fonksyon sa a itil pou kominike avèk interfaces etranje ki itilize de endikasyon pou refere a yon seri de eleman nan memwa, menm jan se komen nan C++ .
    ///
    ///
    /// Li kapab itil tou pou tcheke si yon konsèy nan yon eleman refere a yon eleman nan tranch sa a:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SEKIRITE: `add` isit la an sekirite, paske:
        //
        //   - Tou de endikasyon yo se yon pati nan objè a menm, kòm montre dirèkteman sot pase objè a tou konte.
        //
        //   - Gwosè a nan tranch la pa janm pi gwo pase isize::MAX bytes, jan yo note sa isit la:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Pa gen okenn anbalaj alantou patisipe, tankou tranch pa vlope sot pase yo nan fen espas adrès la.
        //
        // Gade dokiman pointer::add la.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Retounen de endikasyon yo ki an sekirite mityèl spanning tranch la.
    ///
    /// Ranje a retounen se demi-louvri, ki vle di ke pwen yo fen pwen *yon sèl sot pase yo* eleman ki sot pase a nan tranch la.
    /// Fason sa a, se yon tranch vid reprezante pa de endikasyon egal, ak diferans ki genyen ant de endikasyon yo reprezante gwosè a nan tranch la.
    ///
    /// Gade [`as_mut_ptr`] pou avètisman sou lè l sèvi avèk endikasyon sa yo.
    /// Konsèy la fen mande pou prekosyon siplemantè, menm jan li pa lonje dwèt sou yon eleman valab nan tranch la.
    ///
    /// Fonksyon sa a itil pou kominike avèk interfaces etranje ki itilize de endikasyon pou refere a yon seri de eleman nan memwa, menm jan se komen nan C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SEKIRITE: Gade as_ptr_range() pi wo a poukisa `add` isit la an sekirite.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Echanj de eleman nan tranch la.
    ///
    /// # Arguments
    ///
    /// * a, endèks premye eleman an
    /// * b, endèks dezyèm eleman an
    ///
    /// # Panics
    ///
    /// Panics si `a` oswa `b` yo soti nan limit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Pa ka pran de prè mutable soti nan yon sèl vector, se konsa olye sèvi ak endikasyon anvan tout koreksyon.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SEKIRITE: `pa` ak `pb` yo te kreye nan referans san danje epi chanje
        // eleman nan tranch lan ak Se poutèt sa yo garanti yo dwe valab ak aliyen.
        // Remake byen ke gen aksè nan eleman yo dèyè `a` ak `b` tcheke epi yo pral panic lè soti nan limit.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Ranvèse lòd eleman nan tranch la, an plas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Pou kalite piti anpil, tout moun nan li nan chemen nòmal la fè mal.
        // Nou ka fè pi byen, bay efikas load/store san aliyen, pa chaje yon moso pi gwo ak ranvèse yon enskri.
        //

        // Idealman LLVM ta fè sa pou nou, menm jan li konnen pi byen pase nou fè si wi ou non li aliyen yo efikas (depi ki chanje ant diferan vèsyon ARM, pou egzanp) ak sa ki gwosè a moso pi bon ta dwe.
        // Malerezman, tankou nan LLVM 4.0 (2017-05) li sèlman dewoulman bouk la, kidonk nou bezwen fè sa tèt nou.
        // (Ipotèz: ranvèse se anbarasman paske kote sa yo ka aliyen yon fason diferan-yo pral, lè longè a se enpè-Se konsa, gen nan pa gen fason pou emèt pre-ak postlude yo sèvi ak konplètman-aliyen SIMD nan mitan an.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Sèvi ak llvm.bswap intrinsèks la ranvèse u8s nan yon usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SEKIRITE: Gen plizyè bagay pou tcheke isit la:
                //
                // - Remake byen ke `chunk` se swa 4 oswa 8 akòz chèk la cfg pi wo a.Se konsa, `chunk - 1` se pozitif.
                // - Indexing ak endèks `i` se amann kòm chèk la garanti garanti
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indexing ak endèks `ln - i - chunk = ln - (i + chunk)` se amann:
                //   - `i + chunk > 0` se trivial vre.
                //   - Chèk la bouk garanti:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, konsa soustraksyon pa underflow.
                // - Apèl `read_unaligned` ak `write_unaligned` yo anfòm:
                //   - `pa` pwen endèks `i` kote `i < ln / 2 - (chunk - 1)` (gade pi wo a) ak `pb` pwen endèks `ln - i - chunk`, kidonk tou de se omwen `chunk` anpil bytes lwen fen `self`.
                //
                //   - Nenpòt inisyalize memwa valab `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Sèvi ak Thorne-pa-16 ranvèse u16s nan yon u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SEKIRITE: Yon u32 ki pa aliyen ka li nan `i` si `i + 1 < ln`
                // (ak evidamman `i < ln`), paske chak eleman se 2 bytes epi nou ap li 4.
                //
                // `i + chunk - 1 < ln / 2` # pandan y ap kondisyon
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Depi li nan mwens pase longè a divize pa 2, Lè sa a, li dwe nan limit.
                //
                // Sa vle di tou ke kondisyon `0 < i + chunk <= ln` la toujou respekte, asire ke konsèy `pb` la ka itilize san danje.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SEKIRITE: `i` enferyè a mwatye longè tranch lan konsa
            // aksè `i` ak `ln - i - 1` san danje (`i` kòmanse nan 0 epi yo pa pral ale pi lwen pase `ln / 2 - 1`).
            // Endikasyon ki kapab lakòz `pa` ak `pb` yo Se poutèt sa valab ak aliyen, epi yo ka li nan epi ekri nan.
            //
            //
            unsafe {
                // Swap ensekirite pou fè pou evite limit yo tcheke nan swap san danje.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Retounen yon iteratè sou tranch la.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Retounen yon iteratè ki pèmèt modifye chak valè.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Retounen yon iteratè sou tout windows vwazen nan longè `size`.
    /// windows a sipèpoze.
    /// Si tranch la pi kout pase `size`, iteratè a pa retounen valè.
    ///
    /// # Panics
    ///
    /// Panics si `size` se 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si tranch la pi kout pase `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Retounen yon iteratè sou eleman `chunk_size` nan tranch lan nan yon moman, kòmanse nan kòmansman tranch lan.
    ///
    /// Moso yo se tranch epi yo pa sipèpoze.Si `chunk_size` pa divize longè tranch lan, lè sa a dènye moso a pap gen longè `chunk_size`.
    ///
    /// Al gade nan [`chunks_exact`] pou yon Variant nan iteratè sa a ki retounen fragman nan toujou egzakteman `chunk_size` eleman, ak [`rchunks`] pou iteratè a menm, men kòmanse nan fen tranch la.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` se 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Retounen yon iteratè sou eleman `chunk_size` nan tranch lan nan yon moman, kòmanse nan kòmansman tranch lan.
    ///
    /// Moso yo se tranch mitab, epi yo pa sipèpoze.Si `chunk_size` pa divize longè tranch lan, lè sa a dènye moso a pap gen longè `chunk_size`.
    ///
    /// Al gade nan [`chunks_exact_mut`] pou yon Variant nan iteratè sa a ki retounen fragman nan toujou egzakteman `chunk_size` eleman, ak [`rchunks_mut`] pou iteratè a menm, men kòmanse nan fen tranch la.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` se 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Retounen yon iteratè sou eleman `chunk_size` nan tranch lan nan yon moman, kòmanse nan kòmansman tranch lan.
    ///
    /// Moso yo se tranch epi yo pa sipèpoze.
    /// Si `chunk_size` pa divize longè tranch lan, Lè sa a, dènye jiska `chunk_size-1` eleman yo pral omisyon epi yo ka Retrieved soti nan fonksyon an `remainder` nan iteratè la.
    ///
    ///
    /// Akòz chak moso ki gen egzakteman eleman `chunk_size`, du a ka souvan optimize kòd la ki kapab lakòz pi bon pase nan ka [`chunks`].
    ///
    /// Al gade nan [`chunks`] pou yon Variant nan iteratè sa a ki retounen tou rès la kòm yon moso ki pi piti, ak [`rchunks_exact`] pou iteratè a menm, men kòmanse nan fen tranch la.
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` se 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Retounen yon iteratè sou eleman `chunk_size` nan tranch lan nan yon moman, kòmanse nan kòmansman tranch lan.
    ///
    /// Moso yo se tranch mitab, epi yo pa sipèpoze.
    /// Si `chunk_size` pa divize longè tranch lan, Lè sa a, dènye jiska `chunk_size-1` eleman yo pral omisyon epi yo ka Retrieved soti nan fonksyon an `into_remainder` nan iteratè la.
    ///
    ///
    /// Akòz chak moso ki gen egzakteman eleman `chunk_size`, du a ka souvan optimize kòd la ki kapab lakòz pi bon pase nan ka [`chunks_mut`].
    ///
    /// Al gade nan [`chunks_mut`] pou yon Variant nan iteratè sa a ki retounen tou rès la kòm yon moso ki pi piti, ak [`rchunks_exact_mut`] pou iteratè a menm, men kòmanse nan fen tranch la.
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` se 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Divize tranch lan nan yon tranch nan ranje 'N`-eleman, an konsideran ke pa gen okenn rès.
    ///
    ///
    /// # Safety
    ///
    /// Sa ka rele sèlman lè
    /// - Tranch la divize egzakteman nan moso N-eleman (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SEKIRITE: fragman 1-eleman pa janm gen rès
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SEKIRITE: (6) longè tranch la se yon miltip nan 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Sa yo ta dwe solid:
    /// // kite moso: &[[_;5]]= slice.as_chunks_unchecked()//Longè a tranch se pa yon miltip nan 5 kite fragman:&[[_;0]]= slice.as_chunks_unchecked()//Zewo-longè moso yo pa janm pèmèt
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEKIRITE: Kondisyon nou an se egzakteman sa ki nesesè yo rele sa a
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEKIRITE: Nou jete yon tranch nan eleman `new_len * N` nan
        // yon tranch `new_len` anpil moso `N` eleman.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Divize tranch lan nan yon tranch nan ranje 'N`-eleman, kòmanse nan kòmansman tranch la, ak yon tranch rès ak longè entèdi mwens pase `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` se 0. Chèk sa a pral pi pwobableman chanje nan yon erè tan konpile anvan metòd sa a vin estabilize.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SEKIRITE: Nou deja panike pou zewo, ak asire pa konstriksyon
        // ke longè subslice a se yon miltip nan N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Divize tranch lan nan yon tranch nan ranje 'N`-eleman, kòmanse nan fen tranch la, ak yon tranch rès ak longè entèdi mwens pase `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` se 0. Chèk sa a pral pi pwobableman chanje nan yon erè tan konpile anvan metòd sa a vin estabilize.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SEKIRITE: Nou deja panike pou zewo, ak asire pa konstriksyon
        // ke longè subslice a se yon miltip nan N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Retounen yon iteratè sou eleman `N` nan tranch lan nan yon moman, kòmanse nan kòmansman tranch lan.
    ///
    /// Fragman yo se referans etalaj epi yo pa sipèpoze.
    /// Si `N` pa divize longè tranch lan, Lè sa a, dènye jiska `N-1` eleman yo pral omisyon epi yo ka Retrieved soti nan fonksyon an `remainder` nan iteratè la.
    ///
    ///
    /// Metòd sa a se ekivalan konst jenerik [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics si `N` se 0. Chèk sa a pral pi pwobableman chanje nan yon erè tan konpile anvan metòd sa a vin estabilize.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Divize tranch lan nan yon tranch nan ranje 'N`-eleman, an konsideran ke pa gen okenn rès.
    ///
    ///
    /// # Safety
    ///
    /// Sa ka rele sèlman lè
    /// - Tranch la divize egzakteman nan moso N-eleman (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SEKIRITE: fragman 1-eleman pa janm gen rès
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SEKIRITE: (6) longè tranch la se yon miltip nan 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Sa yo ta dwe solid:
    /// // kite moso: &[[_;5]]= slice.as_chunks_unchecked_mut()//Longè a tranch se pa yon miltip nan 5 kite fragman:&[[_;0]]= slice.as_chunks_unchecked_mut()//Zewo-longè moso yo pa janm pèmèt
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEKIRITE: Kondisyon nou an se egzakteman sa ki nesesè yo rele sa a
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEKIRITE: Nou jete yon tranch nan eleman `new_len * N` nan
        // yon tranch `new_len` anpil moso `N` eleman.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Divize tranch lan nan yon tranch nan ranje 'N`-eleman, kòmanse nan kòmansman tranch la, ak yon tranch rès ak longè entèdi mwens pase `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` se 0. Chèk sa a pral pi pwobableman chanje nan yon erè tan konpile anvan metòd sa a vin estabilize.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SEKIRITE: Nou deja panike pou zewo, ak asire pa konstriksyon
        // ke longè subslice a se yon miltip nan N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Divize tranch lan nan yon tranch nan ranje 'N`-eleman, kòmanse nan fen tranch la, ak yon tranch rès ak longè entèdi mwens pase `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` se 0. Chèk sa a pral pi pwobableman chanje nan yon erè tan konpile anvan metòd sa a vin estabilize.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SEKIRITE: Nou deja panike pou zewo, ak asire pa konstriksyon
        // ke longè subslice a se yon miltip nan N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Retounen yon iteratè sou eleman `N` nan tranch lan nan yon moman, kòmanse nan kòmansman tranch lan.
    ///
    /// Fragman yo se referans etalaj mutabl epi yo pa sipèpoze.
    /// Si `N` pa divize longè tranch lan, Lè sa a, dènye jiska `N-1` eleman yo pral omisyon epi yo ka Retrieved soti nan fonksyon an `into_remainder` nan iteratè la.
    ///
    ///
    /// Metòd sa a se ekivalan konst jenerik [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics si `N` se 0. Chèk sa a pral pi pwobableman chanje nan yon erè tan konpile anvan metòd sa a vin estabilize.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Retounen yon iteratè sipèpoze windows nan eleman `N` nan yon tranch, kòmanse nan kòmansman tranch lan.
    ///
    ///
    /// Sa a se ekivalan konst jenerik [`windows`].
    ///
    /// Si `N` pi gran pase gwosè tranch la, li pap retounen windows.
    ///
    /// # Panics
    ///
    /// Panics si `N` se 0.
    /// Chèk sa a pral pi pwobableman chanje nan yon erè tan konpile anvan metòd sa a vin estabilize.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Retounen yon iteratè sou eleman `chunk_size` nan tranch la nan yon moman, kòmanse nan fen tranch la.
    ///
    /// Moso yo se tranch epi yo pa sipèpoze.Si `chunk_size` pa divize longè tranch lan, lè sa a dènye moso a pap gen longè `chunk_size`.
    ///
    /// Al gade nan [`rchunks_exact`] pou yon Variant nan iteratè sa a ki retounen fragman nan toujou egzakteman `chunk_size` eleman, ak [`chunks`] pou iteratè a menm, men kòmanse nan kòmansman an nan tranch la.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` se 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Retounen yon iteratè sou eleman `chunk_size` nan tranch la nan yon moman, kòmanse nan fen tranch la.
    ///
    /// Moso yo se tranch mitab, epi yo pa sipèpoze.Si `chunk_size` pa divize longè tranch lan, lè sa a dènye moso a pap gen longè `chunk_size`.
    ///
    /// Al gade nan [`rchunks_exact_mut`] pou yon Variant nan iteratè sa a ki retounen fragman nan toujou egzakteman `chunk_size` eleman, ak [`chunks_mut`] pou iteratè a menm, men kòmanse nan kòmansman an nan tranch la.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` se 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Retounen yon iteratè sou eleman `chunk_size` nan tranch la nan yon moman, kòmanse nan fen tranch la.
    ///
    /// Moso yo se tranch epi yo pa sipèpoze.
    /// Si `chunk_size` pa divize longè tranch lan, Lè sa a, dènye jiska `chunk_size-1` eleman yo pral omisyon epi yo ka Retrieved soti nan fonksyon an `remainder` nan iteratè la.
    ///
    /// Akòz chak moso ki gen egzakteman eleman `chunk_size`, du a ka souvan optimize kòd la ki kapab lakòz pi bon pase nan ka [`chunks`].
    ///
    /// Al gade nan [`rchunks`] pou yon Variant nan iteratè sa a ki retounen tou rès la kòm yon moso ki pi piti, ak [`chunks_exact`] pou iteratè a menm, men kòmanse nan konmansman an nan tranch la.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` se 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Retounen yon iteratè sou eleman `chunk_size` nan tranch la nan yon moman, kòmanse nan fen tranch la.
    ///
    /// Moso yo se tranch mitab, epi yo pa sipèpoze.
    /// Si `chunk_size` pa divize longè tranch lan, Lè sa a, dènye jiska `chunk_size-1` eleman yo pral omisyon epi yo ka Retrieved soti nan fonksyon an `into_remainder` nan iteratè la.
    ///
    /// Akòz chak moso ki gen egzakteman eleman `chunk_size`, du a ka souvan optimize kòd la ki kapab lakòz pi bon pase nan ka [`chunks_mut`].
    ///
    /// Al gade nan [`rchunks_mut`] pou yon Variant nan iteratè sa a ki retounen tou rès la kòm yon moso ki pi piti, ak [`chunks_exact_mut`] pou iteratè a menm, men kòmanse nan konmansman an nan tranch la.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` se 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Retounen yon iteratè sou tranch la pwodwi ki pa sipèpoze kouri nan eleman lè l sèvi avèk predikate a separe yo.
    ///
    /// Se predikatif la rele sou de eleman sa yo tèt yo, sa vle di se predikatif la rele sou `slice[0]` ak `slice[1]` Lè sa a, sou `slice[1]` ak `slice[2]` ak sou sa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Metòd sa a ka itilize pou ekstrè subklis yo klase:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Retounen yon iteratè sou tranch la pwodwi ki pa sipèpoze kouri mitab nan eleman lè l sèvi avèk predikate a separe yo.
    ///
    /// Se predikatif la rele sou de eleman sa yo tèt yo, sa vle di se predikatif la rele sou `slice[0]` ak `slice[1]` Lè sa a, sou `slice[1]` ak `slice[2]` ak sou sa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Metòd sa a ka itilize pou ekstrè subklis yo klase:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Divize yon sèl tranch an de nan yon endèks.
    ///
    /// Premye a ap gen ladan tout endis ki soti nan `[0, mid)` (eksepte endèks la `mid` tèt li) ak dezyèm lan ap gen ladan tout endis ki soti nan `[mid, len)` (eksepte endèks la `len` tèt li).
    ///
    ///
    /// # Panics
    ///
    /// Panics si `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SEKIRITE: `[ptr; mid]` ak `[mid; len]` yo andedan `self`, ki
        // satisfè kondisyon ki nan `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Divize yon sèl tranch ki ka chanje an de nan yon endèks.
    ///
    /// Premye a ap gen ladan tout endis ki soti nan `[0, mid)` (eksepte endèks la `mid` tèt li) ak dezyèm lan ap gen ladan tout endis ki soti nan `[mid, len)` (eksepte endèks la `len` tèt li).
    ///
    ///
    /// # Panics
    ///
    /// Panics si `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SEKIRITE: `[ptr; mid]` ak `[mid; len]` yo andedan `self`, ki
        // satisfè kondisyon ki nan `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Divize yon sèl tranch an de nan yon endèks, san yo pa fè limit tcheke.
    ///
    /// Premye a ap gen ladan tout endis ki soti nan `[0, mid)` (eksepte endèks la `mid` tèt li) ak dezyèm lan ap gen ladan tout endis ki soti nan `[mid, len)` (eksepte endèks la `len` tèt li).
    ///
    ///
    /// Pou yon altènativ ki an sekirite al gade [`split_at`].
    ///
    /// # Safety
    ///
    /// Rele metòd sa a ak yon endèks deyò-limit se *[konpòtman endefini]* menm si referans ki kapab lakòz la pa itilize.Moun kap rele a gen asire ke `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SEKIRITE: Moun kap rele a dwe tcheke ke `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Divize yon sèl tranch mutable an de nan yon endèks, san yo pa fè limit tcheke.
    ///
    /// Premye a ap gen ladan tout endis ki soti nan `[0, mid)` (eksepte endèks la `mid` tèt li) ak dezyèm lan ap gen ladan tout endis ki soti nan `[mid, len)` (eksepte endèks la `len` tèt li).
    ///
    ///
    /// Pou yon altènativ ki an sekirite al gade [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Rele metòd sa a ak yon endèks deyò-limit se *[konpòtman endefini]* menm si referans ki kapab lakòz la pa itilize.Moun kap rele a gen asire ke `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SEKIRITE: Moun kap rele a dwe tcheke ke `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` ak `[mid; len]` yo pa sipèpoze, se konsa retounen yon referans mutable se amann.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Retounen yon iteratè sou subslices separe pa eleman ki matche ak `pred`.
    /// Eleman matche a pa genyen nan subklizyon yo.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si eleman nan premye matche, yon tranch vid yo pral atik la premye retounen pa iterateur la.
    /// Menm jan an tou, si eleman ki sot pase a nan tranch la matche, yon tranch vid yo pral dènye atik la tounen pa iteratè a:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si de eleman matche dirèkteman adjasan, yon tranch vid ap prezan ant yo:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Retounen yon iteratè sou subklas mutabl separe pa eleman ki matche ak `pred`.
    /// Eleman matche a pa genyen nan subklizyon yo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Retounen yon iteratè sou subslices separe pa eleman ki matche ak `pred`.
    /// Eleman matche a genyen nan fen subslice anvan an kòm yon tèminatè.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si dènye eleman tranch la matche, eleman sa ap konsidere kòm tèminatè tranch ki vin anvan an.
    ///
    /// Tranch sa a pral dènye atik ke iteratè a retounen.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Retounen yon iteratè sou subklas mutabl separe pa eleman ki matche ak `pred`.
    /// Eleman matche a genyen nan subplas anvan an kòm yon tèminatè.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Retounen yon iteratè sou subslices separe pa eleman ki matche ak `pred`, kòmanse nan fen tranch lan ak travay bak.
    /// Eleman matche a pa genyen nan subklizyon yo.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Menm jan ak `split()`, si eleman an premye oswa dènye matche, yon tranch vid yo pral premye (oswa dènye) atik la tounen pa iteratè la.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Retounen yon iteratè sou subslices mutable separe pa eleman ki matche ak `pred`, kòmanse nan fen tranch la ak travay bak.
    /// Eleman matche a pa genyen nan subklizyon yo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Retounen yon iteratè sou subslices separe pa eleman ki matche ak `pred`, limite a retounen nan pifò atik `n`.
    /// Eleman matche a pa genyen nan subklizyon yo.
    ///
    /// Eleman nan dènye retounen, si genyen, ap gen rès la nan tranch la.
    ///
    /// # Examples
    ///
    /// Ekri an lèt detache tranch la yon fwa pa nimewo divizib pa 3 (sa vle di, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Retounen yon iteratè sou subslices separe pa eleman ki matche ak `pred`, limite a retounen nan pifò atik `n`.
    /// Eleman matche a pa genyen nan subklizyon yo.
    ///
    /// Eleman nan dènye retounen, si genyen, ap gen rès la nan tranch la.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Retounen yon iteratè sou subslices separe pa eleman ki matche ak `pred` limite a retounen nan pifò atik `n`.
    /// Sa a kòmanse nan fen tranch la ak travay bak.
    /// Eleman matche a pa genyen nan subklizyon yo.
    ///
    /// Eleman nan dènye retounen, si genyen, ap gen rès la nan tranch la.
    ///
    /// # Examples
    ///
    /// Ekri an lèt detache tranch la yon fwa, kòmanse nan fen a, pa nimewo divizib pa 3 (sa vle di, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Retounen yon iteratè sou subslices separe pa eleman ki matche ak `pred` limite a retounen nan pifò atik `n`.
    /// Sa a kòmanse nan fen tranch la ak travay bak.
    /// Eleman matche a pa genyen nan subklizyon yo.
    ///
    /// Eleman nan dènye retounen, si genyen, ap gen rès la nan tranch la.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Retounen `true` si tranch la gen yon eleman ki gen valè yo bay la.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Si ou pa gen yon `&T`, men jis yon `&U` tankou `T: Borrow<U>` (egzanp
    /// `Fisèl: Prete<str>`), ou ka itilize `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // tranch `String`
    /// assert!(v.iter().any(|e| e == "hello")); // rechèch ak `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Retounen `true` si `needle` se yon prefiks nan tranch la.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Toujou retounen `true` si `needle` se yon tranch vid:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Retounen `true` si `needle` se yon sifiks nan tranch la.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Toujou retounen `true` si `needle` se yon tranch vid:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Retounen yon subslice ak prefiks la retire li.
    ///
    /// Si tranch la kòmanse ak `prefix`, retounen subslice a apre prefiks la, vlope nan `Some`.
    /// Si `prefix` vid, tou senpleman retounen tranch orijinal la.
    ///
    /// Si tranch la pa kòmanse ak `prefix`, retounen `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Fonksyon sa a ap bezwen reekri si ak ki lè SlicePattern vin pi sofistike.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Retounen yon subslice ak sifiks la retire li.
    ///
    /// Si tranch la fini ak `suffix`, retounen subslice a anvan sifiks la, vlope nan `Some`.
    /// Si `suffix` vid, tou senpleman retounen tranch orijinal la.
    ///
    /// Si tranch la pa fini ak `suffix`, retounen `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Fonksyon sa a ap bezwen reekri si ak ki lè SlicePattern vin pi sofistike.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binè rechèch tranch sa a Ranje pou yon eleman yo bay yo.
    ///
    /// Si valè a jwenn Lè sa a, [`Result::Ok`] retounen, ki gen endèks la nan eleman nan matche.
    /// Si gen plizyè alimèt, lè sa a nenpòt ki nan alimèt yo ta ka retounen.
    /// Si valè a pa jwenn Lè sa a, [`Result::Err`] retounen, ki gen endèks la kote yon eleman matche ta ka eleman pandan w ap kenbe Ranje lòd.
    ///
    ///
    /// Gade tou [`binary_search_by`], [`binary_search_by_key`], ak [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Chache yon seri de kat eleman.
    /// Premye a jwenn, ak yon pozisyon inikman detèmine;dezyèm lan ak twazyèm yo pa jwenn;katriyèm lan te kapab matche ak nenpòt ki pozisyon nan `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Si ou vle insert yon atik nan yon vector Ranje, pandan w ap kenbe lòd sòt:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binè rechèch tranch sa a Ranje ak yon fonksyon konparatè.
    ///
    /// Fonksyon an konparezon ta dwe aplike yon lòd ki konsistan avèk lòd la sòt nan tranch la kache, retounen yon kòd lòd ki endike si agiman li yo se `Less`, `Equal` oswa `Greater` sib la vle.
    ///
    ///
    /// Si valè a jwenn Lè sa a, [`Result::Ok`] retounen, ki gen endèks la nan eleman nan matche.Si gen plizyè alimèt, Lè sa a, nenpòt ki youn nan alimèt yo ta ka retounen.
    /// Si valè a pa jwenn Lè sa a, [`Result::Err`] retounen, ki gen endèks la kote yon eleman matche ta ka eleman pandan w ap kenbe Ranje lòd.
    ///
    /// Gade tou [`binary_search`], [`binary_search_by_key`], ak [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Chache yon seri de kat eleman.Premye a jwenn, ak yon pozisyon inikman detèmine;dezyèm lan ak twazyèm yo pa jwenn;katriyèm lan te kapab matche ak nenpòt ki pozisyon nan `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SEKIRITE: apèl la fèt san danje pa envariants sa yo:
            // - `mid >= 0`
            // - `mid < size`: `mid` limite pa `[left; right)` mare.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Rezon an pou kisa nou itilize koule kontwòl if/else olye ke matche ak se paske match reorders operasyon konparezon, ki se perf sansib.
            //
            // Sa a se x86 asm pou u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binè rechèch tranch sa a Ranje ak yon fonksyon ekstraksyon kle.
    ///
    /// Sipoze ke tranch la Ranje pa kle a, pou egzanp ak [`sort_by_key`] lè l sèvi avèk menm fonksyon ekstraksyon kle a.
    ///
    /// Si valè a jwenn Lè sa a, [`Result::Ok`] retounen, ki gen endèks la nan eleman nan matche.
    /// Si gen plizyè alimèt, lè sa a nenpòt ki nan alimèt yo ta ka retounen.
    /// Si valè a pa jwenn Lè sa a, [`Result::Err`] retounen, ki gen endèks la kote yon eleman matche ta ka eleman pandan w ap kenbe Ranje lòd.
    ///
    ///
    /// Gade tou [`binary_search`], [`binary_search_by`], ak [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Chache yon seri kat eleman nan yon tranch pè ki klase selon dezyèm eleman yo.
    /// Premye a jwenn, ak yon pozisyon inikman detèmine;dezyèm lan ak twazyèm yo pa jwenn;katriyèm lan te kapab matche ak nenpòt ki pozisyon nan `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links pèmèt tankou `slice::sort_by_key` se nan crate `alloc`, e jan sa pa egziste ankò lè bilding `core`.
    //
    // lyen ki mennen nan en crate: #74481.Depi primitif yo sèlman dokimante nan libstd (#73423), sa pa janm mennen nan lyen kase nan pratik.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Triye tranch la, men li pa ka prezève lòd eleman egal yo.
    ///
    /// Sa a sòt se enstab (sa vle di, pouvwa reorganize eleman egal), an plas (sa vle di, pa asiyen), ak *O*(*n*\*log(* n*)) pi move-ka.
    ///
    /// # Kouran aplikasyon
    ///
    /// Se algorithm aktyèl la ki baze sou [pattern-defeating quicksort][pdqsort] pa Orson Peters, ki konbine ka an mwayèn vit nan randomized quicksort ak ka ki pi mal vit nan heapsort, pandan y ap reyalize tan lineyè sou tranch ak modèl sèten.
    /// Li itilize kèk owaza pou evite ka dejenere, men avèk yon fiks seed pou toujou bay konpòtman detèminis.
    ///
    /// Li se tipikman pi vit pase klasman ki estab, eksepte nan yon kèk ka espesyal, egzanp, lè tranch la konsiste de plizyè sekans triye konekte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Triye tranch la ak yon fonksyon konparatè, men li pa ka prezève lòd eleman egal yo.
    ///
    /// Sa a sòt se enstab (sa vle di, pouvwa reorganize eleman egal), an plas (sa vle di, pa asiyen), ak *O*(*n*\*log(* n*)) pi move-ka.
    ///
    /// Fonksyon konparatè a dwe defini yon kòmann total pou eleman ki nan tranch la.Si kòmann-nan pa total, lòd eleman yo pa espesifye.Yon lòd se yon lòd total si li (pou tout `a`, `b` ak `c`):
    ///
    /// * total ak antisimetri: egzakteman youn nan `a < b`, `a == b` oswa `a > b` se vre, ak
    /// * tranzitif, `a < b` ak `b < c` implique `a < c`.Menm bagay la tou dwe kenbe pou tou de `==` ak `>`.
    ///
    /// Pou egzanp, pandan y ap [`f64`] pa aplike [`Ord`] paske `NaN != NaN`, nou ka itilize `partial_cmp` kòm fonksyon sòt nou an lè nou konnen tranch la pa gen yon `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Kouran aplikasyon
    ///
    /// Se algorithm aktyèl la ki baze sou [pattern-defeating quicksort][pdqsort] pa Orson Peters, ki konbine ka an mwayèn vit nan randomized quicksort ak ka ki pi mal vit nan heapsort, pandan y ap reyalize tan lineyè sou tranch ak modèl sèten.
    /// Li itilize kèk owaza pou evite ka dejenere, men avèk yon fiks seed pou toujou bay konpòtman detèminis.
    ///
    /// Li se tipikman pi vit pase klasman ki estab, eksepte nan yon kèk ka espesyal, egzanp, lè tranch la konsiste de plizyè sekans triye konekte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ranvèse klasman
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Triye tranch la ak yon fonksyon ekstraksyon kle, men li pa ka prezève lòd la nan eleman egal.
    ///
    /// Sa a sòt se enstab (sa vle di, pouvwa reorganize eleman egal), an plas (sa vle di, pa asiyen), ak *O*(m\* * n *\* log(*n*)) pi move-ka, kote fonksyon kle a se *O*(*m*).
    ///
    /// # Kouran aplikasyon
    ///
    /// Se algorithm aktyèl la ki baze sou [pattern-defeating quicksort][pdqsort] pa Orson Peters, ki konbine ka an mwayèn vit nan randomized quicksort ak ka ki pi mal vit nan heapsort, pandan y ap reyalize tan lineyè sou tranch ak modèl sèten.
    /// Li itilize kèk owaza pou evite ka dejenere, men avèk yon fiks seed pou toujou bay konpòtman detèminis.
    ///
    /// Akòz estrateji kle rele li yo, [`sort_unstable_by_key`](#method.sort_unstable_by_key) gen chans rive nan pi dousman pase [`sort_by_cached_key`](#method.sort_by_cached_key) nan ka kote fonksyon kle a chè.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Reorganize tranch lan tankou eleman ki nan `index` se nan pozisyon final li yo klase.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Reorganize tranch la ak yon fonksyon konparatè tankou eleman ki nan `index` se nan pozisyon final klase li yo.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Reorganize tranch la ak yon fonksyon ekstraksyon kle tankou ke eleman nan `index` se nan pozisyon final Ranje li yo.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Reorganize tranch lan tankou eleman ki nan `index` se nan pozisyon final li yo klase.
    ///
    /// Reòdone sa a gen pwopriyete adisyonèl ke nenpòt valè nan pozisyon `i < index` ap mwens pase oswa egal a nenpòt valè nan yon pozisyon `j > index`.
    /// Anplis de sa, reòdone sa a enstab (sètadi
    /// nenpòt ki kantite eleman egal pouvwa fini nan pozisyon `index`), an plas (sa vle di
    /// pa asiyen), ak *O*(*n*) pi move ka-a.
    /// Fonksyon sa a se tou/li te ye tankou "kth element" nan lòt bibliyotèk.
    /// Li retounen yon triplet nan valè sa yo: tout eleman mwens pase yon sèl la nan endèks yo bay la, valè a nan endèks yo bay la, ak tout eleman ki pi konsekan pase yon sèl la nan endèks yo bay la.
    ///
    ///
    /// # Kouran aplikasyon
    ///
    /// Se algorithm aktyèl la ki baze sou pòsyon nan quickselect nan algorithm nan quicksort menm itilize pou [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics lè `index >= len()`, sa vle di li toujou panics sou tranch vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Jwenn medyàn lan
    /// v.select_nth_unstable(2);
    ///
    /// // Nou sèlman garanti tranch la pral youn nan bagay sa yo, ki baze sou fason nou sòt sou endèks la espesifye.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reorganize tranch la ak yon fonksyon konparatè tankou eleman ki nan `index` se nan pozisyon final klase li yo.
    ///
    /// Reòdone sa a gen pwopriyete adisyonèl ke nenpòt valè nan pozisyon `i < index` pral mwens pase oswa egal a nenpòt valè nan yon pozisyon `j > index` lè l sèvi avèk fonksyon an konparezon.
    /// Anplis de sa, reòdone sa a enstab (sètadi nenpòt ki kantite eleman egal pouvwa fini nan pozisyon `index`), an plas (sètadi pa asiyen), ak *O*(*n*) pi move-ka.
    /// Fonksyon sa a ke yo rele tou "kth element" nan lòt bibliyotèk yo.
    /// Li retounen yon triplet nan valè sa yo: tout eleman mwens pase yon sèl la nan endèks yo bay la, valè a nan endèks yo bay la, ak tout eleman ki pi konsekan pase yon sèl la nan endèks yo bay la, lè l sèvi avèk fonksyon an konparezon bay yo.
    ///
    ///
    /// # Kouran aplikasyon
    ///
    /// Se algorithm aktyèl la ki baze sou pòsyon nan quickselect nan algorithm nan quicksort menm itilize pou [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics lè `index >= len()`, sa vle di li toujou panics sou tranch vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Jwenn medyàn lan tankou si tranch la te klase nan lòd desandan.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Nou sèlman garanti tranch la pral youn nan bagay sa yo, ki baze sou fason nou sòt sou endèks la espesifye.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Reorganize tranch la ak yon fonksyon ekstraksyon kle tankou ke eleman nan `index` se nan pozisyon final Ranje li yo.
    ///
    /// Reòdone sa a gen pwopriyete adisyonèl ke nenpòt valè nan pozisyon `i < index` pral mwens pase oswa egal a nenpòt valè nan yon pozisyon `j > index` lè l sèvi avèk fonksyon ekstraksyon kle a.
    /// Anplis de sa, reòdone sa a enstab (sètadi nenpòt ki kantite eleman egal pouvwa fini nan pozisyon `index`), an plas (sètadi pa asiyen), ak *O*(*n*) pi move-ka.
    /// Fonksyon sa a ke yo rele tou "kth element" nan lòt bibliyotèk yo.
    /// Li retounen yon triplet nan valè sa yo: tout eleman mwens pase yon sèl la nan endèks yo bay la, valè a nan endèks yo bay la, ak tout eleman ki pi konsekan pase yon sèl la nan endèks yo bay la, lè l sèvi avèk bay fonksyon an ekstraksyon kle.
    ///
    ///
    /// # Kouran aplikasyon
    ///
    /// Se algorithm aktyèl la ki baze sou pòsyon nan quickselect nan algorithm nan quicksort menm itilize pou [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics lè `index >= len()`, sa vle di li toujou panics sou tranch vid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Retounen medyàn lan tankou si etalaj la te klase selon valè absoli.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Nou sèlman garanti tranch la pral youn nan bagay sa yo, ki baze sou fason nou sòt sou endèks la espesifye.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Deplase tout eleman repete youn apre lòt nan fen tranch lan selon aplikasyon [`PartialEq`] trait la.
    ///
    ///
    /// Retounen de tranch.Premye a pa gen okenn eleman konsekitif repete.
    /// Dezyèm lan gen tout kopi yo nan okenn lòd espesifye.
    ///
    /// Si se tranch la Ranje, premye tranch la retounen pa gen okenn kopi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Deplase tout, men premye nan eleman youn apre lòt nan fen tranch la satisfè yon relasyon egalite bay yo.
    ///
    /// Retounen de tranch.Premye a pa gen okenn eleman konsekitif repete.
    /// Dezyèm lan gen tout kopi yo nan okenn lòd espesifye.
    ///
    /// Fonksyon `same_bucket` la pase referans a de eleman ki soti nan tranch lan epi yo dwe detèmine si eleman yo konpare egal.
    /// Eleman yo pase nan lòd opoze nan lòd yo nan tranch lan, kidonk si `same_bucket(a, b)` retounen `true`, `a` deplase nan fen tranch lan.
    ///
    ///
    /// Si se tranch la Ranje, premye tranch la retounen pa gen okenn kopi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Malgre ke nou gen yon referans mutable nan `self`, nou pa ka fè chanjman *abitrè*.Apèl yo `same_bucket` te kapab panic, kidonk nou dwe asire ke tranch la se nan yon eta ki valab nan tout tan.
        //
        // Fason ke nou okipe sa a se lè l sèvi avèk echanj;nou repete sou tout eleman yo, échanjé jan nou ale pou ke nan fen eleman yo nou ta vle kenbe yo nan devan an, ak moun nou swete rejte yo nan do a.
        // Nou ka Lè sa a, fann tranch la.
        // Operasyon sa a toujou `O(n)`.
        //
        // Egzanp: Nou kòmanse nan eta sa a, kote `r` reprezante "pwochen
        // li "ak `w` reprezante" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Konpare self[r] kont pwòp tèt ou [w-1], sa a se pa yon kopi, se konsa nou swap self[r] ak self[w] (pa gen efè kòm r==w) ak Lè sa a, enkreman tou de r ak w, kite nou ak:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Konpare self[r] kont pwòp tèt ou [w-1], valè sa a se yon kopi, kidonk nou ogmante `r` men kite tout lòt bagay san okenn chanjman:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Konpare self[r] kont pwòp tèt ou [w-1], sa a se pa yon kopi, se konsa swap self[r] ak self[w] ak avanse r ak w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Se pa yon kopi, repete:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Kopi, advance r. End nan tranch.Fann nan w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SEKIRITE: kondisyon `while` la garanti `next_read` ak `next_write`
        // yo mwens pase `len`, kidonk yo andedan `self`.
        // `prev_ptr_write` lonje dwèt sou yon sèl eleman anvan `ptr_write`, men `next_write` kòmanse nan 1, kidonk `prev_ptr_write` pa janm mwens pase 0 e li andedan tranch lan.
        // Sa a ranpli kondisyon yo pou dereferencing `ptr_read`, `prev_ptr_write` ak `ptr_write`, ak pou itilize `ptr.add(next_read)`, `ptr.add(next_write - 1)` ak `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` se tou incrémentiée nan pifò yon fwa pou chak bouk nan pifò siyifikasyon pa gen okenn eleman sote lè li ka bezwen échanges.
        //
        // `ptr_read` ak `prev_ptr_write` pa janm lonje dwèt sou menm eleman an.Sa oblije pou `&mut *ptr_read`, `&mut* prev_ptr_write` an sekirite.
        // Eksplikasyon an se tou senpleman ke `next_read >= next_write` toujou vre, kidonk `next_read > next_write - 1` tou.
        //
        //
        //
        //
        //
        unsafe {
            // Evite limit chèk lè l sèvi avèk endikasyon anvan tout koreksyon.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Deplase tout men premye nan eleman youn apre lòt nan fen tranch la ki rezoud nan kle a menm.
    ///
    ///
    /// Retounen de tranch.Premye a pa gen okenn eleman konsekitif repete.
    /// Dezyèm lan gen tout kopi yo nan okenn lòd espesifye.
    ///
    /// Si se tranch la Ranje, premye tranch la retounen pa gen okenn kopi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Wotasyon tranch la nan plas sa yo ke premye eleman yo `mid` nan tranch la deplase nan fen a pandan y ap dènye `self.len() - mid` eleman yo deplase nan devan an.
    /// Apre ou fin rele `rotate_left`, eleman ki deja nan endèks `mid` ap vin premye eleman nan tranch la.
    ///
    /// # Panics
    ///
    /// Fonksyon sa a pral panic si `mid` pi gran pase longè tranch la.Remake byen ke `mid == self.len()` fè _not_ panic e li se yon wotasyon pa gen okenn-op.
    ///
    /// # Complexity
    ///
    /// Pran lineyè (nan tan `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Wotasyon yon subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SEKIRITE: Ranje `[p.add(mid) - mid, p.add(mid) + k)` la trivial
        // valab pou lekti ak ekri, jan `ptr_rotate` mande sa.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Wotasyon tranch la nan plas sa yo ke premye eleman yo `self.len() - k` nan tranch la deplase nan fen a pandan y ap dènye `k` eleman yo deplase nan devan an.
    /// Apre ou fin rele `rotate_right`, eleman ki deja nan endèks `self.len() - k` ap vin premye eleman nan tranch la.
    ///
    /// # Panics
    ///
    /// Fonksyon sa a pral panic si `k` pi gran pase longè tranch la.Remake byen ke `k == self.len()` fè _not_ panic e li se yon wotasyon pa gen okenn-op.
    ///
    /// # Complexity
    ///
    /// Pran lineyè (nan tan `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Thorne yon subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SEKIRITE: Ranje `[p.add(mid) - mid, p.add(mid) + k)` la trivial
        // valab pou lekti ak ekri, jan `ptr_rotate` mande sa.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Ranpli `self` ak eleman pa klonaj `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Ranpli `self` ak eleman retounen lè w rele yon fèmti repete.
    ///
    /// Metòd sa a itilize yon fèmti pou kreye nouvo valè.Si ou ta pito [`Clone`] yon valè yo bay, sèvi ak [`fill`].
    /// Si ou vle sèvi ak [`Default`] trait la jenere valè, ou ka pase [`Default::default`] kòm agiman an.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopye eleman ki soti nan `src` nan `self`.
    ///
    /// Longè `src` dwe menm ak `self`.
    ///
    /// Si `T` aplike `Copy`, li ka pi performant pou itilize [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Fonksyon sa a pral panic si de tranch yo gen longè diferan.
    ///
    /// # Examples
    ///
    /// Klonaj de eleman ki soti nan yon tranch nan yon lòt:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Paske tranch yo dwe menm longè, nou tranch tranch sous la soti nan kat eleman a de.
    /// // Li pral panic si nou pa fè sa.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ranfòse ke kapab genyen sèlman yon referans mutable ki pa gen okenn referans imuiabl nan yon moso patikilye nan done nan yon sijè ki abòde patikilye.
    /// Poutèt sa, eseye sèvi ak `clone_from_slice` sou yon sèl tranch sa pral lakòz nan yon echèk konpile:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Pou travay alantou sa a, nou ka itilize [`split_at_mut`] yo kreye de distenk sub-tranch ki sòti nan yon tranch:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopi tout eleman ki soti nan `src` nan `self`, lè l sèvi avèk yon memcpy.
    ///
    /// Longè `src` dwe menm ak `self`.
    ///
    /// Si `T` pa aplike `Copy`, itilize [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Fonksyon sa a pral panic si de tranch yo gen longè diferan.
    ///
    /// # Examples
    ///
    /// Kopye de eleman ki soti nan yon tranch nan yon lòt:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Paske tranch yo dwe menm longè, nou tranch tranch sous la soti nan kat eleman a de.
    /// // Li pral panic si nou pa fè sa.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ranfòse ke kapab genyen sèlman yon referans mutable ki pa gen okenn referans imuiabl nan yon moso patikilye nan done nan yon sijè ki abòde patikilye.
    /// Poutèt sa, eseye sèvi ak `copy_from_slice` sou yon sèl tranch sa pral lakòz nan yon echèk konpile:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Pou travay alantou sa a, nou ka itilize [`split_at_mut`] yo kreye de distenk sub-tranch ki sòti nan yon tranch:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Chemen kòd panic la te mete nan yon fonksyon frèt pou pa gonfle sit apèl la.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SEKIRITE: `self` valab pou eleman `self.len()` pa definisyon, e `src` te
        // tcheke pou gen menm longè a.
        // Tranch yo pa ka sipèpoze paske referans mityèl yo eksklizif.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopi eleman ki soti nan yon pati nan tranch lan nan yon lòt pati nan tèt li, lè l sèvi avèk yon memmove.
    ///
    /// `src` se seri a nan `self` kopye soti nan.
    /// `dest` se endèks la kòmanse nan seri a nan `self` kopye nan, ki pral gen menm longè a kòm `src`.
    /// De chenn yo ka sipèpoze.
    /// Pwent yo nan de chenn yo dwe mwens pase oswa egal a `self.len()`.
    ///
    /// # Panics
    ///
    /// Fonksyon sa a pral panic si swa ranje depase nan fen tranch la, oswa si nan fen `src` se anvan kòmansman an.
    ///
    ///
    /// # Examples
    ///
    /// Kopye kat bytes nan yon tranch:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SEKIRITE: kondisyon yo pou `ptr::copy` tout te tcheke pi wo a,
        // menm jan ak sa yo pou `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Swaps tout eleman nan `self` ak sa yo ki nan `other`.
    ///
    /// Longè `other` dwe menm ak `self`.
    ///
    /// # Panics
    ///
    /// Fonksyon sa a pral panic si de tranch yo gen longè diferan.
    ///
    /// # Example
    ///
    /// Twoke de eleman atravè tranch:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust ranfòse ke kapab genyen sèlman yon referans mutable nan yon moso patikilye nan done nan yon sijè ki abòde patikilye.
    ///
    /// Poutèt sa, eseye sèvi ak `swap_with_slice` sou yon sèl tranch sa pral lakòz nan yon echèk konpile:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Pou travay ozalantou sa a, nou ka itilize [`split_at_mut`] yo kreye de distenk mitabl sub-tranch ki sòti nan yon tranch:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SEKIRITE: `self` valab pou eleman `self.len()` pa definisyon, e `src` te
        // tcheke pou gen menm longè a.
        // Tranch yo pa ka sipèpoze paske referans mityèl yo eksklizif.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Fonksyon kalkile longè nan tranch nan mitan ak fin pou `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ki sa nou pral fè sou `rest` se figi konnen ki sa ki miltip nan `U`s nou ka mete nan yon nimewo ki pi ba nan`T`s.
        //
        // Ak konbyen `T` nou bezwen pou chak "multiple" sa yo.
        //
        // Konsidere pou egzanp T=u8 U=u16.Lè sa a, nou ka mete 1 U nan 2 Ts.Senp.
        // Koulye a, konsidere pou egzanp yon ka kote size_of: :<T>=16, size_of::<U>=24.</u>
        // Nou ka mete 2 Us nan plas chak 3 Ts nan tranch `rest` la.
        // Yon ti jan pi konplike.
        //
        // Fòmil pou kalkile sa a se:
        //
        // Nou= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Elaji ak senplifye:
        //
        // Nou=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Chans pou depi tout bagay sa a se konstan-evalye ... pèfòmans isit la zafè pa!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algorithm stein iteratif la Nou ta dwe toujou fè sa a `const fn` (ak retounen nan algorithm repetitif si nou fè sa) paske repoze sou llvm konstal tout bagay sa a se ... byen, li fè m 'alèz.
            //
            //

            // SEKIRITE: `a` ak `b` yo tcheke yo dwe valè ki pa zewo.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // retire tout faktè 2 nan b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SEKIRITE: `b` tcheke pou yo pa zewo.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Ame ak konesans sa a, nou ka jwenn konbyen `U`s nou ka anfòm!
        let us_len = self.len() / ts * us;
        // Ak konbyen `T` yo pral nan tranch la fin!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmute tranch lan nan yon tranch nan yon lòt kalite, asire aliyman nan kalite yo kenbe.
    ///
    /// Metòd sa a divize tranch la nan twa tranch distenk: prefiks, kòrèkteman aliyen tranch presegondè nan yon nouvo kalite, ak tranch la sifiks.
    /// Metòd la ka fè tranch nan mitan longè a pi gran posib pou yon kalite bay ak tranch opinyon, men se sèlman pèfòmans algorithm ou a ta dwe depann sou sa, pa jistès li yo.
    ///
    /// Li akseptab pou tout done yo opinyon yo dwe retounen kòm prefiks la oswa tranch sifiks.
    ///
    /// Metòd sa a pa gen okenn objektif lè swa eleman opinyon `T` oswa pwodiksyon eleman `U` yo zewo-gwosè epi yo pral retounen tranch orijinal la san yo pa divize anyen.
    ///
    /// # Safety
    ///
    /// Metòd sa a se esansyèlman yon `transmute` ki gen rapò ak eleman ki nan tranch nan mitan retounen, se konsa tout avètisman abityèl ki gen rapò ak `transmute::<T, U>` aplike tou isit la.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Remake byen ke pi fò nan fonksyon sa a pral konstan-evalye,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // okipe ZST espesyalman, ki se-pa okipe yo ditou.
            return (self, &[], &[]);
        }

        // Premyèman, jwenn nan ki pwen nou divize ant tranch nan premye ak 2nd.
        // Fasil ak ptr.align_offset.
        let ptr = self.as_ptr();
        // SEKIRITE: Gade metòd `align_to_mut` pou kòmantè sekirite detaye.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SEKIRITE: kounye a `rest` definitivman aliyen, kidonk `from_raw_parts` anba a oke,
            // depi moun kap rele a garanti ke nou ka transmute `T` a `U` san danje.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmute tranch lan nan yon tranch nan yon lòt kalite, asire aliyman nan kalite yo kenbe.
    ///
    /// Metòd sa a divize tranch la nan twa tranch distenk: prefiks, kòrèkteman aliyen tranch presegondè nan yon nouvo kalite, ak tranch la sifiks.
    /// Metòd la ka fè tranch nan mitan longè a pi gran posib pou yon kalite bay ak tranch opinyon, men se sèlman pèfòmans algorithm ou a ta dwe depann sou sa, pa jistès li yo.
    ///
    /// Li akseptab pou tout done yo opinyon yo dwe retounen kòm prefiks la oswa tranch sifiks.
    ///
    /// Metòd sa a pa gen okenn objektif lè swa eleman opinyon `T` oswa pwodiksyon eleman `U` yo zewo-gwosè epi yo pral retounen tranch orijinal la san yo pa divize anyen.
    ///
    /// # Safety
    ///
    /// Metòd sa a se esansyèlman yon `transmute` ki gen rapò ak eleman ki nan tranch nan mitan retounen, se konsa tout avètisman abityèl ki gen rapò ak `transmute::<T, U>` aplike tou isit la.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Remake byen ke pi fò nan fonksyon sa a pral konstan-evalye,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // okipe ZST espesyalman, ki se-pa okipe yo ditou.
            return (self, &mut [], &mut []);
        }

        // Premyèman, jwenn nan ki pwen nou divize ant tranch nan premye ak 2nd.
        // Fasil ak ptr.align_offset.
        let ptr = self.as_ptr();
        // SEKIRITE: Isit la nou ap asire nou pral sèvi ak pwent aliyen pou U pou la
        // rès metòd la.Sa a se fè pa pase yon konsèy nan&[T] ak yon aliyman vize pou U.
        // `crate::ptr::align_offset` yo rele ak yon `ptr` konsèy kòrèkteman aliyen ak valab (li soti nan yon referans a `self`) ak yon gwosè ki se yon pouvwa nan de (depi li soti nan aliyman an pou U), satisfè kontrent sekirite li yo.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Nou pa ka itilize `rest` ankò apre sa, ki ta invalid `mut_ptr` alyas li yo!SEKIRITE: gade kòmantè pou `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Tcheke si eleman sa yo nan tranch yo klase.
    ///
    /// Sa vle di, pou chak eleman `a` ak eleman sa yo `b`, `a <= b` dwe kenbe.Si tranch la bay egzakteman zewo oswa yon eleman, `true` retounen.
    ///
    /// Remake byen ke si `Self::Item` se sèlman `PartialOrd`, men se pa `Ord`, definisyon an pi wo a implique ke fonksyon sa a retounen `false` si nenpòt de atik youn apre lòt yo pa konparab.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Tcheke si eleman yo nan tranch sa a Ranje lè l sèvi avèk fonksyon an konparezon bay yo.
    ///
    /// Olye pou yo itilize `PartialOrd::partial_cmp`, fonksyon sa a itilize fonksyon `compare` yo bay la pou detèmine kòmann-nan de eleman yo.
    /// Apa de sa, li ekivalan a [`is_sorted`];gade dokiman li yo pou plis enfòmasyon.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Tcheke si eleman yo nan tranch sa a Ranje lè l sèvi avèk fonksyon yo bay ekstraksyon kle yo.
    ///
    /// Olye pou yo konpare eleman tranch la dirèkteman, fonksyon sa a konpare kle eleman yo, jan `f` detèmine li.
    /// Apa de sa, li ekivalan a [`is_sorted`];gade dokiman li yo pou plis enfòmasyon.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Retounen endèks la nan pwen an patisyon dapre predikatif yo bay la (endèks la nan eleman nan premye nan dezyèm patisyon an).
    ///
    /// Se tranch la sipoze partition selon predikat yo bay la.
    /// Sa vle di ke tout eleman ki predikatè a retounen vre se nan kòmansman tranch lan ak tout eleman ki predikatè a retounen fo yo nan fen an.
    ///
    /// Pou egzanp, [7, 15, 3, 5, 4, 12, 6] se yon partitioned anba predikat la x% 2!=0 (tout nimewo enpè yo nan kòmansman an, tout menm nan fen a).
    ///
    /// Si tranch sa a pa partition, rezilta a retounen se espesifye ak san sans, menm jan metòd sa a fè yon kalite rechèch binè.
    ///
    /// Gade tou [`binary_search`], [`binary_search_by`], ak [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SEKIRITE: Lè `left < right`, `left <= mid < right`.
            // Se poutèt sa `left` toujou ogmante ak `right` toujou diminye, epi yo chwazi youn nan yo.Nan tou de ka `left <= right` satisfè.Se poutèt sa, si `left < right` nan yon etap, `left <= right` satisfè nan pwochen etap la.
            //
            // Se poutèt sa osi lontan ke `left != right`, `0 <= left < right <= len` satisfè epi si ka sa a `0 <= mid < len` satisfè tou.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Nou bezwen klèman tranch yo nan menm longè a
        // fè li pi fasil pou optimizeur a elimine limit tcheke.
        // Men, depi li pa ka konte sou nou menm tou nou gen yon espesyalizasyon eksplisit pou T: Kopi.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Kreye yon tranch vid.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Kreye yon tranch vid mutable.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Modèl nan tranch, kounye a, sèlman itilize pa `strip_prefix` ak `strip_suffix`.
/// Nan yon pwen future, nou espere jeneralize `core::str::Pattern` (ki nan moman sa a ekri a limite a sa sèlman `str`) nan tranch, ak Lè sa a, sa a trait pral ranplase oswa aboli.
///
pub trait SlicePattern {
    /// Kalite eleman nan tranch la ke yo te matche sou.
    type Item;

    /// Kounye a, konsomatè yo nan `SlicePattern` bezwen yon tranch.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}