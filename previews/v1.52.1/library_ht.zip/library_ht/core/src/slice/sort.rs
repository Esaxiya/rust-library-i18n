//! Tranch klasman
//!
//! Modil sa a gen yon algorithm klasman ki baze sou modèl Orson Peters 'defèt quicksort, pibliye nan: <https://github.com/orlp/pdqsort>
//!
//!
//! Triye enstab konpatib ak libcore paske li pa asiyen memwa, kontrèman ak aplikasyon ki estab klasman nou an.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Lè tonbe, kopi soti nan `src` nan `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SEKIRITE: Sa a se yon klas èd.
        //          Tanpri gade l 'li yo pou kòrèkte.
        //          Savwa, youn dwe asire ke `src` ak `dst` pa sipèpoze jan sa nesesè pa `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Chanje premye eleman adwat la jiskaske li rankontre yon eleman pi gwo oswa egal.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEKIRITE: operasyon ki pa an sekirite anba a enplike nan Indexing san yo pa yon chèk mare (`get_unchecked` ak `get_unchecked_mut`)
    // ak kopye memwa (`ptr::copy_nonoverlapping`).
    //
    // yon.Indexing:
    //  1. Nou tcheke gwosè etalaj la pou>=2.
    //  2. Tout Indexing ke nou pral fè se toujou ant {0 <= index < len} nan pifò.
    //
    // b.Kopi memwa
    //  1. Nou ap jwenn endikasyon referans ki garanti yo dwe valab.
    //  2. Yo pa ka sipèpoze paske nou jwenn endikasyon sou endis diferans nan tranch la.
    //     Savwa, `i` ak `i-1`.
    //  3. Si tranch la byen aliyen, eleman yo byen aliyen.
    //     Se responsablite moun kap rele a pou asire ke tranch lan byen aliyen.
    //
    // Gade kòmantè ki anba a pou plis detay.
    unsafe {
        // Si de premye eleman yo soti nan lòd ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Li eleman nan premye nan yon varyab pile-atribye ba.
            // Si yon operasyon konparezon sa yo panics, `hole` pral jwenn tonbe epi otomatikman ekri eleman an tounen nan tranch la.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Deplase `mwen`-th eleman yon sèl kote sou bò gòch, konsa déplacement twou a sou bò dwat la.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` vin tonbe e konsa kopi `tmp` nan twou ki rete nan `v`.
        }
    }
}

/// Chanje eleman ki sot pase a sou bò gòch jiskaske li rankontre yon eleman ki pi piti oswa egal.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEKIRITE: operasyon ki pa an sekirite anba a enplike nan Indexing san yo pa yon chèk mare (`get_unchecked` ak `get_unchecked_mut`)
    // ak kopye memwa (`ptr::copy_nonoverlapping`).
    //
    // yon.Indexing:
    //  1. Nou tcheke gwosè etalaj la pou>=2.
    //  2. Tout Indexing ke nou pral fè se toujou ant `0 <= index < len-1` nan pifò.
    //
    // b.Kopi memwa
    //  1. Nou ap jwenn endikasyon referans ki garanti yo dwe valab.
    //  2. Yo pa ka sipèpoze paske nou jwenn endikasyon sou endis diferans nan tranch la.
    //     Savwa, `i` ak `i+1`.
    //  3. Si tranch la byen aliyen, eleman yo byen aliyen.
    //     Se responsablite moun kap rele a pou asire ke tranch lan byen aliyen.
    //
    // Gade kòmantè ki anba a pou plis detay.
    unsafe {
        // Si de dènye eleman yo soti nan lòd ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Li eleman ki sot pase a nan yon varyab chemine-atribye ba.
            // Si yon operasyon konparezon sa yo panics, `hole` pral jwenn tonbe epi otomatikman ekri eleman an tounen nan tranch la.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Deplase `mwen`-th eleman yon sèl kote sou bò dwat la, konsa déplacement twou a sou bò gòch la.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` vin tonbe e konsa kopi `tmp` nan twou ki rete nan `v`.
        }
    }
}

/// Pasyèlman kalite yon tranch pa déplacement plizyè eleman soti-nan-lòd alantou.
///
/// Retounen `true` si tranch la klase nan fen an.Fonksyon sa a se *O*(*n*) pi move ka.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Kantite maksimòm pè adjasan ki soti nan lòd ki pral jwenn deplase.
    const MAX_STEPS: usize = 5;
    // Si tranch la pi kout pase sa, pa chanje okenn eleman.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SEKIRITE: Nou deja klèman te fè tcheke a mare ak `i < len`.
        // Tout Indexing ki vin apre nou an se sèlman nan seri a `0 <= index < len`
        unsafe {
            // Jwenn pwochen pè eleman adjasan ki pa nan lòd yo.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Eske nou fini?
        if i == len {
            return true;
        }

        // Pa chanje eleman sou etalaj kout, ki gen yon pri pèfòmans.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Boukante pè eleman yo jwenn yo.Sa mete yo nan lòd kòrèk.
        v.swap(i - 1, i);

        // Chanje eleman ki pi piti a sou bò goch la.
        shift_tail(&mut v[..i], is_less);
        // Chanje eleman ki pi gwo a dwat.
        shift_head(&mut v[i..], is_less);
    }

    // Pa t 'jere sòt tranch la nan kantite limite nan etap.
    false
}

/// Triye yon tranch lè l sèvi avèk sòt ensèsyon, ki se *O*(*n*^ 2) pi move-ka.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Triye `v` lè l sèvi avèk heapsort, ki garanti *O*(*n*\*log(* n*)) pi move-ka.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sa a pil binè respekte envariant `parent >= child` la.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Timoun nan `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Chwazi pi gwo pitit la.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // One Stop si envariant la kenbe nan `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Boukante `node` ak pi gwo pitit la, deplase yon etap desann, epi kontinye tamize.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Bati pil la nan tan lineyè.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop eleman maksimòm soti nan pil la.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partitions `v` nan eleman ki pi piti pase `pivot`, ki te swiv pa eleman ki pi gran pase oswa egal a `pivot`.
///
///
/// Retounen kantite eleman ki pi piti pase `pivot`.
///
/// Se patisyon fè blòk-pa-blòk yo nan lòd pou misyon pou minimize a depans pou operasyon branch.
/// Lide sa a prezante nan papye [BlockQuicksort][pdf] la.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Kantite eleman nan yon blòk tipik.
    const BLOCK: usize = 128;

    // Algorit la patisyon repete etap sa yo jouk fini:
    //
    // 1. Trase yon blòk soti nan bò gòch yo idantifye eleman ki pi gran pase oswa egal a pivot la.
    // 2. Trase yon blòk sou bò dwat la pou idantifye eleman ki pi piti pase pivot la.
    // 3. Echanj eleman yo idantifye ant bò gòch ak bò dwat.
    //
    // Nou kenbe varyab sa yo pou yon blòk eleman:
    //
    // 1. `block` - Kantite eleman ki nan blòk la.
    // 2. `start` - Kòmanse konsèy nan etalaj la `offsets`.
    // 3. `end` - Fen konsèy nan etalaj la `offsets`.
    // 4. `Offsets, Endis nan eleman soti-of-lòd nan blòk la.

    // Blòk aktyèl la sou bò gòch (ki soti nan `l` rive `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Blòk aktyèl la sou bò dwat (ki soti nan `r.sub(block_r)` to `r`).
    // SEKIRITE: Dokiman pou .add() espesyalman mansyone ke `vec.as_ptr().add(vec.len())` toujou an sekirite
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Lè nou jwenn VLAs, eseye kreye yon etalaj longè `min(v.len(), 2 * BLOCK) `pito
    // pase de ranje fiks-gwosè `BLOCK` longè.VLAs ta ka pi efikas kachèt.

    // Retounen kantite eleman ant pwent `l` (inclusive) ak `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Nou fini ak partitioning blòk-pa-blòk lè `l` ak `r` vin trè pre.
        // Lè sa a, nou fè kèk patch-up travay yo nan lòd yo patisyon eleman ki rete yo nan ant.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Kantite eleman ki rete yo (toujou pa konpare ak pivot la).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Ajiste gwosè blòk yo pou blòk gòch ak dwa pa sipèpoze, men jwenn parfe aliyen pou kouvri tout espas ki rete a.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Trase `block_l` eleman ki soti sou bò gòch la.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SEKIRITE: Operasyon ensekirite ki anba yo enplike itilizasyon `offset` la.
                //         Dapre kondisyon fonksyon an egzije a, nou satisfè yo paske:
                //         1. `offsets_l` se chemine-resevwa lajan, e konsa konsidere kòm separe resevwa lajan objè yo.
                //         2. Fonksyon `is_less` la retounen yon `bool`.
                //            Distribisyon yon `bool` pap janm debòde `isize`.
                //         3. Nou garanti ke `block_l` pral `<= BLOCK`.
                //            Plus, `end_l` te okòmansman mete nan konsèy la kòmanse nan `offsets_` ki te deklare sou chemine a.
                //            Se konsa, nou konnen ke menm nan ka ki pi mal la (tout envokasyon nan `is_less` retounen fo) nou pral sèlman nan pifò 1 byte pase fen an.
                //        Yon lòt operasyon ensekirite isit la se dereferencing `elem`.
                //        Sepandan, `elem` te okòmansman konsèy la kòmanse nan tranch la ki se toujou valab.
                unsafe {
                    // Branchless konparezon.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Trase `block_r` eleman ki soti sou bò dwat la.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SEKIRITE: Operasyon ensekirite ki anba yo enplike itilizasyon `offset` la.
                //         Dapre kondisyon fonksyon an egzije a, nou satisfè yo paske:
                //         1. `offsets_r` se chemine-resevwa lajan, e konsa konsidere kòm separe resevwa lajan objè yo.
                //         2. Fonksyon `is_less` la retounen yon `bool`.
                //            Distribisyon yon `bool` pap janm debòde `isize`.
                //         3. Nou garanti ke `block_r` pral `<= BLOCK`.
                //            Plus, `end_r` te okòmansman mete nan konsèy la kòmanse nan `offsets_` ki te deklare sou chemine a.
                //            Se konsa, nou konnen ke menm nan ka ki pi mal la (tout envokasyon nan `is_less` retounen vre) nou pral sèlman nan pifò 1 byte pase fen an.
                //        Yon lòt operasyon ensekirite isit la se dereferencing `elem`.
                //        Sepandan, `elem` te okòmansman `1 *sizeof(T)` sot pase yo nan fen a ak nou dekrement li pa `1* sizeof(T)` anvan aksè li.
                //        Plus, `block_r` te revandike yo dwe mwens pase `BLOCK` ak `elem` pral Se poutèt sa nan pi dwe montre nan konmansman an nan tranch la.
                unsafe {
                    // Branchless konparezon.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Kantite eleman ki soti nan lòd swap ant bò gòch ak bò dwat.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Olye pou yo échanjé yon pè nan moman an, li pi efikas pou fè yon pèmitasyon siklik.
            // Sa a se pa entèdi ekivalan a échanjé, men pwodui yon rezilta menm jan an lè l sèvi avèk mwens operasyon memwa.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Tout eleman ki pa nan lòd nan blòk gòch la te deplase.Deplase nan blòk kap vini an.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Tout eleman ki pa nan lòd nan blòk dwat la te deplase.Deplase nan blòk anvan an.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Tout sa ki rete kounye a se nan pifò yon blòk (swa bò gòch la oswa dwa a) ak eleman soti-of-lòd ki bezwen deplase.
    // Eleman ki rete sa yo ka senpleman deplase nan fen nan blòk yo.
    //

    if start_l < end_l {
        // Blòk gòch la rete.
        // Deplase rès eleman ki pa nan lòd li yo sou bò dwat la.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Blòk la dwa rete.
        // Deplase rès eleman ki pa nan lòd li yo sou bò goch la.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Anyen ankò pou nou fè, nou fini.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitions `v` nan eleman ki pi piti pase `v[pivot]`, ki te swiv pa eleman ki pi gran pase oswa egal a `v[pivot]`.
///
///
/// Retounen yon tupl nan:
///
/// 1. Kantite eleman ki pi piti pase `v[pivot]`.
/// 2. Se vre si `v` te deja partition.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Mete pivot la nan kòmansman tranch.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Li pivot la nan yon varyab chemine-resevwa lajan pou efikasite.
        // Si yon operasyon konparezon sa yo panics, yo pral pivote a otomatikman ekri tounen nan tranch la.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Jwenn premye pè eleman ki pa nan lòd yo.
        let mut l = 0;
        let mut r = v.len();

        // SEKIRITE: Ensekirite ki anba a enplike nan Indexing yon etalaj.
        // Pou youn nan premye: Nou deja fè limit yo tcheke isit la ak `l < r`.
        // Pou youn nan dezyèm: Nou okòmansman gen `l == 0` ak `r == v.len()` epi nou tcheke ke `l < r` nan chak operasyon Indexing.
        //                     Soti isit la nou konnen ke `r` dwe omwen `r == l` ki te montre yo dwe valab soti nan yon sèl la an premye.
        unsafe {
            // Jwenn premye eleman ki pi gran pase oswa egal a pivot la.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Jwenn dènye eleman ki pi piti ke pivot la.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ale soti nan sijè ki abòde epi ekri pivot la (ki se yon varyab chemine-atribye ba) tounen nan tranch la kote li te orijinèlman.
        // Etap sa a se kritik nan asire sekirite!
        //
    };

    // Mete pivot la ant de Partitions yo.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partitions `v` nan eleman egal a `v[pivot]` ki te swiv pa eleman ki pi konsekan pase `v[pivot]`.
///
/// Retounen kantite eleman ki egal ak pivot la.
/// Li sipoze ke `v` pa gen eleman ki pi piti pase pivot la.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Mete pivot la nan kòmansman tranch.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Li pivot la nan yon varyab chemine-resevwa lajan pou efikasite.
    // Si yon operasyon konparezon sa yo panics, yo pral pivote a otomatikman ekri tounen nan tranch la.
    // SEKIRITE: konsèy la isit la valab paske li jwenn nan yon referans a yon tranch.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Koulye a, patisyon tranch la.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SEKIRITE: Ensekirite ki anba a enplike nan Indexing yon etalaj.
        // Pou youn nan premye: Nou deja fè limit yo tcheke isit la ak `l < r`.
        // Pou youn nan dezyèm: Nou okòmansman gen `l == 0` ak `r == v.len()` epi nou tcheke ke `l < r` nan chak operasyon Indexing.
        //                     Soti isit la nou konnen ke `r` dwe omwen `r == l` ki te montre yo dwe valab soti nan yon sèl la an premye.
        unsafe {
            // Jwenn premye eleman ki pi gran pase pivot la.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Jwenn dènye eleman ki egal a pivot la.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Eske nou fini?
            if l >= r {
                break;
            }

            // Swap pè a yo te jwenn nan soti-of-lòd eleman yo.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Nou jwenn eleman `l` egal a pivot la.Add 1 nan kont pou pivot nan tèt li.
    l + 1

    // `_pivot_guard` ale soti nan sijè ki abòde epi ekri pivot la (ki se yon varyab chemine-atribye ba) tounen nan tranch la kote li te orijinèlman.
    // Etap sa a se kritik nan asire sekirite!
}

/// Gaye kèk eleman alantou nan yon tantativ pou kraze modèl ki ta ka lakòz Partitions dezekilib nan quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom nimewo dèlko soti nan papye a "Xorshift RNGs" pa George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Pran nimewo o aza modulo nimewo sa a.
        // Nimewo a adapte nan `usize` paske `len` pa pi gran pase `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Gen kèk kandida pivot ki pral nan tou pre endèks sa a.Se pou yo owaza yo.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Jenere yon nimewo o aza modulo `len`.
            // Sepandan, yo nan lòd pou fè pou evite operasyon koute chè nou premye pran li modulo yon pouvwa nan de, ak Lè sa a, diminye pa `len` jiskaske li adapte nan seri a `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` garanti mwens pase `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Chwazi yon pivot nan `v` epi retounen endèks la ak `true` si tranch la gen anpil chans deja klase.
///
/// Eleman nan `v` ta ka reordered nan pwosesis la.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Longè minimòm pou chwazi metòd medyàn medyàn.
    // Tranch pi kout itilize senp metòd medyàn-nan-twa.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maksimòm kantite echanj ki ka fèt nan fonksyon sa a.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Twa endis tou pre ki nou pral chwazi yon pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Konte kantite total swaps nou pral fè pandan y ap triye endis yo.
    let mut swaps = 0;

    if len >= 8 {
        // Boukantay endis pou `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Boukantay endis pou `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Jwenn medyàn `v[a - 1], v[a], v[a + 1]` epi estoke endèks la nan `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Jwenn medyàn nan katye `a`, `b`, ak `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Jwenn medyàn nan mitan `a`, `b`, ak `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Maksimòm kantite swaps te fèt.
        // Chans yo se tranch la se desann oswa sitou desann, se konsa ranvèse ap pwobableman ede sòt li pi vit.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Triye `v` repetitif.
///
/// Si tranch la te gen yon predesesè nan etalaj orijinal la, li espesifye kòm `pred`.
///
/// `limit` se kantite patisyon pèmèt dezekilib anvan ou chanje nan `heapsort`.
/// Si zewo, fonksyon sa a pral imedyatman chanje nan heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tranch jiska longè sa a jwenn Ranje lè l sèvi avèk sòt ensèsyon.
    const MAX_INSERTION: usize = 20;

    // Se vre si patisyon an dènye te rezonab ekilibre.
    let mut was_balanced = true;
    // Se vre si patisyon an dènye pa melanje eleman (tranch la te deja partition).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Tranch trè kout jwenn Ranje lè l sèvi avèk sòt ensèsyon.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Si twòp chwa pivot move yo te fè, tou senpleman tonbe tounen nan heapsort yo nan lòd yo garanti `O(n * log(n))` pi move-ka.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Si patisyon an dènye te dezekilib, eseye kraze modèl nan tranch la pa mélanger kèk eleman alantou.
        // Nou swete ke nou pral chwazi yon pi bon pivot tan sa a.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Chwazi yon pivot epi eseye devine si wi ou non tranch la deja klase.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Si patisyon an dènye te konvnableman balanse epi yo pa melanje eleman, epi si seleksyon pivot predi tranch la gen anpil chans deja klase ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Eseye idantifye plizyè eleman ki pa nan lòd epi chanje yo nan pozisyon kòrèk.
            // Si tranch la fini konplètman Ranje, nou fini.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Si pivot la chwazi a egal a predesesè a, Lè sa a, li nan eleman ki pi piti a nan tranch la.
        // Patisyon tranch lan nan eleman ki egal ak eleman ki pi konsekan pase pivot la.
        // Ka sa a anjeneral frape lè tranch la gen anpil eleman kopi.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Kontinye klasman eleman ki pi gran pase pivot la.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Patisyon tranch la.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Fann tranch lan nan `left`, `pivot`, ak `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Madichon nan bò ki pi kout la sèlman nan lòd pou misyon pou minimize kantite total apèl repetitif ak konsome mwens espas chemine.
        // Lè sa a, jis kontinye ak bò a pi long (sa a se analogue nan rkursyon ke).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Triye `v` lè l sèvi avèk quicksort modèl-bat, ki se *O*(*n*\*log(* n*)) pi move-ka.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tri pa gen okenn konpòtman ki gen sans sou kalite zewo-gwosè.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limite kantite Partitions dezekilib nan `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Pou tranch jiska longè sa a li pwobableman pi vit tou senpleman sòt yo.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Chwazi yon pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Si pivot la chwazi a egal a predesesè a, Lè sa a, li nan eleman ki pi piti a nan tranch la.
        // Patisyon tranch lan nan eleman ki egal ak eleman ki pi konsekan pase pivot la.
        // Ka sa a anjeneral frape lè tranch la gen anpil eleman kopi.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Si nou te pase endèks nou an, Lè sa a, nou ap bon.
                if mid > index {
                    return;
                }

                // Sinon, kontinye klasman eleman ki pi gran pase pivot la.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Fann tranch lan nan `left`, `pivot`, ak `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Si mitan==endèks, Lè sa a, nou ap fè, depi partition() garanti ke tout eleman apre mitan yo pi gran pase oswa egal a mitan.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Tri pa gen okenn konpòtman ki gen sans sou kalite zewo-gwosè.Pa fè anyen.
    } else if index == v.len() - 1 {
        // Jwenn max eleman epi mete l nan dènye pozisyon etalaj la.
        // Nou lib pou itilize `unwrap()` isit la paske nou konnen v pa dwe vid.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Jwenn min eleman epi mete l nan premye pozisyon etalaj la.
        // Nou lib pou itilize `unwrap()` isit la paske nou konnen v pa dwe vid.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}