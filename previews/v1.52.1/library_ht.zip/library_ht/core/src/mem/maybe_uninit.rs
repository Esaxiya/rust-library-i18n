use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Yon kalite pakè pou konstwi sikonstans inisyalize nan `T`.
///
/// # Initializasyon envariant
///
/// Konpilateur la, an jeneral, sipoze ke se yon varyab byen inisyalize selon kondisyon ki nan kalite varyab la.Pou egzanp, yon varyab nan kalite referans dwe aliyen ak ki pa NULL.
/// Sa a se yon envariant ki dwe *toujou* dwe konfime, menm nan kòd danjere.
/// Kòm yon konsekans, zewo-inisyalizasyon yon varyab nan kalite referans lakòz enstantane [undefined behavior][ub], pa gen pwoblèm si wi ou non ke referans janm vin itilize jwenn aksè nan memwa:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // konpòtman endefini!⚠️
/// // Kòd ekivalan a ak `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // konpòtman endefini!⚠️
/// ```
///
/// Sa a se eksplwate pa du a pou optimize divès kalite, tankou elid chèk kouri-tan ak optimize Layout `enum`.
///
/// Menm jan an tou, antyèman uninitialized memwa ka gen nenpòt ki kontni, pandan y ap yon `bool` dwe toujou `true` oswa `false`.Pakonsekan, kreye yon `bool` uninitialized se konpòtman endefini:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // konpòtman endefini!⚠️
/// // Kòd ekivalan a ak `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // konpòtman endefini!⚠️
/// ```
///
/// Anplis, memwa inisyalize se espesyal nan ke li pa gen yon valè fiks ("fixed" sa vle di "it won't change without being written to").Lekti menm inisyalize byte plizyè fwa ka bay rezilta diferan.
/// Sa fè li konpòtman endefini gen done uninitialized nan yon varyab menm si varyab sa a gen yon kalite nonb antye relatif, ki otreman ka kenbe nenpòt ki modèl *fiks* ti jan:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // konpòtman endefini!⚠️
/// // Kòd ekivalan a ak `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // konpòtman endefini!⚠️
/// ```
/// (Remake ke règleman yo alantou nonb antye relatif antye yo pa finalize ankò, men jiskaske yo, li rekòmande pou fè pou evite yo.)
///
/// Anplis de sa, sonje ke pifò kalite gen envariant adisyonèl pi lwen pase senpleman ke yo te konsidere kòm inisyalize nan nivo kalite.
/// Pou egzanp, yon `1`-inisyalize [`Vec<T>`] konsidere kòm inisyalize (anba aplikasyon aktyèl la; sa a pa konstitye yon garanti ki estab) paske kondisyon an sèlman du a konnen sou li se ke konsèy la done yo dwe ki pa nil.
/// Kreye tankou yon `Vec<T>` pa lakòz *imedya* konpòtman endefini, men yo pral lakòz konpòtman endefini ak operasyon ki pi an sekirite (ki gen ladan jete li).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` sèvi pou pèmèt kòd ki an sekirite pou fè fas ak done ki pa inisyalize.
/// Li se yon siyal nan du a ki endike ke done yo isit la ta ka *pa* dwe inisyalize:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Kreye yon referans klèman uninitialized.
/// // Konpilatè a konnen ke done andedan yon `MaybeUninit<T>` ka valab, e pakonsekan sa a se pa UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Mete li nan yon valè ki valab.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Ekstrè done yo inisyalize-sa a se sèlman pèmèt *apre* byen inisyalize `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Konpilatè a Lè sa a, konnen yo pa fè okenn sipozisyon kòrèk oswa optimize sou kòd sa a.
///
/// Ou ka panse a `MaybeUninit<T>` tankou yo te yon ti jan tankou `Option<T>` men san yo pa nenpòt nan kouri nan tan-swiv ak san yo pa nenpòt nan chèk yo sekirite.
///
/// ## out-pointers
///
/// Ou ka itilize `MaybeUninit<T>` pou aplike "out-pointers": olye pou yo retounen done ki sòti nan yon fonksyon, pase li yon konsèy nan kèk memwa (uninitialized) pou mete rezilta a nan.
/// Sa a ka itil lè li enpòtan pou moun kap rele a kontwole kijan memwa rezilta a estoke nan vin resevwa lajan, epi ou vle pou fè pou evite mouvman nesesè.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` pa lage sa ki fin vye granmoun yo, ki enpòtan.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Koulye a, nou konnen `v` inisyalize!Sa a tou asire ke vector a vin byen tonbe.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inisyalizasyon yon etalaj eleman pa eleman
///
/// `MaybeUninit<T>` ka itilize pou inisyalize yon gwo etalaj eleman pa eleman:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Kreye yon etalaj uninitialized nan `MaybeUninit`.
///     // `assume_init` a san danje paske kalite a nou ap reklame ke yo te inisyalize isit la se yon pakèt moun sou `MaybeUninit`s, ki pa mande pou inisyalizasyon.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Jete yon `MaybeUninit` pa fè anyen.
///     // Se konsa, lè l sèvi avèk devwa konsèy kri olye pou yo `ptr::write` pa lakòz fin vye granmoun valè a uninitialized yo dwe tonbe.
/////
///     // Epitou si gen yon panic pandan bouk sa a, nou gen yon koule memwa, men pa gen okenn pwoblèm sekirite memwa.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Tout bagay inisyalize.
///     // Transmute etalaj la nan kalite inisyalize a.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Ou kapab tou travay avèk etalaj pasyèlman inisyalize, ki ta ka jwenn nan datastructures nivo ki ba.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Kreye yon etalaj uninitialized nan `MaybeUninit`.
/// // `assume_init` a san danje paske kalite a nou ap reklame ke yo te inisyalize isit la se yon pakèt moun sou `MaybeUninit`s, ki pa mande pou inisyalizasyon.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Konte kantite eleman nou asiyen.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Pou chak atik nan etalaj la, lage si nou resevwa lajan li.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inisyalizasyon yon struct jaden-pa-jaden
///
/// Ou ka itilize `MaybeUninit<T>`, ak [`std::ptr::addr_of_mut`] macro, inisyalize structs jaden pa jaden:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inisyalizasyon jaden `name` la
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inisyalizasyon jaden `list` a Si gen yon panic isit la, Lè sa a, `String` a nan jaden an `name` fwit.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Tout jaden yo inisyalize, se konsa nou rele `assume_init` yo ka resevwa yon Foo inisyalize.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` garanti gen menm gwosè, aliyman, ak ABI tankou `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Sepandan sonje ke yon kalite *ki gen* yon `MaybeUninit<T>` se pa nesesèman menm Layout la;Rust pa an jeneral garanti ke jaden yo nan yon `Foo<T>` gen lòd la menm jan ak yon `Foo<U>` menm si `T` ak `U` gen menm gwosè ak aliyman.
///
/// Anplis de sa paske nenpòt valè ti jan valab pou yon `MaybeUninit<T>` du a pa ka aplike non-zero/niche-filling optimizasyon, ki kapab lakòz yon gwosè pi gwo:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Si `T` se FFI-an sekirite, Lè sa a, se konsa `MaybeUninit<T>`.
///
/// Pandan ke `MaybeUninit` se `#[repr(transparent)]` (ki endike li garanti menm gwosè, aliyman, ak ABI tankou `T`), sa pa * chanje okenn nan avètisman anvan yo.
/// `Option<T>` ak `Option<MaybeUninit<T>>` ka toujou gen diferan gwosè, ak kalite ki gen yon jaden nan kalite `T` ka mete deyò (ak gwosè) yon fason diferan pase si jaden sa a te `MaybeUninit<T>`.
/// `MaybeUninit` se yon kalite sendika, ak `#[repr(transparent)]` sou sendika yo enstab (gade [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Apre yon tan, garanti egzak yo nan `#[repr(transparent)]` sou sendika yo ka evolye, ak `MaybeUninit` ka oswa ka pa rete `#[repr(transparent)]`.
/// Sa te di, `MaybeUninit<T>` pral *toujou* garanti ke li gen menm gwosè, aliyman, ak ABI tankou `T`;li jis ke fason `MaybeUninit` aplike ki garanti ka evolye.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang atik pou nou ka vlope lòt kalite ladan li.Sa a itil pou dèlko.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Pa rele `T::clone()`, nou pa ka konnen si nou inisyalize ase pou sa.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Kreye yon nouvo `MaybeUninit<T>` inisyalize ak valè yo bay la.
    /// Li san danje pou rele [`assume_init`] sou valè retou fonksyon sa a.
    ///
    /// Remake byen ke jete yon `MaybeUninit<T>` pa janm ap rele kòd gout `T` a.
    /// Se responsablite w pou asire ke `T` vin tonbe si li te inisyalize.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Kreye yon nouvo `MaybeUninit<T>` nan yon eta inisyalize.
    ///
    /// Remake byen ke jete yon `MaybeUninit<T>` pa janm ap rele kòd gout `T` a.
    /// Se responsablite w pou asire ke `T` vin tonbe si li te inisyalize.
    ///
    /// Gade [type-level documentation][MaybeUninit] la pou kèk egzanp.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Kreye yon nouvo etalaj de atik `MaybeUninit<T>`, nan yon eta inisyalize.
    ///
    /// Note: nan yon future Rust vèsyon metòd sa a ka vin nesesè lè etaks sentaks literal pèmèt [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Egzanp ki anba a te kapab Lè sa a, sèvi ak `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Retounen yon (petèt pi piti) tranch nan done ki te aktyèlman li
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SEKIRITE: Yon `[MaybeUninit<_>; LEN]` inisyalize valab.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Kreye yon nouvo `MaybeUninit<T>` nan yon eta uninitialized, ak memwa a ke yo te ranpli ak `0` bytes.Sa depann de `T` si wi ou non sa deja fè pou inisyalizasyon apwopriye.
    ///
    /// Pou egzanp, `MaybeUninit<usize>::zeroed()` inisyalize, men `MaybeUninit<&'static i32>::zeroed()` se pa paske referans pa dwe nil.
    ///
    /// Remake byen ke jete yon `MaybeUninit<T>` pa janm ap rele kòd gout `T` a.
    /// Se responsablite w pou asire ke `T` vin tonbe si li te inisyalize.
    ///
    /// # Example
    ///
    /// Kòrèk l 'nan fonksyon sa a: inisyalizasyon yon struct ak zewo, kote tout jaden nan struct la ka kenbe ti jan-modèl la 0 kòm yon valè ki valab.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Kòrèk* l 'nan fonksyon sa a: rele `x.zeroed().assume_init()` lè `0` se pa yon ti jan valab-modèl pou kalite a:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Anndan yon pè, nou kreye yon `NotZero` ki pa gen yon diskriminan valab.
    /// // Sa a se konpòtman endefini.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SEKIRITE: `u.as_mut_ptr()` pwen nan atribye ba memwa.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Mete valè `MaybeUninit<T>` la.
    /// Sa a ranplase nenpòt valè anvan san yo pa jete l ', se konsa dwe fè atansyon pa sèvi ak sa a de fwa sof si ou vle sote kouri destriktè a.
    ///
    /// Pou konvenyans ou, sa a tou retounen yon referans mutable a (kounye a san danje inisyalize) sa ki nan `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SEKIRITE: Nou jis inisyalize valè sa a.
        unsafe { self.assume_init_mut() }
    }

    /// Jwenn yon konsèy sou valè ki genyen an.
    /// Lekti soti nan konsèy sa a oswa vire l 'nan yon referans se konpòtman endefini sof si `MaybeUninit<T>` la inisyalize.
    /// Ekri nan memwa ke pwen sa a (non-transitively) pwen yo se konpòtman endefini (eksepte andedan yon `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Itilizasyon kòrèk nan metòd sa a:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Kreye yon referans nan `MaybeUninit<T>` la.Sa a se oke paske nou inisyalize li.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Kòrèk* l 'nan metòd sa a:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Nou te kreye yon referans a yon vector uninitialized!Sa a se konpòtman endefini.⚠️
    /// ```
    ///
    /// (Remake ke règleman yo alantou referans a done inisyalize yo pa finalize ankò, men jiskaske yo, li se rekòmande pou fè pou evite yo.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ak `ManuallyDrop` yo tou de `repr(transparent)` pou nou ka jete konsèy la.
        self as *const _ as *const T
    }

    /// Jwenn yon konsèy mutable valè ki genyen.
    /// Lekti soti nan konsèy sa a oswa vire l 'nan yon referans se konpòtman endefini sof si `MaybeUninit<T>` la inisyalize.
    ///
    /// # Examples
    ///
    /// Itilizasyon kòrèk nan metòd sa a:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Kreye yon referans nan `MaybeUninit<Vec<u32>>` la.
    /// // Sa a se oke paske nou inisyalize li.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Kòrèk* l 'nan metòd sa a:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Nou te kreye yon referans a yon vector uninitialized!Sa a se konpòtman endefini.⚠️
    /// ```
    ///
    /// (Remake ke règleman yo alantou referans a done inisyalize yo pa finalize ankò, men jiskaske yo, li se rekòmande pou fè pou evite yo.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ak `ManuallyDrop` yo tou de `repr(transparent)` pou nou ka jete konsèy la.
        self as *mut _ as *mut T
    }

    /// Ekstrè valè ki soti nan veso a `MaybeUninit<T>`.Sa a se yon bon fason asire ke done yo pral jwenn tonbe, paske `T` a ki kapab lakòz se sijè a manyen la gout abityèl.
    ///
    /// # Safety
    ///
    /// Li se jiska moun kap rele a garanti ke `MaybeUninit<T>` a reyèlman se nan yon eta inisyalize.Rele sa a lè kontni an se pa sa konplètman inisyalize lakòz imedya konpòtman endefini.
    /// [type-level documentation][inv] a gen plis enfòmasyon sou envariant inisyalizasyon sa a.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Anplis de sa, sonje ke pifò kalite gen envariant adisyonèl pi lwen pase senpleman ke yo te konsidere kòm inisyalize nan nivo kalite.
    /// Pou egzanp, yon `1`-inisyalize [`Vec<T>`] konsidere kòm inisyalize (anba aplikasyon aktyèl la; sa a pa konstitye yon garanti ki estab) paske kondisyon an sèlman du a konnen sou li se ke konsèy la done yo dwe ki pa nil.
    ///
    /// Kreye tankou yon `Vec<T>` pa lakòz *imedya* konpòtman endefini, men yo pral lakòz konpòtman endefini ak operasyon ki pi an sekirite (ki gen ladan jete li).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Itilizasyon kòrèk nan metòd sa a:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Kòrèk* l 'nan metòd sa a:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` pa te inisyalize ankò, kidonk dènye liy sa a te lakòz konpòtman endefini.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` inisyalize.
        // Sa vle di tou ke `self` dwe yon Variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Li valè ki soti nan veso a `MaybeUninit<T>`.`T` ki kapab lakòz la sijè a manyen gout abityèl la.
    ///
    /// Chak fwa sa posib, li pi preferab pou itilize [`assume_init`] olye de sa, ki anpeche kopi kontni `MaybeUninit<T>` la.
    ///
    /// # Safety
    ///
    /// Li se jiska moun kap rele a garanti ke `MaybeUninit<T>` a reyèlman se nan yon eta inisyalize.Rele sa a lè kontni an se pa sa konplètman inisyalize lakòz konpòtman endefini.
    /// [type-level documentation][inv] a gen plis enfòmasyon sou envariant inisyalizasyon sa a.
    ///
    /// Anplis, sa a kite yon kopi done yo menm dèyè nan `MaybeUninit<T>` la.
    /// Lè w ap itilize kopi miltip nan done yo (lè w rele `assume_init_read` plizyè fwa, oswa premye rele `assume_init_read` ak Lè sa a, [`assume_init`]), li se responsablite ou a asire ke done sa yo ka tout bon kopi.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Itilizasyon kòrèk nan metòd sa a:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` se `Copy`, pou nou ka li plizyè fwa.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Kopi yon valè `None` se oke, se konsa nou ka li plizyè fwa.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Kòrèk* l 'nan metòd sa a:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Nou kounye a kreye de kopi vector a menm, ki mennen nan yon doub-gratis when️ lè yo tou de jwenn tonbe!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` inisyalize.
        // Lekti soti nan `self.as_ptr()` an sekirite depi `self` yo ta dwe inisyalize.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Gout valè ki genyen nan plas li.
    ///
    /// Si ou gen an komen nan `MaybeUninit` a, ou ka itilize [`assume_init`] olye.
    ///
    /// # Safety
    ///
    /// Li se jiska moun kap rele a garanti ke `MaybeUninit<T>` a reyèlman se nan yon eta inisyalize.Rele sa a lè kontni an se pa sa konplètman inisyalize lakòz konpòtman endefini.
    ///
    /// Anplis de sa, tout envariant adisyonèl nan kalite `T` yo dwe satisfè, menm jan aplikasyon `Drop` nan `T` (oswa manm li yo) ka konte sou sa.
    /// Pou egzanp, yon `1`-inisyalize [`Vec<T>`] konsidere kòm inisyalize (anba aplikasyon aktyèl la; sa a pa konstitye yon garanti ki estab) paske kondisyon an sèlman du a konnen sou li se ke konsèy la done yo dwe ki pa nil.
    ///
    /// Jete tankou yon `Vec<T>` sepandan ap lakòz konpòtman endefini.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` inisyalize ak
        // satisfè tout envariants nan `T`.
        // Jete valè a an plas an sekirite si se ka a.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Jwenn yon referans pataje nan valè ki genyen an.
    ///
    /// Sa a ka itil lè nou vle jwenn aksè nan yon `MaybeUninit` ki te inisyalize men pa gen an komen nan `MaybeUninit` la (anpeche itilizasyon `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Rele sa a lè kontni an se pa sa konplètman inisyalize lakòz konpòtman endefini: li se jiska moun kap rele a garanti ke `MaybeUninit<T>` a reyèlman se nan yon eta inisyalize.
    ///
    ///
    /// # Examples
    ///
    /// ### Itilizasyon kòrèk nan metòd sa a:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inisyalize `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Kounye a ke `MaybeUninit<_>` nou an li te ye yo dwe inisyalize, li se oke yo kreye yon referans pataje nan li:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SEKIRITE: `x` te inisyalize.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Kòrèk* itilizasyon metòd sa a:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Nou te kreye yon referans a yon vector uninitialized!Sa a se konpòtman endefini.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inisyalize `MaybeUninit` la lè l sèvi avèk `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referans a yon `Cell<bool>` uninitialized: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` inisyalize.
        // Sa vle di tou ke `self` dwe yon Variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Jwenn yon referans (unique) mutable valè ki genyen.
    ///
    /// Sa a ka itil lè nou vle jwenn aksè nan yon `MaybeUninit` ki te inisyalize men pa gen an komen nan `MaybeUninit` la (anpeche itilizasyon `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Rele sa a lè kontni an se pa sa konplètman inisyalize lakòz konpòtman endefini: li se jiska moun kap rele a garanti ke `MaybeUninit<T>` a reyèlman se nan yon eta inisyalize.
    /// Pou egzanp, `.assume_init_mut()` pa ka itilize yo inisyalize yon `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Itilizasyon kòrèk nan metòd sa a:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inisyalize *tout* bytes yo nan tanpon an opinyon.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inisyalize `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Koulye a, nou konnen ke `buf` te inisyalize, se konsa nou te kapab `.assume_init()` li.
    /// // Sepandan, lè l sèvi avèk `.assume_init()` ka deklanche yon `memcpy` nan 2048 bytes yo.
    /// // Pou afime tanpon nou an te inisyalize san kopye li, nou ajou `&mut MaybeUninit<[u8; 2048]>` a nan yon `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SEKIRITE: `buf` te inisyalize.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Koulye a, nou ka itilize `buf` kòm yon tranch nòmal:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Kòrèk* itilizasyon metòd sa a:
    ///
    /// Ou pa ka itilize `.assume_init_mut()` pou inisyalize yon valè:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Nou te kreye yon referans (mutable) nan yon `bool` uninitialized!
    ///     // Sa a se konpòtman endefini.⚠️
    /// }
    /// ```
    ///
    /// Pou egzanp, ou pa ka [`Read`] nan yon tanpon inisyalize:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referans a uninitialized memwa!
    ///                             // Sa a se konpòtman endefini.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ni ou pa ka itilize aksè dirèk nan jaden pou fè inisyalizasyon gradyèl jaden pa jaden:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referans a uninitialized memwa!
    ///                  // Sa a se konpòtman endefini.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referans a uninitialized memwa!
    ///                  // Sa a se konpòtman endefini.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Nou kounye a konte sou pi wo a yo te kòrèk, sa vle di, nou gen referans a done inisyalize (egzanp, nan `libcore/fmt/float.rs`).
    // Nou ta dwe pran yon desizyon final sou règleman yo anvan estabilizasyon.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` inisyalize.
        // Sa vle di tou ke `self` dwe yon Variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Ekstrè valè yo soti nan yon etalaj de kontenè `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Li se jiska moun kap rele a garanti ke tout eleman nan etalaj la yo nan yon eta inisyalize.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SEKIRITE: Koulye a, san danje menm jan nou inisyalize tout eleman yo
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Moun kap rele a garanti ke tout eleman nan etalaj la inisyalize
        // * `MaybeUninit<T>` ak T yo garanti yo gen menm Layout la
        // * MaybeUnint pa gout, kidonk pa gen okenn doub-gratis Epi konsa konvèsyon an an sekirite
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Sipoze tout eleman yo inisyalize, jwenn yon tranch yo.
    ///
    /// # Safety
    ///
    /// Li se jiska moun kap rele a garanti ke eleman yo `MaybeUninit<T>` reyèlman yo nan yon eta inisyalize.
    ///
    /// Rele sa a lè kontni an se pa sa konplètman inisyalize lakòz konpòtman endefini.
    ///
    /// Gade [`assume_init_ref`] pou plis detay ak egzanp.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SEKIRITE: Distribisyon tranch nan yon `*const [T]` san danje depi moun kap rele a garanti sa
        // `slice` se inisyalize, ak "PetètUninit" se garanti yo gen Layout a menm jan ak `T`.
        // Konsèy la jwenn valab depi li refere a memwa posede pa `slice` ki se yon referans e konsa garanti yo dwe valab pou li.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Sipoze tout eleman yo inisyalize, jwenn yon tranch mitab yo.
    ///
    /// # Safety
    ///
    /// Li se jiska moun kap rele a garanti ke eleman yo `MaybeUninit<T>` reyèlman yo nan yon eta inisyalize.
    ///
    /// Rele sa a lè kontni an se pa sa konplètman inisyalize lakòz konpòtman endefini.
    ///
    /// Gade [`assume_init_mut`] pou plis detay ak egzanp.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SEKIRITE: menm jan ak nòt sekirite pou `slice_get_ref`, men nou gen yon
        // referans mutable ki garanti tou valab pou ekri.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Jwenn yon konsèy nan premye eleman nan etalaj la.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Jwenn yon konsèy mutable nan eleman an premye nan etalaj la.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopye eleman ki soti nan `src` a `this`, retounen yon referans mutable nan sa ki kounye a initalize nan `this`.
    ///
    /// Si `T` pa aplike `Copy`, itilize [`write_slice_cloned`]
    ///
    /// Sa a se menm jan ak [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Fonksyon sa a pral panic si de tranch yo gen longè diferan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEKIRITE: nou fèk kopye tout eleman len nan kapasite rezèv la
    /// // premye eleman src.len() yo nan vèk la valab kounye a.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SEKIRITE: &[T] ak&[PetètUninit<T>] gen menm Layout la
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SEKIRITE: Eleman valab yo te jis kopye nan `this` kidonk li inisyalize
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klon eleman ki soti nan `src` `this`, retounen yon referans mutable nan sa ki kounye a initalize nan `this`.
    /// Nenpòt eleman ki deja inisyalize pa pral tonbe.
    ///
    /// Si `T` aplike `Copy`, itilize [`write_slice`]
    ///
    /// Sa a sanble ak [`slice::clone_from_slice`] men li pa lage eleman ki deja egziste yo.
    ///
    /// # Panics
    ///
    /// Fonksyon sa a pral panic si de tranch yo gen longè diferan, oswa si aplikasyon an nan `Clone` panics.
    ///
    /// Si gen yon panic, eleman ki deja klone yo pral tonbe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEKIRITE: nou fèk klone tout eleman len nan kapasite rezèv la
    /// // premye eleman src.len() yo nan vèk la valab kounye a.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // kontrèman ak copy_from_slice sa a pa rele clone_from_slice sou tranch la sa a se paske `MaybeUninit<T: Clone>` pa aplike klonaj.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SEKIRITE: tranch sa a anvan tout koreksyon ap gen sèlman inisyalize objè yo
                // se poutèt sa, li pèmèt yo lage li.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Nou bezwen klèman tranch yo nan menm longè a
        // pou limit tcheke yo dwe elided, ak optimizeur a pral jenere memcpy pou ka senp (pou egzanp T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // gad nesesè b/c panic ta ka rive pandan yon script
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SEKIRITE: Eleman valab yo te jis ekri nan `this` kidonk li inisyalize
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}