use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Yon pakè anpeche konpile soti nan otomatikman rele destriktè `T` a.
/// Sa a vlope se 0-pri.
///
/// `ManuallyDrop<T>` se sijè a menm optimize yo layout kòm `T`.
/// Kòm yon konsekans, li gen *pa gen okenn efè* sou sipozisyon yo ke du a fè sou sa li yo.
/// Pou egzanp, inisyalizasyon yon `ManuallyDrop<&mut T>` ak [`mem::zeroed`] se konpòtman endefini.
/// Si ou bezwen okipe done inisyalize, sèvi ak [`MaybeUninit<T>`] olye.
///
/// Remake byen ke aksè valè a andedan yon `ManuallyDrop<T>` san danje.
/// Sa vle di ke yon `ManuallyDrop<T>` ki gen kontni te tonbe pa dwe ekspoze nan yon API piblik san danje.
/// Korespondan, `ManuallyDrop::drop` pa an sekirite.
///
/// # `ManuallyDrop` ak gout lòd.
///
/// Rust gen yon [drop order] byen defini nan valè.
/// Pou asire ke jaden oswa moun nan lokalite yo tonbe nan yon lòd espesifik, reòdone deklarasyon yo tankou ke lòd la gout enplisit se youn nan kòrèk.
///
/// Li posib yo sèvi ak `ManuallyDrop` kontwole lòd la gout, men sa a mande pou kòd an sekirite epi li difisil fè kòrèkteman nan prezans nan detant.
///
///
/// Pou egzanp, si ou vle asire ke se yon jaden espesifik tonbe apre lòt moun yo, fè li dènye jaden an nan yon struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` yo pral tonbe apre `children`.
///     // Rust garanti ke jaden yo tonbe nan lòd deklarasyon an.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Vlope yon valè yo dwe manyèlman tonbe.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Ou ka toujou opere san danje sou valè a
    /// assert_eq!(*x, "Hello");
    /// // Men, `Drop` pa pral kouri isit la
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Ekstrè valè ki soti nan veso a `ManuallyDrop`.
    ///
    /// Sa pèmèt valè a tonbe ankò.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Sa a lage `Box` la.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Pran valè ki soti nan veso a `ManuallyDrop<T>` soti.
    ///
    /// Metòd sa a sitou fèt pou deplase valè nan gout.
    /// Olye pou yo sèvi ak [`ManuallyDrop::drop`] manyèlman gout valè a, ou ka itilize metòd sa a yo pran valè a epi sèvi ak li sepandan vle.
    ///
    /// Chak fwa sa posib, li pi preferab pou itilize [`into_inner`][`ManuallyDrop::into_inner`] olye de sa, ki anpeche kopi kontni `ManuallyDrop<T>` la.
    ///
    ///
    /// # Safety
    ///
    /// Fonksyon sa a semantik deplase soti valè ki genyen san yo pa anpeche plis itilizasyon, kite eta a nan veso sa a chanje.
    /// Se responsablite w pou asire ke `ManuallyDrop` sa a pa itilize ankò.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SEKIRITE: n ap li nan yon referans, ki garanti
        // yo dwe valab pou li.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Manyèlman gout valè ki genyen an.Sa a se egzakteman ekivalan a rele [`ptr::drop_in_place`] ak yon konsèy sou valè ki genyen an.
    /// Kòm sa yo, sof si valè ki genyen an se yon struct chaje, yo pral destriktè a yo rele nan plas san yo pa deplase valè a, e konsa yo ka itilize yo san danje gout done [pinned].
    ///
    /// Si ou gen an komen nan valè a, ou ka itilize [`ManuallyDrop::into_inner`] olye.
    ///
    /// # Safety
    ///
    /// Fonksyon sa a kouri destriktè valè ki genyen an.
    /// Lòt pase chanjman ki fèt pa destriktè a li menm, memwa a rete san okenn chanjman, e konsa osi lwen ke du a konsène toujou kenbe yon ti jan-modèl ki valab pou kalite `T` la.
    ///
    ///
    /// Sepandan, valè "zombie" sa a pa ta dwe ekspoze a kòd san danje, epi fonksyon sa a pa ta dwe rele plis pase yon fwa.
    /// Pou itilize yon valè apre li fin tonbe, oswa lage yon valè plizyè fwa, sa ka lakòz Konpòtman Endefini (tou depann de sa `drop` fè).
    /// Sa a se nòmalman anpeche pa sistèm nan kalite, men itilizatè yo nan `ManuallyDrop` dwe defann sa yo garanti san asistans nan men du a.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SEKIRITE: nou ap jete valè a pwente nan yon referans mutable
        // ki garanti yo valab pou ekri.
        // Li se jiska moun kap rele a asire w ke `slot` pa tonbe ankò.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}