//! Fonksyon debaz pou fè fas ak memwa.
//!
//! Modil sa a gen fonksyon pou mande gwosè a ak aliyman nan kalite, inisyalize ak manipile memwa.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Pran an komen ak "forgets" sou valè a **san yo pa kouri destriktè li yo**.
///
/// Nenpòt resous valè a jere, tankou memwa pil oswa yon manch dosye, yo pral retade pou tout tan nan yon eta irealizabl.Sepandan, li pa garanti ke endikasyon sou memwa sa a ap rete valab.
///
/// * Si ou vle koule memwa, gade [`Box::leak`].
/// * Si ou vle jwenn yon konsèy anvan tout koreksyon nan memwa a, gade [`Box::into_raw`].
/// * Si ou vle jete yon valè byen, kouri destriktè li yo, gade [`mem::drop`].
///
/// # Safety
///
/// `forget` pa make kòm `unsafe`, paske garanti sekirite Rust a pa gen ladan yon garanti ke destriktè ap toujou kouri.
/// Pou egzanp, yon pwogram ka kreye yon sik referans lè l sèvi avèk [`Rc`][rc], oswa rele [`process::exit`][exit] sòti san yo pa kouri destriktè.
/// Se konsa, pèmèt `mem::forget` soti nan kòd ki an sekirite pa chanje fondamantalman garanti sekirite Rust la.
///
/// Sa te di, koule resous tankou memwa oswa I/O objè se nòmalman endezirab.
/// Bezwen an vini nan kèk ka itilize espesyalize pou FFI oswa kòd ki pa an sekirite, men menm lè sa a, [`ManuallyDrop`] tipikman pi pito.
///
/// Paske bliye yon valè pèmèt, nenpòt kòd `unsafe` ou ekri dwe pèmèt pou posibilite sa a.Ou pa ka retounen yon valè epi espere ke moun kap rele a ap nesesèman kouri destriktè valè a.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Itilize kanonik san danje nan `mem::forget` se kontourne destriktè yon valè aplike pa `Drop` trait la.Pou egzanp, sa a pral koule yon `File`, sa vle di
/// reklame espas ki pran pa varyab la men pa janm fèmen resous sistèm kache a:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Sa a se itil lè yo te an komen nan resous ki kache deja transfere nan kòd deyò nan Rust, pou egzanp pa transmèt deskriptè a dosye anvan tout koreksyon C kòd.
///
/// # Relasyon ak `ManuallyDrop`
///
/// Pandan ke `mem::forget` kapab tou itilize yo transfere *memwa* pwopriyetè, fè sa ki gen tandans erè.
/// [`ManuallyDrop`] ta dwe itilize olye.Konsidere, pou egzanp, kòd sa a:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Bati yon `String` lè l sèvi avèk sa ki nan `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // koule `v` paske se memwa li kounye a jere pa `s`
/// mem::forget(v);  // ERÈ, v se valab epi yo pa dwe pase nan yon fonksyon
/// assert_eq!(s, "Az");
/// // `s` se implicite tonbe ak memwa li deallocated.
/// ```
///
/// Gen de pwoblèm ak egzanp ki anwo a:
///
/// * Si yo te ajoute plis kòd ant konstriksyon `String` ak envokasyon `mem::forget()`, yon panic nan li ta lakòz yon doub gratis paske se memwa a menm okipe pa tou de `v` ak `s`.
/// * Apre ou fin rele `v.as_mut_ptr()` epi transmèt pwopriyetè done yo nan `s`, valè `v` la envalid.
/// Menm lè yon valè jis demenaje ale rete nan `mem::forget` (ki pa pral enspekte li), kèk kalite gen kondisyon strik sou valè yo ki fè yo envalid lè pendant oswa pa posede ankò.
/// Sèvi ak valè envalib nan nenpòt fason, ki gen ladan pase yo nan oswa retounen yo soti nan fonksyon, konstitye konpòtman endefini epi yo ka kraze sipozisyon yo ki fèt pa du a.
///
/// Oblije chanje nan `ManuallyDrop` evite tou de pwoblèm:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Anvan nou demont `v` nan pati anvan tout koreksyon li yo, asire w ke li pa tonbe!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Koulye a, demont `v`.Operasyon sa yo pa kapab panic, kidonk pa ka gen yon koule.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Finalman, bati yon `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` se implicite tonbe ak memwa li deallocated.
/// ```
///
/// `ManuallyDrop` gaya anpeche doub-gratis paske nou enfim destriktè `v` a anvan yo fè nenpòt lòt bagay.
/// `mem::forget()` pa pèmèt sa a paske li konsome agiman li yo, fòse nou rele li sèlman apre ekstrè anyen nou bezwen soti nan `v`.
/// Menm si yo te prezante yon panic ant konstriksyon `ManuallyDrop` ak bati fisèl la (ki pa ka rive nan kòd la jan yo montre sa), li ta lakòz yon koule epi yo pa yon doub gratis.
/// Nan lòt mo, `ManuallyDrop` erè sou bò a nan koule olye pou yo erè sou bò a nan (doub-) jete.
///
/// Epitou, `ManuallyDrop` anpeche nou gen "touch" `v` apre transfere pwopriyetè a nan `s`-etap final la nan kominike avèk `v` jete tout fatra ki li san yo pa kouri destriktè li se antyèman evite.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Tankou [`forget`], men tou, aksepte valè gwosè.
///
/// Fonksyon sa a se jis yon shim gen entansyon yo dwe retire lè karakteristik nan `unsized_locals` vin estabilize.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Retounen gwosè yon kalite an bytes.
///
/// Plis espesyalman, sa a se konpanse nan bytes ant eleman siksesif nan yon etalaj ak ki kalite atik ki gen ladan padding aliyman.
///
/// Kidonk, pou nenpòt ki kalite `T` ak longè `n`, `[T; n]` gen yon gwosè `n * size_of::<T>()`.
///
/// An jeneral, gwosè a nan yon kalite se pa ki estab nan tout konpilasyon, men kalite espesifik tankou primitif yo.
///
/// Tablo sa a bay gwosè a pou primitif yo.
///
/// Kalite |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Anplis de sa, `usize` ak `isize` gen menm gwosè a.
///
/// Kalite `*const T`, `&T`, `Box<T>`, `Option<&T>`, ak `Option<Box<T>>` tout gen menm gwosè.
/// Si `T` gwosè, tout kalite sa yo gen menm gwosè ak `usize`.
///
/// Mutabilite yon konsèy pa chanje gwosè li.Kòm sa yo, `&T` ak `&mut T` gen menm gwosè a.
/// Menm jan an tou pou `*const T` ak `* mut T`.
///
/// # Gwosè atik `#[repr(C)]`
///
/// Reprezantasyon `C` pou atik gen yon layout defini.
/// Avèk Layout sa a, gwosè a nan atik se tou ki estab osi lontan ke tout jaden gen yon gwosè ki estab.
///
/// ## Gwosè Structs
///
/// Pou `structs`, gwosè a detèmine pa algorithm sa a.
///
/// Pou chak jaden nan struct la te bay lòd pa deklarasyon lòd:
///
/// 1. Ajoute gwosè jaden an.
/// 2. Awondi gwosè aktyèl la nan miltip ki pi pre a nan [alignment] pwochen jaden an.
///
/// Finalman, wonn gwosè a nan struct ki pi pre miltip nan [alignment] li yo.
/// Aliman nan struct la se nòmalman pi gwo aliyman nan tout jaden li yo;sa ka chanje avèk itilizasyon `repr(align(N))`.
///
/// Kontrèman ak `C`, zewo struct gwosè yo pa awondi jiska yon sèl byte nan gwosè.
///
/// ## Gwosè Enums
///
/// Anbou ki pa pote okenn lòt done pase diskriminan an gen menm gwosè ak enb C sou platfòm la yo konpile pou.
///
/// ## Gwosè sendika yo
///
/// Gwosè a nan yon sendika se gwosè a nan pi gwo jaden li yo.
///
/// Kontrèman ak `C`, zewo inyon gwosè yo pa awondi jiska yon sèl byte nan gwosè.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Kèk primitif
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Gen kèk ranje
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pointeur egalite gwosè
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Sèvi ak `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Gwosè a nan premye jaden an se 1, se konsa ajoute 1 nan gwosè a.Gwosè se 1.
/// // Aliyman nan dezyèm jaden an se 2, se konsa ajoute 1 nan gwosè a pou padding.Gwosè se 2.
/// // Gwosè dezyèm jaden an se 2, kidonk ajoute 2 nan gwosè a.Gwosè a se 4.
/// // Aliyman nan twazyèm jaden an se 1, se konsa ajoute 0 nan gwosè a pou padding.Gwosè a se 4.
/// // Gwosè a nan twazyèm jaden an se 1, se konsa ajoute 1 nan gwosè a.Gwosè se 5.
/// // Finalman, aliyman nan struct la se 2 (paske aliyman nan pi gwo pami jaden li yo se 2), se konsa ajoute 1 nan gwosè a pou padding.
/// // Gwosè se 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Struct structur swiv menm règ yo.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Remake byen ke reordering jaden yo ka bese gwosè a.
/// // Nou ka retire tou de bytes padding pa mete `third` anvan `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Gwosè Inyon se gwosè a nan jaden an pi gwo.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Retounen gwosè a nan valè a pwente nan bytes.
///
/// Sa a se anjeneral menm jan ak `size_of::<T>()`.
/// Sepandan, lè `T`*pa gen* gwosè statikman li te ye, pa egzanp, yon tranch [`[T]`][slice] oswa yon [trait object], lè sa a `size_of_val` ka itilize pou jwenn gwosè dinamik-li te ye.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SEKIRITE: `val` se yon referans, kidonk li se yon konsèy valab anvan tout koreksyon
    unsafe { intrinsics::size_of_val(val) }
}

/// Retounen gwosè a nan valè a pwente nan bytes.
///
/// Sa a se anjeneral menm jan ak `size_of::<T>()`.Sepandan, lè `T`*pa gen* gwosè statikman li te ye, pa egzanp, yon tranch [`[T]`][slice] oswa yon [trait object], lè sa a `size_of_val_raw` ka itilize pou jwenn gwosè dinamik-li te ye.
///
/// # Safety
///
/// Fonksyon sa a sèlman an sekirite pou rele si kondisyon sa yo kenbe:
///
/// - Si `T` se `Sized`, fonksyon sa a toujou an sekirite pou rele.
/// - Si ke dimansyon `T` se:
///     - yon [slice], lè sa a longè ke tranch lan dwe yon nonb antye relatif inisyalize, ak gwosè *tout valè*(dinamik ke longè + statik gwosè prefiks) dwe anfòm nan `isize`.
///     - yon [trait object], Lè sa a, pati a vtable nan konsèy la dwe lonje dwèt sou yon vtable valab akeri pa yon kontrent dimansyon, ak gwosè a nan *valè a tout antye*(dinamik ke longè + statik gwosè prefiks) dwe anfòm nan `isize`.
///
///     - yon (unstable) [extern type], Lè sa a, fonksyon sa a se toujou san danje yo rele, men yo ka panic oswa otreman retounen valè a sa ki mal, kòm Layout kalite ekstèn lan pa li te ye.
///     Sa a se konpòtman an menm jan ak [`size_of_val`] sou yon referans a yon kalite ki gen yon ke kalite ekstèn.
///     - otreman, li se konsèvativman pa pèmèt yo rele fonksyon sa a.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEKIRITE: moun kap rele a dwe bay yon konsèy valab anvan tout koreksyon
    unsafe { intrinsics::size_of_val(val) }
}

/// Retounen [ABI]-aliman minimòm aliyman yon kalite.
///
/// Chak referans a yon valè kalite `T` dwe yon miltip nan nimewo sa a.
///
/// Sa a se aliyman ki itilize pou jaden struct.Li ka pi piti pase aliyman an pi pito.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retounen [ABI]-aliman minimòm aliyman kalite valè `val` montre yo.
///
/// Chak referans a yon valè kalite `T` dwe yon miltip nan nimewo sa a.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEKIRITE: val se yon referans, kidonk li nan yon konsèy valab anvan tout koreksyon
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retounen [ABI]-aliman minimòm aliyman yon kalite.
///
/// Chak referans a yon valè kalite `T` dwe yon miltip nan nimewo sa a.
///
/// Sa a se aliyman ki itilize pou jaden struct.Li ka pi piti pase aliyman an pi pito.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retounen [ABI]-aliman minimòm aliyman kalite valè `val` montre yo.
///
/// Chak referans a yon valè kalite `T` dwe yon miltip nan nimewo sa a.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEKIRITE: val se yon referans, kidonk li nan yon konsèy valab anvan tout koreksyon
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retounen [ABI]-aliman minimòm aliyman kalite valè `val` montre yo.
///
/// Chak referans a yon valè kalite `T` dwe yon miltip nan nimewo sa a.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Fonksyon sa a sèlman an sekirite pou rele si kondisyon sa yo kenbe:
///
/// - Si `T` se `Sized`, fonksyon sa a toujou an sekirite pou rele.
/// - Si ke dimansyon `T` se:
///     - yon [slice], lè sa a longè ke tranch lan dwe yon nonb antye relatif inisyalize, ak gwosè *tout valè*(dinamik ke longè + statik gwosè prefiks) dwe anfòm nan `isize`.
///     - yon [trait object], Lè sa a, pati a vtable nan konsèy la dwe lonje dwèt sou yon vtable valab akeri pa yon kontrent dimansyon, ak gwosè a nan *valè a tout antye*(dinamik ke longè + statik gwosè prefiks) dwe anfòm nan `isize`.
///
///     - yon (unstable) [extern type], Lè sa a, fonksyon sa a se toujou san danje yo rele, men yo ka panic oswa otreman retounen valè a sa ki mal, kòm Layout kalite ekstèn lan pa li te ye.
///     Sa a se konpòtman an menm jan ak [`align_of_val`] sou yon referans a yon kalite ki gen yon ke kalite ekstèn.
///     - otreman, li se konsèvativman pa pèmèt yo rele fonksyon sa a.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEKIRITE: moun kap rele a dwe bay yon konsèy valab anvan tout koreksyon
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retounen `true` si valè valè kalite `T`.
///
/// Sa a se piman yon allusion optimize, epi yo ka aplike konsèvativman:
/// li ka retounen `true` pou kalite ki pa aktyèlman bezwen tonbe.
/// Kòm sa yo toujou retounen `true` ta dwe yon aplikasyon ki valab nan fonksyon sa a.Sepandan si fonksyon sa a aktyèlman retounen `false`, Lè sa a, ou ka sèten jete `T` pa gen okenn efè segondè.
///
/// Aplikasyon nivo ki ba nan bagay sa yo tankou koleksyon, ki bezwen manyèlman gout done yo, yo ta dwe itilize fonksyon sa a pou fè pou evite san nesesite ap eseye lage tout sa yo lè yo detwi.
///
/// Sa a pa ta ka fè yon diferans nan lage bati (kote yon bouk ki pa gen okenn efè segondè-fasil detekte ak elimine), men se souvan yon gwo genyen pou debug bati.
///
/// Remake byen ke [`drop_in_place`] deja fè chèk sa a, kidonk si kantite travay ou ka redwi a kèk ti kantite [`drop_in_place`] apèl, lè l sèvi avèk sa a se nesesè.
/// An patikilye sonje ke ou ka [`drop_in_place`] yon tranch, epi ki pral fè yon sèl need_drop tcheke pou tout valè yo.
///
/// Kalite tankou Vec Se poutèt sa jis `drop_in_place(&mut self[..])` san yo pa itilize `needs_drop` klèman.
/// Kalite tankou [`HashMap`], nan lòt men an, gen lage valè youn nan yon moman epi yo ta dwe itilize sa a API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Isit la nan yon egzanp sou kouman yon koleksyon ta ka fè pou sèvi ak `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // lage done yo
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Retounen valè kalite `T` ki reprezante pa modèl tout-zewo byte.
///
/// Sa vle di ke, pou egzanp, okti a padding nan `(u8, u16)` se pa nesesèman zero.
///
/// Pa gen okenn garanti ke yon modèl tout-zewo byte reprezante yon valè valab nan kèk kalite `T`.
/// Pou egzanp, modèl la tout-zewo byte se pa yon valè ki valab pou kalite referans (`&T`, `&mut T`) ak fonksyon endikasyon.
/// Sèvi ak `zeroed` sou kalite sa yo lakòz imedya [undefined behavior][ub] paske [the Rust compiler assumes][inv] ki toujou gen yon valè valab nan yon varyab li konsidere inisyalize.
///
///
/// Sa a gen efè a menm jan ak [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Li itil pou FFI pafwa, men yo ta dwe jeneralman evite.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Kòrèk itilizasyon fonksyon sa a: inisyalizasyon yon nonb antye relatif ak zewo.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Kòrèk* l 'nan fonksyon sa a: inisyalizasyon yon referans ak zewo.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Konpòtman san defini!
/// let _y: fn() = unsafe { mem::zeroed() }; // Epi ankò!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SEKIRITE: moun kap rele a dwe garanti ke yon valè tout-zewo valab pou `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Evite chèk nòmal-inisyalizasyon memwa Rust pa pretann yo pwodwi yon valè de kalite `T`, pandan y ap fè anyen nan tout.
///
/// **Fonksyon sa a obsolèt.** Sèvi ak [`MaybeUninit<T>`] olye de sa.
///
/// Rezon ki fè la pou depresyasyon se ke fonksyon an fondamantalman pa ka itilize kòrèkteman: li gen efè a menm jan ak [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Kòm [`assume_init` documentation][assume_init] a eksplike, [the Rust compiler assumes][inv] ki valè yo byen inisyalize.
/// Kòm yon konsekans, rele egzanp
/// `mem::uninitialized::<bool>()` lakòz imedya konpòtman endefini pou retounen yon `bool` ki pa definitivman swa `true` oswa `false`.
/// Pi mal, se vre wi: inisyativ memwa tankou sa ki vin tounen isit la se espesyal nan ki du a konnen ke li pa gen yon valè fiks yo.
/// Sa fè li konpòtman endefini gen done uninitialized nan yon varyab menm si ki varyab gen yon kalite nonb antye relatif.
/// (Remake ke règleman yo alantou nonb antye relatif antye yo pa finalize ankò, men jiskaske yo, li rekòmande pou fè pou evite yo.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SEKIRITE: moun kap rele a dwe garanti ke yon valè unitialize valab pou `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Swaps valè yo nan de kote ki ka chanje, san yo pa deinitializing swa youn.
///
/// * Si ou vle swap ak yon valè default oswa egare, gade [`take`].
/// * Si ou vle swap ak yon valè pase, retounen valè a fin vye granmoun, gade [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SEKIRITE: endikasyon yo anvan tout koreksyon yo te kreye soti nan referans san danje mutabl satisfè tout la
    // kontrent sou `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Ranplase `dest` ak valè default `T`, retounen valè `dest` anvan an.
///
/// * Si ou vle ranplase valè de varyab yo, gade [`swap`].
/// * Si ou vle ranplase ak yon valè pase olye pou yo valè a default, gade [`replace`].
///
/// # Examples
///
/// Yon egzanp senp:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` pèmèt pran an komen nan yon jaden struct pa ranplase li ak yon valè "empty".
/// San yo pa `take` ou ka kouri antre nan pwoblèm tankou sa yo:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Remake byen ke `T` pa nesesèman aplike [`Clone`], kidonk li pa menm ka klonaj ak Reyajiste `self.buf`.
/// Men, `take` ka itilize yo separe valè orijinal la nan `self.buf` soti nan `self`, sa ki pèmèt li yo dwe retounen:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Deplase `src` nan `dest` referansye a, retounen valè `dest` anvan an.
///
/// Ni valè yo tonbe.
///
/// * Si ou vle ranplase valè de varyab yo, gade [`swap`].
/// * Si ou vle ranplase ak yon valè default, gade [`take`].
///
/// # Examples
///
/// Yon egzanp senp:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` pèmèt konsomasyon nan yon jaden struct pa ranplase li ak yon lòt valè.
/// San yo pa `replace` ou ka kouri antre nan pwoblèm tankou sa yo:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Remake byen ke `T` pa nesesèman aplike [`Clone`], kidonk nou pa menm ka script `self.buf[i]` pou fè pou evite deplase la.
/// Men, `replace` ka itilize yo separe valè orijinal la nan ki endèks soti nan `self`, sa ki pèmèt li yo dwe retounen:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SEKIRITE: Nou li soti nan `dest` men dirèkteman ekri `src` nan li apre sa,
    // tankou ke valè a fin vye granmoun pa kopi.
    // Pa gen anyen ki tonbe e pa gen anyen isit la ka panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Dispoze de yon valè.
///
/// Sa a fè sa lè w rele aplikasyon agiman an nan [`Drop`][drop].
///
/// Sa a efektivman pa fè anyen pou kalite ki aplike `Copy`, egzanp
/// integers.
/// Valè sa yo kopye ak _then_ demenaje ale rete nan fonksyon an, se konsa valè a pèsiste apre sa a apèl fonksyon.
///
///
/// Fonksyon sa a se pa majik;li literalman defini kòm
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Paske `_x` deplase nan fonksyon an, li otomatikman tonbe anvan fonksyon an retounen.
///
/// [drop]: Drop
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // klèman lage vector la
/// ```
///
/// Depi [`RefCell`] ranfòse règleman yo prete nan ègzekutabl, `drop` ka lage yon [`RefCell`] prete:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // abandone prete a mutable sou plas sa a
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Nonb antye ak lòt kalite aplike [`Copy`] yo pa afekte pa `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // yon kopi `x` deplase ak tonbe
/// drop(y); // yon kopi `y` deplase ak tonbe
///
/// println!("x: {}, y: {}", x, y.0); // toujou disponib
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Entèprete `src` tankou li gen kalite `&U`, epi li `src` san li pa deplase valè ki genyen an.
///
/// Fonksyon sa a pral san danje asime konsèy la `src` ki valab pou [`size_of::<U>`][size_of] bytes pa transmutasyon `&T` `&U` ak Lè sa a, li `&U` la (eksepte ke sa a se fè nan yon fason ki kòrèk menm lè `&U` fè pi sevè aliyman kondisyon pase `&T`).
/// Li pral kreye tou san danje yon kopi valè ki genyen olye pou yo deplase soti nan `src`.
///
/// Li pa yon erè konpile-tan si `T` ak `U` gen diferan gwosè, men li trè ankouraje sèlman envoke fonksyon sa a kote `T` ak `U` gen menm gwosè a.Fonksyon sa a deklannche [undefined behavior][ub] si `U` pi gwo pase `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopye done ki soti nan 'foo_array' epi trete li kòm yon 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modifye done kopye yo
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Sa ki nan 'foo_array' pa ta dwe chanje
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Si U gen yon egzijans aliyman ki pi wo, src pa ka konvnableman aliyen.
    if align_of::<U>() > align_of::<T>() {
        // SEKIRITE: `src` se yon referans ki garanti valab pou li.
        // Moun kap rele a dwe garanti ke transmutasyon aktyèl la an sekirite.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SEKIRITE: `src` se yon referans ki garanti valab pou li.
        // Nou jis tcheke si `src as *const U` te byen aliyen.
        // Moun kap rele a dwe garanti ke transmutasyon aktyèl la an sekirite.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Kalite opak ki reprezante diskriminan yon enum.
///
/// Gade fonksyon [`discriminant`] nan modil sa a pou plis enfòmasyon.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Aplikasyon trait sa yo pa ka sòti paske nou pa vle okenn limit sou T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Retounen yon valè inikman idantifye Variant la enum nan `v`.
///
/// Si `T` se pa yon enum, rele fonksyon sa a pa pral lakòz nan konpòtman endefini, men valè a retounen se unspecified.
///
///
/// # Stability
///
/// Diskriminan an nan yon Variant enum ka chanje si definisyon an enum chanje.
/// Yon diskriminan nan kèk Variant pa pral chanje ant konpilasyon ak du a menm.
///
/// # Examples
///
/// Sa a ka itilize yo konpare enums ki pote done, pandan y ap neglije done aktyèl la:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Retounen kantite variantes nan kalite enum `T` la.
///
/// Si `T` se pa yon enum, rele fonksyon sa a pa pral lakòz nan konpòtman endefini, men valè a retounen se unspecified.
/// Egal-ego, si `T` se yon enum ki gen plis varyant pase `usize::MAX` valè retounen an pa espesifye.
/// Variant dezole yo pral konte.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}