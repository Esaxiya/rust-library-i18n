//! Defini `IntoIter` posede iteratè a pou ranje.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Yon iteratè pa valè [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Sa a se etalaj la nou ap repete sou.
    ///
    /// Eleman ak endèks `i` kote `alive.start <= i < alive.end` pa te sede ankò epi yo valab antre etalaj.
    /// Eleman ki gen endis `i < alive.start` oswa `i >= alive.end` yo te sede deja epi yo pa dwe jwenn aksè ankò!Moun sa yo ki eleman mouri ta ka menm nan yon eta konplètman uninitialized!
    ///
    ///
    /// Se konsa, envariants yo se:
    /// - `data[alive]` vivan (sètadi gen eleman valab)
    /// - `data[..alive.start]` ak `data[alive.end..]` yo mouri (sa vle di eleman yo te deja li epi yo pa dwe manyen ankò!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Eleman yo nan `data` ki pa te sede ankò.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Kreye yon iterateur nouvo sou `array` yo bay la.
    ///
    /// *Remak*: metòd sa a ta ka obsolèt nan future la, apre [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Kalite `value` se yon `i32` isit la, olye de `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SEKIRITE: transmut la isit la aktyèlman an sekirite.Dokiman yo nan `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` se garanti yo gen menm gwosè a ak aliyman
        // > kòm `T`.
        //
        // Doktè yo menm montre yon transmute soti nan yon etalaj de `MaybeUninit<T>` nan yon etalaj de `T`.
        //
        //
        // Avèk sa, inisyalizasyon sa a satisfè envariants yo.

        // FIXME(LukasKalbertodt): aktyèlman itilize `mem::transmute` isit la, yon fwa li travay ak konst jenerik:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Jouk lè sa a, nou ka itilize `mem::transmute_copy` yo kreye yon kopi bit tankou yon kalite diferan, Lè sa a, bliye `array` pou ke li pa tonbe.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Retounen yon tranch imuiabl nan tout eleman ki pa te sede ankò.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SEKIRITE: Nou konnen ke tout eleman nan `alive` yo byen inisyalize.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Retounen yon tranch mitab nan tout eleman ki pa te sede ankò.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SEKIRITE: Nou konnen ke tout eleman nan `alive` yo byen inisyalize.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Jwenn endèks kap vini an soti nan devan an.
        //
        // Ogmante `alive.start` pa 1 kenbe envariant la konsènan `alive`.
        // Sepandan, akòz chanjman sa a, pou yon ti tan, zòn vivan an se pa `data[alive]` ankò, men `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Li eleman ki soti nan etalaj la.
            // SEKIRITE: `idx` se yon endèks nan ansyen rejyon "alive" nan
            // etalaj.Lekti eleman sa a vle di ke `data[idx]` konsidere kòm mouri kounye a (sètadi pa manyen).
            // Kòm `idx` te kòmanse nan zòn nan vivan, zòn nan vivan se kounye a `data[alive]` ankò, restore tout envariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Jwenn endèks kap vini an nan do a.
        //
        // Diminye `alive.end` pa 1 kenbe envariant la konsènan `alive`.
        // Sepandan, akòz chanjman sa a, pou yon ti tan, zòn vivan an se pa `data[alive]` ankò, men `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Li eleman ki soti nan etalaj la.
            // SEKIRITE: `idx` se yon endèks nan ansyen rejyon "alive" nan
            // etalaj.Lekti eleman sa a vle di ke `data[idx]` konsidere kòm mouri kounye a (sètadi pa manyen).
            // Kòm `idx` te nan fen zòn nan vivan, zòn nan vivan se kounye a `data[alive]` ankò, restore tout envariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SEKIRITE: Sa a san danje: `as_mut_slice` retounen egzakteman sub-tranch la
        // nan eleman ki pa te deplase soti ankò epi ki rete yo dwe tonbe.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Pa janm pral debòde akòz envariant la `vivan.kòmanse <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iteratè a rapòte tout bon longè ki kòrèk la.
// Nimewo a nan eleman "alive" (ki pral toujou sede) se longè a nan seri a `alive`.
// Sa a ranje dekremente nan longè nan swa `next` oswa `next_back`.
// Li toujou dekremente pa 1 nan metòd sa yo, men sèlman si `Some(_)` retounen.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Remake byen, nou pa reyèlman bezwen matche ak egzak menm ranje vivan an, pou nou ka jis script nan konpanse 0 kèlkeswa kote `self` se.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonaj tout eleman vivan.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Ekri yon script nan etalaj la nouvo, Lè sa a, mete ajou ranje vivan li yo.
            // Si klonaj panics, nou pral kòrèkteman lage atik yo anvan yo.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Se sèlman enprime eleman yo ki pa te sede ankò: nou pa ka jwenn aksè nan eleman yo sede ankò.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}