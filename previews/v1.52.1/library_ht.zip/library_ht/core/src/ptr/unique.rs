use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Yon pakè alantou yon `*mut T` anvan tout koreksyon ki pa nil ki endike ke posede pakè sa a posede referan an.
/// Itil pou bati abstraksyon tankou `Box<T>`, `Vec<T>`, `String`, ak `HashMap<K, V>`.
///
/// Kontrèman ak `*mut T`, `Unique<T>` konpòte li "as if" li te yon egzanp `T`.
/// Li aplike `Send`/`Sync` si `T` se `Send`/`Sync`.
/// Li te tou implique ki kalite fò aliasing garanti yon egzanp nan `T` ka atann:
/// referan a nan konsèy la pa ta dwe modifye san yo pa yon chemen inik nan posede inik li yo.
///
/// Si ou pa sèten si wi ou non li nan kòrèk yo sèvi ak `Unique` pou rezon ou, konsidere lè l sèvi avèk `NonNull`, ki te gen pi fèb semantik.
///
///
/// Kontrèman ak `*mut T`, konsèy la dwe toujou ki pa nil, menm si konsèy la pa janm dereferansye.
/// Sa a se konsa ke enums ka itilize valè sa a entèdi kòm yon diskriminan-`Option<Unique<T>>` gen menm gwosè ak `Unique<T>`.
/// Sepandan konsèy la ka toujou balance si li pa dereferansye.
///
/// Kontrèman ak `*mut T`, `Unique<T>` se covariant sou `T`.
/// Sa a ta dwe toujou kòrèk pou nenpòt ki kalite ki konfime kondisyon aliasing inik la.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: makè sa a pa gen okenn konsekans pou divèjans, men li nesesè
    // pou dropck konprann ke nou lojikman posede yon `T`.
    //
    // Pou plis detay, gade:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pwent yo `Send` si `T` se `Send` paske done yo referans se alyas.
/// Remake byen ke invariant alyasan sa a pa ranfòse pa sistèm nan kalite;abstraksyon an lè l sèvi avèk `Unique` a dwe ranfòse li.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pwent yo `Sync` si `T` se `Sync` paske done yo referans se alyas.
/// Remake byen ke invariant alyasan sa a pa ranfòse pa sistèm nan kalite;abstraksyon an lè l sèvi avèk `Unique` a dwe ranfòse li.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Kreye yon nouvo `Unique` ki pandye, men ki byen aliyen.
    ///
    /// Sa a itil pou inisyalize kalite ki parese asiyen, tankou `Vec::new` fè.
    ///
    /// Remake byen ke valè konsèy la ka reprezante yon konsèy valab pou yon `T`, ki vle di sa pa dwe itilize kòm yon valè santinèl "not yet initialized".
    /// Kalite ki parese asiyen dwe swiv inisyalizasyon pa kèk lòt mwayen.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SEKIRITE: mem::align_of() retounen yon valab, ki pa nil konsèy.La
        // kondisyon yo rele new_unchecked() yo respekte konsa.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Kreye yon nouvo `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` dwe ki pa nil.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEKIRITE: moun kap rele a dwe garanti ke `ptr` pa nil.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Kreye yon nouvo `Unique` si `ptr` ki pa nil.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEKIRITE: Te konsèy la deja tcheke epi li pa nil.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Achte konsèy kache `*mut` la.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferans kontni an.
    ///
    /// Se lavi a ki kapab lakòz mare nan pwòp tèt ou konsa sa a konpòte "as if" li te aktyèlman yon egzanp nan T ki ap resevwa prete.
    /// Si yon lavi (unbound) pi long nesesè, sèvi ak `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` satisfè tout
        // kondisyon pou yon referans.
        unsafe { &*self.as_ptr() }
    }

    /// Mityèlman dereferans kontni an.
    ///
    /// Se lavi a ki kapab lakòz mare nan pwòp tèt ou konsa sa a konpòte "as if" li te aktyèlman yon egzanp nan T ki ap resevwa prete.
    /// Si yon lavi (unbound) pi long nesesè, sèvi ak `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` satisfè tout
        // kondisyon pou yon referans mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Distribisyon nan yon konsèy nan yon lòt kalite.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SEKIRITE: Unique::new_unchecked() kreye yon nouvo inik ak bezwen
        // konsèy yo bay la pa dwe nil.
        // Depi nou ap pase pwòp tèt ou kòm yon konsèy, li pa ka nil.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEKIRITE: Yon referans mutable pa kapab nil
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}