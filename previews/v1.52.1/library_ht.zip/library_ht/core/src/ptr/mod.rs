//! Manyèlman jere memwa nan endikasyon anvan tout koreksyon.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Anpil fonksyon nan modil sa a pran endikasyon anvan tout koreksyon kòm agiman ak li nan oswa ekri yo.Pou sa an sekirite, endikasyon sa yo dwe *valab*.
//! Si yon konsèy valab depann de operasyon li itilize pou (li oswa ekri), ak limit memwa ki jwenn aksè (sètadi, konbyen bytes read/written).
//! Pifò fonksyon itilize `*mut T` ak `* const T` pou jwenn aksè sèlman yon valè sèl, nan ka sa a dokiman an omisyon gwosè a ak implicitement sipoze li yo dwe `size_of::<T>()` bytes.
//!
//! Règ yo egzak pou validite yo pa detèmine ankò.Garanti yo bay nan pwen sa a trè minim:
//!
//! * Yon konsèy [null] se *pa janm* valab, pa menm pou aksè nan [size zero][zst].
//! * Pou yon konsèy yo valab, li nesesè, men se pa toujou ase, ke konsèy la dwe *dereferenceable*: seri a memwa nan gwosè yo bay la kòmanse nan konsèy la dwe tout nan limit yo nan yon sèl objè atribye ba.
//!
//! Remake byen ke nan Rust, chak varyab (stack-allocated) konsidere kòm yon objè separe resevwa lajan.
//! * Menm pou operasyon [size zero][zst], konsèy la pa dwe montre nan memwa deallocated, sa vle di, deallocation fè endikasyon envalid menm pou zewo-gwosè operasyon yo.
//! Sepandan, depoze nenpòt ki antye ki pa zero *literal* nan yon konsèy ki valab pou aksè ki menm gwosè ak zewo, menm si kèk memwa rive egziste nan adrès sa a epi li vin distribye.
//! Sa a koresponn ak ekri alokatè pwòp ou a: asiyen zewo-gwosè objè se pa trè difisil.
//! Fason kanonik pou jwenn yon konsèy ki valab pou aksè zewo-gwosè se [`NonNull::dangling`].
//! * Tout aksè ki fèt pa fonksyon nan modil sa a se *ki pa atomik* nan sans [atomic operations] ki itilize pou senkronize ant fil yo.
//! Sa vle di li se konpòtman endefini fè de aksè konkouran nan menm kote a soti nan fil diferan sof si tou de aksè li sèlman nan memwa.
//! Remake ke sa klèman gen ladan [`read_volatile`] ak [`write_volatile`]: aksè temèt pa ka itilize pou senkronizasyon entè-fil.
//! * Rezilta a nan Distribisyon yon referans a yon konsèy valab pou osi lontan ke objè a kache se ap viv epi pa gen okenn referans (pwent jis anvan tout koreksyon) yo itilize jwenn aksè nan memwa a menm.
//!
//! Aksiom sa yo, ansanm ak itilizasyon ak anpil atansyon [`offset`] pou aritmetik konsèy, yo ase kòrèkteman aplike anpil bagay itil nan kòd danjere.
//! Pi fò garanti yo pral bay evantyèlman, menm jan yo te detèmine règleman [aliasing] yo.
//! Pou plis enfòmasyon, gade [book] la kòm byen ke seksyon an nan referans la konsakre nan [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Valid pwent anvan tout koreksyon jan sa defini pi wo a yo pa nesesèman byen aliyen (kote "proper" aliyman defini nan kalite pointee, sa vle di, `*const T` dwe aliyen ak `mem::align_of::<T>()`).
//! Sepandan, pifò fonksyon mande pou agiman yo byen aliyen, epi yo pral klèman deklare egzijans sa a nan dokiman yo.
//! Eksepsyon remakab nan sa a se [`read_unaligned`] ak [`write_unaligned`].
//!
//! Lè yon fonksyon mande pou aliyman apwopriye, li fè sa menm si aksè a gen gwosè 0, sa vle di, menm si memwa pa aktyèlman manyen.Konsidere itilize [`NonNull::dangling`] nan ka sa yo.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Egzekite destriktè a (si genyen) nan valè a pwente-a.
///
/// Sa a se semantik ekivalan a rele [`ptr::read`] ak jete rezilta a, men li gen avantaj sa yo:
///
/// * Li se *obligatwa* yo sèvi ak `drop_in_place` lage kalite dimansyon tankou objè trait, paske yo pa ka li soti sou chemine a ak tonbe nòmalman.
///
/// * Li pi amikal pou optimizeur la pou fè sa sou [`ptr::read`] lè ou lage manyèlman atribye ba memwa (pa egzanp, nan aplikasyon `Box`/`Rc`/`Vec`), menm jan du a pa bezwen pwouve ke li nan son elide kopi an.
///
///
/// * Li ka itilize pou lage done [pinned] lè `T` se pa `repr(packed)` (done estime yo pa dwe deplase anvan li tonbe).
///
/// Valè ki pa aliyen pa ka tonbe nan plas yo, yo dwe kopye nan yon kote ki aliyen premye lè l sèvi avèk [`ptr::read_unaligned`].Pou chaje structs, mouvman sa a fèt otomatikman pa du a.
/// Sa vle di jaden yo nan struct chaje yo pa tonbe nan plas.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `to_drop` dwe [valid] pou tou de li ak ekri.
///
/// * `to_drop` dwe byen aliyen.
///
/// * Valè `to_drop` pwen yo dwe valab pou jete, ki ka vle di li dwe kenbe envariant adisyonèl, sa a se kalite depandan.
///
/// Anplis de sa, si `T` se pa [`Copy`], lè l sèvi avèk valè a pwente apre ou fin rele `drop_in_place` ka lakòz konpòtman endefini.Remake byen ke `*to_drop = foo` konte kòm yon itilizasyon paske li pral lakòz valè a dwe tonbe ankò.
/// [`write()`] ka itilize recouvrir done san yo pa sa ki lakòz li nan tonbe.
///
/// Remake byen ke menm si `T` gen gwosè `0`, konsèy la dwe ki pa NULL ak byen aliyen.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Manyèlman retire dènye atik la nan yon vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Jwenn yon konsèy anvan tout koreksyon nan eleman ki sot pase a nan `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Vin pi kout `v` pou anpeche dènye atik la tonbe.
///     // Nou fè sa an premye, yo anpeche pwoblèm si `drop_in_place` ki anba a panics.
///     v.set_len(1);
///     // San yo pa yon apèl `drop_in_place`, dènye atik la pa ta janm tonbe, epi memwa li jere ta dwe fwit.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Asire ke dènye atik la te tonbe.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Remake ke du a fè kopi sa a otomatikman lè ou lage structs chaje, sa vle di, anjeneral ou pa bezwen enkyete w pou kesyon sa yo sof si ou rele `drop_in_place` manyèlman.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kòd isit la pa gen pwoblèm, sa a se ranplase pa lakòl la gout reyèl pa du a.
    //

    // SEKIRITE: gade kòmantè anwo a
    unsafe { drop_in_place(to_drop) }
}

/// Kreye yon konsèy nil anvan tout koreksyon.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Kreye yon nil mutable konsèy kri.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manyèl impl nesesè pou fè pou evite `T: Clone` mare.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manyèl impl nesesè pou fè pou evite `T: Copy` mare.
impl<T> Copy for FatPtr<T> {}

/// Fòme yon tranch anvan tout koreksyon ki sòti nan yon konsèy ak yon longè.
///
/// Agiman `len` la se kantite **eleman**, se pa kantite bytes.
///
/// Fonksyon sa a an sekirite, men aktyèlman lè l sèvi avèk valè a retounen se an sekirite.
/// Gade dokiman [`slice::from_raw_parts`] la pou kondisyon sekirite tranch yo.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // kreye yon konsèy tranch lè kòmanse soti ak yon konsèy nan eleman an premye
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SEKIRITE: Aksè valè ki soti nan sendika `Repr` la an sekirite depi * const [T]
        //
        // ak FatPtr gen kouman memwa yo menm.Se sèlman std ki ka fè garanti sa a.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Fè menm fonctionnalités a kòm [`slice_from_raw_parts`], eksepte ke yon tranch kri mutable retounen, kòm opoze a yon tranch kri imuiabl.
///
///
/// Gade dokiman [`slice_from_raw_parts`] la pou plis detay.
///
/// Fonksyon sa a an sekirite, men aktyèlman lè l sèvi avèk valè a retounen se an sekirite.
/// Gade dokiman [`slice::from_raw_parts_mut`] la pou kondisyon sekirite tranch yo.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // bay yon valè nan yon endèks nan tranch la
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SEKIRITE: Aksè valè ki soti nan sendika `Repr` la an sekirite depi * mut [T]
        // ak FatPtr gen kouman memwa yo menm
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Swaps valè yo nan de kote ki ka chanje nan menm kalite a, san yo pa deinitializing swa.
///
/// Men, pou de eksepsyon sa yo, fonksyon sa a se semantik ekivalan a [`mem::swap`]:
///
///
/// * Li opere sou endikasyon anvan tout koreksyon olye pou yo referans.
/// Lè referans yo disponib, [`mem::swap`] ta dwe pi pito.
///
/// * De valè yo pwente-a ka sipèpoze.
/// Si valè yo sipèpoze, lè sa a yo pral itilize rejyon an sipèpoze nan memwa soti nan `x`.
/// Sa demontre nan dezyèm egzanp ki anba a.
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * Tou de `x` ak `y` dwe [valid] pou tou de li ak ekri.
///
/// * Tou de `x` ak `y` dwe byen aliyen.
///
/// Remake byen ke menm si `T` gen gwosè `0`, endikasyon yo dwe ki pa NULL ak byen aliyen.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Boukante de rejyon ki pa sipèpoze:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // sa a se `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // sa a se `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Boukante de rejyon sipèpoze:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // sa a se `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // sa a se `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Endis yo `1..3` nan tranch la sipèpoze ant `x` ak `y`.
///     // Rezilta rezonab yo ta dwe pou yo `[2, 3]`, se konsa ke endis `0..3` yo `[1, 2, 3]` (matche `y` anvan `swap` la);oswa pou yo ka `[0, 1]` pou ke endis `1..4` yo `[0, 1, 2]` (matche `x` anvan `swap` la).
/////
///     // Aplikasyon sa a defini fè chwa lèt la.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Bay tèt nou kèk espas grafouyen pou travay avèk yo.
    // Nou pa bezwen enkyete sou gout: `MaybeUninit` pa fè anyen lè tonbe.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Fè swap la SEKIRITE: moun kap rele a dwe garanti ke `x` ak `y` yo valab pou ekri ak byen aliyen.
    // `tmp` pa ka sipèpoze swa `x` oswa `y` paske `tmp` te jis resevwa lajan sou chemine a kòm yon objè separe resevwa lajan.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ak `y` ka sipèpoze
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Swaps `count * size_of::<T>()` bytes ant de rejyon yo nan memwa kòmanse nan `x` ak `y`.
/// De rejyon yo dwe *pa* sipèpoze.
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * Tou de `x` ak `y` dwe [valid] pou tou de li ak ekri nan `konte *
///   size_of: :<T>() `bytes.
///
/// * Tou de `x` ak `y` dwe byen aliyen.
///
/// * Rejyon an nan memwa kòmanse nan `x` ak yon gwosè nan `konte *
///   size_of: :<T>() `bytes dwe *pa* sipèpoze ak rejyon an nan memwa kòmanse nan `y` ak menm gwosè a.
///
/// Remake byen ke menm si gwosè a efektivman kopye (`konte * size_of: :<T>()`) se `0`, endikasyon yo dwe ki pa NULL ak byen aliyen.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SEKIRITE: moun kap rele a dwe garanti ke `x` ak `y` yo ye
    // valab pou ekri ak byen aliyen.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Pou kalite ki pi piti pase optimize blòk ki anba a, jis swap dirèkteman pou evite pesimize codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SEKIRITE: moun kap rele a dwe garanti ke `x` ak `y` valab
        // pou ekri, byen aliyen, epi ki pa sipèpoze.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Apwòch la isit la se itilize simd swap x&y avèk efikasite.
    // Tès revele ke échanjé swa 32 bytes oswa 64 bytes nan yon moman ki pi efikas pou processeurs Intel Haswell E.
    // LLVM plis kapab optimize si nou bay yon struct yon #[repr(simd)], menm si nou pa aktyèlman itilize struct sa a dirèkteman.
    //
    //
    // FIXME repr(simd) kase sou emscripten ak redoks
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop nan x&y, kopye yo `Block` nan yon tan Optimiseur a ta dwe dewoulman bouk la konplètman pou pifò kalite NB
    // Nou pa ka itilize yon bouk pou `range` impl apèl `mem::swap` rekursivman
    //
    let mut i = 0;
    while i + block_size <= len {
        // Kreye kèk memwa uninitialized kòm espas grate Deklare `t` isit la evite aliyen chemine a lè sa a bouk rès
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SEKIRITE: Kòm `i < len`, epi kòm moun kap rele a dwe garanti ke `x` ak `y` yo valab
        // pou `len` bytes, `x + i` ak `y + i` dwe adrès valab, ki satisfè kontra sekirite pou `add`.
        //
        // Epitou, moun kap rele a dwe garanti ke `x` ak `y` yo valab pou ekri, byen aliyen, epi ki pa sipèpoze, ki satisfè kontra sekirite pou `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Boukante yon blòk bytes nan x&y, lè l sèvi avèk t kòm yon tanpon tanporè Sa a ta dwe optimize nan operasyon efikas SIMD kote ki disponib
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Boukante nenpòt bytes ki rete yo
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SEKIRITE: gade kòmantè sekirite anvan an.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Deplase `src` nan `dst` pwente a, retounen valè `dst` anvan an.
///
/// Ni valè yo tonbe.
///
/// Fonksyon sa a se semantik ekivalan a [`mem::replace`] eksepte ke li opere sou endikasyon anvan tout koreksyon olye pou yo referans.
/// Lè referans yo disponib, [`mem::replace`] ta dwe pi pito.
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `dst` dwe [valid] pou tou de li ak ekri.
///
/// * `dst` dwe byen aliyen.
///
/// * `dst` dwe lonje dwèt sou yon valè byen inisyalize nan kalite `T`.
///
/// Remake byen ke menm si `T` gen gwosè `0`, konsèy la dwe ki pa NULL ak byen aliyen.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ta gen efè a menm san yo pa egzije blòk la an sekirite.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SEKIRITE: moun kap rele a dwe garanti ke `dst` valab yo dwe
    // jete nan yon referans mutable (valab pou ekri, aliyen, inisyalize), epi yo pa ka sipèpoze `src` depi `dst` dwe montre nan yon objè distenk resevwa lajan.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // pa ka sipèpoze
    }
    src
}

/// Li valè ki soti nan `src` san deplase li.Sa a kite memwa a nan `src` chanje.
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `src` dwe [valid] pou li.
///
/// * `src` dwe byen aliyen.Sèvi ak [`read_unaligned`] si sa a se pa ka a.
///
/// * `src` dwe lonje dwèt sou yon valè byen inisyalize nan kalite `T`.
///
/// Remake byen ke menm si `T` gen gwosè `0`, konsèy la dwe ki pa NULL ak byen aliyen.
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manyèlman aplike [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Kreye yon kopi bit nan valè a nan `a` nan `tmp`.
///         let tmp = ptr::read(a);
///
///         // Sòti nan pwen sa a (swa pa klèman retounen oswa lè w rele yon fonksyon ki panics) ta lakòz valè a nan `tmp` yo dwe tonbe pandan y ap menm valè a toujou referansye pa `a`.
///         // Sa a ka deklanche konpòtman endefini si `T` se pa `Copy`.
/////
/////
///
///         // Kreye yon kopi bit nan valè a nan `b` nan `a`.
///         // Sa a san danje paske referans mutable pa ka alyas.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kòm pi wo a, sòti isit la ta ka deklanche konpòtman endefini paske se menm valè a referansye pa `a` ak `b`.
/////
///
///         // Deplase `tmp` nan `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` te deplase (`write` pran an komen nan agiman dezyèm li yo), se konsa pa gen anyen ki tonbe enplisitman isit la.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Pwopriyetè ki gen valè ki retounen an
///
/// `read` kreye yon kopi bit de `T`, kèlkeswa si `T` se [`Copy`].
/// Si `T` se pa [`Copy`], lè l sèvi avèk tou de valè a retounen ak valè a nan `*src` ka vyole sekirite memwa.
/// Remake byen ke asiyen nan `*src` konte kòm yon itilizasyon paske li pral eseye lage valè a nan `* src`.
///
/// [`write()`] ka itilize recouvrir done san yo pa sa ki lakòz li nan tonbe.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` kounye a pwen memwa ki kache menm jan ak `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Plasman nan `s2` lakòz valè orijinal li yo dwe tonbe.
///     // Pi lwen pase pwen sa a, `s` pa dwe itilize ankò, menm jan yo te memwa ki kache libere.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Bay `s` ta lakòz valè a fin vye granmoun yo dwe tonbe ankò, sa ki lakòz konpòtman endefini.
/////
///     // s= String::from("bar");//ERÈ
///
///     // `ptr::write` ka itilize recouvrir yon valè san yo pa jete li.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEKIRITE: moun kap rele a dwe garanti ke `src` valab pou li.
    // `src` pa ka sipèpoze `tmp` paske `tmp` te jis resevwa lajan sou chemine a kòm yon objè separe resevwa lajan.
    //
    //
    // Epitou, depi nou jis ekri yon valè ki valab nan `tmp`, li garanti yo dwe byen inisyalize.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Li valè ki soti nan `src` san deplase li.Sa a kite memwa a nan `src` chanje.
///
/// Kontrèman ak [`read`], `read_unaligned` ap travay avèk endikasyon ki pa aliyen.
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `src` dwe [valid] pou li.
///
/// * `src` dwe lonje dwèt sou yon valè byen inisyalize nan kalite `T`.
///
/// Tankou [`read`], `read_unaligned` kreye yon kopi bit de `T`, kèlkeswa si `T` se [`Copy`].
/// Si `T` se pa [`Copy`], lè l sèvi avèk tou de valè a retounen ak valè a nan `*src` ka [violate memory safety][read-ownership].
///
/// Remake byen ke menm si `T` gen gwosè `0`, konsèy la dwe ki pa NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Sou `packed` structs
///
/// Li aktyèlman enposib yo kreye endikasyon anvan tout koreksyon nan jaden san aliyen nan yon struct chaje.
///
/// Eseye kreye yon konsèy anvan tout koreksyon nan yon jaden struct `unaligned` ak yon ekspresyon tankou `&packed.unaligned as *const FieldType` kreye yon referans entèmedyè san aliyen anvan konvèti sa nan yon konsèy anvan tout koreksyon.
///
/// Ke referans sa a se tanporè ak imedyatman jete se enkonsistan kòm du a toujou espere referans yo dwe byen aliyen.
/// Kòm yon rezilta, lè l sèvi avèk `&packed.unaligned as *const FieldType` lakòz imedya* endefini konpòtman * nan pwogram ou an.
///
/// Yon egzanp sou sa ki pa fè ak ki jan sa a gen rapò ak `read_unaligned` se:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Isit la nou eseye pran adrès yon nonb antye relatif 32-bit ki pa aliyen.
///     let unaligned =
///         // Yon referans tanporè san aliyen kreye isit la ki rezilta nan konpòtman endefini kèlkeswa si wi ou non referans la itilize oswa ou pa.
/////
///         &packed.unaligned
///         // Distribisyon nan yon konsèy kri pa ede;erè a deja rive.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Antre nan jaden ki pa aliyen dirèkteman avèk egzanp `packed.unaligned` san danje sepandan.
///
///
///
///
///
///
// FIXME: Mizajou dokiman ki baze sou rezilta RFC #2582 ak zanmi yo.
/// # Examples
///
/// Li yon valè itilizasyon ki sòti nan yon tanpon byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEKIRITE: moun kap rele a dwe garanti ke `src` valab pou li.
    // `src` pa ka sipèpoze `tmp` paske `tmp` te jis resevwa lajan sou chemine a kòm yon objè separe resevwa lajan.
    //
    //
    // Epitou, depi nou jis ekri yon valè ki valab nan `tmp`, li garanti yo dwe byen inisyalize.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Remplace yon kote memwa ak valè yo bay la san li oswa jete valè a fin vye granmoun.
///
/// `write` pa lage sa ki nan `dst`.
/// Sa a san danje, men li te kapab koule alokasyon oswa resous, kidonk yo ta dwe pran prekosyon pou yo pa kouvri yon objè ki ta dwe tonbe.
///
///
/// Anplis de sa, li pa lage `src`.Semantikman, `src` demenaje ale rete nan kote a pwente pa `dst`.
///
/// Sa a apwopriye pou inisyalize inisyalize memwa, oswa ranplasman memwa ki te deja [`read`] soti nan.
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `dst` dwe [valid] pou ekri.
///
/// * `dst` dwe byen aliyen.Sèvi ak [`write_unaligned`] si sa a se pa ka a.
///
/// Remake byen ke menm si `T` gen gwosè `0`, konsèy la dwe ki pa NULL ak byen aliyen.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manyèlman aplike [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Kreye yon kopi bit nan valè a nan `a` nan `tmp`.
///         let tmp = ptr::read(a);
///
///         // Sòti nan pwen sa a (swa pa klèman retounen oswa lè w rele yon fonksyon ki panics) ta lakòz valè a nan `tmp` yo dwe tonbe pandan y ap menm valè a toujou referansye pa `a`.
///         // Sa a ka deklanche konpòtman endefini si `T` se pa `Copy`.
/////
/////
///
///         // Kreye yon kopi bit nan valè a nan `b` nan `a`.
///         // Sa a san danje paske referans mutable pa ka alyas.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kòm pi wo a, sòti isit la ta ka deklanche konpòtman endefini paske se menm valè a referansye pa `a` ak `b`.
/////
///
///         // Deplase `tmp` nan `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` te deplase (`write` pran an komen nan agiman dezyèm li yo), se konsa pa gen anyen ki tonbe enplisitman isit la.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Nou ap rele intrinsèques yo dirèkteman pou fè pou evite apèl fonksyon nan kòd la pwodwi kòm `intrinsics::copy_nonoverlapping` se yon fonksyon anvlòp.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SEKIRITE: moun kap rele a dwe garanti ke `dst` valab pou ekri.
    // `dst` pa ka sipèpoze `src` paske moun kap rele a gen aksè mitabilite nan `dst` pandan y ap `src` posede pa fonksyon sa a.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Remplace yon kote memwa ak valè yo bay la san li oswa jete valè a fin vye granmoun.
///
/// Kontrèman ak [`write()`], konsèy la ka aliyen.
///
/// `write_unaligned` pa lage sa ki nan `dst`.Sa a san danje, men li te kapab koule alokasyon oswa resous, kidonk yo ta dwe pran prekosyon pou yo pa kouvri yon objè ki ta dwe tonbe.
///
/// Anplis de sa, li pa lage `src`.Semantikman, `src` demenaje ale rete nan kote a pwente pa `dst`.
///
/// Sa a apwopriye pou inisyalize inisyalize memwa, oswa ranplasman memwa ki te deja li ak [`read_unaligned`].
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `dst` dwe [valid] pou ekri.
///
/// Remake byen ke menm si `T` gen gwosè `0`, konsèy la dwe ki pa NULL.
///
/// [valid]: self#safety
///
/// ## Sou `packed` structs
///
/// Li aktyèlman enposib yo kreye endikasyon anvan tout koreksyon nan jaden san aliyen nan yon struct chaje.
///
/// Eseye kreye yon konsèy anvan tout koreksyon nan yon jaden struct `unaligned` ak yon ekspresyon tankou `&packed.unaligned as *const FieldType` kreye yon referans entèmedyè san aliyen anvan konvèti sa nan yon konsèy anvan tout koreksyon.
///
/// Ke referans sa a se tanporè ak imedyatman jete se enkonsistan kòm du a toujou espere referans yo dwe byen aliyen.
/// Kòm yon rezilta, lè l sèvi avèk `&packed.unaligned as *const FieldType` lakòz imedya* endefini konpòtman * nan pwogram ou an.
///
/// Yon egzanp sou sa ki pa fè ak ki jan sa a gen rapò ak `write_unaligned` se:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Isit la nou eseye pran adrès yon nonb antye relatif 32-bit ki pa aliyen.
///     let unaligned =
///         // Yon referans tanporè san aliyen kreye isit la ki rezilta nan konpòtman endefini kèlkeswa si wi ou non referans la itilize oswa ou pa.
/////
///         &mut packed.unaligned
///         // Distribisyon nan yon konsèy kri pa ede;erè a deja rive.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Antre nan jaden ki pa aliyen dirèkteman avèk egzanp `packed.unaligned` san danje sepandan.
///
///
///
///
///
///
///
///
///
// FIXME: Mizajou dokiman ki baze sou rezilta RFC #2582 ak zanmi yo.
/// # Examples
///
/// Ekri yon valè itilizasyon nan yon tanpon byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SEKIRITE: moun kap rele a dwe garanti ke `dst` valab pou ekri.
    // `dst` pa ka sipèpoze `src` paske moun kap rele a gen aksè mitabilite nan `dst` pandan y ap `src` posede pa fonksyon sa a.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Nou ap rele intrinsèques la dirèkteman pou fè pou evite apèl fonksyon nan kòd la pwodwi.
        intrinsics::forget(src);
    }
}

/// Fè yon li temèt nan valè a soti nan `src` san yo pa deplase li.Sa a kite memwa a nan `src` chanje.
///
/// Operasyon temèt yo gen entansyon aji sou memwa I/O, epi yo garanti yo pa dwe elid oswa reordered pa du a atravè lòt operasyon temèt.
///
/// # Notes
///
/// Rust pa gen kounye a yon modèl memwa rigoureux ak fòmèlman defini, se konsa semantik egzak la nan sa ki "volatile" vle di isit la sijè a chanje sou tan.
/// Sa yo te di, semantik la ap prèske toujou fini trè menm jan ak [C11's definition of volatile][c11].
///
/// Du a pa ta dwe chanje lòd relatif la oswa kantite operasyon temèt memwa.
/// Sepandan, operasyon memwa temèt sou kalite zewo-gwosè (egzanp, si se yon kalite zewo-gwosè pase `read_volatile`) yo se noops epi yo ka inyore.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `src` dwe [valid] pou li.
///
/// * `src` dwe byen aliyen.
///
/// * `src` dwe lonje dwèt sou yon valè byen inisyalize nan kalite `T`.
///
/// Tankou [`read`], `read_volatile` kreye yon kopi bit de `T`, kèlkeswa si `T` se [`Copy`].
/// Si `T` se pa [`Copy`], lè l sèvi avèk tou de valè a retounen ak valè a nan `*src` ka [violate memory safety][read-ownership].
/// Sepandan, estoke kalite ki pa [Kopi] nan memwa temèt se prèske sètènman kòrèk.
///
/// Remake byen ke menm si `T` gen gwosè `0`, konsèy la dwe ki pa NULL ak byen aliyen.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Jis tankou nan C, si wi ou non yon operasyon temèt pa gen okenn portant tou sou kesyon ki enplike aksè konkouran soti nan fil miltip.Aksè temèt konpòte yo egzakteman tankou aksè ki pa atomik nan sans sa.
///
/// An patikilye, yon ras ant yon `read_volatile` ak nenpòt ki operasyon ekri nan menm kote a se konpòtman endefini.
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Pa panike kenbe enpak codegen ki pi piti.
        abort();
    }
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Fè yon ekri temèt nan yon kote memwa ak valè yo bay la san li oswa jete valè a fin vye granmoun.
///
/// Operasyon temèt yo gen entansyon aji sou memwa I/O, epi yo garanti yo pa dwe elid oswa reordered pa du a atravè lòt operasyon temèt.
///
/// `write_volatile` pa lage sa ki nan `dst`.Sa a san danje, men li te kapab koule alokasyon oswa resous, kidonk yo ta dwe pran prekosyon pou yo pa kouvri yon objè ki ta dwe tonbe.
///
/// Anplis de sa, li pa lage `src`.Semantikman, `src` demenaje ale rete nan kote a pwente pa `dst`.
///
/// # Notes
///
/// Rust pa gen kounye a yon modèl memwa rigoureux ak fòmèlman defini, se konsa semantik egzak la nan sa ki "volatile" vle di isit la sijè a chanje sou tan.
/// Sa yo te di, semantik la ap prèske toujou fini trè menm jan ak [C11's definition of volatile][c11].
///
/// Du a pa ta dwe chanje lòd relatif la oswa kantite operasyon temèt memwa.
/// Sepandan, operasyon memwa temèt sou kalite zewo-gwosè (egzanp, si se yon kalite zewo-gwosè pase `write_volatile`) yo se noops epi yo ka inyore.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Konpòtman pa defini si yo vyole nenpòt nan kondisyon sa yo:
///
/// * `dst` dwe [valid] pou ekri.
///
/// * `dst` dwe byen aliyen.
///
/// Remake byen ke menm si `T` gen gwosè `0`, konsèy la dwe ki pa NULL ak byen aliyen.
///
/// [valid]: self#safety
///
/// Jis tankou nan C, si wi ou non yon operasyon temèt pa gen okenn portant tou sou kesyon ki enplike aksè konkouran soti nan fil miltip.Aksè temèt konpòte yo egzakteman tankou aksè ki pa atomik nan sans sa.
///
/// An patikilye, yon ras ant yon `write_volatile` ak nenpòt lòt operasyon (lekti oswa ekri) sou menm kote a se konpòtman endefini.
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Pa panike kenbe enpak codegen ki pi piti.
        abort();
    }
    // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Aliman konsèy `p`.
///
/// Kalkile konpanse (an tèm de eleman nan `stride` stride) ki te dwe aplike nan konsèy `p` pou ke konsèy `p` ta jwenn aliyen ak `a`.
///
/// Note: Aplikasyon sa a te byen pwepare pou pa panic.Li se UB pou sa a panic.
/// Sèl chanjman reyèl ki ka fèt isit la se chanjman `INV_TABLE_MOD_16` ak konstan asosye yo.
///
/// Si nou janm deside fè li posib yo rele intrinsèques la ak `a` ki se pa yon pouvwa-de-de, li pral pwobableman gen plis pridan jis chanje nan yon aplikasyon nayif olye ke eseye adapte sa a akomode ki chanjman.
///
///
/// Nenpòt kesyon ale sou@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Sèvi dirèk nan sa yo intrinsèques amelyore codegen siyifikativman nan opt-nivo <=
    // 1, kote vèsyon yo metòd nan operasyon sa yo yo pa aliyen.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Kalkile miltiplikatif envès modilè nan `x` modulo `m`.
    ///
    /// Aplikasyon sa a pwepare pou `align_offset` e li gen kondisyon sa yo:
    ///
    /// * `m` se yon pouvwa-de-de;
    /// * `x < m`; (si `x ≥ m`, pase nan `x % m` olye de sa)
    ///
    /// Aplikasyon nan fonksyon sa a pa dwe panic.Tout tan.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Miltiplikatif modilè inverse tab modulo 2⁴=16.
        ///
        /// Remake byen, ke tablo sa a pa gen valè kote envès pa egziste (sa vle di, pou `0⁻¹ mod 16`, `2⁻¹ mod 16`, elatriye)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo pou ki `INV_TABLE_MOD_16` la fèt.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SEKIRITE: `m` oblije yon pouvwa-de-de, pakonsekan ki pa zewo.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Nou repete "up" lè l sèvi avèk fòmil sa a:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // jouk 2²ⁿ ≥ m.Lè sa a, nou ka redwi a `m` vle nou an lè nou pran rezilta `mod m` la.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Remake byen, ke nou itilize anbalaj operasyon isit la entansyonèlman-fòmil orijinal la sèvi ak egzanp, soustraksyon `mod n`.
                // Li se antyèman amann fè yo `mod usize::MAX` olye, paske nou pran rezilta a `mod n` nan fen a de tout fason.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SEKIRITE: `a` se yon pouvwa-de-, Se poutèt sa ki pa zewo.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` ka ka kalkile plis tou senpleman nan `-p (mod a)`, men fè sa inibit kapasite LLVM a yo chwazi enstriksyon tankou `lea`.Olye de sa nou kalkile
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // ki distribye operasyon alantou chay-pote a, men pesimize `and` ase pou LLVM pou kapab itilize optimize yo divès kalite li konnen sou yo.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Deja aliyen.Yay!
        return 0;
    } else if stride == 0 {
        // Si konsèy la pa aliyen, ak eleman an se zewo-gwosè, Lè sa a, pa gen okenn kantite lajan nan eleman ap janm aliman konsèy la.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SEKIRITE: yon se pouvwa-de-pakonsekan ki pa zewo.stride==0 ka trete pi wo a.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SEKIRITE: gcdpow gen yon anwo-mare sa a, se nan pifò kantite Bits nan yon usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SEKIRITE: gcd se toujou pi gran oswa egal a 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch sa a rezoud pou ekwasyon kongriyans lineyè sa yo:
        //
        // ` p + so = 0 mod a `
        //
        // `p` isit la se valè a konsèy, `s`, stride nan `T`, `o` konpanse nan `T`s, ak `a`, aliyman an mande yo.
        //
        // Avèk `g = gcd(a, s)`, ak kondisyon ki anwo a ki afime ke `p` se tou divizib pa `g`, nou ka endike `a' = a/g`, `s' = s/g`, `p' = p/g`, Lè sa a, sa a vin ekivalan a:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Premye manda a se "the relative alignment of `p` to `a`" (divize pa `g`), dezyèm manda a se "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (ankò divize pa `g`).
        //
        // Divizyon pa `g` nesesè pou fè envès la byen fòme si `a` ak `s` yo pa ko-premye.
        //
        // Anplis de sa, rezilta a ki te pwodwi pa solisyon sa a se pa "minimal", kidonk li nesesè pran rezilta a `o mod lcm(s, a)`.Nou ka ranplase `lcm(s, a)` ak jis yon `a'`.
        //
        //
        //
        //
        //

        // SEKIRITE: `gcdpow` gen yon anwo-mare pa pi gran pase nimewo a nan fin 0-Bits nan `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SEKIRITE: `a2` ki pa zewo.Chanje `a` pa `gcdpow` pa ka chanje soti nenpòt nan Bits yo mete
        // nan `a` (nan ki li gen egzakteman yon sèl).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SEKIRITE: `gcdpow` gen yon anwo-mare pa pi gran pase nimewo a nan fin 0-Bits nan `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SEKIRITE: `gcdpow` gen yon anwo-mare pa pi gran pase nimewo a nan fin 0-Bits nan
        // `a`.
        // Anplis de sa, soustraksyon an pa ka debòde, paske `a2 = a >> gcdpow` ap toujou entèdi pi gran pase `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SEKIRITE: `a2` se yon pouvwa-de-de, jan yo pwouve pi wo a.`s2` se senpman mwens pase `a2`
        // paske `(s % a) >> gcdpow` se senpman mwens pase `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Pa ka aliyen ditou.
    usize::MAX
}

/// Konpare endikasyon anvan tout koreksyon pou egalite.
///
/// Sa a se menm bagay la kòm lè l sèvi avèk operatè a `==`, men mwens jenerik:
/// agiman yo dwe `*const T` endikasyon anvan tout koreksyon, pa anyen ki aplike `PartialEq`.
///
/// Sa a ka itilize yo konpare `&T` referans (ki fòse `*const T` enplisitman) pa adrès yo olye ke konpare valè yo yo montre nan (ki se sa ki aplikasyon an `PartialEq for &T` fè).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Tranch yo konpare tou pa longè yo (endikasyon grès):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits yo tou konpare pa aplikasyon yo:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Endikasyon gen adrès egal.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objè gen adrès egal, men `Trait` gen aplikasyon diferan.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Konvèti referans a nan yon `*const u8` konpare pa adrès.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash yon konsèy kri.
///
/// Sa a ka itilize nan hash yon referans `&T` (ki fòse `*const T` enplisitman) pa adrès li olye ke valè a li lonje dwèt sou (ki se sa ki aplikasyon an `Hash for &T` fè).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls pou endikasyon fonksyon
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Se jete entèmedyè a kòm usize obligatwa pou AVR
                // se konsa ke espas adrès la nan konsèy la fonksyon sous konsève nan konsèy la fonksyon final la.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Se jete entèmedyè a kòm usize obligatwa pou AVR
                // se konsa ke espas adrès la nan konsèy la fonksyon sous konsève nan konsèy la fonksyon final la.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Pa gen fonksyon variadic ak 0 paramèt
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Kreye yon `const` konsèy kri nan yon kote, san yo pa kreye yon referans entèmedyè.
///
/// Kreye yon referans ak `&`/`&mut` pèmèt sèlman si konsèy la byen aliyen ak pwen done inisyalize yo.
/// Pou ka kote kondisyon sa yo pa kenbe, endikasyon anvan tout koreksyon yo ta dwe itilize olye.
/// Sepandan, `&expr as *const _` kreye yon referans anvan depoze li nan yon konsèy anvan tout koreksyon, e referans sa a sijè a règleman yo menm jan ak tout lòt referans.
///
/// Macro sa a ka kreye yon konsèy kri *san yo pa* kreye yon referans an premye.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` ta kreye yon referans san aliyen, e konsa gen Konpòtman ki pa defini!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Kreye yon `mut` konsèy kri nan yon kote, san yo pa kreye yon referans entèmedyè.
///
/// Kreye yon referans ak `&`/`&mut` pèmèt sèlman si konsèy la byen aliyen ak pwen done inisyalize yo.
/// Pou ka kote kondisyon sa yo pa kenbe, endikasyon anvan tout koreksyon yo ta dwe itilize olye.
/// Sepandan, `&mut expr as *mut _` kreye yon referans anvan depoze li nan yon konsèy anvan tout koreksyon, e referans sa a sijè a règleman yo menm jan ak tout lòt referans.
///
/// Macro sa a ka kreye yon konsèy kri *san yo pa* kreye yon referans an premye.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` ta kreye yon referans san aliyen, e konsa gen Konpòtman ki pa defini!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` fòs kopye jaden an olye pou yo kreye yon referans.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}