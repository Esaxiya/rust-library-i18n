#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Bay kalite metadata konsèy nenpòt kalite pwente.
///
/// # Pointe métadonnées
///
/// Kalite konsèy kri ak kalite referans nan Rust ka panse a kòm te fè nan de pati:
/// yon konsèy done ki gen adrès memwa valè a, ak kèk metadata.
///
/// Pou kalite statik ki menm gwosè ak (ki aplike `Sized` traits a) osi byen ke pou kalite `extern`, endikasyon yo di yo dwe "mens": metadata se zewo-gwosè ak kalite li yo se `()`.
///
///
/// Pwent [dynamically-sized types][dst] yo di yo dwe "lajè" oswa "grès", yo gen metadata ki pa zewo ki menm gwosè ak:
///
/// * Pou struct ki gen dènye jaden an se yon DST, metadata se metadata pou dènye jaden an
/// * Pou kalite `str`, metadata se longè an bytes kòm `usize`
/// * Pou kalite tranch tankou `[T]`, metadata se longè nan atik kòm `usize`
/// * Pou objè trait tankou `dyn SomeTrait`, metadata se [`DynMetadata<Self>`][DynMetadata] (egzanp `DynMetadata<dyn SomeTrait>`)
///
/// Nan future, lang Rust la ka jwenn nouvo kalite kalite ki gen diferan Metadata konsèy.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait la
///
/// Pwen trait sa a se kalite asosye `Metadata` li yo, ki se `()` oswa `usize` oswa `DynMetadata<_>` jan sa dekri anwo a.
/// Li otomatikman aplike pou chak kalite.
/// Li ka sipoze aplike nan yon kontèks jenerik, menm san yon korespondan mare.
///
/// # Usage
///
/// Endikasyon kri yo ka dekonpoze nan adrès done yo ak eleman metadata ak metòd [`to_raw_parts`] yo.
///
/// Altènativman, Metadata pou kont li ka ekstrè ak fonksyon [`metadata`] la.
/// Yon referans ka pase nan [`metadata`] ak enplisit kontrent.
///
/// Ou ka mete yon konsèy (possibly-wide) ansanm nan adrès li ak metadata ak [`from_raw_parts`] oswa [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Kalite pou Metadata nan endikasyon ak referans a `Self`.
    #[lang = "metadata_type"]
    // NOTE: Kenbe trait bounds nan `static_assert_expected_bounds_for_metadata`
    //
    // nan `library/core/src/ptr/metadata.rs` nan senkronizasyon ak sa yo isit la:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Endikasyon nan kalite aplike sa a trait alyas yo "mens".
///
/// Sa gen ladann tipikman-gwosè "kalite" ak kalite `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: pa estabilize sa a anvan trait alyas yo ki estab nan lang lan?
pub trait Thin = Pointee<Metadata = ()>;

/// Ekstrè eleman metadata yon konsèy.
///
/// Valè nan kalite `*mut T`, `&T`, oswa `&mut T` ka pase dirèkteman nan fonksyon sa a menm jan yo enplisit kontrent `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SEKIRITE: Aksè valè ki soti nan sendika `PtrRepr` la an sekirite depi * konst T
    // ak PtrComponents<T>gen kouman memwa yo menm.
    // Se sèlman std ki ka fè garanti sa a.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Fòme yon konsèy (possibly-wide) anvan tout koreksyon ki sòti nan yon adrès done ak metadata.
///
/// Fonksyon sa a an sekirite, men konsèy la retounen se pa nesesèman san danje yo dereferans.
/// Pou tranch, gade dokiman [`slice::from_raw_parts`] pou kondisyon sekirite.
/// Pou objè trait, metadata yo dwe soti nan yon konsèy sou menm kalite kache ki disparèt la.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SEKIRITE: Aksè valè ki soti nan sendika `PtrRepr` la an sekirite depi * konst T
    // ak PtrComponents<T>gen kouman memwa yo menm.
    // Se sèlman std ki ka fè garanti sa a.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Fè menm fonctionnalités a kòm [`from_raw_parts`], eksepte ke se yon konsèy `*mut` anvan tout koreksyon retounen, kòm opoze a yon konsèy anvan tout koreksyon `* const`.
///
///
/// Gade dokiman [`from_raw_parts`] la pou plis detay.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SEKIRITE: Aksè valè ki soti nan sendika `PtrRepr` la an sekirite depi * konst T
    // ak PtrComponents<T>gen kouman memwa yo menm.
    // Se sèlman std ki ka fè garanti sa a.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manyèl impl nesesè pou fè pou evite `T: Copy` mare.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manyèl impl nesesè pou fè pou evite `T: Clone` mare.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata yo pou yon kalite objè `Dyn = dyn SomeTrait` trait.
///
/// Li se yon konsèy nan yon vtable (tab apèl vityèl) ki reprezante tout enfòmasyon ki nesesè yo manipile kalite a konkrè ki estoke andedan yon objè trait.
/// Vtable la miyò li genyen ladan li:
///
/// * kalite gwosè
/// * kalite aliyman
/// * yon konsèy nan `drop_in_place` kalite tip a (pouvwa gen yon pa gen okenn-op pou plenn-fin vye granmoun-done)
/// * endikasyon nan tout metòd yo pou aplikasyon kalite a nan trait la
///
/// Remake byen ke twa premye yo espesyal paske yo ap nesesè yo asiyen, gout, ak deallocate nenpòt objè trait.
///
/// Li posib pou non struct sa a ak yon paramèt kalite ki pa yon objè `dyn` trait (pa egzanp `DynMetadata<u64>`) men se pa pou jwenn yon valè siyifikatif nan struct sa a.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Prefiks la komen nan tout vtables.Li swiv pa endikasyon fonksyon pou metòd trait.
///
/// Prive aplikasyon detay nan `DynMetadata::size_of` elatriye.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Retounen gwosè a nan kalite ki asosye ak vtable sa a.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Retounen aliyman kalite ki asosye avèk vtable sa a.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Retounen gwosè a ak aliyman ansanm kòm yon `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SEKIRITE: du a emèt vtable sa a pou yon kalite konkrè Rust ki
        // se konnen yo gen yon Layout ki valab.Menm rezon tankou nan `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manyèl impls nesesè pou fè pou evite limit `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}