use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Retounen `true` si konsèy la nil.
    ///
    /// Remake byen ke kalite gwosè gen anpil pwent posib nil, kòm se sèlman konsèy la done anvan tout koreksyon konsidere, pa longè yo, vtable, elatriye.
    /// Se poutèt sa, de endikasyon ki nil ka toujou pa konpare egal youn ak lòt.
    ///
    /// ## Konpòtman pandan evalyasyon konst
    ///
    /// Lè yo itilize fonksyon sa a pandan evalyasyon konstan, li ka retounen `false` pou endikasyon ki vire nil nan ègzekutabl.
    /// Espesyalman, lè yon konsèy nan kèk memwa konpanse pi lwen pase limit li yo nan yon fason ke konsèy la ki kapab lakòz se nil, fonksyon an ap toujou retounen `false`.
    ///
    /// Pa gen okenn fason pou CTFE konnen pozisyon absoli memwa sa a, kidonk nou pa ka di si konsèy la nil oswa ou pa.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Konpare via yon jete nan yon konsèy mens, se konsa endikasyon grès yo sèlman konsidere pati "data" yo pou nil-ness.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Distribisyon nan yon konsèy nan yon lòt kalite.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Dekonpoze yon konsèy (petèt lajè) nan adrès ak konpozan metadata.
    ///
    /// Ka konsèy la dwe pita rekonstwi ak [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Retounen `None` si konsèy la se nil, oswa lòt moun retounen yon referans pataje nan valè a vlope nan `Some`.Si valè a ka inisyalize, [`as_uninit_ref`] dwe itilize olye.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Lè w rele metòd sa a, ou dwe asire ke *swa* konsèy la se NIL *oswa* tout bagay sa yo se verite:
    ///
    /// * Konsèy la dwe byen aliyen.
    ///
    /// * Li dwe "dereferencable" nan sans ki defini nan [the module documentation].
    ///
    /// * Konsèy la dwe lonje dwèt sou yon egzanp inisyalize nan `T`.
    ///
    /// * Ou dwe ranfòse règleman alyasman Rust a, depi `'a` pou tout lavi retounen abitrèman chwazi epi yo pa nesesèman reflete lavi aktyèl la nan done yo.
    ///   An patikilye, pou dire a nan lavi sa a, memwa nan pwen yo konsèy pa dwe jwenn mitasyon (eksepte andedan `UnsafeCell`).
    ///
    /// Sa a aplike menm si rezilta a nan metòd sa a rès!
    /// (Pati a sou ke yo te inisyalize se pa sa ankò konplètman deside, men jiskaske li se, apwòch la sèlman ki an sekirite se asire ke yo tout bon inisyalize.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Nil-san vèsyon
    ///
    /// Si ou sèten konsèy la pa janm ka nil epi yo ap chèche pou kèk kalite `as_ref_unchecked` ki retounen `&T` a olye pou yo `Option<&T>`, konnen ke ou ka dereference konsèy la dirèkteman.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` valab
        // pou yon referans si li pa nil.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Retounen `None` si konsèy la se nil, oswa lòt moun retounen yon referans pataje nan valè a vlope nan `Some`.
    /// Kontrèman a [`as_ref`], sa pa mande pou valè a dwe inisyalize.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Lè w rele metòd sa a, ou dwe asire ke *swa* konsèy la se NIL *oswa* tout bagay sa yo se verite:
    ///
    /// * Konsèy la dwe byen aliyen.
    ///
    /// * Li dwe "dereferencable" nan sans ki defini nan [the module documentation].
    ///
    /// * Ou dwe ranfòse règleman alyasman Rust a, depi `'a` pou tout lavi retounen abitrèman chwazi epi yo pa nesesèman reflete lavi aktyèl la nan done yo.
    ///
    ///   An patikilye, pou dire a nan lavi sa a, memwa nan pwen yo konsèy pa dwe jwenn mitasyon (eksepte andedan `UnsafeCell`).
    ///
    /// Sa a aplike menm si rezilta a nan metòd sa a rès!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` satisfè tout
        // kondisyon pou yon referans.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Kalkile konpanse ki soti nan yon konsèy.
    ///
    /// `count` se nan inite T;egzanp, yon `count` nan 3 reprezante yon konpanse konsèy nan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Si yo vyole nenpòt nan kondisyon sa yo, rezilta a se Konpòtman Endefini:
    ///
    /// * Tou de konsèy la kòmanse ak ki kapab lakòz yo dwe swa nan limit oswa yon sèl byte sot pase yo nan fen menm objè a resevwa lajan.
    /// Remake byen ke nan Rust, chak varyab (stack-allocated) konsidere kòm yon objè separe resevwa lajan.
    ///
    /// * Offset a kalkile,**nan bytes**, pa ka debòde yon `isize`.
    ///
    /// * Desantre a nan limit pa ka konte sou "wrapping around" espas adrès la.Sa se, enfini-presizyon sòm total la,**nan bytes** dwe anfòm nan yon usize.
    ///
    /// Konpilatè a ak bibliyotèk estanda jeneralman eseye asire alokasyon pa janm rive nan yon gwosè kote yon konpanse se yon enkyetid.
    /// Pou egzanp, `Vec` ak `Box` asire yo pa janm asiyen plis pase `isize::MAX` bytes, se konsa `vec.as_ptr().add(vec.len())` se toujou an sekirite.
    ///
    /// Pifò tribin fondamantalman pa menm ka konstwi tankou yon alokasyon.
    /// Pou egzanp, pa gen okenn platfòm li te ye 64-ti jan ka janm sèvi yon demann pou 2 <sup>63</sup> bytes akòz limit paj-tab oswa divize espas adrès la.
    /// Sepandan, kèk platfòm 32-bit ak 16-bit ka avèk siksè sèvi yon demann pou plis pase `isize::MAX` bytes ak bagay tankou ekstansyon adrès fizik.
    ///
    /// Kòm sa yo, memwa akeri ki sòti dirèkteman nan alokatè oswa memwa trase dosye *pouvwa* twò gwo okipe ak fonksyon sa a.
    ///
    /// Konsidere itilize [`wrapping_offset`] olye si kontrent sa yo difisil pou satisfè.
    /// Avantaj nan sèlman nan metòd sa a se ke li pèmèt optimize pi agresif du.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Kalkile konpanse ki soti nan yon konsèy lè l sèvi avèk aritmetik anbalaj.
    ///
    /// `count` se nan inite T;egzanp, yon `count` nan 3 reprezante yon konpanse konsèy nan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Operasyon sa a li menm se toujou an sekirite, men lè l sèvi avèk konsèy la ki kapab lakòz se pa.
    ///
    /// Konsèy la ki kapab lakòz rete tache ak objè a menm atribye ba ki pwen `self`.
    /// Li ka *pa* dwe itilize pou jwenn aksè nan yon objè diferan resevwa lajan.Remake byen ke nan Rust, chak varyab (stack-allocated) konsidere kòm yon objè separe resevwa lajan.
    ///
    /// Nan lòt mo, `let z = x.wrapping_offset((y as isize) - (x as isize))` fè *pa* fè `z` menm jan ak `y` menm si nou sipoze `T` gen gwosè `1` epi pa gen okenn debòde: `z` toujou tache ak objè a `x` se tache ak, ak dereferencing li se Konpòtman Endefini sof si `x` ak `y` pwen nan menm objè a resevwa lajan.
    ///
    /// Konpare ak [`offset`], metòd sa a fondamantalman retade egzijans pou rete nan menm objè ki resevwa lajan an: [`offset`] se yon konpòtman imedyat san defini lè w ap travèse limit objè yo;`wrapping_offset` pwodui yon konsèy men li toujou mennen nan Konpòtman Endefini si yon konsèy dereferansye lè li soti-of-limit nan objè a li se tache ak.
    /// [`offset`] ka optimize pi byen e se konsa pi preferab nan kòd pèfòmans-sansib.
    ///
    /// Chèk la anreta sèlman konsidere valè konsèy la ki te dereferansye, pa valè entèmedyè yo itilize pandan kalkil rezilta final la.
    /// Pou egzanp, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` se toujou menm jan ak `x`.Nan lòt mo, kite objè a resevwa lajan ak Lè sa a, re-antre nan li pita pèmèt.
    ///
    /// Si ou bezwen travèse limit objè, jete konsèy la nan yon nonb antye relatif epi fè aritmetik la.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// // Iterate lè l sèvi avèk yon konsèy anvan tout koreksyon nan ogmantasyon de eleman
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Sa a bouk enprime "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SEKIRITE: `arith_offset` intrinsèques la pa gen okenn kondisyon yo dwe rele.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Kalkile distans ki genyen ant de pwent.Valè retounen an se nan inite T: distans an bytes divize pa `mem::size_of::<T>()`.
    ///
    /// Fonksyon sa a se envès [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Si yo vyole nenpòt nan kondisyon sa yo, rezilta a se Konpòtman Endefini:
    ///
    /// * Tou de konsèy la kòmanse ak lòt yo dwe swa nan limit oswa yon sèl byte sot pase yo nan fen menm objè a resevwa lajan.
    /// Remake byen ke nan Rust, chak varyab (stack-allocated) konsidere kòm yon objè separe resevwa lajan.
    ///
    /// * Tou de endikasyon yo dwe *sòti nan* yon konsèy nan menm objè a.
    ///   (Gade anba a pou yon egzanp.)
    ///
    /// * Distans ki genyen ant endikasyon yo, an bytes, dwe yon miltip egzak nan gwosè `T`.
    ///
    /// * Distans ki genyen ant endikasyon yo,**nan bytes**, pa ka debòde yon `isize`.
    ///
    /// * Distans ke yo te nan limit pa ka konte sou "wrapping around" espas adrès la.
    ///
    /// Kalite Rust yo pa janm pi gwo pase `isize::MAX` ak Rust alokasyon pa janm vlope toutotou espas adrès la, se konsa de endikasyon nan kèk valè de nenpòt ki kalite Rust `T` ap toujou satisfè de dènye kondisyon yo.
    ///
    /// Bibliyotèk la estanda tou jeneralman asire ke alokasyon pa janm rive nan yon gwosè kote yon konpanse se yon enkyetid.
    /// Pou egzanp, `Vec` ak `Box` asire yo pa janm asiyen plis pase `isize::MAX` bytes, se konsa `ptr_into_vec.offset_from(vec.as_ptr())` toujou satisfè de dènye kondisyon yo.
    ///
    /// Pifò tribin fondamantalman pa menm ka konstwi tankou yon gwo alokasyon.
    /// Pou egzanp, pa gen okenn platfòm li te ye 64-ti jan ka janm sèvi yon demann pou 2 <sup>63</sup> bytes akòz limit paj-tab oswa divize espas adrès la.
    /// Sepandan, kèk platfòm 32-bit ak 16-bit ka avèk siksè sèvi yon demann pou plis pase `isize::MAX` bytes ak bagay tankou ekstansyon adrès fizik.
    /// Kòm sa yo, memwa akeri ki sòti dirèkteman nan alokatè oswa memwa trase dosye *pouvwa* twò gwo okipe ak fonksyon sa a.
    /// (Remake byen ke [`offset`] ak [`add`] tou gen yon limit ki sanble yo e pakonsekan pa ka itilize sou gwo alokasyon sa yo swa.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Fonksyon sa a panics si `T` se yon Zewo-gwosè Kalite ("ZST").
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Kòrèk* l ':
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Fè ptr2_other yon "alias" nan ptr2, men sòti nan ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Depi ptr2_other ak ptr2 yo sòti nan endikasyon nan objè diferan, informatique konpanse yo se konpòtman endefini, menm si yo lonje dwèt sou menm adrès la!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Konpòtman san defini
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Retounen si wi ou non de endikasyon yo garanti yo dwe egal.
    ///
    /// Nan ègzekutabl fonksyon sa a konpòte li tankou `self == other`.
    /// Sepandan, nan kèk kontèks (egzanp, evalyasyon konpile-tan), li pa toujou posib pou detèmine egalite nan de pwent, kidonk fonksyon sa a ka fè espre retounen `false` pou endikasyon ki pita aktyèlman vire soti yo dwe egal.
    ///
    /// Men, lè li retounen `true`, endikasyon yo garanti yo dwe egal.
    ///
    /// Fonksyon sa a se glas la nan [`guaranteed_ne`], men se pa envès li yo.Gen konparezon konsèy pou ki tou de fonksyon retounen `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Valè a retounen ka chanje depann sou vèsyon an du ak kòd ki an sekirite ka pa konte sou rezilta a nan fonksyon sa a pou solid.
    /// Li sijere ke yo itilize sèlman fonksyon sa a pou optimize pèfòmans kote fo valè retounen `false` pa fonksyon sa a pa afekte rezilta a, men jis pèfòmans lan.
    /// Konsekans yo nan lè l sèvi avèk metòd sa a fè ègzekutabl ak konpile-tan postal konpòte yo yon fason diferan pa te eksplore.
    /// Metòd sa a pa ta dwe itilize prezante diferans sa yo, epi li ta dwe tou pa dwe estabilize anvan nou gen yon pi bon konpreyansyon yo genyen sou pwoblèm sa a.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Retounen si wi ou non de endikasyon yo garanti yo dwe inegal.
    ///
    /// Nan ègzekutabl fonksyon sa a konpòte li tankou `self != other`.
    /// Sepandan, nan kèk kontèks (egzanp, evalyasyon konpile-tan), li pa toujou posib pou detèmine inegalite de pwent yo, kidonk fonksyon sa a ka fè espre retounen `false` pou endikasyon ki pita aktyèlman vire soti yo dwe inegal.
    ///
    /// Men, lè li retounen `true`, endikasyon yo garanti yo dwe inegal.
    ///
    /// Fonksyon sa a se glas la nan [`guaranteed_eq`], men se pa envès li yo.Gen konparezon konsèy pou ki tou de fonksyon retounen `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Valè a retounen ka chanje depann sou vèsyon an du ak kòd ki an sekirite ka pa konte sou rezilta a nan fonksyon sa a pou solid.
    /// Li sijere ke yo itilize sèlman fonksyon sa a pou optimize pèfòmans kote fo valè retounen `false` pa fonksyon sa a pa afekte rezilta a, men jis pèfòmans lan.
    /// Konsekans yo nan lè l sèvi avèk metòd sa a fè ègzekutabl ak konpile-tan postal konpòte yo yon fason diferan pa te eksplore.
    /// Metòd sa a pa ta dwe itilize prezante diferans sa yo, epi li ta dwe tou pa dwe estabilize anvan nou gen yon pi bon konpreyansyon yo genyen sou pwoblèm sa a.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Kalkile konpanse ki soti nan yon konsèy (konvenyans pou `.offset(count as isize)`).
    ///
    /// `count` se nan inite T;egzanp, yon `count` nan 3 reprezante yon konpanse konsèy nan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Si yo vyole nenpòt nan kondisyon sa yo, rezilta a se Konpòtman Endefini:
    ///
    /// * Tou de konsèy la kòmanse ak ki kapab lakòz yo dwe swa nan limit oswa yon sèl byte sot pase yo nan fen menm objè a resevwa lajan.
    /// Remake byen ke nan Rust, chak varyab (stack-allocated) konsidere kòm yon objè separe resevwa lajan.
    ///
    /// * Offset a kalkile,**nan bytes**, pa ka debòde yon `isize`.
    ///
    /// * Desantre a nan limit pa ka konte sou "wrapping around" espas adrès la.Sa vle di, sòm enfini-presizyon an dwe anfòm nan yon `usize`.
    ///
    /// Konpilatè a ak bibliyotèk estanda jeneralman eseye asire alokasyon pa janm rive nan yon gwosè kote yon konpanse se yon enkyetid.
    /// Pou egzanp, `Vec` ak `Box` asire yo pa janm asiyen plis pase `isize::MAX` bytes, se konsa `vec.as_ptr().add(vec.len())` se toujou an sekirite.
    ///
    /// Pifò tribin fondamantalman pa menm ka konstwi tankou yon alokasyon.
    /// Pou egzanp, pa gen okenn platfòm li te ye 64-ti jan ka janm sèvi yon demann pou 2 <sup>63</sup> bytes akòz limit paj-tab oswa divize espas adrès la.
    /// Sepandan, kèk platfòm 32-bit ak 16-bit ka avèk siksè sèvi yon demann pou plis pase `isize::MAX` bytes ak bagay tankou ekstansyon adrès fizik.
    ///
    /// Kòm sa yo, memwa akeri ki sòti dirèkteman nan alokatè oswa memwa trase dosye *pouvwa* twò gwo okipe ak fonksyon sa a.
    ///
    /// Konsidere itilize [`wrapping_add`] olye si kontrent sa yo difisil pou satisfè.
    /// Avantaj nan sèlman nan metòd sa a se ke li pèmèt optimize pi agresif du.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Kalkile konpanse ki soti nan yon konsèy (konvenyans pou `. Offset ((konte kòm isize).wrapping_neg())`).
    ///
    /// `count` se nan inite T;egzanp, yon `count` nan 3 reprezante yon konpanse konsèy nan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Si yo vyole nenpòt nan kondisyon sa yo, rezilta a se Konpòtman Endefini:
    ///
    /// * Tou de konsèy la kòmanse ak ki kapab lakòz yo dwe swa nan limit oswa yon sèl byte sot pase yo nan fen menm objè a resevwa lajan.
    /// Remake byen ke nan Rust, chak varyab (stack-allocated) konsidere kòm yon objè separe resevwa lajan.
    ///
    /// * Offset a kalkile pa ka depase `isize::MAX`**bytes**.
    ///
    /// * Desantre a nan limit pa ka konte sou "wrapping around" espas adrès la.Sa se, sòm enfini-presizyon an dwe anfòm nan yon usize.
    ///
    /// Konpilatè a ak bibliyotèk estanda jeneralman eseye asire alokasyon pa janm rive nan yon gwosè kote yon konpanse se yon enkyetid.
    /// Pou egzanp, `Vec` ak `Box` asire yo pa janm asiyen plis pase `isize::MAX` bytes, se konsa `vec.as_ptr().add(vec.len()).sub(vec.len())` se toujou an sekirite.
    ///
    /// Pifò tribin fondamantalman pa menm ka konstwi tankou yon alokasyon.
    /// Pou egzanp, pa gen okenn platfòm li te ye 64-ti jan ka janm sèvi yon demann pou 2 <sup>63</sup> bytes akòz limit paj-tab oswa divize espas adrès la.
    /// Sepandan, kèk platfòm 32-bit ak 16-bit ka avèk siksè sèvi yon demann pou plis pase `isize::MAX` bytes ak bagay tankou ekstansyon adrès fizik.
    ///
    /// Kòm sa yo, memwa akeri ki sòti dirèkteman nan alokatè oswa memwa trase dosye *pouvwa* twò gwo okipe ak fonksyon sa a.
    ///
    /// Konsidere itilize [`wrapping_sub`] olye si kontrent sa yo difisil pou satisfè.
    /// Avantaj nan sèlman nan metòd sa a se ke li pèmèt optimize pi agresif du.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Kalkile konpanse ki soti nan yon konsèy lè l sèvi avèk aritmetik anbalaj.
    /// (konvenyans pou `.wrapping_offset(count as isize)`)
    ///
    /// `count` se nan inite T;egzanp, yon `count` nan 3 reprezante yon konpanse konsèy nan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Operasyon sa a li menm se toujou an sekirite, men lè l sèvi avèk konsèy la ki kapab lakòz se pa.
    ///
    /// Konsèy la ki kapab lakòz rete tache ak objè a menm atribye ba ki pwen `self`.
    /// Li ka *pa* dwe itilize pou jwenn aksè nan yon objè diferan resevwa lajan.Remake byen ke nan Rust, chak varyab (stack-allocated) konsidere kòm yon objè separe resevwa lajan.
    ///
    /// Nan lòt mo, `let z = x.wrapping_add((y as usize) - (x as usize))` fè *pa* fè `z` menm jan ak `y` menm si nou sipoze `T` gen gwosè `1` epi pa gen okenn debòde: `z` toujou tache ak objè a `x` se tache ak, ak dereferencing li se Konpòtman Endefini sof si `x` ak `y` pwen nan menm objè a resevwa lajan.
    ///
    /// Konpare ak [`add`], metòd sa a fondamantalman retade egzijans pou rete nan menm objè ki resevwa lajan an: [`add`] se yon konpòtman imedyat san defini lè w ap travèse limit objè yo;`wrapping_add` pwodui yon konsèy men li toujou mennen nan Konpòtman Endefini si yon konsèy dereferansye lè li soti-of-limit nan objè a li se tache ak.
    /// [`add`] ka optimize pi byen e se konsa pi preferab nan kòd pèfòmans-sansib.
    ///
    /// Chèk la anreta sèlman konsidere valè konsèy la ki te dereferansye, pa valè entèmedyè yo itilize pandan kalkil rezilta final la.
    /// Pou egzanp, `x.wrapping_add(o).wrapping_sub(o)` se toujou menm jan ak `x`.Nan lòt mo, kite objè a resevwa lajan ak Lè sa a, re-antre nan li pita pèmèt.
    ///
    /// Si ou bezwen travèse limit objè, jete konsèy la nan yon nonb antye relatif epi fè aritmetik la.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// // Iterate lè l sèvi avèk yon konsèy anvan tout koreksyon nan ogmantasyon de eleman
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Sa a bouk enprime "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Kalkile konpanse ki soti nan yon konsèy lè l sèvi avèk aritmetik anbalaj.
    /// (konvenyans pou `.wrapping_offset ((konte kòm isize).wrapping_neg())`)
    ///
    /// `count` se nan inite T;egzanp, yon `count` nan 3 reprezante yon konpanse konsèy nan `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Operasyon sa a li menm se toujou an sekirite, men lè l sèvi avèk konsèy la ki kapab lakòz se pa.
    ///
    /// Konsèy la ki kapab lakòz rete tache ak objè a menm atribye ba ki pwen `self`.
    /// Li ka *pa* dwe itilize pou jwenn aksè nan yon objè diferan resevwa lajan.Remake byen ke nan Rust, chak varyab (stack-allocated) konsidere kòm yon objè separe resevwa lajan.
    ///
    /// Nan lòt mo, `let z = x.wrapping_sub((x as usize) - (y as usize))` fè *pa* fè `z` menm jan ak `y` menm si nou sipoze `T` gen gwosè `1` epi pa gen okenn debòde: `z` toujou tache ak objè a `x` se tache ak, ak dereferencing li se Konpòtman Endefini sof si `x` ak `y` pwen nan menm objè a resevwa lajan.
    ///
    /// Konpare ak [`sub`], metòd sa a fondamantalman retade egzijans pou rete nan menm objè ki resevwa lajan an: [`sub`] se yon konpòtman imedyat san defini lè w ap travèse limit objè yo;`wrapping_sub` pwodui yon konsèy men li toujou mennen nan Konpòtman Endefini si yon konsèy dereferansye lè li soti-of-limit nan objè a li se tache ak.
    /// [`sub`] ka optimize pi byen e se konsa pi preferab nan kòd pèfòmans-sansib.
    ///
    /// Chèk la anreta sèlman konsidere valè konsèy la ki te dereferansye, pa valè entèmedyè yo itilize pandan kalkil rezilta final la.
    /// Pou egzanp, `x.wrapping_add(o).wrapping_sub(o)` se toujou menm jan ak `x`.Nan lòt mo, kite objè a resevwa lajan ak Lè sa a, re-antre nan li pita pèmèt.
    ///
    /// Si ou bezwen travèse limit objè, jete konsèy la nan yon nonb antye relatif epi fè aritmetik la.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// // Iterate lè l sèvi avèk yon konsèy anvan tout koreksyon nan ogmantasyon de eleman (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Sa a bouk enprime "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Mete valè konsèy nan `ptr`.
    ///
    /// Nan ka `self` se yon konsèy (fat) nan yon kalite gwosè, operasyon sa a pral sèlman afekte pati nan konsèy, Lè nou konsidere ke pou (thin) endikasyon nan kalite gwosè, sa a gen efè a menm jan ak yon plasman ki senp.
    ///
    /// Konsèy la ki kapab lakòz ap gen orijin nan `val`, sa vle di, pou yon konsèy grès, operasyon sa a se semantik menm jan ak kreye yon nouvo konsèy grès ak valè a konsèy done nan `val` men metadata yo nan `self`.
    ///
    ///
    /// # Examples
    ///
    /// Fonksyon sa a se sitou itil pou pèmèt aritmetik konsèy byte-ki gen bon konprann sou pwent potansyèlman grès:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // ap enprime "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SEKIRITE: Nan ka yon konsèy mens, operasyon sa a ki idantik
        // nan yon plasman senp.
        // Nan ka yon konsèy grès, ak aplikasyon aktyèl la Layout konsèy grès, premye jaden an tankou yon konsèy toujou konsèy la done, ki se menm jan an tou asiyen.
        //
        unsafe { *thin = val };
        self
    }

    /// Li valè ki soti nan `self` san deplase li.
    /// Sa a kite memwa a nan `self` chanje.
    ///
    /// Gade [`ptr::read`] pou enkyetid ak egzanp sekirite.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `read`.
        unsafe { read(self) }
    }

    /// Fè yon li temèt nan valè a soti nan `self` san yo pa deplase li.Sa a kite memwa a nan `self` chanje.
    ///
    /// Operasyon temèt yo gen entansyon aji sou memwa I/O, epi yo garanti yo pa dwe elid oswa reordered pa du a atravè lòt operasyon temèt.
    ///
    ///
    /// Gade [`ptr::read_volatile`] pou enkyetid ak egzanp sekirite.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Li valè ki soti nan `self` san deplase li.
    /// Sa a kite memwa a nan `self` chanje.
    ///
    /// Kontrèman ak `read`, konsèy la ka aliyen.
    ///
    /// Gade [`ptr::read_unaligned`] pou enkyetid ak egzanp sekirite.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopi `count * size_of<T>` bytes soti nan `self` rive `dest`.
    /// Sous la ak destinasyon ka sipèpoze.
    ///
    /// NOTE: sa gen menm lòd agiman * kòm [`ptr::copy`].
    ///
    /// Gade [`ptr::copy`] pou enkyetid ak egzanp sekirite.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopi `count * size_of<T>` bytes soti nan `self` rive `dest`.
    /// Sous la ak destinasyon an ka *pa* sipèpoze.
    ///
    /// NOTE: sa gen menm lòd agiman * kòm [`ptr::copy_nonoverlapping`].
    ///
    /// Gade [`ptr::copy_nonoverlapping`] pou enkyetid ak egzanp sekirite.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kalkile konpanse a ki bezwen aplike nan konsèy la yo nan lòd yo fè li aliyen ak `align`.
    ///
    /// Si li pa posib fè aliman konsèy la, aplikasyon an retounen `usize::MAX`.
    /// Li akseptab pou aplikasyon an *toujou* retounen `usize::MAX`.
    /// Se sèlman pèfòmans algorithm ou a ka depann de ap resevwa yon konpanse ka itilize isit la, pa kòrèkte li yo.
    ///
    /// Se konpanse nan eksprime nan kantite eleman `T`, epi yo pa bytes.Valè retounen an ka itilize ak metòd `wrapping_add`.
    ///
    /// Pa gen okenn garanti tou ke konpanse konsèy la pa pral debòde oswa ale pi lwen pase alokasyon an ki pwen yo konsèy nan.
    ///
    /// Li se jiska moun kap rele a asire ke konpanse nan retounen kòrèk nan tout tèm lòt pase aliyman.
    ///
    /// # Panics
    ///
    /// Fonksyon panics a si `align` se pa yon pouvwa-de-de.
    ///
    /// # Examples
    ///
    /// Antre nan adjasan `u8` kòm `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // pandan y ap konsèy la ka aliyen via `offset`, li ta pwen deyò alokasyon an
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SEKIRITE: `align` te tcheke yo dwe yon pouvwa nan 2 pi wo a
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Retounen longè yon tranch kri.
    ///
    /// Valè a retounen se kantite **eleman**, pa kantite bytes.
    ///
    /// Fonksyon sa a an sekirite, menm lè tranch la anvan tout koreksyon pa ka jete nan yon referans tranch paske konsèy la nil oswa san aliyen.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEKIRITE: sa a san danje paske `*const [T]` ak `FatPtr<T>` gen menm Layout la.
            // Se sèlman `std` ki ka fè garanti sa a.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Retounen yon konsèy anvan tout koreksyon nan tanpon tranch la.
    ///
    /// Sa a ekivalan a depoze `self` `*const T`, men plis kalite-san danje.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Retounen yon konsèy anvan tout koreksyon nan yon eleman oswa subslice, san yo pa fè limit tcheke.
    ///
    /// Rele metòd sa a ak yon endèks deyò-oswa-limit lè `self` se pa dereferansabl se *[endefini konpòtman]* menm si konsèy la ki kapab lakòz pa itilize.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SEKIRITE: moun kap rele a asire ke `self` se dereferencable ak `index` nan-limit.
        unsafe { index.get_unchecked(self) }
    }

    /// Retounen `None` si konsèy la se nil, oswa lòt moun retounen yon tranch pataje nan valè a vlope nan `Some`.
    /// Kontrèman a [`as_ref`], sa pa mande pou valè a dwe inisyalize.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Lè w rele metòd sa a, ou dwe asire ke *swa* konsèy la se NIL *oswa* tout bagay sa yo se verite:
    ///
    /// * Konsèy la dwe [valid] pou li pou `ptr.len() * mem::size_of::<T>()` anpil bytes, epi li dwe byen aliyen.Sa vle di an patikilye:
    ///
    ///     * Ranje a memwa tout nan sa a tranch dwe genyen nan yo nan yon sèl objè atribye ba!
    ///       Tranch pa janm ka span atravè plizyè objè resevwa lajan.
    ///
    ///     * Pointer la dwe aliyen menm pou tranch zewo-longè.
    ///     Youn nan rezon pou sa a se ke optimize layout enum ka konte sou referans (ki gen ladan tranch nan nenpòt ki longè) yo te aliyen ak ki pa nil yo fè distenksyon ant yo soti nan lòt done.
    ///
    ///     Ou ka jwenn yon konsèy ki ka itilize kòm `data` pou tranch zewo-longè lè l sèvi avèk [`NonNull::dangling()`].
    ///
    /// * Gwosè total `ptr.len() * mem::size_of::<T>()` nan tranch la pa dwe pi gwo pase `isize::MAX`.
    ///   Gade dokiman sekirite [`pointer::offset`] la.
    ///
    /// * Ou dwe ranfòse règleman alyasman Rust a, depi `'a` pou tout lavi retounen abitrèman chwazi epi yo pa nesesèman reflete lavi aktyèl la nan done yo.
    ///   An patikilye, pou dire a nan lavi sa a, memwa nan pwen yo konsèy pa dwe jwenn mitasyon (eksepte andedan `UnsafeCell`).
    ///
    /// Sa a aplike menm si rezilta a nan metòd sa a rès!
    ///
    /// Gade tou [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Egalite pou endikasyon
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Konparezon pou endikasyon
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}