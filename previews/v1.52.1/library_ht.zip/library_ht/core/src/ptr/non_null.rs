use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` men ki pa zewo ak covariant.
///
/// Sa a se souvan bagay ki kòrèk la yo sèvi ak lè bati estrikti done lè l sèvi avèk endikasyon anvan tout koreksyon, men se finalman pi danjere yo sèvi ak paske nan pwopriyete adisyonèl li yo.Si ou pa sèten si ou ta dwe itilize `NonNull<T>`, jis itilize `*mut T`!
///
/// Kontrèman ak `*mut T`, konsèy la dwe toujou ki pa nil, menm si konsèy la pa janm dereferansye.Sa a se konsa ke enums ka itilize valè sa a entèdi kòm yon diskriminan-`Option<NonNull<T>>` gen menm gwosè ak `* mut T`.
/// Sepandan konsèy la ka toujou balance si li pa dereferansye.
///
/// Kontrèman ak `*mut T`, `NonNull<T>` te chwazi yo dwe Covariant sou `T`.Sa fè li posib pou itilize `NonNull<T>` lè w ap bati kalite kovariant, men li entwodui risk ensolitid si yo itilize nan yon kalite ki pa ta dwe aktyèlman covariant.
/// (Chwa opoze a te fè pou `*mut T` menm si teknikman ka lakòz pwoblèm nan sèlman ki te koze pa rele fonksyon ki pa an sekirite.)
///
/// Covariance kòrèk pou pi abstrèksyon san danje, tankou `Box`, `Rc`, `Arc`, `Vec`, ak `LinkedList`.Sa a se ka a paske yo bay yon API piblik ki swiv nòmal pataje XOR règ yo mutable nan Rust.
///
/// Si tip ou a pa ka san danje konvariant, ou dwe asire li gen kèk jaden anplis bay envariance.Souvan jaden sa a pral yon kalite [`PhantomData`] tankou `PhantomData<Cell<T>>` oswa `PhantomData<&'a mut T>`.
///
/// Remake `NonNull<T>` gen yon egzanp `From` pou `&T`.Sepandan, sa pa chanje lefèt ke mitasyon nan yon (konsèy sòti nan yon) referans pataje se konpòtman endefini sof si mitasyon an k ap pase andedan yon [`UnsafeCell<T>`].Menm bagay la tou ale pou kreye yon referans mutable ki sòti nan yon referans pataje.
///
/// Lè w ap itilize egzanp `From` sa a san yon `UnsafeCell<T>`, se responsablite w pou asire ke `as_mut` pa janm rele, epi `as_ptr` pa janm itilize pou mitasyon.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pwent yo pa `Send` paske done yo referans yo ka alyas.
// NB, impl sa a pa nesesè, men yo ta dwe bay pi bon mesaj erè.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pwent yo pa `Sync` paske done yo referans yo ka alyas.
// NB, impl sa a pa nesesè, men yo ta dwe bay pi bon mesaj erè.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Kreye yon nouvo `NonNull` ki pandye, men ki byen aliyen.
    ///
    /// Sa a itil pou inisyalize kalite ki parese asiyen, tankou `Vec::new` fè.
    ///
    /// Remake byen ke valè konsèy la ka reprezante yon konsèy valab pou yon `T`, ki vle di sa pa dwe itilize kòm yon valè santinèl "not yet initialized".
    /// Kalite ki parese asiyen dwe swiv inisyalizasyon pa kèk lòt mwayen.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SEKIRITE: mem::align_of() retounen yon itilizasyon ki pa zewo ki lè sa a jete
        // a yon * mut T.
        // Se poutèt sa, `ptr` se pa nil ak kondisyon yo pou rele new_unchecked() yo respekte.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Retounen yon referans pataje nan valè a.Kontrèman a [`as_ref`], sa pa mande pou valè a dwe inisyalize.
    ///
    /// Pou kontrepati a mutable wè [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Lè w rele metòd sa a, ou dwe asire ke tout bagay sa yo se verite:
    ///
    /// * Konsèy la dwe byen aliyen.
    ///
    /// * Li dwe "dereferencable" nan sans ki defini nan [the module documentation].
    ///
    /// * Ou dwe ranfòse règleman alyasman Rust a, depi `'a` pou tout lavi retounen abitrèman chwazi epi yo pa nesesèman reflete lavi aktyèl la nan done yo.
    ///
    ///   An patikilye, pou dire a nan lavi sa a, memwa nan pwen yo konsèy pa dwe jwenn mitasyon (eksepte andedan `UnsafeCell`).
    ///
    /// Sa a aplike menm si rezilta a nan metòd sa a rès!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` satisfè tout
        // kondisyon pou yon referans.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Retounen yon referans inik nan valè a.Kontrèman a [`as_mut`], sa pa mande pou valè a dwe inisyalize.
    ///
    /// Pou kontrepati a pataje gade [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Lè w rele metòd sa a, ou dwe asire ke tout bagay sa yo se verite:
    ///
    /// * Konsèy la dwe byen aliyen.
    ///
    /// * Li dwe "dereferencable" nan sans ki defini nan [the module documentation].
    ///
    /// * Ou dwe ranfòse règleman alyasman Rust a, depi `'a` pou tout lavi retounen abitrèman chwazi epi yo pa nesesèman reflete lavi aktyèl la nan done yo.
    ///
    ///   An patikilye, pou dire a nan tout lavi sa a, memwa a pwen yo pwen yo pa dwe jwenn aksè (li oswa ekri) nan nenpòt lòt konsèy.
    ///
    /// Sa a aplike menm si rezilta a nan metòd sa a rès!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` satisfè tout
        // kondisyon pou yon referans.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Kreye yon nouvo `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` dwe ki pa nil.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEKIRITE: moun kap rele a dwe garanti ke `ptr` pa nil.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Kreye yon nouvo `NonNull` si `ptr` ki pa nil.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEKIRITE: konsèy la deja tcheke epi li pa nil
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Fè menm fonctionnalités a kòm [`std::ptr::from_raw_parts`], eksepte ke yon konsèy `NonNull` retounen, kòm opoze a yon konsèy `*const` anvan tout koreksyon.
    ///
    ///
    /// Gade dokiman [`std::ptr::from_raw_parts`] la pou plis detay.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SEKIRITE: Rezilta `ptr::from::raw_parts_mut` la pa nil paske `data_address` se.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Dekonpoze yon konsèy (petèt lajè) nan adrès ak konpozan metadata.
    ///
    /// Ka konsèy la dwe pita rekonstwi ak [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Achte konsèy kache `*mut` la.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Retounen yon referans pataje nan valè a.Si valè a ka inisyalize, [`as_uninit_ref`] dwe itilize olye.
    ///
    /// Pou kontrepati a mutable wè [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Lè w rele metòd sa a, ou dwe asire ke tout bagay sa yo se verite:
    ///
    /// * Konsèy la dwe byen aliyen.
    ///
    /// * Li dwe "dereferencable" nan sans ki defini nan [the module documentation].
    ///
    /// * Konsèy la dwe lonje dwèt sou yon egzanp inisyalize nan `T`.
    ///
    /// * Ou dwe ranfòse règleman alyasman Rust a, depi `'a` pou tout lavi retounen abitrèman chwazi epi yo pa nesesèman reflete lavi aktyèl la nan done yo.
    ///
    ///   An patikilye, pou dire a nan lavi sa a, memwa nan pwen yo konsèy pa dwe jwenn mitasyon (eksepte andedan `UnsafeCell`).
    ///
    /// Sa a aplike menm si rezilta a nan metòd sa a rès!
    /// (Pati a sou ke yo te inisyalize se pa sa ankò konplètman deside, men jiskaske li se, apwòch la sèlman ki an sekirite se asire ke yo tout bon inisyalize.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` satisfè tout
        // kondisyon pou yon referans.
        unsafe { &*self.as_ptr() }
    }

    /// Retounen yon referans inik nan valè a.Si valè a ka inisyalize, [`as_uninit_mut`] dwe itilize olye.
    ///
    /// Pou kontrepati a pataje gade [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Lè w rele metòd sa a, ou dwe asire ke tout bagay sa yo se verite:
    ///
    /// * Konsèy la dwe byen aliyen.
    ///
    /// * Li dwe "dereferencable" nan sans ki defini nan [the module documentation].
    ///
    /// * Konsèy la dwe lonje dwèt sou yon egzanp inisyalize nan `T`.
    ///
    /// * Ou dwe ranfòse règleman alyasman Rust a, depi `'a` pou tout lavi retounen abitrèman chwazi epi yo pa nesesèman reflete lavi aktyèl la nan done yo.
    ///
    ///   An patikilye, pou dire a nan tout lavi sa a, memwa a pwen yo pwen yo pa dwe jwenn aksè (li oswa ekri) nan nenpòt lòt konsèy.
    ///
    /// Sa a aplike menm si rezilta a nan metòd sa a rès!
    /// (Pati a sou ke yo te inisyalize se pa sa ankò konplètman deside, men jiskaske li se, apwòch la sèlman ki an sekirite se asire ke yo tout bon inisyalize.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEKIRITE: moun kap rele a dwe garanti ke `self` satisfè tout
        // kondisyon pou yon referans mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Distribisyon nan yon konsèy nan yon lòt kalite.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SEKIRITE: `self` se yon konsèy `NonNull` ki nesesèman ki pa nil
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Kreye yon tranch ki pa nil anvan tout koreksyon soti nan yon konsèy mens ak yon longè.
    ///
    /// Agiman `len` la se kantite **eleman**, se pa kantite bytes.
    ///
    /// Fonksyon sa a an sekirite, men dereferansye valè retou a pa an sekirite.
    /// Gade dokiman [`slice::from_raw_parts`] la pou kondisyon sekirite tranch yo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // kreye yon konsèy tranch lè kòmanse soti ak yon konsèy nan eleman an premye
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Remake byen ke egzanp sa a atifisyèlman demontre yon itilizasyon metòd sa a, men `kite tranch= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SEKIRITE: `data` se yon konsèy `NonNull` ki nesesèman ki pa nil
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Retounen longè yon tranch ki pa nil anvan tout koreksyon.
    ///
    /// Valè a retounen se kantite **eleman**, pa kantite bytes.
    ///
    /// Fonksyon sa a san danje, menm lè tranch la ki pa nil anvan tout koreksyon pa ka dereferansye nan yon tranch paske konsèy la pa gen yon adrès valab.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Retounen yon konsèy ki pa nil nan tanpon tranch la.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SEKIRITE: Nou konnen `self` ki pa nil.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Retounen yon konsèy anvan tout koreksyon nan tanpon tranch la.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Retounen yon referans pataje nan yon tranch nan valè petèt uninitialized.Kontrèman a [`as_ref`], sa pa mande pou valè a dwe inisyalize.
    ///
    /// Pou kontrepati a mutable wè [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Lè w rele metòd sa a, ou dwe asire ke tout bagay sa yo se verite:
    ///
    /// * Konsèy la dwe [valid] pou li pou `ptr.len() * mem::size_of::<T>()` anpil bytes, epi li dwe byen aliyen.Sa vle di an patikilye:
    ///
    ///     * Ranje a memwa tout nan sa a tranch dwe genyen nan yo nan yon sèl objè atribye ba!
    ///       Tranch pa janm ka span atravè plizyè objè resevwa lajan.
    ///
    ///     * Pointer la dwe aliyen menm pou tranch zewo-longè.
    ///     Youn nan rezon pou sa a se ke optimize layout enum ka konte sou referans (ki gen ladan tranch nan nenpòt ki longè) yo te aliyen ak ki pa nil yo fè distenksyon ant yo soti nan lòt done.
    ///
    ///     Ou ka jwenn yon konsèy ki ka itilize kòm `data` pou tranch zewo-longè lè l sèvi avèk [`NonNull::dangling()`].
    ///
    /// * Gwosè total `ptr.len() * mem::size_of::<T>()` nan tranch la pa dwe pi gwo pase `isize::MAX`.
    ///   Gade dokiman sekirite [`pointer::offset`] la.
    ///
    /// * Ou dwe ranfòse règleman alyasman Rust a, depi `'a` pou tout lavi retounen abitrèman chwazi epi yo pa nesesèman reflete lavi aktyèl la nan done yo.
    ///   An patikilye, pou dire a nan lavi sa a, memwa nan pwen yo konsèy pa dwe jwenn mitasyon (eksepte andedan `UnsafeCell`).
    ///
    /// Sa a aplike menm si rezilta a nan metòd sa a rès!
    ///
    /// Gade tou [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Retounen yon referans inik nan yon tranch nan valè petèt uninitialized.Kontrèman a [`as_mut`], sa pa mande pou valè a dwe inisyalize.
    ///
    /// Pou kontrepati a pataje gade [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Lè w rele metòd sa a, ou dwe asire ke tout bagay sa yo se verite:
    ///
    /// * Konsèy la dwe [valid] pou li ak ekri pou `ptr.len() * mem::size_of::<T>()` anpil bytes, epi li dwe byen aliyen.Sa vle di an patikilye:
    ///
    ///     * Ranje a memwa tout nan sa a tranch dwe genyen nan yo nan yon sèl objè atribye ba!
    ///       Tranch pa janm ka span atravè plizyè objè resevwa lajan.
    ///
    ///     * Pointer la dwe aliyen menm pou tranch zewo-longè.
    ///     Youn nan rezon pou sa a se ke optimize layout enum ka konte sou referans (ki gen ladan tranch nan nenpòt ki longè) yo te aliyen ak ki pa nil yo fè distenksyon ant yo soti nan lòt done.
    ///
    ///     Ou ka jwenn yon konsèy ki ka itilize kòm `data` pou tranch zewo-longè lè l sèvi avèk [`NonNull::dangling()`].
    ///
    /// * Gwosè total `ptr.len() * mem::size_of::<T>()` nan tranch la pa dwe pi gwo pase `isize::MAX`.
    ///   Gade dokiman sekirite [`pointer::offset`] la.
    ///
    /// * Ou dwe ranfòse règleman alyasman Rust a, depi `'a` pou tout lavi retounen abitrèman chwazi epi yo pa nesesèman reflete lavi aktyèl la nan done yo.
    ///   An patikilye, pou dire a nan tout lavi sa a, memwa a pwen yo pwen yo pa dwe jwenn aksè (li oswa ekri) nan nenpòt lòt konsèy.
    ///
    /// Sa a aplike menm si rezilta a nan metòd sa a rès!
    ///
    /// Gade tou [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Sa a san danje kòm `memory` valab pou li ak ekri pou `memory.len()` anpil bytes.
    /// // Remake byen ke rele `memory.as_mut()` pa pèmèt isit la kòm kontni an ka uninitialized.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SEKIRITE: moun kap rele a dwe konfime kontra sekirite pou `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Retounen yon konsèy anvan tout koreksyon nan yon eleman oswa subslice, san yo pa fè limit tcheke.
    ///
    /// Rele metòd sa a ak yon endèks deyò-oswa-limit lè `self` se pa dereferansabl se *[endefini konpòtman]* menm si konsèy la ki kapab lakòz pa itilize.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SEKIRITE: moun kap rele a asire ke `self` se dereferencable ak `index` nan-limit.
        // Kòm yon konsekans, konsèy la ki kapab lakòz pa kapab NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SEKIRITE: Yon konsèy inik pa kapab nil, se konsa kondisyon yo pou
        // new_unchecked() yo respekte.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEKIRITE: Yon referans mutable pa kapab nil.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SEKIRITE: Yon referans pa kapab nil, se konsa kondisyon yo pou
        // new_unchecked() yo respekte.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}