//! Modil sa a aplike `Any` trait a, ki pèmèt dinamik sezisman nan nenpòt kalite `'static` nan refleksyon ègzekutabl.
//!
//! `Any` tèt li ka itilize yo ka resevwa yon `TypeId`, e li gen plis karakteristik lè yo itilize kòm yon objè trait.
//! Kòm `&dyn Any` (yon objè trait prete), li gen metòd `is` ak `downcast_ref`, pou teste si valè ki genyen an se yon kalite yo bay, epi pou jwenn yon referans a valè enteryè a kòm yon kalite.
//! Kòm `&mut dyn Any`, gen tou metòd la `downcast_mut`, pou jwenn yon referans mutable nan valè enteryè a.
//! `Box<dyn Any>` ajoute metòd la `downcast`, ki eseye konvèti nan yon `Box<T>`.
//! Gade dokiman [`Box`] la pou detay konplè yo.
//!
//! Remake byen ke `&dyn Any` limite a tès si yon valè se nan yon kalite konkrè espesifye, epi yo pa kapab itilize li teste si yon kalite aplike yon trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Endikasyon entelijan ak `dyn Any`
//!
//! Yon sèl moso nan konpòtman kenbe nan tèt ou lè w ap itilize `Any` kòm yon objè trait, espesyalman ak kalite tankou `Box<dyn Any>` oswa `Arc<dyn Any>`, se ke tou senpleman rele `.type_id()` sou valè a pral pwodwi `TypeId` nan *veso a*, pa objè a trait kache.
//!
//! Sa a ka evite pa konvèti konsèy la entelijan nan yon `&dyn Any` olye, ki pral retounen `TypeId` objè a.
//! Pa egzanp:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Ou gen plis chans vle sa a:
//! let actual_id = (&*boxed).type_id();
//! // ... pase sa a:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Konsidere yon sitiyasyon kote nou vle konekte yon valè pase nan yon fonksyon.
//! Nou konnen valè a nou ap travay sou aplike debug, men nou pa konnen ki kalite konkrè li yo.Nou vle bay tretman espesyal nan sèten kalite: nan ka sa a enprime soti longè a nan valè fisèl anvan valè yo.
//! Nou pa konnen ki kalite konkrè valè nou nan tan konpile, kidonk nou bezwen sèvi ak refleksyon ègzekutabl olye.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Fonksyon Logger pou nenpòt ki kalite ki aplike debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Eseye konvèti valè nou an nan yon `String`.
//!     // Si siksè, nou vle pwodiksyon longè fisèl la kòm byen ke valè li yo.
//!     // Si ou pa, li nan yon kalite diferan: jis enprime li soti dekore.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Fonksyon sa a vle konekte paramèt li yo anvan yo fè travay avèk li.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... fè kèk lòt travay
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Nenpòt trait
///////////////////////////////////////////////////////////////////////////////

/// Yon trait rivalize sezisman dinamik.
///
/// Pifò kalite aplike `Any`.Sepandan, nenpòt ki kalite ki gen yon referans ki pa "estatik" pa fè sa.
/// Gade [module-level documentation][mod] la pou plis detay.
///
/// [mod]: crate::any
// trait sa a pa an sekirite, menm si nou konte sou spesifik yo nan fonksyon sèl li a `type_id` impl nan kòd ki pa an sekirite (egzanp, `downcast`).Nòmalman, sa ta yon pwoblèm, men paske sèlman impl nan `Any` se yon aplikasyon dra, pa gen okenn lòt kòd ka aplike `Any`.
//
// Nou te kapab plausibly fè sa a trait danjere-li pa ta lakòz rupture, depi nou kontwole tout aplikasyon yo-men nou chwazi pa tankou sa a tou de pa reyèlman nesesè epi yo ka konfonn itilizatè yo sou distenksyon an nan danjere traits ak metòd danjere (sa vle di `type_id` ta toujou an sekirite yo rele, men nou ta gen anpil chans vle endike tankou sa yo nan dokiman).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Vin `TypeId` nan `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metòd ekstansyon pou nenpòt objè trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Asire ke rezilta a nan egzanp, rantre nan yon fil ka enprime yo e pakonsekan itilize ak `unwrap`.
// Me evantyèlman pa bezwen ankò si ekspedisyon travay ak upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Retounen `true` si kalite bwat la menm jan ak `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Jwenn `TypeId` nan kalite sa a se fonksyon enstansye ak.
        let t = TypeId::of::<T>();

        // Jwenn `TypeId` nan kalite a nan objè a trait (`self`).
        let concrete = self.type_id();

        // Konpare tou de `TypeId`s sou egalite.
        t == concrete
    }

    /// Retounen kèk referans a valè bwat la si li se nan kalite `T`, oswa `None` si li pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SEKIRITE: jis tcheke si nou ap montre nan kalite ki kòrèk la, epi nou ka konte sou
            // ki tcheke pou sekirite memwa paske nou te aplike Nenpòt pou tout kalite;pa gen lòt impls ka egziste menm jan yo ta konfli ak impl nou an.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Retounen kèk referans mutable nan valè a bwat si li se nan kalite `T`, oswa `None` si li pa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SEKIRITE: jis tcheke si nou ap montre nan kalite ki kòrèk la, epi nou ka konte sou
            // ki tcheke pou sekirite memwa paske nou te aplike Nenpòt pou tout kalite;pa gen lòt impls ka egziste menm jan yo ta konfli ak impl nou an.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Anvwa nan metòd la defini sou kalite `Any` la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Anvwa nan metòd la defini sou kalite `Any` la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Anvwa nan metòd la defini sou kalite `Any` la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Anvwa nan metòd la defini sou kalite `Any` la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Anvwa nan metòd la defini sou kalite `Any` la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Anvwa nan metòd la defini sou kalite `Any` la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ak metòd li yo
///////////////////////////////////////////////////////////////////////////////

/// Yon `TypeId` reprezante yon idantifyan globalman inik pou yon kalite.
///
/// Chak `TypeId` se yon objè opak ki pa pèmèt enspeksyon nan sa ki andedan men pèmèt operasyon debaz tankou klonaj, konparezon, enprime, ak montre.
///
///
/// Yon `TypeId` ki disponib sèlman kounye a pou kalite ki atribiye a `'static`, men limit sa a ka retire nan future la.
///
/// Pandan ke `TypeId` aplike `Hash`, `PartialOrd`, ak `Ord`, li vo anyen ke hash yo ak kòmann-nan ap varye ant Rust degaje.
/// Pran prekosyon nou ak repoze sou yo anndan kòd ou!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Retounen `TypeId` ki kalite fonksyon jenerik sa a te enstansye ak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Retounen non yon kalite kòm yon tranch fisèl.
///
/// # Note
///
/// Sa a fèt pou itilize dyagnostik.
/// Sa ki egzak ak fòma nan fisèl la retounen yo pa espesifye, lòt pase yo te yon deskripsyon pi bon efò nan kalite la.
/// Pou egzanp, pami strings yo ki `type_name::<Option<String>>()` ta ka retounen yo se `"Option<String>"` ak `"std::option::Option<std::string::String>"`.
///
///
/// Fisèl la retounen pa dwe konsidere yo dwe yon idantifyan inik nan yon kalite kòm plizyè kalite ka kat jeyografik nan non an menm kalite.
/// Menm jan an tou, pa gen okenn garanti ke tout pati nan yon kalite ap parèt nan fisèl la retounen: pou egzanp, espesifik pou tout lavi yo kounye a pa enkli.
/// Anplis de sa, pwodiksyon an ka chanje ant vèsyon du a.
///
/// Aplikasyon aktyèl la itilize enfrastrikti menm jan ak dyagnostik du ak debuginfo, men sa pa garanti.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Retounen non ki kalite valè pwente-a kòm yon tranch fisèl.
/// Sa a se menm bagay la kòm `type_name::<T>()`, men yo ka itilize kote kalite a nan yon varyab se pa fasil ki disponib.
///
/// # Note
///
/// Sa a fèt pou itilize dyagnostik.Sa ki egzak ak fòma nan fisèl la yo pa espesifye, lòt pase yo te yon deskripsyon pi bon efò nan kalite la.
/// Pou egzanp, `type_name_of_val::<Option<String>>(None)` ta ka retounen `"Option<String>"` oswa `"std::option::Option<std::string::String>"`, men se pa `"foobar"`.
///
/// Anplis de sa, pwodiksyon an ka chanje ant vèsyon du a.
///
/// Fonksyon sa a pa rezoud trait objè, sa vle di ke `type_name_of_val(&7u32 as &dyn Debug)` ka retounen `"dyn Debug"`, men se pa `"u32"`.
///
/// Non tip la pa ta dwe konsidere kòm yon idantifikatè inik nan yon kalite;
/// plizyè kalite ka pataje menm kalite non an.
///
/// Aplikasyon aktyèl la itilize enfrastrikti menm jan ak dyagnostik du ak debuginfo, men sa pa garanti.
///
/// # Examples
///
/// Enprime nonb antye relatif la ak kalite flote.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}