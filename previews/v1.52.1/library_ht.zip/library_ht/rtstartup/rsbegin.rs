// rsbegin.o ak rsend.o yo se sa yo rele "compiler runtime startup objects".
// Yo genyen kòd ki nesesè pou kòrèkteman inisyalize ègzekutabl la du.
//
// Lè se yon ègzèkutabl oswa imaj dylib lye, tout kòd itilizatè ak bibliyotèk yo "sandwiched" ant de dosye sa yo objè, se konsa kòd oswa done ki soti nan rsbegin.o vin premye nan seksyon yo respektif nan imaj la, Lè nou konsidere ke kòd ak done ki soti nan rsend.o vin dènye yo.
// Sa a ka itilize efè yo mete senbòl nan kòmansman an oswa nan fen yon seksyon, osi byen ke insert nenpòt Tèt obligatwa oswa pye.
//
// Remake byen ke pwen aktyèl la antre modil sitiye nan objè a demaraj C runtime (anjeneral yo rele `crtX.o`), ki Lè sa a, envoke rapèl inisyalizasyon nan lòt konpozan ègzekutabl (ki anrejistre atravè ankò yon lòt seksyon imaj espesyal).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Mak kòmansman ankadreman chemine a detant seksyon enfòmasyon an
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Grate espas pou entèn liv-kenbe deroulan an.
    // Sa a defini kòm `struct object` nan $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Debouche enfòmasyon woutin registration/deregistration.
    // Gade dokiman libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // enskri detant enfòmasyon sou demaraj modil
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // anrejistre sou are
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-espesifik enskripsyon woutin init/uninit
    pub mod mingw_init {
        // Objè demaraj MinGW a (crt0.o/dllcrt0.o) pral envoke konstriktè mondyal nan seksyon .ctors ak .dtors sou demaraj ak sòti.
        // Nan ka DLL yo, sa fèt lè DLL la chaje ak dechaje.
        //
        // Linker a pral sòt seksyon yo, ki asire ke rapèl nou yo sitiye nan fen lis la.
        // Depi constructors yo kouri nan lòd ranvèse, sa a asire ke rapèl nou yo se yo menm ki premye ak dènye egzekite.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C inisyalizasyon rapèl
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: rapèl C revokasyon
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}