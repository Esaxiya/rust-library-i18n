# `rustc-std-workspace-core` crate la

crate sa a se yon crate shim ak vid ki tou senpleman depann sou `libcore` ak reexports tout sa li yo.
crate a se pwen enpòtan nan abilite bibliyotèk la estanda depann sou crates soti nan crates.io

Crates sou crates.io ke bibliyotèk la estanda depann sou bezwen depann sou `rustc-std-workspace-core` crate a soti nan crates.io, ki se vid.

Nou itilize `[patch]` pase sou desizyon sa a crate nan repozitwa sa a.
Kòm yon rezilta, crates sou crates.io pral trase yon depandans edge `libcore`, vèsyon ki defini nan depo sa a.
Ki ta dwe trase tout bor yo depandans asire Cargo bati crates avèk siksè!

Remake byen ke crates sou crates.io bezwen depann sou sa a crate ak non `core` la pou tout bagay yo travay kòrèkteman.Pou fè sa yo ka itilize:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Atravè itilizasyon kle `package` la, crate chanje non li nan `core`, sa vle di li pral sanble

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

lè Cargo envoke du a, satisfè direktiv la enplisit `extern crate core` enjekte pa du a.




