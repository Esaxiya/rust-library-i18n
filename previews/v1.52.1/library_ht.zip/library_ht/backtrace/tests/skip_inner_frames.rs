use backtrace::Backtrace;

// Tès sa a sèlman ap travay sou tribin ki gen yon fonksyon k ap travay `symbol_address` pou ankadreman ki rapòte adrès la kòmanse nan yon senbòl.
// Kòm yon rezilta li a sèlman pèmèt sou yon tribin kèk.
//
const ENABLED: bool = cfg!(all(
    // Windows pa te reyèlman teste, ak OSX pa sipòte aktyèlman jwenn yon ankadreman jwen, kidonk enfim sa a
    //
    target_os = "linux",
    // Sou ARM jwenn fonksyon an jwen se senpleman retounen ip nan tèt li.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}