# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Yon bibliyotèk pou trape backtraces nan ègzekutabl pou Rust.
Bibliyotèk sa a gen pou objaktif pou amelyore sipò bibliyotèk estanda a lè li bay yon koòdone pwogramatik pou travay avèk li, men li sipòte tou senpleman fasilman enprime backtrace aktyèl la tankou panics libstd a.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Senpleman pran yon backtrace ak ranvwaye fè fas ak li jiskaske yon tan pita, ou ka itilize kalite a `Backtrace` tèt-nivo.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Si, sepandan, ou ta renmen plis aksè anvan tout koreksyon nan fonksyonalite aktyèl la trase, ou ka itilize fonksyon yo `trace` ak `resolve` dirèkteman.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Rezoud konsèy enstriksyon sa a nan yon non senbòl
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // kontinye ale nan ankadreman kap vini an
    });
}
```

# License

Pwojè sa a gen lisans anba youn nan

 * Lisans Apache, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) oswa http://www.apache.org/licenses/LICENSE-2.0)
 * Lisans MIT ([LICENSE-MIT](LICENSE-MIT) oswa http://opensource.org/licenses/MIT)

nan opsyon ou.

### Contribution

Sòf si ou klèman deklare otreman, nenpòt kontribisyon entansyonèlman soumèt pou enklizyon nan backtrace-rs pa ou, jan sa defini nan lisans lan Apache-2.0, yo dwe doub lisansye kòm pi wo a, san yo pa nenpòt ki kondisyon adisyonèl.







