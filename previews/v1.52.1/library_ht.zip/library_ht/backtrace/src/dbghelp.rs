//! Yon modil ede nan jere mare dbghelp sou Windows
//!
//! Backtraces sou Windows (omwen pou MSVC) yo lajman mache nan `dbghelp.dll` ak fonksyon yo divès kalite ke li genyen ladan li.
//! Fonksyon sa yo kounye a chaje *dynamique* olye ke konekte ak `dbghelp.dll` statikman.
//! Sa a se kounye a fè pa bibliyotèk la estanda (e se nan teyori obligatwa gen), men se yon efò ede diminye depandans yo dll estatik nan yon bibliyotèk depi backtraces yo tipikman trè si ou vle.
//!
//! Sa yo te di, `dbghelp.dll` prèske toujou avèk siksè chaje sou Windows.
//!
//! Remake byen ke depi nou ap chaje tout sipò sa a dynamique nou pa ka aktyèlman sèvi ak definisyon yo anvan tout koreksyon nan `winapi`, men pito nou bezwen defini kalite yo konsèy konsèy tèt nou epi sèvi ak sa.
//! Nou pa vle reyèlman yo dwe nan biznis la nan kopi winapi, se konsa nou gen yon karakteristik Cargo `verify-winapi` ki afime ke tout mare matche ak sa yo ki nan winapi ak karakteristik sa a pèmèt sou CI.
//!
//! Finalman, ou pral sonje isit la ke dll la pou `dbghelp.dll` pa janm dechaje, e ke sa a kounye a entansyonèl.
//! Panse a se ke nou ka globalman kachèt li epi sèvi ak li ant apèl nan API a, evite chè loads/unloads.
//! Si sa a se yon pwoblèm pou detektè koule oswa yon bagay tankou sa nou ka travèse pon an lè nou rive la.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Travay alantou `SymGetOptions` ak `SymSetOptions` pa te prezan nan winapi tèt li.
// Sinon sa a se sèlman itilize lè nou ap doub-tcheke kalite kont winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Pa defini nan winapi ankò
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Sa defini nan winapi, men li pa kòrèk (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Pa defini nan winapi ankò
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Sa a se macro itilize yo defini yon estrikti `Dbghelp` ki intern gen tout endikasyon yo fonksyon ke nou ta ka chaje.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL la chaje pou `dbghelp.dll`
            dll: HMODULE,

            // Chak konsèy fonksyon pou chak fonksyon nou ta ka itilize
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Okòmansman nou pa chaje DLL la
            dll: 0 as *mut _,
            // Initiall tout fonksyon yo mete a zewo yo di yo bezwen yo dwe dinamik chaje.
            //
            $($name: 0,)*
        };

        // Konvenans tip pou chak kalite fonksyon.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Tantativ pou louvri `dbghelp.dll`.
            /// Retounen siksè si li travay oswa erè si `LoadLibraryW` echwe.
            ///
            /// Panics si bibliyotèk la deja chaje.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Fonksyon pou chak metòd nou ta renmen itilize.
            // Lè yo rele li pral swa li konsèy la fonksyon kach oswa chaje li epi retounen valè a chaje.
            // Chaj yo revandike pou yo reyisi.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Prokurite konvenyans yo sèvi ak kadna yo netwayaj referans fonksyon dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inisyalize tout sipò ki nesesè pou jwenn aksè nan fonksyon API `dbghelp` sa a soti nan crate.
///
///
/// Remake byen ke fonksyon sa a se **san danje**, li intern gen senkronizasyon pwòp li yo.
/// Epitou sonje ke li an sekirite yo rele fonksyon sa a plizyè fwa rekursivman.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Premye bagay nou bezwen fè se senkroniz fonksyon sa a.Sa a ka rele an menm tan soti nan lòt fil oswa recursiv nan yon sèl fil.
        // Remake byen ke li pi difisil pase sa menm si sa nou itilize la a, `dbghelp`,*tou* bezwen senkronize ak tout lòt moun kap rele `dbghelp` nan pwosesis sa a.
        //
        // Tipikman pa gen reyèlman ke anpil apèl nan `dbghelp` nan menm pwosesis la epi nou ka pwobableman san danje asime ke nou se yo menm sèlman aksè li.
        // Gen, sepandan, yon sèl itilizatè prensipal lòt nou gen enkyete sou ki se iwonilman tèt nou, men nan bibliyotèk la estanda.
        // Bibliyotèk estanda Rust la depann de crate sa a pou sipò backtrace, ak crate sa a egziste tou sou crates.io.
        // Sa vle di ke si bibliyotèk la estanda enprime yon backtrace panic li ka ras ak sa a crate vini soti nan crates.io, sa ki lakòz segfaults.
        //
        // Pou ede rezoud pwoblèm sa a senkronizasyon nou anplwaye yon Trick Windows-espesifik isit la (li se, apre tout, yon restriksyon Windows-espesifik sou senkronizasyon).
        // Nou kreye yon *sesyon-lokal* yo te rele mutex pou pwoteje apèl sa a.
        // Entansyon an isit la se ke bibliyotèk la estanda ak crate sa a pa gen yo pataje Rust-nivo APIs senkroniz isit la, men ka olye travay dèyè sèn nan asire w ke yo ap senkronize youn ak lòt.
        //
        // Nan fason sa a lè yo rele fonksyon sa a nan bibliyotèk la estanda oswa nan crates.io nou ka asire w ke se menm mutex la ke yo te akeri.
        //
        // Se konsa, tout sa ki vle di ke premye bagay nou fè isit la se nou atomikman kreye yon `HANDLE` ki se yon mutex yo te rele sou Windows.
        // Nou senkronize yon ti jan ak lòt fil pataje fonksyon sa a espesyalman epi asire ke se sèlman yon sèl manch kreye pou chak egzanp nan fonksyon sa a.
        // Remake byen ke manch lan pa janm fèmen yon fwa li estoke nan mondyal la.
        //
        // Apre nou te aktyèlman ale fèmen nan nou tou senpleman jwenn li, ak manch `Init` nou nou soti men yo pral responsab pou jete li evantyèlman.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Kounye a ke nou tout senkronize san danje, kite a aktyèlman kòmanse trete tout bagay.
        // Premye moute nou bezwen asire ke `dbghelp.dll` aktyèlman chaje nan pwosesis sa a.
        // Nou fè sa dinamik pou evite yon depandans estatik.
        // Sa a te istorikman te fè nan travay alantou pwoblèm etranj ki lye ak se gen entansyon fè binè yon ti jan pi pòtab depi sa a se lajman jis yon sèvis piblik debogaj.
        //
        //
        // Yon fwa nou te louvri `dbghelp.dll` nou bezwen rele kèk fonksyon inisyalizasyon nan li, e ke sa a detaye plis anba a.
        // Nou sèlman fè sa yon fwa, menm si, se konsa nou te gen yon boolean mondyal ki endike si nou fini ankò oswa ou pa.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Asire ke drapo `SYMOPT_DEFERRED_LOADS` la tabli, paske selon pwòp dokiman MSVC sou sa: "This is the fastest, most efficient way to use the symbol handler.", donk ann fè sa!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Aktyèlman inisyalize senbòl ak MSVC.Remake byen ke sa a ka febli, men nou inyore li.
        // Pa gen yon tòn atizay anvan pou sa a poukont li, men LLVM intern sanble inyore valè retounen isit la ak youn nan bibliyotèk dezenfektan nan LLVM enprime yon avètisman pè si sa echwe men fondamantalman inyore li nan kouri nan longè.
        //
        //
        // Yon ka sa a vini anpil pou Rust se ke bibliyotèk la estanda ak sa a crate sou crates.io tou de vle fè konpetisyon pou `SymInitializeW`.
        // Bibliyotèk la estanda istorikman te vle inisyalize Lè sa a, netwayaj pi fò nan tan an, men kounye a ke li nan lè l sèvi avèk sa a crate sa vle di ke yon moun pral jwenn inisyalizasyon premye ak lòt la pral ranmase inisyalizasyon sa a.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}