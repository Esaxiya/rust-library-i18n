use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Reprezantasyon nan yon backtrace posede ak endepandan.
///
/// Ka estrikti sa a dwe itilize yo pran yon backtrace nan divès pwen nan yon pwogram epi pita itilize yo enspekte ki sa backtrace a te nan tan sa a.
///
///
/// `Backtrace` sipòte bèl-enprime nan backtraces nan aplikasyon `Debug` li yo.
///
/// # Karakteristik obligatwa
///
/// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Ankadreman isit la yo ki nan lis soti nan tèt-a-anba nan chemine a
    frames: Vec<BacktraceFrame>,
    // Endèks la nou kwè se kòmansman aktyèl la nan backtrace a, omisyon ankadreman tankou `Backtrace::new` ak `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Kaptire vèsyon nan yon ankadreman nan yon backtrace.
///
/// Sa a se kalite retounen kòm yon lis ki soti nan `Backtrace::frames` ak reprezante yon sèl ankadreman chemine nan yon backtrace kaptire.
///
/// # Karakteristik obligatwa
///
/// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Kaptire vèsyon an yon senbòl nan yon backtrace.
///
/// Sa a se kalite retounen kòm yon lis ki soti nan `BacktraceFrame::symbols` ak reprezante metadata yo pou yon senbòl nan yon backtrace.
///
/// # Karakteristik obligatwa
///
/// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Kaptire yon backtrace nan callsite nan fonksyon sa a, retounen yon reprezantasyon posede.
    ///
    /// Fonksyon sa a itil pou reprezante yon backtrace kòm yon objè nan Rust.Valè sa a retounen ka voye atravè fil ak enprime yon lòt kote, ak bi pou yo valè sa a se yo dwe antyèman endepandan.
    ///
    /// Remake byen ke sou kèk tribin trape yon backtrace plen ak rezoud li ka trè chè.
    /// Si pri a twòp pou aplikasyon w lan li rekòmande olye pou yo itilize `Backtrace::new_unresolved()` ki evite etap la rezolisyon senbòl (ki tipikman pran pi long lan) ak pèmèt ranvwaye sa nan yon dat apre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // vle asire ke gen yon ankadreman isit la yo retire
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Menm jan ak `new` eksepte ke sa a pa rezoud nenpòt senbòl, sa a tou senpleman kaptire backtrace a kòm yon lis adrès.
    ///
    /// Nan yon moman pita yo ka rele fonksyon `resolve` pou rezoud senbòl backtrace sa a nan non lizib.
    /// Fonksyon sa a egziste paske pwosesis rezolisyon an ka pafwa pran yon kantite siyifikatif nan tan tandiske nenpòt ki backtrace yon sèl ka sèlman enprime raman.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // pa gen non senbòl
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // non senbòl kounye a prezan
    /// ```
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    ///
    ///
    #[inline(never)] // vle asire ke gen yon ankadreman isit la yo retire
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Retounen ankadreman yo depi lè yo te kaptire backtrace sa a.
    ///
    /// Premye antre nan tranch sa a gen anpil chans fonksyon `Backtrace::new`, ak dènye ankadreman an gen anpil chans yon bagay sou kouman fil sa a oswa fonksyon prensipal la te kòmanse.
    ///
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Si backtrace sa a te kreye soti nan `new_unresolved` Lè sa a, fonksyon sa a pral rezoud tout adrès nan backtrace a non senbolik yo.
    ///
    ///
    /// Si backtrace sa a te deja rezoud oswa te kreye nan `new`, fonksyon sa a pa fè anyen.
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Menm jan ak `Frame::ip`
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Menm jan ak `Frame::symbol_address`
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Menm jan ak `Frame::module_base_address`
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Retounen lis la nan senbòl ki ankadreman sa a koresponn ak.
    ///
    /// Nòmalman gen yon sèl senbòl pou chak ankadreman, men pafwa si yon kantite fonksyon yo aliyen nan yon sèl ankadreman Lè sa a, senbòl miltip yo pral retounen.
    /// Premye senbòl ki nan lis la se "innermost function", tandiske senbòl ki sot pase a se eksteryè a (dènye moun kap rele).
    ///
    /// Remake byen ke si ankadreman sa a te soti nan yon backtrace ki pako rezoud Lè sa a, sa a pral retounen yon lis vid.
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Menm jan ak `Symbol::name`
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Menm jan ak `Symbol::addr`
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Menm jan ak `Symbol::filename`
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Menm jan ak `Symbol::lineno`
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Menm jan ak `Symbol::colno`
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Lè enprime chemen nou eseye dezabiye cwd a si li egziste, otreman nou jis enprime chemen an kòm-se.
        // Remake byen ke nou menm tou nou fè sa pou fòma a kout, paske si li nan plen nou prezimableman vle enprime tout bagay.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}