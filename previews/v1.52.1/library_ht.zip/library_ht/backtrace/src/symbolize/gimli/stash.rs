// sèlman itilize sou Linux kounye a, se konsa pèmèt kòd mouri yon lòt kote
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Yon alokatè tèren senp pou tanpon byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Asigne yon tanpon nan gwosè a espesifye epi retounen yon referans mutable nan li.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SEKIRITE: sa a se fonksyon an sèlman ki janm konstwi yon mutable
        // referans a `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SEKIRITE: nou pa janm retire eleman nan `self.buffers`, kidonk yon referans
        // done yo andedan nenpòt pezib ap viv osi lontan ke `self` fè.
        &mut buffers[i]
    }
}