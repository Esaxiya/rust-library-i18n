use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Rezoud yon adrès nan yon senbòl, pase senbòl la nan fèmti a espesifye.
///
/// Fonksyon sa a pral gade moute adrès yo bay la nan zòn tankou tab la senbòl lokal yo, tab senbòl dinamik, oswa enfòmasyon debug DWARF (ki depann sou aplikasyon an aktive) jwenn senbòl sede.
///
///
/// Fèmti a pa ka rele si rezolisyon pa ta ka fèt, epi li ka rele tou plis pase yon fwa nan ka fonksyon aliyen yo.
///
/// Senbòl sede reprezante ekzekisyon an nan `addr` la espesifye, retounen file/line pè pou adrès sa a (si disponib).
///
/// Remake byen ke si ou gen yon `Frame` Lè sa a, li rekòmande yo sèvi ak fonksyon an `resolve_frame` olye pou yo yon sèl sa a.
///
/// # Karakteristik obligatwa
///
/// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
///
/// # Panics
///
/// Fonksyon sa a fè efò pa janm panic, men si `cb` la bay panics Lè sa a, kèk tribin pral fòse yon panic doub avòtman pwosesis la.
/// Gen kèk tribin ki itilize yon bibliyotèk C ki intern itilize rapèl ki pa ka deroule nan, se konsa panik soti nan `cb` ka deklanche yon pwosesis avòtman.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // sèlman gade nan ankadreman an tèt
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Rezoud yon ankadreman kaptire deja nan yon senbòl, pase senbòl la nan fèmti a espesifye.
///
/// Fonksyon sa a fè menm fonksyon ak `resolve` eksepte ke li pran yon `Frame` kòm yon agiman olye de yon adrès.
/// Sa a ka pèmèt kèk aplikasyon platfòm nan backtracing bay enfòmasyon senbòl pi egzak oswa enfòmasyon sou ankadreman aliye pou egzanp.
///
/// Li rekòmande pou itilize sa a si ou kapab.
///
/// # Karakteristik obligatwa
///
/// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
///
/// # Panics
///
/// Fonksyon sa a fè efò pa janm panic, men si `cb` la bay panics Lè sa a, kèk tribin pral fòse yon panic doub avòtman pwosesis la.
/// Gen kèk tribin ki itilize yon bibliyotèk C ki intern itilize rapèl ki pa ka deroule nan, se konsa panik soti nan `cb` ka deklanche yon pwosesis avòtman.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // sèlman gade nan ankadreman an tèt
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Valè IP soti nan ankadreman chemine yo tipikman (always?) enstriksyon an *apre* apèl la ki nan tras chemine aktyèl la.
// Senbolize sa a sou nimewo filename/line la yo dwe youn devan e petèt nan anile a si li nan tou pre nan fen fonksyon an.
//
// Sa a parèt fondamantalman toujou ka a sou tout tribin, se konsa nou toujou soustraksyon youn nan yon ip rezoud rezoud li nan enstriksyon an apèl anvan olye pou yo enstriksyon an te retounen nan.
//
//
// Idealman nou pa ta fè sa.
// Idealman nou ta mande pou moun kap rele APIs `resolve` yo isit la pou fè manyèlman -1 la ak kont yo ke yo vle enfòmasyon kote pou enstriksyon an *anvan*, pa aktyèl la.
// Idealman nou ta ekspoze tou sou `Frame` si nou tout bon adrès enstriksyon kap vini an oswa aktyèl la.
//
// Pou kounye a menm si sa a se yon enkyetid bèl Tanporèman nich pou nou jis intern toujou soustraksyon yon sèl.
// Konsomatè yo ta dwe kontinye travay ak ap resevwa rezilta trè bon, kidonk nou ta dwe bon ase.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Menm jan ak `resolve`, sèlman danjere ke li nan senkronize.
///
/// Fonksyon sa a pa gen garanti senkronizasyon men ki disponib lè karakteristik nan `std` nan sa a crate pa konpile nan.
/// Gade fonksyon `resolve` la pou plis dokiman ak egzanp.
///
/// # Panics
///
/// Gade enfòmasyon sou `resolve` pou opozisyon sou panik `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Menm jan ak `resolve_frame`, sèlman danjere ke li nan senkronize.
///
/// Fonksyon sa a pa gen garanti senkronizasyon men ki disponib lè karakteristik nan `std` nan sa a crate pa konpile nan.
/// Gade fonksyon `resolve_frame` la pou plis dokiman ak egzanp.
///
/// # Panics
///
/// Gade enfòmasyon sou `resolve_frame` pou opozisyon sou panik `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Yon trait ki reprezante rezolisyon yon senbòl nan yon dosye.
///
/// Sa a trait sede kòm yon objè trait fèmti a bay fonksyon an `backtrace::resolve`, epi li se nòmalman voye kòm li nan enkoni ki aplikasyon ki dèyè li.
///
///
/// Yon senbòl ka bay enfòmasyon kontèks sou yon fonksyon, pou egzanp non, non dosye, nimewo liy, adrès egzak, elatriye.
/// Se pa tout enfòmasyon ki toujou disponib nan yon senbòl, sepandan, se konsa tout metòd retounen yon `Option`.
///
///
pub struct Symbol {
    // TODO: lavi sa a mare yo dwe pèsiste evantyèlman `Symbol`,
    // men sa a kounye a yon chanjman kraze.
    // Pou kounye a sa a san danje depi `Symbol` se sèlman janm remèt pa referans epi yo pa ka klone.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Retounen non fonksyon sa a.
    ///
    /// Ka estrikti a retounen dwe itilize nan rechèch divès kalite pwopriyete sou non an senbòl:
    ///
    ///
    /// * Aplikasyon `Display` la ap enprime senbòl demangle a.
    /// * Ou ka jwenn valè `str` anvan tout koreksyon senbòl la (si li valab utf-8).
    /// * Bytes kri pou non senbòl la ka jwenn aksè.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Retounen adrès la kòmanse nan fonksyon sa a.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Retounen non an anvan tout koreksyon kòm yon tranch.
    /// Sa a se sitou itil pou anviwònman `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Retounen nimewo kolòn nan pou kote senbòl sa a egzekite kounye a.
    ///
    /// Se sèlman gimli kounye a bay yon valè isit la e menm lè sa a sèlman si `filename` retounen `Some`, e konsa li Lè sa a, kidonk sijè a opozisyon menm jan an.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Retounen nimewo liy lan pou kote senbòl sa a egzekite kounye a.
    ///
    /// Valè retou sa a se tipikman `Some` si `filename` retounen `Some`, epi kidonk sijè a opozisyon menm jan an.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Retounen non dosye kote fonksyon sa a te defini.
    ///
    /// Sa a se kounye a sèlman ki disponib lè libbacktrace oswa gimli yo te itilize (egzanp
    /// unix tribin lòt) ak lè se yon binè konpile ak debuginfo.
    /// Si okenn nan kondisyon sa yo pa satisfè, sa ap gen chans pou retounen `None`.
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Petèt yon senbòl C++ analize, si analize senbòl la mangled kòm Rust echwe.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Asire w ke ou kenbe sa a zewo-gwosè, se konsa ke karakteristik nan `cpp_demangle` pa gen okenn pri lè enfim.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Yon pakè alantou yon non senbòl pou bay aksè ergonomik nan non demangle a, bytes yo anvan tout koreksyon, fisèl la anvan tout koreksyon, elatriye.
///
// Pèmèt kòd mouri pou lè karakteristik `cpp_demangle` la pa pèmèt.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Kreye yon non senbòl nouvo soti nan bytes yo kache kache.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Retounen non senbòl kri (mangled) kòm yon `str` si senbòl la valab utf-8.
    ///
    /// Sèvi ak aplikasyon an `Display` si ou vle vèsyon an demangle.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Retounen non senbòl la anvan tout koreksyon kòm yon lis bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Sa a ka ekri ak lèt detache si senbòl la demangle se pa aktyèlman valab, se konsa okipe erè a isit la grasyeu pa pa pwopaje li deyò.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Eseye reklame ke memwa kach itilize pou senbolize adrès yo.
///
/// Metòd sa a ap eseye lage nenpòt estrikti done mondyal ki te otreman te kache globalman oswa nan fil la ki tipikman reprezante analize enfòmasyon DWARF oswa menm jan an.
///
///
/// # Caveats
///
/// Pandan ke fonksyon sa a toujou disponib li pa aktyèlman fè anyen sou pifò aplikasyon yo.
/// Bibliyotèk tankou dbghelp oswa libbacktrace pa bay fasilite yo pou yo repati eta a epi jere memwa ki afekte a.
/// Pou kounye a karakteristik `gimli-symbolize` nan crate sa a se sèl karakteristik kote fonksyon sa a gen okenn efè.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}