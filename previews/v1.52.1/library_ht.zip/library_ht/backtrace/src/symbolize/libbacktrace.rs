//! Senbolizasyon estrateji lè l sèvi avèk kòd la DWARF-analize nan libbacktrace.
//!
//! Libbacktrace C bibliyotèk la, tipikman distribiye ak gcc, sipòte pa sèlman génération yon backtrace (ki nou pa aktyèlman itilize), men tou senbolize backtrace la ak manyen enfòmasyon debug tinen sou bagay sa yo tankou ankadreman aliyen ak kèlkeswa sa.
//!
//!
//! Sa a se relativman konplike akòz anpil enkyetid divès kalite isit la, men lide debaz la se:
//!
//! * Premye nou rele `backtrace_syminfo`.Sa a vin enfòmasyon senbòl nan tablo a senbòl dinamik si nou kapab.
//! * Next nou rele `backtrace_pcinfo`.Sa a pral analize tab debuginfo si yo disponib epi pèmèt nou refè enfòmasyon sou ankadreman aliye, non dosye, nimewo liy, elatriye.
//!
//! Genyen anpil nan riz sou ap resevwa tab yo tinen nan libbacktrace, men èspere ke li pa nan fen mond lan epi li klè ase lè w ap li anba a.
//!
//! Sa a se estrateji senbolizasyon default pou platfòm ki pa MSVC ak ki pa OSX.Nan libstd menm si sa a se estrateji an default pou OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Si sa posib pito non `function` ki soti nan debuginfo epi ki ka tipikman pi egzak pou ankadreman aliye pou egzanp.
                // Si sa a pa prezan menm si tonbe tounen nan non an tab senbòl espesifye nan `symname`.
                //
                // Remake byen ke pafwa `function` ka santi yon ti jan mwens egzat, pou egzanp ke yo te ki nan lis kòm `try<i32,closure>` isntead nan `std::panicking::try::do_call`.
                //
                // Li pa reyèlman klè poukisa, men an jeneral non `function` la sanble pi egzat.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // pa fè anyen pou kounye a
}

/// Kalite konsèy `data` la pase nan `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Yon fwa ke rapèl sa a envoke soti nan `backtrace_syminfo` lè nou kòmanse rezoud nou ale pi lwen yo rele `backtrace_pcinfo`.
    // Fonksyon `backtrace_pcinfo` la ap konsilte enfòmasyon debug ak atemp tto fè bagay sa yo tankou refè enfòmasyon file/line kòm byen ke ankadreman aliyen.
    // Remake byen ke `backtrace_pcinfo` ka febli oswa ou pa fè anpil si pa gen enfòmasyon debug, kidonk si sa rive nou asire w ke ou rele rapèl la ak omwen yon senbòl soti nan `syminfo_cb` la.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Kalite konsèy `data` la pase nan `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace sipòte kreye yon eta, men li pa sipòte detwi yon eta.
// Mwen pèsonèlman pran sa a vle di ke yon eta vle di ke yo dwe kreye ak Lè sa a, ap viv pou tout tan.
//
// Mwen ta renmen enskri yon moun kap okipe at_exit() ki netwaye eta sa a, men libbacktrace pa bay okenn fason pou fè sa.
//
// Avèk kontrent sa yo, fonksyon sa a gen yon eta statik kach ki kalkile premye fwa yo mande sa a.
//
// Sonje ke backtracing tout k ap pase seri (yon sèl fèmen mondyal).
//
// Remake mank de senkronizasyon isit la se akòz kondisyon ki `resolve` se deyò senkronize.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Pa fè egzèsis kapasite threadsafe nan libbacktrace depi nou ap toujou rele l 'nan yon mòd senkronize.
        //
        0,
        error_cb,
        ptr::null_mut(), // pa gen done siplemantè
    );

    return STATE;

    // Remake byen ke pou libbacktrace yo opere nan tout li bezwen jwenn enfòmasyon yo debar DWARF pou ègzèkutabl aktyèl la.Li tipikman fè sa atravè yon kantite mekanis ki gen ladan, men pa limite a:
    //
    // * /proc/self/exe sou tribin sipòte
    // * Non dosye a te pase nan klèman lè kreye eta
    //
    // Bibliyotèk la libbacktrace se yon gwo wad nan C kòd.Sa natirèlman vle di li te gen frajilite sekirite memwa, espesyalman lè manyen debuginfo malformed.
    // Libstd te kouri antre nan anpil nan sa yo istorikman.
    //
    // Si /proc/self/exe yo itilize Lè sa a, nou ka tipikman inyore sa yo kòm nou asime ke libbacktrace se "mostly correct" ak otreman pa fè bagay sa yo etranj ak "attempted to be correct" enfòmasyon debug tinen.
    //
    //
    // Si nou pase nan yon non dosye, sepandan, Lè sa a, li posib sou kèk tribin (tankou BSDs) kote yon aktè move ka lakòz yon dosye abitrè yo dwe mete nan ki kote.
    // Sa vle di ke si nou di libbacktrace sou yon non dosye li ka lè l sèvi avèk yon dosye abitrè, petèt sa ki lakòz segfaults.
    // Si nou pa di libbacktrace anyen menm si li pa pral fè anyen sou tribin ki pa sipòte chemen tankou /proc/self/exe!
    //
    // Etandone tout sa nou eseye osi difisil ke posib *pa* pase nan yon non dosye, men nou dwe sou tribin ki pa sipòte /proc/self/exe ditou.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Remake byen ke depreferans nou ta itilize `std::env::current_exe`, men nou pa ka mande pou `std` isit la.
            //
            // Sèvi ak `_NSGetExecutablePath` pou chaje chemen ègzèkutabl aktyèl la nan yon zòn estatik (ki si li twò piti jis bay moute).
            //
            //
            // Remake byen ke nou ap seryezman konfyans libbacktrace isit la pa mouri sou ègzèkutabl koripsyon, men li siman fè ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows gen yon mòd nan louvri dosye kote apre li nan louvri li pa ka efase.
            // Sa a an jeneral sa nou vle isit la paske nou vle asire ke ègzèkutabl nou an pa chanje soti anba nou apre nou remèt li libbacktrace, èspere ke diminye kapasite pou pase nan done abitrè nan libbacktrace (ki ka mal trete).
            //
            //
            // Etandone ke nou fè yon ti jan nan yon dans isit la eseye jwenn yon sòt de fèmen sou imaj pwòp nou yo:
            //
            // * Jwenn yon manch nan pwosesis aktyèl la, chaje non dosye li yo.
            // * Louvri yon dosye nan non sa a ak drapo yo dwa.
            // * Reload non dosye pwosesis aktyèl la, asire w ke li nan menm bagay la
            //
            // Si ke tout pase nou nan teyori gen tout bon louvri dosye pwosesis nou an ak nou ap garanti li pa pral chanje.FWIW se yon pakèt moun sa a kopye nan libstd istorikman, se konsa sa a se pi bon entèpretasyon mwen nan sa ki te pase.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Sa a ap viv nan memwa estatik pou nou ka retounen li ..
                static mut BUF: [i8; N] = [0; N];
                // ... ak sa a ap viv sou chemine a depi li tanporè
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // entansyonèlman koule `handle` isit la paske gen ki louvri yo ta dwe prezève fèmen nou an sou non sa a dosye.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Nou vle retounen yon tranch ki se nul-sispann, Se konsa, si tout bagay te ranpli nan epi li egal a longè total Lè sa a, egal ki echèk.
                //
                //
                // Sinon lè retounen siksè asire w ke octet nul la enkli nan tranch la.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // erè backtrace yo kounye a baleye anba tapi an
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Rele `backtrace_syminfo` API ki (soti nan lekti kòd la) ta dwe rele `syminfo_cb` egzakteman yon fwa (oswa febli ak yon erè prezimableman).
    // Lè sa a, nou okipe plis nan `syminfo_cb` la.
    //
    // Remake byen ke nou fè sa depi `syminfo` ap konsilte tab la senbòl, jwenn non senbòl menm si pa gen okenn enfòmasyon debug nan binè a.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}