use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr pran yon rapèl ki pral resevwa yon konsèy dl_phdr_info pou chak DSO ki te lye nan pwosesis la.
    // dl_iterate_phdr tou asire ke se lyen dinamik la fèmen nan kòmansman fini nan iterasyon an.
    // Si rapèl la retounen yon valè ki pa zewo se iterasyon an sispann byen bonè.
    // 'data' yo pral pase kòm agiman an twazyèm nan rapèl la sou chak apèl.
    // 'size' bay gwosè a nan dl_phdr_info la.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Nou bezwen analize soti ID a bati ak kèk done header pwogram debaz ki vle di ke nou bezwen yon ti jan nan bagay ki soti nan spesifikasyon la ELF tou.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Koulye a, nou gen replike, ti jan pou ti jan, estrikti a nan kalite a dl_phdr_info itilize pa aktyèl Fuchsia a linker dinamik.
// Kwòm tou gen fwontyè ABI sa a kòm byen ke crashpad.
// Evantyèlman nou ta renmen pou avanse pou pi ka sa yo yo sèvi ak farfade-rechèch, men nou ta bezwen bay ki nan sdk a ak ki pa gen ankò yo te fè.
//
// Se konsa, nou (ak yo) yo kole gen yo sèvi ak metòd sa a ki antrene yon kouple sere ak fuchsia libc la.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Nou pa gen okenn fason pou konnen nan tcheke si e_phoff ak e_phnum yo valab.
    // libc ta dwe asire sa a pou nou sepandan kidonk li an sekirite pou fòme yon tranch isit la.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr reprezante yon header pwogram ELF 64-bit nan endianness nan achitekti sib la.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr reprezante yon header pwogram ELF valab ak sa li yo.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Nou pa gen okenn fason pou tcheke si p_addr oswa p_memsz valab.
    // Libc Fuchsia a analize nòt yo an premye sepandan konsa pa vèti pou yo te isit la Tèt sa yo dwe valab.
    //
    // NoteIter pa mande pou done yo kache yo dwe valab men li mande pou limit yo yo dwe valab.
    // Nou mete konfyans ke libc te asire ke sa a se ka a pou nou isit la.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Kalite nòt la pou bati ID yo.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr reprezante yon header nòt ELF nan endianness nan sib la.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Remak reprezante yon nòt ELF (header + kontni).
// Se non an kite kòm yon tranch u8 paske li pa toujou nil sispann ak rust fè li fasil ase yo tcheke ke bytes yo matche ak kanmenm.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter pèmèt ou san danje repete sou yon segman nòt.
// Li fini le pli vit ke yon erè rive oswa pa gen okenn nòt plis.
// Si ou repete sou done envalid li pral fonksyone tankou si yo pa jwenn okenn nòt.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Li se yon invariant nan fonksyon ki konsèy la ak gwosè yo bay vle di yon seri valab nan bytes ki ka tout li.
    // Sa ki nan bytes sa yo kapab anyen, men seri a dwe valab pou sa an sekirite.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aliyen 'x' a 'to'-byte aliyman an konsideran 'to' se yon pouvwa nan 2.
// Sa a swiv yon modèl estanda nan C/C ++ ELF analize kòd kote (x + a, 1)&-to yo itilize.
// Rust pa kite ou negate usize Se konsa, mwen itilize
// 2's-konpleman konvèsyon rkree sa.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 konsome bytes num soti nan tranch la (si prezan) ak Anplis de sa asire ke tranch final la se correctly aliyen.
// Si yon swa kantite bytes yo mande a twò gwo oswa tranch la pa ka reamenaje apre sa akòz pa rete ase bytes ki egziste deja, Okenn retounen epi tranch lan pa modifye.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Fonksyon sa a pa gen okenn envariant reyèl moun kap rele a dwe defann lòt pase petèt ke 'bytes' ta dwe aliyen pou pèfòmans (ak sou kèk achitekti kòrèkte).
// Valè yo nan jaden yo Elf_Nhdr ta ka istwa san sans men fonksyon sa a asire pa gen okenn bagay sa yo.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Sa a san danje osi lontan ke gen ase espas epi nou jis konfime ke nan deklarasyon an si pi wo a kidonk sa a pa ta dwe an sekirite.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Remake byen ke sice_of: :<Elf_Nhdr>() se toujou 4-byte ki aliyen.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Tcheke si nou te rive nan fen an.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Nou transmute soti yon nhdr men nou ak anpil atansyon konsidere struct a ki kapab lakòz.
        // Nou pa mete konfyans namesz la oswa descsz epi nou pa pran okenn desizyon ki pa an sekirite ki baze sou kalite a.
        //
        // Se konsa, menm si nou jwenn soti fatra konplè nou ta dwe toujou an sekirite.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Endike ke yon segman ègzèkutabl.
const PERM_X: u32 = 0b00000001;
/// Endike ke yon segman ekri.
const PERM_W: u32 = 0b00000010;
/// Endike ke yon segman lizib.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Reprezante yon segman ELF nan ègzekutabl.
struct Segment {
    /// Bay ègzekutabl adrès la vityèl nan sa segman sa a.
    addr: usize,
    /// Bay gwosè memwa sa ki nan segman sa a.
    size: usize,
    /// Bay modil adrès la vityèl nan segman sa a ak dosye a ELF.
    mod_rel_addr: usize,
    /// Bay otorizasyon yo jwenn nan dosye ELF la.
    /// Otorizasyon sa yo pa nesesèman otorizasyon yo prezan nan ègzekutabl sepandan.
    flags: Perm,
}

/// Pèmèt yon sèl repete sou segman ki sòti nan yon DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Reprezante yon ELF DSO (dinamik Pataje objè).
/// Kalite sa a referans done ki estoke nan DSO aktyèl la olye ke fè kopi pwòp li yo.
struct Dso<'a> {
    /// Linker dinamik la toujou ban nou yon non, menm si non an vid.
    /// Nan ka ègzèkutabl prensipal la non sa a ap vid.
    /// Nan ka yon objè pataje li pral soname a (gade DT_SONAME).
    name: &'a str,
    /// Sou Fuchsia nòmalman tout binè gen idantifikasyon bati men sa a se pa yon requierment strik.
    /// Pa gen okenn fason matche ak enfòmasyon DSO ak yon dosye reyèl ELF apre sa si pa gen okenn build_id pou nou mande pou chak DSO gen youn isit la.
    ///
    /// DSO san yon build_id yo inyore.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Retounen yon iteratè sou segman nan DSO sa a.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Erè sa yo kode pwoblèm ki rive pandan y ap analize enfòmasyon sou chak DSO.
///
enum Error {
    /// NameError vle di ke yon erè ki te fèt pandan y ap konvèti yon fisèl style C nan yon fisèl rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError vle di ke nou pa t 'jwenn yon ID bati.
    /// Sa a te kapab swa paske DSO a pa te gen okenn ID bati oswa paske segman ki gen ID a bati te mal.
    ///
    BuildIDError,
}

/// Apèl swa 'dso' oswa 'error' pou chak DSO lye nan pwosesis la pa linker dinamik la.
///
///
/// # Arguments
///
/// * `visitor` - Yon DsoPrinter ki pral gen youn nan manje metòd yo rele foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr asire ke info.name ap lonje dwèt sou yon kote ki valab.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Fonksyon sa a enprime baliz senbolizè Fuchsia pou tout enfòmasyon ki nan yon DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}