use core::ffi::c_void;
use core::fmt;

/// Enspekte aktyèl apèl-chemine a, pase tout ankadreman aktif nan fèmti a bay kalkile yon tras chemine.
///
/// Fonksyon sa a se workhorse a nan bibliyotèk sa a nan kalkile tras yo chemine pou yon pwogram.Fèmti `cb` la bay ka yon `Frame` ki reprezante enfòmasyon sou ki ankadreman apèl sou chemine a.
/// Se fèmti a sede ankadreman nan yon mòd tèt-desann (pi resamman yo rele fonksyon an premye).
///
/// Retounen valè fèmti a se yon endikasyon si wi ou non backtrace a ta dwe kontinye.Yon valè retou `false` ap mete fen nan backtrace a epi retounen imedyatman.
///
/// Yon fwa ke yon `Frame` akeri ou pral gen anpil chans vle rele `backtrace::resolve` konvèti `ip` la (konsèy enstriksyon) oswa adrès senbòl nan yon `Symbol` nan ki non an ak/oswa non dosye/nimewo liy ka aprann.
///
///
/// Remake byen ke sa a se yon fonksyon relativman ba-nivo epi si ou ta renmen, pou egzanp, pran yon backtrace yo dwe enspekte pita, Lè sa a, kalite a `Backtrace` ka pi apwopriye.
///
/// # Karakteristik obligatwa
///
/// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
///
/// # Panics
///
/// Fonksyon sa a fè efò pa janm panic, men si `cb` la bay panics Lè sa a, kèk tribin pral fòse yon panic doub avòtman pwosesis la.
/// Gen kèk tribin ki itilize yon bibliyotèk C ki intern itilize rapèl ki pa ka deroule nan, se konsa panik soti nan `cb` ka deklanche yon pwosesis avòtman.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // kontinye backtrace la
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Menm jan ak `trace`, sèlman danjere ke li nan senkronize.
///
/// Fonksyon sa a pa gen garanti senkronizasyon men ki disponib lè karakteristik nan `std` nan sa a crate pa konpile nan.
/// Gade fonksyon `trace` la pou plis dokiman ak egzanp.
///
/// # Panics
///
/// Gade enfòmasyon sou `trace` pou opozisyon sou panik `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Yon trait ki reprezante yon sèl ankadreman nan yon backtrace, sede nan fonksyon `trace` sa a crate.
///
/// Fèmti fonksyon trase a pral sede ankadreman, epi li se ankadreman an nòmalman voye kòm aplikasyon an kache se pa toujou li te ye jouk ègzekutabl.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Retounen konsèy enstriksyon aktyèl la nan ankadreman sa a.
    ///
    /// Sa a se nòmalman enstriksyon nan pwochen egzekite nan ankadreman an, men se pa tout aplikasyon lis sa a ak 100% presizyon (men li la jeneralman trè fèmen).
    ///
    ///
    /// Li rekòmande yo pase valè sa a `backtrace::resolve` vire l 'nan yon non senbòl.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Retounen konsèy pil aktyèl la nan ankadreman sa a.
    ///
    /// Nan ka ke yon backend pa ka refè konsèy la chemine pou ankadreman sa a, se yon konsèy nil retounen.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Retounen adrès la senbòl kòmanse nan ankadreman an nan fonksyon sa a.
    ///
    /// Sa a pral eseye ranbouse konsèy la enstriksyon retounen pa `ip` nan kòmansman an nan fonksyon an, retounen ki valè.
    ///
    /// Nan kèk ka, sepandan, backend pral jis retounen `ip` soti nan fonksyon sa a.
    ///
    /// Valè retounen an ka itilize pafwa si `backtrace::resolve` echwe sou `ip` yo bay pi wo a.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Retounen adrès baz modil la ki fè pati ankadreman an.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Sa a bezwen vini an premye, asire ke Miri pran priyorite sou platfòm la lame
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // sèlman itilize nan dbghelp senbolize
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}