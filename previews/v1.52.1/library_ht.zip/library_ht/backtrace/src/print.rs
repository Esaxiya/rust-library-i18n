#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Yon fòmatè pou backtraces.
///
/// Kalite sa a ka itilize pou enprime yon backtrace kèlkeswa kote backtrace nan tèt li soti.
/// Si ou gen yon kalite `Backtrace` Lè sa a, aplikasyon `Debug` li yo deja itilize fòma enprime sa a.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Stil yo nan enprime ke nou ka enprime
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Enprime yon backtrace Terser ki depreferans sèlman gen enfòmasyon ki enpòtan
    Short,
    /// Enprime yon backtrace ki gen tout enfòmasyon posib
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Kreye yon nouvo `BacktraceFmt` ki pral ekri pwodiksyon bay `fmt` yo bay la.
    ///
    /// Agiman `format` la pral kontwole style la nan ki backtrace la enprime, epi yo pral agiman `print_path` la dwe itilize pou enprime ka yo `BytesOrWideString` nan non dosye.
    /// Kalite sa a li menm pa fè okenn enprime nan non dosye, men sa a rapèl oblije fè sa.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Enprime yon préambule pou backtrace a sou yo dwe enprime.
    ///
    /// Sa a se obligatwa sou kèk tribin pou backtraces yo dwe konplètman senbolize pita, ak otreman sa a ta dwe jis premye metòd la ou rele apre kreye yon `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Ajoute yon ankadreman nan pwodiksyon an backtrace.
    ///
    /// Sa a komèt retounen yon egzanp RAII nan yon `BacktraceFrameFmt` ki ka itilize aktyèlman enprime yon ankadreman, ak sou destriksyon li pral enkreman kontwa an ankadreman.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Konplete pwodiksyon an backtrace.
    ///
    /// Sa a se kounye a yon pa gen okenn-op, men se te ajoute pou future konpatibilite ak fòma backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Kounye a yon pa gen okenn op-ki gen ladan sa a hook pou pèmèt pou testaman future.
        Ok(())
    }
}

/// Yon fòmatè pou jis yon sèl ankadreman nan yon backtrace.
///
/// Kalite sa a kreye pa fonksyon `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Enprime yon `BacktraceFrame` ak fòmatè ankadreman sa a.
    ///
    /// Sa a pral rekursivman enprime tout ka `BacktraceSymbol` nan `BacktraceFrame` la.
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Enprime yon `BacktraceSymbol` nan yon `BacktraceFrame`.
    ///
    /// # Karakteristik obligatwa
    ///
    /// Fonksyon sa a mande pou karakteristik `std` nan `backtrace` crate yo dwe pèmèt, epi karakteristik `std` la pèmèt pa default.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: sa a se pa gwo ke nou pa fini enprime anyen
            // ak non ki pa utf8.
            // Erezman prèske tout bagay se utf8 kidonk sa pa ta dwe twò move.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Enprime yon `Frame` ak `Symbol` anvan tout koreksyon trase, tipikman soti nan rapèl yo anvan tout koreksyon nan crate sa a.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Ajoute yon ankadreman anvan tout koreksyon nan pwodiksyon an backtrace.
    ///
    /// Metòd sa a, kontrèman ak anvan an, pran agiman yo anvan tout koreksyon nan ka yo ke yo te sous ki soti nan diferan kote.
    /// Remake byen ke yo ka rele sa plizyè fwa pou yon sèl ankadreman.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Ajoute yon ankadreman anvan tout koreksyon nan pwodiksyon an backtrace, ki gen ladan enfòmasyon kolòn.
    ///
    /// Metòd sa a, tankou anvan an, pran agiman yo anvan tout koreksyon nan ka yo te ke yo te sous soti nan diferan kote.
    /// Remake byen ke yo ka rele sa plizyè fwa pou yon sèl ankadreman.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia pa kapab senbolize nan yon pwosesis konsa li gen yon fòma espesyal ki ka itilize pou senbolize pita.
        // Ekri an lèt detache ke olye pou yo enprime adrès nan fòma pwòp nou isit la.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Pa bezwen enprime ankadreman "null", li fondamantalman jis vle di ke backtrace nan sistèm te yon ti jan anvi trase tounen byen lwen.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Pou diminye gwosè TCB nan Sgx anklav, nou pa vle aplike fonksyonalite rezolisyon senbòl.
        // Olye de sa, nou ka enprime konpanse adrès la isit la, ki ta ka pita trase pou korije fonksyon an.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Ekri an lèt detache endèks la nan ankadreman an kòm byen ke konsèy la enstriksyon si ou vle nan ankadreman an.
        // Si nou depase premye senbòl ankadreman sa a menm si nou jis enprime espas ki apwopriye.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Next moute ekri non an senbòl, lè l sèvi avèk fòma a altène pou plis enfòmasyon si nou se yon backtrace plen.
        // Isit la nou tou okipe senbòl ki pa gen yon non,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Epi dire, enprime nimewo filename/line la si yo disponib.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line yo enprime sou liy anba non an senbòl, se konsa enprime kèk espas ki apwopriye sòt de dwat-aliyen tèt nou.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delege nan rapèl entèn nou an pou enprime non fichye a epi enprime nimewo liy lan.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Ajoute nimewo kolòn, si li disponib.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Nou sèlman pran swen sou senbòl nan premye nan yon ankadreman
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}