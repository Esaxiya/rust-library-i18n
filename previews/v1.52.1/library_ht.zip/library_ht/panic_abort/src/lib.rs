//! Aplikasyon nan Rust panics atravè pwosesis avòtman
//!
//! Lè yo konpare ak aplikasyon an atravè detant, sa a crate se *anpil* pi senp!Sa yo te di, li pa byen kòm versatile, men isit la ale!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" chaj la ak shim avòtman an ki enpòtan sou platfòm la nan kesyon an.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // rele std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Sou Windows, sèvi ak processeur-espesifik mekanis __fastfail la.Nan Windows 8 ak pita, sa a pral mete fen nan pwosesis la imedyatman san yo pa kouri nenpòt nan-pwosesis eksepsyonè.
            // Nan vèsyon pi bonè nan Windows, yo pral trete sekans enstriksyon sa a kòm yon vyolasyon aksè, mete fen nan pwosesis la men san yo pa nesesèman kontoune tout moun kap okipe eksepsyon.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: sa a se aplikasyon an menm jan ak nan `abort_internal` libstd a
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Sa a ... se yon ti jan nan yon etranj.Tl la; dr;se ke sa a oblije konekte kòrèkteman, eksplikasyon ki pi long la anba a.
//
// Kounye a binè yo nan libcore/libstd ke nou bato yo tout konpile ak `-C panic=unwind`.Sa a se fè asire ke binè yo se maksimòm konpatib ak sitiyasyon kòm anpil ke posib.
// Du a, sepandan, mande pou yon "personality function" pou tout fonksyon konpile ak `-C panic=unwind`.Fonksyon pèsonalite sa a hardcoded nan senbòl `rust_eh_personality` e li defini nan atik lang `eh_personality` la.
//
// So...
// poukisa nou pa jis defini ke lang atik isit la?Bon kesyon!Fason ki panic ègzekutabl yo lye nan se aktyèlman yon ti kras sibtil nan yo ke yo ap "sort of" nan magazen crate du a, men se sèlman aktyèlman lye si yon lòt pa aktyèlman lye.
//
// Sa a fini vle di ke tou de sa a crate ak panic_unwind crate a ka parèt nan magazen crate du a, epi si tou de defini `eh_personality` lang atik la Lè sa a, ki pral frape yon erè.
//
// Pou okipe sa a du a sèlman mande pou `eh_personality` a defini si ègzekutabl la panic ke yo te lye nan se ègzekutabl nan detant, ak otreman li pa oblije defini (just konsa).
// Nan ka sa a, sepandan, bibliyotèk sa a jis defini senbòl sa a pou gen omwen kèk pèsonalite yon kote.
//
// Esansyèlman se senbòl sa a jis defini jwenn branche jiska libcore/libstd binè, men li pa ta dwe janm rele jan nou pa konekte nan yon ègzekutabl detant nan tout.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Sou x86_64-pc-windows-gnu nou itilize pwòp fonksyon pèsonalite nou ki bezwen retounen `ExceptionContinueSearch` pandan nap pase sou tout ankadreman nou yo.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Menm jan ak pi wo a, sa a koresponn ak atik la lang `eh_catch_typeinfo` ki itilize sèlman sou Emscripten kounye a.
    //
    // Depi panics pa jenere eksepsyon ak eksepsyon etranje yo kounye a UB ak -C panic=avòtman (byenke sa a ka sijè a chanje), nenpòt ki apèl catch_unwind pa janm pral sèvi ak sa a tipinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // De sa yo rele pa objè demaraj nou yo sou i686-pc-windows-gnu, men yo pa bezwen fè anyen pou kò yo se nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}