#![feature(no_core)]
#![no_core]

// Gade rustc-std-workspace-core poukisa crate sa a nesesè.

// Chanje non crate la pou fè pou evite konfli ak modil la alloc nan liballoc.
extern crate alloc as foo;

pub use foo::*;