//! Detant panics pou Miri.
use alloc::boxed::Box;
use core::any::Any;

// Ki kalite chaj la ke motè Miri a pwopaje nan detant pou nou.
// Ou dwe konsèy ki menm gwosè ak.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-bay fonksyon ekstèn yo kòmanse detant.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Chaj la nou pase nan `miri_start_panic` yo pral egzakteman agiman an nou jwenn nan `cleanup` anba a.
    // Se konsa, nou jis bwat li moute yon fwa, yo ka resevwa yon bagay konsèy ki menm gwosè ak.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Rekipere kache `Box` la.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}