//! Detant pou *emscripten* sib.
//!
//! Lè nou konsidere ke aplikasyon abityèl detant Rust a pou tribin Unix apèl nan libunwind APIs yo dirèkteman, sou Emscripten nou olye rele nan C++ APW yo detant.
//! Sa a se jis yon konvenyans depi ègzekutabl Emscripten a toujou aplike sa yo APIs epi yo pa aplike libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Sa a matche ak Layout la nan std::type_info nan C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Premye `\x01` byte isit la se aktyèlman yon siyal majik nan LLVM nan *pa* aplike nenpòt lòt mangling tankou prefiks ak yon karaktè `_`.
    //
    //
    // Senbòl sa a se vtable ke `std::type_info` C++ itilize.
    // Objè nan kalite `std::type_info`, kalite deskriptè, gen yon konsèy sou tab sa a.
    // Kalite deskriptè yo referansye pa estrikti C++ EH yo defini pi wo a e ke nou konstwi anba a.
    //
    // Remake byen ke gwosè a reyèl se pi gwo pase 3 itilize, men nou sèlman bezwen vtable nou nan pwen nan eleman nan twazyèm.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info pou yon klas rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Nòmalman nou ta itilize .as_ptr().add(2) men sa pa mache nan yon kontèks konst.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Sa a entansyonèlman pa sèvi ak konplo a non nòmal mangling paske nou pa vle C++ pou kapab pwodwi oswa trape Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Sa nesesè paske C++ kòd ka pran execption nou yo ak std::exception_ptr ak retwow li plizyè fwa, petèt menm nan yon lòt fil.
    //
    //
    caught: AtomicBool,

    // Sa a bezwen yon Opsyon paske tout lavi objè a swiv C++ semantik: lè catch_unwind deplase bwat la soti nan eksepsyon an li dwe toujou kite objè a eksepsyon nan yon eta ki valab paske destriktè li yo toujou pral rele pa __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try aktyèlman ban nou yon konsèy nan estrikti sa a.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Depi cleanup() pa pèmèt yo panic, nou jis avòtman olye.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}