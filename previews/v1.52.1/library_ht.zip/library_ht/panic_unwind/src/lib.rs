//! Aplikasyon nan panics atravè chemine detant
//!
//! crate sa a se yon aplikasyon nan panics nan Rust lè l sèvi avèk "most native" chemine mekanis dewoulman nan platfòm la sa a se ke yo te konpile pou.
//! Sa a esansyèlman vin kategori nan twa bokit kounye a:
//!
//! 1. MSVC sib itilize SEH nan dosye `seh.rs` la.
//! 2. Emscripten itilize eksepsyon C++ nan dosye `emcc.rs` la.
//! 3. Tout lòt sib itilize libunwind/libgcc nan dosye `gcc.rs` la.
//!
//! Ou ka jwenn plis dokiman sou chak aplikasyon nan modil respektif la.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` se rès ak Miri, se konsa silans avètisman.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust demaraj objè depann sou senbòl sa yo, se konsa fè yo piblik.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Objektif ki pa sipòte detant.
        // - arch=wasm32
        // - os=okenn (sib "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Sèvi ak ègzekutabl la Miri.
        // Nou toujou bezwen tou chaje ègzekutabl nòmal ki anwo a, menm jan rustc espere sèten atik lang soti nan gen yo dwe defini.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Sèvi ak ègzekutabl reyèl la.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler nan libstd rele lè yon objè panic tonbe deyò nan `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler nan libstd rele lè yon eksepsyon etranje kenbe.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Pwen Antre pou ogmante yon eksepsyon, jis delege nan aplikasyon an platfòm-espesifik.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}