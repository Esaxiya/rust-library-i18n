//! Windows SEH
//!
//! Sou Windows (kounye a sèlman sou MSVC), mekanis defo manyen eksepsyon se estrikti eksepsyonèl manyen (SEH).
//! Sa a se byen diferan pase manyen eksepsyon ki baze sou nen (egzanp, sa ki lòt tribin unix itilize) an tèm de entèn entèn, se konsa LLVM oblije gen yon bon zafè nan sipò siplemantè pou SEH.
//!
//! Nan yon Nutshell, sa k ap pase isit la se:
//!
//! 1. Fonksyon `panic` la rele estanda Windows fonksyon `_CxxThrowException` lanse yon eksepsyon C++ tankou, sa ki lakòz pwosesis la detant.
//! 2.
//! Tout kousinen aterisaj ki te pwodwi pa du a sèvi ak fonksyon pèsonalite `__CxxFrameHandler3`, yon fonksyon nan CRT a, ak kòd la detant nan Windows pral sèvi ak fonksyon sa a pèsonalite egzekite tout kòd netwayaj sou chemine a.
//!
//! 3. Tout apèl du-pwodwi `invoke` gen yon pad aterisaj mete kòm yon enstriksyon `cleanuppad` LLVM, ki endike kòmansman woutin netwayaj la.
//! Pèsonalite a (nan etap 2, defini nan CRT a) ki responsab pou kouri woutin yo netwayaj.
//! 4. Evantyèlman kòd la "catch" nan intrinsèques la `try` (ki te pwodwi pa du a) egzekite ak endike ke kontwòl ta dwe tounen vin jwenn Rust.
//! Sa a se fè atravè yon `catchswitch` plis yon enstriksyon `catchpad` nan tèm LLVM IR, finalman retounen nòmal kontwòl nan pwogram nan ak yon enstriksyon `catchret`.
//!
//! Kèk diferans espesifik nan manyen eksepsyon ki baze sou gcc yo se:
//!
//! * Rust pa gen okenn fonksyon pèsonalite koutim, li pito *toujou*`__CxxFrameHandler3`.Anplis de sa, pa gen okenn filtraj siplemantè fèt, se konsa nou fini pwan nenpòt eksepsyon C++ ki rive sanble ak kalite a nou ap voye.
//! Remake byen ke voye yon eksepsyon nan Rust se konpòtman endefini de tout fason, kidonk sa a ta dwe amann.
//! * Nou te gen kèk done yo transmèt atravè fwontyè a detant, espesyalman yon `Box<dyn Any + Send>`.Tankou ak eksepsyon Tinen de endikasyon sa yo yo estoke kòm yon chaj nan eksepsyon nan tèt li.
//! Sou MSVC, sepandan, pa gen okenn bezwen pou yon alokasyon pil siplemantè paske se chemine a ap konsève pandan y ap fonksyon filtre yo te egzekite.
//! Sa vle di ke endikasyon yo te pase dirèkteman nan `_CxxThrowException` ki fè yo Lè sa a, refè nan fonksyon an filtre yo dwe ekri nan ankadreman an chemine nan `try` a intrinsèques.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Sa a bezwen yon Opsyon paske nou trape eksepsyon an pa referans ak destriktè li yo egzekite pa ègzekutabl la C++ .
    // Lè nou pran bwat la soti nan eksepsyon an, nou bezwen kite eksepsyon an nan yon eta ki valab pou destriktè li yo kouri san yo pa doub-jete bwat la.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Premye leve, yon pakèt antye definisyon kalite.Gen kèk etranj platfòm-espesifik isit la, ak yon anpil ki jis flagrant kopye soti nan LLVM.Rezon ki fè tout bagay sa a se aplike fonksyon an `panic` anba a nan yon apèl nan `_CxxThrowException`.
//
// Fonksyon sa a pran de agiman.Premye a se yon konsèy nan done yo nou ap pase nan, ki nan ka sa a se objè trait nou an.Trè fasil jwenn!Pwochen an, sepandan, se pi konplike.
// Sa a se yon konsèy nan yon estrikti `_ThrowInfo`, epi li jeneralman jis gen entansyon jis dekri eksepsyon ke yo te jete.
//
// Kounye a definisyon sa a kalite [1] se yon ti kras pwal sou tout kò, ak etranj prensipal la (ak diferans ki genyen nan atik la sou entènèt) se ke sou 32-ti jan pwent yo se endikasyon, men sou 64-ti jan pwent yo eksprime kòm 32-ti jan konpanse nan Senbòl `__ImageBase`.
//
// Macro `ptr_t` ak `ptr!` nan modil ki anba yo itilize pou eksprime sa.
//
// Labirent la nan definisyon kalite tou swiv sa LLVM emèt pou sa a sòt de operasyon.Pou egzanp, si ou konpile sa a C++ kòd sou MSVC ak emèt IR a LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      anile foo() { rust_panic a = {0, 1};
//          voye yon;}
//
// Sa a esansyèlman sa nou ap eseye rivalize.Pifò nan valè konstan ki anba yo te jis kopye nan LLVM,
//
// Nan nenpòt ka, estrikti sa yo, yo tout konstwi nan yon fason ki sanble, epi li jis yon ti jan detaye pou nou.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Remake byen ke nou entansyonèlman inyore règ mangling non isit la: nou pa vle C++ pou kapab trape Rust panics pa senpleman deklare yon `struct rust_panic`.
//
//
// Lè w ap modifye, asire w ke kòd la non tip egzakteman matche ak yon sèl la yo itilize nan `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Premye `\x01` byte isit la se aktyèlman yon siyal majik nan LLVM nan *pa* aplike nenpòt lòt mangling tankou prefiks ak yon karaktè `_`.
    //
    //
    // Senbòl sa a se vtable ke `std::type_info` C++ itilize.
    // Objè nan kalite `std::type_info`, kalite deskriptè, gen yon konsèy sou tab sa a.
    // Kalite deskriptè yo referansye pa estrikti C++ EH yo defini pi wo a e ke nou konstwi anba a.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Sa a se deskriptè kalite sèlman itilize lè voye yon eksepsyon.
// Se pati nan trape okipe pa eseye nan intrinsèques, ki jenere pwòp TypeDescriptor li yo.
//
// Sa a se amann depi ègzekutabl la MSVC itilize konparezon fisèl sou non an kalite matche ak TypeDescriptors olye ke egalite konsèy.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destriktè itilize si kòd la C++ deside pran eksepsyon an ak gout li san yo pa miltiplikasyon li.
// Pati nan trape nan eseye nan intrinsèques pral mete mo an premye nan objè a eksepsyon a 0 pou ke li se sote pa destriktè la.
//
// Remake byen ke x86 Windows sèvi ak konvansyon an rele "thiscall" pou fonksyon manm C++ olye pou yo konvansyon an default "C" rele.
//
// Fonksyon exception_copy la se yon ti jan espesyal isit la: li envoke pa ègzekutabl MSVC anba yon blòk try/catch ak panic ke nou jenere isit la yo pral itilize kòm rezilta kopi eksepsyon an.
//
// Sa a se itilize nan ègzekutabl la C++ sipòte kaptire eksepsyon ak std::exception_ptr, ki nou pa ka sipòte paske Box<dyn Any>se pa klonabl.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException ègzekutra antyèman sou sa a ankadreman chemine, kidonk pa gen okenn bezwen otreman transfere `data` nan pil la.
    // Nou jis pase yon konsèy chemine fonksyon sa a.
    //
    // ManuallyDrop a nesesè isit la depi nou pa vle eksepsyon yo dwe tonbe lè detant.
    // Olye de sa li pral tonbe nan exception_cleanup ki envoke pa ègzekutabl la C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Sa a ... pouvwa sanble etone, ak jistis konsa.Sou 32-ti jan MSVC endikasyon ki genyen ant estrikti sa yo se jis sa, endikasyon.
    // Sou 64-ti jan MSVC, sepandan, endikasyon ki genyen ant estrikti yo olye eksprime kòm konpansasyon 32-ti jan soti nan `__ImageBase`.
    //
    // Kontinwe, sou 32-ti jan MSVC nou ka deklare tout pwent sa yo nan `estatik la` s pi wo a.
    // Sou 64-ti jan MSVC, nou ta dwe eksprime soustraksyon nan endikasyon nan statik, ki Rust pa pèmèt kounye a, se konsa nou pa ka aktyèlman fè sa.
    //
    // Pi bon bagay kap vini an, lè sa a se ranpli estrikti sa yo nan ègzekutabl (panike se deja "slow path" la de tout fason).
    // Se konsa, isit la nou reentèrprete tout jaden sa yo konsèy kòm nonb antye relatif 32-ti jan ak Lè sa a, magazen valè a ki enpòtan nan li (atomikman, menm jan panics konkouran ka rive).
    //
    // Teknikman ègzekutabl la ap pwobableman fè yon lekti nonatomic nan jaden sa yo, men nan teyori yo pa janm li valè a *mal* konsa li pa ta dwe twò move ...
    //
    // Nan nenpòt ka, nou fondamantalman bezwen fè yon bagay tankou sa jiskaske nou ka eksprime plis operasyon nan estatik (e nou pa janm ka kapab).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Yon chaj NIL isit la vle di ke nou te resevwa isit la soti nan trape (...) nan __rust_try.
    // Sa rive lè yo kenbe yon eksepsyon etranje ki pa Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Sa a se egzije pa du a egziste (egzanp, li nan yon atik lang), men li pa janm aktyèlman rele pa du a paske __C_specific_handler oswa_except_handler3 se fonksyon an pèsonalite ki toujou itilize.
//
// Pakonsekan sa a se jis yon souch avòtman.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}