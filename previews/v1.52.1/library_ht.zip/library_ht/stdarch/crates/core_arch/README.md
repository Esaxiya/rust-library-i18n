`core::arch` - Nwayo bibliyotèk Rust a achitekti-espesifik intrinsèques
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modil la `core::arch` aplike achitekti ki depann de intrinsèques (egzanp SIMD).

# Usage 

`core::arch` ki disponib kòm yon pati nan `libcore` epi li se re-ekspòte pa `libstd`.Prefere itilize li via `core::arch` oswa `std::arch` pase via crate sa a.
Karakteristik enstab yo souvan disponib nan swa Rust via `feature(stdsimd)` la.

Sèvi ak `core::arch` atravè sa a crate mande pou lannwit Rust, epi li ka (ak fè) kraze souvan.Sèl ka kote ou ta dwe konsidere itilize li atravè crate sa a se:

* si ou bezwen re-konpile `core::arch` tèt ou, egzanp, ak sib-karakteristik patikilye pèmèt ki pa pèmèt pou `libcore`/`libstd`.
Note: si ou bezwen re-konpile li pou yon sib ki pa estanda, tanpri pito lè l sèvi avèk `xargo` ak re-konpile `libcore`/`libstd` jan sa apwopriye olye pou yo sèvi ak sa a crate.
  
* lè l sèvi avèk kèk karakteristik ki pa ta ka disponib menm dèyè karakteristik enstab Rust.Nou eseye kenbe sa yo nan yon minimòm.
Si ou bezwen sèvi ak kèk nan karakteristik sa yo, tanpri louvri yon pwoblèm pou nou ka ekspoze yo nan lannwit Rust epi ou ka itilize yo soti nan la.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` se sitou distribye anba kondisyon yo nan tou de lisans lan MIT ak Lisans lan Apache (Version 2.0), ak pòsyon ki kouvri pa divès kalite BSD tankou lisans.

Gade LISANS-APACHE, ak LISANS-MIT pou plis detay.

# Contribution

Sòf si ou klèman deklare otreman, nenpòt ki kontribisyon entansyonèlman soumèt pou enklizyon nan `core_arch` pa ou, jan sa defini nan lisans lan Apache-2.0, yo dwe doub lisansye kòm pi wo a, san yo pa nenpòt lòt tèm oswa kondisyon.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












