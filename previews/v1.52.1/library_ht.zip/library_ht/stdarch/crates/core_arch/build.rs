use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Itilize pou di anotasyon `#[assert_instr]` nou yo ke tout intrinsèques simd yo disponib pou teste codegen yo, depi kèk ladan yo fèmen pòt dèyè yon `-Ctarget-feature=+unimplemented-simd128` siplemantè ki pa gen okenn ekivalan nan `#[target_feature]` kounye a.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}