# Kontribye nan stdarch

`stdarch` crate a pi plis pase vle aksepte kontribisyon!Premye ou pral pwobableman vle tcheke deyò depo a epi asire w ke tès yo pase pou ou:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Ki kote `<your-target-arch>` se sib la sib jan `rustup` itilize, egzanp `x86_x64-unknown-linux-gnu` (san yo pa nenpòt ki `nightly-` anvan oswa menm jan an).
Sonje tou ke depo sa a egzije pou chanèl chak swa nan Rust!
Tès ki anwo yo an reyalite mande pou chak swa rust yo dwe default la sou sistèm ou a, yo mete ki itilize `rustup default nightly` (ak `rustup default stable` retounen).

Si nenpòt nan etap ki anwo yo pa travay, [please let us know][new]!

Next ou ka [find an issue][issues] ede soti sou, nou te chwazi yon kèk ak [`help wanted`][help] a ak [`impl-period`][impl] Tags ki ta ka patikilyèman itilize kèk èd. 
Ou ka pi enterese nan [#40][vendor], mete ann aplikasyon tout vandè intrinsèques sou x86.Pwoblèm sa a te gen kèk endikasyon bon sou ki kote yo kòmanse!

Si ou te gen kesyon jeneral santi yo lib yo [join us on gitter][gitter] epi mande alantou!Ezite ping swa@BurntSushi oswa@alexcrichton ak kesyon.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Ki jan yo ekri egzanp pou intrinsics stdarch

Gen kèk karakteristik ki dwe pèmèt pou entresèk yo bay yo travay byen epi yo dwe egzanp lan sèlman dwe dirije pa `cargo test --doc` lè karakteristik nan sipòte pa CPU a.

Kòm yon rezilta, `fn main` la default ki te pwodwi pa `rustdoc` pa pral travay (nan pifò ka yo).
Konsidere itilize sa ki annapre yo kòm yon gid asire egzanp ou travay jan yo espere a.

```rust
/// # // Nou bezwen cfg_target_feature asire egzanp lan se sèlman
/// # // kouri pa `cargo test --doc` lè CPU a sipòte karakteristik la
/// # #![feature(cfg_target_feature)]
/// # // Nou bezwen target_feature pou intrinsèques la nan travay
/// # #![feature(target_feature)]
/// #
/// # // rustdoc pa default itilize `extern crate stdarch`, men nou bezwen
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Vrè fonksyon prensipal la
/// # fn main() {
/// #     // Kouri sa sèlman si `<target feature>` sipòte
/// #     si cfg_feature_enabled! ("<target feature>"){
/// #         // Kreye yon fonksyon `worker` ki pral sèlman kouri si karakteristik sib la
/// #         // se sipòte epi asire ke `target_feature` pèmèt pou travayè ou
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         danjere fn worker() {
/// // Ekri egzanp ou isit la.Karakteristik intrinsèques espesifik ap travay isit la!Ale sovaj!
///
/// #         }
///
/// #         danjere { worker(); }
/// #     }
/// # }
```

Si kèk nan sentaks ki anwo a pa sanble abitye, seksyon [Documentation as tests] nan [Rust Book] dekri sentaks `rustdoc` la byen byen.
Kòm toujou, santi yo lib yo [join us on gitter][gitter] epi mande nou si ou frape nenpòt ki dechire, epi di ou mèsi pou ede amelyore dokiman yo nan `stdarch`!

# Enstriksyon Tès Altènatif

Li jeneralman rekòmande ke ou itilize `ci/run.sh` nan kouri tès yo.
Sepandan sa pa ka mache pou ou, pa egzanp si ou sou Windows.

Nan ka sa a ou ka tonbe tounen nan kouri `cargo +nightly test` ak `cargo +nightly test --release -p core_arch` pou fè tès jenerasyon an kòd.
Remake byen ke sa yo mande pou chèn lan lannwit yo dwe enstale ak pou `rustc` konnen sou sib sib ou ak CPU li yo.
An patikilye ou bezwen mete varyab anviwònman an `TARGET` menm jan ou ta pou `ci/run.sh`.
Anplis de sa ou bezwen mete `RUSTCFLAGS` (bezwen `C` a) yo endike karakteristik sib, egzanp `RUSTCFLAGS="-C -target-features=+avx2"`.
Ou kapab tou mete `-C -target-cpu=native` si w ap "just" devlope kont CPU ou ye kounye a.

Ou dwe avèti ke lè ou itilize enstriksyon altènatif sa yo, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], egzanp
tès jenerasyon enstriksyon ka echwe paske demonte a te nonmen yo yon lòt jan, pa egzanp
li ka jenere `vaesenc` olye pou yo enstriksyon `aesenc` malgre yo konpòte yo menm bagay la.
Epitou enstriksyon sa yo egzekite mwens tès pase sa ki ta nòmalman fèt, kidonk pa sezi ke lè ou evantyèlman rale-mande kèk erè ka parèt pou tès ki pa kouvri isit la

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






