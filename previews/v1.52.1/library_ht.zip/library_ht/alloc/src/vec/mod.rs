//! Yon vwazen etalaj ki ka grandi kalite ak pil-atribye ba sa, ekri `Vec<T>`.
//!
//! Vectors gen `O(1)` Indexing, amortise `O(1)` pouse (nan fen a) ak `O(1)` pòp (soti nan fen a).
//!
//!
//! Vectors asire yo pa janm asiyen plis pase `isize::MAX` bytes.
//!
//! # Examples
//!
//! Ou ka klèman kreye yon [`Vec`] ak [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... oswa lè l sèvi avèk macro [`vec!`] la:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // dis zewo
//! ```
//!
//! Ou ka [`push`] valè sou fen yon vector (ki pral grandi vector a jan sa nesesè):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping valè travay nan anpil menm jan an:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors sipòte endèksasyon tou (atravè [`Index`] ak [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Yon vwazen etalaj ki ka grandi, ekri kòm `Vec<T>` ak pwononse 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Makro [`vec!`] la bay pou fè inisyalizasyon pi pratik:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Li kapab tou inisyalize chak eleman nan yon `Vec<T>` ak yon valè yo bay yo.
/// Sa a pouvwa ap pi efikas pase fè alokasyon ak inisyalizasyon nan etap apa, espesyalman lè inisyalize yon vector nan zewo:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Sa ki annapre yo ekivalan, men potansyèlman pi dousman:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Pou plis enfòmasyon, gade [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Sèvi ak yon `Vec<T>` kòm yon chemine efikas:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Enprime 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Kalite `Vec` la pèmèt jwenn aksè nan valè pa endèks, paske li aplike [`Index`] trait la.Yon egzanp ap gen plis eksplisit:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // li pral montre '2'
/// ```
///
/// Sepandan fè atansyon: si ou eseye jwenn aksè nan yon endèks ki pa nan `Vec` la, lojisyèl ou pral panic!Ou pa ka fè sa:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Sèvi ak [`get`] ak [`get_mut`] si ou vle tcheke si endèks la se nan `Vec` la.
///
/// # Slicing
///
/// Yon `Vec` ka chanje.Nan lòt men an, tranch yo se li sèlman objè yo.
/// Pou jwenn yon [slice][prim@slice], sèvi ak [`&`].Egzanp:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... e se tout!
/// // ou ka fè li tou konsa:
/// let u: &[usize] = &v;
/// // oswa tankou sa a:
/// let u: &[_] = &v;
/// ```
///
/// Nan Rust, li pi komen yo pase tranch kòm agiman olye ke vectors lè ou jis vle bay aksè li.Menm bagay la tou ale pou [`String`] ak [`&str`].
///
/// # Kapasite ak alokasyon
///
/// Kapasite yon vector se kantite espas ki afekte pou nenpòt eleman future ke yo pral ajoute sou vector la.Sa a pa dwe konfonn ak *longè a* nan yon vector, ki presize kantite eleman aktyèl nan vector la.
/// Si longè yon vector a depase kapasite li, yo pral kapasite li otomatikman ap ogmante, men eleman li yo pral oblije reasigne.
///
/// Pou egzanp, yon vector ak kapasite 10 ak longè 0 ta dwe yon vector vid ak espas pou 10 plis eleman.Pouse 10 oswa mwens eleman sou vector a pa pral chanje kapasite li oswa lakòz reasignasyon rive.
/// Sepandan, si longè vector a ogmante a 11, li pral oblije reasigne, ki ka ralanti.Pou rezon sa a, li rekòmande pou itilize [`Vec::with_capacity`] chak fwa li posib pou presize ki jan gwo vector la espere jwenn.
///
/// # Guarantees
///
/// Akòz nati ekstrèmman fondamantal li yo, `Vec` fè yon anpil nan garanti sou konsepsyon li yo.Sa a asire ke li nan kòm ba-anlè ke posib nan ka jeneral la, epi yo ka kòrèkteman manipile nan fason primitif pa kòd danjere.Remake byen ke garanti sa yo, al gade nan yon `Vec<T>` ki pa kalifye.
/// Si paramèt kalite adisyonèl yo te ajoute (egzanp, sipòte alokatè koutim), pase defo défaut yo ka chanje konpòtman an.
///
/// Pifò fondamantalman, `Vec` se epi toujou ap yon (konsèy, kapasite, longè) triplet.Pa plis, pa mwens.Lòd la nan jaden sa yo se konplètman espesifye, epi ou ta dwe itilize metòd ki apwopriye yo modifye sa yo.
/// Konsèy la pap janm nil, kidonk kalite sa a nil-konsèy-optimize.
///
/// Sepandan, konsèy la pa ka aktyèlman pwen nan atribye ba memwa.
/// An patikilye, si ou konstwi yon `Vec` ak kapasite 0 via [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], oswa lè w rele [`shrink_to_fit`] sou yon Vec vid, li pa pral asiyen memwa.Menm jan an tou, si ou magazen kalite zewo ki menm gwosè ak andedan yon `Vec`, li pa pral asiyen espas pou yo.
/// *Remake byen ke nan ka sa a `Vec` a pa ka rapòte yon [`capacity`] nan 0*.
/// `Vec` ap asiyen si epi sèlman si [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// An jeneral, detay alokasyon `Vec` yo trè sibtil-si ou gen entansyon asiyen memwa lè l sèvi avèk yon `Vec` epi sèvi ak li pou yon lòt bagay (swa yo pase nan kòd danjere, oswa yo bati pwòp memwa-te apiye koleksyon ou), asire w ke deallocate memwa sa a lè l sèvi avèk `from_raw_parts` refè `Vec` la ak Lè sa a jete li.
///
/// Si yon `Vec`*gen* atribye ba memwa, Lè sa a, memwa a li lonje dwèt sou se sou pil wòch la (jan sa defini nan allocator a Rust se configuré yo itilize pa default), ak pwen konsèy li yo [`len`] inisyalize, eleman vwazen nan lòd (ki sa ou ta gade si ou fòse li nan yon tranch), ki te swiv pa [`kapasite`]`,`[`len`] lojikman inisyalize, eleman vwazen.
///
///
/// Yon vector ki gen eleman `'a'` ak `'b'` ak kapasite 4 ka vizyalize tankou anba a.Pati nan tèt se `Vec` struct la, li gen yon konsèy nan tèt la nan alokasyon an nan pil lan, longè ak kapasite.
/// Pati ki anba a se alokasyon an sou pil la, yon blòk memwa vwazen.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** reprezante memwa ki pa inisyalize, gade [`MaybeUninit`].
/// - Note: ABI a se pa ki estab ak `Vec` pa fè okenn garanti sou Layout memwa li yo (ki gen ladan lòd la nan jaden).
///
/// `Vec` pap janm fè yon "small optimization" kote eleman yo aktyèlman estoke sou chemine a pou de rezon:
///
/// * Li ta fè li pi difisil pou kòd danjere pou kòrèkteman manipile yon `Vec`.Sa ki nan yon `Vec` pa ta gen yon adrès ki estab si li te sèlman deplase, epi li ta pi difisil detèmine si yon `Vec` te aktyèlman resevwa lajan memwa.
///
/// * Li ta penalize ka jeneral la, antrene yon branch adisyonèl sou chak aksè.
///
/// `Vec` pa janm ap otomatikman retresi tèt li, menm si konplètman vid.Sa a asire pa gen okenn alokasyon nesesè oswa deallocations rive.Vide yon `Vec` ak Lè sa a ranpli li tounen jiska menm [`len`] a ta dwe antrene pa gen okenn apèl nan allocator la.Si ou vle libere memwa ki pa itilize, itilize [`shrink_to_fit`] oswa [`shrink_to`].
///
/// [`push`] ak [`insert`] pap janm (re) asiyen si kapasite rapòte a ase.[`push`] ak [`insert`]*ap*(re) asiyen si [`len`]`==`[`kapasite`].Sa se, kapasite a rapòte se konplètman egzat, epi yo ka konte sou.Li ka menm itilize manyèlman lib memwa a atribye ba pa yon `Vec` si yo vle.
/// Metòd ensèsyon esansyèl *ka* reasigne, menm lè li pa nesesè.
///
/// `Vec` pa garanti okenn estrateji kwasans patikilye lè reasignasyon lè plen, ni lè yo rele [`reserve`].Estrateji aktyèl la se debaz epi li ka pwouve dezirab yo sèvi ak yon faktè kwasans ki pa konstan.Kèlkeswa sa estrateji yo itilize pral nan kou garanti *O*(1) [`push`] amortize.
///
/// `vec![x; n]`, `vec![a, b, c, d]`, ak [`Vec::with_capacity(n)`][`Vec::with_capacity`], pral tout pwodwi yon `Vec` ak egzakteman kapasite yo mande yo.
/// Si [`len`]`==`[`kapasite`], (tankou se ka a pou [`vec!`] macro), Lè sa a, yon `Vec<T>` ka konvèti pou ale ak pou soti nan yon [`Box<[T]>`][owned slice] san yo pa alokasyon oswa deplase eleman yo.
///
/// `Vec` pa pral espesyalman recouvrir nenpòt done ki retire nan li, men tou, pa pral espesyalman prezève li.Memwa uninitialized li se grafouyen espas ke li ka itilize sepandan li vle.Li pral jeneralman jis fè tou sa ki pi efikas oswa otreman fasil aplike.Pa konte sou retire done yo dwe efase pou rezon sekirite.
/// Menm si ou lage yon `Vec`, tanpon li yo ka senpleman reyitilize pa yon lòt `Vec`.
/// Menm si ou zewo yon memwa `Vec` an premye, ki ka pa aktyèlman rive paske optimizeur a pa konsidere sa a yon efè segondè ki dwe konsève.
/// Gen yon ka ke nou pa pral kraze, sepandan: lè l sèvi avèk `unsafe` kòd yo ekri nan kapasite a depase, ak Lè sa a, ogmante longè a matche ak, se toujou valab.
///
/// Kounye a, `Vec` pa garanti lòd kote eleman yo tonbe.
/// Lòd la chanje nan tan lontan an epi li ka chanje ankò.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metòd nannan
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Konstwi yon nouvo `Vec<T>` vid.
    ///
    /// vector a pa pral asiyen jiskaske eleman yo pouse sou li.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Konstwi yon nouvo, vid `Vec<T>` ak kapasite a espesifye.
    ///
    /// vector a yo pral kapab kenbe egzakteman `capacity` eleman san yo pa reasigne.
    /// Si `capacity` se 0, vector a pa pral asiyen.
    ///
    /// Li enpòtan pou remake ke byenke vector retounen an gen *kapasite* espesifye, vector a pral gen yon *zewo* longè *.
    ///
    /// Pou yon eksplikasyon sou diferans ki genyen ant longè ak kapasite, gade *[Kapasite ak alokasyon]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector a pa gen okenn atik, menm si li gen kapasite pou plis
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Sa yo tout fè san yo pa alokasyon ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... men sa ka fè vector a reasigne
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Kreye yon `Vec<T>` ki sòti dirèkteman nan eleman anvan tout koreksyon nan yon lòt vector.
    ///
    /// # Safety
    ///
    /// Sa a trè danjere, akòz kantite envariant ki pa tcheke:
    ///
    /// * `ptr` bezwen yo te deja resevwa lajan atravè [`String`]/`Vec<T>`(omwen, li trè chans yo dwe kòrèk si li pa t ').
    /// * `T` bezwen gen menm gwosè ak aliyman tankou sa `ptr` te resevwa lajan an.
    ///   (`T` ki gen yon aliyman mwens strik se pa ase, aliyman an reyèlman bezwen yo dwe egal a satisfè kondisyon an [`dealloc`] ki dwe memwa dwe resevwa lajan ak deallocated ak Layout a menm.)
    ///
    /// * `length` bezwen mwens pase oswa egal a `capacity`.
    /// * `capacity` bezwen yo dwe kapasite a ki konsèy la resevwa lajan ak.
    ///
    /// Vyole sa yo ka lakòz pwoblèm tankou koripsyon estrikti done entèn allocator la.Pou egzanp li se **pa** san danje yo bati yon `Vec<u8>` soti nan yon konsèy nan yon etalaj C `char` ak longè `size_t`.
    /// Li la tou pa an sekirite yo bati yon sèl soti nan yon `Vec<u16>` ak longè li yo, paske allocator a gen sousi pou aliyman an, ak de kalite sa yo gen aliyman diferan.
    /// Tanpon la te resevwa lajan ak aliyman 2 (pou `u16`), men apre yo fin vire l 'nan yon `Vec<u8>` li pral deallocated ak aliyman 1.
    ///
    /// Pwopriyetè a nan `ptr` se efektivman transfere nan `Vec<T>` la ki ka Lè sa a, repati, reasigne oswa chanje sa ki nan memwa pwente nan pa konsèy la nan volonte.
    /// Asire ke pa gen anyen lòt bagay ki itilize konsèy la apre ou fin rele fonksyon sa a.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Mete ajou sa a lè vec_into_raw_parts estabilize.
    ///     // Anpeche kouri `v` destriktè pou nou nan kontwòl konplè sou alokasyon an.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Rale divès moso enfòmasyon enpòtan sou `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Kouvri memwa ak 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Mete tout bagay tounen ansanm nan yon Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Konstwi yon nouvo `Vec<T, A>` vid.
    ///
    /// vector a pa pral asiyen jiskaske eleman yo pouse sou li.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Konstwi yon nouvo, vid `Vec<T, A>` ak kapasite espesifye ak distribitè yo bay la.
    ///
    /// vector a yo pral kapab kenbe egzakteman `capacity` eleman san yo pa reasigne.
    /// Si `capacity` se 0, vector a pa pral asiyen.
    ///
    /// Li enpòtan pou remake ke byenke vector retounen an gen *kapasite* espesifye, vector a pral gen yon *zewo* longè *.
    ///
    /// Pou yon eksplikasyon sou diferans ki genyen ant longè ak kapasite, gade *[Kapasite ak alokasyon]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector a pa gen okenn atik, menm si li gen kapasite pou plis
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Sa yo tout fè san yo pa alokasyon ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... men sa ka fè vector a reasigne
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Kreye yon `Vec<T, A>` ki sòti dirèkteman nan eleman anvan tout koreksyon nan yon lòt vector.
    ///
    /// # Safety
    ///
    /// Sa a trè danjere, akòz kantite envariant ki pa tcheke:
    ///
    /// * `ptr` bezwen yo te deja resevwa lajan atravè [`String`]/`Vec<T>`(omwen, li trè chans yo dwe kòrèk si li pa t ').
    /// * `T` bezwen gen menm gwosè ak aliyman tankou sa `ptr` te resevwa lajan an.
    ///   (`T` ki gen yon aliyman mwens strik se pa ase, aliyman an reyèlman bezwen yo dwe egal a satisfè kondisyon an [`dealloc`] ki dwe memwa dwe resevwa lajan ak deallocated ak Layout a menm.)
    ///
    /// * `length` bezwen mwens pase oswa egal a `capacity`.
    /// * `capacity` bezwen yo dwe kapasite a ki konsèy la resevwa lajan ak.
    ///
    /// Vyole sa yo ka lakòz pwoblèm tankou koripsyon estrikti done entèn allocator la.Pou egzanp li se **pa** san danje yo bati yon `Vec<u8>` soti nan yon konsèy nan yon etalaj C `char` ak longè `size_t`.
    /// Li la tou pa an sekirite yo bati yon sèl soti nan yon `Vec<u16>` ak longè li yo, paske allocator a gen sousi pou aliyman an, ak de kalite sa yo gen aliyman diferan.
    /// Tanpon la te resevwa lajan ak aliyman 2 (pou `u16`), men apre yo fin vire l 'nan yon `Vec<u8>` li pral deallocated ak aliyman 1.
    ///
    /// Pwopriyetè a nan `ptr` se efektivman transfere nan `Vec<T>` la ki ka Lè sa a, repati, reasigne oswa chanje sa ki nan memwa pwente nan pa konsèy la nan volonte.
    /// Asire ke pa gen anyen lòt bagay ki itilize konsèy la apre ou fin rele fonksyon sa a.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Mete ajou sa a lè vec_into_raw_parts estabilize.
    ///     // Anpeche kouri `v` destriktè pou nou nan kontwòl konplè sou alokasyon an.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Rale divès moso enfòmasyon enpòtan sou `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Kouvri memwa ak 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Mete tout bagay tounen ansanm nan yon Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Dekonpoze yon `Vec<T>` nan eleman anvan tout koreksyon li yo.
    ///
    /// Retounen konsèy la anvan tout koreksyon nan done yo kache, longè vector la (nan eleman), ak kapasite a atribye nan done yo (nan eleman).
    /// Sa yo se agiman yo menm nan lòd la menm jan ak agiman yo [`from_raw_parts`].
    ///
    /// Apre ou fin rele fonksyon sa a, moun kap rele a responsab pou memwa ki deja jere pa `Vec` la.
    /// Sèl fason pou fè sa se konvèti konsèy la anvan tout koreksyon, longè, ak kapasite tounen nan yon `Vec` ak fonksyon [`from_raw_parts`] a, sa ki pèmèt destriktè a fè netwayaj la.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Nou kapab kounye a fè chanjman nan eleman yo, tankou transmutasyon konsèy la anvan tout koreksyon nan yon kalite konpatib.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Dekonpoze yon `Vec<T>` nan eleman anvan tout koreksyon li yo.
    ///
    /// Retounen konsèy la anvan tout koreksyon nan done ki kache, longè vector la (nan eleman), kapasite atribye nan done yo (nan eleman), ak allocator la.
    /// Sa yo se agiman yo menm nan lòd la menm jan ak agiman yo [`from_raw_parts_in`].
    ///
    /// Apre ou fin rele fonksyon sa a, moun kap rele a responsab pou memwa ki deja jere pa `Vec` la.
    /// Sèl fason pou fè sa se konvèti konsèy la anvan tout koreksyon, longè, ak kapasite tounen nan yon `Vec` ak fonksyon [`from_raw_parts_in`] a, sa ki pèmèt destriktè a fè netwayaj la.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Nou kapab kounye a fè chanjman nan eleman yo, tankou transmutasyon konsèy la anvan tout koreksyon nan yon kalite konpatib.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Retounen kantite eleman vector la ka kenbe san yo pa relokalize yo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Rezève kapasite pou omwen `additional` plis eleman yo dwe eleman nan `Vec<T>` yo bay la.
    /// Koleksyon an ka rezève plis espas pou evite alokasyon souvan.
    /// Apre ou fin rele `reserve`, kapasite yo pral pi gran pase oswa egal a `self.len() + additional`.
    /// Pa fè anyen si kapasite deja ase.
    ///
    /// # Panics
    ///
    /// Panics si nouvo kapasite a depase `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Rezève kapasite minimòm lan pou ekzakteman `additional` plis eleman yo dwe eleman nan `Vec<T>` yo bay la.
    ///
    /// Apre ou fin rele `reserve_exact`, kapasite yo pral pi gran pase oswa egal a `self.len() + additional`.
    /// Pa fè anyen si kapasite a deja ase.
    ///
    /// Remake byen ke alokatè a ka bay koleksyon an plis espas pase sa li mande.
    /// Se poutèt sa, kapasite pa ka konte sou yo dwe jisteman minim.
    /// Prefere `reserve` si future ensèsyon yo espere.
    ///
    /// # Panics
    ///
    /// Panics si nouvo kapasite a debòde `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Eseye rezève kapasite pou omwen `additional` plis eleman yo dwe eleman nan `Vec<T>` yo bay la.
    /// Koleksyon an ka rezève plis espas pou evite alokasyon souvan.
    /// Apre ou fin rele `try_reserve`, kapasite yo pral pi gran pase oswa egal a `self.len() + additional`.
    /// Pa fè anyen si kapasite deja ase.
    ///
    /// # Errors
    ///
    /// Si kapasite a debòde, oswa alokatè a rapòte yon echèk, Lè sa a, se yon erè retounen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-rezève memwa a, sòti si nou pa kapab
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Koulye a, nou konnen sa a pa ka OOM nan mitan travay konplèks nou an
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // trè konplike
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Eseye rezève kapasite minimòm pou ekzakteman eleman `additional` yo dwe eleman nan `Vec<T>` yo bay la.
    /// Apre ou fin rele `try_reserve_exact`, kapasite yo pral pi gran pase oswa egal a `self.len() + additional` si li retounen `Ok(())`.
    ///
    /// Pa fè anyen si kapasite a deja ase.
    ///
    /// Remake byen ke alokatè a ka bay koleksyon an plis espas pase sa li mande.
    /// Se poutèt sa, kapasite pa ka konte sou yo dwe jisteman minim.
    /// Prefere `reserve` si future ensèsyon yo espere.
    ///
    /// # Errors
    ///
    /// Si kapasite a debòde, oswa alokatè a rapòte yon echèk, Lè sa a, se yon erè retounen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-rezève memwa a, sòti si nou pa kapab
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Koulye a, nou konnen sa a pa ka OOM nan mitan travay konplèks nou an
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // trè konplike
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Retresi kapasite vector la otank posib.
    ///
    /// Li pral lage desann tankou fèmen ke posib nan longè a, men allocator a ka toujou enfòme vector a ke gen espas pou kèk eleman plis.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kapasite a pa janm mwens pase longè a, e pa gen anyen pou yo fè lè yo egal, pou nou ka evite ka panic nan `RawVec::shrink_to_fit` pa sèlman rele li ak yon pi gwo kapasite.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Réduit kapasite vector a ak yon pi ba mare.
    ///
    /// Kapasite a ap rete omwen gwo tankou tou de longè ak valè apwovizyone.
    ///
    ///
    /// Si kapasite aktyèl la se mwens pase limit ki pi ba a, sa a se yon pa gen okenn op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Konvèti vector a nan [`Box<[T]>`][owned slice].
    ///
    /// Remake byen ke sa a pral lage nenpòt kapasite depase.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Nenpòt kapasite depase retire:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Pi kout vector la, kenbe premye eleman yo `len` ak jete rès la.
    ///
    /// Si `len` pi gran pase longè aktyèl vector a, sa pa gen okenn efè.
    ///
    /// Metòd [`drain`] la ka rivalize `truncate`, men sa lakòz eleman depase yo retounen olye pou yo tonbe.
    ///
    ///
    /// Remake byen ke metòd sa a pa gen okenn efè sou kapasite a resevwa lajan nan vector la.
    ///
    /// # Examples
    ///
    /// Koupe yon senk eleman vector a de eleman:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Pa gen koupe ki rive lè `len` pi gran pase longè aktyèl vector la:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Koupe lè `len == 0` ekivalan a rele metòd [`clear`] la.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Sa a san danje paske:
        //
        // * tranch la pase nan `drop_in_place` valab;ka a `len > self.len` evite kreye yon tranch envalid, ak
        // * se `len` la nan vector la retresi anvan yo rele `drop_in_place`, tankou ke pa gen okenn valè dwe tonbe de fwa nan ka `drop_in_place` yo te panic yon fwa (si li panics de fwa, pwogram lan avòt).
        //
        //
        //
        unsafe {
            // Note: Li entansyonèl ke sa a se `>` epi yo pa `>=`.
            //       Chanje li nan `>=` gen enplikasyon pèfòmans negatif nan kèk ka.
            //       Gade #78884 pou plis.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Ekstrè yon tranch ki gen vector a tout antye.
    ///
    /// Ekivalan a `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Ekstrè yon tranch mutable nan vector a tout antye.
    ///
    /// Ekivalan a `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Retounen yon konsèy anvan tout koreksyon nan tanpon vector la.
    ///
    /// Moun kap rele a dwe asire ke vector la surviv konsèy la fonksyon sa a retounen, oswa lòt moun li pral fini montre fatra.
    /// Modifye vector la ka lakòz tanpon li yo dwe reasigne, ki ta tou fè nenpòt ki endikasyon li envalid.
    ///
    /// Moun kap rele a dwe asire tou ke memwa pwen (non-transitively) pwen yo pa janm ekri (eksepte andedan yon `UnsafeCell`) lè l sèvi avèk konsèy sa a oswa nenpòt konsèy ki soti nan li.
    /// Si ou bezwen mitasyon sa ki nan tranch la, sèvi ak [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Nou lonbraj metòd la tranch an menm non an pou fè pou evite ale nan `deref`, ki kreye yon referans entèmedyè.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Retounen yon konsèy danjere san danje nan pezib vector la.
    ///
    /// Moun kap rele a dwe asire ke vector la surviv konsèy la fonksyon sa a retounen, oswa lòt moun li pral fini montre fatra.
    ///
    /// Modifye vector la ka lakòz tanpon li yo dwe reasigne, ki ta tou fè nenpòt ki endikasyon li envalid.
    ///
    /// # Examples
    ///
    /// ```
    /// // Asiyen vector gwo ase pou 4 eleman.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inisyalize eleman atravè konsèy kri ekri, Lè sa a, mete longè.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Nou lonbraj metòd la tranch an menm non an pou fè pou evite ale nan `deref_mut`, ki kreye yon referans entèmedyè.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Retounen yon referans nan alokatè a kache.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Fòs longè vector a `new_len`.
    ///
    /// Sa a se yon operasyon ki ba-nivo ki kenbe okenn nan envariant yo nòmal nan kalite la.
    /// Nòmalman chanje longè yon vector fè lè l sèvi avèk youn nan operasyon ki an sekirite olye, tankou [`truncate`], [`resize`], [`extend`], oswa [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` dwe mwens pase oswa egal a [`capacity()`].
    /// - Eleman yo nan `old_len..new_len` dwe inisyalize.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Metòd sa a kapab itil pou sitiyasyon kote vector la ap sèvi kòm yon pezib pou lòt kòd, patikilyèman sou FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Sa a se jis yon skelèt minim pou egzanp lan doc;
    /// # // pa sèvi ak sa a kòm yon pwen depa pou yon bibliyotèk reyèl.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Pou chak dokiman metòd FFI a, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SEKIRITE: Lè `deflateGetDictionary` retounen `Z_OK`, li kenbe sa:
    ///     // 1. `dict_length` eleman yo te inisyalize.
    ///     // 2.
    ///     // `dict_length` <= (32_768) kapasite ki fè `set_len` san danje yo rele.
    ///     unsafe {
    ///         // Fè apèl FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... epi mete ajou longè a nan sa ki te inisyalize.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Pandan ke egzanp sa a se son, gen yon koule memwa depi vectors enteryè yo pa te libere anvan apèl la `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` se vid konsa pa gen okenn eleman bezwen inisyalize.
    /// // 2. `0 <= capacity` toujou kenbe tou sa `capacity` se.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Nòmalman, isit la, yon sèl ta sèvi ak [`clear`] olye yo kòrèkteman gout sa ki nan epi konsa pa koule memwa.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Retire yon eleman nan vector a epi retounen li.
    ///
    /// Se eleman nan retire ranplase pa eleman ki sot pase a nan vector la.
    ///
    /// Sa a pa prezève kòmann-nan, men se O(1).
    ///
    /// # Panics
    ///
    /// Panics si `index` se soti nan limit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Nou ranplase pwòp tèt ou [endèks] ak dènye eleman an.
            // Remake byen ke si limit yo tcheke pi wo a reyisi dwe gen yon dènye eleman (ki ka pwòp tèt ou [endèks] tèt li).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Mete yon eleman nan pozisyon `index` nan vector, déplacement tout eleman apre li sou bò dwat la.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // espas pou eleman nan nouvo
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // enfayib Tach la yo mete valè a nouvo
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Chanje tout bagay pou fè espas.
                // (Kopi eleman "endèks la" an de kote youn apre lòt.)
                ptr::copy(p, p.offset(1), len - index);
                // Ekri li an, ranplase premye kopi eleman endèks la.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Retire epi retounen eleman an nan pozisyon `index` nan vector, déplacement tout eleman apre li sou bò gòch la.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `index` se soti nan limit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // kote nap pran an.
                let ptr = self.as_mut_ptr().add(index);
                // kopye li soti, san danje gen yon kopi valè a sou chemine a ak nan vector an menm tan an.
                //
                ret = ptr::read(ptr);

                // Shift tout bagay desann ranpli ki plas.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Kenbe sèlman eleman yo espesifye nan predikate la.
    ///
    /// Nan lòt mo, retire tout eleman `e` sa yo ki `f(&e)` retounen `false`.
    /// Metòd sa a opere nan plas, vizite chak eleman egzakteman yon fwa nan lòd orijinal la, ak prezève lòd la nan eleman yo double klas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Paske eleman yo vizite egzakteman yon fwa nan lòd orijinal la, yo ka itilize eta ekstèn pou deside ki eleman pou kenbe.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Evite doub gout si gad gout la pa egzekite, depi nou ka fè kèk twou pandan pwosesis la.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-trete len-> |^-pwochen yo tcheke
        //                  | <-efase cnt-> |
        //      | <-orijinal_len-> |Kenbe: Eleman ki predikatè retounen vre sou.
        //
        // Twou: Deplase oswa tonbe plas eleman.
        // Unchecked: Eleman ki valab san kontwòl.
        //
        // Pral gad gout sa a dwe envoke lè predikatif oswa `drop` nan eleman panike.
        // Li orè eleman san kontwòl yo kouvri twou ak `set_len` nan longè ki kòrèk la.
        // Nan ka lè predikatif ak `drop` pa janm panike, li pral optimize soti.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SEKIRITE: Trailing atik san kontwòl yo dwe valab depi nou pa janm manyen yo.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SEKIRITE: Apre ou fin ranpli twou, tout bagay yo nan memwa vwazen.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SEKIRITE: Eleman san kontwòl dwe valab.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Avanse bonè pou evite doub gout si `drop_in_place` panike.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SEKIRITE: Nou pa janm manyen eleman sa a ankò apre nou fin tonbe.
                unsafe { ptr::drop_in_place(cur) };
                // Nou deja avanse kontwa an.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SEKIRITE: `deleted_cnt`> 0, kidonk plas twou a pa dwe sipèpoze ak eleman aktyèl la.
                // Nou itilize kopi pou deplase, epi pa janm manyen eleman sa a ankò.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Tout atik yo trete.Sa a ka optimize nan `set_len` pa LLVM.
        drop(g);
    }

    /// Retire tout men premye eleman konsekitif nan vector ki rezoud menm kle a.
    ///
    ///
    /// Si vector la klase, sa retire tout kopi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Retire tout men premye eleman konsekitif nan vector ki satisfè yon relasyon egalite yo bay.
    ///
    /// Fonksyon `same_bucket` la pase referans a de eleman ki soti nan vector epi li dwe detèmine si eleman yo konpare egal.
    /// Eleman yo pase nan lòd opoze nan lòd yo nan tranch lan, kidonk si `same_bucket(a, b)` retounen `true`, `a` yo retire li.
    ///
    ///
    /// Si vector la klase, sa retire tout kopi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Mete yon eleman nan do a nan yon koleksyon.
    ///
    /// # Panics
    ///
    /// Panics si nouvo kapasite a depase `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Sa a pral panic oswa avòtman si nou ta asiyen> isize::MAX bytes oswa si ogmantasyon nan longè ta debòde pou kalite zewo-gwosè.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Retire dènye eleman ki soti nan yon vector epi retounen li, oswa [`None`] si li vid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Deplase tout eleman yo nan `other` nan `Self`, kite `other` vid.
    ///
    /// # Panics
    ///
    /// Panics si kantite eleman nan vector a debòde yon `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Mete eleman `Self` soti nan lòt pezib.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Kreye yon iteratè drenaj ki retire seri a espesifye nan vector la ak pwodiksyon atik yo retire yo.
    ///
    /// Lè iteratè **a** tonbe, tout eleman nan seri a yo retire nan vector, menm si iteratè a pa te konplètman boule.
    /// Si iteratè a **pa** tonbe (avèk [`mem::forget`] pou egzanp), li pa espesifye konbyen eleman yo retire.
    ///
    /// # Panics
    ///
    /// Panics si pwen an kòmanse pi gran pase pwen an fen oswa si pwen an fen a pi gran pase longè vector la.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Yon seri konplè efase vector la
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Sekirite memwa
        //
        // Lè Drain la premye kreye, li diminye longè sous vector a pou asire ke pa gen okenn eleman inisyalize oswa deplase ki soti nan aksesib nan tout si destriktè Drain a pa janm vin kouri.
        //
        //
        // Drain pral ptr::read soti valè yo retire.
        // Lè fini, rete ke vèk la kopye tounen pou kouvri twou a, epi longè vector la retabli nan nouvo longè a.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // mete longè self.vec a yo kòmanse, yo dwe san danje nan ka Drain se fwit
            self.set_len(start);
            // Sèvi ak prete nan IterMut pou endike konpòtman prete tout iteratè Drain (tankou &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Efase vector la, retire tout valè.
    ///
    /// Remake byen ke metòd sa a pa gen okenn efè sou kapasite a resevwa lajan nan vector la.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Retounen kantite eleman ki nan vector, ki refere tou kòm 'length' li yo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Retounen `true` si vector a pa gen okenn eleman.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divize koleksyon an an de nan endèks yo bay la.
    ///
    /// Retounen yon vector ki fèk resevwa lajan ki gen eleman ki nan seri `[at, len)` la.
    /// Apre apèl la, yo pral kite vector orijinal la ki gen eleman `[0, at)` yo ak kapasite anvan li yo chanje.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // nouvo vector a ka pran sou tanpon orijinal la epi evite kopi an
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Unsafely `set_len` ak kopi atik nan `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Rdimansyonman `Vec` la an plas pou `len` egal a `new_len`.
    ///
    /// Si `new_len` pi gran pase `len`, `Vec` la pwolonje pa diferans lan, ak chak plas adisyonèl ki ranpli ak rezilta a nan rele fèmen `f` la.
    ///
    /// Valè yo retounen soti nan `f` pral fini nan `Vec` a nan lòd la yo te pwodwi.
    ///
    /// Si `new_len` se mwens pase `len`, `Vec` la tou senpleman koupe.
    ///
    /// Metòd sa a itilize yon fèmti pou kreye nouvo valè sou chak pouse.Si ou ta pito [`Clone`] yon valè yo bay, sèvi ak [`Vec::resize`].
    /// Si ou vle itilize [`Default`] trait la pou jenere valè, ou ka pase [`Default::default`] kòm dezyèm agiman an.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Konsome ak fwit `Vec` la, retounen yon referans mityèl nan sa ki, `&'a mut [T]`.
    /// Remake byen ke kalite `T` la dwe survivre `'a` pou tout lavi yo chwazi a.
    /// Si kalite a gen sèlman referans estatik, oswa okenn nan tout, Lè sa a, sa a ka chwazi yo dwe `'static`.
    ///
    /// Fonksyon sa a sanble ak fonksyon [`leak`][Box::leak] sou [`Box`] eksepte ke pa gen okenn fason pou rekipere memwa ki fwit lan.
    ///
    ///
    /// Fonksyon sa a itil sitou pou done k ap viv pou rès lavi pwogram nan.
    /// Jete referans la retounen ap lakòz yon koule memwa.
    ///
    /// # Examples
    ///
    /// Itilizasyon senp:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Retounen kapasite rezèv ki rete nan vector a kòm yon tranch `MaybeUninit<T>`.
    ///
    /// Tranch la retounen ka itilize yo ranpli vector la ak done (egzanp
    /// pa lekti ki soti nan yon dosye) anvan make done yo kòm inisyalize lè l sèvi avèk metòd la [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Asiyen vector gwo ase pou 10 eleman.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Ranpli premye 3 eleman yo.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Make 3 premye eleman vector yo menm jan yo te inisyalize yo.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Metòd sa a pa aplike an tèm de `split_at_spare_mut`, yo anpeche invalidasyon nan endikasyon pezib la.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Retounen kontni vector kòm yon tranch `T`, ansanm ak kapasite rezèv ki rete nan vector kòm yon tranch `MaybeUninit<T>`.
    ///
    /// Tranch kapasite rezèv retounen an ka itilize pou ranpli vector ak done (pa egzanp lè w li nan yon dosye) anvan ou make done yo kòm inisyalize lè l sèvi avèk metòd [`set_len`] la.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Remake byen ke sa a se yon API ki ba-nivo, ki ta dwe itilize ak swen pou rezon optimize.
    /// Si ou bezwen ajoute done nan yon `Vec` ou ka itilize [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] oswa [`resize_with`], tou depann de bezwen egzak ou yo.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Rezève plis espas ase ase pou 10 eleman.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Ranpli 4 eleman kap vini yo.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Make 4 eleman vector yo menm jan yo te inisyalize yo.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len inyore e konsa pa janm chanje
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sekirite: chanje retounen .2 (&mut itilize) konsidere menm jan ak rele `.set_len(_)`.
    ///
    /// Metòd sa a itilize pou gen aksè inik nan tout pati vèk nan yon fwa nan `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` se garanti yo dwe valab pou eleman `len`
        // - `spare_ptr` ap montre yon eleman pase tanpon an, kidonk li pa sipèpoze ak `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Rdimansyonman `Vec` la an plas pou `len` egal a `new_len`.
    ///
    /// Si `new_len` pi gran pase `len`, `Vec` la pwolonje pa diferans lan, ak chak plas adisyonèl ki ranpli ak `value`.
    ///
    /// Si `new_len` se mwens pase `len`, `Vec` la tou senpleman koupe.
    ///
    /// Metòd sa a egzije pou `T` aplike [`Clone`], yo nan lòd pou kapab script valè a pase.
    /// Si ou bezwen plis fleksibilite (oswa ou vle konte sou [`Default`] olye pou yo [`Clone`]), sèvi ak [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klon ak ajoute tout eleman nan yon tranch `Vec` la.
    ///
    /// Repete sou tranch `other` la, klone chak eleman, epi apre sa ajoute li nan `Vec` sa a.
    /// `other` vector la travèse nan lòd.
    ///
    /// Remake byen ke fonksyon sa a se menm jan ak [`extend`] eksepte ke li se espesyalize nan travay ak tranch olye.
    ///
    /// Si ak ki lè Rust vin spesyalizasyon fonksyon sa a ap gen chans pou obsolèt (men li toujou disponib).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopi eleman ki soti nan seri `src` nan fen vector la.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garanti ke seri yo bay la valab pou endèksman pwòp tèt ou
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Kòd sa a jeneralize `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Pwolonje vector a pa `n` valè, lè l sèvi avèk dèlko yo bay la.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Sèvi ak SetLenOnDrop nan travay alantou ensèk kote du ka pa reyalize magazen an nan `ptr` nan self.set_len() pa alyas.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Ekri tout eleman eksepte dènye a
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Ogmante longè a nan chak etap nan ka next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Nou ka ekri dènye eleman dirèkteman san klonaj san nesesite
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len mete pa gad dimansyon
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Retire youn apre lòt eleman repete nan vector selon aplikasyon [`PartialEq`] trait la.
    ///
    ///
    /// Si vector la klase, sa retire tout kopi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Metòd entèn ak fonksyon
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` bezwen endèks valab
    /// - `self.capacity() - self.len()` dwe `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len ogmante sèlman apre inisyalizasyon eleman yo
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - moun kap rele garanti ke src se yon endèks valab
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Eleman te jis inisyalize ak `MaybeUninit::write`, kidonk li ok pou ogmante len
            // - len ogmante apre chak eleman pou anpeche fwit (gade pwoblèm #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - moun kap rele garanti ke `src` se yon endèks ki valab
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Tou de pwent yo kreye nan referans tranch inik (`&mut [_]`) Se konsa, yo valab epi yo pa sipèpoze.
            //
            // - Eleman yo se: Kopi kidonk li OK kopye yo, san yo pa fè anyen ak valè orijinal yo
            // - `count` ki egal a len nan `source`, se konsa sous ki valab pou `count` li
            // - `.reserve(count)` garanti ke `spare.len() >= count` se konsa rezèv ki valab pou `count` ekri
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Eleman yo te jis inisyalize pa `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Komen enplemantasyon trait pou Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): ak cfg(test) metòd `[T]::to_vec` nannan, ki nesesè pou definisyon metòd sa a, pa disponib.
    // Olye de sa sèvi ak fonksyon an `slice::to_vec` ki disponib sèlman ak cfg(test) NB al gade modil la slice::hack nan slice.rs pou plis enfòmasyon
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // lage nenpòt bagay ki pa pral ranplase
        self.truncate(other.len());

        // self.len <= other.len akòz koupe anwo a, se konsa tranch yo isit la yo toujou nan-limit.
        //
        let (init, tail) = other.split_at(self.len());

        // reutilize valè yo genyen allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Kreye yon iteratè konsome, se sa ki, yon sèl ki deplase chak valè soti nan vector la (nan kòmansman nan fen).
    /// vector la pa ka itilize apre ou fin rele sa.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s gen kalite fisèl, pa &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // fèy metòd kote divès kalite aplikasyon SpecFrom/SpecExtend delege lè yo pa gen okenn optimizasyon plis pou aplike
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Sa a se ka a pou yon iteratè jeneral.
        //
        // Fonksyon sa a ta dwe ekivalan moral nan:
        //
        //      pou atik nan iteratè {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB pa ka debòde depi nou ta oblije alokasyon espas adrès la
                self.set_len(len + 1);
            }
        }
    }

    /// Kreye yon iterasyon épissure ki ranplase seri a espesifye nan vector la ak iteratè a bay `replace_with` ak pwodiksyon atik yo retire.
    ///
    /// `replace_with` pa bezwen menm longè ak `range`.
    ///
    /// `range` se retire menm si iteratè a pa boule jouk nan fen an.
    ///
    /// Li pa espesifye konbyen eleman yo retire nan vector la si valè `Splice` la fwit.
    ///
    /// D 'iteratè `replace_with` la sèlman boule lè valè `Splice` la tonbe.
    ///
    /// Sa a pi bon si:
    ///
    /// * Ke a (eleman nan vector la apre `range`) vid,
    /// * oswa `replace_with` bay mwens oswa egal eleman pase longè `ranje` a
    /// * oswa limit ki pi ba nan `size_hint()` li yo egzak.
    ///
    /// Sinon, yon vector tanporè resevwa lajan ak ke a deplase de fwa.
    ///
    /// # Panics
    ///
    /// Panics si pwen an kòmanse pi gran pase pwen an fen oswa si pwen an fen a pi gran pase longè vector la.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Kreye yon iteratè ki itilize yon fèmti pou detèmine si yo ta dwe retire yon eleman.
    ///
    /// Si fèmti a retounen vre, Lè sa a, se eleman an retire ak sede.
    /// Si fèmti a retounen fo, eleman an ap rete nan vector la epi yo pa pral sede pa iteratè la.
    ///
    /// Sèvi ak metòd sa a ekivalan a kòd sa a:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // kòd ou isit la
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Men, `drain_filter` se pi fasil yo sèvi ak.
    /// `drain_filter` se tou pi efikas, paske li ka backshift eleman yo nan etalaj la nan esansyèl.
    ///
    /// Remake byen ke `drain_filter` tou pèmèt ou mitasyon chak eleman nan fèmti a filtre, kèlkeswa si ou chwazi kenbe oswa retire li.
    ///
    ///
    /// # Examples
    ///
    /// Divize yon etalaj nan even ak chans, reutilize alokasyon orijinal la:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Gad kont nou ap fwit (anplifikasyon koule)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Pwolonje aplikasyon ki kopye eleman soti nan referans anvan pouse yo sou Vec la.
///
/// Aplikasyon sa a espesyalize pou iteratè tranch, kote li itilize [`copy_from_slice`] pou ajoute tout tranch la an menm tan.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Aplike konparezon nan vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Aplike kòmann-nan vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // sèvi ak gout pou [T] sèvi ak yon tranch anvan tout koreksyon, al gade nan eleman ki nan vector la kòm pi fèb kalite nesesè;
            //
            // te kapab evite kesyon de validite nan sèten ka
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec okipe deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Kreye yon `Vec<T>` vid.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: tès rale nan libstd, ki lakòz erè isit la
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: tès rale nan libstd, ki lakòz erè isit la
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Jwenn tout sa ki nan `Vec<T>` la kòm yon etalaj, si gwosè li egzakteman matche ak sa yo ki nan etalaj la mande yo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Si longè a pa matche ak, opinyon an vini tounen nan `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Si ou anfòm ak jis ap resevwa yon prefiks nan `Vec<T>` a, ou ka rele [`.truncate(N)`](Vec::truncate) an premye.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SEKIRITE: `.set_len(0)` toujou bon.
        unsafe { vec.set_len(0) };

        // SEKIRITE: Yon konsèy `Vec` toujou aliyen byen, epi
        // aliyman etalaj la bezwen se menm bagay ak atik yo.
        // Nou tcheke pi bonè ke nou gen ase atik.
        // Atik yo pa pral double-gout kòm `set_len` a di `Vec` a pa lage yo tou.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}