use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Yon lòt espesyalizasyon trait pou Vec::from_iter nesesè lamen priyorite espesyalizasyon sipèpoze gade [`SpecFromIter`](super::SpecFromIter) pou plis detay.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Dewoule iterasyon an premye, menm jan vector a pral elaji sou iterasyon sa a nan chak ka lè iterabl la pa vid, men bouk la nan extend_desugared() pa pral wè vector la yo te plen nan kèk iterasyon riban ki vin apre yo.
        //
        // Se konsa, nou jwenn pi bon branch prediksyon.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // dwe delege nan spec_extend() depi extend() li menm delege spec_from pou Vecs vid
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // dwe delege nan spec_extend() depi extend() li menm delege spec_from pou Vecs vid
        //
        vector.spec_extend(iterator);
        vector
    }
}