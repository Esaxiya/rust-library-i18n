use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Espesyalizasyon trait itilize pou Vec::from_iter
///
/// ## Graf delegasyon an:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Yon ka komen se pase yon vector nan yon fonksyon ki imedyatman re-kolekte nan yon vector.
        // Nou ka kout sikwi sa a si IntoIter la pa te avanse nan tout.
        // Lè li te avanse Nou kapab tou reutilize memwa a epi deplase done yo devan an.
        // Men, nou sèlman fè sa lè VEC a ki kapab lakòz pa ta gen plis kapasite rès pase kreye li nan aplikasyon an jenerik FromIterator ta.
        //
        // Limitasyon sa a pa estrikteman nesesè kòm konpòtman alokasyon Vec la entansyonèlman pa espesifye.
        // Men, li se yon chwa konsèvatif.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // dwe delege nan spec_extend() depi extend() li menm delege spec_from pou Vecs vid
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Sa a itilize `iterator.as_slice().to_vec()` depi spec_extend dwe pran plis etap pou rezone sou kapasite final la + longè e konsa fè plis travay.
// `to_vec()` dirèkteman asiyen kantite lajan ki kòrèk la ak ranpli li egzakteman.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ak cfg(test) metòd `[T]::to_vec` nannan, ki nesesè pou definisyon metòd sa a, pa disponib.
    // Olye de sa sèvi ak fonksyon an `slice::to_vec` ki disponib sèlman ak cfg(test) NB al gade modil la slice::hack nan slice.rs pou plis enfòmasyon
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}