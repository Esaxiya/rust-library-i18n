use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Yon iteratè ki itilize yon fèmti pou detèmine si yo ta dwe retire yon eleman.
///
/// Struct sa a kreye pa [`Vec::drain_filter`].
/// Gade dokiman li yo pou plis.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Endèks la nan atik la ke yo pral enspekte pa apèl nan pwochen `next`.
    pub(super) idx: usize,
    /// Nimewo a nan atik ki te vide (removed) konsa byen lwen.
    pub(super) del: usize,
    /// Longè orijinal la nan `vec` anvan yo seche.
    pub(super) old_len: usize,
    /// Predikat tès filtre a.
    pub(super) pred: F,
    /// Yon drapo ki endike yon panic ki te fèt nan predikatè tès filtre a.
    /// Sa a se itilize kòm yon allusion nan aplikasyon an gout yo anpeche konsomasyon nan rès la nan `DrainFilter` la.
    /// Nenpòt atik ki pa trete yo pral backshifted nan `vec` a, men pa gen okenn atik plis yo pral tonbe oswa teste pa predikatè a filtre.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Retounen yon referans nan alokatè a kache.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Mete ajou endèks la *apre* yo rele predikatè a.
                // Si se endèks la mete ajou anvan ak panics a predikate, eleman nan endèks sa a ta dwe fwit.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Sa a se yon eta trè messed moute, epi pa gen reyèlman yon bagay evidamman dwa fè.
                        // Nou pa vle kontinye ap eseye egzekite `pred`, se konsa nou jis backshift tout eleman yo trete epi di vèk la ke yo toujou egziste.
                        //
                        // Backshift la oblije anpeche yon gout doub nan dènye atik la avèk siksè vide anvan yon panic nan predike la.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Eseye konsome nenpòt eleman ki rete si predikatè filtre a poko panike.
        // Nou pral backshift nenpòt eleman ki rete si nou te deja panike oswa si konsomasyon isit la panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}