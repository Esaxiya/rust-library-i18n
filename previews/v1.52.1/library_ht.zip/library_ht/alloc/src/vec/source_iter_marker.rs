use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Mak espesyalizasyon pou kolekte yon tiyo iteratè nan yon Vec pandan y ap reutilize alokasyon sous la, sa vle di
/// egzekite tiyo a an plas.
///
/// Paran SourceIter trait la nesesè pou fonksyon espesyalize a pou jwenn aksè nan alokasyon ki dwe reyitilize a.
/// Men li pa sifi pou spesyalizasyon an valab.
/// Gade limit adisyonèl sou impl la.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-entèn SourceIter/InPlaceIterable traits yo sèlman aplike pa chenn nan adaptè <Adapter<Adapter<IntoIter>>> (tout posede pa core/std).
// Lòt limit sou aplikasyon yo adaptè (pi lwen pase `impl<I: Trait> Trait for Adapter<I>`) sèlman depann sou lòt traits deja make kòm espesyalizasyon traits (Kopi, TrustedRandomAccess, FusedIterator).
//
// I.e. makè a pa depann de vi nan kalite itilizatè-apwovizyone.Modulo twou a Kopi, ki plizyè lòt espesyalizasyon deja depann sou.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Lòt kondisyon ki pa ka eksprime atravè trait bounds.Nou konte sou konst eval olye:
        // a) pa gen okenn ZSTs kòm pa ta gen okenn alokasyon yo reutilize ak konsèy aritmetik ta panic b) gwosè matche ak jan sa nesesè nan kontra Alloc c) aliyman matche ak jan sa nesesè nan kontra Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // rezèv nan aplikasyon plis jenerik
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // itilize eseye-pliye depi
        // - li vektè pi bon pou kèk cartes iteratè
        // - kontrèman ak pi metòd iterasyon entèn, li sèlman pran yon pwòp tèt ou &mut
        // - li pèmèt nou fil konsèy la ekri nan anndan li yo ak jwenn li tounen nan fen an
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iterasyon reyisi, pa lage tèt
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // tcheke si kontra SourceIter te konfime avètisman: si yo pa t 'nou pa ka menm fè li nan pwen sa a
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // tcheke kontra InPlaceIterable.Sa a se posib sèlman si iteratè a avanse konsèy la sous nan tout.
        // Si li itilize aksè san kontwòl atravè TrustedRandomAccess Lè sa a, konsèy la sous ap rete nan pozisyon inisyal li yo ak nou pa ka itilize li kòm referans
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // gout nenpòt valè ki rete nan ke sous la men anpeche gout nan alokasyon nan tèt li yon fwa IntoIter ale soti nan sijè ki abòde lan si gout panics a Lè sa a, nou menm tou nou koule nenpòt eleman kolekte nan dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // kontra a InPlaceIterable pa ka verifye jisteman isit la depi try_fold gen yon referans eksklizif nan konsèy la sous tout sa nou ka fè se tcheke si li la toujou nan ranje
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}