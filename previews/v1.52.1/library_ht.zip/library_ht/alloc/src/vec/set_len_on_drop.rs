// Mete longè vèk la lè valè `SetLenOnDrop` la soti nan dimansyon.
//
// Lide a se: jaden an longè nan SetLenOnDrop se yon varyab lokal ki optimizeur a pral wè pa alyas ak nenpòt magazen nan konsèy done Vec la.
// Sa a se yon solisyon pou pwoblèm alyas #32155 pwoblèm
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}