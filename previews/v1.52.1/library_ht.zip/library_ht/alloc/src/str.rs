//! Tranch fisèl Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Kalite `&str` la se youn nan de kalite fisèl prensipal yo, lòt la se `String`.
//! Kontrèman ak kontrepati `String` li yo, sa li yo prete.
//!
//! # Itilizasyon Debaz
//!
//! Yon deklarasyon fisèl debaz nan kalite `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Isit la nou te deklare yon fisèl literal, konnen tou kòm yon tranch fisèl.
//! Chèn literal gen yon lavi estatik, ki vle di fisèl la `hello_world` garanti yo dwe valab pou dire a nan pwogram nan tout antye.
//!
//! Nou ka klèman presize tout lavi `hello_world` tou:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Anpil nan itilizasyon yo nan modil sa a yo sèlman itilize nan konfigirasyon tès la.
// Li pi pwòp jis fèmen avètisman an unused_imports pase ranje yo.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` nan `Concat<str>` pa gen sans isit la.
/// Paramèt kalite sa a nan trait la egziste sèlman pou pèmèt yon lòt impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // pasan ak gwosè hardcoded kouri pi vit espesyalize ka yo ak longè ti séparation
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // abitrè ki pa zewo gwosè fallback
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Optimize rantre nan aplikasyon ki travay pou tou de Vec<T>(T: Kopi) ak vwazin enteryè fisèl la Kounye a (2018-05-13) gen yon ensèk ak enferans kalite ak espesyalizasyon (al gade pwoblèm #36262) Pou rezon sa a SliceConcat<T>pa espesyalize pou T: Kopi ak SliceConcat<str>se sèl itilizatè fonksyon sa a.
// Li rete an plas pou tan an lè sa a se fiks yo.
//
// limit yo pou fisèl-rantre nan yo se S: Prete<str>ak pou Vec-rantre Prete <[T]> [T] ak str tou de impl AsRef <[T]> pou kèk T
// => s.borrow().as_ref() e nou toujou gen tranch
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // tranch nan premye se youn nan sèlman san yo pa yon separateur anvan li
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // kalkile longè total egzak la nan Vec la ansanm si kalkil la `len` debòde, nou pral panic nou ta gen kouri soti nan memwa de tout fason ak rès la nan fonksyon an egzije pou tout Vec la pre-resevwa lajan pou sekirite
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // prepare yon tanpon inisyalize
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // kopi séparation ak tranch sou san limit chèk jenere pasan ak konpanse hardcoded pou ti separasyon amelyorasyon masiv posib (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Yon aplikasyon prete etranj ka retounen tranch diferan pou kalkil la longè ak kopi aktyèl la.
        //
        // Asire w ke nou pa ekspoze octets inisyalize moun kap rele a.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Metòd pou tranch fisèl.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Konvèti yon `Box<str>` nan yon `Box<[u8]>` san kopye oswa repati.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Ranplase tout alimèt nan yon modèl ak yon lòt fisèl.
    ///
    /// `replace` kreye yon nouvo [`String`], ak kopi done ki soti nan tranch fisèl sa a nan li.
    /// Pandan y ap fè sa, li eseye jwenn alimèt nan yon modèl.
    /// Si li jwenn nenpòt, li ranplase yo ak tranch la fisèl ranplasman.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Lè modèl la pa matche ak:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Ranplase premye N alimèt nan yon modèl ak yon lòt fisèl.
    ///
    /// `replacen` kreye yon nouvo [`String`], ak kopi done ki soti nan tranch fisèl sa a nan li.
    /// Pandan y ap fè sa, li eseye jwenn alimèt nan yon modèl.
    /// Si li jwenn nenpòt ki, li ranplase yo ak tranch la fisèl ranplasman nan pifò `count` fwa.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Lè modèl la pa matche ak:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Espere diminye tan yo nan re-alokasyon an
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Retounen ekivalan miniskil tranch fisèl sa a, kòm yon nouvo [`String`].
    ///
    /// 'Lowercase' se defini dapre kondisyon ki nan Unicode Derive Nwayo `Lowercase` Pwopriyete a.
    ///
    /// Depi kèk karaktè ka elaji nan karaktè miltip lè chanje ka a, fonksyon sa a retounen yon [`String`] olye pou yo modifye paramèt la an plas.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Yon egzanp difisil, ak sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // men nan fen yon mo, li nan ς, pa σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Lang san ka pa chanje:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ kat pou σ, eksepte nan fen yon mo kote li kat pou ς.
                // Sa a se sèlman kondisyonèl (contextual) la men lang-endepandan kat nan `SpecialCasing.txt`, se konsa difisil-kòd li olye ke gen yon jenerik mekanis "condition".
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // pou definisyon `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Retounen ekivalan majiskil tranch fisèl sa a, kòm yon nouvo [`String`].
    ///
    /// 'Uppercase' se defini dapre kondisyon ki nan Unicode Derive Nwayo `Uppercase` Pwopriyete a.
    ///
    /// Depi kèk karaktè ka elaji nan karaktè miltip lè chanje ka a, fonksyon sa a retounen yon [`String`] olye pou yo modifye paramèt la an plas.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Scripts san ka yo pa chanje:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Yon karaktè ka vin miltip:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Konvèti yon [`Box<str>`] nan yon [`String`] san kopye oswa repati.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Kreye yon nouvo [`String`] pa repete yon fisèl `n` fwa.
    ///
    /// # Panics
    ///
    /// Fonksyon sa a pral panic si kapasite a ta debòde.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// Yon panic sou debòde:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Retounen yon kopi fisèl sa a kote chak karaktè trase nan ekivalan ASCII majuskul li yo.
    ///
    ///
    /// Lèt ASCII 'a' a 'z' yo trase nan 'A' a 'Z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou majiskil valè a nan plas, sèvi ak [`make_ascii_uppercase`].
    ///
    /// Pou majiskil karaktè ASCII nan adisyon a karaktè ki pa ASCII, sèvi ak [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() prezève envariant UTF-8 la.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Retounen yon kopi fisèl sa a kote chak karaktè trase nan ekivalan ASCII miniskil li yo.
    ///
    ///
    /// Lèt ASCII 'A' a 'Z' yo trase nan 'a' a 'z', men lèt ki pa ASCII yo chanje.
    ///
    /// Pou miniskil valè an plas, sèvi ak [`make_ascii_lowercase`].
    ///
    /// Pou miniskil karaktè ASCII nan adisyon a karaktè ki pa ASCII, sèvi ak [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() prezève envariant UTF-8 la.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Konvèti yon tranch bwat nan bytes nan yon tranch fisèl bwat san yo pa tcheke si fisèl la gen UTF-8 valab.
///
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}