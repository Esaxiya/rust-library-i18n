#![stable(feature = "wake_trait", since = "1.51.0")]
//! Kalite ak Traits pou travay ak travay asenkron.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Aplikasyon an nan reveye yon travay sou yon ègzekuteur.
///
/// trait sa a ka itilize pou kreye yon [`Waker`].
/// Yon ègzèkuteur ka defini yon aplikasyon nan sa a trait, epi sèvi ak sa yo konstwi yon Waker yo pase nan travay yo ke yo egzekite sou ki ègzèkuteur.
///
/// trait sa a se yon altènatif memwa-san danje ak ergonomic pou konstwi yon [`RawWaker`].
/// Li sipòte konsepsyon ègzèkuteur komen nan ki done yo itilize yo reveye yon travay ki estoke nan yon [`Arc`].
/// Gen kèk ègzèkuteur (espesyalman sa yo pou sistèm entegre) pa ka itilize API sa a, ki se poukisa [`RawWaker`] egziste kòm yon altènativ pou sistèm sa yo.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Yon fonksyon debaz `block_on` ki pran yon future ak kouri li nan fini sou fil aktyèl la.
///
/// **Note:** Egzanp sa a echanj jistès pou senplisite.
/// Yo nan lòd yo anpeche enpas, aplikasyon pwodiksyon-klas ap bezwen tou okipe apèl entèmedyè `thread::unpark` kòm byen ke envokasyon enbrike.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Yon waker ki reveye fil aktyèl la lè yo rele li.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Kouri yon future a fini sou fil aktyèl la.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // PIN future la pou li ka vote.
///     let mut fut = Box::pin(fut);
///
///     // Kreye yon nouvo kontèks yo dwe pase nan future la.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Kouri future a fini.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Reveye travay sa a.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Reveye travay sa a san yo pa konsome waker la.
    ///
    /// Si yon ègzèkuteur sipòte yon fason pi bon mache reveye san yo pa konsome waker la, li ta dwe pase sou desizyon metòd sa a.
    /// Pa default, li klon [`Arc`] la ak apèl [`wake`] sou script la.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SEKIRITE: Sa a san danje paske raw_waker san danje konstwi
        // yon RawWaker soti nan Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Sa a se fonksyon prive pou konstwi yon RawWaker itilize, olye ke
// aliyen sa a nan `From<Arc<W>> for RawWaker` impl a, asire ke sekirite `From<Arc<W>> for Waker` pa depann de ekspedisyon ki kòrèk la trait, olye tou de impls rele fonksyon sa a dirèkteman ak klèman.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Ogmante konte referans nan ark la script li.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Reveye pa valè, k ap deplase Arc la nan fonksyon Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Reveye pa referans, vlope waker la nan ManuallyDrop pou fè pou evite jete li
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Dekline konte referans nan Arc la sou gout
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}