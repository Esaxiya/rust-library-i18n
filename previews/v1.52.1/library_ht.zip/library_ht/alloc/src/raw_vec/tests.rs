use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Ekri yon tès nan entegrasyon ant twazyèm pati allocators ak `RawVec` se yon ti kras difisil paske API la `RawVec` pa ekspoze metòd alokasyon fayib, kidonk nou pa ka tcheke sa k ap pase lè alokatè a fin itilize (pi lwen pase detekte yon panic).
    //
    //
    // Olye de sa, sa a jis tcheke ke metòd yo `RawVec` fè omwen ale nan API a Allocator lè li rezève depo.
    //
    //
    //
    //
    //

    // Yon alokatè bèbè ki konsome yon kantite gaz fiks anvan tantativ alokasyon kòmanse echwe.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (lakòz yon realloc, konsa lè l sèvi avèk 50 + 150=200 inite gaz)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Premyèman, `reserve` asiyen tankou `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 se plis pase doub nan 7, se konsa `reserve` ta dwe travay tankou `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 se mwens pase mwatye nan 12, se konsa `reserve` dwe grandi exponentielle.
        // Nan moman sa a nan ekri tès sa a grandi faktè se 2, se konsa nouvo kapasite se 24, sepandan, grandi faktè nan 1.5 se OK tou.
        //
        // Pakonsekan `>= 18` nan revandike.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}