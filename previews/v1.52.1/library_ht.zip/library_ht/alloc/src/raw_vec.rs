#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Sa ki nan memwa nan nouvo yo uninitialized.
    Uninitialized,
    /// Se memwa nan nouvo garanti yo dwe zero.
    Zeroed,
}

/// Yon sèvis piblik ki ba-nivo pou plis ergonomic asiyen, reasigne, ak deallocating yon pezib nan memwa sou pil la san yo pa gen enkyete sou tout ka yo kwen ki enplike.
///
/// Kalite sa a ekselan pou bati pwòp estrikti done ou tankou Vec ak VecDeque.
/// An patikilye:
///
/// * Pwodui `Unique::dangling()` sou kalite zewo-gwosè.
/// * Pwodui `Unique::dangling()` sou alokasyon zewo-longè.
/// * Evite libere `Unique::dangling()`.
/// * Trape tout debòde nan kalkil kapasite (ankouraje yo "capacity overflow" panics).
/// * Gad kont sistèm 32-bit ki asiyen plis pase isize::MAX bytes.
/// * Gad kont debòde longè ou.
/// * Apèl `handle_alloc_error` pou alokasyon fayib.
/// * Gen yon `ptr::Unique` e konsa dot itilizatè a ak tout benefis ki gen rapò.
/// * Sèvi ak depase a retounen soti nan allocator a yo sèvi ak pi gwo kapasite a ki disponib.
///
/// Kalite sa a pa nan de tout fason enspekte memwa ke li jere.Lè tonbe li *ap* libere memwa li, men li *pa* ap eseye lage sa li yo.
/// Li se jiska itilizatè a nan `RawVec` okipe bagay sa yo reyèl *ki estoke* andedan nan yon `RawVec`.
///
/// Remake byen ke depase yon kalite zewo ki menm gwosè ak se toujou enfini, se konsa `capacity()` toujou retounen `usize::MAX`.
/// Sa vle di ke ou bezwen dwe fè atansyon lè wonn-Tripping kalite sa a ak yon `Box<[T]>`, depi `capacity()` pa pral sede longè a.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Sa egziste paske `#[unstable]` `const fn`s pa bezwen konfòme yo ak `min_const_fn` e konsa yo pa ka rele yo nan`min_const_fn`s swa.
    ///
    /// Si ou chanje `RawVec<T>::new` oswa depandans, tanpri pran swen pa prezante anyen ki ta vrèman vyole `min_const_fn`.
    ///
    /// NOTE: Nou te kapab evite Hack sa a epi tcheke konfòmite avèk kèk atribi `#[rustc_force_min_const_fn]` ki mande pou konfòmite avèk `min_const_fn` men li pa nesesèman pèmèt li rele li nan `stable(...) const fn`/kòd itilizatè ki pa pèmèt `foo` lè `#[rustc_const_unstable(feature = "foo", issue = "01234")]` prezan.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Kreye pi gwo `RawVec` posib (sou pil sistèm lan) san repati.
    /// Si `T` gen gwosè pozitif, lè sa a sa fè yon `RawVec` ak kapasite `0`.
    /// Si `T` se zewo ki menm gwosè ak, Lè sa a, li fè yon `RawVec` ak kapasite `usize::MAX`.
    /// Itil pou mete ann aplikasyon alokasyon anreta.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Kreye yon `RawVec` (sou pil sistèm lan) avèk egzakteman kapasite ak aliyman kondisyon pou yon `[T; capacity]`.
    /// Sa a ekivalan a rele `RawVec::new` lè `capacity` se `0` oswa `T` se zewo ki menm gwosè ak.
    /// Remake byen ke si `T` se zewo-gwosè sa vle di ou pral *pa* jwenn yon `RawVec` ak kapasite yo mande yo.
    ///
    /// # Panics
    ///
    /// Panics si kapasite yo mande a depase `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Avòt sou OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Tankou `with_capacity`, men garanti tanpon an zero.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rekonstitwi yon `RawVec` soti nan yon konsèy ak kapasite.
    ///
    /// # Safety
    ///
    /// `ptr` la dwe resevwa lajan (sou pil sistèm lan), epi ak `capacity` yo bay la.
    /// `capacity` la pa ka depase `isize::MAX` pou kalite gwosè.(sèlman yon enkyetid sou sistèm 32-bit).
    /// ZST vectors ka gen yon kapasite jiska `usize::MAX`.
    /// Si `ptr` ak `capacity` soti nan yon `RawVec`, lè sa a sa garanti.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Ti Vecs yo bèbè.Ale nan:
    // - 8 si gwosè a eleman se 1, paske nenpòt ki allocators pil gen chans rive nan awondi yon demann ki gen mwens pase 8 bytes omwen 8 bytes.
    //
    // - 4 si eleman yo modere gwosè (<=1 KiB).
    // - 1 otreman, pou fè pou evite gaspiye twòp espas pou Vecs trè kout.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Tankou `new`, men paramètize sou chwa a nan allocator pou `RawVec` la retounen.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` vle di "unallocated".zewo-gwosè kalite yo inyore.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Tankou `with_capacity`, men paramètize sou chwa a nan allocator pou `RawVec` la retounen.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Tankou `with_capacity_zeroed`, men paramètize sou chwa a nan allocator pou `RawVec` la retounen.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Konvèti yon `Box<[T]>` nan yon `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Konvèti tanpon an tout antye nan `Box<[MaybeUninit<T>]>` ak `len` la espesifye.
    ///
    /// Remake byen ke sa a pral kòrèkteman reconstituer nenpòt chanjman `cap` ki ka te fèt.(Gade deskripsyon kalite pou plis detay.)
    ///
    /// # Safety
    ///
    /// * `len` dwe pi gran pase oswa egal a kapasite ki pi resamman mande a, epi
    /// * `len` dwe mwens pase oswa egal a `self.capacity()`.
    ///
    /// Remake byen, ke kapasite yo mande yo ak `self.capacity()` te kapab diferan, menm jan yon allocator te kapab an jeneral lokalize epi retounen yon blòk memwa pi gran pase mande yo.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Saniti-tcheke yon mwatye nan kondisyon sekirite (nou pa ka tcheke lòt mwatye a).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Nou evite `unwrap_or_else` isit la paske li gonfle kantite lajan an nan LLVM IR pwodwi.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rekonstitwi yon `RawVec` ki soti nan yon konsèy, kapasite, ak allocator.
    ///
    /// # Safety
    ///
    /// `ptr` la dwe resevwa lajan (atravè `alloc` alokatè yo bay la), ak `capacity` yo bay la.
    /// `capacity` la pa ka depase `isize::MAX` pou kalite gwosè.
    /// (sèlman yon enkyetid sou sistèm 32-bit).
    /// ZST vectors ka gen yon kapasite jiska `usize::MAX`.
    /// Si `ptr` ak `capacity` soti nan yon `RawVec` ki te kreye via `alloc`, lè sa a sa garanti.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Jwenn yon konsèy kri nan kòmansman an nan alokasyon an.
    /// Remake byen ke sa a se `Unique::dangling()` si `capacity == 0` oswa `T` se zewo-gwosè.
    /// Nan ansyen ka a, ou dwe fè atansyon.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Vin kapasite alokasyon an.
    ///
    /// Sa a ap toujou `usize::MAX` si `T` se zewo-gwosè.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Retounen yon referans pataje nan alokatè a fè bak `RawVec` sa a.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Nou gen yon moso resevwa lajan nan memwa, pou nou ka kontoune chèk ègzekutabl jwenn layout aktyèl nou an.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Asire ke pezib la gen omwen ase espas pou kenbe eleman `len + additional` yo.
    /// Si li pa deja gen ase kapasite, yo pral reasigne ase espas plis konfòtab espas kanson jwenn amortise *O*(1) konpòtman.
    ///
    /// Ap limite konpòtman sa a si li ta nesesèman lakòz tèt li nan panic.
    ///
    /// Si `len` depase `self.capacity()`, sa ka fail aktyèlman asiyen espas yo mande a.
    /// Sa a se pa reyèlman danjere, men kòd la danjere *ou* ekri ki depann sou konpòtman an nan fonksyon sa a ka kraze.
    ///
    /// Sa a se ideyal pou mete ann aplikasyon yon operasyon esansyèl-pouse tankou `extend`.
    ///
    /// # Panics
    ///
    /// Panics si nouvo kapasite a depase `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Avòt sou OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezèv ta avòtman oswa panike si len a depase `isize::MAX` kidonk sa a san danje fè san kontwòl kounye a.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Menm jan ak `reserve`, men retounen sou erè olye pou yo panike oswa avòtman.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Asire ke pezib la gen omwen ase espas pou kenbe eleman `len + additional` yo.
    /// Si li pa deja, yo pral reasigne kantite minimòm posib pou memwa ki nesesè yo.
    /// Anjeneral sa a pral egzakteman kantite lajan an nan memwa nesesè, men nan prensip alokatè a se gratis bay tounen plis pase sa nou te mande pou yo.
    ///
    ///
    /// Si `len` depase `self.capacity()`, sa ka fail aktyèlman asiyen espas yo mande a.
    /// Sa a se pa reyèlman danjere, men kòd la danjere *ou* ekri ki depann sou konpòtman an nan fonksyon sa a ka kraze.
    ///
    /// # Panics
    ///
    /// Panics si nouvo kapasite a depase `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Avòt sou OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Menm jan ak `reserve_exact`, men retounen sou erè olye pou yo panike oswa avòtman.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Réduire alokasyon an desann nan kantite lajan an espesifye.
    /// Si kantite lajan yo bay la se 0, aktyèlman konplètman deallocates.
    ///
    /// # Panics
    ///
    /// Panics si kantite lajan yo bay la se *pi gwo* pase kapasite aktyèl la.
    ///
    /// # Aborts
    ///
    /// Avòt sou OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Retounen si tanpon an bezwen grandi pou satisfè bezwen kapasite siplemantè a.
    /// Sitou itilize pou fè inlining rezèv-apèl posib san inlining `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Metòd sa a anjeneral enstansye anpil fwa.Se konsa, nou vle li yo dwe tankou ti ke posib, amelyore konpile fwa.
    // Men, nou vle tou kòm anpil nan sa li yo dwe statik enfòmatik ke posib, fè kòd la pwodwi kouri pi vit.
    // Se poutèt sa, metòd sa a ak anpil atansyon ekri pou ke tout kòd la ki depann sou `T` se nan li, pandan ke kòm anpil nan kòd la ki pa depann sou `T` ke posib se nan fonksyon ki pa jenerik sou `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Sa a se asire pa kontèks yo rele.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Depi nou retounen yon kapasite de `usize::MAX` lè `elem_size` se
            // 0, ap resevwa isit la nesesèman vle di `RawVec` la se twòp.
            return Err(CapacityOverflow);
        }

        // Pa gen anyen nou ka reyèlman fè sou chèk sa yo, Malerezman.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Sa garanti kwasans eksponansyèl.
        // Double a pa ka debòde paske `cap <= isize::MAX` ak kalite `cap` se `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ki pa jenerik sou `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Kontrent yo sou metòd sa a yo se menm bagay la tankou sa yo ki sou `grow_amortized`, men se metòd sa a anjeneral enstansye mwens souvan se konsa li a mwens kritik.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Depi nou retounen yon kapasite de `usize::MAX` lè gwosè a kalite se
            // 0, ap resevwa isit la nesesèman vle di `RawVec` la se twòp.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ki pa jenerik sou `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Fonksyon sa a se deyò `RawVec` pou misyon pou minimize konpile fwa.Gade kòmantè ki anwo a `RawVec::grow_amortized` pou plis detay.
// (Paramèt `A` la pa enpòtan, paske kantite diferan kalite `A` yo wè nan pratik pi piti anpil pase kantite kalite `T` yo.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Tcheke pou erè a isit la pou misyon pou minimize gwosè a nan `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Alokatè a tcheke pou egalite aliyman
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Libere memwa posede pa `RawVec`*san li pa* eseye lage sa li yo.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Fonksyon santral pou manyen erè rezèv.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Nou bezwen garanti bagay sa yo:
// * Nou pa janm asiyen `> isize::MAX` objè byte-gwosè.
// * Nou pa debòde `usize::MAX` ak aktyèlman asiyen twò piti.
//
// Sou 64-ti jan nou jis bezwen tcheke pou debòde depi ap eseye asiyen `> isize::MAX` bytes pral siman febli.
// Sou 32-bit ak 16-bit nou bezwen ajoute yon gad siplemantè pou sa a nan ka nou ap kouri sou yon platfòm ki ka itilize tout 4GB nan itilizatè-espas, egzanp, PAE oswa x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Yon fonksyon santral responsab pou rapòte kapasite debòde.
// Sa a pral asire ke jenerasyon an kòd ki gen rapò ak sa yo panics se minim kòm gen nan yon sèl kote ki panics olye ke yon pakèt moun nan tout modil la.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}