//! # Rust alokasyon debaz la ak koleksyon bibliyotèk la
//!
//! Bibliyotèk sa a bay endikasyon entelijan ak koleksyon pou jere valè-atribye ba.
//!
//! Bibliyotèk sa a, tankou libcore, nòmalman pa bezwen itilize dirèkteman depi sa li re-ekspòte nan [`std` crate](../std/index.html) la.
//! Crates ki itilize atribi `#![no_std]` la sepandan pa pral tipikman depann sou `std`, se konsa yo ta itilize crate sa a olye.
//!
//! ## Valè bwat
//!
//! Kalite [`Box`] la se yon kalite konsèy entelijan.Kapab genyen yon sèl mèt kay nan yon [`Box`], ak mèt kay la ka deside mitasyon sa ki, ki ap viv sou pil la.
//!
//! Kalite sa a ka voye pami fil avèk efikasite kòm gwosè yon valè `Box` se menm bagay la kòm sa yo ki nan yon konsèy.
//! Pyebwa tankou estrikti done yo souvan bati ak bwat paske chak ne souvan gen yon sèl mèt kay, paran an.
//!
//! ## Referans konte pwent
//!
//! Kalite [`Rc`] la se yon kalite konsèy ki pa threadsafe referans ki konte pou pataje memwa nan yon fil.
//! Yon konsèy [`Rc`] vlope yon kalite, `T`, epi sèlman pèmèt aksè a `&T`, yon referans pataje.
//!
//! Kalite sa a itil lè eritye mutabilite (tankou lè l sèvi avèk [`Box`]) twò kontrent pou yon aplikasyon, epi li souvan pè ak kalite [`Cell`] oswa [`RefCell`] yo nan lòd yo pèmèt mitasyon.
//!
//!
//! ## Atomikman referans konte endikasyon
//!
//! Kalite [`Arc`] la se ekivalan threadsafe kalite [`Rc`] la.Li bay tout menm fonctionnalités nan [`Rc`], eksepte li mande pou kalite ki genyen `T` a se partajabl.
//! Anplis de sa, [`Arc<T>`][`Arc`] se tèt li sendable pandan y ap [`Rc<T>`][`Rc`] se pa.
//!
//! Kalite sa a pèmèt pou pataje aksè nan done ki genyen yo, epi li souvan pè ak primitif senkronizasyon tankou mutexes pou pèmèt mitasyon nan resous pataje.
//!
//! ## Collections
//!
//! Aplikasyon nan estrikti ki pi komen done jeneral objektif yo defini nan bibliyotèk sa a.Yo re-ekspòte nan [standard collections library](../std/collections/index.html) la.
//!
//! ## Entèfas pil
//!
//! Modil la [`alloc`](alloc/index.html) defini koòdone nan nivo ki ba alokatè a default mondyal.Li pa konpatib ak libc allocator API la.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Teknikman, sa a se yon ensèk nan rustdoc: rustdoc wè dokiman an sou blòk `#[lang = slice_alloc]` se pou `&[T]`, ki tou te gen dokiman lè l sèvi avèk karakteristik sa a nan `core`, epi li vin fache ke karakteristik-pòtay la pa pèmèt.
// Idealman, li pa ta tcheke pou pòtay la karakteristik pou dok soti nan lòt crates, men depi sa a ka sèlman parèt pou atik lang, li pa sanble vo repare.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Pèmèt tès bibliyotèk sa a

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Modil ak makro entèn itilize pa lòt modil (bezwen yo dwe enkli anvan modil lòt).
#[macro_use]
mod macros;

// Pil bay pou ba-nivo alokasyon estrateji

pub mod alloc;

// Kalite primitif lè l sèvi avèk pil ki anwo yo

// Bezwen kondisyon defini mod la soti nan `boxed.rs` pou fè pou evite kopi lang-atik yo lè bati nan tès cfg;men tou bezwen pèmèt kòd gen deklarasyon `use boxed::Box;`.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}