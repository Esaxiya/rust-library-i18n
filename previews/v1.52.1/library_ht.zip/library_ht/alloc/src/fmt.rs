//! Itilite pou fòma ak enprime `fisèl`.
//!
//! Modil sa a gen sipò pou ègzekutabl pou ekstansyon sentaks [`format!`] la.
//! Sa a se macro aplike nan du a emèt apèl nan modil sa a yo nan lòd yo fòma agiman nan ègzekutabl nan strings.
//!
//! # Usage
//!
//! Makro [`format!`] la gen entansyon abitye ak moun ki soti nan fonksyon `printf`/`fprintf` C a oswa fonksyon `str.format` Python la.
//!
//! Kèk egzanp nan ekstansyon [`format!`] yo se:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" ak dirijan zewo
//! ```
//!
//! Soti nan sa yo, ou ka wè ke agiman an premye se yon fisèl fòma.Li oblije pa du a pou sa a yo dwe yon literal fisèl;li pa kapab yon varyab pase nan (yo nan lòd yo fè validite tcheke).
//! Konpilatè a pral Lè sa a, analize fisèl la fòma ak detèmine si lis la nan agiman yo bay se apwopriye yo pase sa a fisèl fòma.
//!
//! Pou konvèti yon valè sèl nan yon fisèl, sèvi ak metòd [`to_string`] la.Sa a pral sèvi ak [`Display`] fòma trait la.
//!
//! ## Paramèt pozisyon
//!
//! Chak agiman fòma pèmèt yo presize ki agiman valè li nan referans, epi si omisyon li sipoze "the next argument".
//! Pou egzanp, fisèl la fòma `{} {} {}` ta pran twa paramèt, epi yo ta dwe fòma nan lòd la menm jan yo te bay yo.
//! Fòma `{2} {1} {0}` fisèl la, sepandan, ta fòma agiman yo nan lòd ranvèse.
//!
//! Bagay sa yo ka jwenn yon ti kras difisil yon fwa ou kòmanse melanje de kalite yo nan espesifik pozisyon.Espesifikatè "next argument" la ka panse a kòm yon iteratè sou agiman an.
//! Chak fwa yo wè yon spesifikatè "next argument", iteratè a avanse.Sa a mennen nan konpòtman tankou sa a:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iteratè entèn sou agiman an pa te avanse nan moman premye `{}` la wè, kidonk li enprime premye agiman an.Lè sa a, sou rive nan dezyèm `{}` a, iteratè a te avanse pou pi devan pou dezyèm agiman an.
//! Esansyèlman, paramèt ki klèman non agiman yo pa afekte paramèt ki pa nonmen yon agiman an tèm de espesifik pozisyon.
//!
//! Yon fisèl fòma oblije sèvi ak tout agiman li yo, otreman li se yon erè konpile-tan.Ou ka al gade nan agiman an menm plis pase yon fwa nan fisèl la fòma.
//!
//! ## Non paramèt
//!
//! Rust tèt li pa gen yon ekivalan Python-tankou nan paramèt yo te rele nan yon fonksyon, men macro la [`format!`] se yon ekstansyon sentaks ki pèmèt li ogmante paramèt yo te rele.
//! Non paramèt yo ki nan lis nan fen lis agiman an epi yo gen sentaks la:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Pou egzanp, ekspresyon sa yo [`format!`] tout itilize yo te rele agiman:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Li pa valab yo mete paramèt pozisyon (sa yo ki san non) apre agiman ki gen non.Tankou ak paramèt pozisyon, li pa valab bay paramèt yo te rele ke yo pa itilize pa fisèl la fòma.
//!
//! # Fòma Paramèt
//!
//! Chak agiman ke yo te fòma ka transfòme pa yon kantite paramèt fòma (ki koresponn ak `format_spec` nan [the syntax](#syntax)). Paramèt sa yo afekte reprezantasyon fisèl sa k ap fòma a.
//!
//! ## Width
//!
//! ```
//! // Tout moun sa yo "Hello x !" ekri an lèt detache
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Sa a se yon paramèt pou "minimum width" ke fòma a ta dwe pran.
//! Si fisèl valè a pa ranpli karaktè sa a anpil, Lè sa a, yo pral padding a espesifye nan fill/alignment dwe itilize yo pran espas ki nesesè yo (gade anba a).
//!
//! Valè pou lajè a kapab tou bay kòm yon [`usize`] nan lis la nan paramèt lè yo ajoute yon `$` postfix, ki endike ke agiman an dezyèm se yon [`usize`] ki espesifye lajè a.
//!
//! An referans a yon agiman ak sentaks a dola pa afekte kontwa an "next argument", kidonk li la anjeneral yon bon lide, al gade nan agiman pa pozisyon, oswa itilize agiman yo te rele.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Karaktè ranpli si ou vle ak aliyman yo bay nòmalman nan konjonksyon avèk paramèt [`width`](#width) la.Li dwe defini anvan `width`, touswit aprè `:` la.
//! Sa a endike ke si valè a ke yo te fòma pi piti pase `width` kèk karaktè siplemantè yo pral enprime bò kote l '.
//! Konble vini nan variantes sa yo pou aliyman diferan:
//!
//! * `[fill]<` - agiman an kite-aliyen nan kolòn `width`
//! * `[fill]^` - agiman an se sant-aliyen nan kolòn `width`
//! * `[fill]>` - agiman an dwat-aliyen nan kolòn `width`
//!
//! [fill/alignment](#fillalignment) la default pou moun ki pa nimerik se yon espas ak bò gòch-aliyen.Default la pou fòma nimerik se tou yon karaktè espas, men ak dwa-aliyman.
//! Si drapo a `0` (gade anba a) espesifye pou nimerik, Lè sa a, karaktè ranpli enplisit la se `0`.
//!
//! Remake byen ke aliyman pa ka aplike pa kèk kalite.An patikilye, li pa jeneralman aplike pou `Debug` trait la.
//! Yon bon fason pou asire padding aplike se fòma opinyon ou, Lè sa a, pad sa a ki kapab lakòz fisèl jwenn pwodiksyon ou:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Bonjou Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Sa yo se tout drapo chanje konpòtman fòmatè a.
//!
//! * `+` - Sa a fèt pou kalite nimerik ak endike ke siy la ta dwe toujou enprime.Siy pozitif yo pa janm enprime pa default, epi siy negatif la sèlman enprime pa default pou `Signed` trait.
//! Drapo sa a endike ke siy ki kòrèk la (`+` oswa `-`) ta dwe toujou enprime.
//! * `-` - Kounye a pa itilize
//! * `#` - Drapo sa a endike ke yo ta dwe itilize fòm enprime "alternate" la.Fòm altène yo se:
//!     * `#?` - bèl-enprime fòma [`Debug`] la
//!     * `#x` - anvan agiman an ak yon `0x`
//!     * `#X` - anvan agiman an ak yon `0x`
//!     * `#b` - anvan agiman an ak yon `0b`
//!     * `#o` - anvan agiman an ak yon `0o`
//! * `0` - Sa a se itilize yo endike pou fòma nonb antye relatif ki padding a `width` ta dwe tou de dwe fè ak yon karaktè `0` kòm byen ke yo dwe siy-okouran.
//! Yon fòma tankou `{:08}` ta sede `00000001` pou nonb antye relatif la `1`, pandan y ap fòma a menm ta bay `-0000001` pou nonb antye relatif la `-1`.
//! Remake ke vèsyon negatif la gen yon mwens zewo pase vèsyon pozitif la.
//!         Remake byen ke zewo padding yo toujou mete apre siy lan (si genyen) ak anvan chif yo.Lè yo itilize ansanm ak drapo a `#`, yon règ ki sanble aplike: zewo padding yo eleman apre prefiks la, men anvan chif yo.
//!         Prefiks la enkli nan lajè total la.
//!
//! ## Precision
//!
//! Pou kalite ki pa nimerik, sa ka konsidere kòm yon "maximum width".
//! Si fisèl la ki kapab lakòz se pi long pase lajè sa a, Lè sa a, li se koupe desann nan sa a karaktè anpil e ke valè tronke emèt ak apwopriye `fill`, `alignment` ak `width` si sa yo paramèt yo mete.
//!
//! Pou kalite entegral, sa a se inyore.
//!
//! Pou kalite pwen k ap flote, sa endike konbyen chif apre pwen desimal la ta dwe enprime.
//!
//! Gen twa fason posib yo presize `precision` a vle:
//!
//! 1. Yon nonb antye relatif `.N`:
//!
//!    nonb antye relatif la `N` tèt li se presizyon an.
//!
//! 2. Yon nonb antye relatif oswa non ki te swiv pa `.N$` siy dola:
//!
//!    sèvi ak fòma *agiman*`N` (ki dwe yon `usize`) kòm presizyon an.
//!
//! 3. Yon asterisk `.*`:
//!
//!    `.*` vle di ke sa a `{...}` ki asosye ak *de* fòma entrain olye ke yon sèl: opinyon nan premye kenbe `usize` presizyon an, ak dezyèm lan kenbe valè a enprime.
//!    Remake byen ke nan ka sa a, si yon sèl sèvi ak fòma `{<arg>:<spec>.*}` a fisèl, Lè sa a, pati nan `<arg>` refere a* valè a * enprime, ak `precision` a dwe vini nan opinyon ki vini anvan `<arg>`.
//!
//! Pou egzanp, apèl sa yo tout enprime menm bagay la `Hello x is 0.01000`:
//!
//! ```
//! // Bonjou {arg 0 ("x")} se {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Bonjou {arg 1 ("x")} se {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Bonjou {arg 0 ("x")} se {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Bonjou {next arg ("x")} se {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Bonjou {next arg ("x")} se {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Bonjou {next arg ("x")} se {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Pandan ke sa yo:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! enprime twa bagay siyifikativman diferan:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Nan kèk lang pwogramasyon, konpòtman fonksyon fòma fisèl la depann de anviwònman lokal sistèm operasyon an.
//! Fonksyon fòma yo bay nan bibliyotèk estanda Rust a pa gen okenn konsèp nan lokalite epi yo pral pwodwi rezilta yo menm sou tout sistèm kèlkeswa konfigirasyon itilizatè.
//!
//! Pou egzanp, kòd sa a ap toujou enprime `1.5` menm si lokalizasyon sistèm lan itilize yon separatè desimal lòt pase yon pwen.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Karaktè literal `{` ak `}` yo ka enkli nan yon fisèl pa anvan yo ak karaktè a menm.Pou egzanp, karaktè `{` la sove ak `{{` epi karaktè `}` la sove ak `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Pou rezime, isit la ou ka jwenn gramè konplè nan strings fòma.
//! Sentaks pou langaj fòma yo itilize a soti nan lòt lang, kidonk li pa ta dwe twò etranje.Agiman yo fòma ak sentaks Python-tankou, sa vle di ke agiman yo antoure pa `{}` olye pou yo C-tankou `%` la.
//! Gramè aktyèl la pou sentaks fòma a se:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Nan gramè ki anwo a, `text` pa ka gen okenn karaktè `'{'` oswa `'}'`.
//!
//! # Fòma traits
//!
//! Lè w mande pou yon agiman fòma ak yon kalite patikilye, ou aktyèlman ap mande pou yon agiman atribiye a yon trait patikilye.
//! Sa pèmèt plizyè kalite aktyèl fòma via `{:x}` (tankou [`i8`] osi byen ke [`isize`]).Kat aktyèl la nan kalite traits se:
//!
//! * *anyen* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] ak miniskil nonb antye relatif ekzadesimal
//! * `X?` ⇒ [`Debug`] ak majiskil nonm antye antye hexadecimal
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ki sa sa vle di se ke nenpòt ki kalite agiman ki aplike [`fmt::Binary`][`Binary`] trait a ka Lè sa a, dwe fòma ak `{:b}`.Aplikasyon yo bay pou sa yo traits pou yon kantite kalite primitif pa bibliyotèk la estanda tou.
//!
//! Si pa gen okenn fòma espesifye (tankou nan `{}` oswa `{:6}`), Lè sa a, fòma trait yo itilize a se [`Display`] trait la.
//!
//! Lè w ap aplike yon fòma trait pou kalite pwòp ou a, ou pral gen aplike yon metòd nan siyati a:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // kalite koutim nou an
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Kalite ou yo pral pase kòm `self` pa-referans, ak Lè sa a, fonksyon an ta dwe emèt pwodiksyon nan kouran an `f.buf`.Li se jiska chak fòma trait aplikasyon yo kòrèkteman konfòme yo ak paramèt yo fòma mande yo.
//! Valè sa yo paramèt yo pral ki nan lis nan jaden yo nan [`Formatter`] struct la.Yo nan lòd yo ede ak sa a, struct la [`Formatter`] tou bay kèk metòd pou ede.
//!
//! Anplis de sa, valè a retounen nan fonksyon sa a se [`fmt::Result`] ki se yon kalite alyas nan [`Rezilta`]`<(),`[`std: : fmt::Erè`] `>`.
//! Fòma enplemantasyon yo ta dwe asire yo ke yo difize erè soti nan [`Formatter`] la (egzanp, lè w rele [`write!`]).
//! Sepandan, yo pa ta dwe janm retounen erè spuriously.
//! Sa vle di, yon aplikasyon fòma dwe epi li ka sèlman retounen yon erè si [`Formatter`] pase-nan retounen yon erè.
//! Sa a se paske, kontrèman ak sa siyati fonksyon an ta ka sijere, fòma fisèl se yon operasyon enfayib.
//! Fonksyon sa a sèlman retounen yon rezilta paske ekri nan kouran an kache ta ka febli epi li dwe bay yon fason yo difize lefèt ke gen yon erè ki te fèt tounen moute chemine a.
//!
//! Yon egzanp sou mete ann aplikasyon fòma traits a ta sanble:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Valè `f` aplike `Write` trait, ki se sa ekri a!macro ap tann.
//!         // Remake byen ke fòma sa a inyore drapo yo divès kalite bay fòma strings.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits diferan pèmèt diferan fòm pwodiksyon yon kalite.
//! // Siyifikasyon fòma sa a se pou enprime mayitid yon vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respekte drapo yo fòma lè l sèvi avèk metòd la èd `pad_integral` sou objè a Fòma.
//!         // Gade dokiman metòd la pou plis detay, epi yo ka itilize fonksyon `pad` pou pad kòd yo.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! De fòma traits sa yo gen rezon diferan:
//!
//! - [`fmt::Display`][`Display`] aplikasyon afime ke ka kalite a dwe fidèlman reprezante kòm yon fisèl UTF-8 nan tout tan.Li **pa** espere ke tout kalite aplike [`Display`] trait la.
//! - [`fmt::Debug`][`Debug`] aplikasyon yo ta dwe aplike pou **tout** kalite piblik yo.
//!   Sòti pral tipikman reprezante eta entèn la fidèlman ke posib.
//!   Objektif la nan [`Debug`] trait a se fasilite debogaj Rust kòd.Nan pifò ka yo, lè l sèvi avèk `#[derive(Debug)]` se ase ak rekòmande.
//!
//! Kèk egzanp nan pwodiksyon an soti nan tou de traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Makro ki gen rapò
//!
//! Gen yon nimewo nan makro ki gen rapò nan fanmi an [`format!`].Sa yo ki aktyèlman aplike yo se:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Sa a ak [`writeln!`] yo se de makro ki yo te itilize emèt fisèl la fòma nan yon kouran espesifye.Sa a se itilize yo anpeche alokasyon entèmedyè nan strings fòma ak olye dirèkteman ekri pwodiksyon an.
//! Anba kapo a, fonksyon sa a aktyèlman envoke fonksyon [`write_fmt`] ki defini sou [`std::io::Write`] trait.
//! Egzanp itilizasyon se:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Sa a ak [`println!`] emèt pwodiksyon yo nan stdout.Menm jan ak macro [`write!`] la, objektif makro sa yo se pou evite alokasyon entèmedyè lè enprime pwodiksyon an.Egzanp itilizasyon se:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makro yo [`eprint!`] ak [`eprintln!`] yo idantik ak [`print!`] ak [`println!`], respektivman, eksepte yo emèt pwodiksyon yo nan stderr.
//!
//! ### `format_args!`
//!
//! Sa a se yon macro kirye itilize san danje pase toutotou yon objè opak ki dekri fisèl la fòma.Objè sa a pa mande pou okenn alokasyon pil yo kreye, epi li sèlman referans enfòmasyon sou chemine a.
//! Anba kapo a, tout makro ki gen rapò yo aplike an tèm de sa.
//! Premye pitit, kèk egzanp l 'se:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Rezilta macro [`format_args!`] la se yon valè tip [`fmt::Arguments`].
//! Estrikti sa a ka Lè sa a, dwe pase nan fonksyon yo [`write`] ak [`format`] andedan modil sa a yo nan lòd yo travay fisèl la fòma.
//! Objektif la nan macro sa a se menm plis anpeche alokasyon entèmedyè lè fè fas ak fòma strings.
//!
//! Pou egzanp, yon bibliyotèk antre te kapab itilize estanda sentaks la fòma, men li ta intern pase alantou estrikti sa a jiskaske li te detèmine ki kote pwodiksyon yo ta dwe ale nan.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Fonksyon `format` a pran yon struct [`Arguments`] epi retounen fisèl ki kapab lakòz fòma a.
///
///
/// Ka egzanp [`Arguments`] la dwe kreye ak macro [`format_args!`] la.
///
/// # Examples
///
/// Itilizasyon debaz:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Tanpri sonje ke lè l sèvi avèk [`format!`] ta ka pi preferab.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}