//! Prelude a alloc
//!
//! Rezon ki fè modil sa a se soulaje enpòtasyon nan atik souvan itilize nan `alloc` crate la lè yo ajoute yon enpòte glob nan tèt la nan modil:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;