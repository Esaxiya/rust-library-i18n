//! APIs alokasyon memwa

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Sa yo se senbòl majik yo rele allocator mondyal la.rustc jenere yo rele `__rg_alloc` elatriye.
    // si gen yon atribi `#[global_allocator]` (kòd la agrandi ki atribi macro jenere fonksyon sa yo), oswa yo rele aplikasyon yo default nan libstd (`__rdl_alloc` elatriye.
    //
    // nan `library/std/src/alloc.rs`) otreman.
    // rustc fork nan LLVM tou espesyal-ka sa yo non fonksyon pou kapab optimize yo tankou `malloc`, `realloc`, ak `free`, respektivman.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Alokatè mondyal la memwa.
///
/// Kalite sa a aplike [`Allocator`] trait a pa voye apèl nan alokatè a ki anrejistre ak atribi `#[global_allocator]` si gen yon sèl, oswa default `std` crate la.
///
///
/// Note: pandan ke kalite sa a enstab, fonctionnalités li bay la ka jwenn aksè nan [free functions in `alloc`](self#functions) la.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Asiyen memwa ak alokatè mondyal la.
///
/// Fonksyon sa a anvwa metòd [`GlobalAlloc::alloc`] alokatè a ki anrejistre ak atribi `#[global_allocator]` la si gen youn, oswa default `std` crate la.
///
///
/// Fonksyon sa a espere yo dwe obsolèt an favè metòd la `alloc` nan kalite a [`Global`] lè li ak [`Allocator`] trait a vin estab.
///
/// # Safety
///
/// Gade [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Deallocate memwa ak allocator mondyal la.
///
/// Fonksyon sa a anvwa metòd [`GlobalAlloc::dealloc`] alokatè a ki anrejistre ak atribi `#[global_allocator]` la si gen youn, oswa default `std` crate la.
///
///
/// Fonksyon sa a espere yo dwe obsolèt an favè metòd la `dealloc` nan kalite a [`Global`] lè li ak [`Allocator`] trait a vin estab.
///
/// # Safety
///
/// Gade [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Alokasyon memwa ak alokatè mondyal la.
///
/// Fonksyon sa a anvwa metòd [`GlobalAlloc::realloc`] alokatè a ki anrejistre ak atribi `#[global_allocator]` la si gen youn, oswa default `std` crate la.
///
///
/// Fonksyon sa a espere yo dwe obsolèt an favè metòd la `realloc` nan kalite a [`Global`] lè li ak [`Allocator`] trait a vin estab.
///
/// # Safety
///
/// Gade [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Asiyen zewo-inisyalize memwa ak alokatè mondyal la.
///
/// Fonksyon sa a anvwa metòd [`GlobalAlloc::alloc_zeroed`] alokatè a ki anrejistre ak atribi `#[global_allocator]` la si gen youn, oswa default `std` crate la.
///
///
/// Fonksyon sa a espere yo dwe obsolèt an favè metòd la `alloc_zeroed` nan kalite a [`Global`] lè li ak [`Allocator`] trait a vin estab.
///
/// # Safety
///
/// Gade [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SEKIRITE: `layout` ki pa zewo nan gwosè,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SEKIRITE: Menm jan ak `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SEKIRITE: `new_size` ki pa zewo kòm `old_size` pi gran pase oswa egal a `new_size`
            // jan kondisyon sekirite yo mande sa.Lòt kondisyon yo dwe konfime pa moun kap rele a
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` pwobableman chèk pou `new_size >= old_layout.size()` oswa yon bagay ki sanble.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEKIRITE: paske `new_layout.size()` dwe pi gran pase oswa egal a `old_size`,
            // tou de ansyen ak nouvo alokasyon memwa yo valab pou li ak ekri pou `old_size` bytes.
            // Epitou, paske alokasyon an fin vye granmoun pa t 'ankò deallocated, li pa ka sipèpoze `new_ptr`.
            // Se konsa, apèl la nan `copy_nonoverlapping` an sekirite.
            // Kontra a pou `dealloc` dwe konfime pa moun kap rele a.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SEKIRITE: `layout` ki pa zewo nan gwosè,
            // lòt kondisyon yo dwe konfime pa moun kap rele a
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEKIRITE: tout kondisyon yo dwe konfime pa moun kap rele a
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEKIRITE: tout kondisyon yo dwe konfime pa moun kap rele a
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SEKIRITE: kondisyon yo dwe konfime pa moun kap rele a
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SEKIRITE: `new_size` ki pa zewo.Lòt kondisyon yo dwe konfime pa moun kap rele a
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` pwobableman chèk pou `new_size <= old_layout.size()` oswa yon bagay ki sanble.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEKIRITE: paske `new_size` dwe pi piti pase oswa egal a `old_layout.size()`,
            // tou de ansyen ak nouvo alokasyon memwa yo valab pou li ak ekri pou `new_size` bytes.
            // Epitou, paske alokasyon an fin vye granmoun pa t 'ankò deallocated, li pa ka sipèpoze `new_ptr`.
            // Se konsa, apèl la nan `copy_nonoverlapping` an sekirite.
            // Kontra a pou `dealloc` dwe konfime pa moun kap rele a.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Alokatè a pou endikasyon inik.
// Fonksyon sa a pa dwe detant.Si li fè sa, MIR codegen ap febli.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Siyati sa a dwe menm ak `Box`, sinon yon ICE pral rive.
// Lè yo ajoute yon paramèt adisyonèl nan `Box` (tankou `A: Allocator`), sa dwe ajoute isit la tou.
// Pa egzanp si `Box` chanje an `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, fonksyon sa a dwe chanje an `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` tou.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Handler erè alokasyon

extern "Rust" {
    // Sa a se senbòl la majik yo rele moun kap okipe erè mondyal la.
    // rustc jenere li yo rele `__rg_oom` si gen yon `#[alloc_error_handler]`, oswa yo rele aplikasyon yo default anba a (`__rdl_oom`) otreman.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Anile sou erè alokasyon memwa oswa echèk.
///
/// Moun ki rele APIs alokasyon memwa ki vle avòtman kalkil an repons a yon erè alokasyon yo ankouraje yo rele fonksyon sa a, olye ke dirèkteman envoke `panic!` oswa menm jan an.
///
///
/// Konpòtman default fonksyon sa a se ekri ak lèt detache yon mesaj nan erè estanda ak avòtman pwosesis la.
/// Li ka ranplase ak [`set_alloc_error_hook`] ak [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Pou alok tès `std::alloc::handle_alloc_error` ka itilize dirèkteman.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // rele atravè pwodwi `__rust_alloc_error_handler`

    // si pa gen okenn `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // si gen yon `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Espesyalize klon nan pre-resevwa lajan, uninitialized memwa.
/// Itilize pa `Box::clone` ak `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Èske w gen atribye ba *premye* ka pèmèt optimizeur a yo kreye valè a klone an plas, sote lokal la yo epi li deplase.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Nou ka toujou kopye an plas, san nou pa janm enplike yon valè lokal.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}