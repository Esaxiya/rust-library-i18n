use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Aksyon moute yon ne petèt underfull pa fusion ak oswa vòlè nan men yon frè ak sè.
    /// Si siksè men nan pri a nan réduction ne paran an, retounen sa retresi ne paran an.
    /// Retounen yon `Err` si ne a se yon rasin vid.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Aksyon moute yon ne petèt underfull, epi si sa ki lakòz ne paran li yo retresi, aksyon moute paran an, rekursivman.
    /// Retounen `true` si li ranje pye bwa a, `false` si li pa t 'kapab paske ne a rasin te vin vid.
    ///
    /// Metòd sa a pa atann zansèt yo deja underfull sou antre ak panics si li rankontre yon zansèt vid.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Retire nivo vid sou tèt la, men kenbe yon fèy vid si tout pyebwa a vid.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Aksyon moute oswa rantre lwen nenpòt ki nœuds underfull sou fwontyè a dwa nan pye bwa an.
    /// Lòt nœuds yo, sa yo ki pa rasin lan ni yon pi dwat edge, dwe deja gen omwen eleman MIN_LEN.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// Klon simetrik `fix_right_border` la.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Stock nenpòt ki nœuds underfull sou fwontyè a dwa nan pye bwa a.
    /// Lòt nœuds yo, sa yo ki pa rasin lan ni yon pi dwat edge, yo dwe prepare pou gen jiska MIN_LEN eleman yo vòlè li.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Tcheke si timoun ki pi bon an pa plen.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Nou bezwen vòlè.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Ale pi lwen desann.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Aksyon moute timoun nan kite, an konsideran timoun nan dwa se pa underfull, ak dispozisyon yon eleman siplemantè yo ki pèmèt fusion pitit li yo nan vire san yo pa vin underfull.
    ///
    /// Retounen timoun nan kite.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` pou fè pou evite reyajiste si rantre rive nan nivo siperyè-a.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Aksyon moute timoun nan dwa, an konsideran timoun nan kite se pa underfull, ak dispozisyon yon eleman siplemantè yo ki pèmèt fusion pitit li yo nan vire san yo pa vin underfull.
    ///
    /// Retounen tout kote timoun nan dwa te fini.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` pou fè pou evite reyajiste si rantre rive nan nivo siperyè-a.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}