use core::intrinsics;
use core::mem;
use core::ptr;

/// Sa ranplase valè dèyè referans inik `v` la lè w rele fonksyon ki enpòtan an.
///
///
/// Si yon panic rive nan fèmti `change` la, tout pwosesis la ap anile.
#[allow(dead_code)] // kenbe kòm ilistrasyon ak pou itilize future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Sa a ranplase valè dèyè referans inik `v` la lè w rele fonksyon ki enpòtan an, epi retounen yon rezilta ki jwenn sou wout la.
///
///
/// Si yon panic rive nan fèmti `change` la, tout pwosesis la ap anile.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}