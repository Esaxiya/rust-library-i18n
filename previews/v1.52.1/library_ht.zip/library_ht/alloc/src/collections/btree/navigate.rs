use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Tanporèman pran yon lòt, imuiabl ekivalan nan seri a menm.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Jwenn kwen fèy distenk yo delimite yon seri espesifye nan yon pyebwa.
    /// Retounen swa yon pè diferan manch nan pyebwa a menm oswa yon pè opsyon vid.
    ///
    /// # Safety
    ///
    /// Sòf si `BorrowType` se `Immut`, pa sèvi ak manch yo kopi ale nan menm KV a de fwa.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ekivalan a `(root1.first_leaf_edge(), root2.last_leaf_edge())` men pi efikas.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Jwenn pè a nan bor fèy delimite yon seri espesifik nan yon pye bwa.
    ///
    /// Rezilta a gen sans sèlman si pyebwa a te bay lòd pa kle, tankou pye bwa a nan yon `BTreeMap` se.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SEKIRITE: kalite prete nou an imuiabl.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Jwenn pè a nan bor fèy delimite yon pye bwa tout antye.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Divize yon referans inik nan yon pè nan fèy fèy delimite yon seri espesifye.
    /// Rezilta a se referans ki pa inik ki pèmèt (some) mitasyon, ki dwe itilize ak anpil atansyon.
    ///
    /// Rezilta a gen sans sèlman si pyebwa a te bay lòd pa kle, tankou pye bwa a nan yon `BTreeMap` se.
    ///
    ///
    /// # Safety
    /// Pa sèvi ak manch yo kopi ale nan menm KV a de fwa.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Divize yon referans inik nan yon pè nan fèy fèy delimite seri a plen nan pye bwa a.
    /// Rezilta yo se referans ki pa inik ki pèmèt mitasyon (nan valè sèlman), se konsa yo dwe itilize ak swen.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Nou kopi rasin NodeRef la isit la-nou pap janm vizite menm KV a de fwa, epi pa janm fini ak referans valè sipèpoze.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Divize yon referans inik nan yon pè nan fèy fèy delimite seri a plen nan pye bwa a.
    /// Rezilta yo se referans ki pa inik ki pèmèt twouve mitasyon destriktif, se konsa yo dwe itilize ak swen nan pli ekstrèm.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Nou kopi rasin NodeRef isit la-nou pap janm jwenn aksè nan li nan yon fason ki sipèpoze referans yo jwenn nan rasin lan.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Bay yon fèy edge manch, retounen [`Result::Ok`] ak yon manch KV vwazen an sou bò dwat la, ki se swa nan ne a fèy menm oswa nan yon ne zansèt.
    ///
    /// Si fèy edge a se youn nan dènye nan pyebwa a, retounen [`Result::Err`] ak ne rasin lan.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Bay yon fèy edge manch, retounen [`Result::Ok`] ak yon manch nan vwazen KV a sou bò gòch, ki se swa nan ne a fèy menm oswa nan yon ne zansèt.
    ///
    /// Si fèy edge la se youn nan premye nan pyebwa a, retounen [`Result::Err`] ak ne rasin lan.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Bay yon manch entèn edge, retounen [`Result::Ok`] ak yon manch nan vwazen KV sou bò dwat la, ki se swa nan menm ne entèn la oswa nan yon ne zansèt.
    ///
    /// Si edge entèn la se youn nan dènye nan pyebwa a, retounen [`Result::Err`] ak ne rasin lan.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Bay yon fèy edge manch nan yon pye bwa mouri, retounen pwochen fèy edge a sou bò dwat la, ak pè a kle-valè nan ant, ki se swa nan ne a fèy menm, nan yon ne zansèt, oswa ki pa-inexistant.
    ///
    ///
    /// Metòd sa a tou deallocates nenpòt node(s) li rive nan fen an.
    /// Sa a implique ke si pa gen okenn plis kle-valè pè egziste, rès la tout antye nan pyebwa a yo te deallocated e pa gen anyen kite retounen.
    ///
    /// # Safety
    /// edge yo bay la pa dwe te deja retounen pa tokay `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Bay yon fèy edge manch nan yon pyebwa mouri, retounen pwochen fèy edge a sou bò gòch, ak pè a kle-valè nan ant, ki se swa nan ne a fèy menm, nan yon ne zansèt, oswa ki pa-inexistant.
    ///
    ///
    /// Metòd sa a tou deallocates nenpòt node(s) li rive nan fen an.
    /// Sa a implique ke si pa gen okenn plis kle-valè pè egziste, rès la tout antye nan pyebwa a yo te deallocated e pa gen anyen kite retounen.
    ///
    /// # Safety
    /// edge yo bay la pa dwe te deja retounen pa tokay `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocates yon pil nan nœuds soti nan fèy la jiska rasin lan.
    /// Sa a se sèl fason pou deallocate rès yon pyebwa apre `deallocating_next` ak `deallocating_next_back` yo te griyote nan tou de bò pyebwa a, epi yo te frape menm edge la.
    /// Kòm li fèt sèlman yo dwe rele lè tout kle ak valè yo te retounen, pa gen okenn netwayaj fè sou nenpòt nan kle yo oswa valè.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Deplase fèy la edge manch nan pwochen fèy edge la epi retounen referans nan kle a ak valè nan ant.
    ///
    ///
    /// # Safety
    /// Dwe gen yon lòt KV nan direksyon vwayaje.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Deplase manch lan fèy edge nan fèy la anvan edge epi retounen referans a kle a ak valè nan ant.
    ///
    ///
    /// # Safety
    /// Dwe gen yon lòt KV nan direksyon vwayaje.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Deplase fèy la edge manch nan pwochen fèy edge la epi retounen referans nan kle a ak valè nan ant.
    ///
    ///
    /// # Safety
    /// Dwe gen yon lòt KV nan direksyon vwayaje.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Fè dènye sa a se pi vit, dapre referans.
        kv.into_kv_valmut()
    }

    /// Deplase fèy la edge manch nan fèy la anvan yo epi retounen referans a kle a ak valè nan ant.
    ///
    ///
    /// # Safety
    /// Dwe gen yon lòt KV nan direksyon vwayaje.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Fè dènye sa a se pi vit, dapre referans.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Deplase manch lan fèy edge nan pwochen fèy edge a epi retounen kle a ak valè nan ant, deallocating nenpòt ne kite dèyè pandan y ap kite edge ki koresponn lan nan ne paran li yo pendant.
    ///
    /// # Safety
    /// - Dwe gen yon lòt KV nan direksyon vwayaje.
    /// - Sa KV pa te deja retounen pa kontrepati `next_back_unchecked` sou nenpòt kopi manch yo te itilize pou travèse pyebwa a.
    ///
    /// Sèl fason ki san danje pou kontinye ak manch ki ajou a se konpare li, lage li, rele metòd sa a ankò sijè a kondisyon sekirite li yo, oswa rele kontrepati `next_back_unchecked` sijè a kondisyon sekirite li yo.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Deplase manch lan fèy edge nan fèy anvan edge a epi retounen kle a ak valè nan ant, deallocating nenpòt ne kite dèyè pandan y ap kite edge ki koresponn lan nan ne paran li yo pendant.
    ///
    /// # Safety
    /// - Dwe gen yon lòt KV nan direksyon vwayaje.
    /// - edge fèy sa a pa te deja retounen pa kontrepati `next_unchecked` sou nenpòt kopi manch yo te itilize pou travèse pyebwa a.
    ///
    /// Sèl fason ki san danje pou kontinye ak manch ki ajou a se konpare li, lage li, rele metòd sa a ankò sijè a kondisyon sekirite li yo, oswa rele kontrepati `next_unchecked` sijè a kondisyon sekirite li yo.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Retounen fèy gòch la edge nan oswa anba yon ne, nan lòt mo, edge a ou bezwen premye lè navige pi devan (oswa dènye lè navige bak).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Retounen fèy la pi dwat edge nan oswa anba yon ne, nan lòt mo, edge a ou bezwen dènye lè navige pi devan (oswa premye lè navige bak).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Vizite nœuds fèy ak KVs entèn yo nan lòd pou moute kle, epi tou vizite nœuds entèn kòm yon antye nan yon lòd pwofondè premye, sa vle di ke nœuds entèn anvan KVs endividyèl yo ak nœuds pitit yo.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Kalkile kantite eleman nan yon (sub) pyebwa.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Retounen fèy edge ki pi pre yon KV pou navigasyon pi devan.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Retounen fèy edge ki pi pre yon KV pou navigasyon bak.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}