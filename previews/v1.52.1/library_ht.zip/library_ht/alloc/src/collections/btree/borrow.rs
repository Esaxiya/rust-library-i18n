use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modèl yon reborrow nan kèk referans inik, lè ou konnen ke reborrow la ak tout pitit pitit li yo (sa vle di, tout endikasyon ak referans sòti nan li) pa pral itilize nenpòt ki plis nan kèk pwen, apre sa ou vle sèvi ak orijinal referans inik la ankò .
///
///
/// Chèk la prete anjeneral okipe sa a anpile nan prete pou ou, men gen kèk koule kontwòl ki akonpli sa a anpile yo twò konplike pou du a swiv.
/// Yon `DormantMutRef` pèmèt ou tcheke prete tèt ou, pandan y ap toujou eksprime nati anpile li yo, ak enkapsulasyon kòd la konsèy anvan tout koreksyon bezwen fè sa san yo pa konpòtman endefini.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Kaptire yon inik prete, epi imedyatman ranbouse li.
    /// Pou du a, lavi a nan referans nan nouvo se menm bagay la kòm lavi a nan referans orijinal la, men ou promise yo sèvi ak li pou yon peryòd ki pi kout.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SEKIRITE: nou kenbe prete a nan tout 'yon via `_marker`, epi nou ekspoze
        // sèlman referans sa a, kidonk li inik.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Retounen nan prete inik la okòmansman te kaptire.
    ///
    /// # Safety
    ///
    /// Ranbousman an dwe te fini, sa vle di, referans lan retounen pa `new` ak tout endikasyon ak referans ki sòti nan li, pa dwe itilize ankò.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SEKIRITE: pwòp kondisyon sekirite nou yo vle di referans sa a ankò inik.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;