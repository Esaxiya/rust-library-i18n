use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Yon plan pou ka egare tès aksidan ki kontwole evènman patikilye.
/// Kèk ka ka configuré pou panic nan kèk pwen.
/// Evènman yo `clone`, `drop` oswa kèk `query` anonim.
///
/// Faktori tès aksidan yo idantifye epi yo te bay lòd pa yon id, pou yo ka itilize kòm kle nan yon BTreeMap.
/// Aplikasyon an entansyonèlman itilize pa konte sou anyen ki defini nan crate a, apa de `Debug` trait la.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Kreye yon tès egare aksidan konsepsyon.`id` la detèmine lòd ak egalite nan ka yo.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Kreye yon egzanp nan yon egare tès aksidan ki anrejistre ki evènman li eksperyans ak opsyonèlman panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Retounen konbyen fwa ka egare yo te klone.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Retounen konbyen fwa ka egare a te tonbe.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Retounen konbyen fwa ka enbesil la te envoke manm `query` yo.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Gen kèk rechèch anonim, rezilta a ki deja bay yo.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}