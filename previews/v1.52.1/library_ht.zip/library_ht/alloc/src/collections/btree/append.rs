use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Mete tout pè kle-valè ki soti nan sendika a nan de iterateur monte, incrémentielle yon varyab `length` sou wout la.Lèt la fè li pi fasil pou moun kap rele a pou fè pou evite yon koule lè yon moun kap okipe gout panike.
    ///
    /// Si tou de iteratè yo pwodui menm kle a, metòd sa a lage pè a soti nan iteratè gòch la epi ajoute pè a soti nan iteratè dwat la.
    ///
    /// Si ou vle pyebwa a fini nan yon lòd estrikteman monte, tankou pou yon `BTreeMap`, tou de iteratè yo ta dwe pwodwi kle nan lòd entèdi monte, yo chak pi gran pase tout kle nan pyebwa a, ki gen ladan nenpòt kle ki deja nan pye bwa a lè antre.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Nou prepare rantre `left` ak `right` nan yon sekans klase nan tan lineyè.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Pandan se tan, nou bati yon pye bwa ki soti nan sekans la klase nan tan lineyè.
        self.bulk_push(iter, length)
    }

    /// Pouse tout pè kle-valè nan fen pyebwa a, incrémentielle yon varyab `length` sou wout la.
    /// Lèt la fè li pi fasil pou moun kap rele a pou fè pou evite yon koule lè iteratè a panike.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Repete nan tout pè kle-valè, pouse yo nan nœuds nan nivo dwat la.
        for (key, value) in iter {
            // Eseye pouse pè kle-valè nan ne fèy aktyèl la.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Pa gen espas kite, monte epi pouse la.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Jwenn yon ne ak espas kite, pouse isit la.
                                open_node = parent;
                                break;
                            } else {
                                // Monte ankò.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Nou se nan tèt la, kreye yon ne rasin nouvo ak pouse la.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Pouse pè kle-valè ak nouvo subtree dwat.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Desann sou fèy ki pi dwat la ankò.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Ogmantasyon longè chak iterasyon, asire w ke kat la gout eleman yo ajoute menm si avanse panik la iterateur.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Yon iteratè pou fusion de sekans Ranje nan yon sèl
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Si de kle yo egal, retounen pè a kle-valè soti nan sous la dwa.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}