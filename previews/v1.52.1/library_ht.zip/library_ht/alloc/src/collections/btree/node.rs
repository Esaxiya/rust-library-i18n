// Sa a se yon tantativ nan yon aplikasyon apre ideyal la
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Depi Rust pa gen aktyèlman kalite depandan ak rkursyon polymorphic, nou fè fè ak anpil nan sekirite.
//

// Yon gwo objektif nan modil sa a se pou fè pou evite konpleksite pa trete pyebwa a kòm yon jenerik jenerik (si etranj ki gen fòm) ak evite fè fas ak pi fò nan envariant yo B-Tree.
//
// Kòm sa yo, modil sa a pa pran swen si wi ou non antre yo Ranje, ki nœuds ka underfull, oswa menm sa underfull vle di.Sepandan, nou konte sou kèk envariants:
//
// - Pye bwa yo dwe gen inifòm depth/height.Sa vle di ke chak chemen desann nan yon fèy ki soti nan yon ne bay gen egzakteman menm longè a.
// - Yon ne longè `n` gen kle `n`, valè `n`, ak bor `n + 1`.
//   Sa a implique ke menm yon ne vid gen omwen yon edge.
//   Pou yon ne fèy, "having an edge" sèlman vle di nou ka idantifye yon pozisyon nan ne a, depi bor fèy yo vid epi yo pa bezwen okenn reprezantasyon done.
// Nan yon ne entèn, yon edge tou de idantifye yon pozisyon epi li gen yon konsèy nan yon ne pitit.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Reprezantasyon ki kache nan nœuds fèy ak yon pati nan reprezantasyon nœuds entèn yo.
struct LeafNode<K, V> {
    /// Nou vle Covariant nan `K` ak `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Endèks ne sa a nan etalaj `edges` ne paran an.
    /// `*node.parent.edges[node.parent_idx]` ta dwe menm bagay la kòm `node`.
    /// Sa a se sèlman garanti yo dwe inisyalize lè `parent` ki pa nil.
    parent_idx: MaybeUninit<u16>,

    /// Nimewo a nan kle ak valè sa a magazen ne.
    len: u16,

    /// Etalaj yo estoke done aktyèl la nan ne la.
    /// Se sèlman premye eleman yo `len` nan chak etalaj inisyalize ak valab.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inisyalize yon nouvo `LeafNode` an plas.
    unsafe fn init(this: *mut Self) {
        // Kòm yon politik jeneral, nou kite jaden inisyalize si yo kapab, tankou sa a ta dwe tou de yon ti kras pi vit ak pi fasil yo swiv nan Valgrind.
        //
        unsafe {
            // parent_idx, kle, ak vals yo tout MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Kreye yon nouvo bwat `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Reprezantasyon ki kache nan nœuds entèn yo.Menm jan ak `LeafNode`s, sa yo ta dwe kache dèyè`BoxedNode`s yo anpeche jete kle uninitialized ak valè.
/// Nenpòt konsèy nan yon `InternalNode` ka dirèkteman jete nan yon konsèy sou pati nan kache `LeafNode` nan ne a, sa ki pèmèt kòd yo aji sou fèy ak nœuds entèn jenerikman san yo pa gen menm tcheke ki nan de la yon konsèy ap montre nan.
///
/// Pwopriyete sa a pèmèt li itilize `repr(C)`.
///
#[repr(C)]
// gdb_providers.py itilize non kalite sa a pou entrospeksyon.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Pwent yo bay timoun yo nan ne sa a.
    /// `len + 1` nan sa yo yo konsidere kòm inisyalize ak valab, eksepte ke tou pre fen a, pandan y ap pye bwa a ki te fèt nan prete tip `Dying`, kèk nan sa yo endikasyon yo pendant.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Kreye yon nouvo bwat `InternalNode`.
    ///
    /// # Safety
    /// Yon envariant nan nœuds entèn se yo ke yo gen omwen yon inisyalize ak valab edge.
    /// Fonksyon sa a pa mete kanpe tankou yon edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Nou sèlman bezwen inisyalize done yo;bor yo se MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Yon jere, ki pa nil konsèy nan yon ne.Sa a se swa yon konsèy posede `LeafNode<K, V>` oswa yon konsèy posede `InternalNode<K, V>`.
///
/// Sepandan, `BoxedNode` pa gen okenn enfòmasyon sou kilès nan de kalite ne li aktyèlman genyen, epi, pasyèlman akòz mank enfòmasyon sa a, se pa yon kalite apa e li pa gen okenn destriktè.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Ne rasin lan nan yon pyebwa posede.
///
/// Remake byen ke sa a pa gen yon destriktè, epi yo dwe netwaye manyèlman.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Retounen yon nouvo pyebwa posede, ak pwòp ne rasin li ki okòmansman vid.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` pa dwe zewo.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mityèlman prete ne rasin lan posede.
    /// Kontrèman ak `reborrow_mut`, sa a san danje paske valè retou a pa ka itilize pou detwi rasin lan, epi pa ka gen lòt referans sou pye bwa a.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Yon ti kras mityèlman prete ne a rasin posede.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Irevèrsibl tranzisyon nan yon referans ki pèmèt traversal epi ki ofri metòd destriktif ak ti kras lòt bagay.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ajoute yon nouvo ne entèn ak yon sèl edge lonje dwèt sou ne a rasin anvan yo, ki fè nouvo ne ne a rasin, epi retounen li.
    /// Sa a ogmante wotè a pa 1 epi li se opoze a nan `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, eksepte ke nou jis bliye nou entèn kounye a:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Retire ne rasin entèn la, lè l sèvi avèk premye pitit li kòm nouvo ne rasin lan.
    /// Kòm li fèt sèlman yo dwe rele lè ne a rasin gen yon sèl timoun, pa gen okenn netwayaj fè sou nenpòt nan kle yo, valè ak lòt timoun yo.
    ///
    /// Sa a diminye wotè a pa 1 e se opoze `push_internal_level`.
    ///
    /// Mande aksè eksklizif nan objè a `Root`, men se pa nan ne a rasin;
    /// li pa pral invalid lòt manch oswa referans nan ne a rasin.
    ///
    /// Panics si pa gen okenn nivo entèn, sa vle di, si ne a rasin se yon fèy.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SEKIRITE: nou deklare yo dwe entèn yo.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SEKIRITE: nou prete `self` sèlman epi kalite prete li yo san konte.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SEKIRITE: premye edge la toujou inisyalize.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` toujou covariant nan `K` ak `V`, menm lè `BorrowType` a se `Mut`.
// Sa a se teknikman mal, men li pa ka rezilta nan nenpòt ki sekirite akòz itilizasyon entèn nan `NodeRef` paske nou rete konplètman jenerik sou `K` ak `V`.
//
// Sepandan, chak fwa yon kalite piblik vlope `NodeRef`, asire w ke li gen divèjans ki kòrèk la.
//
/// Yon referans a yon ne.
///
/// Kalite sa a gen yon kantite paramèt ki kontwole kijan li aji:
/// - `BorrowType`: Yon kalite egare ki dekri ki kalite prete epi pote yon lavi.
///    - Lè sa a se `Immut<'a>`, `NodeRef` aji apeprè tankou `&'a Node`.
///    - Lè sa a se `ValMut<'a>`, `NodeRef` aji apeprè tankou `&'a Node` ki gen rapò ak kle ak estrikti pyebwa, men tou, pèmèt anpil referans mutable nan valè nan tout pyebwa a coexist.
///    - Lè sa a se `Mut<'a>`, `NodeRef` aji apeprè tankou `&'a mut Node`, byenke insert metòd pèmèt yon konsèy mutable nan yon valè coexist.
///    - Lè sa a se `Owned`, `NodeRef` aji apeprè tankou `Box<Node>`, men li pa gen yon destriktè, epi yo dwe netwaye manyèlman.
///    - Lè sa a se `Dying`, `NodeRef` la toujou aji apeprè tankou `Box<Node>`, men li gen metòd detwi pye bwa a ti jan pa ti jan, ak metòd òdinè, pandan y ap pa make kòm danjere yo rele, ka envoke UB si yo rele mal.
///
///   Depi nenpòt `NodeRef` pèmèt navige nan pyebwa a, `BorrowType` efektivman aplike nan pye bwa a tout antye, pa sèlman nan ne nan tèt li.
/// - `K` ak `V`: Sa yo se kalite kle ak valè ki estoke nan nœuds yo.
/// - `Type`: Sa a ka `Leaf`, `Internal`, oswa `LeafOrInternal`.
/// Lè sa a se `Leaf`, pwen yo `NodeRef` nan yon ne fèy, lè sa a se `Internal` pwen yo `NodeRef` nan yon ne entèn yo, ak lè sa a se `LeafOrInternal` `NodeRef` a ta ka montre nan swa kalite ne.
///   `Type` yo rele li `NodeType` lè yo itilize li deyò `NodeRef`.
///
/// Tou de `BorrowType` ak `NodeType` mete restriksyon sou ki metòd nou aplike, esplwate sekirite kalite estatik.Gen limit nan fason nou ka aplike restriksyon sa yo:
/// - Pou chak paramèt kalite, nou ka sèlman defini yon metòd swa jenerikman oswa pou yon kalite patikilye.
/// Pou egzanp, nou pa ka defini yon metòd tankou `into_kv` jenerikman pou tout `BorrowType`, oswa yon fwa pou tout kalite ki pote yon lavi, paske nou vle li retounen referans `&'a`.
///   Se poutèt sa, nou defini li sèlman pou kalite ki pi piti `Immut<'a>`.
/// - Nou pa ka jwenn coercition implicite nan di `Mut<'a>` pou `Immut<'a>`.
///   Se poutèt sa, nou dwe klèman rele `reborrow` sou yon `NodeRef` plis pwisan yo nan lòd yo rive jwenn yon metòd tankou `into_kv`.
///
/// Tout metòd sou `NodeRef` ki retounen kèk kalite referans, swa:
/// - Pran `self` pa valè, epi retounen tout lavi ou pote pa `BorrowType`.
///   Pafwa, pou envoke tankou yon metòd, nou bezwen rele `reborrow_mut`.
/// - Pran `self` pa referans, ak (implicitly) retounen lavi referans sa a, olye pou lavi a pote pa `BorrowType`.
/// Nan fason sa a, korektè a prete garanti ke `NodeRef` a rete prete osi lontan ke yo itilize referans lan retounen.
///   Metòd yo sipòte insert pliye règ sa a pa retounen yon konsèy anvan tout koreksyon, sa vle di, yon referans san yo pa nenpòt ki lavi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Nimewo a nan nivo ke ne la ak nivo a nan fèy yo apa, yon konstan nan ne a ki pa ka antyèman dekri nan `Type`, e ke ne nan tèt li pa estoke.
    /// Nou sèlman bezwen nan magazen wotè nan ne a rasin, ak dériver wotè chak lòt ne soti nan li.
    /// Dwe zewo si `Type` se `Leaf` epi ki pa zewo si `Type` se `Internal`.
    ///
    ///
    height: usize,
    /// Konsèy nan fèy la oswa ne entèn yo.
    /// Definisyon `InternalNode` asire ke konsèy la valab swa.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Dekonpoze yon referans ne ki te chaje kòm `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ekspoze done yo nan yon ne entèn yo.
    ///
    /// Retounen yon ptr anvan tout koreksyon pou fè pou evite invalid lòt referans nan ne sa a.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SEKIRITE: kalite ne estatik la se `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Prete aksè san konte nan done yo nan yon ne entèn yo.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Jwenn longè ne a.Sa a se nimewo a nan kle oswa valè.
    /// Nimewo a nan bor se `len() + 1`.
    /// Remake byen ke, malgre yo te an sekirite, lè w rele fonksyon sa a ka gen efè segondè nan invalid referans mityèl ke kòd danjere te kreye.
    ///
    pub fn len(&self) -> usize {
        // Absoliman, nou sèlman jwenn aksè nan jaden an `len` isit la.
        // Si BorrowType se marker::ValMut, ta ka gen referans eksepsyonèl mutable nan valè ke nou pa dwe invalid.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Retounen kantite nivo ne ak fèy yo apa.
    /// Zewo wotè vle di ne a se yon fèy tèt li.
    /// Si ou imaj pyebwa ak rasin lan sou tèt, nimewo a di nan ki elevasyon ne a parèt.
    /// Si ou imaj pyebwa ak fèy sou tèt, nimewo a di ki jan segondè pye bwa a fin pi wo pase ne la.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Tanporèman pran yon lòt referans imuiabl nan ne la menm.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ekspoze pòsyon nan fèy nan nenpòt ki fèy oswa ne entèn yo.
    ///
    /// Retounen yon ptr anvan tout koreksyon pou fè pou evite invalid lòt referans nan ne sa a.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Ne a dwe valab pou omwen pòsyon LeafNode la.
        // Sa a se pa yon referans nan kalite a NodeRef paske nou pa konnen si li ta dwe inik oswa pataje.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Jwenn paran an nan ne aktyèl la.
    /// Retounen `Ok(handle)` si ne aktyèl la aktyèlman gen yon paran, kote `handle` lonje dwèt sou edge paran an ki lonje dwèt sou ne aktyèl la.
    ///
    /// Retounen `Err(self)` si ne aktyèl la pa gen okenn paran, bay tounen `NodeRef` orijinal la.
    ///
    /// Non metòd la sipoze ou pyebwa foto ak ne a rasin sou tèt.
    ///
    /// `edge.descend().ascend().unwrap()` ak `node.ascend().unwrap().descend()` ta dwe tou de, sou siksè, pa fè anyen.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Nou bezwen sèvi ak pwent anvan tout koreksyon nœuds paske, si BorrowType se marker::ValMut, ta ka gen referans eksepsyonèl mityèl nan valè ke nou pa dwe invalid.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Remake byen ke `self` dwe nonempty.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Remake byen ke `self` dwe nonempty.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Ekspoze pòsyon fèy nan nenpòt fèy oswa ne entèn nan yon pyebwa imuiabl.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SEKIRITE: pa ka gen referans ki ka chanje nan pyebwa sa a ki prete kòm `Immut`.
        unsafe { &*ptr }
    }

    /// Prete yon View nan kle yo ki estoke nan ne la.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Menm jan ak `ascend`, vin yon referans a ne paran yon ne, men tou, deallocates ne aktyèl la nan pwosesis la.
    /// Sa a an sekirite paske ne aktyèl la ap toujou aksesib malgre yo te repati.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Unsafely afime du a enfòmasyon estatik ke ne sa a se yon `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Unsafely afime nan du enfòmasyon estatik ke ne sa a se yon `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Tanporèman pran yon lòt, referans mutable nan ne la menm.Pran prekosyon nou, kòm metòd sa a trè danjere, doubl konsa depi li ka pa imedyatman parèt danjere.
    ///
    /// Paske endikasyon mutable ka Roaming nenpòt kote alantou pye bwa a, konsèy la retounen ka fasil pou itilize pou fè konsèy orijinal la pendant, soti nan limit, oswa envalid anba anpile règ prete.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) konsidere ajoute yon lòt paramèt kalite `NodeRef` ki mete restriksyon sou itilizasyon metòd navigasyon sou pwent reborrowed, anpeche sa a sekirite.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Prete aksè san konte nan pòsyon nan fèy nan nenpòt ki fèy oswa ne entèn yo.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SEKIRITE: nou gen aksè san konte tout ne a.
        unsafe { &mut *ptr }
    }

    /// Ofri aksè san konte nan pòsyon nan fèy nan nenpòt ki fèy oswa ne entèn yo.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SEKIRITE: nou gen aksè san konte tout ne a.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Prete aksè san konte nan yon eleman nan zòn nan depo kle.
    ///
    /// # Safety
    /// `index` se nan limit 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SEKIRITE: moun kap rele a pa yo pral kapab rele metòd plis sou pwòp tèt ou
        // jiskaske referans la tranch kle tonbe, menm jan nou gen aksè inik pou tout lavi a nan prete la.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Prete aksè san konte nan yon eleman oswa tranch nan zòn depo valè valè a.
    ///
    /// # Safety
    /// `index` se nan limit 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SEKIRITE: moun kap rele a pa yo pral kapab rele metòd plis sou pwòp tèt ou
        // jiskaske referans la tranch valè tonbe, menm jan nou gen aksè inik pou tout lavi a nan prete la.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Prete aksè san konte nan yon eleman oswa tranch nan zòn depo ne a pou sa edge.
    ///
    /// # Safety
    /// `index` se nan limit 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SEKIRITE: moun kap rele a pa yo pral kapab rele metòd plis sou pwòp tèt ou
        // jiskaske referans la tranch edge tonbe, menm jan nou gen aksè inik pou tout lavi a nan prete la.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Ne a gen plis pase `idx` eleman inisyalize.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Nou sèlman kreye yon referans a eleman nan yon sèl nou enterese nan, pou fè pou evite alyasman ak referans eksepsyonèl nan lòt eleman, an patikilye, moun ki retounen nan moun kap rele a nan iterasyon pi bonè.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Nou dwe fòse endikasyon etalaj gwosè paske nan Rust pwoblèm #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Prete aksè san konte longè ne a.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Mete lyen ne a nan paran li yo edge, san yo pa invalid lòt referans nan ne la.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Efase lyen rasin lan nan paran edge li yo.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Ajoute yon pè kle-valè nan fen ne la.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Chak atik retounen pa `range` se yon endèks edge valab pou ne a.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ajoute yon pè kle-valè, ak yon edge pou yo ale sou bò dwat la nan pè sa a, nan fen ne la.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Tcheke si wi ou non yon ne se yon ne `Internal` oswa yon ne `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Yon referans a yon pè kle-valè espesifik oswa edge nan yon ne.
/// Paramèt la `Node` dwe yon `NodeRef`, pandan y ap `Type` la ka swa `KV` (ki vle di yon manch sou yon pè kle-valè) oswa `Edge` (ki vle di yon manch sou yon edge).
///
/// Remake byen ke menm nœuds `Leaf` ka gen manch `Edge`.
/// Olye pou yo reprezante yon konsèy nan yon ne pitit, sa yo reprezante espas yo kote pwent timoun ta ale ant pè yo kle-valè.
/// Pou egzanp, nan yon ne ak longè 2, ta gen 3 kote edge posib, youn sou bò gòch nan ne a, youn ant de pè yo, ak yon sèl sou bò dwat la nan ne la.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Nou pa bezwen jeneralite a plen nan `#[derive(Clone)]`, kòm tan an sèlman `Node` yo pral `klone`able se lè li se yon referans imuiabl ak Se poutèt sa `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Rekipere ne a ki gen edge la oswa kle-valè pè sa a manch pwen nan.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Retounen pozisyon manch sa a nan ne a.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Kreye yon nouvo manch nan yon pè kle-valè nan `node`.
    /// Ensekirite paske moun kap rele a dwe asire ke `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Te kapab yon aplikasyon piblik nan PartialEq, men sèlman yo itilize nan modil sa a.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tanporèman pran yon lòt manch imuiabl sou menm kote a.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Nou pa ka itilize Handle::new_kv oswa Handle::new_edge paske nou pa konnen kalite nou yo
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Unsafely afime nan du enfòmasyon estatik ke ne manch lan se yon `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Tanporèman pran yon lòt, manch ki ka chanje sou menm kote a.
    /// Pran prekosyon nou, kòm metòd sa a trè danjere, doubl konsa depi li ka pa imedyatman parèt danjere.
    ///
    ///
    /// Pou plis detay, gade `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Nou pa ka itilize Handle::new_kv oswa Handle::new_edge paske nou pa konnen kalite nou yo
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Kreye yon nouvo manch nan yon edge nan `node`.
    /// Ensekirite paske moun kap rele a dwe asire ke `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Bay yon endèks edge kote nou vle insert nan yon ne plen kapasite, kalkile yon endèks KV sansib nan yon pwen fann ak ki kote fè ensèsyon an.
///
/// Objektif la nan pwen an fann se pou kle li yo ak valè fini nan yon ne paran;
/// kle yo, valè ak bor sou bò gòch la nan pwen an fann vin timoun nan kite;
/// kle yo, valè ak kwen sou bò dwat la nan pwen an fann vin timoun nan dwa.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust pwoblèm #74834 ap eseye eksplike règleman sa yo simetrik.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mete yon nouvo pè kle-valè ant pè kle-valè yo sou bò dwat ak sou bò gòch edge sa a.
    /// Metòd sa a sipoze ke gen ase espas nan ne a pou pè a nouvo anfòm.
    ///
    /// Konsèy la retounen pwen nan valè a eleman.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mete yon nouvo pè kle-valè ant pè kle-valè yo sou bò dwat ak sou bò gòch edge sa a.
    /// Metòd sa a divize ne a si pa gen ase plas.
    ///
    /// Konsèy la retounen pwen nan valè a eleman.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fikse konsèy paran an ak endèks nan ne pitit la ki lyen edge sa a.
    /// Sa a se itil lè yo te kòmann-nan nan bor chanje,
    fn correct_parent_link(self) {
        // Kreye backpointer san invalid lòt referans nan ne la.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Mete yon nouvo pè kle-valè ak yon edge ki pral ale sou bò dwat nouvo pè sa ant edge ak pè kle-valè sou bò dwat edge sa a.
    /// Metòd sa a sipoze ke gen ase espas nan ne a pou pè a nouvo anfòm.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Mete yon nouvo pè kle-valè ak yon edge ki pral ale sou bò dwat nouvo pè sa ant edge ak pè kle-valè sou bò dwat edge sa a.
    /// Metòd sa a divize ne a si pa gen ase plas.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mete yon nouvo pè kle-valè ant pè kle-valè yo sou bò dwat ak sou bò gòch edge sa a.
    /// Metòd sa a divize ne a si pa gen ase plas, epi eseye fann pòsyon an nan ne paran an rekursivman, jiskaske rasin lan rive.
    ///
    ///
    /// Si rezilta a retounen se yon `Fit`, ne manch li yo ka ne edge sa a oswa yon zansèt.
    /// Si rezilta a retounen se yon `Split`, jaden an `left` yo pral ne a rasin.
    /// Konsèy la retounen pwen nan valè a eleman.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Jwenn ne a pwente nan edge sa a.
    ///
    /// Non metòd la sipoze ou pyebwa foto ak ne a rasin sou tèt.
    ///
    /// `edge.descend().ascend().unwrap()` ak `node.ascend().unwrap().descend()` ta dwe tou de, sou siksè, pa fè anyen.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Nou bezwen sèvi ak pwent anvan tout koreksyon nœuds paske, si BorrowType se marker::ValMut, ta ka gen referans eksepsyonèl mityèl nan valè ke nou pa dwe invalid.
        // Pa gen okenn enkyetid aksè nan jaden an wotè paske se valè ki kopye.
        // Pran prekosyon nou ke, yon fwa konsèy la ne dereferenced, nou jwenn aksè etalaj la bor ak yon referans (Rust pwoblèm #73987) ak invalid nenpòt lòt referans nan oswa andedan etalaj la, yo ta dwe nenpòt ki dwe alantou.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Nou pa ka rele separe kle ak valè metòd, paske lè w rele dezyèm lan valab referans la tounen pa premye a.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Ranplase kle a ak valè ki manch lan KV refere a.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Ede enplemantasyon `split` pou yon `NodeType` patikilye, lè li pran swen done fèy yo.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Divize ne a kache an twa pati:
    ///
    /// - Se ne a tronke sèlman ki gen pè yo kle-valè sou bò gòch la nan manch sa a.
    /// - Kle a ak valè pwente nan manch sa a yo ekstrè.
    /// - Tout pè yo kle-valè sou bò dwat la nan manch sa a yo mete nan yon ne ki fèk resevwa lajan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Retire pè a kle-valè pwente nan manch sa a epi retounen li, ansanm ak edge ke pè kle-valè a tonbe.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Divize ne a kache an twa pati:
    ///
    /// - Se ne a tronke sèlman ki gen bor yo ak pè kle-valè sou bò gòch la nan manch sa a.
    /// - Kle a ak valè pwente nan manch sa a yo ekstrè.
    /// - Tout bor yo ak pè kle-valè sou bò dwat la nan manch sa a yo mete nan yon ne ki fèk resevwa lajan.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Reprezante yon sesyon pou evalye ak fè yon operasyon balanse alantou yon pè entèn kle-valè.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Chwazi yon kontèks balanse ki enplike ne la tankou yon timoun, konsa ant KV a imedyatman sou bò gòch la oswa sou bò dwat la nan ne paran an.
    /// Retounen yon `Err` si pa gen okenn paran.
    /// Panics si paran an vid.
    ///
    /// Pwefere bò gòch la, yo dwe pi bon si ne yo bay la se yon jan kanmenm underfull, sa vle di isit la sèlman ke li gen mwens eleman pase frè ak sè gòch li yo ak pase frè ak sè dwat li yo, si yo egziste.
    /// Nan ka sa a, fusion ak frè ak sè a gòch se pi vit, depi nou sèlman bezwen pou avanse pou pi N eleman ne a, olye pou yo déplacement yo sou bò dwat la ak deplase plis pase N eleman nan devan.
    /// Vòlè soti nan frè ak sè a gòch se tou tipikman pi vit, depi nou sèlman bezwen chanjman N eleman ne a sou bò dwat la, olye pou yo chanje omwen N nan eleman frè ak sè a sou bò gòch la.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Retounen si wi ou non fizyon se posib, sa vle di, si gen ase plas nan yon ne konbine KV santral la ak tou de nœuds adjasan pitit.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Fè yon rantre ak pèmèt yon fèmti deside ki sa yo retounen.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SEKIRITE: wotè nan nœuds yo te fizyone se youn anba wotè a
                // nan ne sa a edge, konsa pi wo pase zewo, se konsa yo entèn yo.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Konbine pè kle-valè paran an ak tou de nœuds pitit adjasan nan ne pitit gòch la epi retounen ne paran an retresi.
    ///
    ///
    /// Panics sof si nou `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Konbine pè kle-valè paran an ak tou de nœuds adjasan nan ne pitit gòch la epi retounen ne pitit sa a.
    ///
    ///
    /// Panics sof si nou `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Konbine pè kle-valè paran an ak tou de nœuds pitit adjasan nan ne pitit gòch la epi retounen manch edge nan ne pitit sa a kote timoun Suivi edge la te fini,
    ///
    ///
    /// Panics sof si nou `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Retire yon pè kle-valè nan timoun gòch la epi li mete l nan depo kle-valè paran an, pandan y ap pouse ansyen paran kle-valè pè a nan bon timoun nan.
    ///
    /// Retounen yon manch nan edge nan timoun nan dwa ki koresponn ak kote orijinal edge la espesifye nan `track_right_edge_idx` te fini.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Retire yon pè kle-valè nan bon timoun nan epi li mete l nan depo kle-valè paran an, pandan y ap pouse ansyen paran kle-valè pè a sou timoun gòch la.
    ///
    /// Retounen yon manch nan edge a nan timoun nan kite espesifye nan `track_left_edge_idx`, ki pa t 'deplase.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Sa a vòlè menm jan ak `steal_left` men vòlè eleman miltip nan yon fwa.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Asire w ke nou ka vòlè san danje.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Deplase done fèy yo.
            {
                // Fè plas pou eleman yo vòlè li nan timoun nan dwa.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Deplase eleman soti nan timoun nan kite a yon sèl la dwat.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Deplase pè a gòch-pi vòlè li bay paran an.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Deplase pè kle-valè paran an bay bon pitit la.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Fè plas pou kwen yo vòlè li.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Vòlè bor.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Klon simetrik `bulk_steal_left` la.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Asire w ke nou ka vòlè san danje.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Deplase done fèy yo.
            {
                // Deplase pè a dwa ki pi yo vòlè li bay paran an.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Deplase pè kle-valè paran an sou pitit gòch la.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Deplase eleman soti nan timoun nan dwa a yon sèl la kite.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Ranpli espas kote yo vòlè eleman yo te konn ye.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Vòlè bor.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Ranpli espas kote yo vòlè li te ye.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Retire nenpòt enfòmasyon estatik ki afime ke ne sa a se yon ne `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Retire nenpòt enfòmasyon estatik ki afime ke ne sa a se yon ne `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Tcheke si wi ou non ne a se yon ne `Internal` oswa yon ne `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Deplase sifiks la apre `self` soti nan yon ne nan yon lòt.`right` dwe vid.
    /// Premye edge nan `right` rete san okenn chanjman.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Rezilta ensèsyon, lè yon ne bezwen elaji pi lwen pase kapasite li yo.
pub struct SplitResult<'a, K, V, NodeType> {
    // Chanje ne nan pye bwa ki deja egziste ak eleman ak bor ki fè pati sou bò gòch `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Gen kèk kle ak valè divize, yo dwe eleman yon lòt kote.
    pub kv: (K, V),
    // Posede, san tache, nouvo ne ak eleman ak bor ki fè pati dwa `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Kit referans ne nan kalite prete sa a pèmèt travèse nan lòt ne nan pyebwa a.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal se pa needede, li k ap pase lè l sèvi avèk rezilta a nan `borrow_mut`.
        // Pa enfim traversal, epi sèlman kreye referans nouvo nan rasin, nou konnen ke chak referans nan kalite `Owned` se nan yon ne rasin.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Mete yon valè nan yon tranch eleman inisyalize ki te swiv pa yon sèl eleman inisyalize.
///
/// # Safety
/// Tranch la gen plis pase eleman `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Retire epi retounen yon valè ki soti nan yon tranch nan tout eleman inisyalize, kite dèyè yon sèl eleman fin inisyalize.
///
///
/// # Safety
/// Tranch la gen plis pase eleman `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Orè eleman yo nan yon tranch `distance` pozisyon sou bò gòch la.
///
/// # Safety
/// Tranch la gen omwen `distance` eleman.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Orè eleman yo nan yon pozisyon `distance` tranch sou bò dwat la.
///
/// # Safety
/// Tranch la gen omwen `distance` eleman.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Deplase tout valè ki sòti nan yon tranch eleman inisyalize nan yon tranch eleman inisyalize, kite dèyè `src` kòm tout inisyalize.
///
/// Travay tankou `dst.copy_from_slice(src)` men li pa egzije `T` yo dwe `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;