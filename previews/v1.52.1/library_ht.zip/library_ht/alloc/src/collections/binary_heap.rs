//! Yon keu priyorite aplike ak yon pil binè.
//!
//! Ensèsyon ak eklate eleman nan pi gwo gen *O*(log(*n*)) tan konpleksite.
//! Tcheke eleman ki pi gwo a se *O*(1).Konvèti yon vector nan yon pil binè ka fè an plas, e li gen *O*(*n*) konpleksite.
//! Yon pil binè kapab tou konvèti nan yon Ranje vector an plas, sa ki pèmèt li dwe itilize pou yon *O*(*n*\*log(* n*)) nan plas heapsort.
//!
//! # Examples
//!
//! Sa a se yon egzanp pi gwo ki aplike [Dijkstra's algorithm][dijkstra] yo rezoud [shortest path problem][sssp] la sou yon [directed graph][dir_graph].
//!
//! Li montre kouman yo sèvi ak [`BinaryHeap`] ak kalite koutim.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Keu priyorite a depann de `Ord`.
//! // Klèman aplike trait la pou keu a vin tounen yon min-pil olye pou yo yon max-pil.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Remake ke nou baskile kòmann-nan sou depans yo.
//!         // Nan ka yon menm kantite vòt nou konpare pozisyon, etap sa a nesesè pou fè aplikasyon `PartialEq` ak `Ord` ki konsistan.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` bezwen aplike tou.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Chak ne reprezante kòm yon `usize`, pou yon aplikasyon ki pi kout.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Pi kout algorithm Dijkstra a.
//!
//! // Kòmanse nan `start` epi sèvi ak `dist` pou swiv distans aktyèl ki pi kout la nan chak ne.Aplikasyon sa a se pa efikas memwa kòm li ka kite nœuds kopi nan nat la.
//! //
//! // Li itilize tou `usize::MAX` kòm yon valè Sentinel, pou yon aplikasyon ki pi senp.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [ne]=aktyèl pi kout distans ant `start` ak `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Nou nan `start`, ak yon pri zewo
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Egzamine fwontyè a ak pi ba pri nœuds premye (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Altènativman, nou te ka kontinye jwenn tout chemen ki pi kout yo
//!         if position == goal { return Some(cost); }
//!
//!         // Enpòtan jan nou ka deja jwenn yon pi bon fason
//!         if cost > dist[position] { continue; }
//!
//!         // Pou chak ne nou ka rive jwenn, wè si nou ka jwenn yon fason ak yon pri pi ba ale atravè tout ne sa a
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Si se konsa, ajoute li sou fwontyè a epi kontinye
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Detant, nou kounye a jwenn yon pi bon fason
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Objektif pa rive
//!     None
//! }
//!
//! fn main() {
//!     // Sa a se graf la dirije nou pral sèvi ak.
//!     // Nimewo yo ne koresponn ak eta yo diferan, ak pwa yo edge senbolize pri a pou avanse pou pi soti nan yon ne nan yon lòt.
//!     //
//!     // Remake byen ke bor yo se yon sèl-fason.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Graf la reprezante kòm yon lis adjasans kote chak endèks, ki koresponn ak yon valè ne, gen yon lis bor sortan.
//!     // Chwazi pou efikasite li yo.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nod 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nod 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Ne 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Ne 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nod 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Yon keu priyorite aplike ak yon pil binè.
///
/// Sa a pral yon max-pil.
///
/// Li se yon erè lojik pou yon atik yo dwe modifye nan yon fason ke lòd atik la relatif nan nenpòt lòt atik, jan sa detèmine pa `Ord` trait a, chanje pandan ke li se nan pil wòch la.
///
/// Sa nòmalman posib sèlman nan `Cell`, `RefCell`, eta global, I/O, oswa kòd ki pa an sekirite.
/// Konpòtman ki soti nan tankou yon erè lojik pa espesifye, men li pa pral lakòz nan konpòtman endefini.
/// Sa a ka gen ladan panics, rezilta kòrèk, avòtman, fwit memwa, ak ki pa revokasyon.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Kalite enferans pèmèt nou kite yon siyati kalite eksplisit (ki ta dwe `BinaryHeap<i32>` nan egzanp sa a).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Nou ka itilize gade vit gade pwochen atik la nan pil la.
/// // Nan ka sa a, pa gen okenn atik nan la ankò pou nou jwenn Okenn.
/// assert_eq!(heap.peek(), None);
///
/// // Ann ajoute kèk nòt ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Koulye a, gade vit montre atik ki pi enpòtan nan pil la.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Nou ka tcheke longè yon pil.
/// assert_eq!(heap.len(), 3);
///
/// // Nou ka repete sou atik yo nan pil la, byenke yo retounen yo nan yon lòd o aza.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Si nou olye pòp nòt sa yo, yo ta dwe tounen nan lòd.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Nou ka efase pil tout atik ki rete yo.
/// heap.clear();
///
/// // Pil la ta dwe kounye a vid.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Swa `std::cmp::Reverse` oswa yon aplikasyon koutim `Ord` ka itilize pou fè `BinaryHeap` yon min-pil.
/// Sa fè `heap.pop()` retounen valè ki pi piti olye pou yo pi gran an.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Vlope valè nan `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Si nou pòp nòt sa yo kounye a, yo ta dwe tounen nan lòd ranvèse a.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Tan konpleksite
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Valè pou `push` se yon pri espere;dokiman metòd la bay yon analiz pi detaye.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Estrikti anbalaj yon referans mutable nan atik la pi gran sou yon `BinaryHeap`.
///
///
/// Sa a se `struct` kreye pa metòd la [`peek_mut`] sou [`BinaryHeap`].
/// Gade dokiman li yo pou plis.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SEKIRITE: PeekMut sèlman enstansye pou pil ki pa vid.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut se sèlman enstansye pou pil ki pa vid
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut se sèlman enstansye pou pil ki pa vid
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Retire valè peeked la nan pil la epi retounen li.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Kreye yon `BinaryHeap<T>` vid.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Kreye yon `BinaryHeap` vid kòm yon max-pil.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Kreye yon `BinaryHeap` vid ak yon kapasite espesifik.
    /// Sa a preallocate ase memwa pou eleman `capacity`, se konsa ke `BinaryHeap` a pa dwe aloue jiskaske li gen omwen ke anpil valè.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Retounen yon referans ki ka chanje nan pi gwo atik ki nan pil binè a, oswa `None` si li vid.
    ///
    /// Note: Si valè `PeekMut` la fwit, pil la ka nan yon eta konsistan.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Tan konpleksite
    ///
    /// Si se atik la modifye Lè sa a, pi move ka a konpleksite tan se *O*(log(*n*)), otreman li nan *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Retire atik la pi gran soti nan pil lan binè epi retounen li, oswa `None` si li vid.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Tan konpleksite
    ///
    /// Pri ki pi mal la nan `pop` sou yon pil ki gen *n* eleman se *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SEKIRITE: !self.is_empty() vle di ke self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Pouse yon atik sou pil la binè.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Tan konpleksite
    ///
    /// Pri a espere nan `push`, mwayèn sou chak kòmann-nan posib nan eleman yo ke yo te pouse, ak sou yon ase gwo kantite pouse, se *O*(1).
    ///
    /// Sa a se pri ki pi siyifikatif metrik la lè pouse eleman ki *pa* deja nan nenpòt ki modèl Ranje.
    ///
    /// Tan konpleksite a degrade si eleman yo pouse nan lòd majorite monte.
    /// Nan ka ki pi mal la, eleman yo pouse nan moute lòd Ranje ak pri a amortize pou chak pouse se *O*(log(*n*)) kont yon pil ki gen *n* eleman.
    ///
    /// Pri ki pi mal la nan yon apèl *sèl* nan `push` se *O*(*n*).Pi move ka a rive lè kapasite fin itilize ak bezwen yon rdimansyonman.
    /// Pri a rdimansyonman te amortise nan figi yo anvan yo.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SEKIRITE: Depi nou pouse yon nouvo atik sa vle di
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Konsome `BinaryHeap` la epi retounen yon vector nan lòd (ascending) klase.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SEKIRITE: `end` ale soti nan `self.len() - 1` a 1 (tou de enkli),
            //  kidonk li toujou yon endèks valab pou jwenn aksè.
            //  Li san danje pou jwenn aksè nan endèks 0 (sa vle di `ptr`), paske
            //  1 <=fen <self.len(), ki vle di self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SEKIRITE: `end` ale soti nan `self.len() - 1` a 1 (tou de enkli) konsa:
            //  0 <1 <=fen <= self.len(), 1 <self.len() Ki vle di 0 <fen ak fen <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Aplikasyon yo nan sift_up ak sift_down sèvi ak blòk danjere yo nan lòd pou avanse pou pi yon eleman soti nan vector a (kite dèyè yon twou), chanjman ansanm lòt moun yo epi li deplase eleman nan retire tounen nan vector la nan kote final la nan twou a.
    //
    // Kalite `Hole` la itilize pou reprezante sa a, epi asire ke twou a plen tounen nan fen sijè ki abòde li yo, menm sou panic.
    // Sèvi ak yon twou diminye faktè a konstan konpare ak lè l sèvi avèk echanj, ki enplike de fwa tankou anpil mouvman.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Moun kap rele a dwe garanti ke `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Wete valè a nan `pos` epi kreye yon twou.
        // SEKIRITE: moun kap rele a garanti ke pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SEKIRITE: hole.pos()> kòmanse>=0, ki vle di hole.pos()> 0
            //  e konsa hole.pos(), 1 pa ka underflow.
            //  Sa a garanti ke paran <hole.pos() kidonk li nan yon endèks ki valab epi tou!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SEKIRITE: Menm jan ak pi wo a
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Pran yon eleman nan `pos` epi deplase li desann pil la, pandan ke pitit li yo pi gwo.
    ///
    ///
    /// # Safety
    ///
    /// Moun kap rele a dwe garanti ke `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SEKIRITE: moun kap rele a garanti ke pos <fen <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop envariant: pitit==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // konpare ak pi gwo a nan de timoun yo SEKIRITE: pitit <fen, 1 <self.len() ak timoun + 1 <fen <= self.len(), se konsa yo ap endis ki valab.
            //
            //  pitit==2 *hole.pos() + 1!= hole.pos() ak pitit + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 oswa 2* hole.pos() + 2 ka debòde si T se yon ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // si nou deja nan lòd, sispann.
            // SEKIRITE: timoun se kounye a swa timoun nan fin vye granmoun oswa timoun nan fin vye granmoun + 1
            //  Nou deja pwouve ke tou de se <self.len() ak!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SEKIRITE: menm jan ak pi wo a.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SEKIRITE: &&kout sikwi, ki vle di ke nan la
        //  dezyèm kondisyon li deja vre ke pitit==fen, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SEKIRITE: pitit deja pwouve yo dwe yon endèks ki valab ak
            //  pitit==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Moun kap rele a dwe garanti ke `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SEKIRITE: pos <len garanti pa moun kap rele a ak
        //  evidamman len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Pran yon eleman nan `pos` epi deplase li tout wout la desann pil wòch la, Lè sa a, vannen li jiska pozisyon li.
    ///
    ///
    /// Note: Sa a se pi vit lè se eleman nan li te ye yo dwe gwo/yo ta dwe pi pre anba a.
    ///
    /// # Safety
    ///
    /// Moun kap rele a dwe garanti ke `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SEKIRITE: moun kap rele a garanti ke pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop envariant: pitit==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SEKIRITE: pitit <fen, 1 <self.len() ak
            //  pitit + 1 <fen <= self.len(), kidonk yo ap endis valab.
            //  pitit==2 *hole.pos() + 1!= hole.pos() ak pitit + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 oswa 2* hole.pos() + 2 ka debòde si T se yon ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SEKIRITE: Menm jan ak pi wo a
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SEKIRITE: pitit==fen, 1 <self.len(), kidonk li se yon endèks valab
            //  ak pitit==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SEKIRITE: pos se pozisyon nan twou a e li te deja pwouve
        //  yo dwe yon endèks ki valab.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SEKIRITE: n kòmanse soti nan self.len()/2 epi li desann nan 0.
            //  Sèl ka a lè! (N <self.len()) se si self.len() ==0, men li regle pa kondisyon bouk la.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Deplase tout eleman yo nan `other` nan `self`, kite `other` vid.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` pran operasyon O(len1 + len2) ak apeprè 2 *(len1 + len2) konparezon nan ka ki pi mal la pandan y ap `extend` pran operasyon O(len2* log(len1)) ak sou 1 *len2* log_2(len1) konparezon nan ka ki pi mal la, an konsideran len1>= len2.
        // Pou pi gwo pil, pwen kwazman an pa swiv rezònman sa a epi yo te detèmine anpirikman.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Retounen yon iteratè ki rekipere eleman nan lòd pil.
    /// Eleman yo Retrieved yo retire nan pil orijinal la.
    /// Eleman ki rete yo pral retire sou gout nan lòd pil.
    ///
    /// Note:
    /// * `.drain_sorted()` se *O*(*n*\*log(* n*)); pi dousman pase `.drain()`.
    ///   Ou ta dwe itilize lèt la pou pifò ka yo.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // retire tout eleman nan lòd pil
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Kenbe sèlman eleman yo espesifye nan predikate la.
    ///
    /// Nan lòt mo, retire tout eleman `e` sa yo ki `f(&e)` retounen `false`.
    /// Eleman yo te vizite nan lòd ki pa klase (ak san presizyon).
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // sèlman kenbe nimewo menm
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Retounen yon iteratè vizite tout valè nan vector ki kache a, nan lòd abitrè.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ekri an lèt detache 1, 2, 3, 4 nan lòd abitrè
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Retounen yon iteratè ki rekipere eleman nan lòd pil.
    /// Metòd sa a konsome pil orijinal la.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Retounen pi gwo atik ki nan pil binè a, oswa `None` si li vid.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Tan konpleksite
    ///
    /// Pri a se *O*(1) nan ka ki pi mal la.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Retounen kantite eleman pil binè a ka kenbe san yo pa alokasyon.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Rezève kapasite minimòm lan pou ekzakteman `additional` plis eleman yo dwe eleman nan `BinaryHeap` yo bay la.
    /// Pa fè anyen si kapasite a deja ase.
    ///
    /// Remake byen ke alokatè a ka bay koleksyon an plis espas pase sa li mande.
    /// Se poutèt sa, kapasite pa ka konte sou yo dwe jisteman minim.
    /// Prefere [`reserve`] si future ensèsyon yo espere.
    ///
    /// # Panics
    ///
    /// Panics si nouvo kapasite a debòde `usize`.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Rezève kapasite pou omwen `additional` plis eleman yo dwe eleman nan `BinaryHeap` la.
    /// Koleksyon an ka rezève plis espas pou evite alokasyon souvan.
    ///
    /// # Panics
    ///
    /// Panics si nouvo kapasite a debòde `usize`.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Jete kapasite plis ke posib.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Jete kapasite ak yon pi ba mare.
    ///
    /// Kapasite a ap rete omwen gwo tankou tou de longè ak valè apwovizyone.
    ///
    ///
    /// Si kapasite aktyèl la se mwens pase limit ki pi ba a, sa a se yon pa gen okenn op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Konsome `BinaryHeap` la epi retounen vector ki kache nan lòd abitrè.
    ///
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Ap enprime nan kèk lòd
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Retounen longè pil binè a.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Chèk si pil binè a vid.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Efase pil binè a, retounen yon iteratè sou eleman yo retire yo.
    ///
    /// Eleman yo retire nan lòd abitrè.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Gout tout atik ki soti nan pil binè a.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Twou reprezante yon twou nan yon tranch sa vle di, yon endèks san valè valab (paske li te deplase soti nan oswa kopi).
///
/// Nan gout, `Hole` pral retabli tranch la pa ranpli pozisyon nan twou ak valè a ki te orijinèlman retire li.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Kreye yon nouvo `Hole` nan endèks `pos`.
    ///
    /// Ensekirite paske pos yo dwe nan tranch done yo.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos yo ta dwe andedan tranch la
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Retounen yon referans a eleman yo retire a.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Retounen yon referans a eleman nan `index`.
    ///
    /// Ensekirite paske endèks yo dwe nan tranch done yo epi yo pa egal a pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Deplase twou nan nouvo kote
    ///
    /// Ensekirite paske endèks yo dwe nan tranch done yo epi yo pa egal a pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // ranpli twou a ankò
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Yon iteratè sou eleman ki nan yon `BinaryHeap`.
///
/// Sa a se `struct` kreye pa [`BinaryHeap::iter()`].
/// Gade dokiman li yo pou plis.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Retire an favè `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Yon iteratè posede sou eleman ki nan yon `BinaryHeap`.
///
/// Sa a `struct` kreye pa [`BinaryHeap::into_iter()`] (ki ofri pa `IntoIterator` trait la).
/// Gade dokiman li yo pou plis.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Yon iteratè vide sou eleman ki nan yon `BinaryHeap`.
///
/// Sa a se `struct` kreye pa [`BinaryHeap::drain()`].
/// Gade dokiman li yo pou plis.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Yon iteratè vide sou eleman ki nan yon `BinaryHeap`.
///
/// Sa a se `struct` kreye pa [`BinaryHeap::drain_sorted()`].
/// Gade dokiman li yo pou plis.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Retire eleman pil nan lòd pil.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Konvèti yon `Vec<T>` nan yon `BinaryHeap<T>`.
    ///
    /// Konvèsyon sa a rive nan plas, e li gen *O*(*n*) konpleksite tan.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Konvèti yon `BinaryHeap<T>` nan yon `Vec<T>`.
    ///
    /// Konvèsyon sa a mande pou pa gen okenn mouvman done oswa alokasyon, e li gen konpleksite tan konstan.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Kreye yon iteratè konsome, se sa ki, youn ki deplase chak valè soti nan pil la binè nan lòd abitrè.
    /// Pil binè a pa ka itilize apre ou fin rele sa.
    ///
    /// # Examples
    ///
    /// Itilizasyon debaz:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ekri an lèt detache 1, 2, 3, 4 nan lòd abitrè
    /// for x in heap.into_iter() {
    ///     // x gen kalite i32, pa &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}