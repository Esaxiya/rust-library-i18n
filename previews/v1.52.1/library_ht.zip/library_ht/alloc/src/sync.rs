#![stable(feature = "rust1", since = "1.0.0")]

//! Fil-san danje referans-konte pwent.
//!
//! Gade dokiman [`Arc<T>`][Arc] la pou plis detay.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Yon limit mou sou kantite referans ki ka fèt nan yon `Arc`.
///
/// Ale pi wo pase limit sa a pral avòtman pwogram ou an (byenke pa nesesèman) nan referans _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer pa sipòte kloti memwa.
// Pou evite fo rapò pozitif nan aplikasyon Arc/fèb sèvi ak charj atomik pou senkronizasyon olye.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Yon fil-san danje referans-konte konsèy.'Arc' kanpe pou 'Referans atomik konte'.
///
/// Kalite `Arc<T>` la bay an komen pataje yon valè de kalite `T`, ki resevwa lajan nan pil la.Envoke [`clone`][clone] sou `Arc` pwodui yon nouvo egzanp `Arc`, ki lonje dwèt sou alokasyon an menm sou pil la kòm sous la `Arc`, pandan y ap ogmante yon konte referans.
/// Lè dènye konsèy `Arc` nan yon alokasyon yo detwi, valè ki estoke nan alokasyon sa a (souvan refere yo kòm "inner value") tou tonbe.
///
/// Pataje referans nan Rust refize mitasyon pa default, ak `Arc` pa gen okenn eksepsyon: ou pa ka jeneralman jwenn yon referans mutable nan yon bagay andedan yon `Arc`.Si ou bezwen mitasyon nan yon `Arc`, sèvi ak [`Mutex`][mutex], [`RwLock`][rwlock], oswa youn nan kalite [`Atomic`][atomic] yo.
///
/// ## Sekirite fil
///
/// Kontrèman ak [`Rc<T>`], `Arc<T>` itilize operasyon atomik pou konte referans li yo.Sa vle di ke li se fil-an sekirite.Dezavantaj la se ke operasyon atomik yo pi chè pase aksè memwa òdinè.Si ou pa pataje referans-konte alokasyon ant fil, konsidere lè l sèvi avèk [`Rc<T>`] pou pi ba anlè.
/// [`Rc<T>`] se yon default san danje, paske du a pral trape nenpòt tantativ voye yon [`Rc<T>`] ant fil.
/// Sepandan, yon bibliyotèk ta ka chwazi `Arc<T>` yo nan lòd yo bay konsomatè bibliyotèk plis fleksibilite.
///
/// `Arc<T>` pral aplike [`Send`] ak [`Sync`] osi lontan ke `T` a aplike [`Send`] ak [`Sync`].
/// Poukisa ou pa ka mete yon kalite ki pa fil-san danje `T` nan yon `Arc<T>` fè li fil-an sekirite?Sa a pouvwa ap yon ti jan counter-entwisyon an premye: apre tout, se pa pwen nan sekirite fil `Arc<T>`?Kle a se sa a: `Arc<T>` fè li fil an sekirite pou gen plizyè pwopriyetè menm done yo, men li pa ajoute sekirite fil nan done li yo.
///
/// Konsidere `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] se pa [`Sync`], epi si `Arc<T>` te toujou [`Send`], `Arc <` [`RefCell<T>`]`>`ta tou.
/// Men, lè sa a nou ta gen yon pwoblèm:
/// [`RefCell<T>`] se pa fil ki an sekirite;li kenbe tras nan konte a prete lè l sèvi avèk operasyon ki pa atomik.
///
/// Nan fen a, sa vle di ke ou ka bezwen pè `Arc<T>` ak kèk sòt de kalite [`std::sync`], anjeneral [`Mutex<T>`][mutex].
///
/// ## Kase sik ak `Weak`
///
/// Metòd [`downgrade`][downgrade] la ka itilize pou kreye yon konsèy [`Weak`] ki pa posede.Yon konsèy [`Weak`] ka [`ajou`][ajou] d nan yon `Arc`, men sa ap retounen [`None`] si valè ki estoke nan alokasyon an te deja tonbe.
/// Nan lòt mo, `Weak` pwent pa kenbe valè a andedan alokasyon an vivan;sepandan, yo *fè* kenbe alokasyon an (magazen an fè bak pou valè a) vivan.
///
/// Yon sik ant `Arc` endikasyon pa janm yo pral deallocated.
/// Pou rezon sa a, [`Weak`] yo itilize kraze sik.Pou egzanp, yon pye bwa te kapab gen pwent `Arc` fò soti nan nœuds paran yo bay timoun yo, ak [`Weak`] pwent soti nan timoun yo tounen nan paran yo.
///
/// # Klonaj referans
///
/// Kreye yon nouvo referans ki sòti nan yon konsèy ki deja egziste referans-konte fè lè l sèvi avèk `Clone` trait aplike pou [`Arc<T>`][Arc] ak [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // De sentaks ki anba yo ekivalan.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, ak foo se tout ark ki montre nan menm kote memwa
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` otomatikman dereferans nan `T` (via [`Deref`][deref] trait), kidonk, ou ka rele metòd `T` sou yon valè kalite `Arc<T>`.Pou evite eklatman non ak metòd `T` a, metòd `Arc<T>` tèt li se fonksyon ki asosye, ki rele lè l sèvi avèk [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Aplikasyon nan traits tankou `Clone` ka rele tou lè l sèvi avèk sentaks konplètman kalifye.
/// Gen kèk moun ki pito sèvi ak sentaks konplètman kalifye, pandan ke lòt moun pito lè l sèvi avèk sentaks metòd-rele.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sentaks Metòd-rele
/// let arc2 = arc.clone();
/// // Sentaks konplètman kalifye
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] pa oto-dereference nan `T`, paske valè enteryè a ka deja tonbe.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Pataje kèk done imuiabl ant fil:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Remake byen ke nou **pa** kouri tès sa yo isit la.
// Bòs mason yo windows jwenn super kontan si yon fil survivre fil prensipal la ak Lè sa a, sòti nan menm tan an (yon bagay enpas) Se konsa, nou jis evite sa a antyèman pa kouri tès sa yo.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Pataje yon [`AtomicUsize`] mutable:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Gade [`rc` documentation][rc_examples] la pou plis egzanp referans konte an jeneral.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` se yon vèsyon [`Arc`] ki kenbe yon referans ki pa posede nan alokasyon jere a.
/// Se alokasyon an jwenn aksè lè w rele [`upgrade`] sou konsèy la `Weak`, ki retounen yon [`Opsyon`]`<`[`Arc`] `<T>>`.
///
/// Depi yon referans `Weak` pa konte nan direksyon pou an komen, li pa pral anpeche valè a ki estoke nan alokasyon an soti nan ke yo te tonbe, ak `Weak` tèt li pa fè okenn garanti sou valè a toujou prezan.
///
/// Se konsa, li ka retounen [`None`] lè [`ajou`] d.
/// Remake sepandan ke yon referans `Weak`*fè* anpeche alokasyon nan tèt li (magazen an fè bak) nan men yo te deallocated.
///
/// Yon konsèy `Weak` itil pou kenbe yon referans tanporè sou alokasyon jere pa [`Arc`] san anpeche valè enteryè li yo te tonbe.
/// Li se tou itilize yo anpeche referans sikilè ant [`Arc`] endikasyon, depi mityèl jan mèt referans pa ta janm pèmèt swa [`Arc`] yo dwe tonbe.
/// Pou egzanp, yon pye bwa te kapab gen pwent [`Arc`] fò soti nan nœuds paran yo bay timoun yo, ak `Weak` pwent soti nan timoun yo tounen nan paran yo.
///
/// Fason tipik pou jwenn yon konsèy `Weak` se rele [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Sa a se yon `NonNull` yo ki pèmèt optimize gwosè a nan kalite sa a nan enums, men li pa nesesèman yon konsèy valab.
    //
    // `Weak::new` mete sa a `usize::MAX` konsa ke li pa bezwen asiyen espas sou pil la.
    // Sa a se pa yon valè yon konsèy reyèl ap janm genyen paske RcBox gen aliyman omwen 2.
    // Sa a se posib sèlman lè `T: Sized`;dimansyon `T` pa janm balance.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Sa a se repr(C) future-prèv kont posib jaden-reordering, ki ta entèfere ak [into|from]_raw() otreman san danje nan kalite enteryè transmutabl.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // valè usize::MAX aji kòm yon santinèl pou tanporèman "locking" kapasite pou amelyore pwent fèb yo oswa pou yo desann pi fò yo;sa a se itilize pou fè pou evite ras nan `make_mut` ak `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstwi yon nouvo `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Kòmanse konte a konsèy fèb kòm 1 ki se konsèy la fèb ki nan ki te fèt nan tout endikasyon yo fò (kinda), gade std/rc.rs pou plis enfòmasyon
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstwi yon nouvo `Arc<T>` lè l sèvi avèk yon referans fèb nan tèt li.
    /// Eseye ajou referans la fèb anvan sa a retounen fonksyon sa pral lakòz nan yon valè `None`.
    /// Sepandan, referans ki fèb la ka klone lib epi estoke pou itilize nan yon moman pita.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstwi enteryè a nan eta "uninitialized" ak yon sèl referans fèb.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Li enpòtan pou nou pa bay moute an komen nan konsèy la fèb, oswa lòt moun ka memwa a dwe libere pa `data_fn` tan an retounen.
        // Si nou reyèlman te vle pase an komen, nou ta ka kreye yon lòt konsèy fèb pou tèt nou, men sa ta lakòz dènye nouvèl adisyonèl nan konte referans fèb la ki pa ta ka nesesè otreman.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Koulye a, nou ka byen inisyalize valè enteryè a epi vire referans fèb nou an nan yon referans fò.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Pi wo a ekri nan jaden an done yo dwe vizib nan nenpòt ki fil ki obsève yon ki pa Peye-zewo konte fò.
            // Se poutèt sa nou bezwen omwen "Release" kòmann-nan yo nan lòd yo senkroniz ak `compare_exchange_weak` la nan `Weak::upgrade`.
            //
            // "Acquire" kòmann-nan pa obligatwa.
            // Lè w ap konsidere konpòtman yo posib nan `data_fn` nou sèlman bezwen gade nan sa li te kapab fè ak yon referans a yon `Weak` ki pa modènizabl:
            //
            // - Li ka *klone*`Weak` la, ogmante konte referans fèb la.
            // - Li ka lage sa yo klon, diminye konte a referans fèb (men pa janm a zewo).
            //
            // Efè segondè sa yo pa gen enpak sou nou nan okenn fason, e pa gen lòt efè segondè ki posib avèk kòd san danje pou kont li.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Bon referans ta dwe kolektivman posede yon referans pataje fèb, kidonk pa kouri destriktè a pou ansyen referans fèb nou an.
        //
        mem::forget(weak);
        strong
    }

    /// Konstwi yon nouvo `Arc` ak sa ki inisyalize.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Diferan inisyalizasyon:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstwi yon nouvo `Arc` ak sa ki inisyalize, ak memwa a ke yo te ranpli ak `0` bytes.
    ///
    ///
    /// Gade [`MaybeUninit::zeroed`][zeroed] pou egzanp sou itilizasyon kòrèk ak kòrèk nan metòd sa a.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstwi yon nouvo `Pin<Arc<T>>`.
    /// Si `T` pa aplike `Unpin`, Lè sa a, `data` pral estime nan memwa epi yo pa kapab deplase.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstwi yon nouvo `Arc<T>`, retounen yon erè si alokasyon echwe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Kòmanse konte a konsèy fèb kòm 1 ki se konsèy la fèb ki nan ki te fèt nan tout endikasyon yo fò (kinda), gade std/rc.rs pou plis enfòmasyon
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstwi yon nouvo `Arc` ak kontni inisyalize, retounen yon erè si alokasyon echwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Diferan inisyalizasyon:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstwi yon nouvo `Arc` ak sa ki inisyalize, ak memwa a ke yo te ranpli ak `0` bytes, retounen yon erè si alokasyon echwe.
    ///
    ///
    /// Gade [`MaybeUninit::zeroed`][zeroed] pou egzanp sou itilizasyon kòrèk ak kòrèk nan metòd sa a.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Retounen valè enteryè a, si `Arc` la gen egzakteman yon sèl referans fò.
    ///
    /// Sinon, se yon [`Err`] retounen ak menm `Arc` la ki te pase nan.
    ///
    ///
    /// Sa ap reyisi menm si gen referans eksepsyonèl fèb.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Fè yon konsèy fèb pou netwaye referans enplisit fò-fèb la
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstwi yon nouvo tranch referans atomik-konte ak sa ki inisyalize.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Diferan inisyalizasyon:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstwi yon nouvo tranch referans atomik-konte ak sa ki inisyalize, ak memwa a ke yo te ranpli ak `0` bytes.
    ///
    ///
    /// Gade [`MaybeUninit::zeroed`][zeroed] pou egzanp sou itilizasyon kòrèk ak kòrèk nan metòd sa a.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konvèti nan `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Menm jan ak [`MaybeUninit::assume_init`], li se jiska moun kap rele a garanti ke valè enteryè a reyèlman se nan yon eta inisyalize.
    ///
    /// Rele sa a lè kontni an se pa sa konplètman inisyalize lakòz imedya konpòtman endefini.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Diferan inisyalizasyon:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konvèti nan `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Menm jan ak [`MaybeUninit::assume_init`], li se jiska moun kap rele a garanti ke valè enteryè a reyèlman se nan yon eta inisyalize.
    ///
    /// Rele sa a lè kontni an se pa sa konplètman inisyalize lakòz imedya konpòtman endefini.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Diferan inisyalizasyon:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Konsome `Arc` la, retounen konsèy la vlope.
    ///
    /// Pou evite yon fuit memwa konsèy la dwe konvèti tounen nan yon `Arc` lè l sèvi avèk [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Bay yon konsèy kri nan done yo.
    ///
    /// Konte yo pa afekte nan okenn fason epi `Arc` la pa boule.
    /// Pointer la valab pou osi lontan ke gen konte fò nan `Arc` la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SEKIRITE: Sa a pa ka ale nan Deref::deref oswa RcBoxPtr::inner paske
        // sa a oblije kenbe raw/mut provenans tankou ke egzanp
        // `get_mut` ka ekri nan konsèy la apre Rc la refè nan `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstwi yon `Arc<T>` ki sòti nan yon konsèy anvan tout koreksyon.
    ///
    /// Konsèy la anvan tout koreksyon yo te deja retounen pa yon apèl nan [`Arc<U>::into_raw`][into_raw] kote `U` dwe gen menm gwosè ak aliyman kòm `T`.
    /// Sa a se trivial vre si `U` se `T`.
    /// Remake byen ke si `U` se pa `T` men gen menm gwosè ak aliyman, sa a se fondamantalman tankou transmutasyon referans nan diferan kalite.
    /// Gade [`mem::transmute`][transmute] pou plis enfòmasyon sou ki restriksyon ki aplike nan ka sa a.
    ///
    /// Itilizatè `from_raw` la dwe asire yon valè espesifik `T` sèlman tonbe yon fwa.
    ///
    /// Fonksyon sa a pa an sekirite paske move itilizasyon ka mennen nan memwa an sekirite, menm si `Arc<T>` retounen an pa janm jwenn aksè.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvèti tounen nan yon `Arc` pou anpeche koule.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Pli lwen apèl nan `Arc::from_raw(x_ptr)` ta dwe memwa-an sekirite.
    /// }
    ///
    /// // Te memwa a libere lè `x` soti nan sijè ki abòde pi wo a, se konsa `x_ptr` se kounye a pendant!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Ranvèse konpanse nan jwenn ArcInner orijinal la.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Kreye yon nouvo konsèy [`Weak`] pou alokasyon sa a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Sa a rilaks se OK paske nou ap tcheke valè a nan CAS ki anba a.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // tcheke si kontwa an fèb se kounye a "locked";si se konsa, vire.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: kòd sa a kounye a inyore posibilite pou debòde
            // nan usize::MAX;an jeneral tou de Rc ak Arc bezwen ajiste pou fè fas ak debòde.
            //

            // Kontrèman ak Clone(), nou bezwen sa a yo dwe yon Achte li senkroniz ak ekri a ap vini soti nan `is_unique`, se konsa ke evènman yo anvan yo ki ekri rive anvan sa a li.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Asire w ke nou pa kreye yon fèb pendant
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Jwenn kantite [`Weak`] endikasyon sa a alokasyon.
    ///
    /// # Safety
    ///
    /// Metòd sa a pou kont li an sekirite, men lè l sèvi avèk li kòrèkteman mande pou swen siplemantè.
    /// Yon lòt fil ka chanje konte a fèb nan nenpòt ki lè, ki gen ladan potansyèlman ant rele metòd sa a ak aji sou rezilta a.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Afimasyon sa a se detèminan paske nou pa te pataje `Arc` la oswa `Weak` ant fil.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Si konte ki fèb la fèmen kounye a, valè konte a te 0 jis anvan ou pran seri a.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Jwenn kantite pwent (`Arc`) fò pou alokasyon sa a.
    ///
    /// # Safety
    ///
    /// Metòd sa a pou kont li an sekirite, men lè l sèvi avèk li kòrèkteman mande pou swen siplemantè.
    /// Yon lòt fil ka chanje konte a fò nan nenpòt ki lè, ki gen ladan potansyèlman ant rele metòd sa a ak aji sou rezilta a.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Afimasyon sa a se detèminan paske nou pa te pataje `Arc` a ant fil.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Ogmante konte a referans fò sou `Arc<T>` la ki asosye ak konsèy la bay pa youn.
    ///
    /// # Safety
    ///
    /// Konsèy la dwe te jwenn nan `Arc::into_raw`, ak egzanp `Arc` ki asosye a dwe valab (sètadi
    /// konte a fò dwe omwen 1) pou dire a nan metòd sa a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Afimasyon sa a se detèminan paske nou pa te pataje `Arc` a ant fil.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Kenbe Arc, men pa manyen refcount pa vlope nan ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Koulye a, ogmante refcount, men se pa lage nouvo refcount swa
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Dekrè konte a referans fò sou `Arc<T>` la ki asosye ak konsèy la bay pa youn.
    ///
    /// # Safety
    ///
    /// Konsèy la dwe te jwenn nan `Arc::into_raw`, ak egzanp `Arc` ki asosye a dwe valab (sètadi
    /// konte a fò dwe omwen 1) lè envoke metòd sa a.
    /// Metòd sa a ka itilize pou lage `Arc` final la ak depo fè bak, men **pa ta dwe** rele apre final la `Arc` te lage.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Moun sa yo ki afimasyon yo detèminan paske nou pa te pataje `Arc` la ant fil.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ensekirite sa a ok paske pandan ke arc sa a vivan nou garanti ke konsèy enteryè a valab.
        // Anplis de sa, nou konnen ke estrikti a `ArcInner` tèt li se `Sync` paske done yo enteryè se `Sync` kòm byen, se konsa nou ap ok prè soti yon konsèy imuiabl sa yo.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Pati ki pa aliyen nan `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Detwi done yo nan moman sa a, menm si nou ka pa libere alokasyon bwat la poukont li (ka toujou gen endikasyon fèb kouche alantou).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Drop ref la fèb kolektivman ki te fèt nan tout referans fò
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Retounen `true` si de `Arc` pwen nan menm alokasyon an (nan yon venn ki sanble ak [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Asiyen yon `ArcInner<T>` ak ase espas pou yon valè enteryè petèt-gwosè kote valè a gen Layout yo bay la.
    ///
    /// Fonksyon `mem_to_arcinner` la yo rele ak konsèy la done epi yo dwe retounen tounen yon (potansyèlman grès)-pointer pou `ArcInner<T>` la.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Kalkile Layout lè l sèvi avèk Layout valè yo bay la.
        // Anvan sa, Layout te kalkile sou ekspresyon `&*(ptr as* const ArcInner<T>)`, men sa te kreye yon referans ki pa aliyen (gade #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Distribye yon `ArcInner<T>` ak ase espas pou yon valè enteryè petèt-gwosè kote valè a gen Layout la bay, retounen yon erè si alokasyon echwe.
    ///
    ///
    /// Fonksyon `mem_to_arcinner` la yo rele ak konsèy la done epi yo dwe retounen tounen yon (potansyèlman grès)-pointer pou `ArcInner<T>` la.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Kalkile Layout lè l sèvi avèk Layout valè yo bay la.
        // Anvan sa, Layout te kalkile sou ekspresyon `&*(ptr as* const ArcInner<T>)`, men sa te kreye yon referans ki pa aliyen (gade #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inisyalize ArcInner la
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Repati yon `ArcInner<T>` ak ase espas pou yon valè enteryè gwosè.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Asiyen pou `ArcInner<T>` la lè l sèvi avèk valè yo bay la.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopi valè kòm bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Gratis alokasyon an san yo pa jete sa li yo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Repati yon `ArcInner<[T]>` ak longè yo bay la.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopye eleman ki soti nan tranch nan Arc ki fèk resevwa lajan <\[T\]>
    ///
    /// Ensekirite paske moun kap rele a dwe swa pran an komen oswa mare `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstwi yon `Arc<[T]>` ki sòti nan yon iteratè li te ye yo dwe nan yon gwosè sèten.
    ///
    /// Konpòtman se endefini yo ta dwe gwosè a mal.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic gad pandan y ap klonaj eleman T.
        // Nan evènman an nan yon panic, eleman ki te ekri nan ArcInner nan nouvo yo pral tonbe, Lè sa a, memwa a libere.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer nan premye eleman
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tout klè.Bliye gad la pou li pa libere nouvo ArcInner la.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Espesyalizasyon trait itilize pou `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Fè yon script nan konsèy la `Arc`.
    ///
    /// Sa kreye yon lòt konsèy pou menm alokasyon an, ogmante konte referans fò a.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Sèvi ak yon kòmann dekontrakte se byen isit la, kòm konesans nan referans orijinal la anpeche lòt fil soti nan erè efase objè a.
        //
        // Jan yo eksplike sa nan [Boost documentation][1] la, Ogmante kontwa referans lan ka toujou fèt avèk memory_order_relaxed: Nouvo referans sou yon objè ka fòme sèlman nan yon referans ki egziste deja, epi pase yon referans ki deja egziste nan yon fil nan yon lòt dwe deja bay nenpòt senkronizasyon obligatwa.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Sepandan nou bezwen veye kont refcounts masiv nan ka yon moun se `mem: : bliye`ing ark.
        // Si nou pa fè sa konte a ka debòde ak itilizatè yo pral itilize-apre gratis.
        // Nou racily satire `isize::MAX` sou sipozisyon an ke pa gen ~2 milya dola fil incrémentiés konte a referans nan yon fwa.
        //
        // branch sa a pap janm pran nan okenn pwogram reyalis.
        //
        // Nou avòtman paske yon pwogram konsa ekstrèmman dejenere, epi nou pa pran swen sipòte li.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Fè yon referans mutable nan `Arc` yo bay la.
    ///
    /// Si gen lòt `Arc` oswa [`Weak`] endikasyon nan menm alokasyon an, Lè sa a, `make_mut` pral kreye yon nouvo alokasyon ak envoke [`clone`][clone] sou valè enteryè a asire an komen inik.
    /// Sa a se tou refere yo kòm script-sou-ekri.
    ///
    /// Remake byen ke sa a diferan de konpòtman an nan [`Rc::make_mut`] ki disasosye nenpòt ki rete `Weak` endikasyon.
    ///
    /// Gade tou [`get_mut`][get_mut], ki pral echwe olye ke klonaj.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Pa pral klone anyen
    /// let mut other_data = Arc::clone(&data); // Pa pral klone done enteryè
    /// *Arc::make_mut(&mut data) += 1;         // Klon done enteryè
    /// *Arc::make_mut(&mut data) += 1;         // Pa pral klone anyen
    /// *Arc::make_mut(&mut other_data) *= 2;   // Pa pral klone anyen
    ///
    /// // Koulye a, `data` ak `other_data` pwen nan alokasyon diferan.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Remake byen ke nou kenbe tou de yon referans fò ak yon referans fèb.
        // Se konsa, divilge referans fò nou an sèlman pa pral, pou kont li, lakòz memwa a dwe repati.
        //
        // Sèvi ak Achte asire ke nou wè nenpòt ki ekri nan `weak` ki rive anvan lage ekri (sa vle di, dekrè) nan `strong`.
        // Depi nou kenbe yon konte fèb, pa gen okenn chans ArcInner nan tèt li ta ka deallocated.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Yon lòt konsèy fò egziste, kidonk nou dwe script.
            // Pre-asiyen memwa yo ki pèmèt ekri valè a klone dirèkteman.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Rilaks sifi nan pi wo a paske sa a se fondamantalman yon optimize: nou toujou kous ak endikasyon fèb ke yo te tonbe.
            // Pi move ka a, nou fini resevwa lajan yon nouvo Arc san nesesite.
            //

            // Nou retire dènye ref la fò, men gen lòt ref ref fèb.
            // Nou pral deplase sa ki nan yon nouvo Arc, ak invalid lòt ref yo fèb.
            //

            // Remake byen ke li pa posib pou li nan `weak` bay usize::MAX (sa vle di, fèmen), depi konte a fèb ka sèlman fèmen pa yon fil ki gen yon referans fò.
            //
            //

            // Materyalize pwòp nou enplisit konsèy fèb, se konsa ke li ka netwaye ArcInner la jan sa nesesè.
            //
            let _weak = Weak { ptr: this.ptr };

            // Èske jis vòlè done yo, tout sa ki rete a se Feblès
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Nou te sèl referans nan nenpòt kalite;frape tounen konte a ref fò.
            //
            this.inner().strong.store(1, Release);
        }

        // Menm jan ak `get_mut()`, ensekirite a se ok paske referans nou an te swa inik yo kòmanse avèk yo, oswa te vin youn sou klonaj sa ki.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Retounen yon referans mutable nan `Arc` yo bay la, si pa gen okenn lòt `Arc` oswa [`Weak`] pwent nan menm alokasyon an.
    ///
    ///
    /// Retounen [`None`] otreman, paske li pa an sekirite pou mitasyon yon valè pataje.
    ///
    /// Gade tou [`make_mut`][make_mut], ki pral [`clone`][clone] valè enteryè a lè gen lòt endikasyon.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Sa a sekirite se ok paske nou ap garanti ke konsèy la retounen se *sèlman* konsèy la ki pral janm retounen nan T.
            // Konte referans nou an garanti yo dwe 1 nan pwen sa a, epi nou mande pou Arc nan tèt li yo dwe `mut`, se konsa nou ap retounen referans a sèlman posib nan done yo enteryè.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Retounen yon referans ki ka chanje nan `Arc` yo bay la, san okenn chèk.
    ///
    /// Gade tou [`get_mut`], ki san danje epi ki fè chèk apwopriye.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Nenpòt lòt `Arc` oswa [`Weak`] endikasyon nan menm alokasyon an pa dwe derereferansye pou dire a nan prete a retounen.
    ///
    /// Sa a se trivial ka a si pa gen endikasyon sa yo egziste, pou egzanp imedyatman apre `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Nou pran prekosyon *pa* kreye yon referans ki kouvri jaden yo "count", tankou sa a ta alyas ak aksè konkouran nan konte yo referans (egzanp
        // pa `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Detèmine si wi ou non sa a se referans a inik (ki gen ladan ref fèb) nan done yo kache.
    ///
    ///
    /// Remake byen ke sa a egzije pou bloke konte a ref fèb.
    fn is_unique(&mut self) -> bool {
        // fèmen konte a pwen fèb si nou parèt yo dwe sèl detantè a konsèy fèb.
        //
        // Etikèt la jwenn isit la asire yon relasyon k ap pase-anvan ak nenpòt ki ekri nan `strong` (an patikilye nan `Weak::upgrade`) anvan dekreman nan konte a `weak` (via `Weak::drop`, ki itilize lage).
        // Si modènize ref la fèb pa janm tonbe, CAS la isit la pral echwe pou nou pa pran swen senkronize.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Sa a bezwen yo dwe yon `Acquire` senkroniz ak dekresyon nan kontwa an `strong` nan `drop`-aksè a sèlman ki k ap pase lè nenpòt ki, men se referans ki sot pase a ke yo te tonbe.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Liberasyon ekri isit la senkroniz ak yon li nan `downgrade`, efektivman anpeche li pi wo a nan `strong` soti nan pase apre ekri a.
            //
            //
            self.inner().weak.store(1, Release); // lage kadna a
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Gout `Arc` la.
    ///
    /// Sa a pral dekreman konte a referans fò.
    /// Si konte a referans fò rive nan zewo Lè sa a, referans yo sèlman lòt (si genyen) yo [`Weak`], se konsa nou `drop` valè enteryè a.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Pa enprime anyen
    /// drop(foo2);   // Enprime "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Paske `fetch_sub` deja atomik, nou pa bezwen senkronize ak lòt fil sof si nou pral efase objè a.
        // Lojik sa a menm aplike a `fetch_sub` ki anba a pou konte `weak` la.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Kloti sa a nesesè yo anpeche reordering nan sèvi ak done yo ak sipresyon nan done yo.
        // Paske li make `Release`, diminye nan konte referans senkroniz ak kloti `Acquire` sa a.
        // Sa vle di ke pou sèvi ak done yo k ap pase anvan diminye konte referans lan, ki k ap pase anvan kloti sa a, ki k ap pase anvan sipresyon an nan done yo.
        //
        // Jan yo eksplike sa nan [Boost documentation][1] la,
        //
        // > Li enpòtan pou ranfòse nenpòt aksè posib pou objè a nan yon sèl
        // > fil (atravè yon referans ki egziste deja) nan *rive anvan* efase
        // > objè a nan yon fil diferan.Sa a se reyalize pa yon "release"
        // > operasyon apre jete yon referans (nenpòt aksè nan objè a
        // > atravè referans sa a dwe evidamman rive anvan), ak yon
        // > "acquire" operasyon anvan efase objè a.
        //
        // An patikilye, pandan y ap sa ki nan yon Arc yo anjeneral imuiabl, li posib gen enteryè ekri nan yon bagay tankou yon Mutex<T>.
        // Depi yon Mutex pa akeri lè li efase, nou pa ka konte sou lojik senkronizasyon li yo fè ekri nan fil A vizib nan yon destriktè kouri nan fil B.
        //
        //
        // Epitou sonje ke kloti a Acquire isit la ta ka pwobableman ranplase ak yon chaj Acquire, ki ta ka amelyore pèfòmans nan sitiyasyon trè-contended.Gade [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Eseye downcast `Arc<dyn Any + Send + Sync>` a nan yon kalite konkrè.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstwi yon nouvo `Weak<T>`, san yo pa asiyen okenn memwa.
    /// Rele [`upgrade`] sou valè retou a toujou bay [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Kalite Èd pou pèmèt jwenn aksè nan konte referans yo san yo pa fè okenn deklarasyon sou jaden done yo.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Retounen yon konsèy anvan tout koreksyon nan objè `T` la pwente pa `Weak<T>` sa a.
    ///
    /// Konsèy la valab sèlman si gen kèk referans fò.
    /// Pointer la ka pandye, san aliyen oswa menm [`null`] otreman.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Tou de pwen nan objè a menm
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Fò a isit la kenbe li vivan, pou nou ka toujou jwenn aksè nan objè a.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Men, pa plis.
    /// // Nou ka fè weak.as_ptr(), men aksè konsèy la ta mennen a konpòtman endefini.
    /// // assert_eq! ("hello", danjere {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Si konsèy la se pendant, nou retounen Sentinel la dirèkteman.
            // Sa a pa kapab yon adrès chaj ki valab, menm jan chaj la se omwen kòm aliyen kòm ArcInner (usize).
            ptr as *const T
        } else {
            // SEKIRITE: si is_dangling retounen fo, Lè sa a, konsèy la se dereferencable.
            // Ka chaj la dwe tonbe nan pwen sa a, epi nou dwe kenbe orijin, se konsa sèvi ak manipilasyon konsèy kri.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Konsome `Weak<T>` a ak vire l 'nan yon konsèy anvan tout koreksyon.
    ///
    /// Sa a konvèti konsèy la fèb nan yon konsèy anvan tout koreksyon, pandan y ap toujou prezève pwopriyetè a nan yon sèl referans fèb (konte a fèb pa modifye pa operasyon sa a).
    /// Li ka tounen tounen nan `Weak<T>` la ak [`from_raw`].
    ///
    /// Restriksyon yo menm nan aksè sib la nan konsèy la menm jan ak [`as_ptr`] aplike.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konvèti yon konsèy kri ki te deja kreye pa [`into_raw`] tounen nan `Weak<T>`.
    ///
    /// Sa a ka itilize san danje jwenn yon referans fò (lè w rele [`upgrade`] pita) oswa deallocate konte a fèb pa jete `Weak<T>` la.
    ///
    /// Li pran an komen nan yon referans fèb (eksepsyon de endikasyon ki te kreye pa [`new`], tankou sa yo pa posede anyen; metòd la toujou ap travay sou yo).
    ///
    /// # Safety
    ///
    /// Konsèy la dwe soti nan [`into_raw`] e li dwe toujou posede referans potansyèl li fèb yo.
    ///
    /// Li pèmèt pou konte a fò yo dwe 0 nan yon moman nan rele sa a.
    /// Men, sa a pran an komen nan yon referans fèb kounye a reprezante kòm yon konsèy anvan tout koreksyon (konte a fèb se pa sa modifye pa operasyon sa a) ak Se poutèt sa li dwe pè ak yon apèl anvan yo [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Dekline dènye konte ki fèb la.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Gade Weak::as_ptr pou kontèks sou kijan konsèy opinyon an sòti.

        let ptr = if is_dangling(ptr as *mut T) {
            // Sa a se yon fèb pendant.
            ptr as *mut ArcInner<T>
        } else {
            // Sinon, nou ap garanti konsèy la te soti nan yon fèb nondangling.
            // SEKIRITE: data_offset san danje yo rele, kòm referans ptr yon reyèl (potansyèlman tonbe) T.
            let offset = unsafe { data_offset(ptr) };
            // Se konsa, nou ranvèse konpanse nan jwenn RcBox an antye.
            // SEKIRITE: konsèy la soti nan yon fèb, kidonk konpanse sa a an sekirite.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEKIRITE: nou kounye a te refè konsèy orijinal la fèb, se konsa ka kreye fèb la.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Eseye ajou konsèy la `Weak` nan yon [`Arc`], retade jete nan valè enteryè a si siksè.
    ///
    ///
    /// Retounen [`None`] si valè enteryè a te tonbe depi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Detwi tout pwent fò.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Nou itilize yon bouk CAS enkreman konte a fò olye pou yo yon fetch_add kòm fonksyon sa a pa ta dwe janm pran konte a referans soti nan zewo nan yon sèl.
        //
        //
        let inner = self.inner()?;

        // Chaj rilaks paske nenpòt ki ekri nan 0 ke nou ka obsève kite jaden an nan yon eta pèmanan zewo (se konsa yon "stale" li nan 0 se amann), ak nenpòt ki lòt valè konfime atravè CAS ki anba a.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Gade kòmantè nan `Arc::clone` poukisa nou fè sa (pou `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Rilaks se amann pou ka a echèk paske nou pa gen okenn atant sou eta a nouvo.
            // Jwenn nesesè pou ka siksè senkroniz ak `Arc::new_cyclic`, lè valè enteryè a ka inisyalize apre referans `Weak` yo te deja kreye.
            // Nan ka sa a, nou espere obsève valè a konplètman inisyalize.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nil tcheke pi wo a
                Err(old) => n = old,
            }
        }
    }

    /// Jwenn kantite pwent (`Arc`) fò ki montre alokasyon sa a.
    ///
    /// Si `self` te kreye lè l sèvi avèk [`Weak::new`], sa a pral retounen 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Jwenn yon apwoksimasyon nan kantite `Weak` endikasyon montre alokasyon sa a.
    ///
    /// Si `self` te kreye lè l sèvi avèk [`Weak::new`], oswa si pa gen okenn pwent ki rete fò, sa a pral retounen 0.
    ///
    /// # Accuracy
    ///
    /// Akòz detay aplikasyon, valè a retounen ka koupe pa 1 nan nenpòt direksyon lè fil lòt yo manipile nenpòt ki `Arc` oswa`fèb`s montre nan alokasyon an menm.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Depi nou obsève ke te gen omwen yon konsèy fò apre ou fin li konte a fèb, nou konnen ke referans a enplisit fèb (prezan chak fwa nenpòt referans fò yo vivan) te toujou alantou lè nou obsève konte a fèb, epi yo ka Se poutèt sa san danje soustraksyon li.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Retounen `None` lè konsèy la se pendant epi pa gen okenn `ArcInner` resevwa lajan, (sètadi, lè sa a `Weak` te kreye pa `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Nou pran prekosyon *pa* kreye yon referans ki kouvri jaden an "data", menm jan jaden an ka mitasyon an menm tan (pou egzanp, si `Arc` ki sot pase a tonbe, jaden an done yo pral tonbe nan plas).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Retounen `true` si de pwen yo `fèb` nan menm alokasyon an (menm jan ak [`ptr::eq`]), oswa si tou de pa montre nan nenpòt ki alokasyon (paske yo te kreye ak `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Depi sa a konpare endikasyon sa vle di ke `Weak::new()` pral egal youn ak lòt, menm si yo pa lonje dwèt sou nenpòt alokasyon.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Konpare `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Fè yon script nan konsèy la `Weak` ki pwen nan alokasyon an menm.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Gade kòmantè nan Arc::clone() poukisa sa a rilaks.
        // Sa a ka itilize yon fetch_add (inyore seri a) paske se konte ki fèb sèlman fèmen kote yo *pa gen okenn lòt* endikasyon fèb nan egzistans.
        //
        // (Se konsa, nou pa ka kouri kòd sa a nan ka sa a).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Gade kòmantè nan Arc::clone() poukisa nou fè sa (pou mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstwi yon nouvo `Weak<T>`, san yo pa asiyen memwa.
    /// Rele [`upgrade`] sou valè retou a toujou bay [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Gout konsèy `Weak` la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Pa enprime anyen
    /// drop(foo);        // Enprime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Si nou jwenn ke nou te dènye konsèy la fèb, Lè sa a, li lè yo deallocate done yo antyèman.Gade diskisyon an nan Arc::drop() sou lòd yo memwa
        //
        // Li pa nesesè yo tcheke pou eta a fèmen isit la, paske ka konte a fèb sèlman ka fèmen si te gen jisteman yon sèl ref fèb, sa vle di ke gout te kapab sèlman imedyatman kouri sou ki rete ref fèb, ki ka sèlman rive apre yo fin fèmen an lage.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Nou ap fè espesyalizasyon sa a isit la, epi yo pa kòm yon optimize plis jeneral sou `&T`, paske li ta otreman ajoute yon pri nan tout chèk egalite sou ref.
/// Nou asime ke `Arc`s yo te itilize nan magazen gwo valè, ki ralanti nan script, men tou, lou yo tcheke pou egalite, sa ki lakòz pri sa a peye pi fasil.
///
/// Li la tou plis chans gen de klon `Arc`, ki pwen nan valè a menm, pase de `&T`s.
///
/// Nou ka sèlman fè sa lè `T: Eq` kòm yon `PartialEq` ta ka fè espre irefleksif.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Egalite pou de `Arc`s.
    ///
    /// De `Arc`s egal si valè enteryè yo egal, menm si yo estoke nan diferan alokasyon.
    ///
    /// Si `T` tou aplike `Eq` (impliquant refleksivite nan egalite), de `Arc`s ki pwen nan alokasyon an menm yo toujou egal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Inegalite pou de `Arc`s.
    ///
    /// De `Arc`s inegal si valè enteryè yo inegal.
    ///
    /// Si `T` tou aplike `Eq` (impliquant refleksivite nan egalite), de `Arc`s ki pwen nan valè a menm yo pa janm inegal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Konparezon pasyèl pou de `Arc`s.
    ///
    /// De yo konpare lè w rele `partial_cmp()` sou valè enteryè yo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mwens pase konparezon pou de `Arc`s.
    ///
    /// De yo konpare lè w rele `<` sou valè enteryè yo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Mwens pase oswa egal a' konparezon pou de `Arc`s.
    ///
    /// De yo konpare lè w rele `<=` sou valè enteryè yo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Pi gwo pase konparezon pou de `Arc`s.
    ///
    /// De yo konpare lè w rele `>` sou valè enteryè yo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Pi gran pase oswa egal a' konparezon pou de `Arc`s.
    ///
    /// De yo konpare lè w rele `>=` sou valè enteryè yo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Konparezon pou de `Arc`s.
    ///
    /// De yo konpare lè w rele `cmp()` sou valè enteryè yo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Kreye yon nouvo `Arc<T>`, ak valè `Default` pou `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Asiyen yon referans-konte tranch epi ranpli li pa klonaj atik `v` a.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Asiyen yon `str` referans-konte ak kopi `v` nan li.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Asiyen yon `str` referans-konte ak kopi `v` nan li.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Deplase yon objè bwat nan yon nouvo, referans-konte alokasyon.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Asiyen yon referans-konte tranch yo epi li deplase atik `v` a nan li.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Pèmèt Vec la libere memwa li, men pa detwi sa li yo
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Pran chak eleman nan `Iterator` la epi kolekte li nan yon `Arc<[T]>`.
    ///
    /// # Karakteristik pèfòmans yo
    ///
    /// ## Ka jeneral la
    ///
    /// Nan ka jeneral la, kolekte nan `Arc<[T]>` se fè pa premye kolekte nan yon `Vec<T>`.Sa vle di, lè wap ekri bagay sa yo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// sa a konpòte li tankou si nou te ekri:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Premye seri alokasyon k ap pase isit la.
    ///     .into(); // Yon dezyèm alokasyon pou `Arc<[T]>` rive isit la.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Sa a pral asiyen kòm anpil fwa jan sa nesesè pou konstwi `Vec<T>` la ak Lè sa a, li pral asiyen yon fwa pou vire `Vec<T>` la nan `Arc<[T]>` la.
    ///
    ///
    /// ## Iteratè nan longè li te ye
    ///
    /// Lè `Iterator` ou aplike `TrustedLen` epi li gen yon gwosè egzak, yo pral fè yon alokasyon sèl pou `Arc<[T]>` la.Pa egzanp:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Jis yon alokasyon sèl k ap pase isit la.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Espesyalizasyon trait itilize pou kolekte nan `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Sa a se ka a pou yon iteratè `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEKIRITE: Nou bezwen asire ke iteratè a gen yon longè egzak e nou genyen.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Retounen nan aplikasyon nòmal.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Jwenn konpanse a nan yon `ArcInner` pou chaj la dèyè yon konsèy.
///
/// # Safety
///
/// Konsèy la dwe lonje dwèt sou (epi yo gen Metadata ki valab pou) yon egzanp ki deja valab nan T, men T la pèmèt yo tonbe.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Aliman valè a gwosè nan fen ArcInner la.
    // Paske RcBox se repr(C), li ap toujou dènye jaden an nan memwa.
    // SEKIRITE: depi sèlman kalite ki pa dimansyon posib yo se tranch, objè trait,
    // ak kalite ekstèn, kondisyon sekirite opinyon an se kounye a ase pou satisfè kondisyon ki nan align_of_val_raw;sa a se yon detay aplikasyon nan lang lan ki pa ka konte sou deyò nan std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}