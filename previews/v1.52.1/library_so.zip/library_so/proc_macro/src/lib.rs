//! Maktabad taageero ah oo loogu talagalay qorayaasha makro marka la qeexayo macros cusub.
//!
//! Maktabaddu, la siiyo by qeybinta caadiga ah, waxay bixisaa noocyada ayuu ku baabba'saday ee interfaces of hannaan lagu qeexay qeexitaan Dhaqale sida function u eg-macros `#[proc_macro]`, sifooyinka Dhaqale `#[proc_macro_attribute]` iyo attributes`caadada ka imaan#[proc_macro_derive]`.
//!
//!
//! Ka eeg [the book] wixii intaa ka badan.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Go'aaminaya haddii proc_macro ayaa la sameeyay ay heli karaan barnaamijka hadda socda.
///
/// Proc_macro crate waxaa kaliya loogu talagalay in loogu isticmaalo gudaha hirgelinta macros-hawleedka.Dhammaan shaqooyinka in this crate panic haddii ka baxsan Dhaqale nidaamka ah gawraco, sida ka script dhista ama imtixaanka unit ama binary caadiga Rust.
///
/// Iyada oo la tixgelinayo maktabadaha Rust in waxaa loogu talagalay si ay u taageeraan Dhaqale iyo Xaaladaha isticmaalka non-Dhaqale labadaba, `proc_macro::is_available()` siisaa hab non-argagaxsanaayeen ah in la ogaado in kaabayaasha loo baahan yahay in la isticmaalo API ee proc_macro waa hadda la heli karo.
/// Dib run haddii gudaha ee Dhaqale nidaamka ah, been ka baryeysaan hadduu ka binary kale gawraco.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// nooca ugu weyn ee ay bixiso crate this, oo ka dhigan durdur wax aan la taaban karin ee tokens, ama, ka badan si gaar ah, isku xigxiga oo ka mid ah geedaha token.
/// Nooca bixiyaan interfaces for iterating kuwa geedaha token iyo, taas bedelkeeda, ururinta tiro ka mid ah geedaha token galay mid ka mid durdur.
///
///
/// Tani waa labadaba talooyin iyo wax soo saarka ee sharaxaadooda `#[proc_macro]`, `#[proc_macro_attribute]` iyo `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Cilad ayaa laga soo celiyey `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Sooceliyaa `TokenStream` madhan oo aan lahayn geedo token ah.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Hubinta haddii `TokenStream` ani madhan yahay.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Isku dayga ah in xarigga loo jajabiyo tokens iyo kuwa tokens loogu daro durdurka token.
/// Waxaa laga yaabaa in baaqanayaa ka tiro ka mid ah sababaha, tusaale ahaan, haddii xarig ah ku jira delimiters qaloocan ama jilayaal aan hadda jira ee luqada.
///
/// Dhamaan tokens ee kujira qulqulka qulqulka waxay helayaan `Span::call_site()` taako.
///
/// NOTE: khaladaadka qaar ayaa sababi kara panics halkii laga celin lahaa `LexError`.Waxaan xaq u leenahay inaan ku beddelno khaladaadkan markii dambe 'LexError`s.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, buundada waxay bixisaa oo kaliya `to_string`, hirgeli `fmt::Display` iyada oo ku saleysan (gadaal xiriirka caadiga ah ee u dhexeeya labada).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Daabacashooyinka durdur token sida string ah oo la moodayay in ay dib losslessly bedeli gelin durdur token isku mid ah (galaasyada modulo), waxaana suurto gal ahayn `TokenTree: : Group`s la delimiters `Delimiter::None` iyo literals tiro taban.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Daabacashooyinka token foom haboon debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Abuuraa durdur token ka kooban geed keliya oo token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Waxay ku ururisaa tiro geedo ah token hal durdur.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Hawlgal "flattening" ah oo ku saabsan durdurrada 'token', wuxuu ka soo ururiyaa geedo token wabiyaal badan oo token ah oo loo maro hal durdur.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Adeegso hirgalinta hirgelinta if/when suurto gal.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Faahfaahinta hirgelinta dadweynaha ee nooca `TokenStream`, sida kuwa ku shaqeeya.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Soo-saare ka hadlaya ``TokenTree`s '' TokenStream`s.
    /// siyaalaha waa "shallow", tusaale ahaan, ka iterator ma recurse kooxo xuduuddiisa, iyo celinta kooxaha oo dhan sida geedaha token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` wuxuu aqbalaa tokens si aan macquul ahayn wuxuuna u ballaariyaa `TokenStream` oo sharraxaya soo gelinta.
/// Tusaale ahaan, `quote!(a + b)` wuxuu soo saari doonaa hadal, in, markii la qiimeeyo, dhiso `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting lagu sameeyaa `$`, oo ka shaqeeya by qaadashada ident kaliya ee soo socda sida ereyga unquoted.
/// Si aad u sheegto `$` lafteeda, isticmaal `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Gobol ka mid ah koodhka ilaha, oo ay weheliso macluumaadka ballaarinta makro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Abuuraa `Diagnostic` cusub `message` la siiyey at taako ku `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// taako A in lagu xaliyo goobta qeexidda Dhaqale.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Dhererka ducaysiga ee macro hawleedka hadda jira.
    /// Calaamado abuuray taako this lagu xalin doonaa sidii iyagoo si toos ah oo qoraal ah goobta Dhaqale wac (nadaafadda call-site) iyo code kale goobta call Dhaqale awoodaan in ay tixraac iyaga iyo sidoo noqon doonaa.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// taako A ka dhigan nadaafadda `macro_rules`, iyo mararka qaarkood lagu xaliyo goobta Dhaqale qeexidda (Variables maxaliga ah, sumadaha, `$crate`) oo mararka qaar goobta call Dhaqale (wax kasta oo kale).
    ///
    /// Goobta taako waxaa laga soo qaatay goobta wicitaanka.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// The file isha asalka ah oo dhibcood taako this.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` ee tokens ee balaadhintii hore ee makro ee `self` laga soo saaray, haddii ay jirto.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// taako ee code source jeedo in `self` ahaa ee ka soo baxa.
    /// Haddii `Span`-kan aan laga abuurin ballaadhinta kale ee macro ka dibna qiimaha soo-celinta waxay la mid tahay `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Wuxuu helayaa bilawga line/column feylka isha ee taako.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Wuxuu hayaa dhamaadka line/column feylka isha ee taako.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Abuuraa taako cusub koobay `self` iyo `other`.
    ///
    /// Dib `None` haddii `self` iyo `other` waa ka files kala duwan.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Waxay abuurtaa taako cusub oo leh isla macluumaadka line/column sida `self` laakiin taasi waxay xallisaa astaamaha sidii ay ahayd `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Abuuraa taako cusub dhaqanka magaca xal la mid ah sida `self` laakiin macluumaad line/column ee `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Marka la barbardhigo taako si loo arko haddii ay siman yihiin.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Sooceliyaa qoraalka isha gadaashiisa
    /// Tani waxay ilaalinaysaa lambarka asalka asalka, oo ay ku jiraan meelaha iyo faallooyinka.
    /// Kaliya waxay ku soo celinaysaa natiijo haddii taako u dhigantaa koodhka isha dhabta ah.
    ///
    /// Note: Natiijada la arki karo ee makro waa inay ku tiirsanaato oo keliya tokens oo aysan ku tiirsanaan qoraalkaan isha.
    ///
    /// Natiijada shaqadani waa dadaalka ugu fiican ee loo isticmaali karo baaritaanka kaliya.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Daabacayaa taako foom haboon debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Lammaane saf ah oo matalaya bilowga ama dhammaadka `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Sadarka 1-ee loo yaqaan 'file index' ee ay taako ku bilaabaneyso ama ku egtahay (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// The column 0-eegid (ee characters UTF-8) ee faylka il on taas oo taako bilaaban ama darafyadiisa (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Faylka isha ee `Span` la siiyay.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Helo jidka file il this.
    ///
    /// ### Note
    /// Haddii tirada koodhka ee la xidhiidha `SourceFile`-kan ay soo saartay macro dibadeed, macro, tani ma noqon karto waddo dhab ah oo ku saabsan nidaamka faylasha.
    /// Adeegso [`is_real`] si aad u hubiso.
    ///
    /// Sidoo kale ogow xitaa haddii `is_real` soo celiyo `true`, haddii `--remap-path-prefix` lagu dhaafiyey xariiqda taliska, wadada la siiyay dhab ahaan ma noqonayso mid ansax ah.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Sooceliyaa `true` haddii file il this waa file dhabta ah isha, iyo ma ahbaa by ballaarinta Dhaqale dibadda ah.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Tani waa hack ilaa galaasyada intercrate la fuliyo oo aan yeelan karaan faylasha isha dhabta ah ee galaasyada ahbaa in macros dibadda.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Hal token ama taxane xaddidan oo geedaha token ah (tusaale, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// A token durdur hareereysan delimiters labixiyo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Aqoonsi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// A qof xarakayn hal (`` +, `,`, `$`, iwm).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// qof A suugaan (`'a'`), string (`"hello"`), tirada (`2.3`), iwm
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Sooceliyaa taako geedkaan, isagoo udiyaarinaya habka `span` ee kujira token ama durdur xadidan.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Waxay u qaabeysaa taako *kaliya tan token*.
    ///
    /// Ogow in haddii token tani waa `Group` a ka dibna habkan ma reserved doonaan taako ka mid ah kasta oo tokens gudaha, tani si fudud u wakiisho doonaa in hab `set_span` ee kala duwanaansho kasta.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// geed daabacayaa token foom haboon debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Mid kasta oo ka mid ah kuwan wuxuu ku leeyahay magaca qaabka qaabdhismeedka ka soo jeeda, markaa ha ku mashquulin lakab dheeri ah oo aan leexasho lahayn
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, buundada waxay bixisaa oo kaliya `to_string`, hirgeli `fmt::Display` iyada oo ku saleysan (gadaal xiriirka caadiga ah ee u dhexeeya labada).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Waxay u daabacdaa geedka token inuu yahay xarig loo maleynayo inuu si khasaaro la'aan ah loogu beddeli karo isla geedkii token (modulo spans), marka laga reebo suurtagalnimada ``TokenTree: : Group`s oo leh xaddidayaasha `Delimiter::None` iyo tirakoobyo taban.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Durdur xaddidan oo token ah.
///
/// A `Group` gudaha ku jira `TokenStream` a kaas oo la hareereeyey by `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Qeexaa sida taxanaha ah ee geedaha token loo xadiday.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// delimiter An awaamiir, in laga yaabaa, tusaale ahaan, ka muuqan agagaarka tokens ka imaanaya "macro variable" `$var` ah.
    /// Waa muhiim in la ilaaliyo mudnaanta wadaha kiisaska sida `$var * 3` halka `$var` uu yahay `1 + 2`.
    /// delimiters awaamiir laga yaabaa in aanay ku noolaan roundtrip of il token ah iyada oo xarig ah.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Waxay abuurtaa `Group` cusub oo leh xaddidaadda la siiyay iyo durdurka token.
    ///
    /// Dhisehani wuxuu dejin doonaa taako kooxdan ilaa `Span::call_site()`.
    /// Si aad u bedesho taako waxaad isticmaali kartaa habka `set_span` ee hoose.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Sooceliyaa delimiter ee `Group` this
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Sooceliyaa `TokenStream` ee tokens ee lagu xadiday `Group`-kan.
    ///
    /// Ogow in webigu ku soo laabtay token kuma jiraan delimiter kor ku soo laabtay.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Soocelinaya taako loogu talagalay soohdinta xaddidan durdurkan 'token', oo ku baahsan dhammaan `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Sooceliyaa taako ku fiiqaya in delimiter furitaanka kooxdan ka.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Soocelinaya taako tilmaamaya soohdinta xiritaanka kooxdan.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configures taako ee this `delimiters Group` ee, laakiin ma ay tokens gudaha.
    ///
    /// Qaabkani **ma** dejin doono taako oo dhan tokens gudaha ah oo ay kooxdani fidisay, laakiin taa beddelkeeda waxay kaliya dejin doontaa taako ka mid ah xaddidayaasha tokens ee heerka `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, buundada waxay bixisaa oo kaliya `to_string`, hirgeli `fmt::Display` iyada oo ku saleysan (gadaal xiriirka caadiga ah ee u dhexeeya labada).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Waxay u daabacdaa kooxda sida xarig ay tahay in si lumis la'aan ah loogu beddeli karo isla kooxdaas (modulo spans), marka laga reebo suurtagalnimada ``TokenTree: : Group`s oo leh xaddidayaasha `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` waa astaamo hal xaraf ah sida `+`, `-` ama `#`.
///
/// Hawlwadeeno badan oo xaraf leh sida `+=` ayaa loo metelaa sida laba xaaladood oo ah `Punct` oo leh qaabab kala duwan oo `Spacing` ah oo la soo celiyay.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Haddii `Punct` la raaceen by `Punct` kale ama raacay by token kale ama whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// tus, `+` is `Alone` in `+ =`, `+ident` or `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// tusaale ahaan, `+` waa `Joint` in `+=` ama `'#`.
    /// Intaa waxaa sii dheer, hal xigasho `'` waxay ku biiri kartaa aqoonsiyeyaasha si ay u sameystaan nolosha `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Waxay ka abuurtaa `Punct` cusub astaamaha la siiyay iyo kala dheereynta.
    /// dood `ch` waa in uu ahaadaa qof a xarakayn ansax ogola by afka, haddii kale shaqada panic doono.
    ///
    /// `Punct` ayaa ku soo laabtay yeelan doonaan taako default of `Span::call_site()` oo la sii qaybiyay kartaa habka `set_span` hoose ah.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Sooceliyaa qiimaha qof xarakaynta sida `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Waxay soocelineysaa kala dheereynta astaamahan xarakaynta, tilmaamaysa inay isla markiiba lasocoto `Punct` kale oo kujira qulqulka token, sidaa darteed waxaa suuragal ah in layskudarsado shirkad dhowr dabeecad leh (`Joint`), ama waxaa raacaya qaar kale oo token ah ama cadaan ah (`Alone`) sidaa darteed shaqaaluhu hubaal dhamaaday.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Ku soo celinayaa taako shaqsiga astaamaha.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// U habee taako astaamaha shaqaaladan.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, buundada waxay bixisaa oo kaliya `to_string`, hirgeli `fmt::Display` iyada oo ku saleysan (gadaal xiriirka caadiga ah ee u dhexeeya labada).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Daabacayaa qof xarakaynta sida xarig ah waa in ay noqon dib losslessly bedeli galay qof isku mid ah.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Aqoonsi (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Waxay abuurtaa `Ident` cusub oo leh `string` la siiyay iyo sidoo kale `span` cayiman.
    /// Doodda `string` waa inay ahaato aqoonsi ansax ah oo uu oggol yahay luuqaddu (oo ay ku jiraan ereyada muhiimka ah, tusaale `self` ama `fn`).Haddii kale, shaqadu waa panic.
    ///
    /// Ogsoonow in `span`, hadda in rustc, configures macluumaad nadaafadda ee aqoonsi this ah.
    ///
    /// Sida waqti this `Span::call_site()` cad dhabeeyo-in si "call-site" macnaha nadaafadda in aqoonsiga abuuray taako this lagu xalin doonaa sidii iyagoo si toos ah u qoray meesha uu call Dhaqale, iyo code kale goobta call Dhaqale awoodaan in ay tixraac u noqon doonaa iyaga sidoo kale.
    ///
    ///
    /// galaasyada Later sida `Span::def_site()` u ogolaan doonaa in ay ka gaabsadeen-in si nadaafadda "definition-site" taasoo la micno ah in aqoonsiga abuuray taako this lagu xalin doonaa meesha uu qeexidda Dhaqale iyo code kale goobta call Dhaqale ma awoodi doonaan in ay tixraac iyaga.
    ///
    /// Sababo la muhiimadda ay hadda nadaafadda constructor this, ka duwan kale tokens, waxay u baahan tahay `Span` ah in la cayimay ee dhismaha.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// La mid ah sida `Ident::new`, laakiin waxay abuurtaa aqoonsi ah cayriin (`r#ident`).
    /// dood `string` waxay noqon aqoonsi sax ah ogola by afka (ay ka mid yihiin keywords, tusaale `fn`).
    /// Erayo-fure ah oo lagu isticmaali karo qaybaha dariiqa (tusaale
    /// `self`, 'super`) lama taageerayo, waxayna sababi doontaa panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Soocelinaya taako `Ident`-kan, oo koobay dhammaan xarigga uu sooceliyay [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures taako ka mid ah `Ident` this, waxaana suurto gal beddelo macno nadaafadda ay.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, buundada waxay bixisaa oo kaliya `to_string`, hirgeli `fmt::Display` iyada oo ku saleysan (gadaal xiriirka caadiga ah ee u dhexeeya labada).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Waxay u daabacdaa aqoonsi sida xarig ay tahay in si lumis ah loogu beddeli karo isla aqoonsi.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// string A suugaan (`"hello"`), byte string (`b"hello"`), qof (`'a'`), qof byte (`b'a'`), abyoonaha ah ama sabayn tiro dhibic leh ama aan lahayn magac qadarin ah (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// literals Boolean sida `true` iyo `false` ma halkan iska leh, oo iyagu waa `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Waxay abuurtaa tirakoob cusub oo tirakoob ah oo leh qiimaha la cayimay.
        ///
        /// Shaqadani waxay abuuri doontaa tiro isku mid ah sida `1u32` oo ah halka tirada isku-dhafan ee la qeexay ay tahay qaybta koowaad ee token isla markaana waxyaabaha muhiimka ah dhammaantoodna lagu dhejinayo.
        /// Literals abuuray tiro taban laga yaabaa in aanay ku noolaan wareega safarada dhex `TokenStream` ama xadhig iyo dhigtayna waa jabi karayaa laba tokens (`-` iyo suugaan positive).
        ///
        ///
        /// Literals abuuray iyada oo loo marayo hab this leeyihiin taako `Span::call_site()` ah by default, taas oo loo qaybiyay kartaa habka `set_span` hoose.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Waxay abuurtaa tiro cusub oo aan dheelitir ahayn oo leh qiimaha la cayimay.
        ///
        /// Hawshani waxay abuuri doontaa tiro isku mid ah sida `1` oo ah halka tirada inteegeeda la qeexay ay tahay qaybta hore ee token.
        /// xarfaha No waxaa loo cayimay on token this, taasoo la micno ah in ducadaas sida `Literal::i8_unsuffixed(1)` u dhigmaa `Literal::u32_unsuffixed(1)`.
        /// Suugaanta laga sameeyay tirooyinka taban ma badbaadi karaan rountrips illaa `TokenStream` ama xarig waxaana loo kala jabinayaa laba tokens (`-` iyo suugaan togan).
        ///
        ///
        /// Literals abuuray iyada oo loo marayo hab this leeyihiin taako `Span::call_site()` ah by default, taas oo loo qaybiyay kartaa habka `set_span` hoose.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Waxay abuurtaa suugaan-dhibic sabayn dhibic cusub oo aan la buuxin.
    ///
    /// Dhismahani wuxuu lamid yahay kuwa sida `Literal::i8_unsuffixed` oo kale ah halka qiimaha sabeynta si toos ah loogu sii daayo token laakiin wax dhejis ah looma adeegsan, sidaa darteed waxaa laga yaabaa inay u muuqato inuu yahay `f64` goor dambe ee isku-duwaha.
    ///
    /// Suugaanta laga sameeyay tirooyinka taban ma badbaadi karaan rountrips illaa `TokenStream` ama xarig waxaana loo kala jabinayaa laba tokens (`-` iyo suugaan togan).
    ///
    /// # Panics
    ///
    /// function waxay u baahan tahay in birtiina ku qeexan yahay uguna, tusaale ahaan haddii ay tahay xad la'aan ama NAN shaqo this doonaa panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Waxay abuurtaa suugaan dul sabbaysan oo dul sabbaysan oo cusub.
    ///
    /// constructor Tani waxay abuuri doonaa suugaan ah sida `1.0f32` halkaas oo qiimaha ku cad waa qayb la soo dhaafay of token iyo `f32` waa qadarin ah ee token ah.
    /// token-kan ayaa had iyo jeer laga dhigayaa inuu yahay `f32` isku-duwaha.
    /// Suugaanta laga sameeyay tirooyinka taban ma badbaadi karaan rountrips illaa `TokenStream` ama xarig waxaana loo kala jabinayaa laba tokens (`-` iyo suugaan togan).
    ///
    ///
    /// # Panics
    ///
    /// function waxay u baahan tahay in birtiina ku qeexan yahay uguna, tusaale ahaan haddii ay tahay xad la'aan ama NAN shaqo this doonaa panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Waxay abuurtaa suugaan-dhibic sabayn dhibic cusub oo aan la buuxin.
    ///
    /// Dhismahani wuxuu lamid yahay kuwa sida `Literal::i8_unsuffixed` oo kale ah halka qiimaha sabeynta si toos ah loogu sii daayo token laakiin wax dhejis ah looma adeegsan, sidaa darteed waxaa laga yaabaa inay u muuqato inuu yahay `f64` goor dambe ee isku-duwaha.
    ///
    /// Suugaanta laga sameeyay tirooyinka taban ma badbaadi karaan rountrips illaa `TokenStream` ama xarig waxaana loo kala jabinayaa laba tokens (`-` iyo suugaan togan).
    ///
    /// # Panics
    ///
    /// function waxay u baahan tahay in birtiina ku qeexan yahay uguna, tusaale ahaan haddii ay tahay xad la'aan ama NAN shaqo this doonaa panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Waxay abuurtaa suugaan dul sabbaysan oo dul sabbaysan oo cusub.
    ///
    /// Dhismahani wuxuu abuuri doonaa suugaan sida `1.0f64` oo kale halka qiimaha la qeexay uu yahay qaybta hore ee token iyo `f64` waa habeyn token ah.
    /// token-kan ayaa had iyo jeer laga dhigayaa inuu yahay `f64` isku-duwaha.
    /// Suugaanta laga sameeyay tirooyinka taban ma badbaadi karaan rountrips illaa `TokenStream` ama xarig waxaana loo kala jabinayaa laba tokens (`-` iyo suugaan togan).
    ///
    ///
    /// # Panics
    ///
    /// function waxay u baahan tahay in birtiina ku qeexan yahay uguna, tusaale ahaan haddii ay tahay xad la'aan ama NAN shaqo this doonaa panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Xarig suugaan ah.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Astaamaha astaamaha.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte string suugaan.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Sooceliyaa taako ku koobay suugaan this.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures taako la xiriira for suugaan this.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Sooceliyaa `Span` taasi waa qeyb ka mid ah `self.span()` oo ay kujiraan oo kaliya baayt-yada lagahelo inta udhaxeysa `range`.
    /// Sooceliyaa `None` haddii taako ku doonayeen-la iska jaro waa ka baxsan xadadka `self`.
    ///
    // FIXME(SergioBenitez): hubi in kala duwan oo byte bilaabo iyo darfihiisa at boundary UTF-8 ah isha.
    // haddii kale, waxay u badan tahay in panic a dhici doona meelo kale marka text isha ku daabacan.
    // FIXME(SergioBenitez): Ma jirto waddo uu isticmaalehu ku ogaan karo waxa dhabta ah ee loo yaqaan `self.span()` khariidadaha, markaa habkan hadda waxaa loogu yeedhi karaa oo keliya indho la'aan.
    // Tusaale ahaan, `to_string()` waayo dabeecadda 'c' laabtay "'\u{63}'";ma jirto hab user ah in la ogaado bal qoraalka isha ahaa 'c' ama in ay ahayd '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) wax ka dhigan tahay `Option::cloned`, laakiin `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, buundada waxay bixisaa oo kaliya `to_string`, hirgeli `fmt::Display` iyada oo ku saleysan (gadaal xiriirka caadiga ah ee u dhexeeya labada).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Waxay u daabacdaa suugaan ahaan sidii xarig ay tahay in si lumis la'aan ah loogu beddeli karo isla isla suugaan (marka laga reebo wareega suurtogalka ah ee suugaanta dhibcaha sabayn).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Dabagal ku helaan doorsoomayaasha deegaanka.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Soo cesho jawiga deegaanka oo ku dar si aad u dhisto macluumaadka ku tiirsanaanta.
    /// Nidaam dhisid fuliya isku-duwaha wuxuu ogaan doonaa in doorsoomaha la helay intii lagu jiray isku-dubbaridka, wuxuuna awood u yeelan doonaa inuu dib-ugu-celiyo dhismaha marka qiimaha doorsoomahaas isbeddelo.
    ///
    /// Ka sokow ku tiirsanaanta raad shaqada this waa in u dhiganta `env::var` maktabadda caadiga ah, marka laga reebo in muran waa in ay ahaadaan UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}