use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Loo isticmaalaa in lagu sheegi qoritaan gaaban `#[assert_instr]` our in dhammaan intrinsics simd waxaa laga heli karaa si ay u tijaabiso ay codegen, tan iyo qaar ka mid ah waxaa markaas dajisay dambeeya `-Ctarget-feature=+unimplemented-simd128` dheeraad ah in uusan haysan wax u dhigma wax ku `#[target_feature]` hadda.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}