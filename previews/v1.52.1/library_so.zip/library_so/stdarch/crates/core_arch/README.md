`core::arch` - intrinsics naqshadaha-gaar ah maktabadda core Rust ee
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Moodalka `core::arch` wuxuu hirgeliyaa astaamaha ku tiirsan qaab dhismeedka (tusaale ahaan SIMD).

# Usage 

`core::arch` waxaa laga heli karaa oo qayb ka ah `libcore` oo waxaa la dib-u-dhoofinaysay `libstd`.Ka doorbido inaad ku isticmaasho iyada oo loo marayo `core::arch` ama `std::arch` marka loo eego tan crate.
Tilmaamo aan xasilloonayn ayaa badanaa laga heli karaa habeenkii Rust iyada oo loo marayo `feature(stdsimd)`.

Isticmaalka `core::arch` adoo adeegsanaya crate-kani waxay u baahan tahay habeen kasta Rust, waana karti kartaa (oo sameyn kartaa) badanaa.Xaaladaha kaliya ee ay tahay inaad ka fiirsato isticmaalkeeda crate waa:

* haddii aad u baahan tahay inaad dib u soo ururiso `core::arch` naftaada, tusaale ahaan, oo leh astaamo bartilmaameed gaar ah oo karti u leh oo aan karti u lahayn `libcore`/`libstd`.
Note: haddii aad u baahan tahay si ay u dib-u-ridida ah target aan caadiga ahayn, fadlan door bidaan isticmaalaya `xargo` iyo dib-u-ururinayaan `libcore`/`libstd` sida ku haboon halkii la isticmaalayo crate this.
  
* adoo adeegsanaya astaamo aan laga heli karin xitaa ka dambeeya astaamaha xasilloonida Rust.Waxaan isku dayeynaa inaan kuwaas ka dhigno kuwa ugu yar.
Haddii aad u baahan tahay inaad adeegsato astaamahan qaar ka mid ah, fadlan fur arrin si aan ugu soo bandhigno habeen kasta Rust oo aad halkaas uga isticmaali karto.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ugu horayn waxa loo qaybiyey ka yar shuruudaha labada liisanka MIT iyo License Apache ah (Version 2.0), iyo intii ay qaybta daboolay by BSD-sida liisanka kala duwan.

Faahfaahin ka eeg LIISKA-APACHE, iyo LIISKA-MIT.

# Contribution

Ilaa aad si cad u sheegtid mooyee, wixii tabarucaad ah oo si ula kac ah loo soo gudbiyey si loogu daro `core_arch` adigu, sida lagu qeexay liisanka Apache-2.0, waxay noqon doontaa laba shati sida kor ku xusan, iyadoon lahayn shuruudo ama shuruudo dheeraad ah.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












