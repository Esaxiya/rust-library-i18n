# Ka qayb qaadanaya istaroog

`stdarch` crate wuxuu aad uga badan yahay inuu aqbalo tabarucaadka!First u badan tahay waxaad u baahan tihiin si aad u hubiso soo baxay bakhaar iyo inay hubiyaan in baaritaan mari aad u:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Halka `<your-target-arch>` uu yahay bartilmaameedka seddex-geesoodka ah ee uu adeegsado `rustup`, tusaale `x86_x64-unknown-linux-gnu` (iyadoon la helin `nightly-` ama wax lamid ah).
Sidoo kale xusuusnow in bakhaarkani u baahan yahay kanaalka habeen ee Rust!
Imtixaanada kor ku xusan waxay dhab ahaantii u baahan yihiin habeen kasta rust inuu noqdo mid ku habboon nidaamkaaga, si loo dejiyo adeegsiga `rustup default nightly` (iyo `rustup default stable` si loogu laabto).

Haddii mid ka mid ah tallaabooyinka kor ku xusan uusan shaqeyn, [please let us know][new]!

Marka xigta waad awoodaa [find an issue][issues] si aad uga caawiso, waxaan ku dooranay in yar oo sumadaha [`help wanted`][help] iyo [`impl-period`][impl] kuwaas oo si gaar ah u isticmaali kara xoogaa caawimaad ah. 
Waxaa laga yaabaa inaad aad u xiiseyneyso [#40][vendor], adoo ka hirgelinaya dhammaan waxyaabaha iibiyaha ah ee ku saabsan x86.Taasi ayaa arrinta ka helay qaar ka mid ah tilmaamo wanaagsan oo ku saabsan halkaas oo si aad u bilowdo!

Haddii aad hayso su'aalo guud xorriyad u hel [join us on gitter][gitter] oo weydii hareerahaaga!Xor ayaad u tahay inaad su'aal weydiiso@BurntSushi ama@alexcrichton

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Sida loo qoro tusaalooyinka stdarch intrinsics

Waxaa jira astaamo yar oo ay tahay inay karti u yeelato asalka la siiyay inuu si sax ah u shaqeeyo tusaalahana waa in lagu socodsiiyaa oo kaliya `cargo test --doc` marka muuqaalka uu taageerayo processor-ka.

Natiijo ahaan, `fn main`-da caadiga ah ee ay soo saartay `rustdoc` ma shaqeyn doono (xaaladaha badankood).
Tixgeli inaad u adeegsato waxyaabaha soo socda tusaale ahaan si aad u hubiso in tusaalahaagu u shaqeeyo sidii la filayay.

```rust
/// # // Waxaan cfg_target_feature baahan si loo hubiyo in tusaale ahaan waa kaliya
/// # // oo ay maamusho `cargo test --doc` marka processorku uu taageerayo muuqaalka
/// # #![feature(cfg_target_feature)]
/// # // Waxaan ubaahanahay bartilmaameed_qeex si asturan u shaqeeyo
/// # #![feature(target_feature)]
/// #
/// # // rustdoc asal ahaan wuxuu adeegsadaa `extern crate stdarch`, laakiin waxaan u baahanahay kan
/// # // `#[macro_use]`
/// # # [macro_use] bannaanka crate stdarch;
/// #
/// # // Shaqada ugu weyn ee dhabta ah
/// # fn main() {
/// #     // Kaliya ordi tan haddii `<target feature>` la taageero
/// #     haddii cfg_feature_enabled! (""<target feature>"){
/// #         // Abuur shaqo `worker` ah oo la shaqeyn doono oo keliya haddii muuqaalka bartilmaameedka
/// #         // la taageeray lana hubiyo in `target_feature` loo kartiyeeyo shaqaalahaaga
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         fn worker() aan aamin ahayn
/// // Halkan ku qor tusaalahaaga.Muujinta waxyaabaha gaarka ah ee gaarka ah ayaa halkan ka shaqeyn doona!Duurjoog!
///
/// #         }
///
/// #         { worker(); } aan aamin ahayn
/// #     }
/// # }
```

Haddii qaar ka mid ah ereyada kor ku xusan aysan u muuqan kuwo la yaqaan, qaybta [Documentation as tests] ee [Rust Book] waxay si fiican u qeexaysaa qaabeynta `rustdoc`.
Sida had iyo jeer, si xor ah u [join us on gitter][gitter] oo na weydii haddii aad ku dhuftey kasta snags, oo waad ku mahadsan tahay caawinta si loo hagaajiyo waraaqo ee `stdarch`!

# Tilmaamaha Baaritaanka Alternative

Waxaa guud ahaan lagugula talinayaa inaad isticmaasho `ci/run.sh` si aad u maamusho imtixaannada.
Si kastaba ha noqotee tani ma kuu shaqeyn karto, tusaale ahaan haddii aad ku jirto Windows.

Xaaladdaas oo kale waxaad dib ugu laaban kartaa socodsiinta `cargo +nightly test` iyo `cargo +nightly test --release -p core_arch` si aad u tijaabiso jiilka koodhka.
Ogsoonow in kuwani ay u baahan yihiin qalab habeennimo oo qalab lagu rakibo iyo in `rustc` laga ogaado bartilmaameedkaaga seddexleey iyo processor-kiisa.
Gaar ahaan waxaad u baahan tahay inaad dejiso isbeddellada deegaanka ee `TARGET` sida aad u dejin lahayd `ci/run.sh`.
Intaa waxaa sii dheer waxaad u baahan tahay inaad dejiso `RUSTCFLAGS` (u baahan `C`) si aad u muujiso astaamaha bartilmaameedka, tusaale `RUSTCFLAGS="-C -target-features=+avx2"`.
Waxa kale oo aad dejin kartaa `-C -target-cpu=native` haddii aad tahay "just" oo ka soo horjeeda processor-kaaga hadda jira.

Ka digtoonow markaad isticmaaleyso tilmaamahan beddelka ah, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], tusaale
imtixaanada jiilka edbinta darnaadeen maxaa yeelay disassembler ka duwan iyaga la odhan jiray, tusaale ahaan
waxay dhalin kartaa `vaesenc` halkii laga siin lahaa tilmaamaha `aesenc` inkasta oo ay isku si u dhaqmayaan.
Sidoo kale tilmaamahan waxay fuliyaan tijaabooyin ka yar intii caadiga ahayd ee la qaban lahaa, sidaa darteed ha la yaabin markii aad aakhirka soo jiidato-codsato khaladaadka qaarkood ayaa laga yaabaa inay muujiyaan imtixaannada aan halkan lagu soo koobi karin.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






