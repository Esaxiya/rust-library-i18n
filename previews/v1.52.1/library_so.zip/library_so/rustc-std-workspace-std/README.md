# `rustc-std-workspace-std` crate

Fiiri warqadaha for crate `rustc-std-workspace-core` ah.