use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Tani ma aha aagga dusha sare ee xasilloon, laakiin waxay kaa caawineysaa inuu `?` ka dhigo mid raqiis ah dhexdooda, xitaa haddii LLVM uusan had iyo jeer ka faa'iideysan karin hadda.
    //
    // (Nasiib xumo Natiijo iyo Xulasho waa iswaafaqsan yihiin, marka ControlFlow labaduba isma waafaqi karaan.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}