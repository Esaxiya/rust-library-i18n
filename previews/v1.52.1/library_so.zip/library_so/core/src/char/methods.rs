//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Qodobka ugu sareeya ee ansax ah ee `char` ayaa yeelan kara.
    ///
    /// A `char` waa [Unicode Scalar Value] ah, taas oo macnaheedu yahay in ay tahay [Code Point] ah, laakiin kuwa kaliya gudahood kala duwan oo gaar ah.
    /// `MAX` waa qodobka koodhka ugu sareeya ee ansax ah kaas oo ah [Unicode Scalar Value] ansax ah.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () waxaa loo isticmaalaa Unicode si loogu metelo qalad kelmadaha.
    ///
    /// Way dhici kartaa, tusaale ahaan, marka la siinayo UTF-8 bytes qaab-dhismeed jirran [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Nooca [Unicode](http://www.unicode.org/) in qaybaha Unicode ee hababka `char` iyo `str` ay ku saleysan yihiin.
    ///
    /// versions of New koodh caalamiga si joogto ah la sii daayay iyo markii danbe oo dhan hababka maktabadda caadiga ah ku xiran tahay koodh caalamiga ayaa la cusbooneysiiyaa.
    /// Sidaa darteed habdhaqanka qaar ka mid ah hababka `char` iyo `str` iyo qiimaha isbeddelladan joogtada ahi muddo isku beddelayso.
    /// Tani * looma arko inay tahay isbedel jabis ah.
    ///
    /// nidaamka version tiradoodii waxaa la sharaxay in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Abuuraa iterator ah in ka badan UTF-16 ku encoded dhibcood code in `iter`, soo laabtay howlgeliyeyaal unpaired sida `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// decoder lossy A waxaa laga heli karaa iyadoo la bedelayo natiijada `Err` leh qof bedelka:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// U rogaa `u32` una beddelaa `char`.
    ///
    /// Xusuusnow in dhammaan ``char`s '' ay ansax yihiin ['u32`] s, waana lagu tuuri karaa mid leh
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Si kastaba ha ahaatee, guuldaradoodii run ma aha, ma dhammaan ansax [`u32`] s waa ansax`char`s.
    /// `from_u32()` soo laaban doonaa `None` haddii la gelin ma aha qiimaha sax ah `char` ah.
    ///
    /// Waayo, version nabadla 'ee shaqada oo iska dhega jeegaga, fiiri [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Ku soo noqoshada `None` marka soo galintu aysan ansax ahayn `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Kuweeda `u32` ah in `char` ah, iska dhego-saxsanaanta.
    ///
    /// Xusuusnow in dhammaan ``char`s '' ay ansax yihiin ['u32`] s, waana lagu tuuri karaa mid leh
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Si kastaba ha ahaatee, guuldaradoodii run ma aha, ma dhammaan ansax [`u32`] s waa ansax`char`s.
    /// `from_u32_unchecked()` this iska indha doonaa, oo ku Daynanaa Iyagoo ku tuuray `char`, waxaana suurto gal abuuraya mid khaldan.
    ///
    ///
    /// # Safety
    ///
    /// function Tani waa ammaan ahayn, sida ay u dhisaan laga yaabaa in qiimaha baadil `char`.
    ///
    /// Waayo, version ammaan ah ee shaqada this, ka eeg function [`from_u32`] ah.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // AMMAANKA: heshiis ammaanka waa in la fuliyo ay wacaha.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Kuweeda god ah ee radikis la siiyay `char` ah.
    ///
    /// 'radix' halkan ayaa mararka qaarkood sidoo kale loo yaqaan 'base'.
    /// Laba shucaac waxay muujineysaa nambarka binary, shucaac toban ah, tobanle, iyo rax oo lix iyo toban ah, hexadecimal, si loo siiyo qiimeyo guud.
    ///
    /// Xagjirnimada sabab la`aanta ah ayaa la taageerayaa.
    ///
    /// `from_digit()` soo laaban doonaa `None` haddii la gelin ma aha god ah ee radikis la siiyey.
    ///
    /// # Panics
    ///
    /// Panics haddii la siiyo shucaac ka weyn 36.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Jajab tobanle 11 waa lambar hal saldhig 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Ku soo noqoshada `None` marka aqbalku uusan ahayn lambar:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Gudbinta shucaac weyn, oo keenaya panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Checks haddii `char` waa god ah ee radikis la siiyey.
    ///
    /// 'radix' halkan ayaa mararka qaarkood sidoo kale loo yaqaan 'base'.
    /// Laba shucaac waxay muujineysaa nambarka binary, shucaac toban ah, tobanle, iyo rax oo lix iyo toban ah, hexadecimal, si loo siiyo qiimeyo guud.
    ///
    /// Xagjirnimada sabab la`aanta ah ayaa la taageerayaa.
    ///
    /// Marka la barbardhigo [`is_numeric()`], shaqadani waxay aqoonsan tahay oo keliya jilayaasha `0-9`, `a-z` iyo `A-Z`.
    ///
    /// 'Digit' waxaa lagu qeexaa in uu noqdo oo kaliya characters soo socda:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Waayo, faham dheeraad ah oo dhamaystiran oo ah 'digit', arki [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics haddii la siiyo shucaac ka weyn 36.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Gudbinta shucaac weyn, oo keenaya panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// U rogaa `char` lambar ka mid ah shucaaca la siiyay.
    ///
    /// 'radix' halkan ayaa mararka qaarkood sidoo kale loo yaqaan 'base'.
    /// Laba shucaac waxay muujineysaa nambarka binary, shucaac toban ah, tobanle, iyo rax oo lix iyo toban ah, hexadecimal, si loo siiyo qiimeyo guud.
    ///
    /// Xagjirnimada sabab la`aanta ah ayaa la taageerayaa.
    ///
    /// 'Digit' waxaa lagu qeexaa in uu noqdo oo kaliya characters soo socda:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Soocelinayaa `None` haddii `char` uusan tixraacin lambar kujira shucaaca lasiiyay.
    ///
    /// # Panics
    ///
    /// Panics haddii la siiyo shucaac ka weyn 36.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Gudbinta ah natiijooyinka aan lambar ee failure:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Gudbinta shucaac weyn, oo keenaya panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // code la kala halkan si loo hagaajiyo xawaaraha dil qaabilsanna kiisaska `radix` waa joogto ah iyo 10 ama ka yar
        //
        let val = if likely(radix <= 10) {
            // Haddii aysan ahayn lambar, lambar ka weyn shucaac ayaa la abuuri doonaa.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Dib iterator in edbiyey hexadecimal koodh caalamiga baxsashada ee qof sida `char`s.
    ///
    /// Tani waxay ka baxsan doontaa jilayaasha leh qaabka Rust ee qaabka `\u{NNNNNN}` halkaasoo `NNNNNN` ay tahay matalaad hexadecimal ah.
    ///
    ///
    /// # Examples
    ///
    /// Hadal ahaan:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Si toos ah u adeegsiga `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Labaduba waxay u dhigmaan:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Adeegsiga `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // ama-nayaa 1 hubisaa in for c==0 computes code in hal god waa in la daabaco iyo (taas oo la mid ah) fogaado ah (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // tusmada lambar hex ee ugu muhiimsan
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Nooc la dheereeyey oo ah `escape_debug` oo ikhtiyaar ahaan u oggolaanaya inuu ka baxsado koodhadhka loo yaqaan 'Extended Grapheme'.
    /// Tani waxay noo oggolaaneysaa in ay qaab characters sida nonspacing marks wanaagsan marka ay tahay bilowgii xarig ah.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Dib iterator ah in lagu edbiyey u code ka baxsado suugaan dabeecad sida `char`s.
    ///
    /// Tani waxay ka baxsan doontaa jilayaasha la midka ah hirgelinta `Debug` ee `str` ama `char`.
    ///
    ///
    /// # Examples
    ///
    /// Hadal ahaan:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Si toos ah u adeegsiga `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Labaduba waxay u dhigmaan:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Adeegsiga `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Dib iterator ah in lagu edbiyey u code ka baxsado suugaan dabeecad sida `char`s.
    ///
    /// Bixinta asaasiga ah waxaa lagu doortaa iyadoo loo xaglinayo soo saarista suugaanta oo sharci ku ah luqado kala duwan, oo ay ku jiraan C++ 11 iyo luqadaha la midka ah ee qoysaska.
    /// Shuruucda saxda ah waa:
    ///
    /// * Tab ayaa loo baxsaday sida `\t`.
    /// * Soo celinta Gawaarida ayaa loo baxsaday sida `\r`.
    /// * Quudinta khadka ayaa loo baxsaday sidii `\n`.
    /// * Hal kudhig ayaa loo baxsaday sida `\'`.
    /// * Labo xigasho ayaa loo baxsaday sidii `\"`.
    /// * Backslash ayaa loo baxsaday sidii `\\`.
    /// * qof kasta oo ku sugan `0x20` .. `0x7e` loo dhan yahay 'Printable ASCII' kala duwan oo aan la baxsaday.
    /// * Dhamaan astaamaha kale waxaa la siiyaa baxsad hexadecimal Unicode;fiiri [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Hadal ahaan:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Si toos ah u adeegsiga `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Labaduba waxay u dhigmaan:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Adeegsiga `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Waxay soo celisaa tirada bytes `char` this u baahan tahay haddii encoded in UTF-8.
    ///
    /// tiro in of bytes had iyo jeer waa inta u dhaxaysa 1 iyo 4, loo dhan yahay.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// The damaanado nooca `&str` in waxyaabaha ay yihiin UTF-8, oo sidaas ayaan is barbardhigi kartaa oo dhererkiisuna wuxuu qaadan lahaa haddii dhibic kasta oo code waxaa matalayay sida `char` a vs in `&str` laftiisa:
    ///
    ///
    /// ```
    /// // sida chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // labadaba waxaa loo matali karaa sadex baay
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // sida &str, labadan waxaa lagu xardhay UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // waan arki karnaa inay qaataan wadarta lix baayt ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... sida &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Sooceliyaa lambarka unugyada koodhka 16-bit ah `char`-kan uu ubaahan lahaa haddii lagudiro UTF-16.
    ///
    ///
    /// Fiiri warqadaha ee [`len_utf8()`] sharaxaad ka badan fikirkan.
    /// Shaqadani waa muraayad, laakiin waxay u tahay UTF-16 halkii ay ka ahaan lahayd UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Calaamadee astaamahan sida UTF-8 oo loogu daro keydka bakteeriyada ee la bixiyay, ka dibna wuxuu soo celiyaa sublice-ka keydka oo ay ku jiraan astaamaha loo yaqaan "encoded".
    ///
    ///
    /// # Panics
    ///
    /// Panics haddii baseka kuma filna waaweyn.
    /// Kaydinta dhererka afaraad ayaa weyn oo ku filan in lagu qoro wixii `char` ah.
    ///
    /// # Examples
    ///
    /// In labada tusaale ee, 'ß' qaadataa laba bytes in encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Kayd ka dhigis aad u yar:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // AMMAANKA: `char` ma aha gaadh ah, si ay tani tahay sax ah UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Baaq fashilayo qof sida UTF-16 gelin bixiyo `u16` baseka, ka dibna ku soo laabtay subslice ku xiranyahay in ku jira dabeecadda encoded.
    ///
    ///
    /// # Panics
    ///
    /// Panics haddii baseka kuma filna waaweyn.
    /// Kaydinta dhererka 2 ayaa weyn oo ku filan in lagu qoro wixii `char` ah.
    ///
    /// # Examples
    ///
    /// Labadan tusaalooyinba, '𝕊' waxay qaadataa laba `` u16 '' si loo qori karo.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Kayd ka dhigis aad u yar:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Sooceliyaa `true` haddii `char`-kani leeyahay hantida `Alphabetic`.
    ///
    /// `Alphabetic` waxaa lagu sharaxay cutubka 4 (sifooyinka astaamaha) ee [Unicode Standard] waxaana lagu qeexay [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // jacayl waa wax badan, laakiin ma aha higgaadda
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Sooceliyaa `true` haddii `char`-kani leeyahay hantida `Lowercase`.
    ///
    /// `Lowercase` waxaa lagu sharaxay cutubka 4 (sifooyinka astaamaha) ee [Unicode Standard] waxaana lagu qeexay [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Qoraallada kala duwan ee Shiinaha iyo xarakayntu ma laha kiis, sidaa darteedna:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Sooceliyaa `true` haddii `char`-kani leeyahay hantida `Uppercase`.
    ///
    /// `Uppercase` waxaa lagu sharaxay cutubka 4 (sifooyinka astaamaha) ee [Unicode Standard] waxaana lagu qeexay [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Qoraallada kala duwan ee Shiinaha iyo xarakayntu ma laha kiis, sidaa darteedna:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Dib `true` haddii `char` this leeyahay hantida `White_Space` ah.
    ///
    /// `White_Space` waxaa lagu qeexay [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // meel aan jabin
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Sooceliyaa `true` haddii this dhergiyey `char` midkood [`is_alphabetic()`] ama [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Dib `true` haddii `char` this category ayaa guud ee codes gacanta.
    ///
    /// Koodhadhka kontoroolka (qodobbada koodhka oo leh qaybta guud ee `Cc`) ayaa lagu sharraxay Cutubka 4 (Astaamaha Astaamaha) ee [Unicode Standard] oo lagu caddeeyay [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// // U + 009C, TERMINATOR string
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Dib `true` haddii `char` this leeyahay hantida `Grapheme_Extend` ah.
    ///
    /// `Grapheme_Extend` waxaa lagu sharaxay [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] waxaana lagu qeexay [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Soocelinayaa `true` haddii kan `char` uu leeyahay mid ka mid ah qaybaha guud ee tirooyinka.
    ///
    /// Qeybaha guud ee tirooyinka (`Nd` ee lambarrada jajab tobanle, `Nl` xarfaha lambarrada u eg, iyo `No` xarfaha kale ee lambar) ayaa lagu qeexay [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Dib iterator in edbiyey khariidaynta kuwa yaryarba ah `char` this sida mid ama ka badan
    /// `char`s.
    ///
    /// Haddii `char` this ma laha khariidaynta kuwa yaryarba ah, iterator ku edbiyey isla `char` ah.
    ///
    /// Haddii `char`-kani uu leeyahay khariidad-yare mid-ka-mid ah oo ay bixiso [Unicode Character Database][ucd] [`UnicodeData.txt`], soo-celinta ayaa soo saaraysa `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Haddii `char`-kani u baahan yahay tixgelinno gaar ah (tusaale. ``Char`s badan) '' soo-celiyaha wuxuu soo saarayaa 'char' (yada) ay bixiso [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Howlgalkan waxuu u qabata khariidaynta ah shuruud la'aan harqaanka.Taasi waa, beddelka ayaa ka madax bannaan macnaha iyo luqadda.
    ///
    /// In [Unicode Standard] ah, Cutubka 4aad (Properties Character) ka hadlaysaa khariidaynta kiiska guud iyo Cutubka 3aad (Conformance) ka hadlaysaa geynta default kiiska qaab beddelidda.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Hadal ahaan:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Si toos ah u adeegsiga `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Labaduba waxay u dhigmaan:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Adeegsiga `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Mararka qaarkood natiijadu waxay ka badan tahay hal dabeecad:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Astaamaha aan lahayn mid weyn iyo mid yar ayaa isu beddelaya naftooda.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Dib iterator in edbiyey naqshadeyntu waawayn ee `char` this mid ka mid ah ama ka badan
    /// `char`s.
    ///
    /// Haddii `char`-kan uusan lahayn khariidad-weyne, soo-saaraha ayaa soo saara isla `char`.
    ///
    /// Haddii `char` this leedahay khariidaynta mid-ka-mid ah xarfo la siiyo by [Unicode Character Database][ucd] [`UnicodeData.txt`] ah, wax-soosaarkooda iterator in `char` ah.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Haddii `char`-kani u baahan yahay tixgelinno gaar ah (tusaale. ``Char`s badan) '' soo-celiyaha wuxuu soo saarayaa 'char' (yada) ay bixiso [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Howlgalkan waxuu u qabata khariidaynta ah shuruud la'aan harqaanka.Taasi waa, beddelka ayaa ka madax bannaan macnaha iyo luqadda.
    ///
    /// In [Unicode Standard] ah, Cutubka 4aad (Properties Character) ka hadlaysaa khariidaynta kiiska guud iyo Cutubka 3aad (Conformance) ka hadlaysaa geynta default kiiska qaab beddelidda.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Hadal ahaan:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Si toos ah u adeegsiga `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Labaduba waxay u dhigmaan:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Adeegsiga `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Mararka qaarkood natiijadu waxay ka badan tahay hal dabeecad:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Astaamaha aan lahayn mid weyn iyo mid yar ayaa isu beddelaya naftooda.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Xusuusin aagagga
    ///
    /// Af Turki ahaan, u dhigma 'i' ee Laatiinka waxay leedahay shan qaab halkii laga isticmaali lahaa labo:
    ///
    /// * 'Dotless': I/ı, mararka qaarna qoran ï
    /// * 'Dotted': İ/i
    ///
    /// Xusuusnow in dhibcaha yar yar ee 'i' uu la mid yahay Laatiinka.Sidaa darteed:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Qiimaha `upper_i` halkan ku tiirsan yahay luqadda qoraalka: haddii aynu ku jirno ee `en-US`, waa in ay noqon `"I"`, laakiin haddii aynu ku jirno ee `tr_TR`, waa in ay noqon `"İ"`.
    /// `to_uppercase()` tan xisaabta ku darsan meyso, sidaasna:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// wuxuu hayaa luqado kala duwan.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Wuxuu hubinayaa haddii qiimaha uu ku dhex jiro heerka ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Ka dhigayaa nuqul ka mid ah qiimaha ay ASCII sare kiiska u dhigma.
    ///
    /// Waraaqaha ASCII 'a' ilaa 'z' waxaa lagu sawiray 'A' ilaa 'Z', laakiin waraaqaha aan ahayn ASCII isma beddelin.
    ///
    /// Si aad u weyneyso qiimaha meesha, isticmaal [`make_ascii_uppercase()`].
    ///
    /// Xarfaha waaweyn ee ASCII marka lagu daro astaamaha aan ahayn ASCII, isticmaal [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Waxay nuqul ka sameysaa qiimaha ASCII kiiskeeda hoose u dhigma.
    ///
    /// warqado ASCII 'A' in 'Z' waxaa baa'bin in 'a' in 'z', laakiin waraaqaha non-ASCII waa iska beddelin.
    ///
    /// Si aad kuwa yaryarba qiimaha ku-meel, isticmaali [`make_ascii_lowercase()`].
    ///
    /// Si aad kuwa yaryarba characters ASCII lagu daro characters non-ASCII, isticmaali [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Wuxuu hubinayaa in laba qiime ay yihiin isku dheelitir la'aanta kiiska ASCII.
    ///
    /// U dhiganta `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Noocani wuxuu u rogaa ASCII kiisa sare ee u dhigma meesha.
    ///
    /// Waraaqaha ASCII 'a' ilaa 'z' waxaa lagu sawiray 'A' ilaa 'Z', laakiin waraaqaha aan ahayn ASCII isma beddelin.
    ///
    /// Si aad u soo ceshato qiimo cusub oo kore ah adigoon wax ka badalin midka jira, isticmaal [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Noocani wuxuu u rogaa ASCII kiisa hoose ee u dhigma goobta.
    ///
    /// warqado ASCII 'A' in 'Z' waxaa baa'bin in 'a' in 'z', laakiin waraaqaha non-ASCII waa iska beddelin.
    ///
    /// Si aad u soo laaban a qiimaha cusub lowercased aan bedelayaan ka mid ah ee hadda jira, isticmaali [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Checks haddii qiimaha waa ASCII qof ah higgaadda:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ama
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Checks haddii qiimaha waa ASCII ah xarfo qof:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Wuxuu hubinayaa haddii qiimuhu yahay dabeecad yar oo ASCII ah:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Wuxuu hubinayaa haddii qiimaha uu yahay astaamaha xarfaha xarfaha ee ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ama
    /// - U + 0061 'a' ..=U + 007A 'z', ama
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Wuxuu hubiyaa haddii qiimuhu uu yahay lambar tobanle ah ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Wuxuu hubinayaa haddii qiimuhu uu yahay lambar laba-geesoodle ah oo ASCII ah:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ama
    /// - U + 0041 'A' ..=U + 0046 'F', ama
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Wuxuu hubiyaa haddii qiimaha uu yahay astaamaha ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ama
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ama
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, ama
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Wuxuu hubinayaa haddii qiimaha uu yahay astaamaha muuqaalka ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Wuxuu hubiyaa haddii qiimuhu yahay dabeecadda bedka ASCII:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FOOM FEED, ama U + 000D SOO NOQOSHADA.
    ///
    /// Rust isticmaalaa aasaasiga WhatWG ee Standard ee [definition of ASCII whitespace][infra-aw].Waxaa jira dhowr qeexitaan kale ee isticmaalka ballaaran.
    /// Tusaale ahaan, [the POSIX locale][pct] waxaa ka mid ah U + 000B VERTICAL TAB iyo sidoo kale dhammaan astaamaha kor ku xusan, laakiin - isla qeexitaankan oo keliya-[xeerka asalka u ah "field splitting" ee Bourne shell][bfs] wuxuu tixgelinayaa *keliya* SPACE, HORIZONTAL TAB, iyo LINE LAGU QUUDIYO sida barta cad.
    ///
    ///
    /// Haddii aad qoraal barnaamij in ka arrinsashada doonaa format file jira, hubi waxa qeexidda format in ee whitespace waa hor inta aadan isticmaalin shaqo this.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Wuxuu hubinayaa haddii qiimaha uu yahay astaamaha xakamaynta ASCII:
    /// U + 0000 NUL ..=U + 001F CUTUB SEPARATOR, ama U + 007F tirtirto.
    /// Ogsoonow in astaamaha badka ASCII badankood ay yihiin jilayaal kontaroola, laakiin SPACE maahan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Baaq ah qiimaha u32 cayriin sida UTF-8 galay baseka byte bixiyo, ka dibna ku soo laabtay subslice ku xiranyahay in ku jira dabeecadda encoded.
///
///
/// Si ka duwan `char::encode_utf8`, habkan ayaa sidoo kale ka qabtaa codepoints kala duwan gaadh.
/// (Abuuridda `char` a kala duwan gaadh waa UB.) Natiijadu waxay tahay ansax [generalized UTF-8] laakiin aan ansax UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics haddii baseka kuma filna waaweyn.
/// Kaydinta dhererka afaraad ayaa weyn oo ku filan in lagu qoro wixii `char` ah.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Wuxuu qirayaa qiime u32 ah oo cayriin ah sida UTF-16 oo loo geliyay keydka `u16`, ka dibna wuxuu soo celinayaa sublice-ka keydka oo ay ku jiraan astaamaha loo yaqaan 'encoded'.
///
///
/// Si ka duwan `char::encode_utf16`, habkan ayaa sidoo kale ka qabtaa codepoints kala duwan gaadh.
/// (Abuuritaanka `char` ee aagga beddelka waa UB.)
///
/// # Panics
///
/// Panics haddii baseka kuma filna waaweyn.
/// Kaydinta dhererka 2 ayaa weyn oo ku filan in lagu qoro wixii `char` ah.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // AMMAANKA: jeeg gacanta kasta haddii ay jiraan gelinno ku filan si ay u qoraan galay
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ayaa soo dhacaya
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Diyaarado dheeri ah ayaa jebiya ku-meelgaar.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}