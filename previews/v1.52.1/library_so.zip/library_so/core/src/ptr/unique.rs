use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Duub ku wareegsan `*mut T` ceyriin aan waxba ka jirin oo tilmaamaya in cidda leh duubkan uu leeyahay tixraacaha.
/// Faa'iido u leh dhismaha soo-saarista sida `Box<T>`, `Vec<T>`, `String`, iyo `HashMap<K, V>`.
///
/// Si ka duwan `*mut T`, `Unique<T>` dhaqmo "as if" waxay ahaayeen tusaale ahaan ah `T`.
/// Waxay fulisaa `Send`/`Sync` haddii `T` uu yahay `Send`/`Sync`.
/// Waxa kale oo ay tilmaamaysaa nooca damaanado aliasing xoog tusaale ah `T` filan kartaa:
/// tixraaca ee tilmaamaha waa in aan la bedeli aan Jid gaar ah si ay lahaanshaha gaar ah.
///
/// Haddii aadan hubin inay sax tahay inaad u isticmaasho `Unique` ujeeddooyinkaaga, tixgeli inaad isticmaasho `NonNull`, oo leh semantics daciif ah.
///
///
/// Si ka duwan `*mut T`, tilmaame waa inuu had iyo jeer noqdaa mid aan waxba ka jirin, xitaa haddii tilmaameha aan waligiis laga gudbin.
/// Tani waa si enumyadu ay ugu adeegsadaan qiimahan mamnuuca ah midabtakoor-`Option<Unique<T>>` wuxuu leegyahay cabirka `Unique<T>`.
/// Si kastaba ha noqotee tilmaamuhu weli wuu sii laalaadi karaa haddii aan laga gudbin.
///
/// Si ka duwan `*mut T`, `Unique<T>` waa covariant badan `T`.
/// Tani waa in mar kasta noqon saxda ah ee nooc kasta oo tiiriyaa shuruudaha aliasing Gaarka ah ee.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: sumadeeyahaan wax cawaaqib ah kuma lahan kala duwanaanshaha, laakiin waa lagama maarmaan
    // daaqada si loo fahmo inaan si macquul ah u leenahay `T`.
    //
    // Wixii faahfaahin ah, fiiri:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` tilmaamayaasha waa `Send` haddii `T` uu yahay `Send` maxaa yeelay xogta ay tixraacayaan waa mid aan habeysaneyn.
/// Xusuusnow in qofkan badalaya ee aan is bedelin uusan awoodin nidaamka nooca;soosaarida iyadoo la adeegsanayo `Unique` waa inay fulisaa.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` tilmaamayaasha waa `Sync` haddii `T` uu yahay `Sync` maxaa yeelay xogta ay tixraacayaan waa mid aan habeysaneyn.
/// Xusuusnow in qofkan badalaya ee aan is bedelin uusan awoodin nidaamka nooca;soosaarida iyadoo la adeegsanayo `Unique` waa inay fulisaa.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Waxay abuurtaa `Unique` cusub oo ruxmaya, laakiin si fiican isugu habboon.
    ///
    /// Tani waxay faa'iido u leedahay bilowga noocyada caajisnimada u qoondeeya, sida `Vec::new` ay sameyso.
    ///
    /// Xusuusnow in qiimaha tilmaamaha ay suuragal tahay inuu tilmaamo tilmaame sax ah oo ku socda `T`, taas oo macnaheedu yahay in tan loo isticmaali karin inay tahay qiimaha sentinel "not yet initialized".
    /// Noocyada caajisnimada loo qoondeeyo waa inay la socdaan bilowga qaab kale.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // AMMAANKA: mem::align_of() laabtay sax ah, tilmaamaha aan waxba a.Ku
        // shuruudaha loogu yeero new_unchecked() sidaas ayaa lagu xushmeeyaa.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Waxay abuurtaa `Unique` cusub.
    ///
    /// # Safety
    ///
    /// `ptr` waa inuu noqdaa mid aan waxba ka jirin
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `ptr` uusan waxba ka jirin.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Waxay abuurtaa `Unique` cusub haddii `ptr` aan waxba ka jirin.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BADBAADADA: Tilmaame ayaa horey loo hubiyey oo waxba kama jiraan.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Heshaa tilmaamaha aasaasiga ah ee `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferences content.
    ///
    /// Nolosha ka dhalataa waxay ku xidhan tahay iskiis markaa tani waxay u dhaqantaa "as if" runtiina waxay ahayd tusaale ka mid ah T oo la amaahdo.
    /// Haddii loo baahdo nolol dheer (unbound), isticmaal `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu la kulmayo dhammaan
        // shuruudaha tixraaca.
        unsafe { &*self.as_ptr() }
    }

    /// Iskudhaf ahaan ayaa u qoraya waxyaabaha ku jira.
    ///
    /// Nolosha ka dhalataa waxay ku xidhan tahay iskiis markaa tani waxay u dhaqantaa "as if" runtiina waxay ahayd tusaale ka mid ah T oo la amaahdo.
    /// Haddii loo baahan yahay a noolaa dheer (unbound), isticmaali `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu la kulmayo dhammaan
        // shuruudaha tixraaca isbeddelaya.
        unsafe { &mut *self.as_ptr() }
    }

    /// Ku tuuraya tilmaame nooc kale ah.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // BADBAADADA: Unique::new_unchecked() wuxuu abuuraa mid cusub iyo baahiyo cusub
        // tilmaamaha la siiyay si uusan null u noqon.
        // Maaddaama aan is-dhaafinno tilmaame ahaan, waxba kama noqon karaan.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // AMMAANKA: Tixraac la beddeli karo ma noqon karo mid aan waxba ka jirin
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}