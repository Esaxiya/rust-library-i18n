use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Soocelinayaa `true` haddii tilmaame uusan waxba kajirin.
    ///
    /// Fiiro gaar ah in noocyada unsized leeyihiin tilmaamo badan oo waxba kama suurto gal ah, sida kaliya pointer xogta ceeriin waxaa loo arkaa, ma dhererka, vtable, iwm
    /// Sidaa darteed, laba tilmaamood oo aan waxba ka jirin ayaa laga yaabaa inaanay isbarbar dhigin midba midka kale.
    ///
    /// ## Dhaqanka inta lagu jiro qiimaynta const
    ///
    /// Marka shaqo this waxaa loo isticmaalaa inta lagu guda jiro qiimaynta const, ku soo celi laga yaabaa `false` for tilmaamo in soo baxayso in waxba at Runtime.
    /// Gaar ahaan, marka tilmaame xusuusta qaar ka mid ah la dheelitiro wixii ka baxsan xadka iyada oo tilmaamaha soo baxa uu yahay mid aan waxba ka jirin, shaqadu wali way soo noqon doontaa `false`.
    ///
    /// Ma jirto waddo ay CTFE ku ogaan karto booska saxda ah ee xusuustaas, sidaa darteed ma sheegi karno haddii tilmaamtu aanu waxba ka jirin iyo in kale.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Isbarbardhigga via kabka ah in pointer khafiif ah, tilmaamo si baruurta ayaa ka fiirsaneysa inay kaliya ay qeyb ka "data" waayo, waxba kama-raag.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Ku tuuraya tilmaame nooc kale ah.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Ku-soo-koobid (suurtogal ahaan ballaaran) tilmaame galay cinwaanka iyo qaybaha metadata.
    ///
    /// Tilmaamaha ayaa dib loo dhisi karaa [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Sooceliyaa `None` haddii tilmaamaha uu yahay waxba kama, ama haddii kale celinta tixraaca la wadaago in ay qiimaha ku duudduubtay oo `Some`.Haddii qiimaha uu noqon karo mid aan la ogaan karin, [`as_uninit_ref`] waa in la adeegsadaa halkii.
    ///
    /// Waayo, dhigiisa mutable arki [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Markaad wacaysid qaabkan, waa inaad hubisaa in *midkood* tilmaamaha uu yahay NULL *ama* dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * tilmaamaha waa in si fiican la safan.
    ///
    /// * Waa inuu noqdaa "dereferencable" macnaha lagu qeexay [the module documentation].
    ///
    /// * Tilmaameyuhu waa inuu tilmaamaa tusaale bilow ah oo ah `T`.
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inuusan is beddelin (marka laga reebo gudaha `UnsafeCell`).
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    /// (Qeybta ku saabsan in la bilaabo weli si buuxda looma go'aamin, laakiin illaa iyo inta laga gaarayo, habka kaliya ee nabdoon ayaa ah in la hubiyo in dhab ahaan la bilaabay.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Nooc aan la hubin
    ///
    /// Haddii aad hubto in tilmaamuhu uusan waligiis waxba noqon karin oo uu raadinayo nooc ka mid ah `as_ref_unchecked` oo soo celiya `&T` halkii uu ka noqon lahaa `Option<&T>`, ogow inaad si toos ah uga diidi karto tilmaanta.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu ansax ku yahay a
        // tixraaca haddii aanay waxba.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Sooceliyaa `None` haddii tilmaamuhu uusan waxba kajirin, ama haddii kale soocelinayo tixraac wadaag ah qiimaha ku duudduuban `Some`.
    /// Marka la barbardhigo [`as_ref`], waxaa looga baahan yahay ma aha in qiimaha ay leedahay in la initialized.
    ///
    /// Waayo, dhigiisa mutable arki [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Markaad wacaysid qaabkan, waa inaad hubisaa in *midkood* tilmaamaha uu yahay NULL *ama* dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * tilmaamaha waa in si fiican la safan.
    ///
    /// * Waa inuu noqdaa "dereferencable" macnaha lagu qeexay [the module documentation].
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inuusan is beddelin (marka laga reebo gudaha `UnsafeCell`).
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu la kulmayo dhammaan
        // shuruudaha tixraaca.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Xisaabinta dheelitirka tilmaame.
    ///
    /// `count` wuxuu ku jiraa unugyada T;Tusaale ahaan, `count` ee 3 wuxuu u taagan yahay tilmaam tilmaame ah oo ah `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Haddii mid ka mid ah shuruudaha soo socda la jebiyo, natiijadu waa Habdhaqan aan La Qeexin:
    ///
    /// * Labada tilmaame ee bilaabaya iyo natiijada ka soo baxdaa waa inay ahaadaan kuwo xuduud ama hal baati dhaafiya dhamaadka isla sheyga loo qoondeeyay.
    /// Ogsoonow in Rust, isbeddel kasta oo (stack-allocated) ah loo tixgelinayo shey gaar ah oo loo qoondeeyey.
    ///
    /// * Isugeynta xisaabta,**baytiyada**, ma buuxin karto `isize`.
    ///
    /// * Jaangooyada oo ku jirta xudduuda kuma tiirsanaan karto "wrapping around" meesha cinwaanka.Taasi waa, wadarta saxnaanta aan dhamaadka lahayn,**ee bytes** waa inay ku habboon tahay adeegsi.
    ///
    /// Isku-dubaridaha iyo maktabadda caadiga ahi guud ahaan waxay isku dayaan inay hubiyaan in qoondayntu aysan waligood gaadhin cabir ay ka cabir leedahay.
    /// Tusaale ahaan, `Vec` iyo `Box` waxay hubinayaan inaysan waligood qoondeyn wax ka badan `isize::MAX` bytes, sidaa darteed `vec.as_ptr().add(vec.len())` marwalba waa aamin.
    ///
    /// dhufto ee intooda badan aasaas xitaa ma dhisi karaan qoondaynta oo caynkaas ah.
    /// Tusaale ahaan, ma yaqaan madal 64-bit weligiis uma shaqayn karo codsiga 2 <sup>63</sup> bytes ay sabab u tahay xadeynta page-miiska ama qaybsama meel cinwaanka.
    /// Si kastaba ha noqotee, qaar ka mid ah aaladaha 32-bit iyo 16-bit ayaa laga yaabaa inay si guul leh ugu adeegaan codsi ka badan `isize::MAX` bytes oo leh waxyaabo ay ka mid yihiin Kordhinta Cinwaanka Jirka.
    ///
    /// Sidan oo kale, xusuusta si toos ah looga soo qaatay qoondeeyayaasha ama faylalka khariidadaha xusuusta *ayaa laga yaabaa inay* aad u ballaaran tahay oo lagu maareeyo shaqadan
    ///
    /// Ka feker inaad isticmaasho [`wrapping_offset`] halkii ay ku adkeyn lahaayeen caqabadahaani.
    /// Faa'iidada kaliya ee habkani leeyahay ayaa ah inay awood u siiso isku-dubba-uruurinta dagaal badan.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `offset`.
        // Tilmaamaha la helay ayaa ku habboon qorista maaddaama soo wacaha uu dammaanad ka qaadayo inuu tilmaamayo isla shayga loo qoondeeyay sida `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Waxay xisaabisaa isugeynta miisaanka tilmaamaha iyadoo la adeegsanaayo isugeynta xisaabta.
    /// `count` wuxuu ku jiraa unugyada T;Tusaale ahaan, `count` ee 3 wuxuu u taagan yahay tilmaam tilmaame ah oo ah `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Hawlgalkani laftiisu had iyo jeer waa ammaan, laakiin adeegsiga tilmaamaha ka soo baxa maaha.
    ///
    /// Tilmaamaha soo baxay ayaa wali ku dhagan isla shayga loo qoondeeyay ee `self` tilmaamayo.
    /// * ** Looma isticmaali karo si loo helo shay kale oo loo qoondeeyay.Ogsoonow in Rust, isbeddel kasta oo (stack-allocated) ah loo tixgelinayo shey gaar ah oo loo qoondeeyey.
    ///
    /// Si kale haddii loo dhigo, `let z = x.wrapping_offset((y as isize) - (x as isize))`*ma* dhigto `z` si la mid ah `y` xitaa haddii aan u qaadanno in `T` uu leeyahay cabbirka `1` oo uusan buux dhaafin karin: `z` weli wuxuu ku dhegan yahay shayga `x` uu ku xiran yahay, dejintana waa dhaqan aan la qeexin mooyee `x` iyo `y` dhibic isla sheyga loo qoondeeyay.
    ///
    /// Marka la barbar dhigo [`offset`], habkan asal ahaan dib looga baahan yahay negaado gudahood wax la mid ah loo qoondeeyey: [`offset`] waa Habdhaqan undefined deg deg ah marka xuduudaha wax isgoyska;`wrapping_offset` waxay soo saartaa tilmaame laakiin wali waxay u horseedaa Habdhaqan aan la qeexin haddii tilmaame laga diro marka uu xad-dhaafka ka yahay shayga uu ku xiran yahay.
    /// [`offset`] in la si fiican filaayo in karaa iyo waa sidan ka fiican ee code qaab-xasaasi ah.
    ///
    /// Jeegga dib u dhacay wuxuu kaliya tixgeliyaa qiimaha tilmaamaha laga reebay, ma aha qiyamka dhexdhexaadka ah ee la isticmaalay inta lagu guda jiray xisaabinta natiijada ugu dambeysa.
    /// Tusaale ahaan, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` wuxuu had iyo jeer la mid yahay `x`.In si kale loo dhigo, ka tago shayga loo qoondeeyay ka dibna dib u soo galaya waxaa ka dib waa la ogol yahay.
    ///
    /// Haddii aad u baahan tahay in xuduudaha wax cross, tilmaamaha si abyoonaha ku tuur iyo xisaabta waxaa ku sameeyaan.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// // Kabiro adigoo adeegsanaya tilmaame cayriin ah marka lagu daro laba walxood
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // BADBAADADA: `arith_offset` intrinsic ma laha shuruudo lagu wici karo.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Sooceliyaa `None` haddii tilmaamuhu uusan waxba kajirin, ama haddii kale uu soo celiyo tixraac u gaar ah qiimaha ku duuban `Some`.Haddii qiimaha la uninitialized laga yaabaa, [`as_uninit_mut`] waa in la isticmaalaa halkii.
    ///
    /// Wixii dhigga la wadaago eeg [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Markaad wacaysid qaabkan, waa inaad hubisaa in *midkood* tilmaamaha uu yahay NULL *ama* dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * tilmaamaha waa in si fiican la safan.
    ///
    /// * Waa inuu noqdaa "dereferencable" macnaha lagu qeexay [the module documentation].
    ///
    /// * Tilmaameyuhu waa inuu tilmaamaa tusaale bilow ah oo ah `T`.
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inaan laga helin (akhrin ama qorin) tilmaamaha kale.
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    /// (Qeybta ku saabsan in la bilaabo weli si buuxda looma go'aamin, laakiin illaa iyo inta laga gaarayo, habka kaliya ee nabdoon ayaa ah in la hubiyo in dhab ahaan la bilaabay.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Waxay daabici doontaa: "[4, 2, 3]".
    /// ```
    ///
    /// # Nooc aan la hubin
    ///
    /// Haddii aad hubto in tilmaamuhu uusan waligiis waxba noqon karin oo uu raadinayo nooc ka mid ah `as_mut_unchecked` oo soo celiya `&mut T` halkii uu ka noqon lahaa `Option<&mut T>`, ogow inaad si toos ah uga diidi karto tilmaanta.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Waxay daabici doontaa: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu ansax yahay
        // tixraac la beddeli karo haddii aanu waxba ka jirin
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Sooceliyaa `None` haddii tilmaamuhu uusan waxba kajirin, ama haddii kale uu soo celiyo tixraac u gaar ah qiimaha ku duuban `Some`.
    /// Marka la barbardhigo [`as_mut`], waxaa looga baahan yahay ma aha in qiimaha ay leedahay in la initialized.
    ///
    /// Wixii dhigga la wadaago eeg [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Markaad wacaysid qaabkan, waa inaad hubisaa in *midkood* tilmaamaha uu yahay NULL *ama* dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * tilmaamaha waa in si fiican la safan.
    ///
    /// * Waa inuu noqdaa "dereferencable" macnaha lagu qeexay [the module documentation].
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inaan laga helin (akhrin ama qorin) tilmaamaha kale.
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu la kulmayo dhammaan
        // shuruudaha tixraaca.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Sooceliyaa haddii laba tilmaame loo damaanad qaaday inay siman yihiin.
    ///
    /// At Runtime this dhaqmo shaqada sida `self == other`.
    /// Si kastaba ha ahaatee, in xaaladaha qaar ka mid ah (tusaale ahaan, qiimaynta ururiso-time), waxa markasta suurtagal ma aha in la ogaado sinaanta laba tilmaamo, si shaqo this unkay noqon karaa `false` for tilmaamo in ka dib run ahaantii soo baxayso in loo siman yahay.
    ///
    /// Laakiin markay soo noqoto `true`, tilmaamayaasha ayaa la damaanad qaadayaa inay siman yihiin.
    ///
    /// Shaqadani waa muraayada [`guaranteed_ne`], laakiin maaha wax iska soo horjeedkeeda.Waxaa jira lala barbardhigo pointer kaas oo labada hawlaha soo laaban `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Qiimaha soo-celinta ayaa is beddeli kara iyadoo ku xiran nooca isku-darka iyo nambarka aan aaminka ahayn waxaa laga yaabaa inuusan ku tiirsaneyn natiijada shaqadan ee maqalka.
    /// Waxaa lagugula talinayaa inaad kaliya u isticmaasho shaqadan waxqabadyada waxqabad ee meesha qiimaha x00X ee soo celinta shaqadan aysan saameyn ku yeelan doonin natiijada, laakiin kaliya waxqabadka.
    /// Cawaaqib xumada ka dhalanaysa adeegsiga habkan si loo sameeyo wakhti-socod iyo waqti-ururin koodh ah oo u dhaqma si ka duwan si kale looma sahamin.
    /// Habkani waa in aan loo isticmaalin in lagu soo bandhigo kala duwanaanshaha noocan oo kale ah, waana in sidoo kale aan la xasilin ka hor intaanan si fiican u fahmin arrintan.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Soocelinayaa haddii laba tilmaamood la hubo in loo sineyn doono.
    ///
    /// Waqtiga ay shaqeyneyso shaqadan waxay u dhaqmeysaa sida `self != other`.
    /// Si kastaba ha noqotee, xaaladaha qaarkood (tusaale ahaan, qiimeynta isku-darka-waqtiga), had iyo jeer suurtagal maahan in la go'aamiyo sinnaan la'aanta laba tilmaame, markaa shaqadani waxay si xushmad leh u soo celin kartaa `false` tilmaamayaasha oo markii dambe runti isu beddelaya mid aan sinnayn.
    ///
    /// Laakiin markay soo noqoto `true`, tilmaamayaasha ayaa la damaanad qaadayaa inaysan sinnayn.
    ///
    /// Shaqadani waa muraayada [`guaranteed_eq`], laakiin maaha wax iska soo horjeedkeeda.Waxaa jira isbarbardhigyo tilmaame ah oo labada hawloodba soo celiyaan `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Qiimaha soo-celinta ayaa is beddeli kara iyadoo ku xiran nooca isku-darka iyo nambarka aan aaminka ahayn waxaa laga yaabaa inuusan ku tiirsaneyn natiijada shaqadan ee maqalka.
    /// Waxaa lagugula talinayaa inaad kaliya u isticmaasho shaqadan waxqabadyada waxqabad ee meesha qiimaha x00X ee soo celinta shaqadan aysan saameyn ku yeelan doonin natiijada, laakiin kaliya waxqabadka.
    /// Cawaaqib xumada ka dhalanaysa adeegsiga habkan si loo sameeyo wakhti-socod iyo waqti-ururin koodh ah oo u dhaqma si ka duwan si kale looma sahamin.
    /// Habkani waa in aan loo isticmaalin in lagu soo bandhigo kala duwanaanshaha noocan oo kale ah, waana in sidoo kale aan la xasilin ka hor intaanan si fiican u fahmin arrintan.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Wuxuu xisaabiyaa masaafada u dhexeysa laba tilmaame.Qiimaha la soo celiyey wuxuu ku jiraa unugyada T: masaafada baytes waxaa loo qaybiyaa `mem::size_of::<T>()`.
    ///
    /// Shaqadani waa rogaanshaha [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Haddii mid ka mid ah shuruudaha soo socda la jebiyo, natiijadu waa Habdhaqan aan La Qeexin:
    ///
    /// * Labada tilmaame ee bilaabaya iyo kuwa kaleba waa inay ahaadaan kuwo soohdimaha ama hal baati dhaafsan dhammaadka isla shayga loo qoondeeyay.
    /// Ogsoonow in Rust, isbeddel kasta oo (stack-allocated) ah loo tixgelinayo shey gaar ah oo loo qoondeeyey.
    ///
    /// * Labada tilmaame waa in *laga soo dheegtay* tilmaamaha isla shayga.
    ///   (Tusaale hoos ka eeg.)
    ///
    /// * Masaafada udhaxeysa tilmaamayaasha, bytes, waa inay ahaataa isku dhufasho sax ah oo cabbirka `T` ah.
    ///
    /// * Masaafada udhaxeysa tilmaamayaasha,**bytes**, ma buuxin karto `isize`.
    ///
    /// * Masaafada ujirta xudduuda kuma tiirsanaan karto "wrapping around" meesha cinwaanka.
    ///
    /// Noocyada 'Rust' waligood kama weynaadaan `isize::MAX` iyo qoondaynta Rust waligood kuma duuban agagaaraha cinwaanka, markaa laba tilmaameyaal oo qiime ahaan u dhigma nooc kasta oo ah Rust nooca `T` ayaa had iyo jeer qancin doona labada xaaladood ee ugu dambeeya.
    ///
    /// Maktabadda caadiga ah sidoo kale guud ahaan hubisaa in loo qoondeeyey inuusan weligiisna gaari size a halkaas oo ah mowjadda walaac.
    /// Tusaale ahaan, `Vec` iyo `Box` waxay hubiyaan inaysan waligood qoondeyn wax ka badan `isize::MAX` bytes, sidaa darteed `ptr_into_vec.offset_from(vec.as_ptr())` had iyo jeer wuu qanciyaa labadii xaaladood ee ugu dambeeyay.
    ///
    /// Meelaha badankood aasaasi ahaan xitaa ma dhisi karaan qoondaynta intaa le'eg.
    /// Tusaale ahaan, ma yaqaan madal 64-bit weligiis uma shaqayn karo codsiga 2 <sup>63</sup> bytes ay sabab u tahay xadeynta page-miiska ama qaybsama meel cinwaanka.
    /// Si kastaba ha noqotee, qaar ka mid ah aaladaha 32-bit iyo 16-bit ayaa laga yaabaa inay si guul leh ugu adeegaan codsi ka badan `isize::MAX` bytes oo leh waxyaabo ay ka mid yihiin Kordhinta Cinwaanka Jirka.
    /// Sidan oo kale, xusuusta si toos ah looga soo qaatay qoondeeyayaasha ama faylalka khariidadaha xusuusta *ayaa laga yaabaa inay* aad u ballaaran tahay oo lagu maareeyo shaqadan
    /// (Xusuusnow [`offset`] iyo [`add`] sidoo kale waxay leeyihiin xaddidaad isku mid ah oo markaa looma isticmaali karo qoondeynta intaa le'eg.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Hawshan panics haddii `T` uu yahay Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Khaldan* adeegsi:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Samee ptr2_other "alias" ah ptr2, laakiin ka soo jeeda ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Maaddaama ptr2_other iyo ptr2 ay ka soo jeedaan tilmaamayaal ilaa walxo kala duwan, xisaabinta jaangooyooyinkoodu waa dabeecad aan la qeexin, in kasta oo ay isla cinwaanka tilmaamayaan!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Dhaqanka undefined
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Xisaabinta dheelitirka tilmaame (ku habboonaanta `.offset(count as isize)`).
    ///
    /// `count` wuxuu ku jiraa unugyada T;Tusaale ahaan, `count` ee 3 wuxuu u taagan yahay tilmaam tilmaame ah oo ah `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Haddii mid ka mid ah shuruudaha soo socda la jebiyo, natiijadu waa Habdhaqan aan La Qeexin:
    ///
    /// * Labada tilmaame ee bilaabaya iyo natiijada ka soo baxdaa waa inay ahaadaan kuwo xuduud ama hal baati dhaafiya dhamaadka isla sheyga loo qoondeeyay.
    /// Ogsoonow in Rust, isbeddel kasta oo (stack-allocated) ah loo tixgelinayo shey gaar ah oo loo qoondeeyey.
    ///
    /// * Isugeynta xisaabta,**baytiyada**, ma buuxin karto `isize`.
    ///
    /// * Jaangooyada oo ku jirta xudduuda kuma tiirsanaan karto "wrapping around" meesha cinwaanka.Taasi waa, wadarta saxnaanta aan dhammaadka lahayn waa inay ku habboon tahay `usize`.
    ///
    /// Isku-dubaridaha iyo maktabadda caadiga ahi guud ahaan waxay isku dayaan inay hubiyaan in qoondayntu aysan waligood gaadhin cabir ay ka cabir leedahay.
    /// Tusaale ahaan, `Vec` iyo `Box` waxay hubinayaan inaysan waligood qoondeyn wax ka badan `isize::MAX` bytes, sidaa darteed `vec.as_ptr().add(vec.len())` marwalba waa aamin.
    ///
    /// dhufto ee intooda badan aasaas xitaa ma dhisi karaan qoondaynta oo caynkaas ah.
    /// Tusaale ahaan, ma yaqaan madal 64-bit weligiis uma shaqayn karo codsiga 2 <sup>63</sup> bytes ay sabab u tahay xadeynta page-miiska ama qaybsama meel cinwaanka.
    /// Si kastaba ha noqotee, qaar ka mid ah aaladaha 32-bit iyo 16-bit ayaa laga yaabaa inay si guul leh ugu adeegaan codsi ka badan `isize::MAX` bytes oo leh waxyaabo ay ka mid yihiin Kordhinta Cinwaanka Jirka.
    ///
    /// Sidan oo kale, xusuusta si toos ah looga soo qaatay qoondeeyayaasha ama faylalka khariidadaha xusuusta *ayaa laga yaabaa inay* aad u ballaaran tahay oo lagu maareeyo shaqadan
    ///
    /// Ka feker inaad isticmaasho [`wrapping_add`] halkii ay ku adkeyn lahaayeen caqabadahaani.
    /// Faa'iidada kaliya ee habkani leeyahay ayaa ah inay awood u siiso isku-dubba-uruurinta dagaal badan.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Xisaabinta dheelitirka tilmaamaha (ku habboonaanta `` .offset ((u tiri sidii isize).wrapping_neg())`)).
    ///
    /// `count` wuxuu ku jiraa unugyada T;Tusaale ahaan, `count` ee 3 wuxuu u taagan yahay tilmaam tilmaame ah oo ah `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Haddii mid ka mid ah shuruudaha soo socda la jebiyo, natiijadu waa Habdhaqan aan La Qeexin:
    ///
    /// * Labada tilmaame ee bilaabaya iyo natiijada ka soo baxdaa waa inay ahaadaan kuwo xuduud ama hal baati dhaafiya dhamaadka isla sheyga loo qoondeeyay.
    /// Ogsoonow in Rust, isbeddel kasta oo (stack-allocated) ah loo tixgelinayo shey gaar ah oo loo qoondeeyey.
    ///
    /// * Xisaabinta xisaabta kama badnaan karto `isize::MAX`**bytes**.
    ///
    /// * The mowjadda isagoo soohdin kuma tiirsanaan karto "wrapping around" meel cinwaanka.Taasi waa, wadarta saxnaanta aan dhamaadka lahayn waa inay ku habboon tahay adeegsiga.
    ///
    /// Isku-dubaridaha iyo maktabadda caadiga ahi guud ahaan waxay isku dayaan inay hubiyaan in qoondayntu aysan waligood gaadhin cabir ay ka cabir leedahay.
    /// Tusaale ahaan, `Vec` iyo `Box` waxay hubinayaan inaysan waligood qoondeyn wax ka badan `isize::MAX` bytes, sidaa darteed `vec.as_ptr().add(vec.len()).sub(vec.len())` marwalba waa aamin.
    ///
    /// dhufto ee intooda badan aasaas xitaa ma dhisi karaan qoondaynta oo caynkaas ah.
    /// Tusaale ahaan, ma yaqaan madal 64-bit weligiis uma shaqayn karo codsiga 2 <sup>63</sup> bytes ay sabab u tahay xadeynta page-miiska ama qaybsama meel cinwaanka.
    /// Si kastaba ha noqotee, qaar ka mid ah aaladaha 32-bit iyo 16-bit ayaa laga yaabaa inay si guul leh ugu adeegaan codsi ka badan `isize::MAX` bytes oo leh waxyaabo ay ka mid yihiin Kordhinta Cinwaanka Jirka.
    ///
    /// Sidan oo kale, xusuusta si toos ah looga soo qaatay qoondeeyayaasha ama faylalka khariidadaha xusuusta *ayaa laga yaabaa inay* aad u ballaaran tahay oo lagu maareeyo shaqadan
    ///
    /// Ka feker inaad isticmaasho [`wrapping_sub`] halkii ay ku adkeyn lahaayeen caqabadahaani.
    /// Faa'iidada kaliya ee habkani leeyahay ayaa ah inay awood u siiso isku-dubba-uruurinta dagaal badan.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Waxay xisaabisaa isugeynta miisaanka tilmaamaha iyadoo la adeegsanaayo isugeynta xisaabta.
    /// (ku habboonaanta `.wrapping_offset(count as isize)`)
    ///
    /// `count` wuxuu ku jiraa unugyada T;Tusaale ahaan, `count` ee 3 wuxuu u taagan yahay tilmaam tilmaame ah oo ah `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Hawlgalkani laftiisu had iyo jeer waa ammaan, laakiin adeegsiga tilmaamaha ka soo baxa maaha.
    ///
    /// Tilmaamaha soo baxay ayaa wali ku dhagan isla shayga loo qoondeeyay ee `self` tilmaamayo.
    /// * ** Looma isticmaali karo si loo helo shay kale oo loo qoondeeyay.Ogsoonow in Rust, isbeddel kasta oo (stack-allocated) ah loo tixgelinayo shey gaar ah oo loo qoondeeyey.
    ///
    /// Si kale haddii loo dhigo, `let z = x.wrapping_add((y as usize) - (x as usize))`*ma* dhigto `z` si la mid ah `y` xitaa haddii aan u qaadanno in `T` uu leeyahay cabbirka `1` oo uusan buux dhaafin karin: `z` weli wuxuu ku dhegan yahay shayga `x` uu ku xiran yahay, dejintana waa dhaqan aan la qeexin mooyee `x` iyo `y` dhibic galay wax la mid ah loo qoondeeyey.
    ///
    /// Marka la barbar dhigo [`add`], habkan asal ahaan dib looga baahan yahay negaado gudahood wax la mid ah loo qoondeeyey: [`add`] waa Habdhaqan undefined deg deg ah marka xuduudaha wax isgoyska;`wrapping_add` saarta Daliil laakiin weli raadad si Dhaqanka undefined haddii tilmaamaha la dereferenced marka ay tahay out-of-soohdimaha shayga waxaa ku lifaaqan.
    /// [`add`] in la si fiican filaayo in karaa iyo waa sidan ka fiican ee code qaab-xasaasi ah.
    ///
    /// Jeegga dib u dhacay wuxuu kaliya tixgeliyaa qiimaha tilmaamaha laga reebay, ma aha qiyamka dhexdhexaadka ah ee la isticmaalay inta lagu guda jiray xisaabinta natiijada ugu dambeysa.
    /// Tusaale ahaan, `x.wrapping_add(o).wrapping_sub(o)` mar walba waa isku mid sida `x`.Si kale haddii loo dhigo, ka tagida shayga loo qoondeeyay ka dibna dib u gelitaankiisa goor dambe ayaa la oggol yahay.
    ///
    /// Haddii aad u baahan tahay in xuduudaha wax cross, tilmaamaha si abyoonaha ku tuur iyo xisaabta waxaa ku sameeyaan.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// // Kabiro adigoo adeegsanaya tilmaame cayriin ah marka lagu daro laba walxood
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Loop-kan ayaa daabacaya "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Waxay xisaabisaa isugeynta miisaanka tilmaamaha iyadoo la adeegsanaayo isugeynta xisaabta.
    /// (Sahlanaato for `.wrapping_offset ((tirin sida isize).wrapping_neg())`)
    ///
    /// `count` wuxuu ku jiraa unugyada T;Tusaale ahaan, `count` ee 3 wuxuu u taagan yahay tilmaam tilmaame ah oo ah `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Hawlgalkani laftiisu had iyo jeer waa ammaan, laakiin adeegsiga tilmaamaha ka soo baxa maaha.
    ///
    /// Tilmaamaha soo baxay ayaa wali ku dhagan isla shayga loo qoondeeyay ee `self` tilmaamayo.
    /// * ** Looma isticmaali karo si loo helo shay kale oo loo qoondeeyay.Ogsoonow in Rust, isbeddel kasta oo (stack-allocated) ah loo tixgelinayo shey gaar ah oo loo qoondeeyey.
    ///
    /// Si kale haddii loo dhigo, `let z = x.wrapping_sub((x as usize) - (y as usize))`*ma* dhigto `z` si la mid ah `y` xitaa haddii aan u qaadanno in `T` uu leeyahay cabbirka `1` oo uusan buux dhaafin karin: `z` weli wuxuu ku dhegan yahay shayga `x` uu ku xiran yahay, dejintana waa dhaqan aan la qeexin illaa `x` iyo `y` dhibic isla sheyga loo qoondeeyay.
    ///
    /// Marka loo barbardhigo [`sub`], qaabkani asal ahaan wuxuu dib u dhigaa shuruudda ah inuu ku sugnaado isla shayga loo qoondeeyay: [`sub`] waa Dhaqan aan La Shaacin isla marka la gudbayo xuduudaha walaxda;`wrapping_sub` waxay soo saartaa tilmaame laakiin wali waxay u horseedaa Habdhaqan aan la qeexin haddii tilmaame laga diro marka uu xad-dhaafka ka yahay shayga uu ku xiran yahay.
    /// [`sub`] in la si fiican filaayo in karaa iyo waa sidan ka fiican ee code qaab-xasaasi ah.
    ///
    /// Jeegga dib u dhacay wuxuu kaliya tixgeliyaa qiimaha tilmaamaha laga reebay, ma aha qiyamka dhexdhexaadka ah ee la isticmaalay inta lagu guda jiray xisaabinta natiijada ugu dambeysa.
    /// Tusaale ahaan, `x.wrapping_add(o).wrapping_sub(o)` mar walba waa isku mid sida `x`.Si kale haddii loo dhigo, ka tagida shayga loo qoondeeyay ka dibna dib u gelitaankiisa goor dambe ayaa la oggol yahay.
    ///
    /// Haddii aad u baahan tahay in xuduudaha wax cross, tilmaamaha si abyoonaha ku tuur iyo xisaabta waxaa ku sameeyaan.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// // Iterate isticmaalaya tilmaamaha a ceeriin ee isabdal ah laba cunsur (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // loop Tani qora "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Qeexaa qiimaha pointer in `ptr` ah.
    ///
    /// Haddii ay dhacdo `self` inay tahay tilmaame (fat) oo ah nooca aan la qiyaasi karin, hawlgalkani wuxuu kaliya saameyn ku yeelan doonaa qaybta tilmaanta, halka tilmaamayaasha (thin) ee noocyada cabbirka leh, tani waxay leedahay saameyn la mid ah meelaynta fudud.
    ///
    /// pointer keentay yeelan doonaan provenance of `val`, ie, waayo tilmaamaha a baruurta, howlgalkan semantically waa isku mid sida la abuuro pointer baruurta cusub qiimaha pointer xogta of `val` laakiin metadata ee `self`.
    ///
    ///
    /// # Examples
    ///
    /// Shaqadani waxay ugu horreyntii faa'iido u leedahay oggolaanshaha xisaab-tilmaame tilmaame-tilmaameedka tilmaamayaasha dufanka leh:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // daabacan doonaa "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // BADBAADADA: Xaaladda tilmaame khafiif ah, hawlgalladani waa isku mid
        // shaqo fudud.
        // In case of tilmaamaha baruur ah, fulinta qaabka pointer baruurtii hadda, duurka ugu horeysay ee tilmaamaha ah sida had iyo jeer waa tilmaamaha xogta, taas oo sidaas oo kale loo xilsaaray.
        //
        unsafe { *thin = val };
        self
    }

    /// Reads qiimaha ka `self` oo aan dhaqaaqin.
    /// Tani waxay ka tagaysaa xusuusta `self` isbeddel la'aan.
    ///
    /// Ka eeg [`ptr::read`] wixii ku saabsan welwelka amniga iyo tusaalooyinka.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee ``.
        unsafe { read(self) }
    }

    /// Waxay qabataa akhrinta isbeddelka ee qiimaha laga bilaabo `self` iyada oo aan la dhaqaajin.Taasi ayaa ka dhigeysa xasuusta in `self` beddelin.
    ///
    /// Hawlgallada isbeddelka ah waxaa loogu talagalay inay ku shaqeeyaan I/O xasuusta, waxaana lagu ballan qaadayaa inaan lagu darin ama aan dib loogu soo celinaynin isku-duwaha hawlgallada kale ee isbedellada leh.
    ///
    ///
    /// Ka eeg [`ptr::read_volatile`] wixii ku saabsan welwelka amniga iyo tusaalooyinka.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Reads qiimaha ka `self` oo aan dhaqaaqin.
    /// Tani waxay ka tagaysaa xusuusta `self` isbeddel la'aan.
    ///
    /// Si ka duwan `read`, tilmaamuhu wuxuu noqon karaa mid aan isleegayn.
    ///
    /// Eeg [`ptr::read_unaligned`] for walaac ammaanka iyo tusaalooyin.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Nuqullada `count * size_of<T>` bytes laga bilaabo `self` illaa `dest`.
    /// Ilaha iyo halka loo socdo ayaa is dulsaari kara.
    ///
    /// NOTE: tani waxay leedahay *isla* amarka dooda sida [`ptr::copy`].
    ///
    /// Ka eeg [`ptr::copy`] wixii ku saabsan welwelka amniga iyo tusaalooyinka.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Nuqullada `count * size_of<T>` bytes laga bilaabo `self` illaa `dest`.
    /// The il iyo Noqosho *laga yaabaa in aan* xirmi.
    ///
    /// NOTE: tani waxay leedahay amarka *isku* dood sida [`ptr::copy_nonoverlapping`].
    ///
    /// Eeg [`ptr::copy_nonoverlapping`] for walaac ammaanka iyo tusaalooyin.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Nuqullada `count * size_of<T>` bytes laga bilaabo `src` illaa `self`.
    /// Ilaha iyo halka loo socdo ayaa is dulsaari kara.
    ///
    /// NOTE: tani waxay leedahay *ka soo horjeedka* amarka doodda ee [`ptr::copy`].
    ///
    /// Ka eeg [`ptr::copy`] wixii ku saabsan welwelka amniga iyo tusaalooyinka.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Nuqullada `count * size_of<T>` bytes laga bilaabo `src` illaa `self`.
    /// The il iyo Noqosho *laga yaabaa in aan* xirmi.
    ///
    /// NOTE: tani ka soo horjeeda *amarka muran* of [`ptr::copy_nonoverlapping`].
    ///
    /// Eeg [`ptr::copy_nonoverlapping`] for walaac ammaanka iyo tusaalooyin.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Oo fulinaya destructor ah (haddii ay jirto) ee qiimaha wadno-ka.
    ///
    /// Eeg [`ptr::drop_in_place`] for walaac ammaanka iyo tusaalooyin.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Wuxuu dul mariyaa goob xasuus leh qiimaha la siiyay isaga oo aan aqrin ama hoos u dhigin qiimihii hore.
    ///
    ///
    /// Eeg [`ptr::write`] for walaac ammaanka iyo tusaalooyin.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `write`.
        unsafe { write(self, val) }
    }

    /// Waxay weydineysaa xusuusta tilmaamaha tilmaamaya, dejinta `count * size_of::<T>()` bytes ee xasuusta laga bilaabo `self` ilaa `val`.
    ///
    ///
    /// Ka eeg [`ptr::write_bytes`] wixii ku saabsan welwelka amniga iyo tusaalooyinka.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Waxay qabataa qoraal isbeddelaya oo ku saabsan goobta xasuusta iyada oo la siinayo qiimaha la siiyay iyada oo aan la akhrin ama aan la dhigin qiimaha hore.
    ///
    /// Hawlgallada isbeddelka ah waxaa loogu talagalay inay ku shaqeeyaan I/O xasuusta, waxaana lagu ballan qaadayaa inaan lagu darin ama aan dib loogu soo celinaynin isku-duwaha hawlgallada kale ee isbedellada leh.
    ///
    ///
    /// Eeg [`ptr::write_volatile`] for walaac ammaanka iyo tusaalooyin.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Wuxuu dul mariyaa goob xasuus leh qiimaha la siiyay isaga oo aan aqrin ama hoos u dhigin qiimihii hore.
    ///
    ///
    /// Si ka duwan `write`, tilmaamaha waxaa laga yaabaa in unaligned.
    ///
    /// Ka eeg [`ptr::write_unaligned`] wixii ku saabsan welwelka amniga iyo tusaalooyinka.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Wuxuu ku beddelayaa qiimaha `self` oo la socda `src`, isagoo soo celinaya qiimihii hore, isagoo aan hoos u dhigin midkoodna.
    ///
    ///
    /// Ka eeg [`ptr::replace`] wixii ku saabsan welwelka amniga iyo tusaalooyinka.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `replace`.
        unsafe { replace(self, src) }
    }

    /// Bedelashada qiimaha at laba goobood mutable ah nooca la mid ah, iyada oo aan deinitializing midkood.
    /// Way isdul dhigi karaan, si ka duwan `mem::swap` oo u dhiganta haddii kale.
    ///
    /// Ka eeg [`ptr::swap`] wixii ku saabsan welwelka amniga iyo tusaalooyinka.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `swap`.
        unsafe { swap(self, with) }
    }

    /// Wuxuu xisaabiyaa isugeynta u baahan in lagu dabaqo tilmaamaha si looga dhigo mid waafaqsan `align`.
    ///
    /// Haddii aysan suurtagal ahayn in la iswaafajiyo tilmaamaha, hirgelinta ayaa soo celinaysa `usize::MAX`.
    /// Waa loo oggol yahay hirgelinta inay *mar walba* soo celiso `usize::MAX`.
    /// qaab aad isku geynta oo keliya ku xirnaan kartaa helitaanka isticmaali karo halkan kabayso, ma ay sax.
    ///
    /// Jaangooyada waxaa lagu muujiyey tiro ka mid ah walxaha `T`, oo aan ahayn baaytyo.Qiimaha la soo celiyay waxaa loo isticmaali karaa habka `wrapping_add`.
    ///
    /// Ma jiraan wax dammaanad qaad ah oo haba yaraatee ah in miisaamidda tilmaamuhu aanu buuxin doonin ama ka gudbi doonin qoondaynta tilmaamuhu tilmaamayo.
    ///
    /// Waxay u taal qofka soo waca inuu hubiyo in soo celinta la soo celiyey ay ku saxan tahay dhammaan shuruudaha marka laga reebo isku xidhka.
    ///
    /// # Panics
    ///
    /// Shaqada panics haddii `align` uusan ahayn awood-labo.
    ///
    /// # Examples
    ///
    /// Helitaanka ku xigta `u8` sida `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // halka tilmaamuhu la jaan qaadi karo iyada oo loo marayo `offset`, wuxuu ku tilmaami lahaa meel ka baxsan qoondaynta
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // AMMAANKA: `align` ayaa hubiyey in ay awood of 2 kor ku xusan
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Sooceliyaa dhererka jeex ah ceeriin.
    ///
    /// Qiimaha la soo celiyey waa tirada **walxaha**, maahan tirada baytiyada.
    ///
    /// Shaqadani waa mid amaan ah, xitaa marka jeexdinta ceyriinka aan lagu tuuri karin tixraac jeexan maxaa yeelay tilmaamtu waa mid aan waxba kajirin ama aan iswaafaqsanayn.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // BADBAADADA: Tani waa ammaan maxaa yeelay `*const [T]` iyo `FatPtr<T>` waxay leeyihiin qaab isku mid ah.
            // Kaliya `std` ayaa samayn kara dammaanad-qaadkan.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Ku soo celiya tilmaame cayriin galka jeexitaanka.
    ///
    /// Tani waxay u dhigantaa ridaya `self` in `*mut T`, laakiin si ka badan nooca-ammaan ah.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Sooceliyaa tilmaamaha a ceeriin in element ama subslice, aan samaynayno soohdin hubinta.
    ///
    /// Wicitaanka habkan la index ah out-of-soohdin ama marka `self` ma aha dereferencable waa *[dhaqanka undefined]* xitaa haddii pointer keentay in aan loo isticmaalin.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // BADBAADADA: Wicitaanku wuxuu xaqiijinayaa in `self` la diidan yahay iyo `index` xadka u dhow.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Sooceliyaa `None` haddii tilmaamaha uu yahay waxba kama, ama haddii kale celinta cad la wadaago in ay qiimaha ku duudduubtay oo `Some`.
    /// Marka la barbardhigo [`as_ref`], waxaa looga baahan yahay ma aha in qiimaha ay leedahay in la initialized.
    ///
    /// Wixii dhigiisa isbeddelaya eeg [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Markaad wacaysid qaabkan, waa inaad hubisaa in *midkood* tilmaamaha uu yahay NULL *ama* dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * Tilmaameyuhu waa inuu ahaadaa [valid] akhrinta `ptr.len() * mem::size_of::<T>()` badan oo bayte ah, waana inuu si sax ah isugu toosnaadaa.Tan macnaheedu waa gaar ahaan:
    ///
    ///     * Xusuusta xasuusta ee jeexdan oo dhan waa inay ku jirtaa hal shay oo loo qoondeeyay!
    ///       Xaleef marnaba noqon karaan guud ahaan waxyaabaha badan loo qoondeeyey.
    ///
    ///     * Tilmaameyuhu waa inuu waafajiyaa xitaa jeexjeexyada dhererka eber-ka ah.
    ///     Mid ka mid ah sababaha tan ayaa ah in qaabeynta qaabeynta enum ay ku tiirsanaan karaan tixraacyada (oo ay ku jiraan jeexjeexyada dherer kasta) oo la waafajiyo oo aan waxba ka jirin si looga sooco xogta kale.
    ///
    ///     Waxaad ka heli kartaa tilmaame loo isticmaali karo sida `data` jeexjeexyada dhererka eber isticmaalaya [`NonNull::dangling()`].
    ///
    /// * Wadarta cabbirka `ptr.len() * mem::size_of::<T>()` ee jeexan waa inuusan ka weyneyn `isize::MAX`.
    ///   Eeg dukumiintiyada amniga ee [`pointer::offset`].
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inuusan is beddelin (marka laga reebo gudaha `UnsafeCell`).
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    ///
    /// Sidoo kale eeg [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Sooceliyaa `None` haddii tilmaamuhu null yahay, ama haddii kale soo celiyo jeex u gaar ah qiimaha ku duudduuban `Some`.
    /// Marka la barbardhigo [`as_mut`], waxaa looga baahan yahay ma aha in qiimaha ay leedahay in la initialized.
    ///
    /// Wixii dhigga la wadaago eeg [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Markaad wacaysid qaabkan, waa inaad hubisaa in *midkood* tilmaamaha uu yahay NULL *ama* dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * Tilmaameyuhu waa inuu ahaadaa [valid] akhrinta iyo wax u qorida `ptr.len() * mem::size_of::<T>()` bytes badan, waana inuu si sax ah isugu toosiyaa.Tan macnaheedu waa gaar ahaan:
    ///
    ///     * Xusuusta xasuusta ee jeexdan oo dhan waa inay ku jirtaa hal shay oo loo qoondeeyay!
    ///       Xaleef marnaba noqon karaan guud ahaan waxyaabaha badan loo qoondeeyey.
    ///
    ///     * Tilmaameyuhu waa inuu waafajiyaa xitaa jeexjeexyada dhererka eber-ka ah.
    ///     Mid ka mid ah sababaha tan ayaa ah in qaabeynta qaabeynta enum ay ku tiirsanaan karaan tixraacyada (oo ay ku jiraan jeexjeexyada dherer kasta) oo la waafajiyo oo aan waxba ka jirin si looga sooco xogta kale.
    ///
    ///     Waxaad ka heli kartaa tilmaame loo isticmaali karo sida `data` jeexjeexyada dhererka eber isticmaalaya [`NonNull::dangling()`].
    ///
    /// * Wadarta cabbirka `ptr.len() * mem::size_of::<T>()` ee jeexan waa inuusan ka weyneyn `isize::MAX`.
    ///   Eeg dukumiintiyada amniga ee [`pointer::offset`].
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inaan laga helin (akhrin ama qorin) tilmaamaha kale.
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    ///
    /// Sidoo kale eeg [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Sinnaanta tilmaamaha
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}