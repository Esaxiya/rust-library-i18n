#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Waxay siisaa tilmaamaha metadata tilmaamaha nooc kasta oo tilmaamaya-nooc ah.
///
/// # Metadata tilmaanta
///
/// Noocyada tilmaanta ceeriin iyo noocyada tixraaca ee Rust ayaa loo malayn karaa inay ka kooban yihiin laba qaybood:
/// Daliil xogta ay ku jiraan cinwaanka xasuusta of qiimaha, iyo qaar ka mid ah metadata.
///
/// Noocyada qiyaasta qiyaasta ah (ee fuliya `Sized` traits) iyo sidoo kale noocyada `extern`, tilmaamayaasha waxaa lagu sheegaa inay yihiin "dhuuban": metadata waa eber cabbirkeeduna waa `()`.
///
///
/// Tilmaamayaasha [dynamically-sized types][dst] waxaa lagu sheegaa inay yihiin "ballac" ama "baruur", waxay leeyihiin metadata aan eber lahayn:
///
/// * Jaangooyooyinka garoonkooda ugu dambeeya uu yahay DST, metadata waa metadata berrinkii ugu dambeeyay
/// * Waayo, nooca `str` ah, metadata waa dhererka ee bytes sida `usize`
/// * Waayo, noocyada cad sida `[T]`, metadata waa dhererka in waxyaabaha sida `usize`
/// * Walxaha trait sida `dyn SomeTrait`, metadata waa [`DynMetadata<Self>`][DynMetadata] (tusaale `DynMetadata<dyn SomeTrait>`)
///
/// future, luqadda Rust waxaa laga yaabaa inay ku soo kordho noocyo cusub oo leh metadata tilmaam kala duwan.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// dhibcood ee trait tani waa ay `Metadata` nooca la xiriira, taas oo `()` ama `usize` ama `DynMetadata<_>` sida lagu qeexay kor.
/// Waxaa si otomaatig ah loogu hirgeliyaa nooc kasta.
/// Waa loo qaadan karaa in lagu hirgeliyo xaalad guud, xitaa iyada oo aan la isku xidhin.
///
/// # Usage
///
/// Tilmaamayaasha ceeriin waxaa loo kala qaadi karaa cinwaanka xogta iyo qaybaha metadata iyadoo la adeegsanayo qaabkooda [`to_raw_parts`].
///
/// Haddii kale, metadata kaligeed waxaa lagu soo saari karaa iyadoo la adeegsanayo shaqada [`metadata`].
/// tixraaca A waxaa loo gudbin karaa si [`metadata`] iyo si dadban cadaadisna.
///
/// Tilmaamaha (possibly-wide) dib ayaa dib looga soo celin karaa cinwaankiisa iyo metadata ee leh [`from_raw_parts`] ama [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Nooca metadata ee tilmaamayaasha iyo tixraacyada `Self`.
    #[lang = "metadata_type"]
    // NOTE: Ku hay trait bounds gudaha `static_assert_expected_bounds_for_metadata`
    //
    // gudaha `library/core/src/ptr/metadata.rs` oo la jaan qaadaya kuwa halkan jooga:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Tilmaamahan noocyada fulinta this alias trait yihiin "khafiif ah".
///
/// Tani waxaa ka mid ah noocyada soo jiidasho-`Sized` iyo noocyada `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: tan ha xasilin kahor intaanay magacyada trait ku xasilooneyn luqada?
pub trait Thin = Pointee<Metadata = ()>;

/// Soo saaro qayb metadata of tilmaamaha ah.
///
/// Qiimaha nooca `*mut T`, `&T`, ama `&mut T` si toos ah ayaa loogu gudbin karaa shaqadan maadaama ay si maldahan ugu khasbayaan `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // BADBAADADA: Ka helitaanka qiimaha ururka `PtrRepr` union' waa amni tan iyo * const T
    // iyo PtrComponents<T>leeyihiin isku shaandheyn isku mid ah.
    // Kaliya std ayaa samayn kara dammaanad-qaadkan.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Foomka tilmaamaha ceyriin ee (possibly-wide) ka sameys cinwaanka xogta iyo metadata.
///
/// function Tani waa ammaan ah, laakiin tilmaamaha soo laabtay khasab ma aha in si nabadgelyo ah dereference.
/// Xaleefyada, fiiri dukumiintiyada [`slice::from_raw_parts`] ee shuruudaha amniga.
/// Waayo, trait diidan, metadata waa ka pointer ah nooca ereased dahsoon isku yimaadaan.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // BADBAADADA: Ka helitaanka qiimaha ururka `PtrRepr` union' waa amni tan iyo * const T
    // iyo PtrComponents<T>leeyihiin isku shaandheyn isku mid ah.
    // Kaliya std ayaa samayn kara dammaanad-qaadkan.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Matalaa shaqeynta la mid ah sida [`from_raw_parts`], marka laga reebo in a pointer `*mut` cayriin waa ku soo laabtay, sida ka soo horjeeda a pointer `* const` ceeriin.
///
///
/// Ka eeg dukumiintiyada [`from_raw_parts`] wixii faahfaahin dheeraad ah.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // BADBAADADA: Ka helitaanka qiimaha ururka `PtrRepr` union' waa amni tan iyo * const T
    // iyo PtrComponents<T>leeyihiin isku shaandheyn isku mid ah.
    // Kaliya std ayaa samayn kara dammaanad-qaadkan.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Buug gacmeed loo baahan yahay si looga fogaado `T: Copy` xiran.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Buug gacmeed loo baahan yahay si looga fogaado `T: Clone` xiran.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Xogta badan ee nooca sheyga `Dyn = dyn SomeTrait` trait.
///
/// Waxay tilmaame u tahay vtable (miiska wicitaanka taleefanka) oo matalaya dhammaan macluumaadka lagama maarmaanka u ah wax ka qabashada nooca la taaban karo ee ku kaydsan gudaha sheyga trait.
/// Xaqiiqda gaar ahaan waxay ka kooban tahay:
///
/// * cabbirka nooca
/// * jaangooynta nooca
/// * tilmaame tilmaamaya nooca `drop_in_place` impl' (waxaa laga yaabaa inuu yahay maya-op data-old old data)
/// * tilmaamayaasha dhammaan hababka loogu talagalay hirgelinta nooca trait
///
/// Xusuusnow in saddexda hore ay gaar yihiin maxaa yeelay waxay lagama maarmaan u yihiin qoondaynta, hoos u dhaca, iyo kala-goynta shey kasta oo trait ah.
///
/// Waa suurtagal in lagu magacaabo qaab-dhismeed nooca halbeegga ah oo aan ahayn shay `dyn` trait (tusaale ahaan `DynMetadata<u64>`) laakiin aan loo helin qiime macno leh oo dhismahaas ku saabsan.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Horgalaha guud ee dhammaan vtables-ka.Waxaa la raacay by tilmaamo function habab trait.
///
/// Faahfaahinta fulinta gaarka ah ee `DynMetadata::size_of` iwm.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Soocelisaa cabirka nooca laxiriira vtableelkan.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Soocelisaa iskuxirka nooca laxiriira vtable-kaan.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Soocelinayaa cabbirka iyo isku toosinta sida `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // BADBAADADA: isku duba ridaha ayaa ku daadiyey qalabkan nooca Rust la taaban karo kaas oo
        // waxaa loo yaqaanaa inuu leeyahay qaabeyn sax ah.Isla caqli gal ah sidii `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Daabacadaha gacanta ayaa loo baahan yahay si looga fogaado xuduudaha `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}