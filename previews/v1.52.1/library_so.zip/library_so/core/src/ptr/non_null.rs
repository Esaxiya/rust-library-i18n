use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` laakiin aan eber ahayn oo aan isbeddel lahayn.
///
/// Tani badiyaa waa waxa saxda ah in la isticmaalo marka la dhisayo qaab dhismeedka xogta iyadoo la adeegsanayo tilmaamayaal ceyriin, laakiin ugu dambeyntii way ka khatar badan tahay in la isticmaalo sababtoo ah sifooyinkeeda dheeraadka ah.Hadaadan hubin inaad isticmaaleyso `NonNull<T>`, isticmaal kaliya `*mut T`!
///
/// Si ka duwan `*mut T`, tilmaame waa inuu had iyo jeer noqdaa mid aan waxba ka jirin, xitaa haddii tilmaame aan waligiis laga gudbin.Tani waa si enumyadu ay ugu adeegsadaan qiimahan mamnuuca ah midabtakoor-`Option<NonNull<T>>` wuxuu leegyahay isla `* mut T`.
/// Si kastaba ha noqotee tilmaamuhu weli wuu sii laalaadi karaa haddii aan laga gudbin.
///
/// Si ka duwan `*mut T`, `NonNull<T>` waxaa loo xushay inuu noqdo mid ka hooseeya `T`.Tani waxay suuro gelineysaa in ay isticmaalaan `NonNull<T>` marka dhismaha noocyada covariant, laakiin barayaa halista ah ee unsoundness haddii loo isticmaalo nooc ka mid ah in aan si dhab ah u noqon covariant.
/// (Xulashada ka soo horjeedka waxaa loo sameeyay `*mut T` inkasta oo farsamo ahaan unsoundness-ka ay sababi karto oo kaliya wicitaanada howlaha aan aaminka ahayn.)
///
/// Kala-beddelku wuxuu ku saxan yahay soo-saarista nabdoon ee ugu badan, sida `Box`, `Rc`, `Arc`, `Vec`, iyo `LinkedList`.Tani waa kiiska, sababtoo ah waxay ku siin API dadweyne oo socota Miyeydnaan wadaago xeerarka caadiga ah mutable of Rust.
///
/// Haddii nooca ammaan ah ma noqon karo covariant, waa inaad hubisaa waxa ku jira qaar ka mid ah beerta oo dheeraad ah si ay u bixiyaan invariance.Badanaa goobtani waxay noqon doontaa nooca [`PhantomData`] sida `PhantomData<Cell<T>>` ama `PhantomData<&'a mut T>`.
///
/// Notice in `NonNull<T>` leeyahay tusaale ahaan `From` ah `&T`.Si kastaba ha noqotee, tani waxba kama beddeleyso xaqiiqda ah in isku-beddelashada (tilmaame ka soo jeeda a) tixraaca la wadaago ay tahay dabeecad aan la qeexin haddii moosku ka dhex dhaco gudaha [`UnsafeCell<T>`].Isla sidaas oo kale ayaa loo abuuraa tixraac isbeddel ah oo laga helo tixraac wadaag ah.
///
/// Markaad isticmaaleyso tusaalahan `From` la'aantiis `UnsafeCell<T>`, waa masuuliyadaada inaad hubiso in `as_mut` aan waligiis la wicin, iyo `as_ptr` waligeed looma adeegsan isbadal.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` tilmaamo aan ahayn `Send` sababtoo ah macluumaadka ay u tixraaca la aliased laga yaabaa.
// FG, impl tani waa aan loo baahnayn, laakiin waa inay bixiyaan farriimaha wanaagsan baadi.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` tilmaamayaasha maahan `Sync` maxaa yeelay xogta ay tixraacayaan waa la beddeli karaa.
// FG, impl tani waa aan loo baahnayn, laakiin waa inay bixiyaan farriimaha wanaagsan baadi.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Waxay abuurtaa `NonNull` cusub oo ruxmaya, laakiin si fiican isugu habboon.
    ///
    /// Tani waxay faa'iido u leedahay bilowga noocyada caajisnimada u qoondeeya, sida `Vec::new` ay sameyso.
    ///
    /// Xusuusnow in qiimaha tilmaamaha ay suuragal tahay inuu tilmaamo tilmaame sax ah oo ku socda `T`, taas oo macnaheedu yahay in tan loo isticmaali karin inay tahay qiimaha sentinel "not yet initialized".
    /// Noocyada caajisnimada loo qoondeeyo waa inay la socdaan bilowga qaab kale.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // BADBAADADA: mem::align_of() wuxuu soo celinayaa adeegsi aan eber aheyn oo markaas la tuuray
        // si T. a mut *
        // Sidaa darteed, `ptr` maahan wax aan waxba ka jirin oo shuruudaha wicitaanka new_unchecked() waa la ixtiraamayaa.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Ku celiyaa tixraacyo wadaag ah qiimaha.Marka loo eego [`as_ref`], tani uma baahna in qiimaha la bilaabay.
    ///
    /// Waayo, dhigiisa mutable arki [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Markaad wacayso qaabkan, waa inaad hubisaa in dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * tilmaamaha waa in si fiican la safan.
    ///
    /// * Waa inuu noqdaa "dereferencable" macnaha lagu qeexay [the module documentation].
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inuusan is beddelin (marka laga reebo gudaha `UnsafeCell`).
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu la kulmayo dhammaan
        // shuruudaha tixraaca.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Ku soo celiyaa tixraacyo gaar ah qiimaha.Marka la barbardhigo [`as_mut`], waxaa looga baahan yahay ma aha in qiimaha ay leedahay in la initialized.
    ///
    /// Wixii dhigga la wadaago eeg [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Markaad wacayso qaabkan, waa inaad hubisaa in dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * tilmaamaha waa in si fiican la safan.
    ///
    /// * Waa inuu noqdaa "dereferencable" macnaha lagu qeexay [the module documentation].
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inaan laga helin (akhrin ama qorin) tilmaamaha kale.
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu la kulmayo dhammaan
        // shuruudaha tixraaca.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Abuuraa `NonNull` cusub.
    ///
    /// # Safety
    ///
    /// `ptr` waa inuu noqdaa mid aan waxba ka jirin
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `ptr` uusan waxba ka jirin.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Abuuraa `NonNull` cusub haddii `ptr` waa non-buriyo.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BADBAADADA: Tilmaame ayaa horeyba loo hubiyey mana aha wax aan waxba ka jirin
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Matalaa shaqeynta la mid ah sida [`std::ptr::from_raw_parts`], ahayn in pointer `NonNull` la soo noqdeen, sida ka soo horjeeda a pointer `*const` ceeriin.
    ///
    ///
    /// Ka eeg dukumiintiyada [`std::ptr::from_raw_parts`] wixii faahfaahin dheeraad ah.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // AMMAAN: Natiijada `ptr::from::raw_parts_mut` waa mid aan waxba ka jirin sababta oo ah `data_address` waa.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Ku-soo-koobid (suurtogal ahaan ballaaran) tilmaame galay cinwaanka iyo qaybaha metadata.
    ///
    /// tilmaamaha la dambe dib karo [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Heshaa tilmaamaha aasaasiga ah ee `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Sooceliyaa tixraaca la wadaago in qiimaha.Haddii qiimaha uu noqon karo mid aan la ogaan karin, [`as_uninit_ref`] waa in la adeegsadaa halkii.
    ///
    /// Waayo, dhigiisa mutable arki [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Markaad wacayso qaabkan, waa inaad hubisaa in dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * tilmaamaha waa in si fiican la safan.
    ///
    /// * Waa inuu noqdaa "dereferencable" macnaha lagu qeexay [the module documentation].
    ///
    /// * Tilmaameyuhu waa inuu tilmaamaa tusaale bilow ah oo ah `T`.
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inuusan is beddelin (marka laga reebo gudaha `UnsafeCell`).
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    /// (Qeybta ku saabsan in la bilaabo weli si buuxda looma go'aamin, laakiin illaa iyo inta laga gaarayo, habka kaliya ee nabdoon ayaa ah in la hubiyo in dhab ahaan la bilaabay.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu la kulmayo dhammaan
        // shuruudaha tixraaca.
        unsafe { &*self.as_ptr() }
    }

    /// Sooceliyaa tixraac u gaar ah qiimaha.Haddii qiimaha uu noqon karo mid aan la ogaan karin, [`as_uninit_mut`] waa in la adeegsadaa halkii.
    ///
    /// Wixii dhigga la wadaago eeg [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Markaad wacayso qaabkan, waa inaad hubisaa in dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * tilmaamaha waa in si fiican la safan.
    ///
    /// * Waa inuu noqdaa "dereferencable" macnaha lagu qeexay [the module documentation].
    ///
    /// * Tilmaameyuhu waa inuu tilmaamaa tusaale bilow ah oo ah `T`.
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inaan laga helin (akhrin ama qorin) tilmaamaha kale.
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    /// (Qeybta ku saabsan in la bilaabo weli si buuxda looma go'aamin, laakiin illaa iyo inta laga gaarayo, habka kaliya ee nabdoon ayaa ah in la hubiyo in dhab ahaan la bilaabay.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` uu la kulmayo dhammaan
        // shuruudaha tixraaca isbeddelaya.
        unsafe { &mut *self.as_ptr() }
    }

    /// Ku tuuraya tilmaame nooc kale ah.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // BADBAADADA: `self` waa tilmaame `NonNull` ah oo daruuri aan waxba ka jirin
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Waxay abuurtaa jeex ceeriin aan null ahayn oo tilmaam khafiif ah iyo dherer.
    ///
    /// dood `len` waa tirada xubno ** **, ma tirada bytes.
    ///
    /// function Tani waa ammaan ah, laakiin dereferencing qiimaha laabashada khatar tahay.
    /// Fiiri warqadaha ee [`slice::from_raw_parts`] waayo shuruudaha ammaanka jeex.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // abuuro pointer jeex ah marka laga bilaabo baxay Daliil in element ugu horeysay ee
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Xusuusnow in tusaalahan si macmal ah u muujinayo adeegsiga qaabkan, laakiin `` ha jarjarto= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // BADBAADADA: `data` waa tilmaame `NonNull` ah oo daruuri aan waxba ka jirin
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Soocelisaa dhererka jeex ceeriin ah oo aan waxba ka jirin
    ///
    /// Qiimaha la soo celiyey waa tirada **walxaha**, maahan tirada baytiyada.
    ///
    /// function Tani waa ammaan ah, xitaa marka jeex cayriin aan waxba lama dereferenced kartaa in jeex ah, maxaa yeelay, pointer uusan haysan cinwaankaaga oo sax ah.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Kuceliyaa tilmaame aan waxba kajirin galka jeexitaanka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // BADBAADADA: Waan ognahay in `self` aan waxba ka jirin.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Ku soo celiya tilmaame cayriin galka jeexitaanka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Dib tixraaca la wadaago in jeex ah qiyamka suurto gal uninitialized.Marka la barbardhigo [`as_ref`], waxaa looga baahan yahay ma aha in qiimaha ay leedahay in la initialized.
    ///
    /// Wixii dhigiisa isbeddelaya eeg [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Markaad wacayso qaabkan, waa inaad hubisaa in dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * Tilmaameyuhu waa inuu ahaadaa [valid] akhrinta `ptr.len() * mem::size_of::<T>()` badan oo bayte ah, waana inuu si sax ah isugu toosnaadaa.Tan macnaheedu waa gaar ahaan:
    ///
    ///     * Xusuusta xasuusta ee jeexdan oo dhan waa inay ku jirtaa hal shay oo loo qoondeeyay!
    ///       Xaleef marnaba noqon karaan guud ahaan waxyaabaha badan loo qoondeeyey.
    ///
    ///     * Tilmaameyuhu waa inuu waafajiyaa xitaa jeexjeexyada dhererka eber-ka ah.
    ///     Mid ka mid ah sababaha tan ayaa ah in qaabeynta qaabeynta enum ay ku tiirsanaan karaan tixraacyada (oo ay ku jiraan jeexjeexyada dherer kasta) oo la waafajiyo oo aan waxba ka jirin si looga sooco xogta kale.
    ///
    ///     Waxaad ka heli kartaa tilmaame loo isticmaali karo sida `data` jeexjeexyada dhererka eber isticmaalaya [`NonNull::dangling()`].
    ///
    /// * Wadarta cabbirka `ptr.len() * mem::size_of::<T>()` ee jeexan waa inuusan ka weyneyn `isize::MAX`.
    ///   Eeg dukumiintiyada amniga ee [`pointer::offset`].
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inuusan is beddelin (marka laga reebo gudaha `UnsafeCell`).
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    ///
    /// Sidoo kale eeg [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Sooceliyaa tixraac gaar ah si ay jeex ah qiyamka suurto gal uninitialized.Marka loo eego [`as_mut`], tani uma baahna in qiimaha la bilaabay.
    ///
    /// Wixii dhigga la wadaago eeg [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Markaad wacayso qaabkan, waa inaad hubisaa in dhammaan waxyaabaha soo socda ay run yihiin:
    ///
    /// * Tilmaameyuhu waa inuu ahaadaa [valid] akhrinta iyo wax u qorida `ptr.len() * mem::size_of::<T>()` bytes badan, waana inuu si sax ah isugu toosiyaa.Tan macnaheedu waa gaar ahaan:
    ///
    ///     * Xusuusta xasuusta ee jeexdan oo dhan waa inay ku jirtaa hal shay oo loo qoondeeyay!
    ///       Xaleef marnaba noqon karaan guud ahaan waxyaabaha badan loo qoondeeyey.
    ///
    ///     * Tilmaameyuhu waa inuu waafajiyaa xitaa jeexjeexyada dhererka eber-ka ah.
    ///     Mid ka mid ah sababaha tan ayaa ah in qaabeynta qaabeynta enum ay ku tiirsanaan karaan tixraacyada (oo ay ku jiraan jeexjeexyada dherer kasta) oo la waafajiyo oo aan waxba ka jirin si looga sooco xogta kale.
    ///
    ///     Waxaad ka heli kartaa tilmaame loo isticmaali karo sida `data` jeexjeexyada dhererka eber isticmaalaya [`NonNull::dangling()`].
    ///
    /// * Wadarta cabbirka `ptr.len() * mem::size_of::<T>()` ee jeexan waa inuusan ka weyneyn `isize::MAX`.
    ///   Eeg dukumiintiyada amniga ee [`pointer::offset`].
    ///
    /// * Waa in aad dhaqangalinta sharciyo aliasing Rust ee, tan iyo markii uu nool yahay ayuu ka noqday `'a` waxaa sabab la'aan la doortay, oo daruuri ma turjumayo noolaa dhabta ah ee xogta.
    ///   Gaar ahaan, inta uu noolyahay, xusuusta tilmaamuhu tilmaamayo waa inaan laga helin (akhrin ama qorin) tilmaamaha kale.
    ///
    /// Tani waxay khuseysaa xitaa haddii natiijada qaabkan aan la isticmaalin!
    ///
    /// Sidoo kale eeg [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Tani waa ammaan maadaama `memory` uu ansax ku yahay akhriska uuna wax ku qoro `memory.len()` bytes badan.
    /// // Xusuusnow wicitaanka `memory.as_mut()` halkan looma oggola maxaa yeelay waxyaabaha laga yaabo inay yihiin kuwo aan la ogaan karin.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Sooceliyaa tilmaamaha a ceeriin in element ama subslice, aan samaynayno soohdin hubinta.
    ///
    /// Wicitaanka habkan la index ah out-of-soohdin ama marka `self` ma aha dereferencable waa *[dhaqanka undefined]* xitaa haddii pointer keentay in aan loo isticmaalin.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // BADBAADADA: Wicitaanku wuxuu xaqiijinayaa in `self` la diidan yahay iyo `index` xadka u dhow.
        // Natiijo ahaan, tilmaame ka dhashay ma noqon karo NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // BADBAADADA: Tilmaame gaar ah ma noqon karo waxba kama jiraan, sidaa darteed shuruudaha loogu talagalay
        // new_unchecked() la ixtiraamo.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // AMMAANKA: Tixraac la beddeli karo ma noqon karo mid aan waxba ka jirin.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // BADBAADADA: Tixraac ma noqon karo mid aan waxba ka jirin, sidaa darteed shuruudaha loogu talagalay
        // new_unchecked() la ixtiraamo.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}