//! Adigu gacanta ku maaree xusuusta adoo adeegsanaya tilmaamayaal cayriin
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! shaqooyin badan buuggan qaadan tilmaamo cayriin sida doodaha iyo akhri ama u qortaa iyaga.Si tan ay u noqoto mid aamin ah, tilmaamahani waa inuu *ansax yahay*.
//! Haddii tilmaame uu ansax yahay waxay kuxirantahay qalliinka loo adeegsaday (wax u akhri ama u qor), iyo inta ay le'eg tahay xusuusta la helay (ie, immisa bayt waa read/written).
//! hawlaha intooda badan isticmaalaan `*mut T` iyo `* const T` in ay helaan oo kaliya qiimaha hal, taas oo kiiska dukumentiyada la tegayaa size iyo si dadban u muuqataa in ay noqon `size_of::<T>()` bytes.
//!
//! Xeerarka saxda ah ee ansaxnimada weli lama go'aamin.Damaanad-qaadyada la bixiyay xilligan waa kuwo aad u yar:
//!
//! * Tilmaame tilmaame [null] ah *weligiis* ma ansaxsana, xitaa ma ahan marinka [size zero][zst].
//! * Si tilmaame u noqdo mid ansax ah, waa lagama maarmaan, laakiin had iyo jeer kuma filna, in tilmaamuhu *qoor-gooyn karo*: baaxadda xusuusta ee cabirka la siiyay ee ka bilaabanaya tilmaamaha waa inay dhammaantood ku jiraan xuduudaha hal shay oo loo qoondeeyay.
//!
//! Ogsoonow in Rust, isbeddel kasta oo (stack-allocated) ah loo tixgelinayo shey gaar ah oo loo qoondeeyey.
//! * Xitaa hawlgallada ee [size zero][zst], tilmaamaha waa in aan loo si xusuusta deallocated, ie ku fiiqaya, deallocation dhigaysa tilmaamo xataa baadil hawlgallada eber yimaa-.
//! Si kastaba ha noqotee, ku shubista wax aan eber eheen *suugaaneed* tilmaame waxay ku habboon tahay marin-u-helka aan cabbirkoodu sarreyn, xitaa haddii xusuusta qaarkood ay ka dhacdo cinwaankaas oo lagu kala wareejin doono.
//! Tani waxay u dhigantaa qorista qoondadaada: qoondaynta walxaha cabbirkoodu aad u adag yahay.
//! Habka ugu soo qaadanin si aad u hesho tilmaamaha ah in ansax tahay muddo Furidda eber yimaa-waa [`NonNull::dangling`].
//! * Dhammaan marinnada ay ku shaqeeyaan shaqooyinka ku jira qaybtani waa *non-atomic* macnaha [atomic operations] ee loo adeegsado in la isku waafajiyo xargaha.
//! Taas macnaheedu waxa weeye dhaqanka undefined si ay u qabtaan laba Furidda waafaqsan in isku meel ka threads kala duwan haddii labada Furidda kaliya akhriyo ka xasuusta.
//! Ogsoonow in tan si cad ay uga mid tahay [`read_volatile`] iyo [`write_volatile`]: Soo-gaadhista kacsan looma isticmaali karo is-waafajinta isku xidhka dunta.
//! * Natiijada saarayay inay marjic u Daliil ansax tahay muddo ilaa inta wax ka dambeeyaa yahay live iyo ma tixraaca (kaliya tilmaamo ceeriin) waxaa loo isticmaalaa in ay helaan xasuusta isku.
//!
//! Axioms-yadaas, oo ay weheliyaan taxaddar isticmaalka [`offset`] ee xisaabinta tilmaamaha, ayaa ku filan in si sax ah loogu hirgeliyo waxyaabo badan oo faa'iido leh oo ku jira koodh aan ammaan ahayn.
//! Dammaanad adag ayaa la bixin doonaa ugu dambayn, maadaama xeerarka [aliasing] la go'aaminayo.
//! Wixii macluumaad dheeraad ah, ka eeg [book] iyo sidoo kale qaybta in tixraaca ee khusaysa [undefined behavior][ub].
//!
//! ## Alignment
//!
//! tilmaamo cayriin sharci ah sida kor ku xusan lagu qeexay waxaa daruuri ma aha si fiican u safan (meesha "proper" lays waxaa lagu qeexaa by nooca pointee ah, ie, `*const T` waa in la toosiyaa `mem::align_of::<T>()`).
//! Si kastaba ha ahaatee, hawlaha ugu badan u baahan dood ay tahay in la si fiican u safan, oo si cad loogu sheegi doonaa looga baahan yahay in ay waraaqo.
//! Waxyaabaha ka reeban ee tan waa [`read_unaligned`] iyo [`write_unaligned`].
//!
//! Marka shaqo u baahan in lays sax ah, waxa aanu si xitaa haddii ay helaan leeyahay size 0, ie, xataa haddii xasuusta dhab ma taabtay.Tixgeli adeegsiga [`NonNull::dangling`] xaaladaha noocaas ah.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Oo fulinaya destructor ah (haddii ay jirto) ee qiimaha wadno-ka.
///
/// Tani waxay u dhigantaa wicitaanka [`ptr::read`] iyo iska tuurista natiijada, laakiin waxay leedahay faa'iidooyinka soo socda:
///
/// * Waxaa loo baahan yahay * * in ay isticmaalaan `drop_in_place` in ay hoos u noocyada unsized sida trait diidan, maxaa yeelay, iyagu ma loo akhriyi kartaa gal xidhmooyin iyo sida caadiga ah hoos.
///
/// * Way uga fiicantahay wax-qabadka inuu tan ku sameeyo [`ptr::read`] markii uu hoos u dhigayo xusuusta gacanta loo qoondeeyay (tusaale ahaan, hirgelinta `Box`/`Rc`/`Vec`), maaddaama isku-duwaha uusan u baahnayn inuu caddeeyo inay cod tahay in nuqul laga dhigo.
///
///
/// * Waxaa loo isticmaali karaa in lagu rido xogta [pinned] marka `T` uusan aheyn `repr(packed)` (xogta xiran waa inaan la dhaqaajin ka hor intaan la tuurin).
///
/// Qiyamyada aan is dhigin laguma ridi karo meesha, waa in loo guuriyaa meel la isku waafaqsan yahay marka hore iyadoo la adeegsanayo [`ptr::read_unaligned`].Jumladaha la buuxiyo, dhaqaaqani wuxuu si otomaatig ah ugu sameeyaa isku-duwaha.
/// Tani waxay ka dhigan tahay beerihii structs buuxiyey oo aan la hoos-meel.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `to_drop` waa inuu ahaadaa [valid] labada aqrin iyo qoraalba.
///
/// * `to_drop` waa in si sax ah loo waafajiyaa.
///
/// * The qiimaha `to_drop` dhibcood waa inay noqdaan kuwo sax ah, waayo, kala go'in, taas oo macnaheedu noqon kartaa waa in ay ilaaliyaan invariants dheeraad ah, taasi waa nooc-tiirsane ah.
///
/// Intaa waxaa sii dheer, haddii `T` uusan aheyn [`Copy`], adeegsiga tilmaanta-qiimaha kadib wicitaanka `drop_in_place` wuxuu sababi karaa dabeecad aan la qeexin.Ogsoonow in `*to_drop = foo` dacwadood sida isticmaalka a maxaa yeelay waxa ay ka dhigi doonaa qiimaha si ay mar kale hoos u.
/// [`write()`] waxaa loo isticmaali karaa in lagu qoro xogta iyadoon keenin in la tuuro.
///
/// Xusuusnow xitaa haddii `T` uu leeyahay cabbirka `0`, tilmaame waa inuu noqdaa mid aan NULL aheyn oo si sax ah isugu habboon.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Joogu ka vector ah ka saar item la soo dhaafay:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // U hel tilmaame cayriin qaybta ugu dambeysa ee `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Gaabi `v` si looga hortago in sheyga ugu dambeeya la tuuro.
///     // Waxaan samayn in marka hore, si looga hortago arrimaha haddii `drop_in_place` hoose panics.
///     v.set_len(1);
///     // Wicitaan la'aan `drop_in_place`, sheyga ugu dambeeya weligood hoos looma dhigi doono, xusuusta ay maamushona waa la daadanayaa.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Hubso in shaygii ugu dambeeyay la tuuray.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Notice in matalaa compiler this si toos ah nuqul marka hoos structs buuxiyey, ie ka, aadan sida caadiga ah waxay leeyihiin in walwal ku saabsan arimaha sida haddii aad wici `drop_in_place` gacanta.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Koodh halkan kuma xirna, tan waxaa lagu beddelay xabagta dhabta ah ee isku dhafan ee isku-duwaha.
    //

    // BADBAADADA: Arag faallada kor ku xusan
    unsafe { drop_in_place(to_drop) }
}

/// Waxay abuurtaa tilmaame aan waxba tarayn.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Abuuraa Daliil waxba mutable ceeriin.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Buug gacmeed loo baahan yahay si looga fogaado `T: Clone` xiran.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Buug gacmeed loo baahan yahay si looga fogaado `T: Copy` xiran.
impl<T> Copy for FatPtr<T> {}

/// Foomamka jeex ah cayriin ka pointer iyo dherer ah.
///
/// dood `len` waa tirada xubno ** **, ma tirada bytes.
///
/// Shaqadani waa mid amaan ah, laakiin dhab ahaan isticmaalka qiimaha soo noqoshada waa mid aan amaan ahayn.
/// Fiiri warqadaha ee [`slice::from_raw_parts`] waayo shuruudaha ammaanka jeex.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // abuuro pointer jeex ah marka laga bilaabo baxay Daliil in element ugu horeysay ee
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // BADBAADADA: Helitaanka qiimaha laga helo urur-weynaha `Repr` union' waa ammaan tan iyo markii * const [T]
        //
        // iyo FatPtr waxay leeyihiin isla qaabeynta xusuusta.Kaliya std ayaa samayn kara dammaanad-qaadkan.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Waxay qabataa isla shaqeyntii sida [`slice_from_raw_parts`], marka laga reebo in jeex la isku beddelay oo ceyriin ah la soo celiyo, iyadoo ka soo horjeedda jeex cayriin aan beddelmi karin.
///
///
/// Ka eeg dukumiintiyada [`slice_from_raw_parts`] wixii faahfaahin dheeraad ah.
///
/// Shaqadani waa mid amaan ah, laakiin dhab ahaan isticmaalka qiimaha soo noqoshada waa mid aan amaan ahayn.
/// Ka eeg dukumintiyada [`slice::from_raw_parts_mut`] shuruudaha badbaadada jeex.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // ku qiimee qiime tixraac jeex ah
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // AMMAANKA: Helitaanka qiimaha ururka `Repr` tahay mid nabdoon oo tan * mut [T]
        // iyo FatPtr leeyihiin Layouts xasuusta isla
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Bedelashada qiimaha at laba goobood mutable ah nooca la mid ah, iyada oo aan deinitializing midkood.
///
/// Laakiin labada ka reebban ee soo socda, shaqadani waxay u dhigantaa [`mem::swap`]:
///
///
/// * Waxay ku shaqeysaa tilmaamayaal ceyriin halkii tixraac laga sameyn lahaa.
/// Marka tixraacyo la heli karo, [`mem::swap`] waa in laga door bidaa.
///
/// * Labada qiyam ee tilmaamaya ayaa is dulsaari kara.
/// Haddii qiimayaashu ay isdabamaraan, markaa aagga iskuxirka ee xusuusta ee `x` ayaa la isticmaali doonaa.
/// Tan waxaa lagu muujiyey tusaalaha labaad ee hoose.
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * Labada `x` iyo `y` labaduba waa inay noqdaan [valid] labadaba akhriska iyo qorista.
///
/// * Labadaba `x` iyo `y` waa in ay si sax ah isu waafajiyaan.
///
/// Fiiro gaar ah in xitaa haddii `T` leeyahay size `0`, tilmaamo waa in ay ahaadaan kuwa aan waxba si fiican u safan.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Nayo laba gobol oo aan isa:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // tani waa `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // tani waa `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Nayo labada gobol isa:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // tani waa `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // tani waa `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // indices The `1..3` of xirmi cad u dhexeeya `x` iyo `y` ah.
///     // Natiijooyinka macquulka ah waxay iyaga u noqon doonaan `[2, 3]`, sidaa darteed indices `0..3` waa `[1, 2, 3]` (u dhigma `y` ka hor `swap`);ama iyaga inay noqdaan `[0, 1]` si indices `1..4` waa `[0, 1, 2]` (u dhigma `x` ka hor `swap` ah).
/////
///     // Hirgalintan waxaa lagu qeexay in la sameeyo doorashada dambe.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Sii nafteena waxoogaa xoq ah oo aan kula shaqeyno.
    // Maaha inaan ka walwalsano dhibcaha: `MaybeUninit` waxba ma sameeyo markii la tuurayo.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Samee BADBAADADA isku beddelka: soo wacaha waa inuu damaanad qaadaa in `x` iyo `y` ay ansax u yihiin qorista oo ay si habboon isugu habboon yihiin.
    // `tmp` lama dulmari karo labada `x` ama `y` maxaa yeelay `tmp` waxaa kaliya loogu qoondeeyay iskudhafka sida shey gaar ah oo loo qoondeeyay.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` iyo `y` daboolaa laga yaabaa in
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Bedelashada `count * size_of::<T>()` bytes u dhaxeeya labada gobol oo bilowgii xasuusta at `x` iyo `y`.
/// Labada gobol waa in *aysan* iskudhafan.
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * Labada `x` iyo `y` labaduba waa inay noqdaan [valid] labadaba akhrinta iyo qorista 'tirinta' *
///   cabirka_of<T>() bytes
///
/// * Labadaba `x` iyo `y` waa in ay si sax ah isu waafajiyaan.
///
/// * Gobolka xasuusta laga bilaabo `x` la size a of `tirin *
///   cabirka_of<T>() `` bytes '' waa inaysan * * iskudhicin aagga xusuusta ee ka bilaabmaya `y` oo leh cabir isku mid ah.
///
/// Xusuusnow in xitaa haddii cabirka wax ku oolka ah la koobiyay (``tiriyo * cabbir_of: :<T>()`) Waa `0`, tilmaamo waa in ay ahaadaan kuwa aan waxba si fiican u safan.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `x` iyo `y` yihiin
    // ansax ah oo wax lagu qoro oo si habboon loo waafajiyo.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Noocyada ka yar ka-fiicnaanshaha xannibaadda hoose, si toos ah isku beddel si aad uga fogaato xumaanta codegen.
    //
    if mem::size_of::<T>() < 32 {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `x` iyo `y` ay ansax yihiin
        // qoraal ahaan, si habboon loo waafajiyay, oo aan is dul-saarneyn.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Habka halkan waa in ay isticmaasha simd inay isku bedelasho x&y si hufan.
    // Tijaabadu waxay muujineysaa in isku beddelka midkood 32 baayt ama 64 baayt markiiba ay ugu waxtarka badan tahay processor-yada Intel Haswell E.
    // LLVM waxay awood u leedahay inay hagaajiso haddii aan siino qaab #[repr(simd)] ah, xitaa haddii aanaan dhab ahaan u isticmaalin qaab-dhismeedkan.
    //
    //
    // FIXME repr(simd) wuxuu ku jabay emscripten iyo redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Ku soo wareeji x&y, iyaga oo koobiyeeynaya iyaga `Block` markiiba Hal-abuure waa inuu si buuxda u furi wareegga wareegga noocyada badankood NB
    // Uma adeegsan karno a loop sida `range` impl ugu yeerayo `mem::swap` recursively
    //
    let mut i = 0;
    while i + block_size <= len {
        // Abuur qaar ka mid ah xusuusta aan la ogeyn sida booska xoqida ee ku dhawaaqida `t` halkan waxay ka hortageysaa isku hagaajinta xargaha marka wareeggan aan la adeegsan
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // AMMAANKA: Sida `i < len`, iyo sida damaanad waajib wacaha in `x` iyo `y` waa ansax
        // loogu talagalay `len` bytes, `x + i` iyo `y + i` waa inay ahaadaan cinwaanno ansax ah, oo buuxiya heshiiska badbaadada ee `add`.
        //
        // Sidoo kale, wacaha waa in la damaanad qaado in `x` iyo `y` waxay shaqaynaysaa muddo qoray, si fiican u safan, oo aan isa, kaas oo buuxiya heshiiska ammaanka `copy_nonoverlapping` ah.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Kala beddel dhisme baay ah x&y, adoo u isticmaalaya t keyd ahaan ku meelgaar ah Tani waa in lagu hagaajiyaa howlaha hufan ee SIMD halka laga heli karo
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Beddel wixii bayt ah ee haray
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // AMMAANKA: arki hore comment ammaanka.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// U dhaqaaqaa `src` dhanka `dst` ee tilmaaman, isagoo soo celinaya qiimihii hore ee `dst`.
///
/// Midkoodna qiimaha hoos uma dhicin.
///
/// Shaqadani waxay u dhigantaa [`mem::replace`] marka laga reebo inay ku shaqayso tilmaamayaasha ceeriin halkii ay ka noqon lahayd tixraacyada.
/// Marka tixraacyo la heli karo, [`mem::replace`] waa in laga door bidaa.
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `dst` waa inuu ahaadaa [valid] labada aqrin iyo qoraalba.
///
/// * `dst` waa in si sax ah loo waafajiyaa.
///
/// * `dst` waa in farta qiimaha a si fiican u initialized nooca `T`.
///
/// Xusuusnow xitaa haddii `T` uu leeyahay cabbirka `0`, tilmaame waa inuu noqdaa mid aan NULL aheyn oo si sax ah isugu habboon.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` waxay lahaan doontaa saameyn isku mid ah iyadoon loo baahnayn xannibaadda aan ammaan ahayn.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // AMMAANKA: damaanad waajib wacaha in `dst` shaqeynayaa in uu noqdo
    // si ay tixraac mutable (ansax qoray, waafaqsan, initialized) kabka, oo kartaa ma xirmi `src` tan waa `dst` farta shay loo qoondeeyay oo kala duwan.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // isma dhaafi karo
    }
    src
}

/// Reads qiimaha ka `src` oo aan dhaqaaqin.Taasi ayaa ka dhigeysa xasuusta in `src` beddelin.
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `src` waa inuu ahaadaa [valid] akhrinta.
///
/// * `src` waa in si sax ah loo waafajiyaa.Adeegso [`read_unaligned`] haddii aysan arintu sidan ahayn.
///
/// * `src` waa in farta qiimaha a si fiican u initialized nooca `T`.
///
/// Xusuusnow xitaa haddii `T` uu leeyahay cabbirka `0`, tilmaame waa inuu noqdaa mid aan NULL aheyn oo si sax ah isugu habboon.
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Adigu gacanta ku hirgeli [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Abuur nuqul bitwise qiimaha at `a` in `tmp` ah.
///         let tmp = ptr::read(a);
///
///         // Baxaysa markan (labada by cad laabtay ama adiga oo waca shaqada ah oo panics) keeni lahaa qiimaha ee `tmp` lagu dejinayo halka qiime isku mid weli tilmaansado by `a`.
///         // Tani waxay kicin kartaa dabeecad aan la qeexin haddii `T` uusan ahayn `Copy`.
/////
/////
///
///         // Abuur nuqul bitwise qiimaha at `b` in `a` ah.
///         // Tani waa ammaan ah, maxaa yeelay, tixraacyo mutable ma alias kartaan.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Sida kor ku xusan, ka bixitaanka halkan waxay kicin kartaa dabeecad aan la qeexin sababtoo ah isla qiimaha waxaa lagu tixraacayaa `a` iyo `b`.
/////
///
///         // U dhaqaaq `tmp` una dhig `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` waa la dhaqaajiyay (`write` wuxuu la wareegayaa lahaanshihiisa dooddiisa labaad), marka waxba si toos ah halkan ugama dhicin.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Lahaanshaha Qiimaha La Laabtay
///
/// `read` abuurtaa nuqul bitwise of `T` ah, iyadoo aan loo eegin in `T` waa [`Copy`].
/// Haddii `T` uusan ahayn [`Copy`], adeegsiga labadaba qiimaha la soo celiyay iyo midka `*src` labaduba waa ku xadgudbi karaan badbaadada xusuusta.
/// Ogow in uu u xilsaarayo si dacwadood `*src` sida isticmaalka a sababtoo ah waxa ay isku dayi doonaan in ay hoos u qiimaha at `* src`.
///
/// [`write()`] waxaa loo isticmaali karaa in lagu qoro xogta iyadoon keenin in la tuuro.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` hadda waxay tilmaamaysaa isla xusuusta hoose sida `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Ku wareejinta `s2` waxay keenaysaa in qiimihiisii asalka ahaa hoos loo dhigo.
///     // Marka laga gudbo qodobkaan, `s` waa inaan mar dambe la isticmaalin, maadaama xusuusta salka ku haysa la fasaxay.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Ku qoondaynta `s` waxay sababi doontaa qiimihii hore in mar kale hoos loo dhigo, taas oo keenaysa dabeecad aan la qeexin.
/////
///     // s= String::from("bar");//KHALAD
///
///     // `ptr::write` waxaa loo isticmaali karaa in lagu dul qoro qiimaha adigoon hoos u dhigin.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `src` uu ansax ku yahay akhriska.
    // `src` ma xirmi `tmp` maxaa yeelay `tmp` kaliya waxaa loo qoondeeyey karaa xidhmooyin sida shay loo qoondeeyay oo kala duwan.
    //
    //
    // Sidoo kale, maadaama aan qormooyin sax ah ku qornay `tmp`, waxaa la hubaa in si habboon loo bilaabay.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Reads qiimaha ka `src` oo aan dhaqaaqin.Taasi ayaa ka dhigeysa xasuusta in `src` beddelin.
///
/// Si ka duwan [`read`], `read_unaligned` wuxuu la shaqeeyaa tilmaamayaal aan is qorneyn.
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `src` waa inuu ahaadaa [valid] akhrinta.
///
/// * `src` waa in farta qiimaha a si fiican u initialized nooca `T`.
///
/// Sida [`read`], `read_unaligned` waxay abuureysaa nuqul xoogaa ah oo ah `T`, iyadoon loo eegin inay `T` tahay [`Copy`] iyo in kale.
/// Haddii `T` uusan ahayn [`Copy`], adoo adeegsanaya qiimaha la soo celiyey iyo kan `*src` labadaba waa [violate memory safety][read-ownership].
///
/// Xusuusnow xitaa haddii `T` uu leeyahay cabbirka `0`, tilmaame waa inuu noqdaa mid aan NULL aheyn.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## On `packed` structs
///
/// Xilligaan macquul maaha in la abuuro tilmaamayaal ceeriin ah oo ku saabsan meelaha aan iswaafaqsaneyn ee qaabdhismeedka la buuxiyay.
///
/// Isku dayga ah in la abuuro tilmaame ceyriin ah oo ku saabsan qaab dhismeedka `unaligned` oo leh muujinta sida `&packed.unaligned as *const FieldType` wuxuu abuuraa tixraac dhexdhexaad ah oo aan is dhigin ka hor inta aan loo rogin tilmaame cayriin.
///
/// In tixraackani yahay mid ku meel gaadh ah isla markiibana la tuurayo waa mid aan macno badan lahayn maadaama isku-duwaha uu had iyo jeer rajaynayo tixraacyada in si habboon loo waafajiyo.
/// Natiijo ahaan, adeegsiga `&packed.unaligned as *const FieldType` wuxuu sababa isla markiiba* dabeecad aan qeexin * barnaamijkaaga.
///
/// Tusaale ka mid ah waxa aan la sameynin iyo sida tani ay la xidhiidho `read_unaligned` waa:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Halkan waxaan isku dayeynaa inaan qaadanno cinwaanka 32-bit integer ah oo aan iswaafajin.
///     let unaligned =
///         // Tixraac ku-meel-gaadh ah oo aan ku-meel-gaadh ahayn ayaa halkan lagu abuuray taas oo keenta dhaqan aan la qeexin iyada oo aan loo eegin in tixraaca la isticmaalay iyo in kale.
/////
///         &packed.unaligned
///         // U tuurista tilmaame cayriin waxba tari maayo;khaladka mar hore dhacay.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Si toos ah u helida meelaha aan is qorneyn tusaale `packed.unaligned` waa aamin laakiin.
///
///
///
///
///
///
// FIXME: Cusboonaysii waraaqaha ku saleysan natiijada RFC #2582 iyo asxaabta.
/// # Examples
///
/// Read qiimaha usize ka kayd byte ah:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `src` uu ansax ku yahay akhriska.
    // `src` ma xirmi `tmp` maxaa yeelay `tmp` kaliya waxaa loo qoondeeyey karaa xidhmooyin sida shay loo qoondeeyay oo kala duwan.
    //
    //
    // Sidoo kale, maadaama aan qormooyin sax ah ku qornay `tmp`, waxaa la hubaa in si habboon loo bilaabay.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Wuxuu dul mariyaa goob xasuus leh qiimaha la siiyay isaga oo aan aqrin ama hoos u dhigin qiimihii hore.
///
/// `write` ma daadinayo waxyaabaha ku jira `dst`.
/// Tani waa ammaan, laakiin waxay daadin kartaa qoondaynta ama kheyraadka, sidaa darteed waa in laga taxaddaraa in aan dib loo dul dhigin shay la tuurayo.
///
///
/// Intaa waxaa sii dheer, ma dhigeyso `src`.Semantically, `src` dhaqaaqaa galay meesha uu tilmaamay in ay `dst`.
///
/// Tani waxay ku habboon tahay bilowga xusuusta aan la ogaan karin, ama dib-u-qorista xusuusta ee horay u ahayd [`read`] laga bilaabo.
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `dst` waa inuu ahaadaa [valid] qorista.
///
/// * `dst` waa in si sax ah loo waafajiyaa.Adeegso [`write_unaligned`] haddii aysan arintu sidan ahayn.
///
/// Xusuusnow xitaa haddii `T` uu leeyahay cabbirka `0`, tilmaame waa inuu noqdaa mid aan NULL aheyn oo si sax ah isugu habboon.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Adigu gacanta ku hirgeli [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Abuur nuqul bitwise qiimaha at `a` in `tmp` ah.
///         let tmp = ptr::read(a);
///
///         // Baxaysa markan (labada by cad laabtay ama adiga oo waca shaqada ah oo panics) keeni lahaa qiimaha ee `tmp` lagu dejinayo halka qiime isku mid weli tilmaansado by `a`.
///         // Tani waxay kicin kartaa dabeecad aan la qeexin haddii `T` uusan ahayn `Copy`.
/////
/////
///
///         // Abuur nuqul bitwise qiimaha at `b` in `a` ah.
///         // Tani waa ammaan ah, maxaa yeelay, tixraacyo mutable ma alias kartaan.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Sida kor ku xusan, ka bixitaanka halkan waxay kicin kartaa dabeecad aan la qeexin sababtoo ah isla qiimaha waxaa lagu tixraacayaa `a` iyo `b`.
/////
///
///         // U dhaqaaq `tmp` una dhig `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` waa la dhaqaajiyay (`write` wuxuu la wareegayaa lahaanshihiisa dooddiisa labaad), marka waxba si toos ah halkan ugama dhicin.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Waxaan si toos ah ugu yeereynaa astaamaha si looga fogaado wicitaanada waxqabadka ee koodhka la sameeyay maaddaama `intrinsics::copy_nonoverlapping` ay tahay shaqo duub ah.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `dst` uu ansax ku yahay qorista.
    // `dst` iskama dhaafi karo `src` maxaa yeelay qofka soo wacayaa wuxuu leeyahy marin isbadal ah `dst` halka `src` ay leedahay howshan.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Wuxuu dul mariyaa goob xasuus leh qiimaha la siiyay isaga oo aan aqrin ama hoos u dhigin qiimihii hore.
///
/// Si ka duwan [`write()`], tilmaamaha waxaa laga yaabaa in unaligned.
///
/// `write_unaligned` ma da'a ka kooban `dst`.Tani waa ammaan, laakiin waxay daadin kartaa qoondaynta ama kheyraadka, sidaa darteed waa in laga taxaddaraa in aan dib loo dul dhigin shay la tuurayo.
///
/// Intaa waxaa sii dheer, ma dhigeyso `src`.Semantically, `src` dhaqaaqaa galay meesha uu tilmaamay in ay `dst`.
///
/// Tani waxay ku habboon tahay bilowga xusuusta aan la ogaan karin, ama dib-u-qorista xusuusta ee horay loogu akhriyay [`read_unaligned`].
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `dst` waa inuu ahaadaa [valid] qorista.
///
/// Xusuusnow xitaa haddii `T` uu leeyahay cabbirka `0`, tilmaame waa inuu noqdaa mid aan NULL aheyn.
///
/// [valid]: self#safety
///
/// ## On `packed` structs
///
/// Xilligaan macquul maaha in la abuuro tilmaamayaal ceeriin ah oo ku saabsan meelaha aan iswaafaqsaneyn ee qaabdhismeedka la buuxiyay.
///
/// Isku dayga ah in la abuuro tilmaame ceyriin ah oo ku saabsan qaab dhismeedka `unaligned` oo leh muujinta sida `&packed.unaligned as *const FieldType` wuxuu abuuraa tixraac dhexdhexaad ah oo aan is dhigin ka hor inta aan loo rogin tilmaame cayriin.
///
/// In tixraackani yahay mid ku meel gaadh ah isla markiibana la tuurayo waa mid aan macno badan lahayn maadaama isku-duwaha uu had iyo jeer rajaynayo tixraacyada in si habboon loo waafajiyo.
/// Natiijo ahaan, adeegsiga `&packed.unaligned as *const FieldType` wuxuu sababa isla markiiba* dabeecad aan qeexin * barnaamijkaaga.
///
/// Tusaalaha waxa aan la sameyn iyo sida tan ay ula xiriirto `write_unaligned` waa:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Halkan waxaan isku dayeynaa inaan qaadanno cinwaanka 32-bit integer ah oo aan iswaafajin.
///     let unaligned =
///         // Tixraac ku-meel-gaadh ah oo aan ku-meel-gaadh ahayn ayaa halkan lagu abuuray taas oo keenta dhaqan aan la qeexin iyada oo aan loo eegin in tixraaca la isticmaalay iyo in kale.
/////
///         &mut packed.unaligned
///         // U tuurista tilmaame cayriin waxba tari maayo;khaladka mar hore dhacay.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Si toos ah u helida meelaha aan is qorneyn tusaale `packed.unaligned` waa aamin laakiin.
///
///
///
///
///
///
///
///
///
// FIXME: Cusboonaysii waraaqaha ku saleysan natiijada RFC #2582 iyo asxaabta.
/// # Examples
///
/// Qor qiimaha usize ah in kayd byte ah:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `dst` uu ansax ku yahay qorista.
    // `dst` iskama dhaafi karo `src` maxaa yeelay qofka soo wacayaa wuxuu leeyahy marin isbadal ah `dst` halka `src` ay leedahay howshan.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Waxaan si toos ah ugu yeereynaa asalka si looga fogaado wicitaanada shaqeynta ee koodhka la sameeyay.
        intrinsics::forget(src);
    }
}

/// Waxay qabataa akhrinta isbeddelka ee qiimaha laga bilaabo `src` iyada oo aan la dhaqaajin.Tani waxay ka tagaysaa xusuusta `src` isbeddel la'aan.
///
/// Hawlgallada isbeddelka ah waxaa loogu talagalay inay ku shaqeeyaan I/O xasuusta, waxaana lagu ballan qaadayaa inaan lagu darin ama aan dib loogu soo celinaynin isku-duwaha hawlgallada kale ee isbedellada leh.
///
/// # Notes
///
/// Rust hadda malaha qaab xusuus adag oo si rasmi ah loo qeexay, markaa macnaha saxda ah ee waxa "volatile" halkan looga jeedo waa la beddeli karaa waqti ka dib.
/// Taas markii la dhaho, semanticsku had iyo jeer wuxuu ku dambayn doonaa si la mid ah [C11's definition of volatile][c11].
///
/// Isku-dubaridaha waa inuusan beddelin amarka ama tirada hawlgallada xusuusta ee isbeddelaya.
/// Si kastaba ha ahaatee, hawlgallada xasuusta kacsan on nooc eber yimaa-(tusaale ahaan, haddii nooca eber yimaa-la maray si `read_volatile`) waa noops oo la iska indho tiri laga yaabaa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `src` waa inuu ahaadaa [valid] akhrinta.
///
/// * `src` waa in si sax ah loo waafajiyaa.
///
/// * `src` waa in farta qiimaha a si fiican u initialized nooca `T`.
///
/// Like [`read`], `read_volatile` abuurtaa nuqul bitwise of `T` ah, iyadoo aan loo eegin in `T` waa [`Copy`].
/// Haddii `T` uusan ahayn [`Copy`], adoo adeegsanaya qiimaha la soo celiyey iyo kan `*src` labadaba waa [violate memory safety][read-ownership].
/// Si kastaba ha ahaatee, kaydinta [`Copy`] noocyada aan xasuusta kacsan waa hubaal sax ahayn.
///
/// Xusuusnow xitaa haddii `T` uu leeyahay cabbirka `0`, tilmaame waa inuu noqdaa mid aan NULL aheyn oo si sax ah isugu habboon.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Sida C oo kale, haddii hawlgalku isbeddelayo wax saameyn ah kuma yeelan karo su'aalaha ku lug leh marin u helka isku midka ah ee ka imanaya dhowr mawduuc.Gaaritaannada isbeddelayaa waxay u dhaqmaan sida saxda ah ee marin-u-hellayaasha atomiga marka loo eego arrintaas.
///
/// Gaar ahaan, tartanka u dhexeeya `read_volatile` iyo hawlgal kasta waxaad u qortaa in isku meel waa dhaqan undefined.
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Kama nixineyso inay yareyso saameynta codegen.
        abort();
    }
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Waxay qabataa qoraal isbeddelaya oo ku saabsan goobta xasuusta iyada oo la siinayo qiimaha la siiyay iyada oo aan la akhrin ama aan la dhigin qiimaha hore.
///
/// Hawlgallada isbeddelka ah waxaa loogu talagalay inay ku shaqeeyaan I/O xasuusta, waxaana lagu ballan qaadayaa inaan lagu darin ama aan dib loogu soo celinaynin isku-duwaha hawlgallada kale ee isbedellada leh.
///
/// `write_volatile` ma da'a ka kooban `dst`.Tani waa ammaan, laakiin waxay daadin kartaa qoondaynta ama kheyraadka, sidaa darteed waa in laga taxaddaraa in aan dib loo dul dhigin shay la tuurayo.
///
/// Intaa waxaa sii dheer, ma dhigeyso `src`.Semantically, `src` dhaqaaqaa galay meesha uu tilmaamay in ay `dst`.
///
/// # Notes
///
/// Rust hadda malaha qaab xusuus adag oo si rasmi ah loo qeexay, markaa macnaha saxda ah ee waxa "volatile" halkan looga jeedo waa la beddeli karaa waqti ka dib.
/// Taas markii la dhaho, semanticsku had iyo jeer wuxuu ku dambayn doonaa si la mid ah [C11's definition of volatile][c11].
///
/// Isku-dubaridaha waa inuusan beddelin amarka ama tirada hawlgallada xusuusta ee isbeddelaya.
/// Si kastaba ha noqotee, hawlgallada xusuusta ee isbeddelaya ee ku saabsan noocyada cabbirkoodu yahay eber (tusaale ahaan, haddii nooc xaddiga eber ah loo gudbiyo `write_volatile`) waa nabarro waana la iska indha tiri karaa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `dst` waa inuu ahaadaa [valid] qorista.
///
/// * `dst` waa in si sax ah loo waafajiyaa.
///
/// Xusuusnow xitaa haddii `T` uu leeyahay cabbirka `0`, tilmaame waa inuu noqdaa mid aan NULL aheyn oo si sax ah isugu habboon.
///
/// [valid]: self#safety
///
/// Sida C oo kale, haddii hawlgalku isbeddelayo wax saameyn ah kuma yeelan karo su'aalaha ku lug leh marin u helka isku midka ah ee ka imanaya dhowr mawduuc.Gaaritaannada isbeddelayaa waxay u dhaqmaan sida saxda ah ee marin-u-hellayaasha atomiga marka loo eego arrintaas.
///
/// Gaar ahaan, tartan u dhexeeya `write_volatile` iyo hawlgal kasta oo kale (akhris ama qoris) isla goobta ah waa dhaqan aan la qeexin.
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Kama nixineyso inay yareyso saameynta codegen.
        abort();
    }
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// pointer align `p`.
///
/// mowjadda xisaabiyo (marka la eego waxyaalaha aasaaska ah ee talaabo `stride`) in uu leeyahay in lagu dabaqo pointer `p` si pointer `p` in aad la safan lahaa in `a`.
///
/// Note: Hirgelintaani waxaa si taxaddar leh loogu waafajiyay in aysan panic ahayn.Waa UB for this si panic.
/// Isbedelka kaliya ee dhabta ah ee halkan lagu sameyn karo waa isbedelka `INV_TABLE_MOD_16` iyo joogteynta laxiriira.
///
/// Haddii aan waligeen go'aansanno inaan suurta gal ka dhigno in aan ugu yeerno astaamaha `a` oo aan ahayn awood labo-labo ah, waxay u badan tahay inay caqli badan tahay in kaliya loo beddelo hirgelinta nacasnimada halkii aan isku dayi lahayn in la waafajiyo tan si loo waafajiyo isbeddelkaas.
///
///
/// Wixii su'aal ah waxaad aadaa@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): isticmaalka Direct ee intrinsics kuwaas oo si weyn u soo hagaagaysa ka codegen heer ka gaabsadeen-<=
    // 1, halkaasoo noocyada qaababka hawlgalladani aan loogu qorin.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Xisaabi iskudhafka qaabdhismeedka iskudhafka ah ee `x` modulo `m`.
    ///
    /// Hirgelintaani waxaa loogu talagalay `align_offset` waxayna leedahay shuruudo soo socda:
    ///
    /// * `m` waa awood-labo ka mid ah;
    /// * `x < m`; (Haddii `x ≥ m`, waxay noqotay `x % m` halkii)
    ///
    /// Fulinta shaqo laguma panic.Weligaa.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Jadwalka qaab-dhismeedka isku-dhafan ee qaab-dhismeedka 2 2=16.
        ///
        /// Xusuusnow, in jadwalkan uusan kujirin qiimayaal meesha ay wax ka jiraan uusan jirin (ie, `0⁻¹ mod 16`, `2⁻¹ mod 16`, iwm.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo kaas oo `INV_TABLE_MOD_16` ah waxaa loogu talagalay.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // AMMAANKA: `m` waxaa looga baahan yahay in ay ka awood-labo ka mid ah, sidaa daraaddeedna aan eber.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Waxaan iterate "up" isticmaalayo qaaciddadan soo socta:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // ilaa 2²ⁿ ≥ m.Markaa waxaan ku yareyn karnaa `m`-keena aan dooneyno adoo qaadanaya natiijada `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=* y (2, xy) mod n
                //
                // Xusuusnow, in aan si ula kac ah ugu adeegsano hawlgallada duubista-qaaciddada asalka ah waxay isticmaashaa tusaale ahaan, kalagoynta `mod n`.
                // Way fiican tahay in la sameeyo iyaga `mod usize::MAX` halkii, maxaa yeelay waxaan qaadanaa natiijada `mod n` dhamaadka si kasta.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // AMMAANKA: `a` waa awood-labo ka mid ah, sidaas darteed aan eber.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` kiiska si fudud ayaa loo xisaabin karaa iyada oo loo marayo `-p (mod a)`, laakiin sidaas oo kale waxay xakameyneysaa awoodda LLVM ee xulashada tilmaamaha sida `lea`.Halkii ayaan ka xisaabeynaa
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // kaas oo u qaybiya hawlgallada hareeraha xamuulka, laakiin rajo-gelin `and` ah oo ku filan LLVM si ay u awoodo inay ka faa'iideysato waxyaabaha kala duwan ee ay ka ogtahay.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Horeba waafaqsan.Yay!
        return 0;
    } else if stride == 0 {
        // Haddii tilmaamuhu uusan iswaafaqsanayn, oo curiyuhu uu yahay eber cabbirkiisa, markaa qaddar walxo waligiis isma waafajin doono tilmaamaha.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // BADBAADADA: a waa awood-labo halka aan eber aheyn.tallaabo==0 kiis ayaa kor lagu xalliyey.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // BADBAADADA: gcdpow wuxuu leeyahay xarig-sare oo ugu badnaan tirada waxoogaa yar oo istcimaala.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // BADBAADADA: gcd had iyo jeer wuu ka weyn yahay ama u dhigmaa 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch-kan ayaa xallinaya isla'egta isku-dhafka toosan:
        //
        // ` p + so = 0 mod a `
        //
        // `p` halkan waxaa ku yaal qiimaha tilmaamaha, `s`, tillaabada `T`, `o` oo lagu dheellitiray ``T`s, iyo `a`, iswaafajinta la codsaday.
        //
        // Iyada oo `g = gcd(a, s)`, iyo xaaladda ku xusan oo sheegaya in `p` sidoo kale waa loo qeybin karaa `g`, waxaan lagu tilmaami karaa `a' = a/g`, `s' = s/g`, `p' = p/g`, ka dibna uu noqdo dhiganta:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Ereyga koowaad waa "the relative alignment of `p` to `a`" (waxaa loo qaybiyay `g`), erayga labaadna waa "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (markale waxaa loo qaybiyay `g`).
        //
        // Qeybinta `g` waa lagama maarmaan in la sameeyo ka soo horjeedka si fiican u sameysmay haddii `a` iyo `s` aysan wada shaqeyn karin.
        //
        // Intaas waxaa sii dheer, natiijada ay soo saartay xalkaani ma ahan "minimal", marka waa lagama maarmaan in la qaato natiijada `o mod lcm(s, a)`.Waxaan ku badali karnaa `lcm(s, a)` kaliya `a'`.
        //
        //
        //
        //
        //

        // BADBAADADA: `gcdpow` wuxuu leeyahay xad-sare oo aan ka badnayn tirada raad-raaca 0-bits ee `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // BADBAADADA: `a2` waa eber.Wareejinta `a` ee `gcdpow` ma beddeli karto mid ka mid ah xirmooyinka la dhigay
        // gudaha `a` (oo ay mid sax ah leedahay).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // BADBAADADA: `gcdpow` wuxuu leeyahay xad-sare oo aan ka badnayn tirada raad-raaca 0-bits ee `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // BADBAADADA: `gcdpow` wuxuu leeyahay xad-sare oo aan ka badnayn tirada raad-raaca 0-bits gudaha
        // `a`.
        // Intaas waxaa sii dheer, kala-goynta ma buuxin karto, maxaa yeelay `a2 = a >> gcdpow` had iyo jeer way ka weynaan doontaa `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // BADBAADADA: `a2` waa awood-labo, sida kor lagu caddeeyay.`s2` waa adag ka yar `a2`
        // maxaa yeelay, `(s % a) >> gcdpow` waa adag ka yar `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Lama jaan qaadi karo gabi ahaanba.
    usize::MAX
}

/// Barbardhigay tilmaamo sida xawliga ah u sinnaanta.
///
/// Tani waa isku mid sida la isticmaalayo operator `==` ah, laakiin generic yar:
/// doodaha waa inay ahaadaan `*const T` tilmaame cayriin, ma ahan wax fuliya `PartialEq`.
///
/// Tan waxaa loo isticmaali karaa in la isbarbar dhigo tixraacyada `&T` (kuwaas oo ku qasbaya `*const T` si aan toos ahayn) cinwaankooda halkii la isbarbar dhigi lahaa qiimayaasha ay tilmaamayaan (taas oo ah waxa uu fulinayo `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Xuduudaha ayaa sidoo kale la barbar dhigaa dhererkooda (tilmaamayaasha dufanka):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits sidoo kale waa la barbardhigaa fulintooda:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Tilmaamayaasha waxay leeyihiin cinwaanno siman.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Waxyaabaha waxay leeyihiin cinwaanno siman, laakiin `Trait` waxay leedahay fulinno kala duwan.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Diinta tixraaca si `*const u8` a barbardhigay by cinwaanka.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash tilmaame cayriin.
///
/// Tani waxaa loo isticmaali karaa si ay u wada xaajoodaan tixraaca `&T` ah (taas oo carrruura in `*const T` si dadban) by ay cinwaanka halkii qiimaha u tilmaamay, in (taas oo ah waxa hirgelinta `Hash for &T` sameeyo).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Ujeedo tilmaamayaasha shaqada
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Kabka dhexe sida loo isticmaalo waxaa looga baahan yahay AVR
                // sidaa darteed booska cinwaanka tilmaamaha shaqada isha lagu keydinayo tilmaamaha shaqada ugu dambeysa.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Kabka dhexe sida loo isticmaalo waxaa looga baahan yahay AVR
                // sidaa darteed booska cinwaanka tilmaamaha shaqada isha lagu keydinayo tilmaamaha shaqada ugu dambeysa.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Majiro shaqooyin kaladuwan oo leh 0 xuduudaha
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Abuur tilmaame ceyriin ah oo ah `const` meel, adigoon abuurin tixraac dhexdhexaad ah.
///
/// Abuuritaanka tixraac la leh `&`/`&mut` waa la oggol yahay oo keliya haddii tilmaamuhu si sax ah isu waafaqo oo tilmaamo xogta la bilaabay.
/// Xaaladaha aysan shuruudahaasi qabanayn, tilmaamayaasha ceeriin waa in loo adeegsadaa halkii.
/// Si kastaba ha noqotee, `&expr as *const _` wuxuu abuuraa tixraac kahor inta uusan u turayn tilmaame cayriin, tixraacaasina wuxuu ku xiran yahay isla sharciyada dhammaan tixraacyada kale.
///
/// Dhaqaaluhu wuxuu abuuri karaa tilmaam cayriin ah *isagoon* abuurin tixraac marka hore.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` abuuri lahaa tixraaca ah unaligned, iyo sidaas noqon Dhaqanka undefined!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Abuur tilmaame ceyriin ah oo ah `mut` meel, adigoon abuurin tixraac dhexdhexaad ah.
///
/// Abuuritaanka tixraac la leh `&`/`&mut` waa la oggol yahay oo keliya haddii tilmaamuhu si sax ah isu waafaqo oo tilmaamo xogta la bilaabay.
/// Xaaladaha aysan shuruudahaasi qabanayn, tilmaamayaasha ceeriin waa in loo adeegsadaa halkii.
/// Si kastaba ha ahaatee, `&mut expr as *mut _` abuuraa tixraac ka hor inta saarayay in tilmaamaha ah cayriin, iyo tixraaca in uu ku xiran yahay xeerarka la mid ah sida oo dhan tixraacyo kale.
///
/// Dhaqaaluhu wuxuu abuuri karaa tilmaam cayriin ah *isagoon* abuurin tixraac marka hore.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` abuuri lahaa tixraaca ah unaligned, iyo sidaas noqon Dhaqanka undefined!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` ku qasbaya inay nuqul ka sameeyaan goobta halkii ay ka abuuri lahaayeen tixraac
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}