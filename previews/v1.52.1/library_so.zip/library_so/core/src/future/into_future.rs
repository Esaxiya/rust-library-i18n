use crate::future::Future;

/// U beddelashada `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Wax soo saarkii future uu soo saari doono marka la dhammeeyo.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Noocee ah future ayaan tan u beddeleynaa?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Waxay ka abuurtaa future qiime.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}