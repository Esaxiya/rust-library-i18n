#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future ka dhigan tahay xisaabinta ah asynchronous.
///
/// A future waa qiimaha laga yaabo in aan dhammeeyey weli kombiyuutarka.
/// Nooca noocan ah ee "asynchronous value" wuxuu u suurta gelinayaa dunta inay sii wadato inay qabato shaqo waxtar leh inta ay sugeyso qiimaha inuu soo baxo.
///
///
/// # Habka `poll` The
///
/// Habka asaasiga ah ee future, `poll`,*iskudayada* si loogu xaliyo future qiime ugu dambeeya.
/// Habkani ma xannibi doono haddii qiimaha uusan diyaar ahayn.
/// Taabadalkeed, howsha hada socota waxaa loo qorsheeyay in lasoo toosiyo markay macquul tahay in horumar horleh lasameeyo ayadoo markale la codeeyo.
/// `context` The maray in hab `poll` ku siin karaan [`Waker`] ah, taas oo ah inaanu u ah tooso hawsha hadda.
///
/// Markaad isticmaaleyso future, guud ahaan si toos ah uma wici doontid `poll`, laakiin beddelkeeda `.await` qiimaha.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Nooca qiimaha lagu soo saaray dhammaystirka.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Isku dayga inaad ku xalliso future qiimaha ugu dambeeya, adigoo diiwaangelinaya hawsha hadda socota ee soo kicinta haddii qiimaha aan weli la helin.
    ///
    /// # Soo celinta qiimaha
    ///
    /// Shaqadani waxay soo noqotaa:
    ///
    /// - [`Poll::Pending`] haddii future ma uu diyaar u yahay weli
    /// - [`Poll::Ready(val)`] natiijada `val` ee tan future haddii ay si guul leh ku dhammaatay.
    ///
    /// Mar haddii future dhammaado, macaamiisha waa inaysan mar kale `poll` marin.
    ///
    /// Marka future ah diyaar ma aha weli, `poll` laabtay `Poll::Pending` iyo dukaamada Gadzhiyev oo ka mid ah [`Waker`] ka soo guuriyeen ka [`Context`] hadda.
    /// [`Waker`]-kan ayaa markaa la toosiyaa mar haddii future uu horumar samayn karo.
    /// Tusaale ahaan, future la sugi saldhigba si ay u noqdaan akhrin wici lahaa `.clone()` on [`Waker`] oo ku kaydiso.
    /// Marka signal a gaaray meel kale oo muujinaysa in godka waa akhrin karo, [`Waker::wake`] waxaa lagu magacaabaa iyo godka hawsha future ayaa dawakhsan.
    /// Marka hawsha la dhacdeyna kor, waa in ay isku dayaan in ay `poll` future mar kale, taas oo laga yaabaa ama ma soo saari karaan qiimaha kama dambays ah.
    ///
    /// Xusuusnow in wicitaano badan oo loo diro `poll`, kaliya [`Waker`] oo ka socda [`Context`] oo loo gudbiyay wicitaankii ugu dambeeyay waa in loo qoondeeyo si loo helo soo kicinta.
    ///
    /// # Astaamaha Runtime
    ///
    /// Futures kaligeed waa *aan firfircooneyn*;waa in ay si firfircoon uga * *`poll`ed in ay horumar ka samayso, taasoo la micno ah in mar kasta oo hawsha hadda waxaa u dhacdeyna, waa in si firfircoon dib-u-`poll` ilaa futures in ay wali xiiso in.
    ///
    /// function `poll` The aan loo yeedhin si joogta ah in loop a dhagan-halkii, waa in kaliya waxaa loogu yeedhi markii future waxay muujinaysaa in ay diyaar u tahay in ay horumar ka samayso (wacaya `wake()`) waa.
    /// Haddii aad taqaanid s0call-ka `poll(2)` ama `select(2)` ee ku yaal Unix waxaa xusid mudan in futures caadi ahaan aysan * la kulmin isla dhibaatooyinka "all wakeups must poll all events";ay ka badan sida `epoll(4)` yihiin.
    ///
    /// fulinta An of `poll` waa ku dadaalaan in ay si deg deg ah ku noqon, oo waa in aan loo joojiyo.si deg deg ah soo laabtay ka hortagtaa baahneyn urka kor u threads ama siddo dhacdo.
    /// Haddii ay ka hor wakhtigaas call a in `poll` laga yaabaa qaadato muddo la og yahay, shaqada waa in la iibinayo iyo balligii dun (ama wax la mid ah) si loo hubiyo in si deg deg ah `poll` noqon karin.
    ///
    /// # Panics
    ///
    /// Marka future ah ayaa dhameystirtay (laabtay `Ready` ka `poll`), wacaya habka ay `poll` mar kale laga yaabaa panic, weligiis xannibi, ama sabab noocyada kale ee dhibaatooyinka;trait `Future` meelaha lagama rabo shuruudo on saamaynta call a sida.
    /// Si kastaba ha noqotee, maadaama habka `poll` uusan calaamadeynin `unsafe`, Rust sharciyadiisa caadiga ah ayaa lagu dabaqaa: wicitaanadu waa inaysan waligood keenin dabeecad aan la qeexin (musuqmaasuq xasuusta, adeegsi qaldan ee howlaha `unsafe`, ama wixii la mid ah), iyadoo aan loo eegin gobolka future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}