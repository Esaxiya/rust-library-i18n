#![stable(feature = "futures_api", since = "1.36.0")]

//! Qiyamka aan is lahayn.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Noocan ayaa loo baahan yahay maxaa yeelay:
///
/// a) Generator ma hirgelin karo `for<'a, 'b> Generator<&'a mut Context<'b>>`, marka waxaan u baahanahay inaan ka gudubno tilmaame cayriin (eeg <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) tilmaamo qaydhiin iyo `NonNull` ma aha `Send` ama `Sync`, si ay sidoo kale ka dhigi lahaa hal future non-Send/Sync kasta, oo ma rabno in.
///
/// Waxay kaloo fududeyneysaa hoos u dhigga HIR ee `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Ku duub koronto-dhaliye future.
///
/// Shaqadani waxay soo celineysaa `GenFuture` hoosta, laakiin waxay ku qarinaysaa `impl Trait` si ay u bixiso farriimo qalad fiican (`impl Future` halkii ay ka ahaan lahayd `GenFuture<[closure.....]>`).
///
// Kani waa `const` si looga fogaado khaladaadka dheeraadka ah ka dib markaan ka soo kabanno `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Waxaan ku tiirsan yihiin xaqiiqda ah in async/await futures waa dhaqaaqayn si loo abuuro deyn is-referential in matoor sababaya.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // AMMAANKA: Safe sababtoo ah waxaan nahay !Unpin + !Drop, oo taasi waa uun qiyaas beer.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Dib u cusbooneysii koronto-dhaliyaha, isaga oo u rogaya `&mut Context` tilmaame ceeriin ah `NonNull`.
            // `.await` hoos u dhigista ayaa si aamin ah ugu tuuri doonta taas `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `cx.0` uu yahay tilmaam sax ah
    // taas oo buuxisa dhammaan shuruudaha tixraaca la beddeli karo.
    unsafe { &mut *cx.0.as_ptr().cast() }
}