//! Weelasha mutable Shareable.
//!
//! ammaanka xasuusta Rust ku salaysan yahay xeerkan: Marka la eego shay `T`, waxaa suurto gal ah oo kaliya in ay leeyihiin mid ka mid ah kuwan soo socda:
//!
//! - Isagoo dhowr tixraacyada aan beddelmi karin (`&T`) in shayga (sidoo kale loo yaqaan aliasing ** **).
//! - Haysashada hal tixraac oo is bedbeddelaya (``&mut T '') shayga (sidoo kale loo yaqaan **isbadal**).
//!
//! Tan waxaa fuliya isku-duwaha 'Rust'.Si kastaba ha noqotee, waxaa jira xaalado aan sharcigani ku habbooneyn.Mararka qaarkood waxaa loo baahan yahay in ay leeyihiin tixraacyo badan in shay oo weli way isbaddali.
//!
//! Weelasha la beddeli karo ee la wadaagi karo ayaa jira si ay u oggolaadaan isu-beddelidda hab xakamaysan, xitaa haddii uu jiro u-soo-gal.Labada [`Cell<T>`] iyo [`RefCell<T>`] labaduba way oggol yihiin in sidan loo sameeyo qaab isku duuban.
//! Si kastaba ha ahaatee, mana `Cell<T>` mana `RefCell<T>` waa nabad thread (iyagu ma ay hirgeliyaan [`Sync`]).
//! Haddii aad u baahan tahay in la sameeyo aliasing iyo isbedel u dhexeeya threads badan waxaa suurtagal ah si ay u isticmaalaan noocyada [`Mutex<T>`], [`RwLock<T>`] ama [`atomic`].
//!
//! Qiimayaasha oo ka mid ah noocyada `Cell<T>` iyo `RefCell<T>` la qaadheen laga yaabaa tixraac la wadaago (ie
//! nooca guud ee `&T`), halka inta badan noocyada Rust kaliya lagu beddeli karo tixraacyo gaar ah (`&mut T`).
//! Waxaan dhahnaa `Cell<T>` iyo `RefCell<T>` waxay bixiyaan 'isbeddel gudaha ah', marka loo eego noocyada Rust ee caadiga ah ee muujiya 'isbeddellada dhaxalka'.
//!
//! Noocyada unugyada waxay ku yimaadaan laba dhadhan: `Cell<T>` iyo `RefCell<T>`.`Cell<T>` qalab mutability gudaha by dhaqaaqin qiimaha gudaha iyo dibedda ee `Cell<T>` ah.
//! Si loo adeegsado tixraacyada halkii laga qiimeyn lahaa, mid waa inuu adeegsadaa nooca `RefCell<T>`, isagoo helaya quful qoris ka hor intaanad is beddelin.`Cell<T>` wuxuu bixiyaa habab lagu soo ceshano laguna beddelo qiimaha gudaha ee hadda jira:
//!
//!  - Noocyada hirgeliya [`Copy`], habka [`get`](Cell::get) wuxuu dib u soo ceshanayaa qiimaha gudaha ee hadda jira.
//!  - Waayo, noocyada in la hirgeliyo [`Default`], habka [`take`](Cell::take) ka badalay qiimaha hadda gudaha la [`Default::default()`] iyo laabtay qiimaha bedelay.
//!  - Waayo, dhamaan noocyada, habka [`replace`](Cell::replace) ka badalay qiimaha hadda gudaha iyo celinta qiimaha bedelay iyo gubtay, habka [`into_inner`](Cell::into_inner) `Cell<T>` iyo celinta qiimaha gudaha.
//!  Intaa waxaa sii dheer, habka [`set`](Cell::set) ayaa beddelaya qiimaha gudaha, isaga oo hoos u dhigaya qiimaha la beddelay.
//!
//! `RefCell<T>` isticmaalaa nool Rust ay u leedahay fulinta 'amaahda firfircoon', geedi socod ku dheehan yahay mid dalban kartaa meel gaar ah, gaar ah, in qiimaha ugu hooseeyey helitaanka mutable.
//! Boorrooyinka loogu talagalay 'RefCell<T>'S waxaa lagu raad joogaa' xilliyada ', oo ka duwan noocyada tixraaca hooyo ee Rust oo gebi ahaanba si rasmi ah loola socdo, isla markaana la soo ururiyo.
//! Sababtoo ah deymaha `RefCell<T>` waa kuwo firfircoon waxaa suurtagal ah in la isku dayo in la amaahdo qiimo durba la amaahday;markay taasi dhacdo waxay keentaa dunta panic.
//!
//! # Goorta la dooranayo isbeddellada gudaha
//!
//! mutability The badan dhaxlay, halkaas oo waa mid ay heli karaan gaar ah si ay isbaddali qiimaha a, waa mid ka mid ah xubno ka af muhiim ah oo awood Rust inay sabab si xoog leh oo ku saabsan aliasing pointer, soo jiidasho leh ka hortagga cayayaanka shil.
//! Sababta oo ah in, mutability dhaxlay waxaa la doorbiday, iyo mutability gudaha waa wax ka mid ah xalka ugu dambeeya.
//! Maaddaama noocyada unugyadu ay awood u siinayaan isbeddel halka haddii kale la diidi lahaa in kastoo, waxaa jira munaasabado marka isbeddellada gudaha ay habboonaan karto, ama xitaa *ay tahay in* la isticmaalo, tusaale ahaan
//!
//! * Soo bandhigida isbeddelka 'inside' ee wax aan la beddeli karin
//! * Faahfaahinta hirgelinta qaabab macquul ah oo aan macquul ahayn.
//! * Iskudhinta hirgelinta [`Clone`].
//!
//! ## Soo bandhigida isbeddelka 'inside' ee wax aan la beddeli karin
//!
//! Qaar badan oo ka mid ah noocyada tilmaamaha caqliga leh ee la wadaago, oo ay ku jiraan [`Rc<T>`] iyo [`Arc<T>`], waxay bixiyaan konteynarro la wada dheellitiri karo isla markaana lala wadaagi karo dhinacyo badan.
//! Sababtoo ah qiimaha ku jira waxaa laga yaabaa in ay tarmaan-aliased, waxay kaliya laga amaahan karaa `&`, ma `&mut`.
//! Unugyo la'aanteed ma ahan wax aan macquul aheyn in lagu beddelo xogta gudaha tilmaamahan caqliga gabi ahaanba.
//!
//! Waa markaas aad caadi u ah in ay ku riday `RefCell<T>` ah gudaha noocyada tilmaamaha la wadaago si mutability nooleyno:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Abuur baloog cusub si aad u xadiddo baaxadda amaahda firfircoon
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Ogow in haddii aan weli ma ha weyddiisto hore ee kayd ku soo dhacaan baaxadda markaas buu amaahdaa ku xiga keeni lahaa dun firfircoon panic.
//!     //
//!     // Tani waa halista ugu weyn ee isticmaalka `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Ogsoonow in tusaale ahaan this isticmaalaa `Rc<T>` oo aan `Arc<T>`.RefCell<T>'s waxaa loogu talagalay xaaladaha hal-dunta ah.Qiimee in aad isticmaasho [`RwLock<T>`] ama [`Mutex<T>`] haddii aad u baahan tahay la wadaago mutability xaalad multi-xidhnayn.
//!
//! ## faahfaahinta Hirgelinta habab macquul-aan beddelmi karin
//!
//! Mararka qaarkood waxaa laga yaabaa in la jecel yahay aan u soo bandhigaan in API ah in uu jiro isbedel ayaa dhacaya "under the hood".
//! Tani waxay noqon kartaa sababtoo ah macquul hawlgalka waa aan beddelmi karin, laakiin tusaale ahaan, caching ciidamada fulinta si ay u qabtaan waxaa isbeddel;ama sababta oo ah waa in aad shaqo hidda wadayaasha si ay u fuliyaan hab trait in markii hore lagu qeexay in ay qaataan `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Xisaabinta qaaliga ah ayaa halkan tageysa
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## fulintii Mutating of `Clone`
//!
//! Kani waa kiis gaar ah, laakiin caadi ah, kiiskii hore: qarsoodi isu beddelidda howlaha u muuqda kuwo aan la beddeli karin.
//! Habka [`clone`](Clone::clone) ayaa la filayaa in ay waxba ka beddelin qiimaha isha, waxaana la sheegay in ay qaataan `&self`, ma `&mut self`.
//! Sidaa darteed, isbeddel kasta oo ku dhaca habka `clone` waa inuu adeegsadaa noocyada unugyada.
//! Tusaale ahaan, [`Rc<T>`] waxay haysaa tirinta tixraaceeda gudaha `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Meel xasuus beddel ah.
///
/// # Examples
///
/// Tusaalahan, waxaad arki kartaa in `Cell<T>` awood u siinayo isbeddel ku yimaada qaab aan la beddeli karin.
/// Si kale haddii loo dhigo, waxay awood u siineysaa "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // QALAD: `my_struct` waa mid aan la beddeli karin
/// // my_struct.regular_field =qiimo cusub;
///
/// // SHAQADA: in kastoo `my_struct` aan la beddeli karin, `special_field` waa `Cell`,
/// // taas oo had iyo jeer la beddeli karo
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Ka eeg [module-level documentation](self) wixii intaa ka badan.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Waxay abuurtaa `Cell<T>`, oo leh qiimaha `Default` ee T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Waxay abuurtaa `Cell` cusub oo ka kooban qiimaha la siiyay.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Dajisaa qiimaha ku jira.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Wuxuu beddelayaa qiimaha laba unug.
    /// Kala duwanaanshaha `std::mem::swap` waa in shaqadani aysan u baahnayn tixraac `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // AMMAANKA: Tani waxay noqon kartaa khatar ah haddii ka threads gaar ah u yeedhay, laakiin `Cell`
        // waa `!Sync` marka tani ma dhici doonto
        // Tani sidoo kale ma burineyso tilmaame kasta maxaa yeelay `Cell` waxay hubineysaa inaysan jirin wax kale oo tilmaamaya mid ka mid ah ``Cell`s ''.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Wuxuu ku badalayaa qiimaha kujira `val`, wuxuuna soo celinayaa qiimihii hore ee kujiray.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // BADBAADADA: Tani waxay sababi kartaa tartamo xog ah haddii looga yeedho dun gaar ah,
        // laakiin `Cell` waa `!Sync` marka tani ma dhici doonto.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Kala bixisa qiimaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Soo celiyaa nuqul ah qiimaha kujira.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // BADBAADADA: Tani waxay sababi kartaa tartamo xog ah haddii looga yeedho dun gaar ah,
        // laakiin `Cell` waa `!Sync` marka tani ma dhici doonto.
        unsafe { *self.value.get() }
    }

    /// Waxay cusbooneysiisaa qiimaha kujira adoo adeegsanaya hawl waxayna soo celineysaa qiimaha cusub.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Ku soo celiya tilmaame cayriin xogta aasaasiga ah ee qolka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ku soo celiyaa tixraac la beddeli karo xogta aasaasiga ah.
    ///
    /// Wicitaankani wuxuu amaahan doonaa `Cell` si isku mid ah (oo la isu ururiyo) kaas oo dammaanad qaadaya inaan haysanno tixraaca kaliya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Sooceliyaa `&Cell<T>` ka `&mut T` a
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // BADBAADADA: `&mut` waxay hubisaa marin gaar ah.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Qaadataa qiimaha gacanta, taasoo ka dhigeysa `Default::default()` in ay meel.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Ka soo celiyaa `&[Cell<T>]` `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // BADBAADADA: `Cell<T>` wuxuu leeyahay isla qaabeynta xusuusta sida `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Meel xasuusta la beddelayo oo leh xeerar amaah ahaan si hufan loo hubiyay
///
/// Ka eeg [module-level documentation](self) wixii intaa ka badan.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Cilad ay soo celisay [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Cilad ay soo celisay [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Qiyamyada togan ayaa matalaya tirada `Ref` firfircoon.Qiyamyada taban waxay matalaan tirada `RefMut` firfircoon.
// Qaar badan oo 'RefMut`s ah ayaa firfircoonaan kara halmar markiiba haddii ay tixraacaan qaybo gaar ah, oo aan wareejin karin oo ah `RefCell` (tusaale, kala duwanaansho kala duwan oo jeex ah).
//
// `Ref` iyo `RefMut` labaduba waa laba eray oo xajmi ahaan leh, sidaa darteedna waxay u badan tahay inaysan jiri doonin waligeed 'Ref`s ama' RefMut`s jiritaan ah oo buux dhaafiya kala badh tirada `usize`.
// Sidaa darteed, `BorrowFlag` malaha waligiis ma buuxsami doono ama hoos uma qulquli doono.
// Si kastaba ha noqotee, tani maahan dammaanad, maaddaama barnaamijka cudurada uu si isdaba joog ah u abuuri karo ka dibna mem::forget ``Ref`s ama '' RefMut`s.
// Sayidka, code oo dhan waa in ay si cad u hubiyo dhulka qarqinaya, oo underflow si ay u unsafety fogow, ama ugu yaraan dhaqanto si sax ah ay dhacdo in la faafi ama underflow dhaca (tusaale ahaan, arki BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Abuuraa `RefCell` cusub oo ka kooban `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Wuxuu cunaa `RefCell`, isagoo soo celinaya qiimaha la duubay.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Tan iyo markii ay shaqo this qaadataa `self` (ku `RefCell`) by qiimaha, compiler ah soo jiidasho leh cadeyso in aan hadda u amaahannay.
        //
        self.value.into_inner()
    }

    /// Badalay qiimaha ku duudduubtay oo la mid cusub, soo laabtay qiimaha jir ah, oo aan deinitializing mid ka mid ah.
    ///
    ///
    /// function Taasi waxay u dhigantaa [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics haddii qiimaha waxaa hadda la amaahday.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Badalay qiimaha ku duudduubtay oo la mid cusub ka `f` xisaabiyaa, soo laabtay qiimaha jir ah, oo aan deinitializing mid ka mid ah.
    ///
    ///
    /// # Panics
    ///
    /// Panics haddii qiimaha waxaa hadda la amaahday.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Wuxuu kudhaafaa qiimaha la duubay ee `self` oo leh qiimaha la duubay ee `other`, isagoon midkoodna ujeesanayn.
    ///
    ///
    /// Shaqadani waxay u dhigantaa [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics haddii qiimaha ka mid `RefCell` waxaa hadda la amaahday.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Si aan macquul aheyn ayaa amaahda qiimaha la duubay.
    ///
    /// Amaahdu waxay soconeysaa illaa inta laga soo noqonayo baaxadda `Ref`.
    /// Amaahyo badan oo aan la beddeli karin ayaa isla mar la bixin karaa.
    ///
    /// # Panics
    ///
    /// Panics haddii qiimaha xilligan si isku mid ah loo amaahday.
    /// Nooc aan cabsi lahayn, isticmaal [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Tusaale panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutably deyn qiimaha ku duudduubay, soo laabtay qalad haddii qiimaha waxaa hadda mutably amaahatay.
    ///
    ///
    /// Amaahdu waxay soconeysaa illaa inta laga soo noqonayo baaxadda `Ref`.
    /// Amaahyo badan oo aan la beddeli karin ayaa isla mar la bixin karaa.
    ///
    /// Tani waa kala duwanaansho non-argagaxsanaayeen of [`borrow`](#method.borrow) ah.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // BADBAADADA: `BorrowRef` waxay hubisaa in ay jirto marin aan la beddeli karin oo keliya
            // in qiimaha halka amaahatay.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Iskudhaaf ahaan ayaa amaahda qiimaha la duubay.
    ///
    /// amaahdaa uu socdaa ilaa `RefMut` soo noqdeen ama dhammaan `RefMut`s oo ka soo jeeda waxaa baaxadda bixidda.
    ///
    /// Qiimaha lama amaahan karo inta amaahdani shaqeyneyso.
    ///
    /// # Panics
    ///
    /// Panics haddii qiimaha waxaa hadda la amaahday.
    /// Waayo, kala duwanaansho non-argagaxsanaayeen ah, isticmaali [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Tusaale panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutably deyn qiimaha ku duudduubay, soo laabtay qalad haddii qiimaha waxaa hadda la amaahday.
    ///
    ///
    /// amaahdaa uu socdaa ilaa `RefMut` soo noqdeen ama dhammaan `RefMut`s oo ka soo jeeda waxaa baaxadda bixidda.
    /// Qiimaha lama amaahan karo inta amaahdani shaqeyneyso.
    ///
    /// Tani waa noocyada aan argagax lahayn ee [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // BADBAADADA: `BorrowRef` wuxuu dammaanad qaadayaa marin gaar ah.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Ku soo celiya tilmaame cayriin xogta aasaasiga ah ee qolka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Ku soo celiyaa tixraac la beddeli karo xogta aasaasiga ah.
    ///
    /// Wicitaankani wuxuu amaahan doonaa `RefCell` si isku mid ah (isku dubbaridan) markaa looma baahna baaritaanno firfircoon.
    ///
    /// Si kastaba ha ahaatee Digtoonaadana, habkan filaysaa `self` in ay mutable, taas oo guud ahaan waa kiiska ma marka la isticmaalayo `RefCell` ah.
    ///
    /// Bal u fiirso habka [`borrow_mut`] halkii haddii `self` aan la beddeli karin.
    ///
    /// Sidoo kale, fadlan la soco in qaabkani yahay mid loogu talagalay oo keliya duruufo gaar ah oo badiyaa aanu ahayn waxa aad rabto.
    /// In case of shaki, isticmaali [`borrow_mut`] halkii.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Ka noqo saameynta ilaalada xanniban ee ku saabsan xaaladda amaahda ee `RefCell`.
    ///
    /// call Tani waxay la mid tahay [`get_mut`] laakiin dheeraad ah oo khaas ah.
    /// Waxaa deyn `RefCell` mutably si loo hubiyo in deyn ma jiraan, ka dibna resets gobolka raad deyn la wadaago.
    /// Tani waa ku haboon, haddii qaar deyn `Ref` ama `RefMut` ayaa la xaday.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutably deyn qiimaha ku duudduubay, soo laabtay qalad haddii qiimaha waxaa hadda mutably amaahatay.
    ///
    /// # Safety
    ///
    /// Si ka duwan `RefCell::borrow`, qaabkani waa mid aan ammaan ahayn maxaa yeelay ma soo celinayo `Ref`, sidaas awgeed calanka amaahda ee aan la taaban.
    /// Mutably amaahashada `RefCell` halka tixraaca by habkan ku soo laabtay waa nool yahay waa dhaqan undefined.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // BADBAADADA: Waxaan hubineynaa in qofna uusan hadda si firfircoon wax u qorin, laakiin waa
            // mas'uuliyadda qofka soo wacaya inuu hubiyo in qofna uusan wax qorin illaa tixraaca la soo celiyey aan la isticmaali doonin.
            // Sidoo kale, `self.value.get()` waxaa loola jeedaa qiimaha ay leedahay `self` oo sidaas ayaa lagu dammaanad qaadayaa inuu shaqeynayo inta uu nool yahay `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Wuxuu qaataa qiimaha la duubay, isagoo uga tagaya `Default::default()` meeshiisa.
    ///
    /// # Panics
    ///
    /// Panics haddii qiimaha waxaa hadda la amaahday.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics haddii qiimaha xilligan si isku mid ah loo amaahday.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Abuuraa `RefCell<T>` ah, iyadoo qiimaha `Default` ee T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics haddii qiimaha ka mid `RefCell` waxaa hadda la amaahday.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics haddii qiimaha ka mid `RefCell` waxaa hadda la amaahday.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics haddii qiimaha ka mid `RefCell` waxaa hadda la amaahday.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics haddii qiimaha ka mid `RefCell` waxaa hadda la amaahday.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics haddii qiimaha ka mid `RefCell` waxaa hadda la amaahday.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics haddii qiimaha ka mid `RefCell` waxaa hadda la amaahday.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics haddii qiimaha ka mid `RefCell` waxaa hadda la amaahday.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Incrementing weyddiisto waxay keeni kartaa in qiimaha a non-akhriska (<=0) xaaladaha soo socda:
            // 1. Waxay ahayd <0, ie waxaa qoraal ammaahdo, sidaas awgeed ma ogolaan karo weyddiisto a akhrin sabab u ah sharciyada aliasing tixraaca Rust ee
            // 2.
            // Waxay ahayd isize::MAX (xaddiga ugu badan ee amaahda aqrinta) waxayna ku soo rogmatay isize::MIN (xaddiga ugu badan ee qorista amaahda) sidaa darteed ma oggolaan karno amaah dheeri ah oo akhris ah maxaa yeelay isize ma matali karaan deynno badan oo akhris ah (tani waxay dhici kartaa oo keliya haddii aad mem::forget ka badan qadar yar oo joogta ah `Ref`s, taas oo aan ahayn dhaqanka wanaagsan)
            //
            //
            //
            //
            None
        } else {
            // Incrementing weyddiisto waxay keeni kartaa in qiimaha reading ah (> 0) xaaladaha soo socda:
            // 1. Waxay ahayd=0, waxaa ie ma deyn buu igu ahaa, iyo waxaan ku qaadato weyddiisto ugu horeysay akhrin
            // 2. Waxay ahayd> 0 iyo <isize::MAX, ie
            // waxaa jiray amaah la akhriyay, iyo isize waa weyn oo ku filan si ay u matalaan isagoo hal amaah akhriska dheeraad ah
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Tan iyo Ref this ka jira, waxaannu og nahay calanka weyddiisto waa weyddiisto reading a.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Looga hortago counter weyddiisto ka Daadan galay weyddiisto qoraal ah.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Wuxuuuna tixraac amaahday si ay qiimo in sanduuqa `RefCell` ah.
/// Nooca duubka ah ee loogu talagalay qiime aan macquul ahayn oo laga amaahday `RefCell<T>`.
///
/// Ka eeg [module-level documentation](self) wixii intaa ka badan.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Nuqulo ah `Ref`.
    ///
    /// `RefCell` horeyba waa loo amaahatay ama loo amaahday, markaa tani ma fashilmi karto.
    ///
    /// Tani waa hawl la xiriirta oo u baahan in loo isticmaalo sidii `Ref::clone(...)`.
    /// Hirgelinta `Clone` ama qaab wax u dhimaya isticmaalka baahsan ee `r.borrow().clone()` si loo mideeyo waxyaabaha ku jira `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Ka dhigayaa `Ref` cusub oo qayb ka mid ah xogta u amaahannay.
    ///
    /// `RefCell` horeyba waa loo amaahatay ama loo amaahday, markaa tani ma fashilmi karto.
    ///
    /// Tani waa hawl la xiriirta oo u baahan in loo isticmaalo sidii `Ref::map(...)`.
    /// Habka A faragelin lahaa hababka magac la mid ah oo ku saabsan waxyaabaha uu `RefCell` loo isticmaalo iyada oo `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Waxay u sameyneysaa `Ref` cusub qayb ikhtiyaar u ah xogta amaahda.
    /// Waardiyihii asalka ahaa waxaa loo soo celiyey `Err(..)` haddii xiritaanku soo laabto `None`.
    ///
    /// `RefCell` horeyba waa loo amaahatay ama loo amaahday, markaa tani ma fashilmi karto.
    ///
    /// Tani waa hawl la xiriirta oo u baahan in loo isticmaalo sidii `Ref::filter_map(...)`.
    /// Habka A faragelin lahaa hababka magac la mid ah oo ku saabsan waxyaabaha uu `RefCell` loo isticmaalo iyada oo `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Jajabiyaa `Ref` ah oo wuxuu galay kala duwan `Ref`s ah ee ka kooban oo kala duwan oo ka mid ah xogta u amaahannay.
    ///
    /// `RefCell` horeyba waa loo amaahatay ama loo amaahday, markaa tani ma fashilmi karto.
    ///
    /// Tani waa hawl la xiriirta oo u baahan in loo isticmaalo sidii `Ref::map_split(...)`.
    /// Habka A faragelin lahaa hababka magac la mid ah oo ku saabsan waxyaabaha uu `RefCell` loo isticmaalo iyada oo `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// U beddel tixraac xogta aasaasiga ah.
    ///
    /// `RefCell` gundhigiisu weligeed si iskumid ah looma amaahan karo mar walbana waxay umuuqan doontaa durba si aan macquul ahayn amaah ahaan.
    ///
    /// Ma ahan fikrad wanaagsan in la daadiyo wax ka badan tixraacyo joogto ah.
    /// `RefCell` mar kale lama amaahan karo haddii tiro yar oo daad ahi ay guud ahaan dhacday.
    ///
    /// Tani waa hawl la xiriirta oo u baahan in loo isticmaalo sidii `Ref::leak(...)`.
    /// Habka A faragelin lahaa hababka magac la mid ah oo ku saabsan waxyaabaha uu `RefCell` loo isticmaalo iyada oo `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // By halmaamay Ref this aan loo hubiyo in counter weyddiisto in RefCell ah ma aan tegi karo dib u isticmaalin gudahood noolyihiin `'b`.
        // Resetting gobolka raadraaca tixraaca u baahan tahay tixraac gaar ah si ay RefCell u amaahannay.
        // Looma samayn karo tixraacyo dheeraad ah oo is-beddeli kara unugga asalka ah.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Ka dhigayaa `RefMut` cusub oo qayb ka mid ah xogta soo amaahday, tusaale ahaan, an enum duwanaansho.
    ///
    /// `RefCell` waxaa hore u amaahatay mutably, si taasi ma dafiri karto.
    ///
    /// Tani waa hawl la xiriirta oo u baahan in loo isticmaalo sidii `RefMut::map(...)`.
    /// Habka A faragelin lahaa hababka magac la mid ah oo ku saabsan waxyaabaha uu `RefCell` loo isticmaalo iyada oo `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): hagaaji deynta-jeegga
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Waxay u sameyneysaa `RefMut` cusub qayb ikhtiyaar u ah xogta amaahda.
    /// Waardiyihii asalka ahaa waxaa loo soo celiyey `Err(..)` haddii xiritaanku soo laabto `None`.
    ///
    /// `RefCell` waxaa hore u amaahatay mutably, si taasi ma dafiri karto.
    ///
    /// Tani waa hawl la xiriirta oo u baahan in loo isticmaalo sidii `RefMut::filter_map(...)`.
    /// Habka A faragelin lahaa hababka magac la mid ah oo ku saabsan waxyaabaha uu `RefCell` loo isticmaalo iyada oo `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): hagaaji deynta-jeegga
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // AMMAANKA: shaqadu waxay ku haysaa tixraac gaar ah muddada
        // ay call dhex `orig`, iyo tilmaamaha uu yahay kaliya de-tilmaansado gudaha ee call function marnaba jidaynayey tixraaca gaar ah si ay uga baxsadaan ka.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // AMMAANKA: waa isku mid sida kor ku xusan.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Jajabiyaa `RefMut` ah oo wuxuu galay `RefMut`s kala duwan oo qaybaha kala duwan ee xogta u amaahannay.
    ///
    /// `RefCell` The salka ku sii mutably amaahatay doonaa ilaa labadoodaba ku soo laabtay `RefMut`s baxa baaxadda.
    ///
    /// `RefCell` waxaa hore u amaahatay mutably, si taasi ma dafiri karto.
    ///
    /// Tani waa shaqo ah la xiriira in loo baahan yahay in loo isticmaalo `RefMut::map_split(...)`.
    /// Habka A faragelin lahaa hababka magac la mid ah oo ku saabsan waxyaabaha uu `RefCell` loo isticmaalo iyada oo `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Diinta galay tixraac mutable in ay xogta ku lammaan.
    ///
    /// `RefCell` salka ma laga amaahan karo mar kale iyo mar walba ka muuqan doontaa mar hore mutably amaahatay, samaynta tixraaca ku soo laabtay kaliya ee gudaha.
    ///
    ///
    /// Tani waa shaqo ah la xiriira in loo baahan yahay in loo isticmaalo `RefMut::leak(...)`.
    /// Habka A faragelin lahaa hababka magac la mid ah oo ku saabsan waxyaabaha uu `RefCell` loo isticmaalo iyada oo `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // By halmaamay BorrowRefMut this aan loo hubiyo in counter weyddiisto in RefCell ah ma aan tegi karo dib u isticmaalin gudahood noolyihiin `'b`.
        // Resetting gobolka raadraaca tixraaca u baahan tahay tixraac gaar ah si ay RefCell u amaahannay.
        // Looma samayn karo tixraacyo dheeri ah unugga asalka ah inta lagu gudajiro noloshaas, taas oo ka dhigaysa amaahda hadda jirta tixraaca kaliya ee inta hadhay nolosha.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Si ka duwan BorrowRefMut::clone, cusub ayaa loogu yeeraa inuu abuuro bilowga
        // mutable tixraaca, iyo sidaa darteed waxaa waajib ah hadda noqon lahayn tixraac jira.
        // Sayidka, halka isabdal Gadzhiyev refcount ku mutable, halkan waxaan si cad oo kaliya ogolaan socday ka aan la isticmaalin in aan la isticmaalin, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones `BorrowRefMut` ah.
    //
    // Tani waxay ansax tahay oo keliya haddii `BorrowRefMut` kasta loo adeegsado in lagu raaco tixraac isbeddel ah oo ku saabsan nooc gaar ah, oo aan dib u wareejinaynin shayga asalka ah.
    //
    // Tani kuma jirto kumbuyuutarrada 'Clone impl' sidaa darteed koodhku tan uguma yeeri karo si aan toos ahayn.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Looga hortago counter weyddiisto ka underflowing ah.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// nooca duuban A for qiimaha mutably laga soo amaahday `RefCell<T>` ah.
///
/// Ka eeg [module-level documentation](self) wixii intaa ka badan.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Bu'da heer hoose for mutability gudaha ee Rust.
///
/// Haddii aad qabto wax tixraac `&T`, ka dibna si caadi in Rust ku optimizations matalaa compiler ku salaysan aqoonta in dhibcood `&T` in xogta aan beddelmi karin.Mutating in xogta, tusaale ahaan iyada oo alias ama by transmuting `&T` galay `&mut T` ah, waxaa loo arkaa dhaqanka undefined.
/// `UnsafeCell<T>` Ka bixitaanka dammaanad-qaad la'aanta ah ee `&T`: tixraac wadaag ah `&UnsafeCell<T>` wuxuu tilmaami karaa xogta la beddelayo.Tan waxaa lagu magacaabaa "interior mutability".
///
/// Dhammaan noocyada kale oo u oggolaan mutability gudaha, sida `Cell<T>` iyo `RefCell<T>`, gudaha isticmaali `UnsafeCell` in duub xogta ay.
///
/// Fiiro gaar ah in kaliya damaanad tuso taladiisa, waayo, tixraacyo la wadaago waxaa saameeya `UnsafeCell`.Dammaanadda gaarka ah ee tixraacyada la beddeli karo saameyn kuma yeelan.Waxaa jira *jirin hab sharci* si aad u hesho aliasing `&mut`, xitaa ma la `UnsafeCell<T>`.
///
/// `UnsafeCell` API lafteeda farsamo ahaan waa mid aad ufudud: [`.get()`] wuxuu ku siinayaa tilmaame cayriin ah `*mut T` waxyaabaha ku jira.Waxay u jirtaa illaa _you_ sidii naqshadeeyaha soo-saarista inuu si sax ah u isticmaalo tilmaamaha cayriin.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Shuruucda saxda ah ee loo yaqaan 'Rust aliage' ayaa xoogaa is beddelaya, laakiin qodobbada ugu waaweyn laguma murmi karo:
///
/// - Haddii aad la abuuro tixraac ammaan ah la noolaa `'a` (mid ah `&T` ama `&mut T` tixraaca) waa la heli karo by code ammaan ah (tusaale ahaan, maxaa yeelay, waxaad u soo laabtay), ka dibna aad waa in aan u helaan xogta iyo jid kasta oo soo horjeedda in tixraac ka dhiman ee `'a`.
/// Tusaale ahaan, tan macnaheedu yahay in haddii aad ka `UnsafeCell<T>` ah qaadan `*mut T` oo si `&T` ku tuur, ka dibna xogta ee `T` waa in aan beddelmi karin (modulo kasta oo xogta laga helay `UnsafeCell` gudahood `T`, dabcan) ilaa uu nool yahay tixraac in uu dhaco.
/// Sidoo kale, haddii aad abuurto tixraac `&mut T` ah oo lagu sii daayo lambarka amniga, markaa waa inaadan marin xogta ku jirta `UnsafeCell` illaa tixraacaasi uu dhacayo.
///
/// - Waqtiyada oo dhan, waa in aad ka fogaato jinsiyadaha xogta.Haddii threads badan ay helaan isla `UnsafeCell` ah, ka dibna qoray kasta waa in ay leedahay sax ah a dhacaya-hor la xiriirta dhammaan Furidda kale (ama isticmaalka atomics).
///
/// Si loo caawiyo la design habboon, ee xaaladood soo socda ayaa si cad shaaca ka qaaday sharci ah code hal-ku dhafnaa:
///
/// 1. tixraaca A `&T` lagu sii deyn karo code ammaan ah oo halkaas ku karaa wada-jira oo leh tixraacyada kale `&T`, laakiin aan la `&mut T` a
///
/// 2. tixraaca A `&mut T` laga yaabaa in la sii daayay si code ammaan la siiyo mana kale `&mut T` mana `&T` co-jirana la.`&mut T` waa inuu had iyo jeer noqdaa mid gaar ah.
///
/// Xusuusnow intaad wax ka beddeleyso waxyaabaha ku jira `&UnsafeCell<T>` (xitaa inta tixraacyada kale ee `&UnsafeCell<T>` loo yaqaanno unugga) waa hagaag (waa haddii aad ku xoojiso kuwa aan kor ku soo xusnay si kale), weli waa dhaqan aan la qeexin inaad yeelato magacyo badan oo `&mut UnsafeCell<T>` ah.
/// Taasi waa, `UnsafeCell` waa duub loogu talagalay inay yeeshaan isdhexgal gaar ah _shared_ accesses (_i.e._, iyada oo loo marayo tixraaca `&UnsafeCell<_>`);ma jiro wax sixir ah haba yaraatee markii aad la macaamilayso _exclusive_ accesses (_e.g._, iyada oo loo marayo `&mut UnsafeCell<_>`): midkoodna unugga ama qiimaha duuduuban midkoodna lama magacaabi karo muddada uu deynsanayo `&mut`.
///
/// Tan waxaa soo bandhigay marin-qaade [`.get_mut()`], oo ah _safe_ getter oo soo saara `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Halkan waxaa ah tusaale soo bandhigaya sida dhawaaqa loogu beddelayo waxyaabaha ku jira `UnsafeCell<_>` inkasta oo ay jiraan tixraacyo badan oo loo bixiyo unugga:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Ku hel tixraacyo badan/isku mid ah/wadaag ah isla `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // BADBAADADA: baaxadda dhexdeeda ma jiraan tixraacyo kale oo ku saabsan waxyaabaha 'x',
///     // sidaas annagaa leh wax ku ool ah u gaar ah.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- deyn-+
///     *p1_exclusive += 27; // |
/// } // <---------- kama gudbi karo qodobkaan -------------------+
///
/// unsafe {
///     // AMMAANKA: gudahood qofna baaxadda sugayaa in ay gaar ku yidhi waxyaabaha x` ee ay helaan,
///     // markaa waxaan heli karnaa marinno wadaag ah oo badan oo isla socda.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Tusaalaha soo socda oo soo bandhigtay xaqiiqda ah in gaar ah si ay u `UnsafeCell<T>` ah helaan ay tilmaamaysaa gaar ah si ay u helaan `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // leh marin gaar ah,
///                         // `UnsafeCell` waa duuban no-op hufan ah, sidaas darteed uma baahna `unsafe` halkan.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Hel tixraaca ururiso-time-hubiyaa gaar ah si ay `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Iyadoo la tixraacayo gaar ah, waxaan way isbaddali karaan waxyaabaha ku for free.
/// *p_unique.get_mut() = 0;
/// // Ama, u dhiganta:
/// x = UnsafeCell::new(0);
///
/// // Marka aynu leedahay qiimaha, waxaan soo saaro kartaa waxyaabaha ku for free.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Waxay dhisaysaa tusaale cusub oo ah `UnsafeCell` kaas oo soo koobaya qiimaha la cayimay.
    ///
    ///
    /// Dhamaan marin u helka qiimaha gudaha iyadoo loo marayo habab waa `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Kala bixisa qiimaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Wuxuu helayaa tilmaame la beddeli karo qiimaha la duubay.
    ///
    /// Tan waxaa lagu tuuri karaa tilmaame nooc kasta oo uu yahay.
    /// Hubso in marin u helka uu yahay mid gaar ah (tixraacyo firfircoon ma leh, wax is beddeli kara ama maahan) markii loo shubayo `&mut T`, oo hubi in aysan jirin wax isku beddel ah ama magacyo la beddelayo oo soconaya marka loo dirayo `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Waxaan kaliya ka tuuri karnaa tilmaamaha `UnsafeCell<T>` ilaa `T` sababtoo ah #[repr(transparent)].
        // Tani xawilaadda xaaladda gaarka ah ee libstd, ma jiraan wax damaanad for code user in this shaqayn doonaa in versions of future compiler ah!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Ku soo celiyaa tixraac la beddeli karo xogta aasaasiga ah.
    ///
    /// Wicitaankani wuxuu amaahan yahay `UnsafeCell` si isku mid ah (oo la isu ururiyo) kaas oo dammaanad qaadaya inaan haysanno tixraaca kaliya.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Wuxuu helayaa tilmaame la beddeli karo qiimaha la duubay.
    /// Farqiga u si [`get`] waa in shaqo this aqbalo tilmaamaha ah cayriin, taas oo faa'iido leh in ay ka fogaadaan abuurka tixraacyo ku meel gaar ah.
    ///
    /// Natiijada waxaa lagu tuuri karaa tilmaame nooc kasta oo uu yahay.
    /// Hubi in ay helaan waa mid gaar ah (tixraac ma firfircoon, mutable ama ma) marka saarayay in `&mut T`, iyo in la xaqiijiyo in aanay jirin Isbedelo ama Kash mutable socday markii saarayay in `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Bilaabidda tartiib tartiib ah ee `UnsafeCell` waxay ubaahantahay `raw_get`, maadaama wicitaanka `get` uu ubaahan doono abuuritaanka tixraac xogta aan la ogeyn:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Waxaan kaliya ka tuuri karnaa tilmaamaha `UnsafeCell<T>` ilaa `T` sababtoo ah #[repr(transparent)].
        // Tani xawilaadda xaaladda gaarka ah ee libstd, ma jiraan wax damaanad for code user in this shaqayn doonaa in versions of future compiler ah!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Abuuraa `UnsafeCell` ah, iyadoo qiimaha `Default` ee T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}