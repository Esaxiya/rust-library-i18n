//! Tani waa module gudaha loo isticmaalo by ifmt ah!waqtiga shaqada.Qaab-dhismeedyadan waxaa lagu siidaayay qaabab kala duwan si loo hormariyo xargaha qaab waqti ka hor.
//!
//! sharaxyo waxay la mid u dhigma ay `ct` yihiin, laakiin ku kala duwan yihiin in la soo jiidasho leh qoondeeyey karaa oo waxaa wax yar ka filaayo in Runtime ah
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// alignments suurto gal ah in loo codsan karaa sida qayb ka mid ah amarka ah formatting.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Tilmaamid ah in waxa ku jira loo baahan yahay in bidix loola socdo.
    Left,
    /// Tilmaamid ah in waxyaabaha ku jira ay noqdaan kuwo saxan.
    Right,
    /// Tilmaamid ah in waxyaabaha ku jira ay ahaadaan kuwo isku dhejisan.
    Center,
    /// Iswaafajin lama codsan.
    Unknown,
}

/// Waxaa adeegsaday tilmaamayaasha [width](https://doc.rust-lang.org/std/fmt/#width) iyo [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Lagu qeexay lambar suugaan ah, ayaa keydinaya qiimaha
    Is(usize),
    /// Lagu qeexay adeegsiga `$` iyo `*` syntaxes, wuxuu kaydiyaa tusmada `args`
    Param(usize),
    /// Oo aan lagu cayimin
    Implied,
}