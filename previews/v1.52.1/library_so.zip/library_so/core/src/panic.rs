//! Taageerada Panic maktabadda caadiga ah.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Qaab bixinaya macluumaad ku saabsan panic.
///
/// `PanicInfo` Qaab dhismeedka waxaa loo gudbiyaa panic hook oo ay dejisay shaqada [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Sooceliyaa culeyska bixinta ee laxiriira panic.
    ///
    /// Tani caadi ahaan, laakiin had iyo jeer, waxay noqon doontaa `&'static str` ama [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Haddii Dhaqale `panic!` ka crate `core` ah (aan ka `std`) waxaa loo isticmaalay xarig formatting ah iyo qaar ka mid ah dood dheeraad ah, soo laabtay in fariin diyaar u ah in loo isticmaalo tusaale ahaan la [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Sooceliyaa macluumaadka ku saabsan meesha uu ka yimid panic, haddii la heli karo.
    ///
    /// Habkani wuxuu had iyo jeer soo celin doonaa [`Some`], laakiin tani waxay ku beddeli kartaa noocyada future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Haddii tan loo beddelo in mararka qaarkood la soo celiyo Midna,
        // wax ka qabta kiiskaas std::panicking::default_hook iyo std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ma isticmaali karno downcast_ref: :<String>() halkan
        // maadaama String aan laga heli karin libcore!
        // Mushaharka waa Xadhig markii `std::panic!` loogu yeero doodo badan, laakiin haddii ay sidaas tahay farriinta sidoo kale waa la heli karaa.
        //

        self.location.fmt(formatter)
    }
}

/// struct A oo ay ku jiraan macluumaad ku saabsan meesha uu panic ah.
///
/// Qaab dhismeedkan waxaa sameeyay [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Isbarbardhiga sinnaanta iyo amar bixinta waxaa lagu sameeyaa feyl ahaan, saf, ka dibna mudnaanta safka.
/// Faylasha waxaa loo barbardhigayaa sida xarig, maahan `Path`, oo noqon kara lama filaan.
/// Eeg dukumiintiyada ["Goobta: : file"] si aad uga doodid.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Sooceliyaa meesha uu kasoo jeedo qofka soo wacaya shaqadan.
    /// Haddii qofka soo wacaya hawshaas la caddeeyo markaa goobtiisa wicitaanku waa la soo celinayaa, oo sidaas oo ay tahayna kor ayuu u kacayaa wicitaankii ugu horreeyay ee ka dhex jira hay'ad shaqo oo aan dabagal ku jirin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Sooceliyaa [`Location`] ee loogu yeero.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Ka soo celiyaa [`Location`] gudaheeda qeexitaanka shaqadan.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ku socodsiinta isla hawsha aan la xakamayn meel kale waxay na siinaysaa isla natiijada
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // socodsiinta hawsha dabagalka ee goob kale waxay soo saartaa qiime ka duwan
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Sooceliyaa magaca faylka ilaha uu ka yimid asalka panic.
    ///
    /// # `&str`, ma ahan `&Path`
    ///
    /// Magaca ku soo laabtay loola jeedaa jid isha ku saabsan nidaamka ururinayaan ah, laakiin ma aha ansax ah in this wakiil toos ah sida `&Path` ah.
    /// Koodhkan la soo ururiyey wuxuu ku shaqeyn karaa nidaam ka duwan kan leh hirgelinta `Path` oo ka duwan nidaamka ku siinaya waxyaabaha ku jira maktabadduna xilligan ma leh nooc ka duwan "host path".
    ///
    /// Dabeecadda ugu yaabka badan waxay dhacdaa marka faylka "the same" la gaarsiin karo iyadoo loo marayo dariiqyo badan oo nidaamka moduleka ah (badiyaa iyadoo la adeegsanayo astaamaha `#[path = "..."]` ama wax la mid ah), taas oo sababi karta waxa u muuqda inay isku mid yihiin si ay uga soo laabtaan qiimayaas kala duwan shaqadan.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Qiimahani kuma haboona inuu u gudbo `Path::new` ama wax dhisayaal la mid ah markay madadaalada martida loo yahay iyo barxada bartilmaameedka ay ku kala duwan yihiin.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Sooceliyaa nambarka xariiqa ee panic asal ahaan ka yimid.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Soocelinaya tiirarka uu panic ka soo bilaabmay
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait gudaha ah oo ay adeegsato libstd si ay xogta uga gudbiso libstd una gudbiso `panic_unwind` iyo waqtiyada kale ee panic.
/// Looma jeedin in la xasiliyo wakhti kasta, ha isticmaalin.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Qaado lahaanshaha buuxa ku jira.
    /// Nooca soo noqoshada runti waa `Box<dyn Any + Send>`, laakiin kuma isticmaali karno `Box` libcore.
    ///
    /// Ka dib markii habkan loo yeedhay, kaliya qaar ka mid ah qiimaha ugu dambeeya ee dummy ayaa ku hadhay `self`
    /// Wicitaanka qaabkan laba jeer, ama wacida `get` kadib markaad wacdo qaabkan, waa qalad.
    ///
    /// Doodda waa la amaahday maxaa yeelay panic runtime (`__rust_start_panic`) kaliya wuxuu helaa `dyn BoxMeUp` amaah ah.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Just amaahan jira.
    fn get(&mut self) -> &(dyn Any + Send);
}