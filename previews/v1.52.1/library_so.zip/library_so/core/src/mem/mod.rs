//! hawlaha aasaasiga ah ee wax looga qabanayo xasuusta.
//!
//! Sawirkan waxa ku jira hawlaha for querying xajmiga iyo in lays of nooc, bilaabida oo qeexa xasuusta.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Waxay qaadataa lahaansho iyo "forgets" ku saabsan qiimaha **iyadoo aan la wadin wax burburiya**.
///
/// khayraadka kasta oo qiimaha maamushaa, sida xasuusta taallo ama riixo file a, Hadhi doonaa mid weligiis waara ee gobolka gaari.Si kastaba ha ahaatee, waxa uu ma aha ballanqaad in tilmaamo in xasuusta la sii shaqeyn doontaa.
///
/// * Haddii aad rabto in aad daadato xasuusta, arki [`Box::leak`].
/// * Haddii aad rabto in aad si aad u hesho tilmaamaha a ceeriin in xusuustiisa, arki [`Box::into_raw`].
/// * Haddii aad rabto in aad u Wakiil ah qiimaha si sax ah, socda oo ay destructor, arki [`mem::drop`].
///
/// # Safety
///
/// `forget` aan la calaamadeeyay sidii `unsafe`, maxaa yeelay, dammaanadaha ammaanka Rust ee ha ka mid ah damaanad ah in destructors had iyo jeer ku ordi doonaa.
/// Tusaale ahaan, barnaamij abuuri karaan wareegga tixraac isticmaalaya [`Rc`][rc], ama wac [`process::exit`][exit] looga baxo oo aan ordaya destructors.
/// Sidaa darteed, u oggolaanshaha `mem::forget` lambarka nabdoon ma aha aasaas ahaan beddelidda dammaanadaha amniga Rust.
///
/// Taas oo uu sheegay, dusaya khayraadka sida xasuusta ama walxaha I/O waa sida caadiga ah aan loo baahnayn.
/// Baahida loo yimaado ilaa in qaar ka mid ah xaaladaha isticmaalka gaarka ah ee FFI ama code ammaan ahayn, laakiin xitaa markaas, [`ManuallyDrop`] waxaa caadi ahaan ka doorteen.
///
/// Sababtoo ah in la iloobo qiimaha waa la oggol yahay, lambar kasta oo `unsafe` ah oo aad qorto waa inuu oggolaadaa suurtagalnimadaas.Waxaad ma soo celin kartaa qiimaha iyo filayaan in wacaha qasab ku ordi doonaa destructor qiimaha ee.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// The isticmaalka ammaan qaadanin ee `mem::forget` waa inay horjoogsadaan destructor qiimaha uu fuliyey trait `Drop` ah.Tusaale ahaan, tani daadato doonaa `File` ah, ie
/// soo cesho booska uu qaatay doorsoomaha laakiin waligaa ha xirin kheyraadka nidaamka salka ku haya:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Tani waa mid waxtar leh marka lahaanshaha ee kheyraadka salka markii hore loo wareejiyay code ka baxsan Rust, tusaale ahaan by gudbinta descriptor ee file ceeriin in code C.
///
/// # Xiriirka `ManuallyDrop`
///
/// Iyadoo `mem::forget` sidoo kale waxaa loo isticmaali karaa si ay u gudbiyaan xasuusta * * lahaanshaha, sidaas samaynaya waa baadi-nugul.
/// [`ManuallyDrop`] waa in la adeegsadaa halkii.Tixgeli, tusaale ahaan, lambarkan:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Dhis `String` isticmaalaya waxyaabaha `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // daadato `v` sababtoo ah xasuusta waxa ay hadda maamulaan `s`
/// mem::forget(v);  // Qalad, v ma ansax yahay mana loo gudbin karo hawl
/// assert_eq!(s, "Az");
/// // `s` waxaa si dadban hoos iyo xasuusta deallocated.
/// ```
///
/// Waxaa jira laba arrimood oo la tusaalaha kore:
///
/// * Haddii lambar dheeri ah lagu daro inta udhaxeysa dhismaha `String` iyo ducada `mem::forget()`, panic gudaheeda ah waxay sababi doontaa labalaab la'aan maxaa yeelay isla xusuusta waxaa wada qabta labada `v` iyo `s`.
/// * Ka dib markii wacaya `v.as_mut_ptr()` iyo gudbinta lahaanshaha xogta si `s`, qiimaha `v` waa mid khaldan.
/// Xitaa markii qiime uun loo wareejiyo `mem::forget` (oo aan baari doonin), noocyada qaarkood waxay leeyihiin shuruudo adag oo ku saabsan qiimayaashooda oo ka dhigaya kuwo aan ansax ahayn marka la ruxayo ama aan la lahayn.
/// Adeegsiga qiimayaasha aan ansax ahayn si kasta, oo ay kujirto u gudbintooda ama ka soo celintooda shaqooyinka, waxay ka dhigan tahay dabeecad aan la qeexin waxayna jabin kartaa fikradaha uu soo uruuriyey.
///
/// U wareegida `ManuallyDrop` waxay iska ilaalinaysaa labada arrimood:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Ka hor inta aan guuriso `v` qaybo ay cayriin, hubi in uusan heli hoos!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Haddaba guuriso `v`.hawlaha kuwaas oo aan panic, sidaas darteed waxaa jira ma noqon karo karaa dillaac ah.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Ugu dambeyntiina, dhiso `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` waxaa si dadban hoos iyo xasuusta deallocated.
/// ```
///
/// `ManuallyDrop` si adag ayey uga hortageysaa laba-laab la`aan maxaa yeelay waxaan joojineynaa burburka 'v' ka hor intaadan wax kale sameyn.
/// `mem::forget()` ma ogola tan sababtoo ah waxay cunaysaa dooddeeda, waxay nagu qasbeysaa inaan wacno kaliya ka dib markaan soo saarno wax kasta oo aan uga baahanahay `v`.
/// Xitaa haddii panic la soo bandhigo inta u dhexeysa dhismaha `ManuallyDrop` iyo dhismaha xarigga (oo aan ku dhici karin koodhka sida muuqata), waxay keenaysaa daadasho ee ma ahan labalaab la'aan.
/// Si kale haddii loo dhigo, `ManuallyDrop` ayaa ku khaldan dhinaca wax daadinta halkii uu ka khaldami lahaa dhinaca (laba-laab) daadashada.
///
/// Sidoo kale, `ManuallyDrop` ayaa naga horjoogsanaysa inaan yeelano "touch" `v` kadib markii aan ku wareejinayno lahaanshaha `s`-tallaabada ugu dambaysa ee la falgalka `v` si loo tuuro iyada oo aan la wadin ciddii waxyeellaysay gebi ahaanba waa laga fogaanayaa.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Sida [`forget`], laakiin sidoo kale waxay aqbashaa qiyamka aan la qiyaasi karin.
///
/// Shaqadani waa uun shumis loogu talagalay in laga saaro marka muuqaalka `unsized_locals` uu xasilloonaado.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Soocelisaa cabirka nooc baytiyada.
///
/// Si gaar ah, tanina waa isdhaafka bytes ee udhaxeeya walxaha isdaba jooga ah ee isugu jira nooc walxaha noocaas ah oo ay kujiraan suufka iswaafajinta.
///
/// Sidaa darteed, nooc kasta oo `T` ah iyo dherer `n`, `[T; n]` wuxuu leeyahay cabbirka `n * size_of::<T>()`.
///
/// Guud ahaan, cabirka nooc ma aha mid xasilloon marka la isu geeyo, laakiin noocyo gaar ah sida kuwa hordhaca ah ayaa jira.
///
/// Jadwalka soo socdaa wuxuu siinayaa cabbirka hordhaca.
///
/// Nooca |cabirka_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Intaas waxaa sii dheer, `usize` iyo `isize` waxay leeyihiin cabir isku mid ah.
///
/// Noocyada `*const T`, `&T`, `Box<T>`, `Option<&T>`, iyo `Option<Box<T>>` dhammaantood waa isku cabir.
/// Haddii `T` uu yahay Sized, dhammaan noocyadaasi waxay le'eg yihiin cabirka `usize`.
///
/// Isbedelka tilmaamaha tilmaamkiisu kama beddelayo cabirkiisa.Sidan oo kale, `&T` iyo `&mut T` waxay leeyihiin cabir isku mid ah.
/// Sidoo kale `*const T` iyo `* mut T`.
///
/// # Cabirka alaabada `#[repr(C)]`
///
/// Matalaada `C` ee walxaha waxay leedahay qaab qeexan.
/// Qaab dhismeedkaan, cabirka alaabtu sidoo kale waa xasilloon yihiin illaa iyo inta beeraha oo dhami leeyihiin cabbir deggan.
///
/// ## Xajmiga Xargaha
///
/// `structs`, cabirka waxaa go'aamiya algorithm-ka soo socda.
///
/// Qeyb kasta oo ka mid ah qaab-dhismeedka oo lagu amrey amar ku dhawaaqid
///
/// 1. Ku dar cabirka berrinka.
/// 2. Ku soo koobi cabirka hadda midka ugu dhow ee garoonka xiga ee [alignment].
///
/// Ugu dambeyntii, ku wareeji cabbirka dhismaha dhowrka ugu dhow ee [alignment].
/// Iswaafajinta qaabdhismeedka ayaa inta badan ah isku dheellitirka ugu ballaadhan dhammaan qeybaheeda;tan waxaa lagu badali karaa isticmaalka `repr(align(N))`.
///
/// Si ka duwan `C`, jaangooyooyin cabbirkoodu yahay eber lama soo koobi karo ilaa hal baiti cabbir ahaan.
///
/// ## Xajmiga 'Enums'
///
/// Faahfaahin aan lahayn xog aan ka ahayn cunsuriyadda ayaa leh cabbir la mid ah kan loo yaqaan 'C enum' oo ku yaal barxadda loo soo ururiyey.
///
/// ## Tirada Ururada Shaqaalaha
///
/// Cabirka midowgu waa cabirka dhulkiisa ugu weyn.
///
/// Si ka duwan `C`, ururada shaqaalaha eber ee xajmigooda ah lama soo koobi karo ilaa hal baiti cabbir ahaan.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Qaar hordhac ah
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Qaar ka mid ah qabanqaabooyinka
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Sinnaanta cabirka tilmaamaha
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Adeegsiga `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Cabbirka duurka ugu horeysay ee waa 1, si dar 1 in le'eg.Cabirku waa 1.
/// // in lays The duurka labaad waa 2, si dar 1 in size ee kursiga.Cabirku waa 2.
/// // Cabbirka duurka labaad waa 2, sidaas dar 2 in le'eg.Cabirku waa 4.
/// // Iswaafajinta goobta seddexaad waa 1, marka ku dar 0 cabirka suufka.Cabirku waa 4.
/// // Cabbirka duurka saddexaad waa 1, si dar 1 in le'eg.Cabirku waa 5.
/// // Ugu dambeyntii, in lays ee struct yahay 2 (maxaa yeelay, in lays ugu weyn id ah beeraheedii waa 2), si dar 1 in size ee kursiga.
/// // Cabbirku waa 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Xeerarka tuple waxay raacaan isla sharciyada.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Ogsoonow in dib-u-habeynta beeraha ay hoos u dhigi karto cabirka.
/// // Waxaan ka saari kara labada bytes kursiga adigoo `third` `second` ka hor.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // size Midowga waa size oo duurka ugu weyn.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Soocelisaa cabirka tilmaanta-in-baitiyada.
///
/// Tani badanaa waxay la mid tahay `size_of::<T>()`.
/// Si kastaba ha noqotee, marka `T`*uusan* lahayn cabir ahaan si muuqata loo yaqaan, tusaale ahaan, jeex [`[T]`][slice] ama [trait object], markaa `size_of_val` ayaa loo isticmaali karaa si loo helo cabirka firfircoon ee la yaqaan.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // BADBAADADA: `val` waa tixraac, markaa waa tilmaam sax ah oo cayiman
    unsafe { intrinsics::size_of_val(val) }
}

/// Soocelisaa cabirka tilmaanta-in-baitiyada.
///
/// Tani badanaa waxay la mid tahay `size_of::<T>()`.Si kastaba ha noqotee, marka `T`*uusan* lahayn cabir ahaan si muuqata loo yaqaan, tusaale ahaan, jeex [`[T]`][slice] ama [trait object], markaa `size_of_val_raw` ayaa loo isticmaali karaa si loo helo cabirka firfircoon ee la yaqaan.
///
/// # Safety
///
/// Shaqadani waxay badbaado u tahay oo keliya in la waco haddii xaaladaha soo socdaa qabtaan:
///
/// - Haddii `T` uu yahay `Sized`, shaqadani had iyo jeer waa aamin in la waco.
/// - Haddii dabada aan la qiyaasin ee `T` ay tahay:
///     - a [slice], markaa dhererka jeex jeexa waa inuu noqdaa isku-darka bilowga ah, cabbirka *qiimaha dhan*(dhererka dabada firfircoon + horgalaha qiyaasta cabirkiisu yahay) waa inuu ku habboon yahay `isize`.
///     - [trait object] ah, markaa qaybta tilmaamtu ee tilmaamtu waa inay tilmaamto vtable ansax ah oo lagu kasbaday qasbid aan kala go 'lahayn, iyo cabirka *qiimaha dhan*(dhererka dabada firfircoon + horgalaha cabbirka leh) waa inuu ku habboon yahay `isize`.
///
///     - (unstable) [extern type] ah, markaa shaqadani had iyo jeer waa aamin in la waco, laakiin panic ama si kale ha u soo celiso qiime qaldan, maadaama qaabka bannaanka loo yaqaan aan la aqoon.
///     Tani waa dabeecad la mid ah tan [`size_of_val`] marka la tixraaco nooc leh dabada nooca dusha.
///     - haddii kale, si muxaafid ah looma oggola in loo yeedho shaqadan.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BADBAADADA: Wicitaanku waa inuu keenaa tilmaame cayriin oo ansax ah
    unsafe { intrinsics::size_of_val(val) }
}

/// Soocelisaa iswaafajinta ugu yar ee loo yaqaan 'ABI'.
///
/// Tixraac kasta oo ku saabsan qiimaha nooca `T` waa inuu noqdaa tiro ka mid ah lambarkan.
///
/// Tani waa iswaafajinta loo adeegsaday dhismooyinka.Way ka yaraan kartaa isku xidhka la doorbiday.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Soocelisaa iswaafajinta ugu yar ee [ABI] ee nooca qiimaha uu tilmaamayo `val`.
///
/// Tixraac kasta oo ku saabsan qiimaha nooca `T` waa inuu noqdaa tiro ka mid ah lambarkan.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // BADBAADADA: val waa tixraac, markaa waa tilmaame cayriin oo ansax ah
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Soocelisaa iswaafajinta ugu yar ee loo yaqaan 'ABI'.
///
/// Tixraac kasta oo ku saabsan qiimaha nooca `T` waa inuu noqdaa tiro ka mid ah lambarkan.
///
/// Tani waa iswaafajinta loo adeegsaday dhismooyinka.Way ka yaraan kartaa isku xidhka la doorbiday.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Soocelisaa iswaafajinta ugu yar ee [ABI] ee nooca qiimaha uu tilmaamayo `val`.
///
/// Tixraac kasta oo ku saabsan qiimaha nooca `T` waa inuu noqdaa tiro ka mid ah lambarkan.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // BADBAADADA: val waa tixraac, markaa waa tilmaame cayriin oo ansax ah
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Soocelisaa iswaafajinta ugu yar ee [ABI] ee nooca qiimaha uu tilmaamayo `val`.
///
/// Tixraac kasta oo ku saabsan qiimaha nooca `T` waa inuu noqdaa tiro ka mid ah lambarkan.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Shaqadani waxay badbaado u tahay oo keliya in la waco haddii xaaladaha soo socdaa qabtaan:
///
/// - Haddii `T` uu yahay `Sized`, shaqadani had iyo jeer waa aamin in la waco.
/// - Haddii dabada aan la qiyaasin ee `T` ay tahay:
///     - a [slice], markaa dhererka jeex jeexa waa inuu noqdaa isku-darka bilowga ah, cabbirka *qiimaha dhan*(dhererka dabada firfircoon + horgalaha qiyaasta cabirkiisu yahay) waa inuu ku habboon yahay `isize`.
///     - [trait object] ah, markaa qaybta tilmaamtu ee tilmaamtu waa inay tilmaamto vtable ansax ah oo lagu kasbaday qasbid aan kala go 'lahayn, iyo cabirka *qiimaha dhan*(dhererka dabada firfircoon + horgalaha cabbirka leh) waa inuu ku habboon yahay `isize`.
///
///     - (unstable) [extern type] ah, markaa shaqadani had iyo jeer waa aamin in la waco, laakiin panic ama si kale ha u soo celiso qiime qaldan, maadaama qaabka bannaanka loo yaqaan aan la aqoon.
///     Tani waa dabeecad la mid ah tan [`align_of_val`] marka la tixraaco nooc leh dabada nooca dusha.
///     - haddii kale, si muxaafid ah looma oggola in loo yeedho shaqadan.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BADBAADADA: Wicitaanku waa inuu keenaa tilmaame cayriin oo ansax ah
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Sooceliyaa `true` haddii hoos u dhigo qiimaha nooca `T`.
///
/// Tani waa uun tilmaam wax-ka-qabasho, waxaana laga yaabaa in loo dhaqan-geliyo si xeel-dheer:
/// waxay soo celin kartaa `true` noocyada aan dhab ahaan u baahnayn in la tuuro.
/// Sidan oo kale had iyo jeer soo noqoshada `true` waxay noqon laheyd dhaqan gal sax ah shaqadan.Si kastaba ha noqotee haddii shaqadani si dhab ah u soo celiso `false`, markaa waxaad hubin kartaa hoos u dhigista `T` ma laha wax saameyn ah.
///
/// Fulinta heerka hoose ee waxyaabaha sida uruurinta, oo ubaahan in lagu tuuro xogtooda, waa inay adeegsadaan shaqadan si looga fogaado iskudayada aan loo baahnayn ee lagu tuurayo dhamaan waxyaabaha kujira markay burburayaan.
///
/// Tani wax isbeddel ah kuma keeni karto sii deynta dhismayaasha (halkaasoo loop aan wax saameyn ah ku yeelanaynin si fudud loo ogaado loona baabi'iyo), laakiin badanaa guul weyn ayey u tahay dhismayaasha qaladka.
///
/// Xusuusnow in [`drop_in_place`] ay horey u sameysay baaritaankaan, marka haddii culeyskaaga shaqada lagu dhimi karo tiro yar oo wicitaano [`drop_in_place`] ah, adeegsiga tanina waa mid aan loo baahnayn.
/// Gaar ahaan ogsoonow inaad [`drop_in_place`] jeexi karto, taasina waxay sameyn doontaa hal baaritaan oo keliya_oobo dhammaan qiimaha.
///
/// Noocyada sida Vec oo kale markaa waa uun `drop_in_place(&mut self[..])` iyadoon si cad loo adeegsan `needs_drop`.
/// Noocyada sida [`HashMap`], dhanka kale, waa inay hoos u dhigaan qiimaha midba mar oo waa inuu adeegsadaa API-kan.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Waa kuwan tusaale sida ururintu u isticmaali karto `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // daadi xogta
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Soocelisaa qiimaha nooca `T` oo ay matalayaan qaab-qaab-dhan-eber.
///
/// Tani waxay ka dhigan tahay, tusaale ahaan, baatiga xirashada ee `(u8, u16)` daruuri ma ahan eber.
///
/// Ma jiraan wax damaanad ah in qaab-dhan-eber ah uu u taagan yahay qiime sax ah nooc ka mid ah `T`.
/// Tusaale ahaan, qaab-eber-qaabeedku ma aha qiime sax ah oo loogu talagalay noocyada tixraaca (``&T`, `&mut T`) iyo tilmaamayaasha howlaha.
/// U adeegsiga `zeroed` noocyada noocan oo kale ah waxay keeneysaa isla markiiba [undefined behavior][ub] maxaa yeelay [the Rust compiler assumes][inv] in had iyo jeer ay jirto qiime sax ah oo ku jira doorsoomaha ay u aragto in la bilaabay.
///
///
/// Tani waxay leedahay saameyn la mid ah tan [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Waxay waxtar u leedahay FFI mararka qaarkood, laakiin guud ahaan waa in laga fogaadaa.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Si sax ah u isticmaalidda shaqadan: bilaabidda tiro isku jir ah oo eber leh.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Khaldan* adeegsiga shaqadan: bilaabida tixraac eber ah.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Dabeecad aan la qeexin!
/// let _y: fn() = unsafe { mem::zeroed() }; // Iyo markale!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in qiime dhan-eber ay ansax u tahay `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Wuxuu dhaafaa baaritaanka Rust ee hubinta bilowga xusuusta asagoo iska dhigaya inuu soo saarayo qiime nooca `T` ah, isagoo aan waxba qabanaynin.
///
/// **Shaqadani waa mid hoos u dhacday.** Beddel isticmaal [`MaybeUninit<T>`].
///
/// Sababta hoos u dhaca ayaa ah in shaqada asal ahaan aan si sax ah loo isticmaali karin: waxay leedahay saameyn la mid ah tan [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Sida [`assume_init` documentation][assume_init] sharxayo, [the Rust compiler assumes][inv] in qiyamka si sax ah loo bilaabay.
/// Natiijo ahaan, wicitaan tusaale ahaan
/// `mem::uninitialized::<bool>()` wuxuu sababa dhaqan aan la qeexin oo deg deg ah oo ku saabsan soo celinta `bool` oo aan dhab ahaan ahayn `true` ama `false`.
/// Kaaga darane, xusuusta runta ah ee aan la ogaan karin sida tan halkan lagu soo celiyo waxay gaar u tahay in isku-duwaha uu ogyahay inuusan lahayn qiimo go'an.
/// Tani waxay ka dhigeysaa dhaqan aan la qeexin in la helo xog aan la ogeyn oo ku jirta doorsoomaha xitaa haddii doorsoomahaasi uu leeyahay nooc isku-dhafan.
/// (Notice in xeerarka ku wareegsan abyoonayaasha uninitialized aanan weli la dhamaystirin, laakiin ilaa ay ka, waxaa lagu talinayaa in iyaga looga fogaado.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in qiimaha aan tooska ahayn uu ansax yahay `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Waxay ku kala beddelaysaa qiimayaasha laba goobood oo is bedbeddelaya, iyadoo aan midna la sii deyn.
///
/// * Haddii aad rabto inaad ku beddelato qiimo caadi ah ama qiimo jaban, eeg [`take`].
/// * Haddii aad rabto inaad ku beddelato qiimo la soo dhaafay, adigoo soo celinaya qiimihii hore, eeg [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // BADBAADADA: tilmaamayaasha ceeriin waxaa laga abuuray tixraacyo aamin ah oo beddeli kara dhammaantood
    // caqabadaha ku saabsan `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Wuxuu ku beddelayaa `dest` qiimaha asalka ah ee `T`, isagoo soo celinaya qiimihii hore ee `dest`.
///
/// * Haddii aad rabto inaad beddesho qiimaha labada doorsoome, eeg [`swap`].
/// * Haddii aad rabto inaad ku beddesho qiimo la soo dhaafay halkii aad ka heli lahayd qiimaha caadiga ah, eeg [`replace`].
///
/// # Examples
///
/// Tusaale fudud:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` Waxay u oggolaaneysaa lahaanshaha lahaanshaha dhisme iyadoo lagu beddelayo qiimaha "empty".
/// `take` la'aanteed waxaad la kulmi kartaa arrimo sidan oo kale ah:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Xusuusnow `T` qasab maahan inuu hirgeliyo [`Clone`], sidaa darteed xitaa ma awoodi karo isla markaana dib u celin karin `self.buf`.
/// Laakiin `take` waxaa loo isticmaali karaa in lagu kala saaro qiimaha asalka ah ee `self.buf` laga bilaabo `self`, taas oo u oggolaaneysa in dib loo celiyo:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Wuxuu u guuriyaa `src` tixraaca `dest`, isagoo soo celinaya qiimihii hore ee `dest`.
///
/// Midkoodna qiimaha hoos uma dhicin.
///
/// * Haddii aad rabto inaad beddesho qiimaha labada doorsoome, eeg [`swap`].
/// * Haddii aad rabto inaad ku beddesho qiimaha caadiga ah, eeg [`take`].
///
/// # Examples
///
/// Tusaale fudud:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` Waxay u oggolaaneysaa isticmaalka goob dhismeed iyadoo lagu beddelayo qiime kale.
/// `replace` la'aanteed waxaad la kulmi kartaa arrimo sidan oo kale ah:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Xusuusnow in `T` uusan daruuri aheyn hirgelinta [`Clone`], sidaa darteed xitaa ma awoodi karno isku xirka `self.buf[i]` si looga fogaado dhaqaaqa.
/// Laakiin `replace` waxaa loo isticmaali karaa in lagu kala saaro qiimaha asalka ah ee tusmadaas laga soo qaatay `self`, taas oo u oggolaaneysa in dib loo celiyo:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // BADBAADADA: Waxaan ka aqrinaa `dest` laakiin si toos ah ugu qor `src` kadib,
    // sida in qiimahii hore aan la nuqufin.
    // Waxba looma tuuro waxna halkan panic ma sameyn karo.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Qiimayn qiimo leh.
///
/// Tani waxay sidaas sameysaa iyadoo la wacayo hirgelinta doodda ee [`Drop`][drop].
///
/// Tani waxtar ma leh noocyada fuliya `Copy`, tusaale ahaan
/// integers.
/// Qiimayaasha noocan ah waa la koobiyeeyay oo _then_ ayaa loo wareejiyay shaqada, markaa qiimuhu wuu sii jiraa ka dib shaqadan wicitaankeeda.
///
///
/// Shaqadani ma aha sixir;macno ahaan waxaa lagu qeexaa sida
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Sababtoo ah `_x` ayaa loo wareejiyay shaqada, si otomaatig ah ayaa loo tuuraa kahor intaan hawshu soo noqon.
///
/// [drop]: Drop
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // si cad u daadi vector
/// ```
///
/// Maaddaama [`RefCell`] ay fulineyso xeerarka amaahda waqtiga, `drop` wuxuu sii deyn karaa deyn [`RefCell`] ah:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // tanaasulo weyddiisto ku mutable on Afyare this
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Isku-darka iyo noocyada kale ee hirgeliya [`Copy`] saameyn kuma yeelanayaan `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // nuqul ka mid ah `x` ayaa la raray oo la tuuray
/// drop(y); // nuqul ka mid ah `y` ayaa la raray oo la tuuray
///
/// println!("x: {}, y: {}", x, y.0); // wali waa la heli karaa
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Wuxuu u tarjumaa `src` inuu leeyahay nooc `&U` ah, ka dibna wuxuu akhriyaa `src` isagoon dhaqaajin qiimaha ku jira.
///
/// Shaqadani waxay aamin la'aan u qaadan doontaa tilmaame `src` inuu ansax yahay [`size_of::<U>`][size_of] bytes isagoo u gudbinaya `&T` ilaa `&U` ka dibna akhrinaya `&U` (marka laga reebo in tan loo sameeyay si sax ah xitaa marka `&U` ay ka dhigeyso shuruudaha isku dheellitirka adag `&T`).
/// Waxay sidoo kale si aan badbaado lahayn u abuuri doontaa nuqul ka mid ah qiimaha ku jira halkii laga rari lahaa `src`.
///
/// Maaha qalad isku-soo-ururin ah haddii `T` iyo `U` ay leeyihiin cabbirro kala duwan, laakiin waxaa si weyn loogu dhiirrigelinayaa in kaliya loo yeero shaqadan halka `T` iyo `U` ay isku cabir yihiin.Shaqadani waxay kicisaa [undefined behavior][ub] haddii `U` ka weyn yahay `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Nuqul ka soo qaad xogta 'foo_array' oo ula dhaqan sidii 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Wax ka beddel xogta la soo guuriyey
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Waxyaabaha ku jira 'foo_array' may ahayn inay isbadaleen
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Haddii U uu leeyahay shuruud iswaafajin ka saraysa, src lagama yaabo inuu si habboon ula jaanqaado.
    if align_of::<U>() > align_of::<T>() {
        // BADBAADADA: `src` waa tixraac la hubo inuu ansax ku yahay akhriska.
        // Wicitaanku waa inuu damaanad qaadaa in transmut-ka dhabta ahi yahay mid nabdoon.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // BADBAADADA: `src` waa tixraac la hubo inuu ansax ku yahay akhriska.
        // Waxaan kaliya hubinay in `src as *const U` si sax ah loo waafajiyay.
        // Wicitaanku waa inuu damaanad qaadaa in transmut-ka dhabta ahi yahay mid nabdoon.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Nooca hufan ee matalaya midab takoorka enum.
///
/// Ka eeg shaqada [`discriminant`] ee cutubkan wixii macluumaad dheeraad ah.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Kuwani hirgelinta trait lama soo saari karo maxaa yeelay dooni meyno wax xuduud ah oo ku saabsan T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Soo celiyaa qiime si gaar ah u aqoonsanaya qaybta kala duwan ee 'enum variant' ee `v`.
///
/// Haddii `T` ma aha enum ah, function wacaysid tani ma keeni doontaa in dhaqanka undefined, laakiin qiimaha celinta waa la cayimin.
///
///
/// # Stability
///
/// Midabtakoorka nooc ka mid ah buugaagta ayaa is beddeli kara haddii qeexitaanka tiradu isbeddelo.
/// Takoorista nooc ka mid ah wax is beddel ah kuma sameyn doono isku-darka isku-ururinta.
///
/// # Examples
///
/// Tan waxaa loo isticmaali karaa in lagu isbarbardhigo qeeybinta xogta sida, iyadoo la iska indha tirayo xogta dhabta ah:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Sooceliyaa tirada kaladuwanaanta nooca enum ee `T`.
///
/// Haddii `T` ma aha enum ah, function wacaysid tani ma keeni doontaa in dhaqanka undefined, laakiin qiimaha celinta waa la cayimin.
/// Sidoo kale, haddii `T` yahay enum leh noocyo badan oo ka badan `usize::MAX` qiimaha soo noqoshada lama qeexin.
/// Noocyada aan la noolayn ayaa la tirin doonaa.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}