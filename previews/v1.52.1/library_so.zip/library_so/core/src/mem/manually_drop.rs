use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// duuban A si compiler joogsada ka si toos ah ugu yeeray `destructor T` ee.
/// duuban Tani waa 0-kharashka.
///
/// `ManuallyDrop<T>` uu ku xiran yahay optimizations khariidad la mid ah sida `T`.
/// Taa awgeed, waxa uu leeyahay *ma saamayn* on fikrado ah in compiler ka dhigaysa ku saabsan waxyaabaha ay.
/// Tusaale ahaan, bilaabida `ManuallyDrop<&mut T>` la [`mem::zeroed`] waa dhaqan undefined.
/// Haddii aad u baahan tahay in ay la tacaalaan xogta uninitialized, isticmaali [`MaybeUninit<T>`] halkii.
///
/// Ogsoonow in helitaanka qiimaha gudaha `ManuallyDrop<T>` waa ammaan.
/// Tani waxay ka dhigan tahay in `ManuallyDrop<T>` ah, kuwaas oo ka kooban ayaa laga saaray waa in aan loo soo bandhigin iyada oo a API ammaan ah dadweynaha.
/// U dhigma, `ManuallyDrop::drop` waa amni darro.
///
/// # `ManuallyDrop` oo hoos u dhig amar.
///
/// Rust ayaa [drop order] a si wanaagsan u qeexan ee qiimaha.
/// Si aad u hubiso in beeraha ama dadka deegaanka waxaa hoos u si gaar ah, reorder caddayntu uga yimid sida in amarka dhibic awaamiir waa mid ka mid sax ah.
///
/// Waxaa suurto gal ah in ay isticmaalaan `ManuallyDrop` si loo xakameeyo si dhibicda, laakiin tani waxay u baahan tahay code ammaan ahayn, waana adag tahay in la sameeyo si sax ah ay goobjoog ka ahaayeen unwinding.
///
///
/// Tusaale ahaan, haddii aad rabto in aad hubiso in beerta gaar ah waxaa hoos u dhacay ka dib markii dadka kale ku samayso, waxa ay duurka ugu dambeeyey ee struct ka dhigi:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` waa la ridi doonaa ka dib `children`.
///     // Rust balanqaadayo in beeraha waxaa hoos u dhacay si ka mid ah lagu dhawaaqo.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Duub qiimo in gacanta lagu dhigo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Weli waad ku shaqeyn kartaa qiimaha
    /// assert_eq!(*x, "Hello");
    /// // Laakiin `Drop` laguma ordi doono halkan
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Qiimaha wuxuu ka soo saaraa weelka `ManuallyDrop`.
    ///
    /// Tani waxay u oggolaaneysaa qiimaha in mar kale hoos loo dhigo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Tani waxay hoos u dhigeysaa `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Wuxuu kaqaadaa qiimaha weelka `ManuallyDrop<T>`.
    ///
    /// Habkani waxaa ugu horayn loogu talagalay guurayo qiyamka in dhibic.
    /// Halkii isticmaalaya [`ManuallyDrop::drop`] inay gacanta da'a qiimaha, waxaad isticmaali kartaa habkan in ay qaataan qiimaha iyo sida loo isticmaalo waxaa si kastaba ha ahaatee doonayo.
    ///
    /// Mar kasta oo suurto gal ah, waxaa quman in la isticmaalo [`into_inner`][`ManuallyDrop::into_inner`] halkii, taas oo ka horjoogsadaa duplicating content ee `ManuallyDrop<T>` ah.
    ///
    ///
    /// # Safety
    ///
    /// function Tani semantically guuro qiimaha ku jira oo aan ka hortagga isticmaalka dheeraad ah, taasoo ka dhigeysa gobolka weel this iska beddelin.
    /// Waa masuuliyadaada inaad hubiso in `ManuallyDrop`-kan aan dib loo isticmaalin.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // AMMAANKA: waxa aan akhriska ka tixraac, taas oo loo balan qaadayo
        // inuu ansax noqdo akhrinta.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Adigu gacantaada hoos ugu dhig qiimaha ku jira.Tani waa dhab u dhiganta wacaya [`ptr::drop_in_place`] leh tilmaamaha ah in qiimaha ku jira.
    /// Sida oo kale, haddii aan qiimaha ku jira waa struct a buux, destructor waxaa loogu yeedhi doonaa meel aan dhaqaaqin qiimaha, iyo sidaas loo isticmaali karo in si ammaan ah da'a xogta [pinned].
    ///
    /// Haddii aad leedahay lahaanshaha qiimaha, waxaad isticmaali kartaa [`ManuallyDrop::into_inner`] halkii.
    ///
    /// # Safety
    ///
    /// Shaqadani waxay maamushaa burburiyaha qiimaha kujira.
    /// Waxyaabaha kale ee aan ka ahayn isbeddelada uu sameeyay burburiyuhu laftiisa, xusuusta ayaa laga tagay iyada oo aan la beddelin, oo illaa iyo inta uu soo ururiyuhu khuseeyo weli wuxuu hayaa xoogaa qaab ah oo ku habboon nooca `T`.
    ///
    ///
    /// Si kastaba ha ahaatee, tani qiimaha "zombie" waa in aan loo soo bandhigin code ammaan ah, iyo shaqada waa in aan lagu magacaabin ka badan hal jeer.
    /// Si aad u isticmaasho qiimaha ka dib markii uu laga saaray, ama iska qiimaha marar badan, waxay keeni kartaa Dhaqanka undefined (ku xiran tahay waxa `drop` falaa).
    /// Tan waxaa si caadi ah looga hortagi by nidaamka nooca, laakiin dadka isticmaala of `ManuallyDrop` waa in ay ilaaliyaan ballan qaado kuwa aan kaalmo ka compiler ah.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // AMMAANKA: waxa aanu hoos u qiimaha tilmaamay in ay tixraac mutable
        // oo waa la hubaa in ay ansax qoray.
        // Waxay tahay in la wacay in ay hubiso in `slot` aan hoos u dhigi mar kale.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}