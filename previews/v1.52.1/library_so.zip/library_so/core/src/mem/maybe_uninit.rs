use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Nooca duubka ah ee lagu dhisayo xaaladaha aan la ogaan karin ee `T`.
///
/// # Bilaabidda isbeddel la'aanta
///
/// compiler The, guud ahaan, loo maleeyo in variable ah oo si fiican loo initialized sida ay shuruudaha nooca variable ee.Tusaale ahaan, variable ah nooca tixraaca waa in la toosiyaa oo aan waxba.
/// Tani waa invariant ah oo ay tahay in mar walba * * in la fuliyo, xataa code ammaan ahayn.
/// Taa awgeed, eber-bilaabida variable ah nooca tixraaca sababa degdeg ah [undefined behavior][ub], wax dhib ah maleh haddii tixraac in abid uu isticmaalaa in lagu helaan xasuusta:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // dabeecad aan la qeexin!⚠️
/// // Koodh u dhigma oo leh `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // dabeecad aan la qeexin!⚠️
/// ```
///
/// Tan waxaa ka faa'ideystay by compiler ee optimizations kala duwan, sida eliding jeeg-time orod oo fiican qaabka `enum`.
///
/// Sidoo kale, xusuusta gebi ahaanba aan la aqoon waxay yeelan kartaa wax kasta oo nuxur ah, halka `bool` uu had iyo jeer yahay `true` ama `false`.Sidaa awgeed, sameynta `bool` aan la aqoon waa dhaqan aan la qeexin:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // dabeecad aan la qeexin!⚠️
/// // code ayaa u dhigma la `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // dabeecad aan la qeexin!⚠️
/// ```
///
/// Waxaa intaa dheer, xusuusta uninitialized waa gaar ah in aysan u leeyihiin qiimo go'an ("fixed" taasoo la micno ah "it won't change without being written to").Akhrinta hal baiti oo aan aqoon lahayn dhowr jeer ayaa ku siin kara natiijooyin kala duwan.
/// Tani waxay undefined dhaqanka in ay xogta uninitialized in variable ah xitaa haddii variable in uu leeyahay nooca abyoonaha ah, taas oo haddii kale qaban karaan wax hannaankii yara * * go'an:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // dabeecad aan la qeexin!⚠️
/// // code ayaa u dhigma la `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // dabeecad aan la qeexin!⚠️
/// ```
/// (Notice in xeerarka ku wareegsan abyoonayaasha uninitialized aanan weli la dhamaystirin, laakiin ilaa ay ka, waxaa lagu talinayaa in iyaga looga fogaado.)
///
/// On top of in, xusuusnow in noocyada ugu leeyihiin invariants dheeraad ah ka baxsan oo keliya in la tixgeliyo initialized heer nooca.
/// Tusaale ahaan, a `1`-initialized [`Vec<T>`] waxaa loo arkaa initialized (hoos fulinta hadda, tani macnaheedu ma aha in damaanad deggan a) sababtoo ah looga baahan yahay oo kaliya compiler ogyahay waxa ku saabsan waa in pointer xogta waa in ay ahaadaan kuwa aan waxba.
/// Abuuritaanka sida `Vec<T>` uusan sabab * * dhaqanka undefined degdeg ah, laakiin waxay keeni doonaa habdhaqanka undefined leh ugu hawlgallada ammaan ah (oo ay ku jiraan waxa hoos).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` adeegtaa si ay awood code ammaan ahayn in la xogta uninitialized ka qabtaan.
/// Waa signal a in compiler ah oo tilmaamaysa in xogta halkan laga yaabaa *aan* la initialized:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Abuur tixraaca ah si cad uninitialized.
/// // compiler wuxuu ogyahay in xogta gudaha `MaybeUninit<T>` ah waxaa laga yaabaa in aan waxba ka jirin, iyo halkan tani ma aha UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // U dhig qiime sax ah.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Ka saar xogta la bilaabay-tan waxaa kaliya oo la oggol yahay *ka dib* si sax ah oo loo bilaabay `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// compiler The markaas waa ogyahay in aan wax fikrado qaldan ama optimizations on code this.
///
/// Waxaad u malayn kartaa of `MaybeUninit<T>` sida isagoo xoogaa sida `Option<T>` laakiin aan lahayn mid ka mid ah-time baxsad raadraaca iyo iyada oo aan wax ka mid ah hubinta ammaanka ah.
///
/// ## out-pointers
///
/// Waxaad isticmaali kartaa `MaybeUninit<T>` si ay u hirgeliyaan "out-pointers": halkii xogta laga function soo laabtay, waxaa Daliil in qaar ka mid ah xasuusta (uninitialized) u dhigay natiijada galay mari.
/// Tani waxay noqon kartaa mid waxtar leh marka waxaa muhiim u ah wacaha inay gacanta ku sida xasuusta natiijada waxa lagu kaydiyaa uu qoondeeyey, oo aad rabto in aad ka fogaato dhaqaaqdo aan loo baahnayn.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ma tuurayo waxyaabihii hore, taas oo muhiim ah.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Hadda waxaan ognahay in `v` la bilaabay!Tani waxay sidoo kale hubineysaa in vector ah uu si fiican hoos.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Talaalmayaa element-by-element diyaariyeen ah
///
/// `MaybeUninit<T>` waxaa loo isticmaali karaa in lagu bilaabo curis ballaaran oo cunsur-cunsur ah:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Samee shaashad aan la ogeyn oo ah `MaybeUninit`.
///     // `assume_init` waa aamin maxaa yeelay nooca aan sheeganeyno inaan halkaan ka bilownay waa farabadan ``maybeUninit`s '', oo aan ubaahneyn bilaabis.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Dhicida `MaybeUninit` waxba ma qabanayso.
///     // Sayidka isticmaalaya shaqo pointer cayriin halkii `ptr::write` ma keento qiimaha jir uninitialized lagu dejinayo.
/////
///     // Sidoo kale haddii ay jirto panic ah inta lagu guda jiro loop this, waxaan leenahay dillaac xusuusta, laakiin ma jirto arrinta ammaanka xasuusta.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Wax walba waa la bilaabay.
///     // U gudbi tarjumaadda nooca la bilaabay.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Waxa kale oo aad la Arrays qayb initialized, kaas oo laga heli karaa in datastructures heerka hoose shaqeyn karaan.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Samee shaashad aan la ogeyn oo ah `MaybeUninit`.
/// // `assume_init` waa aamin maxaa yeelay nooca aan sheeganeyno inaan halkaan ka bilownay waa farabadan ``maybeUninit`s '', oo aan ubaahneyn bilaabis.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Tiri inta cunsur ee aan u xilsaarnay.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Waayo, wax kasta oo isdiyaarin kara, da'a haddii aynu u qoondeeyey.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Bilaabidda qaab-dhismeedka qaab-dhismeed
///
/// Waxaad isticmaali kartaa `MaybeUninit<T>`, iyo Dhaqale [`std::ptr::addr_of_mut`] ah, in initialize beerta structs beerta:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Bilaabida qaybta `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Talaalmayaa beerta `list` ah Haddii uu jiro panic halkan, ka dibna `String` maanta duurka ku darroor `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Beeraha oo dhan waxaa initialized, si aynu u qayshanno `assume_init` si aad u hesho Foo ah initialized.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` waa la hubaa in ay leeyihiin size isla, in lays, iyo ABI sida `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Si kastaba ha ahaatee xusuusnow in nooc ka mid ah *kooban*`MaybeUninit<T>` a khasab ma aha in qaabka isku mid ah;Rust dammaanad qaad guud ma ahan in aagagga `Foo<T>` ay leeyihiin amar la mid ah kan `Foo<U>` xitaa haddii `T` iyo `U` ay isku cabir iyo iskula mid yihiin.
///
/// Intaas waxaa sii dheer, sababtoo ah qiimaha qayb kasta oo ansax tahay muddo `MaybeUninit<T>` a compiler ma dalban kartaa optimizations non-zero/niche-filling, laga yaabo inay keentay in size a ka weyn:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Haddii `T` uu yahay FFI-aamin, markaa sidoo kale waa `MaybeUninit<T>`.
///
/// Iyadoo `MaybeUninit` waa `#[repr(transparent)]` (muujinaysa waxa damaanad qaadaya isla size, in lays, iyo ABI sida `T`), waxan sameeya *aan* beddelo mid ka mid ah digniinahaa hore.
/// `Option<T>` iyo `Option<MaybeUninit<T>>` weli waxay yeelan karaan cabirro kala duwan, noocyada ay ku jiraan beero nooca `T` ah ayaa la dhigi karaa (oo la qiyaasi karaa) si ka duwan haddii ay aaggaasi ahaan lahaayeen `MaybeUninit<T>`.
/// `MaybeUninit` waa nooc urur shaqaale, iyo `#[repr(transparent)]` on ururada waa deganayn (eeg [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Waqti ka, in nidaamkan saxda ah ee `#[repr(transparent)]` on ururada ahaan umuuruhu laga yaabaa in, iyo `MaybeUninit` laga yaabaa ama ma laga yaabaa in `#[repr(transparent)]`.
/// Taas oo uu sheegay, `MaybeUninit<T>`*mar walba doono* damaanad in uu leeyahay size isla, in lays, iyo ABI sida `T`;waa uun habka `MaybeUninit` u fuliyo dammaanaddaas oo is beddeli karta.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// item Lang si aan qof huwan karo noocyo kale oo ah waxa ku jira.Tani waxay waxtar u leedahay matoorrada.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ma wacaya `T::clone()`, garan mayno karaa haddii aan initialized ku filan in.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Waxay abuurtaa `MaybeUninit<T>` cusub oo lagu bilaabay qiimaha la siiyay.
    /// Waa ammaan in loo yeedho [`assume_init`] qiimaha celinta shaqada this ka.
    ///
    /// Fiiro gaar ah in hoos `MaybeUninit<T>` ah marnaba u yeedhi doonaa `T` ee code dhibic.
    /// Waa masuuliyadaada inaad hubiso in `T` hoos u dhacday haddii la bilaabay.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Abuuraa `MaybeUninit<T>` cusub ee gobolka uninitialized.
    ///
    /// Fiiro gaar ah in hoos `MaybeUninit<T>` ah marnaba u yeedhi doonaa `T` ee code dhibic.
    /// Waa masuuliyadaada inaad hubiso in `T` hoos u dhacday haddii la bilaabay.
    ///
    /// Ka eeg [type-level documentation][MaybeUninit] tusaalooyinka qaarkood.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Abuur soo diyaariyeen cusub oo alaabta `MaybeUninit<T>`, in dawlad uninitialized.
    ///
    /// Note: in a version future Rust habkan noqon karaan loo baahnayn marka Saan suugaan isugu soo ogolaanaya [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Tusaalaha hoos kuqoran kadibna isticmaali kartaa `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Sooceliyaa (suurtagalna yar) cad xogta in ay aheyd mid run akhri
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // AMMAANKA: An uninitialized `[MaybeUninit<_>; LEN]` waa ansax ah.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Abuuraa `MaybeUninit<T>` cusub ee gobolka uninitialized, la xasuusta waxaana ka buuxsantay bytes `0`.Waxay kuxirantahay `T` hadii taasi horey usameysay bilowis sax ah.
    ///
    /// Tusaale ahaan, waxaa `MaybeUninit<usize>::zeroed()` initialized, laakiin `MaybeUninit<&'static i32>::zeroed()` ma aha, maxaa yeelay, tixraac waa in aan waxba.
    ///
    /// Fiiro gaar ah in hoos `MaybeUninit<T>` ah marnaba u yeedhi doonaa `T` ee code dhibic.
    /// Waa masuuliyadaada inaad hubiso in `T` hoos u dhacday haddii la bilaabay.
    ///
    /// # Example
    ///
    /// isticmaalka saxda ah ee shaqada this: bilaabida struct la eber, halkaas oo ay dhammaan beerihii struct qaban karaa xoogaa-hannaankii 0 sida qiimaha sax ah.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Isticmaalka* Si qaldan oo shaqo this: wacaya `x.zeroed().assume_init()` markii `0` ma aha ansax ah qayb-hannaankii nooca:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Inside labo ka mid ah, waxaan la abuuro `NotZero` ah in uusan haysan discriminant oo sax ah.
    /// // Tani waa dhaqan undefined.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // BADBAADADA: `u.as_mut_ptr()` waxay u dhigantaa xusuusta loo qoondeeyay.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Qeexaa qiimaha `MaybeUninit<T>` ah.
    /// Tani overwrites wax qiimo hore oo aan hoos, si taxadir in aadan isticmaali this laba jeer haddii aad rabto in aad ka boodo socda destructor ah.
    ///
    /// Si laguugu sahlo, waxa ay sidoo kale ku soo laabtay tixraac mutable u (hadda si nabad ah initialized) ka kooban `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // BADBAADADA: Waxaan bilownay qiimahan.
        unsafe { self.assume_init_mut() }
    }

    /// Waxay tilmaam u tahay qiimaha ku jira.
    /// Akhriska ka tilmaamaha ama u jeestay galay tixraac waa dhaqan undefined haddii `MaybeUninit<T>` la initialized.
    /// Qoraalka si ay u xasuusta in pointer this (non-transitively) dhibcood waa dhaqan undefined (marka laga reebo gudaha `UnsafeCell<T>` ah).
    ///
    /// # Examples
    ///
    /// isticmaalka saxda ah ee habkan:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Abuur tixraac ah oo wuxuu galay `MaybeUninit<T>` ah.Tani waa caadi maxaa yeelay waan bilownay.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Qalad* isticmaalka qaabkan:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Waxaan abuurnay tixraac ku saabsan vector aan la aqoon!Tani waa dhaqan aan la qeexin.⚠️
    /// ```
    ///
    /// (Notice in xeerarka ku wareegsan tixraacyo xogta uninitialized aanan weli la dhamaystirin, laakiin ilaa ay ka, waxaa lagu talinayaa in iyaga looga fogaado.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` iyo `ManuallyDrop` labaduba waa `repr(transparent)` marka waan tuuri karnaa tilmaamaha.
        self as *const _ as *const T
    }

    /// Helo tilmaamaha a mutable qiimaha ku jira.
    /// Akhriska ka tilmaamaha ama u jeestay galay tixraac waa dhaqan undefined haddii `MaybeUninit<T>` la initialized.
    ///
    /// # Examples
    ///
    /// isticmaalka saxda ah ee habkan:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Abuur tixraac `MaybeUninit<Vec<u32>>` ah.
    /// // Tani waa caadi sababtoo ah waxaan u initialized.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Qalad* isticmaalka qaabkan:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Waxaan abuurnay tixraac ku saabsan vector aan la aqoon!Tani waa dhaqan aan la qeexin.⚠️
    /// ```
    ///
    /// (Notice in xeerarka ku wareegsan tixraacyo xogta uninitialized aanan weli la dhamaystirin, laakiin ilaa ay ka, waxaa lagu talinayaa in iyaga looga fogaado.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` iyo `ManuallyDrop` labaduba waa `repr(transparent)` marka waan tuuri karnaa tilmaamaha.
        self as *mut _ as *mut T
    }

    /// Qeybaha qiimaha weelka `MaybeUninit<T>` ah.Tani waa hab fiican si loo hubiyo in xogta aad hoos doonaa, maxaa yeelay, `T` keentay xiran yahay maamulidda dhibic caadiga ah.
    ///
    /// # Safety
    ///
    /// Waxay tahay in la wacay in ay damaanad in `MaybeUninit<T>` ah run ahaantii waa in dawlad initialized.Wicitaanka marka content uusan weli si buuxda initialized sababaha dhaqanka undefined degdeg ah.
    /// [type-level documentation][inv] wuxuu ka koobanyahay macluumaad dheeri ah oo kusaabsan isbadalkan bilowga ah.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// On top of in, xusuusnow in noocyada ugu leeyihiin invariants dheeraad ah ka baxsan oo keliya in la tixgeliyo initialized heer nooca.
    /// Tusaale ahaan, a `1`-initialized [`Vec<T>`] waxaa loo arkaa initialized (hoos fulinta hadda, tani macnaheedu ma aha in damaanad deggan a) sababtoo ah looga baahan yahay oo kaliya compiler ogyahay waxa ku saabsan waa in pointer xogta waa in ay ahaadaan kuwa aan waxba.
    ///
    /// Abuuritaanka sida `Vec<T>` uusan sabab * * dhaqanka undefined degdeg ah, laakiin waxay keeni doonaa habdhaqanka undefined leh ugu hawlgallada ammaan ah (oo ay ku jiraan waxa hoos).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// isticmaalka saxda ah ee habkan:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Qalad* isticmaalka qaabkan:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` weli lama bilaabin, sidaa darteed qadkaan ugu dambeeya wuxuu sababay dabeecad aan la qeexin.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` la bilaabay.
        // Tani waxay sidoo kale ka dhigan tahay in `self` ay tahay inuu ahaado nooc `value` ah.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Wuxuu ka akhriyaa qiimaha weelka `MaybeUninit<T>`.`T` keentay xiran yahay maamulidda dhibic caadiga ah.
    ///
    /// Mar kasta oo suurto gal ah, waxaa quman in la isticmaalo [`assume_init`] halkii, taas oo ka horjoogsadaa duplicating content ee `MaybeUninit<T>` ah.
    ///
    /// # Safety
    ///
    /// Waxay tahay in la wacay in ay damaanad in `MaybeUninit<T>` ah run ahaantii waa in dawlad initialized.Wicitaanka marka content uusan weli si buuxda initialized sababaha dhaqanka undefined.
    /// [type-level documentation][inv] wuxuu ka koobanyahay macluumaad dheeri ah oo kusaabsan isbadalkan bilowga ah.
    ///
    /// Waxaa intaa dheer, this caleemaha nuqul ka mid ah ka dambeeya xogta isla `MaybeUninit<T>` ah.
    /// Marka la isticmaalayo nuqulo tiro badan oo xogta (wacaya `assume_init_read` marar badan, marka hore waca `assume_init_read` ka dibna [`assume_init`]), waa adiga masuuliyadaada si loo hubiyo in xogta si dhab loo labalaabka.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// isticmaalka saxda ah ee habkan:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` waa `Copy`, si aannu u akhri marar badan.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Kordhinta qiimaha `None` waa caadi, markaa waa inaan aqrinnaa dhowr jeer.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Qalad* isticmaalka qaabkan:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Waxaan hadda abuurnay laba nuqul oo isku mid ah vector, taasoo horseedaysa laba-laba-jabis ⚠️ markay labadooduba hoos u dhacaan!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` la bilaabay.
        // ka `self.as_ptr()` Reading waa ammaan tan iyo `self` waa in la initialized.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Ku daadinaya qiimaha ku jira meesha.
    ///
    /// Haddii aad leedahay lahaanshaha `MaybeUninit` ah, waxaad isticmaali kartaa [`assume_init`] halkii.
    ///
    /// # Safety
    ///
    /// Waxay tahay in la wacay in ay damaanad in `MaybeUninit<T>` ah run ahaantii waa in dawlad initialized.Wicitaanka marka content uusan weli si buuxda initialized sababaha dhaqanka undefined.
    ///
    /// On top of in, dhammaan invariants dheeraad ah oo nooca `T` waa ka dhergi, sida fulinta `Drop` ee `T` (ama xubnihiisa) tiirsan waxaa laga yaabaa on this.
    /// Tusaale ahaan, a `1`-initialized [`Vec<T>`] waxaa loo arkaa initialized (hoos fulinta hadda, tani macnaheedu ma aha in damaanad deggan a) sababtoo ah looga baahan yahay oo kaliya compiler ogyahay waxa ku saabsan waa in pointer xogta waa in ay ahaadaan kuwa aan waxba.
    ///
    /// Geynta sida `Vec<T>` si kastaba ha ahaatee ka dhigi doonaa in dhaqanka undefined.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // AMMAANKA: dammaanadda waa wacay in `self` waxaa initialized iyo
        // wuxuu qanciyaa dhammaan kuwa aan is beddelin ee `T`.
        // Geynta qiimaha meel waa amaan haddii ay taasi tahay kiiska.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Hesho tixraac wadaag ah qiimaha kujira.
    ///
    /// Tani waxay noqon kartaa mid waxtar leh marka waxaan rabnaa in aan ka heli `MaybeUninit` ah oo uu soo initialized laakiin aadan haysan lahaanshaha `MaybeUninit` ah (ka hortagga isticmaalka `.assume_init()`).
    ///
    /// # Safety
    ///
    /// this waca marka content uusan weli si buuxda initialized sababaha dhaqanka undefined: kor u tahay in wacaha in damaanad in `MaybeUninit<T>` ah run ahaantii waa in dawlad initialized.
    ///
    ///
    /// # Examples
    ///
    /// ### isticmaalka saxda ah ee habkan:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Bilow `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Hadda oo `MaybeUninit<_>`-keena la og yahay in la bilaabay, waa caadi in la abuuro tixraac wadaag ah oo ku saabsan:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // AMMAANKA: `x` ayaa initialized.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Isticmaal la'aan* qaabkan:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Waxaan abuurnay tixraac ku saabsan vector aan la aqoon!Tani waa dhaqan aan la qeexin.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialize `MaybeUninit` isticmaalaya `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Tixraaca in `Cell<bool>` ah uninitialized: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` la bilaabay.
        // Tani waxay sidoo kale ka dhigan tahay in `self` ay tahay inuu ahaado nooc `value` ah.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Wuxuu helayaa tixraac (unique) oo la beddeli karo oo ku saabsan qiimaha ku jira.
    ///
    /// Tani waxay noqon kartaa mid waxtar leh marka waxaan rabnaa in aan ka heli `MaybeUninit` ah oo uu soo initialized laakiin aadan haysan lahaanshaha `MaybeUninit` ah (ka hortagga isticmaalka `.assume_init()`).
    ///
    /// # Safety
    ///
    /// this waca marka content uusan weli si buuxda initialized sababaha dhaqanka undefined: kor u tahay in wacaha in damaanad in `MaybeUninit<T>` ah run ahaantii waa in dawlad initialized.
    /// Tusaale ahaan, `.assume_init_mut()` looma adeegsan karo bilowga `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### isticmaalka saxda ah ee habkan:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Wuxuu bilaabaa *dhammaan* baaytka keydka gelinaya.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Bilow `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Imminka waxaannu garanaynaa `buf` ayaa initialized, si aan u `.assume_init()` laga yaabaa.
    /// // Si kastaba ha ahaatee, iyadoo la isticmaalayo `.assume_init()` kicinayaa `memcpy` ka mid ah 2048 bytes.
    /// // Si loo caddeeyo keydkeenna ayaa la bilaabay iyada oo aan nuqul laga dhigin, waxaan kor u qaadnay `&mut MaybeUninit<[u8; 2048]>` illaa `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // BADBAADADA: `buf` ayaa la bilaabay.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Hadda waxaan u isticmaali karnaa `buf` jeex caadi ah:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Isticmaal la'aan* qaabkan:
    ///
    /// Uma isticmaali kartid `.assume_init_mut()` inaad bilowdid qiime:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Waxaan u abuurnay (mutable) tixraac `bool` aan xog-ogaal ahayn!
    ///     // Tani waa dhaqan undefined.⚠️
    /// }
    /// ```
    ///
    /// Tusaale ahaan, ma aad kartaan [`Read`] galay kayd ah uninitialized:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) tixraac xusuusta aan la ogeyn!
    ///                             // Tani waa dhaqan undefined.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Mana waxaad isticmaali kartaa si toos ah helitaanka beerta inay sameeyaan field-by-field initialization tartiib ah:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tixraac xusuusta aan la ogeyn!
    ///                  // Tani waa dhaqan undefined.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tixraac xusuusta aan la ogeyn!
    ///                  // Tani waa dhaqan undefined.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Waxaan hadda ku tiirsan nahay waxyaabaha aan kor ku soo xusnay inay khaldan yihiin, yacni, waxaan haynaa tixraacyo xogta aan la ogeyn (tusaale ahaan, `libcore/fmt/float.rs`).
    // Waa in aan go'aan kama dambays ah oo ku saabsan xeerarka ka hor xasilinta.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in `self` la bilaabay.
        // Tani waxay sidoo kale ka dhigan tahay in `self` ay tahay inuu ahaado nooc `value` ah.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Qeybaha qiimaha ka soo diyaariyeen ah ee weelasha `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Waxay tahay in la wacay in ay damaanad in dhamaan qaybaha safi ku jiraan xaalad ah initialized.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // AMMAANKA: Hadda ammaan ah sida aynu initialised dhamaan qaybaha
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * dammaanadaha ku wacay in dhamaan qaybaha soo diyaariyeen waxaa initialized
        // * `MaybeUninit<T>` iyo T aad loogu balan qaadayo in ay khariidad la mid ah
        // * MaybeUnint ma da'a, sidaa darteed ma jiraan double-siidaysay Oo sidan waa diinta ay tahay mid amaan ah
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Haddii loo maleeyo in canaasiirta oo dhami ay yihiin kuwa la bilaabay, iyaga u jar qayb iyaga u gaar ah.
    ///
    /// # Safety
    ///
    /// Waxay waa in wacaha in la damaanad qaado in xubno `MaybeUninit<T>` runtii ku jiraan xaalad ah initialized.
    ///
    /// Wicitaanka marka content uusan weli si buuxda initialized sababaha dhaqanka undefined.
    ///
    /// Ka eeg [`assume_init_ref`] wixii faahfaahin dheeri ah iyo tusaalooyin ah.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // AMMAANKA: ridaya cad in `*const [T]` waa ammaan tan iyo damaanado Yeedhe in
        // `slice` waa initialized, and`MaybeUninit` waa la hubaa in ay khariidad la mid ah sida `T`.
        // pointer The helay shaqeynayaa tan waxaa loola jeedaa in ay xasuusta ay leedahay `slice` taas oo ah tixraac iyo sidaas ballan qaaday in ay ansax ah oo akhrinaya.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Haddii loo maleeyo in xubno ka yihiin initialized oo dhan, hesho jeex ah mutable iyaga.
    ///
    /// # Safety
    ///
    /// Waxay waa in wacaha in la damaanad qaado in xubno `MaybeUninit<T>` runtii ku jiraan xaalad ah initialized.
    ///
    /// Wicitaanka marka content uusan weli si buuxda initialized sababaha dhaqanka undefined.
    ///
    /// Ka eeg [`assume_init_mut`] wixii faahfaahin dheeri ah iyo tusaalooyin ah.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // AMMAANKA: mid ah qoraalada ammaanka `slice_get_ref`, laakiinse waxaannu yeelanaynaa a
        // tixraac is bedbeddelaya oo isna loo dammaanad qaaday inuu ansax u yahay qorista.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Helo tilmaamaha ah in element ugu horeysay ee isu safi.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Helo tilmaamaha a mutable in element ugu horeysay ee isu safi.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Nuqul ka sameysaa walxaha laga soo bilaabo `src` ilaa `this`, oo soo celinaya tixraac la beddeli karo oo ku saabsan waxyaabaha hadda la soo gudbiyay ee `this`.
    ///
    /// Haddii `T` uusan hirgelin `Copy`, isticmaal [`write_slice_cloned`]
    ///
    /// Tani waxay lamid tahay [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Shaqadani waa panic haddii labada qaybood ay leeyihiin dherer kala duwan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // AMMAANKA: aynu hadda soo guuriyeen oo dhan xubno ka Len galay awooda firaaqada
    /// // walxaha ugu horeeya ee src.len() ee vec-ka ayaa shaqeynaya hadda.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // BADBAADADA: &[T] iyo&[MalahaUninit<T>] waxay leeyihiin isku qaab
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // AMMAANKA: xubno sharci ah ayaa lagu soo guuriyeen galay `this` sidaas waxaa initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones xubno ka `src` in `this`, soo laabtay tixraac mutable ku yimid waxyaabaha hadda initalized of `this`.
    /// Waxyaabo walboo horey loo xayiray lama dejin doono.
    ///
    /// Haddii `T` fuliyo `Copy`, isticmaal [`write_slice`]
    ///
    /// Tani waxay la mid tahay [`slice::clone_from_slice`] laakiin ma da'a xubno ka jira.
    ///
    /// # Panics
    ///
    /// Shaqadani waa panic haddii labada qaybood ay leeyihiin dherer kala duwan, ama haddii hirgelinta `Clone` panics.
    ///
    /// Haddii ay jirto panic ah, waxyaalaha ay hore u gjærceler la hoos doonaa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // BADBAADADA: Waxaan hadda isku koobnay dhammaan waxyaabihii deynka lagu siiyay ee ahaa awoodda dayactirka
    /// // walxaha ugu horeeya ee src.len() ee vec-ka ayaa shaqeynaya hadda.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ka duwan copy_from_slice taasi ma wac clone_from_slice on jeex ah sababtoo ah waa `MaybeUninit<T: Clone>` aanay fulin Gadzhiyev.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // AMMAANKA: this jeex ceeriin ku jiri doona waxyaabaha kaliya initialized
                // taasi waa sababta, waa loo oggol yahay inuu hoos u dhigo.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Waxaan u baahanahay inaan si cad u jajabino iyaga oo isku dherer ah
        // waayo, soohdin hubinta in la elided, oo optimizer ka dhalin doonaa memcpy kiisaska fudud (tusaale ahaan T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // waardiyayaasha loo baahan yahay b/c panic dhici kara inta lagu guda jiro Gadzhiyev oo a
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // AMMAANKA: xubno sharci ah ayaa kaliya lagu qoray `this` sidaas waxaa initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}