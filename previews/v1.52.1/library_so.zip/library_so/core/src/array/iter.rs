//! Wuxuu qeexayaa qalabka soo-celinta `IntoIter` ee loo yaqaan 'array'.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Qiimeeye qiime leh [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Tani waa safka aan ku mashquulsan nahay.
    ///
    /// Walxaha leh tusmada `i` halkaasoo `alive.start <= i < alive.end` aan wali la soo saarin oo ay yihiin waxqabadyo soo diyaariyey oo sax ah.
    /// Walxaha leh indices indhoolayaasha `i < alive.start` ama `i >= alive.end` horay ayaa loo soo saaray waana inaan dib dambe loo marin!Kuwa xubno ka dhintay xitaa waxaa laga yaabaa in dawlad buuxda u uninitialized!
    ///
    ///
    /// Sidaas invariants waa:
    /// - `data[alive]` nool yahay (yacni waxaa ku jira waxyaabo sax ah)
    /// - `data[..alive.start]` iyo `data[alive.end..]` waa dhinteen (yacni canaasiirta horay ayaa loo akhriyay waana inaan la taaban mar dambe!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Curiyeyaasha ku jira `data` ee aan weli la soo saarin.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Waxay ku abuureysaa jaangooyooyin cusub `array` la siiyay.
    ///
    /// *Fiiro gaar ah*: qaabkani waxaa laga yaabaa inuu hoos udhaco future, wixii ka dambeeya [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Nooca `value` waa `i32` halkan, halkii laga ahaan lahaa `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // BADBAADADA: Transmute halkan runti waa aamin.Waraaqaha `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` waa la damaanad qaadayaa inay le'eg tahay isla markaana ay isla jaanqaadayso
        // > sida `T`.
        //
        // Dukumiintiyada xitaa waxay muujinayaan transmute ka soo xero `MaybeUninit<T>` ah oo loo soo xirayo `T`.
        //
        //
        // Iyadoo taas la adeegsanayo, bilaabitaankani wuxuu qancinayaa kuwa is beddelaya.

        // FIXME(LukasKalbertodt): dhab ahaantii u isticmaal `mem::transmute` halkan, mar ay la shaqeyso gen genics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Ilaa waqtigaas, waxaan u adeegsan karnaa `mem::transmute_copy` si aan u abuurno nuqul xoogaa ah nooc ka duwan, ka dib ilaawno `array` si aan hoos loogu dhigin.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Sooceliyaa jeex ah oo aan beddelmi karin dhammaan arrimaha aan weli la koreen.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // AMMAANKA: Waxaan ognahay in dhamaan qaybaha gudahood `alive` si fiican initialized.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Waxay soo celisaa gabal la beddeli karo oo ka kooban dhammaan walxaha aan wali la soo saarin.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // AMMAANKA: Waxaan ognahay in dhamaan qaybaha gudahood `alive` si fiican initialized.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Ka hel tusmada xigta xagga hore.
        //
        // Kordhinta `alive.start` by 1 haysaa invariant ku saabsan `alive`.
        // Si kastaba ha noqotee, isbeddelkan awgood, muddo gaaban, aagga nool ma aha `data[alive]` mar dambe, laakiin `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Ka akhriso curiyaha safka.
            // BADBAADADA: `idx` waa tixraac kujira gobolki hore "alive" ee
            // diyaarinAkhrinta cunsurkan waxay ka dhigan tahay in `data[idx]` loo arko inuu hadda dhintay (yacni ha taaban).
            // Maaddaama `idx` uu ahaa bilowgii aagga-nool, aagga nool ayaa hadda ah `data[alive]` markale, dib u soo celinta dhammaan kuwa aan is beddelin.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Hel index soo socda ka dib ka.
        //
        // Hoosudhaca `alive.end` ee 1 wuxuu hayaa isbedelka ku saabsan `alive`.
        // Si kastaba ha noqotee, isbeddelkan awgood, muddo gaaban, aagga nool ma aha `data[alive]` mar dambe, laakiin `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Ka akhriso curiyaha safka.
            // BADBAADADA: `idx` waa tixraac kujira gobolki hore "alive" ee
            // diyaarinAkhrinta cunsurkan waxay ka dhigan tahay in `data[idx]` loo arko inuu hadda dhintay (yacni ha taaban).
            // Maaddaama `idx` uu ahaa dhammaadka aagga-aagga, aagga nool ayaa hadda ah `data[alive]` markale, dib u soo celinta dhammaan kuwa aan is beddelin.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // BADBAADADA: Tani waa ammaan: `as_mut_slice` wuxuu si sax ah u soo celiyaa qayb-hoosaadkii
        // walxaha aan weli la dhaqaaqin oo weli harsan in la tuuro.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Marna hoos udaadan doonin sababo la xiriira isbadal la'aanta `` live.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Tilmaamuhu runtii wuxuu soo sheegayaa dhererka saxda ah.
// Tirada xubno "alive" (in weli la ruuxii doona) waa dhererka kala duwan ee `alive`.
// Baaxadani waxay hoos udhacday dherer ahaan ama `next` ama `next_back`.
// Had iyo jeer waxaa hoos u dhigaya 1 hababkaas, laakiin waa haddii `Some(_)` la soo celiyo.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Xusuusin, runti uma baahnin inaan is waafajinno isku mid ah nolosha saxda ah, sidaas darteed waxaan ku dhexbixi karnaa isku dheelitirnaanta 0 iyadoo aan loo eegin halka ay tahay `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone dhammaan walxaha nool.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Qor Gadzhiyev ah oo wuxuu galay dagaal isugu diyaariyeen cusub, ka dibna u cusbooneysiin ay kala duwan nool.
            // Haddii cloning panics, waxaan si sax ah u tuuri doonaa waxyaabaha hore.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Kaliya daabac walxaha aan wali la dhalin: mar dambe ma awoodi karno inaan helno walxaha ka dhashay.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}