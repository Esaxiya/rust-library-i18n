//! Qiimaha caajiska iyo bilaabida hal-mar ee xogta taagan.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// cell A taas oo si loo qori karaa hal mar oo keliya.
///
/// Si ka duwan `RefCell`, `OnceCell` ah kaliya waxay bixisaa tixraacyada `&T` la wadaago in miraheeda.
/// Si ka duwan `Cell`, `OnceCell` ah uma baahna koobi ama lagu beddeli karo qiimaha si ay u helaan.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: qoraal ah ugu badnaan hal mar.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Waxay abuurtaa unug cusub oo madhan.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Hesho tixraaca qiimaha salka ku haya.
    ///
    /// Soocelinayaa `None` haddii unuggu faaruq yahay.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // AMMAANKA: Safe ay sabab u tahay `invariant inner` ee
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Helo tixraaca mutable qiimaha dahsoon.
    ///
    /// Soocelinayaa `None` haddii unuggu faaruq yahay.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // AMMAANKA: Safe sababtoo ah waxaan ay helaan gaar ah
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Qeexaa waxyaabaha uu gacanta si `value`.
    ///
    /// # Errors
    ///
    /// Habkani soo laabtay `Ok(())` haddii cell waa madhnaa oo `Err(value)` haddii ay ahayd buuxa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // BADBAADADA: Ammaan maxaa yeelay ma haysan karno amaahyo is-beddeli kara oo is-dul saaran
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // AMMAANKA: Tani waa meesha kaliya ee ay waxaannu Afyare, ma jinsiyadaha
        // reentrancy/concurrency awgood waa suurtagal, waana hubinay in booska uu hadda yahay `None`, sidaas darteed qoraalkan wuxuu hayaa isbedelka `` gudaha ''.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Wuxuu helaa waxa ku jira unugga, isagoo ku bilaabaya `f` haddii unuggu madhan yahay.
    ///
    /// # Panics
    ///
    /// Haddii `f` panics, panic la faafin in wacaha, iyo gacanta weli uninitialized.
    ///
    ///
    /// Waa qalad in dib loo cusbooneysiiyo unugga laga bilaabo `f`.Sameynta sidaas waxay keeneysaa a panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Wuxuu helaa waxa ku jira unugga, isagoo ku bilaabaya `f` haddii unuggu madhan yahay.
    /// Haddii qolku madhnaa oo `f` xumaaday, qalad ayaa la soo celiyey.
    ///
    /// # Panics
    ///
    /// Haddii `f` panics, panic la faafin in wacaha, iyo gacanta weli uninitialized.
    ///
    ///
    /// Waa qalad in dib loo cusbooneysiiyo unugga laga bilaabo `f`.Sameynta sidaas waxay keeneysaa a panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Ogsoonow in *noocyada* qaababka dib-u-soo-celinta ay horseedi karto UB (eeg imtixaanka `reentrant_init`).
        // Waxaan aaminsanahay in kaliya ka saarida `assert`-da, iyadoo la ilaalinayo `set/get` ay noqoneyso mid dhawaq ah, laakiin waxay u muuqataa inay ka fiican tahay panic, halkii si aamusnaan ah loo isticmaali lahaa qiimo duug ah.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Gubtay, gacanta, soo laabtay qiimaha ku duudduubay.
    ///
    /// Soocelinayaa `None` haddii qolku madhan yahay.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Maxaa yeelay, `into_inner` qaadataa `self` by qiimaha, compiler ah soo jiidasho leh cadeyso in aan hadda u amaahannay.
        // Marka waa amaan in laga guuro `Option<T>`.
        self.inner.into_inner()
    }

    /// Qaadataa qiimaha baxay `OnceCell` this, waxaa u dhaqaaqo dawlad uninitialized dib.
    ///
    /// Saameyn ah kuma laha oo soo laabtay `None` haddii `OnceCell` aan la initialized.
    ///
    /// Ammaanka waa la hubaa in ay u baahan tixraac mutable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Qiime lagu bilaabayo marinka koowaad.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   diyaarinta bilowga ah
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Waxay abuurtaa a qiimaha cusub caajis la function ku siiyey bilaabida.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Waxay ku qasbeysaa qiimeynta qiimaha caajiska ah waxayna ku celineysaa tixraac natiijada.
    ///
    ///
    /// Tani waxay u dhigantaa impl `Deref` ah, laakiin waa cad.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Abuuraa qiimaha caajis cusub isticmaalaya `Default` sida shaqo bilaabida.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}