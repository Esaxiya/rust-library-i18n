//! Qaybtani waxay hirgelinaysaa `Any` trait, taas oo awood u siinaysa qorista firfircoon ee nooc kasta oo `'static` ah iyada oo loo marayo milicsiga waqtiga.
//!
//! `Any` lafteeda ayaa loo isticmaali karaa si loo helo `TypeId`, waxayna leedahay astaamo badan markii loo isticmaalo sheyga trait.
//! Sida `&dyn Any` (a amaahatay wax trait), waxa ay leedahay hababka `is` iyo `downcast_ref`, si ay u tijaabiso hadii qiimaha ku qoran waa nooc ka mid ah la siiyay, iyo si aad u hesho tixraac in qiimaha hoose sida nooc ka mid ah.
//! `&mut dyn Any` ahaan, waxaa sidoo kale jira habka `downcast_mut`, ee helitaanka tixraac isbeddel ah oo ku saabsan qiimaha gudaha.
//! `Box<dyn Any>` darayaa habka `downcast` ah, oo isku day in uu diinta Islaamka si `Box<T>` ah.
//! Ka eeg dukumintiyada [`Box`] wixii faahfaahin ah ee buuxa.
//!
//! Xusuusnow in `&dyn Any` ay ku egtahay baaritaanka in qiimuhu uu yahay nooc la taaban karo oo cayiman, loomana adeegsan karo in lagu tijaabiyo in nooc uu fulinayo trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Tilmaamayaasha casriga ah iyo `dyn Any`
//!
//! Hal dabeecad oo maskaxda lagu hayo marka la isticmaalayo `Any` sida sheyga trait, gaar ahaan noocyada sida `Box<dyn Any>` ama `Arc<dyn Any>`, ayaa ah in si fudud loogu yeero `.type_id()` qiimaha ay soo saareyso `TypeId` ee *weelka*, ma ahan sheyga trait.
//!
//! Tani waxaa looga fogaan karaa by diinta tilmaamaha smart galay `&dyn Any` halkii, taas oo soo noqon doonaa shay ee `TypeId`.
//! Tusaale ahaan:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Waxaad u badan tahay inaad tan rabto:
//! let actual_id = (&*boxed).type_id();
//! // ... tan tan:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Tixgeli xaalad aan rabno inaan ka baxno qiime lagu wareejiyay hawl.
//! Waan ognahay qiimaha aan ku shaqeyneyno fulinta Debug, laakiin ma ogin nooca la taaban karo.Waxaan rabnaa in aan ku siin daaweyn gaar ah noocyada qaarkood, haddii ay taasi ku daabacaadda baxay dhererka String la qiimeeyo ka hor inta ay qiimaha.
//! Annagu garan mayno nooca la taaban karo ee our qiimaha waqtiga isku ururiso, sidaas darteed waxaan u baahan tahay in ay isticmaalaan milicsiga Runtime halkii.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger shaqo nooc kasta oo qalab Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Isku day inaad u badasho qiimaheena `String`.
//!     // Haddii lagu guuleysto, waxaan dooneynaa inaan soo saarno dhererka String`ka iyo sidoo kale qiimahiisa.
//!     // Haddii kale, waa nooc ka duwan: kaliya daabac adigoon qurxin.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Hawshani waxay rabtaa inay ka baxdo halbeeggeeda ka hor intaanay la shaqeynin.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... qabso shaqo kale
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// trait kasta
///////////////////////////////////////////////////////////////////////////////

/// trait si loogu daydo makiinad firfircoon.
///
/// Noocyada badankood waxay hirgeliyaan `Any`.Si kastaba ha noqotee, nooc kasta oo ka kooban tixraac aan-ahayn 'static` ma sameeyo.
/// Ka eeg [module-level documentation][mod] wixii faahfaahin dheeraad ah.
///
/// [mod]: crate::any
// trait kani ma ahan mid aan amaan aheyn, in kastoo aan ku tiirsanahay waxyaabaha gaarka u ah shaqadiisa 'impl' ee `type_id` function' koodh aan aamin ahayn (tusaale, `downcast`).Caadi ahaan, taasi dhibaato ayay noqon laheyd, laakiin maxaa yeelay waxa keliya ee keena `Any` waa hirgelinta buste, ma jiro lambar kale oo hirgelin kara `Any`.
//
// Waxaan si macquul ah uga dhigi karnaa trait amni darro ah-ma keeni doonto jajab, maaddaama aan xakameyno dhammaan hirgelinta-laakiin waxaan dooranay inaanan u noqonin maadaama aysan labadaba runtii ahayn wax loo baahan yahay oo laga yaabo inay ku jahwareeraan isticmaalayaasha ku saabsan kala soocida traits iyo hababka aan amniga ahayn (ie, `type_id` weli noqon lahaa ammaan ah u yeedho, laakiin ay u badan tahay waxaan dooneynaa lahaa si ay u muujiyaan sida in waraaqo).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Helo `TypeId` of `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Hababka fidinta walxaha trait ah.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Hubi in natiijada tusaale ahaan, ku biiro dun laga daabacan karaa oo halkan loo isticmaalo `unwrap`.
// Mar dambe lagama yaabo in loo baahdo haddii diristu ay la shaqeyso kor u qaadista.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Sooceliyaa `true` haddii nooca xerad waa isku mid sida `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Hel `TypeId` nooca shaqadan loogu talagalay.
        let t = TypeId::of::<T>();

        // Hel `TypeId` nooca ku jira shayga trait ee (`self`).
        let concrete = self.type_id();

        // Isbarbar dhig labada nooc ee 'TypeId`s ah.
        t == concrete
    }

    /// Waxay ku celineysaa tixraac ku saabsan qiimaha sanduuqa haddii uu yahay nooca `T`, ama `None` haddii uusan ahayn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // AMMAANKA: kaliya hubiyaa in aan la fiiqaya in nooca saxda ah, oo aan ku kalsoonaan kartaa
            // kaas oo hubinaya badbaadada xusuusta maxaa yeelay waxaan hirgelinay Nooc kasta oo noocyadu u socdaan;ma impls kale jiri karaan sida ay ka hor imanayn doono our impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Waxay ku celineysaa tixraac la beddeli karo qiimaha sanduuqa haddii uu yahay nooca `T`, ama `None` haddii uusan ahayn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // AMMAANKA: kaliya hubiyaa in aan la fiiqaya in nooca saxda ah, oo aan ku kalsoonaan kartaa
            // kaas oo hubinaya badbaadada xusuusta maxaa yeelay waxaan hirgelinay Nooc kasta oo noocyadu u socdaan;ma impls kale jiri karaan sida ay ka hor imanayn doono our impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// U gudbinta habka lagu qeexay nooca `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// U gudbinta habka lagu qeexay nooca `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// U gudbinta habka lagu qeexay nooca `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// U gudbinta habka lagu qeexay nooca `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// U gudbinta habka lagu qeexay nooca `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// U gudbinta habka lagu qeexay nooca `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID iyo hababka ay
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` wuxuu u taagan yahay aqoonsi caalami ah oo u gaar ah nooc.
///
/// `TypeId` kasta waa shay mugdi ku jiro oo aan oggolaanayn in la baaro waxa gudaha ku jira laakiin u oggolaanaya hawlgallada aasaasiga ah sida cloning, isbarbardhiga, daabacaadda, iyo muujinta.
///
///
/// A `TypeId` hadda waa kaliya diyaar u ah noocyada kuwaas oo ka sheegtaan `'static`, laakiin xaddidaadda this laga yaabaa in la saaro in future ah.
///
/// Halka `TypeId` fuliyo `Hash`, `PartialOrd`, iyo `Ord`, waxaa xusid mudan in haashka iyo amarka ay ku kala duwanaan doonaan Rust sii deynta.
/// Ka taxaddar inaad ku tiirsanaato iyaga gudaha lambarkaaga!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Sooceliyaa `TypeId` nooca nooca shaqadan guud lagu shaqeeyay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Waxay ku celisaa magaca nooc jeex jeexan.
///
/// # Note
///
/// Tan waxaa loogu talagalay isticmaalka cudurka.
/// Waxyaabaha saxda ah iyo qaabka xariga loo soo celiyey lama cayimin, marka laga reebo inuu yahay sharaxaadda ugu fiican ee nooca.
/// Tusaale ahaan, xargaha ay `type_name::<Option<String>>()` soo celin karto waa `"Option<String>"` iyo `"std::option::Option<std::string::String>"`.
///
///
/// string soo noqdeen waa in aan loo arkaa in ay aqoonsi u gaar ah oo ah nooc ka mid ah noocyada kala duwan waxaa laga yaabaa in khariidada in magac la mid ah nooca.
/// Sidoo kale, ma jiraan wax damaanad ah in dhammaan qaybo ka mid ah nooc ka mid ah ka muuqan doontaa in string soo noqdeen, waayo, tusaale ahaan, specifiers noolaa ayaa hadda ka mid ahayn.
/// Intaa waxaa dheer, wax soo saarka ayaa laga yaabaa in la beddelo dhexeeya versions of compiler ah.
///
/// Hirgelinta hadda waxay isticmaashaa kaabayaal isku mid ah sida cilad-ururinta iyo debuginfo, laakiin tan maahan mid dammaanad qaad ah.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Waxay soocelisaa magaca nooca tilmaanta-u-qiimaha sida jeex xarig ah.
/// Tani waxay lamid tahay `type_name::<T>()`, laakiin waa loo isticmaali karaa halka nooca doorsoomaha uusan si fudud ku heli karin.
///
/// # Note
///
/// Tani waxaa loogu tala galay in loo isticmaalo ogaanshaha.Waxyaabaha saxda ah iyo qaabka xadhigga ayaan la cayimin, oo aan ka ahayn ahaanshaha tilmaanta ugu fiican ee nooca.
/// Tusaale ahaan, `type_name_of_val::<Option<String>>(None)` yaabaa inay soo laabtaan `"Option<String>"` ama `"std::option::Option<std::string::String>"`, laakiin ma `"foobar"`.
///
/// Intaa waxaa dheer, wax soo saarka ayaa laga yaabaa in la beddelo dhexeeya versions of compiler ah.
///
/// Shaqadani ma xalinayso walxaha trait, taas oo macnaheedu yahay in `type_name_of_val(&7u32 as &dyn Debug)` ay soo laaban karto `"dyn Debug"`, laakiin aan ahayn `"u32"`.
///
/// Magaca nooca waa inaan loo tixgelin aqoonsi gaar ah oo nooc ah;
/// noocyo badan ayaa laga yaabaa inay wadaagaan magac isku mid ah.
///
/// Hirgelinta hadda waxay isticmaashaa kaabayaal isku mid ah sida cilad-ururinta iyo debuginfo, laakiin tan maahan mid dammaanad qaad ah.
///
/// # Examples
///
/// Daabacdaa tiradii caadiga ahayd iyo sababihii.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}