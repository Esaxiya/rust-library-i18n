//! Libcore prelude
//!
//! Qaybtani waxaa loogu talagalay dadka isticmaala libcore ee aan ku xirnayn libstd sidoo kale.
//! Qaybtani waxaa loo soo dhoofiyaa si caadi ah markii `#![no_std]` loo isticmaalo si la mid ah maktabadda caadiga ah 'prelude'.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Nooca 2015 ee xudunta prelude.
///
/// Ka eeg [module-level documentation](self) wixii intaa ka badan.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Nooca 2018 ee xudunta prelude.
///
/// Ka eeg [module-level documentation](self) wixii intaa ka badan.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Nooca 2021 ee xudunta prelude.
///
/// Ka eeg [module-level documentation](self) wixii intaa ka badan.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Kudar waxyaabo dheeri ah.
}