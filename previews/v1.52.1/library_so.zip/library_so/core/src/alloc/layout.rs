use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// In kasta oo hawshan hal meel lagu wada adeegsanayo oo fulinteeda lagu tilmaami karo, haddana isku daygii hore ee sidaa lagu doonayey ayaa rustc ka gaabiyay:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout of block ah oo xasuusta.
///
/// Tusaale `Layout` wuxuu sharxayaa qaabeynta xusuusta gaar ah.
/// Waxaad la dhiso `Layout` ah sida talooyin ah in la siiyo allocator ah.
///
/// Dhammaan qaababku waxay leeyihiin cabir la xidhiidha iyo isku dheellitir awood-labo ah.
///
/// (Xusuusnow in qaababku *aan* looga baahnayn inay yeeshaan cabbir aan eber ahayn, in kastoo `GlobalAlloc` u baahan tahay in dhammaan codsiyada xusuusta ay cabbir ahaan eber aheyn.
/// Yeedhe A waa mid loo hubiyo in xaaladaha sidan oo kale waxaa la kulmay, allocators isticmaalka gaarka ah shuruudaha debecsan, ama isticmaalaan interface `Allocator` more dabacsan.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // baaxadda xusuusta la codsaday, oo lagu cabiray bytes.
    size_: usize,

    // iswaafajinta qalabka la codsaday ee xasuusta, oo lagu cabiray baaytyo.
    // aan loo hubiyo in this had iyo jeer waa ka awood-labo ka mid ah, sababtoo ah ee API sida `posix_memalign` waxay u baahan yihiin oo ay tahay caqabadda ugu macquul ah si ay ku soo rogi on constructors Layout.
    //
    //
    // (Si kastaba ha ahaatee, ma waxaan ku analogously baahan `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Dhista `Layout` ka `size` la siiyo iyo `align`, ama celinta `LayoutError` haddii mid ka mid ah shuruudaha soo socda aan la kulmay,
    ///
    /// * `align` waa inuusan eber noqon,
    ///
    /// * `align` waa inuu ahaadaa awood labo,
    ///
    /// * `size`, markii kor loo soo koobay si badan ugu dhow ee `align`, waa in aan dhulka qarqinaya (ie, qiimaha fekrado waa inuu ka yaraadaa ama la mid ah `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (Awoodda-labo ayaa tilmaamaya!=0.)

        // size ilaa fekrado waa:
        //   size_rounded_up=(+ align size, 1)&(align, 1)!
        //
        // Waxaan ka ognahay xagga sare isku toosintaas!=0.
        // Haddii ku darista (isku toosinta, 1) uusan buux dhaafin, markaa isku soo wada duubku wuu fiicnaan doonaa.
        //
        // Taa bedelkeeda,&-maamuusid (isku toosin, 1) ayaa ka goyn doonta kaliya xoogaa yar oo amar ah.
        // Sidaas darteed haddii buuxdhaafku ku yimaado wadarta,&&-maskku ma goyn karo wax ku filan si uu uga laabto qulqulkaas.
        //
        //
        // Kor ku tusinaysaa in la hubiyo faafi summation waa labada lagama maarmaan ah oo ku filan.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // BADBAADADA: shuruudaha `from_size_align_unchecked` ayaa ahaa
        // kor lagu hubiyey.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Waxay abuurtaa qaab-dhismeed, iyadoo laga gudbayo dhammaan jeegagga.
    ///
    /// # Safety
    ///
    /// Shaqadani waa mid aan amaan ahayn maadaama aysan xaqiijinayn shuruudaha laga rabo [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // AMMAANKA: wacaha waa inay hubiyaan in `align` waa ka weyn yahay eber.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Cabbirka ugu yar ee baaytka loogu talagalay xusuusta xannibaadda qaabkan.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Jaangooyada ugu yar ee baytka ee aaladda xusuusta ee qaabeynta.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Dhista `Layout` ku haboon haysta qiimaha nooca `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // BADBAADADA: isku toosinta waxaa damaanad qaaday Rust inay ahaato awood labo iyo
        // baaxadda + isku dhejiska shanlaha ayaa la damaanad qaadayaa inay ku habboon tahay cinwaanka cinwaankayaga.
        // Sidaas darteed isticmaali constructor ka qaban halkan si looga fogaado galinta code in panics haddii aan filaayo in si fiican oo ku filan.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Soo saarta khariidad ku tilmaamay rikoor yaabo in loo isticmaalo si loo qaybiyo qaab-dhismeedka taageero for `T` (oo ay noqon kartaa trait ama nooc kale unsized sida cad a).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // AMMAANKA: Fikirka arki in `new` waayo, bal maxaad this waxaa la isticmaalayo kala duwanaansho ku ammaan ahayn
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Soo saarta khariidad ku tilmaamay rikoor yaabo in loo isticmaalo si loo qaybiyo qaab-dhismeedka taageero for `T` (oo ay noqon kartaa trait ama nooc kale unsized sida cad a).
    ///
    /// # Safety
    ///
    /// Shaqadani waxay badbaado u tahay oo keliya in la waco haddii xaaladaha soo socdaa qabtaan:
    ///
    /// - Haddii `T` uu yahay `Sized`, shaqadani had iyo jeer waa aamin in la waco.
    /// - Haddii dabada aan la qiyaasin ee `T` ay tahay:
    ///     - a [slice], ka dibna dhererka jeex jeexa waa inuu ahaadaa mid isku dhex jira, iyo cabirka *qiimaha oo dhan*(dhererka dabada firfircoon + horgale ahaan qiyaas ahaan le'eg) waa inuu ku habboon yahay `isize`.
    ///     - [trait object] ah, ka dibna qaybta tilmaanta tilmaantu waa inay tilmaamto faseexad sax ah nooca `T` ee ay heshay qasab aan kala go 'lahayn, iyo cabirka *qiimaha oo dhan*(dhererka dabada firfircoon + horgale ahaan qiyaas ahaan le'eg) waa inuu ku habboon yahay `isize`.
    ///
    ///     - (unstable) [extern type] ah, markaa shaqadani had iyo jeer waa aamin in la waco, laakiin panic ama si kale ha u soo celiso qiime qaldan, maadaama qaabka bannaanka loo yaqaan aan la aqoon.
    ///     Tani waa dabeecad la mid ah tan [`Layout::for_value`] marka la tixraaco dabada nooca dusha.
    ///     - haddii kale, si muxaafid ah looma oggola in loo yeedho shaqadan.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // AMMAANKA: waxaan mari weheliyaan shuruudaha ka mid ah hawlaha si wacaha
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // AMMAANKA: Fikirka arki in `new` waayo, bal maxaad this waxaa la isticmaalayo kala duwanaansho ku ammaan ahayn
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Waxay abuurtaa `NonNull` oo ruxruxaya, laakiin si fiican isugu habboon Layout-kan.
    ///
    /// Fiiro gaar ah in qiimaha tilmaamaha laga yaabo meteli kara tilmaamaha sax ah, taas oo macnaheedu yahay waajib this aan loo isticmaali karin "not yet initialized" a jooga Raqiib iyo qiimaha.
    /// Noocyada caajisnimada loo qoondeeyo waa inay la socdaan bilowga qaab kale.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // AMMAANKA: align waa la hubaa in ay noqon aan eber
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Waxay abuurtaa qaab lagu sharraxayo diiwaanka hanan kara qiime isla qaab ah sida `self`, laakiin taasi sidoo kale waxay la jaanqaadaysaa isku dheelitirnaanta `align` (oo lagu cabiray bytes).
    ///
    ///
    /// Haddii `self` horay u kulmay in lays ku qoray, ka dibna ku soo laabtay `self`.
    ///
    /// Ogsoonow in qaabkani aanu ku darin wax suuf ah cabirka guud, iyadoo aan loo eegin haddii qaabka loo soo celiyey uu leeyahay iswaafajin ka duwan.
    /// Si kale haddii loo dhigo, haddii `K` uu leeyahay cabbirka 16, `K.align_to(32)` wuxuu *weli* yeelan doonaa cabbirka 16.
    ///
    /// Sooceliyaa qalad haddii isku darka ee `self.size()` iyo `align` la siiyey xadgudub ku shuruudaha ku qoran [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Waxay soo celineysaa xaddiga suufka ee ay tahay inaan gelino `self` kadib si loo hubiyo in cinwaanka soo socda uu qancin doono `align` (oo lagu cabiray bytes).
    ///
    /// tusaale ahaan, haddii `self.size()` waa 9, ka dibna `self.padding_needed_for(4)` Laabtay 3, sababtoo ah in uu yahay tirada ugu yar ee bytes ee kursiga loo baahan yahay si aad u hesho cinwaan 4-safan (haddii loo maleeyo in u dhiganta bilowday block xusuusta cinwaanka ah 4-waafaqsan).
    ///
    ///
    /// Qiimaha soo noqoshada shaqadan micno malahan hadii `align` uusan aheyn awood-labo.
    ///
    /// Xusuusnow in adeegga qiimaha la soo celiyey u baahan yahay `align` inuu ka yaraado ama u dhigmo iswaafajinta cinwaanka bilowga ee dhammaan xusuusta loo qoondeeyey.Mid ka mid ah si ay ka dhergin caqabadda this waa in la hubiyo `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Qiimaha isku dhafan waa:
        //   len_rounded_up=(len + toosin, 1)&! (isku toos, 1);
        // ka dibna waxaan soo celinnaa farqiga suufka: `len_rounded_up - len`.
        //
        // Waxaan u isticmaalnaa xisaab xisaabeed dhammaan:
        //
        // 1. isku toosin ayaa loo dammaanad qaadayaa inuu yahay> 0, markaa isku toos, 1 marwalba waa ansax
        //
        // 2.
        // `len + align - 1` qulqulaya ugu badnaan `align - 1`, sidaa darteed&-maaska leh `!(align - 1)` wuxuu hubin doonaa in kiisaska buuxdhaafka, `len_rounded_up` laftiisu noqon doonto 0.
        //
        //    Sayidka kursiga ku soo laabtay, markii lagu daray `len`, edbiyey 0, taas oo trivially dhergiyey in lays `align`.
        //
        // (Dabcan, isku dayga ah in loo qoondeeyo baloogyo xusuusta ka mid ah oo cabirkooda iyo suufkoodu buuxsamo sida kor ku xusan ay tahay inay u keenaan qaybiyaha inuu khalad keeno si kastaba ha ahaatee)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Waxay abuurtaa qaab-dhismeed iyada oo lagu soo koobayo cabbirka qaab-dhismeedka illaa in badan oo ka mid ah iswaafajinta qaabeynta.
    ///
    ///
    /// Tani waxay u dhigantaa ku darista natiijada `padding_needed_for` cabbirka hadda qaabeynta.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Tani ma buuxin karto.Ka soo xiganaya isbeddelka Layout:
        // > `size`, markii la isugu geeyo tirada ugu dhow ee `align`,
        // > waa in aanu buux dhaafin (yacni, qiimaha wareegsan waa inuu kayaryahay
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Abuuraa qaabka a ku tilmaamay rikoorka mararka `n` of `self`, xaddiga ku habboon ee kursiga dhexeeya kasta si loo hubiyo in wax kasta la siiyo ay size codsaday iyo in lays.
    /// Guul ahaan, wuxuu soo celiyaa `(k, offs)` halka `k` uu yahay qaabeynta qaabka iyo `offs` waa masaafada udhaxeysa bilowga walx walba ee safka.
    ///
    /// Xisaab xirka xisaabta, wuxuu soo celinayaa `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Tani ma buuxin karto.Ka soo xiganaya isbeddelka Layout:
        // > `size`, markii la isugu geeyo tirada ugu dhow ee `align`,
        // > waa in aanu buux dhaafin (yacni, qiimaha wareegsan waa inuu kayaryahay
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // BADBAADADA: self.align horeyba waa loo ogaa inuu ansax yahay oo qoondaynta_size ayaa jirtay
        // mar hore suuf ah
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Waxay abuurtaa qaab lagu sharraxayo diiwaanka `self` oo ay ku xigto `next`, oo ay ku jiraan wixii suuf ah ee loo baahan yahay si loo hubiyo in `next` si habboon loo waafajin doono, laakiin *aan lahayn dabagalin dabagal*.
    ///
    /// In si ay u dhigma matalaad C qaabka `repr(C)`, waa inaad wacdaa `pad_to_align` ka dib markii kordhin khariidad la beeraha oo dhan.
    /// (Ma jiro hab u dhigma default Rust matalaad ah qaabka `repr(Rust)`, as it is unspecified.)
    ///
    /// Ogsoonow in lays ee khariidad keentay noqon doonaa ugu badnaan kuwii `self` iyo `next`, si loo hubiyo in lays ee labada qaybood.
    ///
    /// Dib `Ok((k, offset))`, halkaas oo `k` waa qaabka of rikoorka concatenated iyo `offset` waa meesha uu qof qaraabo, in bytes, billowga `next` ah gundhig gudahood diiwaanka concatenated (haddii loo maleeyo in record laftiisa bilaabantaa mowjadda 0).
    ///
    ///
    /// Xisaab xirka xisaabta, wuxuu soo celinayaa `LayoutError`.
    ///
    /// # Examples
    ///
    /// Si loo xisaabiyo qaabeynta qaab-dhismeedka `#[repr(C)]` iyo is-beddelka beeraha ee qaabka '
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Xusuusnow inaad ku dhammaystirto `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // tijaabi inay shaqeyso
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Waxay abuurtaa qaab sharraxaad ka bixinaya diiwaanka dhacdooyinka `n` ee `self`, oo aan lahayn suuf u dhexeeya tusaale kasta.
    ///
    /// Note in, si ka duwan `repeat`, `repeat_packed` ma aha ballanqaad in ay dhacdooyin soo noqnoqda ee `self` in si fiican la safan doonaa, xataa haddii tusaale ahaan la siiyo ee `self` si fiican waafaqsan.
    /// Si kale haddii loo dhigo, haddii qaabka ay soo celisay `repeat_packed` loo isticmaalo in loo qoondeeyo array, looma ballan qaadayo in dhammaan walxaha ku jira safka ay si habboon isu waafajin doonaan.
    ///
    /// Xisaab xirka xisaabta, wuxuu soo celinayaa `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Waxay abuurtaa qaab qeexaya diiwaanka `self` oo ay ku xigto `next` iyada oo aan lahayn suuf dheeri ah oo u dhexeeya labada.
    /// Tan iyo markii kursiga ma la geliyo, in lays ee `next` waa ku tacaluqda, iyo waxa aan la dari *ee* walba u soo gelin qaabka keentay.
    ///
    ///
    /// Xisaab xirka xisaabta, wuxuu soo celinayaa `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Waxay abuurtaa qaab lagu sharraxayo diiwaanka `[T; n]`.
    ///
    /// Xisaab xirka xisaabta, wuxuu soo celinayaa `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Beegyada uu siiyey in `Layout::from_size_align` ama qaar ka mid ah constructor kale `Layout` ma dhergaan caqabadaha ay diiwaan.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (waxaan tan ugu baahanahay soo qaadista hoose ee qaladka trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}