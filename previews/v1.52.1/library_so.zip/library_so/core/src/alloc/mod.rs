//! Qoondaynta xusuusta APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Baadi `AllocError` waxay muujinaysaa qoondaynta failure in sabab u noqon kara daal khayraadka ama si khalad ah wax marka isku doodaha talooyin siiyey la allocator this.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (waxaan tan ugu baahanahay soo qaadista hoose ee qaladka trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Hirgelinta `Allocator` ayaa u qoondeyn karta, kori karta, yareyn karta, isla markaana kala wareejin kartaa baloogyada macquulka ah ee xogta lagu sharraxay [`Layout`][].
///
/// `Allocator` waxaa loogu talagalay in lagu hirgaliyo ZST-yada, tixraacyada, ama tilmaamayaasha caqliga badan maxaa yeelay yeelasho qoondeeye sida `MyAlloc([u8; N])` lama dhaqaajin karo, iyada oo aan lagu cusbooneysiinin tilmaamayaasha xusuusta loo qoondeeyay.
///
/// Si ka duwan [`GlobalAlloc`][], qoondaynta qiyaasta eber ayaa loo oggol yahay `Allocator`.
/// Haddii qaybiyaha hoose uusan taageerin tan (sida jemalloc) ama uusan soo celin tilmaame aan waxba ka jirin (sida `libc::malloc`), tani waa inay qabataa fulinta.
///
/// ### Xusuusta waqtigan loo qoondeeyay
///
/// Qaababka qaarkood waxay u baahan yihiin in xasuusta la xiro *oo hadda loo qoondeeyo* iyadoo loo marayo qaybiyaha.Tan macnaheedu waa:
///
/// * cinwaanka bilowga ee xusuusta xannibaadda waxaa horey u soo celiyey [`allocate`], [`grow`], ama [`shrink`], iyo
///
/// * Xusuusta xusuusta lama sii kala bixin, halkaas oo baloogyada si toos ah loogu kala wareejiyo iyadoo loo sii gudbiyo [`deallocate`] ama loo beddelay in loo gudbiyo [`grow`] ama [`shrink`] oo soo celiya `Ok`.
///
/// Haddii `grow` ama `shrink` ayaa ku soo laabtay `Err`, tilmaamaha maray weli aan dhicin.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Xusuusta ku habboon
///
/// Qaababka qaarkood waxay u baahan yihiin qaabeynta *ku habboon tahay* xannibaadda xusuusta.
/// Maxaa looga jeedaa qaabeynta illaa "fit" xusuusta xannibaadda macnaheedu waa (ama u dhigma, xusuusta xannibaadda illaa "fit" qaabeynta) waa in xaaladaha soo socdaa ay tahay inay qabtaan:
///
/// * Baloogga waa in loo qoondeeyo isku mid ah sida [`layout.align()`], iyo
///
/// * [`layout.size()`] la bixiyay waa inuu ku dhacaa aagga `min ..= max`, halkaasoo:
///   - `min` waa cabirka qaabeynta ugu dambayntii loo adeegsaday qoondaynta baloogga, iyo
///   - `max` waa size ugu dambeeyay ee dhabta ah ka [`allocate`], [`grow`], ama [`shrink`] soo laabtay.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Qalabka xusuusta ee laga soo celiyey qoondeeye waa inuu tilmaamaa xasuusta saxda ah isla markaana ilaaliyaa ansaxnimadooda illaa tusaalaha iyo dhammaan jaangooyooyinkiisu hoos u dhacaan,
///
/// * cloning ama dhaqaajiye qeybiyaha waa in uusan burineynin astaamaha xasuusta ee laga soo celiyey qeybiyaha.allocator A gjærceler dhaqmaa sida allocator isla, iyo
///
/// * tilmaame kasta oo ku saabsan xusuusta xannibaadda oo ah [*currently allocated*] waxaa loo gudbin karaa qaab kasta oo kale oo loo qoondeeyo.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Isku dayga ah in loo qoondeeyo baloog xusuusta.
    ///
    /// On guusha, soo laabtay [`NonNull<[u8]>`][NonNull] a kulan size iyo in lays damaanado ee `layout`.
    ///
    /// Xannibaadda la soo celiyey waxay yeelan kartaa cabir ka weyn inta uu cayimay `layout.size()`, waana laga yaabaa ama laga yaabaa in aan la bilaabin waxyaabaha ay ka kooban tahay.
    ///
    /// # Errors
    ///
    /// Soo noqoshada `Err` waxay muujineysaa in xusuusta midkoodna ay daashay ama `layout` uusan la kulmin cabbirka qoondeynta ama isku dheellitirnaanta.
    ///
    /// Hirgelinta waxaa lagu dhiirrigelinayaa inay ku soo laabato `Err` daalidda xusuusta halkii ay ka nixin lahayd ama ka soo ridi lahayd, laakiin tani maahan shuruud adag.
    /// (Gaar ahaan: waa *sharci* in lagu hirgeliyo trait dusha sare maktabadda qoondaynta qoyseed ee asaasiga ah ee ku adkaata xusuusta daal.)
    ///
    /// Macaamiisha doonaya inay tirtiraan xisaabinta iyagoo ka jawaabaya qaladka qoondaynta waxaa lagu dhiirigelinayaa inay wacaan shaqada [`handle_alloc_error`], halkii ay si toos ah uga yeeri lahaayeen `panic!` ama wax la mid ah.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Dhaqmo sida `allocate`, laakiin sidoo kale hubiyaan in xasuusta noqdeen waa eber-initialized.
    ///
    /// # Errors
    ///
    /// Soo noqoshada `Err` waxay muujineysaa in xusuusta midkoodna ay daashay ama `layout` uusan la kulmin cabbirka qoondeynta ama isku dheellitirnaanta.
    ///
    /// Hirgelinta waxaa lagu dhiirrigelinayaa inay ku soo laabato `Err` daalidda xusuusta halkii ay ka nixin lahayd ama ka soo ridi lahayd, laakiin tani maahan shuruud adag.
    /// (Gaar ahaan: waa *sharci* in lagu hirgeliyo trait dusha sare maktabadda qoondaynta qoyseed ee asaasiga ah ee ku adkaata xusuusta daal.)
    ///
    /// Macaamiisha doonaya inay tirtiraan xisaabinta iyagoo ka jawaabaya qaladka qoondaynta waxaa lagu dhiirigelinayaa inay wacaan shaqada [`handle_alloc_error`], halkii ay si toos ah uga yeeri lahaayeen `panic!` ama wax la mid ah.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // BADBAADADA: `alloc` wuxuu soo celiyaa xayeysiis xusuus sax ah
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates xasuusta tilmaansado by `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` waa inuu sheegaa block xasuusta [*currently allocated*] iyada oo loo marayo qaybiyaha, iyo
    /// * `layout` waa [*fit*] in block of xasuusta.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Isku dayga kordhinta xusuusta.
    ///
    /// Sooceliyaa [`NonNull<[u8]>`][NonNull] cusub oo ay kujiraan tilmaame iyo cabirka dhabta ah ee xusuusta loo qoondeeyay.Tilmaameyuhu wuxuu ku habboon yahay inuu hayo xog uu sharraxay `new_layout`.
    /// Si tan loo dhammeeyo, qoondeeyaha ayaa kordhin kara qoondeynta ay tilmaamtay `ptr` si uu ugu habboonaado qaabka cusub.
    ///
    /// Hadday tan soo noqoto `Ok`, markaa lahaanshaha aaladda xusuusta ee tixraacaysa `ptr` waxaa loo wareejiyay qayb-bixiyeha.
    /// xusuustiisu laga yaabaa ama laga yaabaa in aanay la sii daayay, iyo waa in la tixgeliyaa istimaalaynin haddii waxa la dib ugu soo wacaha wareejiyo mar kale via qiimaha celinta habkan ah.
    ///
    /// Haddii habkan soo laabtay `Err`, lahaanshaha markaas of block xusuusta aan la wareejiyo allocator this, iyo waxyaabaha uu block xasuusta waa oon doorsoomaynin.
    ///
    /// # Safety
    ///
    /// * `ptr` waa inuu sheegaa block xasuusta [*currently allocated*] iyada oo loo marayo qaybiyaha.
    /// * `old_layout` waa [*fit*] in block of xasuusta (u baahan dood The `new_layout` ma ku haboon.).
    /// * `new_layout.size()` waa inuu ka weynaadaa ama u dhigmaa `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Sooceliyaa `Err` haddii khariidad cusub ma la kulmaan caqabado size iyo in lays allocator ee allocator ah, ama haddii si kale loo sii kordhaya guuldareysto.
    ///
    /// Hirgelinta waxaa lagu dhiirrigelinayaa inay ku soo laabato `Err` daalidda xusuusta halkii ay ka nixin lahayd ama ka soo ridi lahayd, laakiin tani maahan shuruud adag.
    /// (Gaar ahaan: waa *sharci* in lagu hirgeliyo trait dusha sare maktabadda qoondaynta qoyseed ee asaasiga ah ee ku adkaata xusuusta daal.)
    ///
    /// Macaamiisha doonaya inay tirtiraan xisaabinta iyagoo ka jawaabaya qaladka qoondaynta waxaa lagu dhiirigelinayaa inay wacaan shaqada [`handle_alloc_error`], halkii ay si toos ah uga yeeri lahaayeen `panic!` ama wax la mid ah.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BADBAADADA, maxaa yeelay, `new_layout.size()` waa ka weyn yahay ama la mid ah
        // `old_layout.size()`, qoondaynta xusuusta hore iyo tan cusub labaduba waxay ansax u yihiin akhrinta iyo wax u qorida `old_layout.size()` bytes.
        // Sidoo kale, maxaa yeelay qoondayntii hore weli lama kala saarin, kama wareejin karto `new_ptr`.
        // Marka, wicitaanka `copy_nonoverlapping` waa aamin.
        // Heshiiska amniga ee `dealloc` waa inuu ilaaliyaa qofka soo wacaya.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Dhaqmo sida `grow`, laakiin sidoo kale hubinayaa in waxyaabaha cusub ayaa lagu wadaa inay eber ka hor la soo noqdeen.
    ///
    /// Xusuusta xuubka ayaa ku jiri doonta waxyaabaha soo socda ka dib wicitaan guuleysi ah
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` waa laga ilaaliyaa qoondaynta asalka ah.
    ///   * Bytes `old_layout.size()..old_size` doonta midkood ha la wada ilaaliyo ama arbushaad, ku xiran tahay fulinta allocator ah.
    ///   `old_size` waxaa loola jeedaa xajmiga xusuusta kahor wicitaanka `grow_zeroed`, oo ka weynaan kara cabbirka markii hore la codsaday markii loo qoondeeyay.
    ///   * Bytes `old_size..new_size` waa eber.`new_size` loola jeedaa size of block xasuusta by call `grow_zeroed` ku soo laabtay ka.
    ///
    /// # Safety
    ///
    /// * `ptr` waa inuu sheegaa block xasuusta [*currently allocated*] iyada oo loo marayo qaybiyaha.
    /// * `old_layout` waa [*fit*] in block of xasuusta (u baahan dood The `new_layout` ma ku haboon.).
    /// * `new_layout.size()` waa inuu ka weynaadaa ama u dhigmaa `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Sooceliyaa `Err` haddii khariidad cusub ma la kulmaan caqabado size iyo in lays allocator ee allocator ah, ama haddii si kale loo sii kordhaya guuldareysto.
    ///
    /// Hirgelinta waxaa lagu dhiirrigelinayaa inay ku soo laabato `Err` daalidda xusuusta halkii ay ka nixin lahayd ama ka soo ridi lahayd, laakiin tani maahan shuruud adag.
    /// (Gaar ahaan: waa *sharci* in lagu hirgeliyo trait dusha sare maktabadda qoondaynta qoyseed ee asaasiga ah ee ku adkaata xusuusta daal.)
    ///
    /// Macaamiisha doonaya inay tirtiraan xisaabinta iyagoo ka jawaabaya qaladka qoondaynta waxaa lagu dhiirigelinayaa inay wacaan shaqada [`handle_alloc_error`], halkii ay si toos ah uga yeeri lahaayeen `panic!` ama wax la mid ah.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // BADBAADADA, maxaa yeelay, `new_layout.size()` waa ka weyn yahay ama la mid ah
        // `old_layout.size()`, qoondaynta xusuusta hore iyo tan cusub labaduba waxay ansax u yihiin akhrinta iyo wax u qorida `old_layout.size()` bytes.
        // Sidoo kale, maxaa yeelay qoondayntii hore weli lama kala saarin, kama wareejin karto `new_ptr`.
        // Marka, wicitaanka `copy_nonoverlapping` waa aamin.
        // Heshiiska amniga ee `dealloc` waa inuu ilaaliyaa qofka soo wacaya.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Isku dayga lagu yaraynayo xannibaadda xusuusta.
    ///
    /// Sooceliyaa [`NonNull<[u8]>`][NonNull] cusub oo ay kujiraan tilmaame iyo cabirka dhabta ah ee xusuusta loo qoondeeyay.Tilmaameyuhu wuxuu ku habboon yahay inuu hayo xog uu sharraxay `new_layout`.
    /// Si tan loo gaadho, allocator markii la xuso waxa laga yaabaa in qoondaynta tilmaansado by `ptr` ku haboon khariidad cusub.
    ///
    /// Hadday tan soo noqoto `Ok`, markaa lahaanshaha aaladda xusuusta ee tixraacaysa `ptr` waxaa loo wareejiyay qayb-bixiyeha.
    /// xusuustiisu laga yaabaa ama laga yaabaa in aanay la sii daayay, iyo waa in la tixgeliyaa istimaalaynin haddii waxa la dib ugu soo wacaha wareejiyo mar kale via qiimaha celinta habkan ah.
    ///
    /// Haddii habkan soo laabtay `Err`, lahaanshaha markaas of block xusuusta aan la wareejiyo allocator this, iyo waxyaabaha uu block xasuusta waa oon doorsoomaynin.
    ///
    /// # Safety
    ///
    /// * `ptr` waa inuu sheegaa block xasuusta [*currently allocated*] iyada oo loo marayo qaybiyaha.
    /// * `old_layout` waa [*fit*] in block of xasuusta (u baahan dood The `new_layout` ma ku haboon.).
    /// * `new_layout.size()` waa inuu kayaryahay ama la egyahay `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Sooceliyaa `Err` haddii khariidad cusub ma la kulmaan caqabado size iyo in lays allocator ee allocator ah, ama haddii si kale loo sii yaraanaya guuldareysto.
    ///
    /// Hirgelinta waxaa lagu dhiirrigelinayaa inay ku soo laabato `Err` daalidda xusuusta halkii ay ka nixin lahayd ama ka soo ridi lahayd, laakiin tani maahan shuruud adag.
    /// (Gaar ahaan: waa *sharci* in lagu hirgeliyo trait dusha sare maktabadda qoondaynta qoyseed ee asaasiga ah ee ku adkaata xusuusta daal.)
    ///
    /// Macaamiisha doonaya inay tirtiraan xisaabinta iyagoo ka jawaabaya qaladka qoondaynta waxaa lagu dhiirigelinayaa inay wacaan shaqada [`handle_alloc_error`], halkii ay si toos ah uga yeeri lahaayeen `panic!` ama wax la mid ah.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BADBAADADA, maxaa yeelay, `new_layout.size()` waa inuu ka hooseeyaa ama la mid ah
        // `old_layout.size()`, labada jir ah oo cusub oo loo qoondeeyay xasuusta waa ansax qoro, akhriyo, waayo `new_layout.size()` bytes.
        // Sidoo kale, maxaa yeelay qoondayntii hore weli lama kala saarin, kama wareejin karto `new_ptr`.
        // Marka, wicitaanka `copy_nonoverlapping` waa aamin.
        // Heshiiska amniga ee `dealloc` waa inuu ilaaliyaa qofka soo wacaya.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Waxay u abuurtaa adabtarada "by reference" tusaalahan `Allocator`.
    ///
    /// Adabtarada la soo celiyey ayaa sidoo kale fulisa `Allocator` oo si fudud ayuu u amaahan doonaa tan.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // BADBAADADA: heshiiska qandaraaska waa inuu ilaaliyaa soo wacaha
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BADBAADADA: heshiiska qandaraaska waa inuu ilaaliyaa soo wacaha
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BADBAADADA: heshiiska qandaraaska waa inuu ilaaliyaa soo wacaha
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BADBAADADA: heshiiska qandaraaska waa inuu ilaaliyaa soo wacaha
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}