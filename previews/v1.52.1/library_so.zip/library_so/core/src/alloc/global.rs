use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Qeybiyaha xusuusta ee loo diiwaangelin karo inuu yahay heerka maktabadda caadiga ah iyada oo loo marayo astaamaha `#[global_allocator]`.
///
/// Qaababka qaarkood waxay u baahan yihiin in xasuusta la xiro *oo hadda loo qoondeeyo* iyadoo loo marayo qaybiyaha.Tan macnaheedu waa:
///
/// * cinwaanka bilowga ee xasuusta xannibaadda waxaa horey loogu soo celiyay wicitaan hore habka qoondaynta sida `alloc`, iyo
///
/// * block xusuusta aan la danbe deallocated, halkaas oo blocks waxaa deallocated ama lagu gudbin hab deallocation sida `dealloc` ama ay ugu gudbi karo hab qoondeeyo in celinta ah tilmaamaha aan waxba a.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait waa `unsafe` trait sababo badan awgood, fuliyayaashuna waa inay hubiyaan inay u hoggaansamaan qandaraasyadan:
///
/// * Waa dabeecad aan la qeexin haddii qoondeeyayaasha adduunka ay kala baxaan.xadaynta Tani waa la sarraysiin laga yaabaa in future ah, laakiin hadda panic ka mid ka mid ah hawlaha kuwaas oo keeni karta in unsafety xasuusta.
///
/// * `Layout` weydiimaha iyo xisaabinta guud ahaan waa inay sax noqdaan.Soo wacayaasha trait waxaa loo oggol yahay inay ku tiirsanaadaan qandaraasyada lagu qeexay qaab kasta, fuliyayaashuna waa inay hubiyaan in qandaraasyada noocan oo kale ah ay run sii ahaanayaan.
///
/// * Waa inaadan ku tiirsaneyn qoondaynta run ahaantii dhaceysa, xitaa haddii ay jiraan qoondeyn cad oo meesha kuqoran.
/// Fududeeyuhu wuxuu ogaan karaa qoondaynta aan la isticmaalin oo ay gebi ahaanba tirtiri karto ama u dhaqaaqi karto isla markaana aan weligiis u yeerin qeybiye.
/// optimizer The dheeraad ah u qaadan waxaa laga yaabaa in loo qoondeeyay in uu yahay isku hallayn karo, si code in loo isticmaalo in ay ku fashilmaan sabab in lagu guulaysan waayay allocator laga yaabaa in haatan si lama filaan ah shaqada maxaa yeelay optimizer shaqeeyeen agagaarka baahida loo qabo qoondeynta ah.
/// Si ka sii macquulsan, tusaalaha tusaalaha soo socdaa waa mid aan caqli gal ahayn, iyadoon loo eegin haddii qoondadaada caadadu kuu ogolaato tirinta inta qoondeyn dhacday.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Ogsoonow in waxyaabaha aan kor ku soo xusnay aysan ahayn waxa kaliya ee la adeegsan karo.Guud ahaan kuma tiirsanaan kartid qoondayn taallo oo socota haddii laga saari karo iyadoon wax laga beddelin dhaqanka barnaamijka.
///   Haddii qoondayntu dhacdo iyo in kale ma aha qayb ka mid ah anshaxa barnaamijka, xitaa haddii lagu ogaan karo iyada oo loo marayo qoondeeye la socda qoondeynta iyada oo la daabacayo ama haddii kale ay leedahay waxyeellooyin.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// U qoondee xusuusta sida lagu sharraxay `layout` ee la siiyay.
    ///
    /// Waxay ku celisaa tilmaame xasuusta cusub ee loo qoondeeyay, ama waxba kama jiraan inay muujiso guuldaraysiga qoondaynta.
    ///
    /// # Safety
    ///
    /// Shaqadani waa mid aan amaan aheyn maxaa yeelay dabeecada aan la qeexin ayaa keeni karta hadii qofka soo waca uusan hubin in `layout` uu leeyahay cabir aan eber aheyn.
    ///
    /// (Subtraits Extension bixiyaan yaabaa in soohdin gaar ah oo ku saabsan dhaqanka, tusaale ahaan, damaanad cinwaanka Raqiib ama tilmaamaha waxba ka jawaabeysa codsiga qoondaynta eber-size a a.)
    ///
    /// Xusuusta loo qoondeeyay ee xusuusta ayaa laga yaabaa ama aan la bilaabi karin.
    ///
    /// # Errors
    ///
    /// Ku soo noqoshada tilmaamaha null wuxuu tilmaamayaa in xasuusta midkoodna uu daalay ama `layout` uusan la kulmin cabirkan qaybiyaha ama caqabadaha isku xidhka.
    ///
    /// Hirgelinta waxaa lagu dhiirigelinayaa inay ku soo celiso null maskaxda daalkeeda halkii laga soo ridi lahaa, laakiin tani maahan shuruud adag.
    /// (Gaar ahaan: waa *sharci* in lagu hirgeliyo trait dusha sare maktabadda qoondaynta qoyseed ee asaasiga ah ee ku adkaata xusuusta daal.)
    ///
    /// Macaamiisha doonaya inay tirtiraan xisaabinta iyagoo ka jawaabaya qaladka qoondaynta waxaa lagu dhiirigelinayaa inay wacaan shaqada [`handle_alloc_error`], halkii ay si toos ah uga yeeri lahaayeen `panic!` ama wax la mid ah.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Kala saar qaybta xusuusta ee tilmaanta `ptr` ee la siiyay `layout`.
    ///
    /// # Safety
    ///
    /// function Tani waa ammaan ahayn, sababtoo ah dhaqanka undefined keeni kartaa haddii aanu wacaha loo hubiyo in aan dhammaan ee soo socda:
    ///
    ///
    /// * `ptr` waa inuu sheegaa baloog xasuusta hadda lagu qoondeeyay qaybiyaha,
    ///
    /// * `layout` waa inuu ahaadaa qaab isku mid ah oo loo adeegsaday qoondaynta qaybta xusuusta.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Wuxuu u dhaqmaa sida `alloc`, laakiin wuxuu kaloo hubiyaa in waxyaabaha ku jira loo dhigay eber ka hor inta aan la soo celin.
    ///
    /// # Safety
    ///
    /// Shaqadani amaan ma ahan isla sababaha ay tahay `alloc`.
    /// Si kastaba ha noqotee xannibaadda loo qoondeeyey ee xusuusta ayaa la damaanad qaadayaa in la bilaabo.
    ///
    /// # Errors
    ///
    /// Ku soo noqoshada tilmaamaha null wuxuu tilmaamayaa in xasuusta midkoodna uu daalay ama `layout` uusan la kulmin cabbirka qoondeynta ama isku dhejinta, sida `alloc`.
    ///
    /// Macaamiisha doonaya inay tirtiraan xisaabinta iyagoo ka jawaabaya qaladka qoondaynta waxaa lagu dhiirigelinayaa inay wacaan shaqada [`handle_alloc_error`], halkii ay si toos ah uga yeeri lahaayeen `panic!` ama wax la mid ah.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // AMMAANKA: heshiis ammaanka `alloc` waa in la fuliyo ay wacaha.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // BADBAADADA: sida qoondayntu u guuleysatay, gobolku wuxuu ka yimid `ptr`
            // cabirkiisu yahay `size` waxaa loo balan qaadayaa inuu ansax u yahay qorista.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Isku soo wada xoori ama ku kori koronto xusuus leh `new_size`.
    /// Baloogga waxaa sharraxay tilmaamaha la siiyay ee `ptr` iyo `layout`.
    ///
    /// Haddii ay taasi soo noqoto tilmaamaha aan waxba a, ka dibna lahaanshaha block xasuusta tilmaansado by `ptr` ayaa loo wareejiyay allocator this.
    /// Xusuusta ayaa laga yaabaa ama laga yaabaa in aan la kala bixin, waana in loo tixgeliyaa inaan la isticmaali karin (dabcan haddii aan dib loogu celin qofka wacaya mar kale iyadoo loo marayo qiimaha soo noqoshada habkan).
    /// Xusuusta xusuusta cusub waxaa loo qoondeeyay `layout`, laakiin leh `size` oo loo cusbooneysiiyay `new_size`.
    /// Qaab-dhismeedkan cusub waa in la adeegsadaa marka lagu wareejinayo qalabka xusuusta cusub `dealloc`.
    /// Baaxadda `0..min(layout.size(), new_size) `` ee xusuusta cusub ayaa la damaanad qaadayaa inay la mid tahay qiimaha asalka ah.
    ///
    /// Haddii ay taasi habka celinta waxba, lahaanshaha markaas of block xusuusta aan la wareejiyo allocator this, iyo waxyaabaha uu block xasuusta waa oon doorsoomaynin.
    ///
    /// # Safety
    ///
    /// function Tani waa ammaan ahayn, sababtoo ah dhaqanka undefined keeni kartaa haddii aanu wacaha loo hubiyo in aan dhammaan ee soo socda:
    ///
    /// * `ptr` waa in hadda loo qoondeeyaa iyada oo loo marayo qaybiyaha,
    ///
    /// * `layout` waa inuu ahaadaa qaab isku mid ah oo loo adeegsaday qoondaynta qaybta xusuusta,
    ///
    /// * `new_size` waa inuu ka weynaadaa eber.
    ///
    /// * `new_size`, markii kor loo soo koobay si badan ugu dhow ee `layout.align()`, waa in aan dhulka qarqinaya (ie, qiimaha fekrado waa inuu ka yaraadaa `usize::MAX`).
    ///
    /// (Subtraits Extension bixiyaan yaabaa in soohdin gaar ah oo ku saabsan dhaqanka, tusaale ahaan, damaanad cinwaanka Raqiib ama tilmaamaha waxba ka jawaabeysa codsiga qoondaynta eber-size a a.)
    ///
    /// # Errors
    ///
    /// Waxay noqoneysaa wax aan waxba kajirin haddii qaabeynta cusub aysan buuxin xaddidaadaha iyo isku dheelitirnaanta qoondada, ama haddii dib uqeysiinta ay ku guuldareysato.
    ///
    /// Hirgelinta waxaa lagu dhiirigelinayaa inay ku soo celiso null daalka xusuusta halkii ay ka argagixi lahayd ama ka soo ridi lahayd, laakiin tani maahan shuruud adag.
    /// (Gaar ahaan: waa *sharci* in lagu hirgeliyo trait dusha sare maktabadda qoondaynta qoyseed ee asaasiga ah ee ku adkaata xusuusta daal.)
    ///
    /// Macaamiisha doonaya in ay xisaabinta rido jawaab u baadi qoondeeyo ah waxaa lagu dhiirigelinayaa inuu u soo yeedho shaqo [`handle_alloc_error`] ah, halkii si toos ah lagu koofaaro `panic!` ama la mid ah.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // AMMAANKA: wacaha waa inay hubiyaan in `new_size` ah ma dhulka qarqinaya.
        // `layout.align()` waxay ka timaadaa `Layout` ah iyo waxaa sidaas ballan qaaday in ay ansax ahaato.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // AMMAANKA: wacaha waa inay hubiyaan in `new_layout` waa ka weyn yahay eber.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // BADBAADADA: baloogii horey loo qoondeeyay iskama dhaafi karo qaybta cusub ee loo qoondeeyay.
            // Heshiiska amniga ee `dealloc` waa inuu ilaaliyaa qofka soo wacaya.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}