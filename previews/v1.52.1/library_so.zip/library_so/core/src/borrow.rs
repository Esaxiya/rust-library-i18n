//! Qayb lagu shaqeynayo xogta amaahda.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait loogu talagalay amaahda xogta.
///
/// In Rust, waxaa caadi ah in ay bixiyaan Wakiilada kala duwan oo nooc ka mid ah kiisaska isticmaalka kala duwan.
/// Tusaale ahaan, meesha kaydinta iyo maaraynta qiimaha la si gaar ah u doortay karaa sida ku haboon in loo isticmaalo si gaar ah via noocyada tilmaamaha sida [`Box<T>`] ama [`Rc<T>`].
/// Marka laga soo tago xirmooyinkan guud ee loo adeegsan karo nooc kasta, noocyada qaarkood waxay bixiyaan wajiyo ikhtiyaari ah oo bixinaya shaqeyn macquul ah oo qaali ah.
/// Tusaalaha noocan oo kale ah waa [`String`] kaas oo ku daraya awooda fidinta xariga [`str`] aasaasiga ah.
/// Tani waxay u baahan hayo macluumaad dheeraad ah oo aan loo baahnayn, waayo, fudud, xarig aan beddelmi karin.
///
/// Noocyadaas bixiyaan helitaanka xogta salka ku dhex tixraacyo nooca xogta in.Waxaa loo sheegay in ay noqon 'amaahatay sida' nooca in.
/// Tusaale ahaan, [`Box<T>`] ah laga amaahan kartaa sida `T` halka [`String`] ah laga amaahan kartaa sida `str`.
///
/// Noocyada muujiyaan in ay laga amaahan kartaa sida qaar ka mid ah nooca `T` by fulinta `Borrow<T>`, bixinta inay marjic u `T` ah in habka [`borrow`] ku trait ee.Nooc waa bilaash amaah ahaan dhowr nooc oo kala duwan.
/// Haddii uu rabo inuu mutably amaahan sida nooca-jidaynayey xogta dahsoon in wax laga badalo, waxaa intaasi dheer oo hirgelin karaan [`BorrowMut<T>`].
///
/// Dheeraad ah, marka la bixinayo hirgelinta traits dheeraad ah, waxay u baahan tahay in laga fiirsado haddii ay u dhaqmayaan kuwo la mid ah kuwa aasaasiga ah taasoo ka dhalaneysa inay u dhaqmaan sidii matalaadda noocaas aasaasiga ah.
/// Summada guud waxay caadi ahaan isticmaashaa `Borrow<T>` markay ku tiirsan tahay dabeecadaha isku midka ah ee fulinyadan dheeriga ah ee trait.
/// Kuwani traits waxay u muuqan doonaan inay yihiin trait bounds dheeraad ah.
///
/// Gaar ahaan `Eq`, `Ord` iyo `Hash` waa inay u dhigmaan qiyamka amaahda iyo kuwa leh: `x.borrow() == y.borrow()` waa inuu siiyaa isla natiijada ay la mid tahay `x == y`.
///
/// Haddii koodhka guud uu kaliya u baahan yahay inuu u shaqeeyo dhammaan noocyada bixin kara tixraaca nooca la xiriira `T`, badanaa way ka wanaagsan tahay in la isticmaalo [`AsRef<T>`] maaddaama noocyo badan ay si ammaan ah u hirgelin karaan.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Xog ururin ahaan, [`HashMap<K, V>`] wuxuu leeyahay furayaasha iyo qiimayaasha labadaba.Haddii xogta dhabta ah ee muhiimka ah ay ku duuban tahay nooc maareyn ah nooc ka mid ah, waa inay, si kastaba ha noqotee, wali suurtagal tahay in la raadiyo qiime iyadoo la adeegsanayo tixraaca xogta fure.
/// Tusaale ahaan, haddii furaha waa string ah, ka dibna waxaa ay u badan tahay lagu kaydiyaa la map hash sida [`String`] ah, halka ay noqon waa suurto gal ah si aad u raadiso isticmaalaya [`&str`][`str`] ah.
/// Sayidka, `insert` u baahan tahay in ay ku shaqeeyaan on `String` ah halka `get` u baahan yahay si ay u awoodaan si ay u isticmaalaan `&str` ah.
///
/// Si fudud loo fududeeyay, qaybaha ku habboon ee `HashMap<K, V>` waxay u egyihiin sidan:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // beeraha laga saaray
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// The map hash dhan waa generic badan nooca muhiim ah `K`.Sababtoo ah furayaashan waxaa lagu keydiyaa khariidada haashka, nuucaani waa inuu lahaadaa xogta furaha.
/// Markaad gelineyso lammaane qiime-qiime leh, khariidada waxaa la siinayaa `K` oo kale waxayna u baahan tahay inay hesho baaldi haash sax ah oo hubi haddii fure uu horey u joogo iyadoo lagu saleynayo `K`.Sidaa darteed waxay u baahan tahay `K: Hash + Eq`.
///
/// Markaad raadineyso qiimo ku yaal khariidada, si kastaba ha noqotee, inaad bixiso tixraac `K` ah maadaama furaha raadinta ay u baahan tahay in had iyo jeer la abuuro qiime noocan oo kale ah.
/// Waayo, furayaasha string, Tani micneheedu waa qiimaha `String` u baahan yahay in la abuuray oo keliya for search for kiisaska kaliya `str` ah waxaa laga heli karaa.
///
/// Taabadalkeed, habka `get` waa mid guud oo ku saabsan nooca xogta aasaasiga ah ee aasaasiga ah, oo loo yaqaan `Q` saxiixa habka kor ku xusan.Waxay sheegaysaa in `K` uu amaahdo `Q` adoo ubaahan `K: Borrow<Q>`.
/// By intaa u baahan `Q: Hash + Eq`, taasi waxay muujinaysaa, looga baahan yahay in `K` iyo `Q` leeyihiin fulintii of `Hash` iyo `Eq` ku traits in natiijo isku mid ah.
///
/// hirgelinta `get` tiirsan gaar ahaan on fulintii isku mid ah `Hash` by go'aaminta baaldi hash muhiimka ah ee wacaya `Hash::hash` qiimaha `Q` ah inkasta oo la geliyo furaha ku salaysan qiimaha hash ka qiimo `K` xisaabinta.
///
///
/// Natiijo ahaan, khariidada haashka ayaa jabta haddii `K` oo duubaya qiimaha `Q` ay soo saarto haash ka duwan `Q`.Tusaale ahaan, qiyaasi aad qabto nooc ka mid ah in wuxuuuna xarig ah laakiin barbardhigay warqado ASCII indha tirayo kiiska:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Sababtoo ah laba qiimeeyo siman u baahan tahay in la soo saaro qiime isku mid hash, hirgelinta `Hash` u baahan yahay inuu iska indha kiiska ASCII, sidoo kale:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` hirgelin karaan `Borrow<str>`?Waxaa hubaal ah ku siin kara inay marjic u jeex string via ay string leedahay ku jira ah.
/// Laakiin sababta oo ah hirgelinteeda `Hash` way ka duwan tahay, waxay u dhaqmeysaa si ka duwan `str` sidaas darteedna waa inaysan, dhab ahaan, hirgelin `Borrow<str>`.
/// Haddii ay rabto inay u oggolaato dadka kale inay galaan `str`, waxay ku sameyn kartaa taas iyada oo loo marayo `AsRef<str>` oo aan wadan wax shuruudo dheeri ah.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Si aan macquul ahayn ayaa wax looga amaahdaa qiimo la leeyahay.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait loogu talagalay amaahda xogta si isku mid ah.
///
/// Sida saaxiibka [`Borrow<T>`] trait tani waxay u oggolaanaysaa nooc ka mid ah si aad u amaahatid sida nooca aan muuqan oo siinaya tixraac mutable.
/// Eeg [`Borrow<T>`] wixii macluumaad dheeraad ah oo ku saabsan amaahashada sida nooc kale.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Isweydaarsi wax ka amaahdo qiimo la leeyahay.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}