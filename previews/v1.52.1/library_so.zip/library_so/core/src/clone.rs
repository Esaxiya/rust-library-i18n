//! trait `Clone` The noocyada in ma noqon karo 'si dadban guuriyeen'.
//!
//! Rust, noocyada fudud qaarkood waa "implicitly copyable" oo markaad u xilsaarto ama aad u gudbiso dood ahaan, qaataha ayaa heli doona nuqul, isagoo uga tagaya qiimaha asalka ah meesha.
//! Noocyadani uma baahna qoondeyn si ay u nuquliyaan mana laha finalizers (yacni, kuma jiraan sanduuqyo ay leeyihiin ama hirgelinta [`Drop`]), sidaa darteed ururiyaha wuxuu u arkaa inay yihiin kuwo raqiis ah oo ammaan u ah nuqul.
//!
//! Wixii noocyada kale nuqul waa in la si cad u sameeyey, by heshiiska hirgelinta trait [`Clone`] iyo wacaya habka [`clone`] ah.
//!
//! [`clone`]: Clone::clone
//!
//! Tusaale adeegsiga aasaasiga ah:
//!
//! ```
//! let s = String::new(); // Nooca String-ka wuxuu hirgaliyaa Clone
//! let copy = s.clone(); // markaa waan isku darsan karnaa
//! ```
//!
//! Si aad si fudud u fuliyaan trait Gadzhiyev oo ah, waxa kale oo aad isticmaali kartaa `#[derive(Clone)]`.Tusaale:
//!
//! ```
//! #[derive(Clone)] // waxaan ku darnaa Clone trait dhismaha Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // oo hadda waannu isku darsan karnaa!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// caadi A trait for awood u leh inay si cad nuqul shay.
///
/// Waxyaabaha ka duwan [`Copy`] ee [`Copy`] waa mid aan toos ahayn oo aad qaali u ah, halka `Clone` uu had iyo jeer cad yahay oo laga yaabo ama qaali noqon karo.
/// Si loo dhaqan geliyo astaamahan, Rust kuuma ogolaanayo inaad dib u soo celiso [`Copy`], laakiin waxaad dib u soo celin kartaa `Clone` oo aad koodh aan macquul ahayn socodsiin kartaa.
///
/// Maaddaama `Clone` ay ka guud tahay [`Copy`], waxaad si otomaatig ah u sameyn kartaa wax kasta oo [`Copy`] noqon kara `Clone` sidoo kale.
///
/// ## Derivable
///
/// trait waxaa loo isticmaali karaa `#[derive]` haddii beeraha oo dhan waa `Clone`.`Hirgelinta derive`d of [`Clone`] oo ku baaqay in [`clone`] garoonka kasta.
///
/// [`clone`]: Clone::clone
///
/// Waayo, struct a generic, `#[derive]` fulisaa `Clone` keeneysa la by daray ku xidhay `Clone` on-beegyada uu generic.
///
/// ```
/// // `derive` waxay fulisaa Clone ee Akhriska<T>marka T waa Gadzhiyev.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Sideen ku hirgelin karaa `Clone`?
///
/// Noocyada in ay yihiin [`Copy`] waa in ay leeyihiin fulinta ah awgood of `Clone`.Si rasmi ah
/// haddii `T: Copy`, `x: T`, iyo `y: &T`, ka dibna `let x = y.clone();` u dhiganta `let x = *y;`.
/// fulintii Manual waa inay ka taxadiraan in ay ilaaliyaan invariant this;Si kastaba ha ahaatee, code ammaan ahayn waa in aan tiirsataan si loo xaqiijiyo badbaadada xasuusta.
///
/// Tusaale waa qaab dhismeed guud oo haya tilmaamaha shaqada.Xaaladdan oo kale, hirgelinta `Clone` ma noqon karo `derive`d, laakiin waxaa lagu fulin karo sida:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Fuliyeyaal dheeri ah
///
/// Marka lagu daro [implementors listed below][impls], noocyada soo socda ayaa sidoo kale fuliya `Clone`:
///
/// * noocyada item Function (ie, noocyada kala duwan lagu qeexay shaqo kasta)
/// * Noocyada tilmaamaha shaqada (tusaale, `fn() -> i32`)
/// * Noocyada kala duwan, ee dhammaan cabbirka, haddii nooca walxaha sidoo kale fuliyo `Clone` (tusaale, `[i32; 123456]`)
/// * Noocyada nuugga, haddii qayb waliba ay sidoo kale fuliso `Clone` (tusaale, `()`, `(i32, bool)`)
/// * Noocyada xiritaanka, haddii aysan wax qiimo ah ka qaadan deegaanka ama haddii dhammaan qiyamka la qabtay ay hirgeliyaan `Clone` naftooda.
///   Xusuusnow in doorsoomayaasha ay qabteen tixraaca la wadaago had iyo jeer ay hirgeliyaan `Clone` (xitaa haddii tixraacaya uusan sameynin), halka doorsoomayaasha ay qabteen tixraaca isbeddelka ah aysan weligood hirgelin `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Kasoo celiyaa koobiga qiimaha.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str waxay fulisaa Kalidaa
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Waxay ka qabataa koobi-qoris `source`.
    ///
    /// `a.clone_from(&b)` waxay u dhigantaa `a = b.clone()` shaqeynta, laakiin waa la dulmari karaa si dib loogu isticmaalo kheyraadka `a` si looga fogaado qoondaynta aan loo baahnayn.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Dhalinta makro oo soosaara impl ah trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): structs kuwan waxaa keliya loo isticmaalo by#[dheegato] isaga oo sheegaya in qayb kasta oo ah qalab nooca Gadzhiyev ama Copy.
//
//
// Qodobadan waa inaysan waligood ka muuqan koodhka isticmaalaha.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Hirgelinta `Clone` ee noocyada asaasiga ah.
///
/// Hirgelinta aan lagu sifeyn karin Rust waxaa laga fuliyaa `traits::SelectionContext::copy_clone_conditions()` gudaha `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Tixraacyada la wadaago waa la wada dhejin karaa, laakiin tixraacyo la beddeli karo *ma* noqon karaan!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Tixraacyada la wadaago waa la wada dhejin karaa, laakiin tixraacyo la beddeli karo *ma* noqon karaan!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}