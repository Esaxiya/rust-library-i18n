use crate::iter::FromIterator;

/// Dhammaan alaabada unugyada ka soo goosata ayuu u kala qaadaa mid.
///
/// Tani waxay waxtar badan leedahay marka lagu daro soo-saaridda heerka sare, sida ku soo ururinta `Result<(), E>` halkaasoo aad kaliya ka taxaddarto khaladaadka:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}