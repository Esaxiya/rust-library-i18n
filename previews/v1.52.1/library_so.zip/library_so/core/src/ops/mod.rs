//! Hawl wadeenada rarka badan.
//!
//! Hirgelinta traits waxay kuu oggolaaneysaa inaad culeys ka saarto hawlwadeennada qaarkood.
//!
//! Qaar ka mid ah traits waxaa soo dhoofiya prelude, marka waxaa laga heli karaa barnaamij kasta oo Rust ah.Kaliya hawlwadeenada ay taageerayaan traits ayaa culeys badan la saari karaa.
//! Tusaale ahaan, shaqaale waxaa dheer (`+`) la buux karaa trait [`Add`] ah, laakiin tan iyo shaqaale shaqo (`=`) ayaa no taageero trait ah, aan jid lahayn ee Xammuul kelmedo ay.
//! Intaa waxaa sii dheer, qaybtani ma bixiso wax farsamo ah oo lagu abuuro hawl wadeenno cusub.
//! Haddii raray traitless ama caadada ka shaqeeya waxaa looga baahan yahay, waa in aad eegto xagga macros ama plugins compiler in la kordhiyo Saan Rust ee.
//!
//! Hirgelinta hawlwadeenka shirkadda 'traits' waa inay ahaato mid aan la yaab ku noqonaynin macnahooda, iyadoo maskaxda lagu hayo macnahooda caadiga ah iyo [operator precedence].
//! Tusaale ahaan, marka la hirgalinayo [`Mul`], qalliinku waa inuu yeeshaa xoogaa u eg isku dhufasho (iyo wadaago guryaha la filayo sida wadajirka).
//!
//! Xusuusnow in wadayaasha `&&` iyo `||` gaagaaban, yacni, waxay qiimeeyaan oo keliya operand-kooda labaad haddii ay wax ku darsato natiijada.Maaddaama dhaqankan uusan fulin karin traits, `&&` iyo `||` looma taageeri karo inay yihiin hawlwadeenno culeys badan.
//!
//! Qaar badan oo ka mid ah hawlwadeennada ayaa qiimeyntooda ku qaata.Xaaladaha aan generic ahayn ee ku lug leh noocyada la dhisay, tani caadi ahaan dhib ma leh.
//! Si kastaba ha ahaatee, iyadoo la isticmaalayo sheegaaya in code generic, waxay u baahan tahay fiiro qaar ka mid ah haddii qiimaha ay tahay in la isticmaali sida soo horjeeda daynin shaqeeya iyaga baabbi'in.Hal ikhtiyaar ayaa ah in mar mar la isticmaalo [`clone`].
//! Ikhtiyaar kale ayaa ah inaad ku tiirsanaato noocyada ku lug leh bixinta fulin hawlwadeenno dheeri ah tixraacyo.
//! Tusaale ahaan, nooca isticmaalaha lagu qeexay `T` ee loo malaynayo inuu taageerayo isku darka, waxay u badan tahay inay fikrad fiican tahay in labada `T` iyo `&T` labadaba la hirgaliyo traits [`Add<T>`][`Add`] iyo [`Add<&T>`][`Add`] si koodhka guud loo qori karo iyada oo aan loo baahnayn dheellitirnaan.
//!
//!
//! # Examples
//!
//! Tusaalahani wuxuu abuuraa qaab `Point` ah oo fuliya [`Add`] iyo [`Sub`], ka dibna muujiya isku darka iyo kalagoynta laba ``Point`s ''.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Eeg dukumintiyada trait kasta tusaale ahaan hirgelinta.
//!
//! [`Fn`], [`FnMut`], iyo [`FnOnce`] traits waxaa lagu fuliyaa noocyo loogu yeeri karo sida shaqooyinka oo kale.Xusuusnow in [`Fn`] ay qaadato `&self`, [`FnMut`] waxay qaadataa `&mut self` halka [`FnOnce`] ay qaadato `self`.
//! Kuwani waxay u dhigmaan saddexda nooc ee habab ee loogu yeeri karo tusaale ahaan: wicitaan-tixraac, wicitaan-ku-beddelid-tixraac, iyo wicitaan-ku-qiimo.
//! The isticmaalka ugu badan ee traits waa inay u dhaqmaan sida soohdin hawlaha heer sare-in ay qaataan hawlaha ama xiritaanka sida doodaha.
//!
//! Qaadashada [`Fn`] ahaan halbeegga:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Qaadashada [`FnMut`] ahaan halbeegga:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Qaadashada [`FnOnce`] ahaan halbeegga:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` waxay cuntaa doorsoomayaasheeda la soo qabtay, markaa lama maamuli karo wax ka badan hal jeer
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Isku dayga inaad mar labaad wacdo `func()` waxay tuuri doontaa qalad `use of moved value` ah `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` mar dambe lama yeeri karo markan
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;