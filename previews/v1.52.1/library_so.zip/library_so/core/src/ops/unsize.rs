use crate::marker::Unsize;

/// Trait oo tilmaamaysa in tani ay tahay tilmaame ama duub mid, halkaasoo xarigga looga jari karo tilmaamaha.
///
/// Ka eeg [DST coercion RFC][dst-coerce] iyo [the nomicon entry on coercion][nomicon-coerce] wixii faahfaahin dheeraad ah.
///
/// Noocyada tilmaamaha la dhisay, tilmaamayaasha `T` waxay ku qasbi doonaan tilmaamayaasha `U` haddii `T: Unsize<U>` iyagoo ka beddelaya tilmaamaha khafiifka ah ee tilmaamaha dufanka.
///
/// Noocyada caadada ah, qasabka halkan wuxuu ku shaqeeyaa adoo ku qasbaya `Foo<T>` ilaa `Foo<U>` iyadoo la bixiyay isugeyn `CoerceUnsized<Foo<U>> for Foo<T>` ah.
/// Nooca noocan oo kale ah ayaa la qori karaa oo keliya haddii `Foo<T>` uu leeyahay hal meel oo aan ahayn phantomdata oo ku lug leh `T`.
/// Haddii nooca duurka in uu yahay `Bar<T>`, hirgelinta ah `CoerceUnsized<Bar<U>> for Bar<T>` waa jiraan.
/// Qasabku wuxuu ku shaqeyn doonaa adoo ku khasbaya goobta `Bar<T>` `Bar<U>` iyo buuxinta qaybaha kale ee ka imanaya `Foo<T>` si loo abuuro `Foo<U>`.
/// Tani wax ku ool ah qodi doonaa inay yimaadaan berrinkii pointer iyo khasbaan in.
///
/// Guud ahaan, tilmaamayaasha caqliga badan waxaad ku hirgelin doontaa `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, oo leh ikhtiyaar `?Sized` ah oo ku xidhan `T` lafteeda.
/// Waayo, noocyada duuban in si toos ah Cudarada `T` sida `Cell<T>` iyo `RefCell<T>`, waxaad si toos ah hirgelin karaan `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Tani waxay u oggolaan doontaa qasbidda noocyada sida `Cell<Box<T>>` inay shaqeeyaan.
///
/// [`Unsize`][unsize] waxaa loo isticmaalaa si ay u xusaan nooc oo lagu qasbaayo kartaa in DSTs haddii gadaashiisa tilmaamo.Waxaa si otomaatig ah u hirgaliya iskuduwaha.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * Const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *Mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Tan waxaa loo adeegsadaa nabadgelyada sheyga, si loo hubiyo in nooca qaab-qaadaha loo diri karo.
///
/// Tusaale hirgelinta trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *Mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}