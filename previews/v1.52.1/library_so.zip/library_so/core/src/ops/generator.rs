use crate::marker::Unpin;
use crate::pin::Pin;

/// Natiijada soo-saare koronto-dhaliyaha.
///
/// Tirakoobkan waxaa laga soo celiyay habka `Generator::resume` wuxuuna muujinayaa qiimaha soo noqoshada ee matoor-dhaliye.
/// Waqtigan xaadirka ah tani waxay u dhigantaa dhibic ganaax (`Yielded`) ama dhibic joojinta (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Matoor dhaliyaha ayaa qiimo lagu laalay.
    ///
    /// Gobolkani wuxuu muujinayaa in koronto-dhaliye la joojiyay, caadi ahaanna wuxuu u dhigmaa bayaanka `yield`.
    /// Qiimaha lagu bixiyay noocani wuxuu u dhigmaa muujinta loo gudbiyay `yield` waxayna u oggolaaneysaa koronto-dhaliyeyaasha inay bixiyaan qiime mar kasta oo ay soo saaraan.
    ///
    ///
    Yielded(Y),

    /// Generator-ka ayaa lagu dhammaystiray qiimaha soo-celinta
    ///
    /// Gobolkani wuxuu muujinayaa in koronto-dhaliye uu ku dhammeeyay fulinta qiimaha la siiyay.
    /// Mar haddii koronto-dhaliye soo celiyey `Complete` waxaa loo tixgeliyaa inuu khalad barnaamij yahay inuu markale waco `resume`.
    ///
    Complete(R),
}

/// trait oo ay hirgelisay noocyada koronto-dhaliyeyaasha la dhisay.
///
/// Soo-saareyaasha, sidoo kale badanaa loo yaqaan 'coroutines', ayaa hadda ah muuqaal luuqad tijaabo ah oo ku jirta Rust.
/// Lagu daray matoorrada [RFC 2033] ayaa hadda loogu talagalay inay ugu horreyntii bixiyaan dhisme dhisme ah oo loogu talagalay sagxadda async/await laakiin waxay u badan tahay inay sii ballaadhato sidoo kale bixinta qeexidda ergonomic ee isuduwayaasha iyo waxyaabaha kale ee hordhaca ah.
///
///
/// Qaaciddada iyo macnaha erey-dhaliyeyaashu waa kuwo aan degganeyn waxayna u baahan doonaan RFC dheeraad ah oo xasilinta ah.Waqtigan xaadirka ah, inkasta oo, qaabeynta ay tahay xirid-u eg:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Dukumiintiyo dheeri ah oo ku saabsan matoorrada ayaa laga heli karaa buugga deggan.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Nooca qiimaha matoor this edbiyey.
    ///
    /// Tani waxay la xidhiidhaa waafaqsantahay nooca in ay ra'yi dhiibashada `yield` iyo qiyamka, kuwaas oo loo ogol yahay in ay la soo laabtay wakhti kasta oo ah wax-soosaarkooda matoor.
    ///
    /// Tusaale ahaan koronto-dhaliye soo-dheereeya ayaa u badan inuu yeesho noocan oo kale ah `T`, nooca loo yaqaan 'iterate over over'.
    ///
    type Yield;

    /// Nooca qiimaha koronto-dhaliyuhu soo laabanayo.
    ///
    /// Tani waxay u dhigantaa nooca laga sooceliyay koronto-dhaliye ama la socda qoraal `return` ah ama si maldahan u ah muujinta ugu dambeysa ee koronto-dhaliye suugaan ahaan.
    /// Tusaale ahaan futures wuxuu u isticmaali lahaa tan `Result<T, E>` maadaama ay mataleyso future dhameystiran.
    ///
    ///
    type Return;

    /// U Bilaabay fulinta matoor this.
    ///
    /// Shaqadani waxay dib u bilaabi doontaa fulinta koronto-dhaliyaha ama waxay bilaabi doontaa fulinta haddii aysan horey u lahayn.
    /// Wicitaankani wuxuu dib ugu laaban doonaa barta danab ee koronto-dhaliyihii ugu dambeeyay, isagoo dib uga bilaabaya fulinta `yield` kii ugu dambeeyay.
    /// Matoor-dhaliyaha ayaa sii wadi doona fulintiisa illaa uu soo saaro ama soo noqdo, markaas oo hawshani soo noqonayso.
    ///
    /// # Soo celinta qiimaha
    ///
    /// Xummada `GeneratorState` enum' ee laga soo celiyey shaqadan waxay muujineysaa xaaladda koronto-dhaliyuhu ku jiro markuu soo laabto.
    /// Haddii noocii `Yielded` la soo celiyo markaa matoorku wuxuu gaadhay meel ganaax ah qiimana waa la soo saaray.
    /// Matoorro ka shaqeeya gobolkan ayaa loo heli karaa dib u bilaabida barta dambe.
    ///
    /// Haddii `Complete` la soo celiyo markaa matoor-dhaliyaha ayaa gebi ahaanba ku dhammaaday qiimaha la siiyay.Waa ansax in matoorku dib loo bilaabo mar kale.
    ///
    /// # Panics
    ///
    /// function Tani panic laga yaabaa in haddii loo yeedhay ka dib markii ay kala duwanaansho `Complete` ayaa loo soo celiyay hore.
    /// In kasta oo suugaanta wax dhalisa ee luqadda loo dammaanad qaadayo panic markay dib u bilaabato `Complete` kadib, taas looma ballan qaadayo dhammaan hirgelinta `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}