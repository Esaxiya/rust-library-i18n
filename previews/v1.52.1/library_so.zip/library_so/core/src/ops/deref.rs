/// Waxaa loo adeegsaday howlaha tirtirida aan bedelka lahayn, sida `*v`.
///
/// Ka sokow in loo adeegsado hawlgallada sifeynta cad ee shirkadda (unary) `*` ee xaaladaha aan la beddeli karin, `Deref` waxaa sidoo kale si toos ah ugu adeegsaday isku duwe xaaladaha badan.
/// Farsamadan waxaa lagu magacaabaa ['`Deref` coercion'][more].
/// Xaaladaha la beddeli karo, [`DerefMut`] ayaa loo isticmaalay.
///
/// Hirgelinta `Deref` ee tilmaamayaasha caqliga badan waxay ka dhigeysaa helitaanka xogta gadaashooda mid ku habboon, waana sababta ay u hirgeliyaan `Deref`.
/// Dhinaca kale, sharciyada la xiriira `Deref` iyo [`DerefMut`] waxaa si gaar ah loogu talagalay in lagu waafajiyo tilmaamayaasha caqliga badan.
/// Tan darteed,**``Deref` waa in loo hirgaliyaa oo kaliya tilmaamayaasha caqliga badan** si looga fogaado jahwareerka.
///
/// Sababaha la midka ah awgood,**kan trait waa inuusan waligiis dhicin**.Ka gaabinta lagu jiro dereferencing la mid aad u jaahwareerin karaan marka `Deref` waxaa si dadban gawraco.
///
/// # More on qasab `Deref`
///
/// Haddii `T` fuliyo `Deref<Target = U>`, iyo `x` waa qiime nooca `T`, markaa:
///
/// * Xaaladaha aan la beddeli karin, `*x` (halka `T` uusan tixraac iyo tilmaam cayriin midna ahayn) wuxuu u dhigmaa `* Deref::deref(&x)`.
/// * Qiimaha nooca `&T` waxaa lagu qasbay qiyamka nooca `&U`
/// * `T` si maldahan u fulinaya dhamaan hababka (immutable) ee nooca `U`.
///
/// Faahfaahin dheeraad ah, booqo [the chapter in *The Rust Programming Language*][book] iyo sidoo kale qaybaha tixraaca ee [the dereference operator][ref-deref-op], [method resolution] iyo [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Qaab dhismeed leh hal goob oo lagu heli karo iyadoo laga dhigayo qaab dhismeedka.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Nooca keentay ka dib markii dereferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferences qiimaha.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Waxaa loo adeegsaday hawlgallada isdabamarin la'aanta, sida `*v = 1;`.
///
/// Marka lagu daro in loo isticmaalo hawlgallada sifeynta caddaynta leh ee shirkadda (unary) `*` ee xaaladaha la beddeli karo, `DerefMut` waxaa sidoo kale si toos ah ugu adeegsanaya isku-duwaha duruufo badan.
/// Farsamadan waxaa lagu magacaabaa ['`Deref` coercion'][more].
/// Xaaladaha aan la beddeli karin, [`Deref`] ayaa loo isticmaalay.
///
/// Ku hirgelinta `DerefMut` ee tilmaamayaasha caqliga badan waxay ka dhigaysaa isku shaandheynta xogta gadaashooda ku habboon, taasna waa sababta ay u hirgeliyaan `DerefMut`.
/// Dhinaca kale, sharciyada la xiriira [`Deref`] iyo `DerefMut` waxaa si gaar ah loogu talagalay in lagu waafajiyo tilmaamayaasha caqliga badan.
/// Tan darteed,**``DerefMut` waa in loo hirgaliyaa oo kaliya tilmaamayaasha caqliga badan** si looga fogaado jahwareerka.
///
/// Sababaha la midka ah awgood,**kan trait waa inuusan waligiis dhicin**.Ku guuldareysiga inta lagu jiro diiwaangelinta waxay noqon kartaa mid aad u jahwareersan marka `DerefMut` si toos ah loogu yeero.
///
/// # More on qasab `Deref`
///
/// Haddii `T` fuliyo `DerefMut<Target = U>`, iyo `x` waa qiime nooca `T`, markaa:
///
/// * Xaaladaha la beddeli karo, `*x` (halka `T` uusan tixraac iyo tilmaam cayriin midna ahayn) wuxuu u dhigmaa `* DerefMut::deref_mut(&mut x)`.
/// * Qiimayaasha nooca `&mut T` waxaa qanciyeen in qiyamka `&mut U` nooca
/// * `T` si maldahan u fulinaya dhamaan hababka (mutable) ee nooca `U`.
///
/// Faahfaahin dheeraad ah, booqo [the chapter in *The Rust Programming Language*][book] iyo sidoo kale qaybaha tixraaca ee [the dereference operator][ref-deref-op], [method resolution] iyo [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// struct A iyo berrinkaba, hal kaas oo modifiable by dereferencing struct ah.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Iskudhaaf ahaan ayaa looga gaabiyaa qiimaha.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Waxay muujineysaa in qaab-dhismeed loo isticmaali karo sidii qaab qaade, oo aan lahayn muuqaalka `arbitrary_self_types`.
///
/// Tan waxaa fuliya noocyada tilmaamaha stdlib sida `Box<T>`, `Rc<T>`, `&T`, iyo `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}