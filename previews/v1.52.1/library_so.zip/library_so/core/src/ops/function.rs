/// version of operator call in qaadataa aqbalana ah oo aan beddelmi karin ah.
///
/// Xaaladaha `Fn` la odhan karaa celcelis ah oo aan mutating gobolka.
///
/// *Tan trait (`Fn`) maahan in lagu qaldo [function pointers] (`fn`).*
///
/// `Fn` waxaa si toos ah loogu hirgaliyaa xiritaanka taas oo kaliya u qaadanaysa tixraacyada aan laga beddeli karin doorsoomayaasha la qabtay ama aan waxba qabsan gabi ahaanba, iyo sidoo kale (safe) [function pointers] (oo leh digniino qaar, fiiri dukumiintigooda wixii faahfaahin dheeraad ah).
///
/// Intaa waxaa sii dheer, nooc kasta oo `F` ah oo fuliya `Fn`, `&F` wuxuu hirgeliyaa `Fn`, sidoo kale.
///
/// Maaddaama labadaba [`FnMut`] iyo [`FnOnce`] yihiin supertraits of `Fn`, tusaale kasta oo `Fn` ah waxaa loo isticmaali karaa halbeegga halka laga filayo [`FnMut`] ama [`FnOnce`].
///
/// U isticmaal `Fn` xiritaan ahaan markaad rabto inaad aqbasho cabirka nooca shaqada oo aad ubaahantahay inaad si isdaba-joog ah ugu wacdo adigoon wax ka beddelin xaaladda gobolka (tusaale ahaan, markii aad si isku mid ah ugu yeeraysid).
/// Haddii aadan samayn u baahan tahay shuruudo adag oo kale, isticmaali [`FnMut`] ama [`FnOnce`] sida gudbee.
///
/// Ka eeg [chapter on closures in *The Rust Programming Language*][book] wixii macluumaad dheeri ah ee ku saabsan mowduucan.
///
/// Sidoo kale waxaa xusid mudan ereyga gaarka ah ee `Fn` traits (tusaale
/// `Fn(usize, bool) -> Isticmaal ').Kuwa xiiseynaya faahfaahinta farsamo ee tan waxay tixraaci karaan [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Wicitaanka xiritaanka
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Adeegsiga halbeegga `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // si regex ugu tiirsanaan karto `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Waxay qabataa hawlgalka wicitaanka.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Nooca wadaha wicitaanka ee qaata qalabka wax lagu beddelo.
///
/// Tusaalooyinka `FnMut` waxaa loogu yeeri karaa si isdaba joog ah waxayna isu beddeli kartaa xaalad.
///
/// `FnMut` waxaa si toos ah loogu hirgaliyaa xiritaanka kuwaas oo qaata tixraacyo la beddeli karo oo ku saabsan doorsoomayaasha la qabtay, iyo sidoo kale dhammaan noocyada fuliya [`Fn`], tusaale, (safe) [function pointers] (maadaama `FnMut` uu yahay supertrait of [`Fn`]).
/// Intaa waxaa sii dheer, nooc kasta oo `F` ah oo fuliya `FnMut`, `&mut F` wuxuu hirgeliyaa `FnMut`, sidoo kale.
///
/// Maaddaama [`FnOnce`] uu yahay supertrait-ka `FnMut`, tusaale kasta oo `FnMut` ah ayaa loo isticmaali karaa halka laga filayo [`FnOnce`], maaddaama [`Fn`] ay tahay hoos u dhac `FnMut`, tusaale kasta oo [`Fn`] ah ayaa loo isticmaali karaa halka `FnMut` laga filayo.
///
/// U isticmaal `FnMut` xiritaan markaad rabto inaad aqbasho halbeegga nooca waxqabadka oo kale oo aad u baahan tahay inaad si isdaba-joog ah u wacdo, adigoo u oggolaanaya inuu isbeddelo gobolka.
/// Haddii aadan rabin in halbeegga uu isbeddelo gobolka, u isticmaal [`Fn`] xiritaan ahaan;haddii aadan u baahnayn inaad si isdaba joog ah u wacdid, isticmaal [`FnOnce`].
///
/// Ka eeg [chapter on closures in *The Rust Programming Language*][book] wixii macluumaad dheeri ah ee ku saabsan mowduucan.
///
/// Sidoo kale waxaa xusid mudan ereyga gaarka ah ee `Fn` traits (tusaale
/// `Fn(usize, bool) -> Isticmaal ').Kuwa xiiseynaya faahfaahinta farsamo ee tan waxay tixraaci karaan [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## U yeerista xiritaan isku mid ah
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Adeegsiga halbeegga `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // si regex ugu tiirsanaan karto `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Waxay qabataa hawlgalka wicitaanka.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Nooca wadaha wicitaanka ee qaata qiime qaate.
///
/// Tusaalooyinka `FnOnce` waa la wici karaa, laakiin waxaa laga yaabaa inaanay la soo kaban karin dhowr jeer.Taas darteed, haddii waxa kaliya ee loo yaqaano oo ku saabsan nooca ah waa in ay fulisaa `FnOnce`, waxa keliya oo la odhan karaa hal mar.
///
/// `FnOnce` waxaa la hirgeliyey si toos ah by xiritaanka laga yaabo in ay ku baabbi'iyee doorsoomayaasha qabsaday, iyo sidoo kale dhammaan noocyada in la hirgeliyo [`FnMut`], tusaale ahaan, (safe) [function pointers] (tan iyo `FnOnce` waa supertrait ah [`FnMut`]).
///
///
/// Maaddaama labadaba [`Fn`] iyo [`FnMut`] ay yihiin cutubyo ka mid ah `FnOnce`, tusaale kasta oo ka mid ah [`Fn`] ama [`FnMut`] waa la isticmaali karaa halka laga filayo `FnOnce`.
///
/// U isticmaal `FnOnce` xiritaan ahaan markaad rabto inaad aqbasho halbeegga nooca waxqabadka oo kale oo keliya waxaad u baahan tahay inaad wacdo hal jeer.
/// Haddii aad u baahato inaad soo wacdo halbeegga si isdaba-joog ah, u isticmaal [`FnMut`] xiritaan ahaan;haddii aad sidoo kale waxa ay u baahan tahay in aan gobolka isbaddali, isticmaali [`Fn`].
///
/// Ka eeg [chapter on closures in *The Rust Programming Language*][book] wixii macluumaad dheeri ah ee ku saabsan mowduucan.
///
/// Sidoo kale waxaa xusid mudan ereyga gaarka ah ee `Fn` traits (tusaale
/// `Fn(usize, bool) -> Isticmaal ').Kuwa xiiseynaya faahfaahinta farsamo ee tan waxay tixraaci karaan [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Adeegsiga halbeegga `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` waxay cuntaa doorsoomayaasheeda la soo qabtay, markaa lama maamuli karo wax ka badan hal jeer.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Isku dayga inaad mar labaad wacdo `func()` waxay tuuri doontaa qalad `use of moved value` ah `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` mar dambe lama yeeri karo markan
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // si regex ugu tiirsanaan karto `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Nooca ku soo laabtay ka dib markii operator call loo isticmaalo.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Waxay qabataa hawlgalka wicitaanka.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}