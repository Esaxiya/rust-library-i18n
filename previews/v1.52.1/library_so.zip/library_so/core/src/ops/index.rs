/// Waxaa loo adeegsaday tilmaamida howlaha (`container[index]`) xaalado aan la beddeli karin.
///
/// `container[index]` dhab ahaantii waa sonkor isku-dhafan oo loogu talagalay `*container.index(index)`, laakiin kaliya marka loo isticmaalo qiimo aan beddelmi karin.
/// Haddii qiimo la beddelayo la codsado, [`IndexMut`] beddelkeeda ayaa la isticmaalaa.
/// Tani waxay u oggolaaneysaa waxyaabo fiican sida `let value = v[index]` haddii nooca `value` fuliyo [`Copy`].
///
/// # Examples
///
/// Tusaalaha soo socda ayaa ku hirgelinaya `Index` weel kaliya oo la akhriyi karo oo ah `NucleotideCount`, taasoo awood u siineysa shakhsiyaadka tirinta in dib loogala soo baxo sintiga tusmada.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Nooca ku soo laabtay ka dib markii tusmaynta.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Waxay qabataa hawlgalka tusmeynta (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Waxaa loo adeegsaday tilmaamida howlaha (`container[index]`) xaaladaha macquulka ah.
///
/// `container[index]` dhab ahaantii waa sonkor isku-dhafan oo loogu talagalay `*container.index_mut(index)`, laakiin kaliya marka loo isticmaalo qiimo la beddeli karo.
/// Haddii qiimo la beddeli karo la codsado, [`Index`] trait ayaa beddelkeeda la adeegsanayaa.
/// Tani waxay u oggolaaneysaa waxyaabo fiican sida `v[index] = value`.
///
/// # Examples
///
/// Fulin aad u fudud oo qaab dhismeedka `Balance` ah oo leh laba dhinac, halkaas oo mid waliba lagu tilmaami karo isbadal iyo is bedel la'aan.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Xaaladdan oo kale, `balance[Side::Right]` waa sonkor loogu talagalay `*balance.index(Side::Right)`, maadaama aan kaliya* aqrinayno * `balance[Side::Right]`, oo aan qorin.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Si kastaba ha noqotee, xaaladdan `balance[Side::Left]` waa sonkor loogu talagalay `*balance.index_mut(Side::Left)`, maadaama aan qoreyno `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Waxay qabataa hawlgalka tusmeynta isbeddelaya ee (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}