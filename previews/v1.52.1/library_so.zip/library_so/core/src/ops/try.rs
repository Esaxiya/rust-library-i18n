/// trait loogu talagalay u habeynta dabeecadda hawlwadeenka `?`.
///
/// nooca A fulinta `Try` waa mid ka mid ah in uu leeyahay hab qaadanin in ay u arkaan in la eego Caqiidadani success/failure ah.
/// trait-kan ayaa u oggolaanaya labadaba soo saarida kuwa guusha ama qiimaha guuldarrooyinka tusaale ahaan jira iyo abuurista tusaale cusub laga soo bilaabo qiimaha guusha ama guul darrada.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Nooca qiimahan markii loo arko inuu guuleystay.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Nooca qiimaha this markii viewed sida ku guuldareystay.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Khuseysaa operator "?" ah.Soocelinta `Ok(t)` waxay ka dhigan tahay in fulintu si caadi ah u socoto, natiijada `?`-na waa qiimaha `t`.
    /// Soocelinta `Err(e)` waxay ka dhigan tahay in fulinta ay tahay branch inay ku xirnaato gudaha ugu hooseeya ee `catch`, ama ka soo laabato shaqada.
    ///
    /// Haddii natiijada `Err(e)` la soo noqdeen, qiimaha `e` waxay noqon doontaa "wrapped" in nooca soo laabashada baaxadda lifaqaya ah (oo waa in laftiisa fuliyo `Try`).
    ///
    /// Gaar ahaan, qiimaha `X::from_error(From::from(e))` waa la soo celiyey, halkaasoo `X` uu yahay nooca soo noqoshada ee shaqada lifaaqa.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Duub qiimo qalad ah si loo dhiso natiijada isku dhafan.
    /// Tusaale ahaan, `Result::Err(x)` iyo `Result::from_error(x)` waa u dhigmaan.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Duub qiimo OK si ay u dhisaan natiijada kooban.
    /// Tusaale ahaan, `Result::Ok(x)` iyo `Result::from_ok(x)` waa u dhigmaan.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}