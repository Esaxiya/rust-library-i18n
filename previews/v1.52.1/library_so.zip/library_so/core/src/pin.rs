//! Noocyada xogta ku dhajiya halka ay ku taal xusuusta.
//!
//! Mararka qaar waxtar ayey leedahay in la helo walxo dammaanad qaad ah oo aan dhaqaaqi karin, iyadoo macnaheedu yahay meelaynta xusuustooda aysan is beddelin, sidaasna lagu kalsoonaan karo.
//! Tusaale A Ra'iisul xaalad sida uu noqon doono dhismaha structs is-referential, sida dhaqaaqin wax la tilmaamo laftiisa si ay u buriyaan doonaa, oo wuxuu keeni karaa dhaqanka undefined.
//!
//! Heer sare, [`Pin<P>`] wuxuu hubiyaa in tilmaamaha nooc kasta oo tilmaam ah `P` uu leeyahay meel xasilloon oo xusuusta ah, taasoo la micno ah inaan loo dhaqaajin karin meel kale xusuustiisana aan lakala saari karin ilaa ay hoos u dhacdo.Waxaan leenahay tilmaamaha waa "pinned".Waxyaabaha aad u hesho khiyaano markii ay kala hadlayaan nooc oo isku iskula xogta aan iskula;[see below](#projections-and-structural-pinning) wixii faahfaahin dheeraad ah.
//!
//! By default, dhammaan noocyada kala duwan ee Rust yihiin dhaqaajin karo.
//! Rust waxay u oggolaaneysaa gudbinta dhammaan noocyada qiime ahaan, iyo noocyada tilmaamaha caqliga badan sida [`Box<T>`] iyo `&mut T` waxay u oggolaanayaan beddelidda iyo dhaqaajinta qiyamka ay wataan: waad ka bixi kartaa [`Box<T>`], ama waad isticmaali kartaa [`mem::swap`].
//! [`Pin<P>`] wuxuu duubaa nooca tilmaamaha `P`, sidaa darteed [`Pin`]`<`['' Box`] ''<T>> wuxuu u shaqeeyaa sida caadiga ah
//!
//! [`Box<T>`]: when ah a (``Pin`] `<` [``Box`] ''<T>> wuu dhacayaa, sidaas oo kale waxa ku jira, xusuustuna way sii dhacaysaa
//!
//! la sii dejiyeySidoo kale, [`Pin`]`<&mut T>`waa wax badan oo la mid ah `&mut T`.Si kastaba ha ahaatee, [`Pin<P>`] ma ha macaamiisha dhab heli [`Box<T>`] ama `&mut T` in xogta iskula, taas oo muujinaysa in aad uma isticmaali karo hawlgallada sida [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` wuxuu ubaahanyahay `&mut T`, laakiin maheli karno.
//!     // Waan ku dhagannahay, ma beddeli karno waxyaabaha ku jira tixraacyadan.
//!     // Waxaan isticmaali karnaa `Pin::get_unchecked_mut`, laakiin taasi ammaan ma ahan sabab ahaan:
//!     // naloooma oggola inaan u isticmaalno inaan wax uga rarno `Pin`.
//! }
//! ```
//!
//! Waxaa xusid mudan in Goluhu [`Pin<P>`] sameeya *aan* beddelo xaqiiqda ah in compiler Rust a aragto dhamaan noocyada dhaqaajin karo.[`mem::swap`] wali waa looheli karaa wixii `T` ah.Halkii, [`Pin<P>`] ka hortagtaa qiimaha *qaarkood*(tilmaamay by tilmaamo ku duudduubtay oo [`Pin<P>`]) ka waday samaynta wax aan macquul ahayn in loo yeedho hababka u baahan `&mut T` iyaga (sida [`mem::swap`]) on.
//!
//! [`Pin<P>`] waxaa loo isticmaali karaa in lagu duubo nooc kasta oo tilmaam ah `P`, oo sida oo kale waxay la falgaleysaa [`Deref`] iyo [`DerefMut`].[`Pin<P>`] halka `P: Deref` ay tahay in loo tixgeliyo inuu yahay "`P`-style pointer" inuu xardhan yahay `P::Target`-so, a (``Pin`] '' <`['' Box`] ''<T>> Waa tilmaamaha ah loo leeyahay si ay u `T` ah iskula, oo ah [`Pin`]`<`[`Rc`] `<T>>`` waa tilmaame tixraac tixraac leh oo ku duugan `T`.
//! Wixii saxnimada, [`Pin<P>`] tiirsan ee fulintii of [`Deref`] iyo [`DerefMut`] ma guurto ah oo ay u dhimaya `self`, iyo weligiis keliya inuu ku soo laabto pointer ah in xogta iskula marka loogu yeedho on tilmaamaha a iskula.
//!
//! # `Unpin`
//!
//! Noocyo badan ayaa had iyo jeer si xor ah loo dhaqaajin karo, xitaa marka la xidho, maxaa yeelay kuma tiirsana inay yeeshaan cinwaan deggan.Tan waxaa ku jira dhammaan noocyada aasaasiga ah (sida [`bool`], [`i32`], iyo tixraacyada) iyo sidoo kale nooc ka kooban oo keliya ka mid ah noocyada kuwan.Noocyada in aadan daryeeli ku saabsan salka hirgeliyaan [`Unpin`] auto-trait, oo cancels saamaynta [`Pin<P>`].
//! Waayo, `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`` iyo [`Box<T>`] waxay u shaqeeyaan si isku mid ah, sida '' Pin`]`<&mut T>` `iyo `&mut T`.
//!
//! Xusuusnow in pinning iyo [`Unpin`] kaliya ay saameynayaan nooca-tilmaamaya `P::Target`, ma ahan nooca tilmaamaha `P` laftiisa oo ku duudduubtay [`Pin<P>`].Tusaale ahaan, haddii [`Box<T>`] waa [`Unpin`] saameyn ah kuma laha dhaqanka [`Pin`]`<`[`Box`] `<T>> (halkan, `T` waa nooca tilmaaman).
//!
//! # Tusaale: is-tixraac dhisme
//!
//! Kahor intaanan u galin faahfaahin dheeraad ah si aan u sharaxno dammaanadaha iyo xulashooyinka la xiriira `Pin<T>`, waxaan ka wada hadalnay tusaalooyin ku saabsan sida loo isticmaali karo.
//! Xor ayaad u tahay [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Tani waa qaab is-tixraac ah maxaa yeelay qaybta jeexjeexa ayaa tilmaamaysa goobta xogta.
//! // Waxaan ma u sheegi kartaa compiler ah oo ku saabsan in la tixraacayo caadi ah, sida hannaankii this aan lagu tilmaami karaa sharciyada amaahda caadiga ah.
//! //
//! // Taabadalkeed waxaan isticmaalnaa tilmaam cayriin, in kastoo mid la ogyahay inuusan waxba kajirin, sidaan ognahay wuxuu ku tilmaamayaa xariga.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Si loo hubiyo in xogtu aysan dhaqaaqin marka shaqadu soo noqoto, waxaan u dhigeynaa meesha ay ku sii nagaaneyso inta shayga uu nool yahay, sida kaliya ee lagu heli karana waxay noqon kartaa tilmaanta iyada u socota.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // annagu waxaan uun nahay abuuro pointer mar xogta waa meel haddii kale waxaa horay u dhaqaaqay ka hor inta aanan xitaa bilaabay
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // Waan ognahay inay taasi badbaado tahay maxaa yeelay wax ka beddelka goobtu ma wareejiso dhismaha oo dhan
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Tilmaameyuhu waa inuu tilmaamaa meesha saxda ah, ilaa iyo inta dhismuhu uusan dhaqaaqin.
//! //
//! // Dhanka kale, waxaan xor u yihiin inay u guuraan tilmaamaha ku wareegsan.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Maadaama noocayagu aanu hirgelin Unpin, tani waxay ku guuldareysan doontaa inay soo uruuriso:
//! // ha mut cusub_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Tusaale: liis laba-geesood ah oo is dhexgal ah
//!
//! In liiska adigoo laab lala-, ururinta aanu run ahaantii ma qoondeeyo xusuusta, waayo, xubno ka laftiisa.
//! Qoondaynta waxaa xukuma macaamiisha, canaasiirtuna waxay ku noolaan karaan dhisme isku dhegan oo ku noolaa wax ka yar inta ururintu ku jirto.
//!
//! Si shaqadan loo sameeyo, cunsur kastaa wuxuu leeyahay tilmaamayaal kan isaga kahoreeyay iyo kan ku xigay ee liiska.Qaybaha kaliya lagu dari karaa marka ay iskula, maxaa yeelay, dhaqaaqin xubno ku wareegsan buriyaan lahaa tilmaamo ah.Intaa waxaa sii dheer, hirgelinta [`Drop`] ee liistada liistada ku xiran waxay dhejin doontaa tilmaamayaasha kan ka horreeyay iyo kan beddelay si uu isaga saaro liiska.
//!
//! Muhiimad ahaan, waa inaan awoodnaa inaan isku halleyno [`drop`] oo la yiraahdo.Haddii curiye la kala qaybin karo ama haddii kale la burin karo iyada oo aan la wicin [`drop`], tilmaamayaasha ka soo baxa ee ka imanaya cunsurrada deriska la ah ayaa noqonaya kuwo aan ansax ahayn, taas oo jebinaysa qaab dhismeedka xogta.
//!
//! Sidaa darteed, dhejinta ayaa sidoo kale la socota dammaanad la xidhiidha [``drop`].
//!
//! # `Drop` guarantee
//!
//! Ujeedada biininta ayaa ah in lagu kalsoonaado meelaynta xogta qaar ee xasuusta.
//! Si shaqadan loo sameeyo, ma aha oo kaliya dhaqaajinta xogta waa la xadiday;kala wareejinta, dib u soo celinta, ama haddii kale baabi'inta xasuusta loo isticmaalay in lagu kaydiyo xogta waa la xaddiday, sidoo kale.
//! Gunaanad ahaan, xogta la dhejiyay waa inaad ilaalisaa is beddel la'aanta ah in *xusuustiisu aysan xumaan doonin ama aan dib loo soo saari doonin laga bilaabo marka ay isqabato ilaa iyo inta [`drop`] loogu yeerayo*.Kaliya hal mar oo ay soo noqoto [`drop`] ama panics, xusuusta ayaa dib loo isticmaali karaa.
//!
//! Xusuusta waxay noqon kartaa "invalidated" is-beddelid, laakiin sidoo kale iyadoo la beddelo [`Some(v)`] oo loo yaqaan [`None`], ama la waco [`Vec::set_len`] illaa "kill" waxyaabo ka mid ah aaladda 'vector'.Waa in la repurposed kartaa adigoo isticmaalaya [`ptr::write`] in ay overwrite aan wacaya destructor ugu horeysay.None of this la oggol yahay, waayo xogta iskula aan wacaya [`drop`].
//!
//! Tani waa dhab nooca damaanad in liiska adigoo lala qeybta hore loo baahan yahay in shaqo sax ah.
//!
//! Notice in damaanad waxan sameeya *aan* macnaheedu xasuusta in aanu daadato!Weli waa caadi in waligeed aan loogu yeerin [`drop`] walxaha jiiniska ah (tusaale ahaan, wali waad u wici kartaa [`mem::forget`] on a (``Pin`] '' <`['' Box`] ''<T>> ``).Tusaalaha liiska labalaabka kuxiran, cunsurku wuxuu kusii nagaan doonaa liiska.Si kastaba ha ahaatee aadan laga yaabaa in lacag la'aan ah ama isticmaalin kaydinta *aan ugu yeeray [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Haddii isticmaalka noocan aad salka (sida labada tusaale ku xusan), aad leedahay si taxaddar marka la fulinayo [`Drop`].Hawsha [`drop`] waxay qaadataa `&mut self`, laakiin tan waxaa lagu magacaabaa *xitaa haddii noocaaga horay loo dhejiyay*!Waa sida haddii compiler si toos ah u yeedhay [`Pin::get_unchecked_mut`].
//!
//! Tani waligeed dhibaato kuma keeni karto lambar aamin ah maxaa yeelay hirgelinta nooc ku tiirsan pinning waxay u baahan tahay koodh aan aamin ahayn, laakiin la soco inaad go'aansato inaad ka faa'iideysato nabarrada noocaaga ah (tusaale ahaan adoo fulinaya qalliin qaar ka mid ah ['Pin`]' <&Self>`` ama ('' Pin`]`<&mut Self>``) waxay leedahay cawaaqib ku saabsan hirgelintaada [`Drop`] sidoo kale: haddii qayb ka mid ah noocaaga la soo jiidan lahaa, waa inaad ula dhaqanto [`Drop`] sidii si aan toos ahayn u qaadata ['Pin`]` <&mut Is>>.
//!
//!
//! Tusaale ahaan, waxaad u hirgelin kartaa `Drop` sida soo socota:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` waa caadi maxaa yeelay waxaan ognahay in qiimahan aan dib dambe loo isticmaalin ka dib markii la tuuro.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Koodhka rasmiga ah ayaa halkan tusaya.
//!         }
//!     }
//! }
//! ```
//!
//! Shaqada `inner_drop` waxay leedahay nooca ay tahay in [`drop`]*ay* yeelato, marka tani waxay hubineysaa inaadan si shil ah u adeegsan `self`/`this` qaab khilaafsan pinning.
//!
//! Waxaa intaa dheer, haddii nooca waa `#[repr(packed)]`, compiler si toos ah u gudbi doontaa beeraha ku wareegsan si ay u awoodaan si ay u soo daadiyaa.Xitaa way sameyn kartaa taas meelaha loogu talagalay in si ku filan loo waafajiyo.Natiijo ahaan, uma isticmaali kartid inaad ku dhejisid nooca `#[repr(packed)]`.
//!
//! # Saadaasha iyo Maskaxda Dhismaha
//!
//! Markaad ku shaqeyneyso jaangooyooyin pinned, su'aasha ayaa soo baxeysa sida qofku u heli karo beeraha qaab dhismeedka qaab qaadanaya kaliya [``Pin ''`<&mut Struct>` `.
//! Qaabka caadiga ah waa in la qoro hababka caawiyaha (oo loogu yeero *Saadaasha*) ee u weeciya [`Pin`]`<&mut Struct>`` tixraac goobta, laakiin noocee tixraac ah ayuu yeelan karaa?Ma [`Pin`] '<&mut Field>` mise `&mut Field`?
//! Su'aal isku mid ah ayaa ka soo baxeysa dhinacyada `enum`, iyo sidoo kale markaad tixgelinayso noocyada container/wrapper sida [`Vec<T>`], [`Box<T>`], ama [`RefCell<T>`].
//! (Su'aashani waxay khuseysaa tixraacyada la beddeli karo iyo kuwa la wadaago labadaba, waxaan kaliya u isticmaalnaa kiiska ugu caansan ee tixraacyada isbeddelaya halkan sawir ahaan.)
//!
//! Waxay soo baxday inay runti ku xidhan tahay qoraaga qaab dhismeedka xogta inuu go aansado in saadaasha jiidan ee goob gaar ahi isu badasho [`Pin`]`<&mut Struct>`` oo loo beddelo '' Pin`]`<&mut Field>` `ama `&mut Field`.Waxaa jira caqabado qaar inkasta oo, laakiin caqabadda ugu muhiimsan ay tahay *joogteyn*:
//! field kasta waxay noqon kartaa mid * * qiyaasay in uu tixraac iskula,*ama* ayaa salka saaro oo qayb ka ah qiyaas ah.
//! Haddii labada waxaa lagu sameeyey beer la mid ah, in badan tahay waxay noqon doontaa in dhimirkiisu!
//!
//! Maaddaama aad tahay qoraha qaab-dhismeedka xogta waxaad go'aan ka gaartaa qayb kasta haddii aad ku dhejineyso "propagates" goobtan iyo in kale.
//! Biininta faafinaysa waxaa sidoo kale loo yaqaan "structural", maxaa yeelay waxay raacdaa qaabdhismeedka nooca.
//! Qeybaha soosocda, waxaan ku sharaxeynaa tixgelinta ay tahay in loo sameeyo midkastoo xulasho ah.
//!
//! ## Bixinta * ma ahan qaab dhismeedka `field`
//!
//! Waxay u muuqan kartaa mid caqli-gal ah in berrinka qaabdhismeedka pinned laga yaabo in aan la xidhin, laakiin taasi runti waa xulashada ugu fudud: haddii aan waligeed la abuurin [``Pin`] '' <&mut Field> ``!Marka, haddii aad go'aansato in qayb ka mid ah aysan lahayn xargo dhismeed, waxa kaliya ee lagaa rabo inaad hubiso ayaa ah inaadan waligaa abuurin tixraac ku duugan goobtaas.
//!
//! Meelaha aan lahayn pinning-ka qaabdhismeedka waxay yeelan karaan qaab saadaalin oo isu rogaya (``Pin`] '' <&mut Struct> `` ilaa `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Tani waa caadi maxaa yeelay `field` waligeed looma tixgeliyo pinned.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Waxa kale oo laga yaabaa inaad `impl Unpin for Struct`*xitaa haddii* nooca `field` uusan ahayn [`Unpin`].Waxa noocaas ka fikirayaa ku dhejinta ma aha mid khuseeya marka aan waligiis la abuurin [`Pin`]` <&mut Field> ''.
//!
//! ## Bixinta *waa* qaabdhismeed loogu talagalay `field`
//!
//! Ikhtiyaarka kale ayaa ah in la go'aansado in biinintu tahay "structural" oo loogu talagalay `field`, taas oo macnaheedu yahay in haddii qaabdhismeedka la dhejiyo markaa waa sidaas oo kale berrinka.
//!
//! Tani waxay u oggolaaneysaa qorista saadaasha abuureysa `'' Pin`]`<&mut Field>``, sidaasna ku markhaati furaysa in berrinka la taagay:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Tani waa caadi maxaa yeelay `field` waa la dhajiyay markii `self` yahay.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Si kastaba ha noqotee, isku dhejinta qaabdhismeedka ayaa leh shuruudo yar oo dheeri ah:
//!
//! 1. struct waa in uu kaliya [`Unpin`] haddii dhammaan beerihii dhismaha waa [`Unpin`].Kani waa tan caadiga ah, laakiin [`Unpin`] waa trait nabdoon, marka qoraaga dhismuhu waa masuuliyadaada *maaha* inaad ku darto wax sida `impl<T> Unpin for Struct<T>` ah.
//! (Fiiro u yeelo in lagu daro hawlgalka saadaashu waxay u baahan tahay nambar aan aamin ahayn, marka xaqiiqda ah in [`Unpin`] ay tahay trait nabdoon ma jebinayso mabda'a ah inaad kaliya ka walwasho mid uun tan haddii aad isticmaasho `` ammaan darro ''.)
//! 2. Burburiye qaab dhismeedka waa inuusan ka dhaqaaqin aagagga dhismaha dooddiisa.Tani waa barta saxda ah ee lagu soo qaaday [previous section][drop-impl]: `drop` waxay qaadataa `&mut self`, laakiin qaabdhismeedka (oo markaa meesheeda) waxaa suuragal ah in horay loo xirxiray.
//!     Waa inaad dammaanad ka qaaddaa inaadan u wareegin meel gudaha ah hirgelintaada [`Drop`].
//!     Gaar ahaan, sida horay u sharxay, Taas macnaheedu waa in aad struct waa *aan* noqon `#[repr(packed)]`.
//!     U fiirso qaybtaas sida loo qoro [`drop`] qaab isku-duwaha uu kaa caawin karo inaadan shil u jabin pinning.
//! 3. Waa in aad hubisaa in aad taageertaa [`Drop` guarantee][drop-guarantee] ah:
//!     mar haddii qaabdhismeedkaaga la dhejiyo, xusuusta ay ku jirto waxa ka kooban dib looma qorin ama lama wareejin doono iyada oo aan loo yeerin dumiyeyaasha maaddada.
//!     Tani waxay noqon kartaa adag, sida goob [`VecDeque<T>`]: destructor ee [`VecDeque<T>`] dafiri karto inaad wacdo [`drop`] on dhammaan qaybaha haddii mid ka mid ah destructors ku panics.Tani waxay ku xad gudbeysaa dammaanadda [`Drop`], maxaa yeelay waxay u horseedi kartaa canaasiirta in la kala qaado iyada oo aan loo yeerin qaswigooda.([`VecDeque<T>`] laha Saadaasha salka, si taasi ma keeni unsoundness.)
//! 4. Waa inaadan soo bandhigin waxqabadyo kale oo horseedi kara in xogta laga raro aagagga dhismaha marka noocaaga la xidho.Tusaale ahaan, haddii struct ku jira [`Option<T>`] ah oo waxaa jira a `take`-sida hawlgal nooca `fn(Pin<&mut Struct<T>>) -> Option<T>`, hawlgalka oo loo isticmaali karo in ay u guuraan `T` ka soo baxay oo `Struct<T>` ah iskula-taas oo macnaheedu yahay salka ma noqon karo dhismaha berrinka ee this haysta xogta.
//!
//!     Tusaalaha ugu adag ee ka guurista xogta nooc jiinis ah, ka fikir haddii [`RefCell<T>`] uu lahaa qaab `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` ah.
//!     Kadib waxaan sameyn karnaa waxyaabaha soo socda:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Tani waa musiibo, waxay ka dhigan tahay in aan marka hore wareemo kartaa content ee [`RefCell<T>`] ah (iyadoo la isticmaalayo `RefCell::get_pin_mut`) ka dibna u guurto content in isticmaalaya tixraaca mutable aan mar dambe helay.
//!
//! ## Examples
//!
//! Waayo, nooc ka mid ah sida [`Vec<T>`], labada fursadaha (salka dhismaha ama ma) macno samaynayaan.
//! A [`Vec<T>`] la salka dhismaha yeelan karaan habab `get_pin`/`get_pin_mut` in iskula tixraacyo xubno.Si kastaba ha ahaatee, waxaa *aan* ogolaan karin wacaya [`pop`][Vec::pop] on [`Vec<T>`] ah iskula sababtoo ah in guurto lahaa (qaab ahaan iskula) ku jira!Sidoo kale ma oggolaan karto [`push`][Vec::push], oo dib u habeyn ku sameyn kara isla markaana sidoo kale dhaqaajin kara waxyaabaha ku jira.
//!
//! [`Vec<T>`] aan lahayn qaabdhismeed dhismeed ayaa `impl<T> Unpin for Vec<T>` noqon kara, maxaa yeelay waxyaabaha ku jira waligood lama dhejin oo [`Vec<T>`] lafteedu way fiicantahay in la dhaqaajiyo sidoo kale.
//! Waqtigaas oo kaliya ayaa wax saameyn ah kuma yeelanayso vector.
//!
//! Maktabadda caadiga ah, noocyada tilmaame guud ahaan ma laha jijin qaab-dhismeed, sidaas darteedna ma bixiyaan saadaallo dhejis.Tani waa sababta `Box<T>: Unpin` u hayso dhammaan `T`.
//! Waxa macno si arrintan loo sameeyo noocyada pointer, maxaa yeelay, dhaqaaqin `Box<T>` uusan dhab ahaantii guurto `T` ah: [`Box<T>`] wuxuu noqon karaa mid si xor ah dhaqaajin karo (aka `Unpin`) xataa haddii `T` ma aha.Xaqiiqdii, xitaa [``Pin`] '' <`[` `Box`] ''<T>> ``iyo '' Pin`] `<&mut T>` marwalba waa [`Unpin`] naftooda, isla sababahaas awgood: waxa ku jira (`T`) waa la dhajiyay, laakiin tilmaamayaasha laftooda waa la dhaqaajin karaa iyadoon la dhaqaajin xogta la soo jiiday.
//! Waayo, [`Box<T>`] iyo [`Pin`]`<`[`Box`] `<T>>``, in waxyaabaha la soo dhejiyay ay gebi ahaanba ka madax bannaan yihiin in tilmaamaha la soo jiiday, taasoo la micno ah qanjaruufo *maaha* qaabdhismeed.
//!
//! Markaad hirgelinaysid isku-darka [`Future`], waxaad badanaa ubaahan doontaa isdabamarin qaabdhismeed loogu talagalay qolka futures, maadaama aad ubaahantahay inaad kaheshid tixraacyo iyaga ku habboon si aad ugu wacdo [`poll`].
//! Laakiin haddii aad combinator ku jira wixii macluumaad kale oo aan loo baahneyn in la iskula, waxaad samayn kartaa beeraha kuwa aan dhismaha iyo halkan si xor ah ku helaan iyaga oo leh tixraac mutable xataa marka aad u leedahay [`Pin`]`<&mut Self>`(sida sida ku xusan hirgelintaada [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Tilmaame tilmaame.
///
/// Kani waa duub ku duuban nooc tilmaame ah taas oo tilmaame ka dhigeysa "pin" in qiimeheeda meesha ku jiro, taasoo ka hortageysa in qiimaha ay tilmaamtay tilmaamehaas la dhaqaajiyo illaa ay fuliso [`Unpin`] mooyee.
///
///
/// *Eeg dukumiintiyada [`pin` module] si aad u hesho sharraxaad ku saabsan pinning.*
///
/// [`pin` module]: self
///
// Note: `Clone` ee ka hooseeya waxay keentaa xaalad-xumo maadaama ay suurtagal tahay in la hirgeliyo
// `Clone` waayo, tixraacyo mutable.
// Ka eeg <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> wixii faahfaahin dheeraad ah.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Dhaqan gelinta soo socota looma soo saarin si looga fogaado arrimaha maqalka.
// `&self.pointer` waa inaan loo ogolaan fulinta trait aan aaminka ahayn.
//
// Ka eeg <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> wixii faahfaahin dheeraad ah.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Dhisaan `Pin<P>` cusub agagaarka pointer ah in xogta qaar ka mid ah nooc ka mid ah in qalab [`Unpin`].
    ///
    /// Si ka duwan `Pin::new_unchecked`, habkan waa amaan waayo tilmaamaha `P` dereferences nooca [`Unpin`] ah, taas oo cancels ku damaanado salka.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // BADBAADADA: qiimaha la tilmaamay waa `Unpin`, sidaas darteedna wax shuruud ah ma lahan
        // hareeraha salka.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Wuxuu furayaa `Pin<P>`-kan isagoo soo celinaya tilmaamaha salka ku haya.
    ///
    /// Tani waxay u baahan tahay in xogta ku jirta `Pin`-kan ay tahay [`Unpin`] si aan iska indha-tiri karno is-beddelka qunyar-socodka markii aan furaynay.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Dhis `Pin<P>` cusub oo ku wareegsan tixraaca xogta qaar nooc ka mid ah oo hirgelin kara ama aan hirgelin karin `Unpin`.
    ///
    /// Haddii `pointer` laga qoro nooca `Unpin`, `Pin::new` waa in la adeegsadaa halkii.
    ///
    /// # Safety
    ///
    /// Dhisehani ma nabad galyo maxaa yeelay dammaanad kama qaadi karno in xogta la tilmaamay ee `pointer` la dhajiyay, taasoo la micno ah in xogta aan la dhaqaajin doonin ama aan kaydintooda la burin doonin ilaa ay hoos u dhacaan.
    /// Haddii `Pin<P>` ka dhisay ma hubo in xogta dhibcood `P` loo iskula, in uu yahay xadgudub ku ah heshiiska API iyo waxay keeni kartaa in dabeecadda undefined ee dambe hawlgallada (safe).
    ///
    /// Adoo adeegsanaya qaabkan, waxaad ka sameyneysaa promise ku saabsan hirgelinta `P::Deref` iyo `P::DerefMut`, haddii ay jiraan.
    /// Tan ugu muhiimsan, waa inaysan ka guurin doodahooda `self`: `Pin::as_mut` iyo `Pin::as_ref` waxay wici doonaan `DerefMut::deref_mut` iyo `Deref::deref`*oo tilmaamaya tilmaamaha* waxayna filayaan in qaababkani ay taageeri doonaan kuwa isdifaacaya.
    /// Intaa waxaa dheer, adigoo wacaya qaabkan waxaad promise in tixraacyada `P` ee ka-noqoshada dib looga saari doonin mar kale;gaar ahaan, waa in aanay noqon macquul in la helo `&mut P::Target` ka dibna ka guurto tixraac in (iyadoo la isticmaalayo, tusaale ahaan [`mem::swap`]).
    ///
    ///
    /// Tusaale ahaan, ku soo wac `Pin::new_unchecked` taleefoonka `&'a mut T` waa mid aan ammaan ahayn maxaa yeelay intaad awood u leedahay inaad ku dhejiso inta aad nooshahay oo dhan `'a`, ma lihid xakameyn haddii lagu dhajinayo markii uu `'a` dhammaado:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Tani waa inay la micno tahay tilmaamaha `a` inuusan mar dambe dhaqaaqi karin.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Cinwaanka `a` waxaa loo beddelay booska `` b '', sidaas darteed `a` waa la dhaqaaqay inkasta oo aan hore u saarnay!Waxaan jebinay qandaraaska API.
    /////
    /// }
    /// ```
    ///
    /// Qiimaha A, mar iskula, waa in ay sii weligiis iskula (haddii qalab nooca ay `Unpin`).
    ///
    /// Sidoo kale, ku wacida `Pin::new_unchecked` ee `Rc<T>` waa amni darro maxaa yeelay waxaa jiri kara magacyo isku mid ah oo xog ah oo aan ku xirnayn xayiraadaha dhejinta:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Tani waxay la macno tahay in tilmaamuhu uusan mar dambe dhaqaaqi karin.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Haddaba, haddii `x` ahaa tixraaca oo keliya, waxaan leenahay tixraac mutable in xogta in aan kor iskula, taas oo aan ku isticmaali kartaa si aad u guurto sida aan soo aragnay in tusaale ahaan la soo dhaafay.
    ///     // Waxaan jebinay qandaraaska API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Helo tixraac iskula la wadaago ka pointer this iskula.
    ///
    /// Tani waa qaab guud oo looga gudbo `&Pin<Pointer<T>>` ilaa `Pin<&T>`.
    /// Waa ammaan sababtoo ah, sida qeyb ka mid ah heshiiska of `Pin::new_unchecked`, pointee ma dhaqaajin karin ka dib markii lagu helay in `Pin<Pointer<T>>` abuuray.
    ///
    /// "Malicious" hirgelinta `Pointer::Deref` waxaa sidoo kale meesha ka saaraya qandaraaska `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // AMMAANKA: arko dukumentiyada ku saabsan shaqo this
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Wuxuu furayaa `Pin<P>`-kan isagoo soo celinaya tilmaamaha salka ku haya.
    ///
    /// # Safety
    ///
    /// Shaqadani waa mid aan amaan ahayn.Waa inaad dammaanad ka qaaddaa inaad sii wadi doontid inaad ula dhaqanto tilmaamaha `P` sidii pinned ka dib markii aad wacdo shaqadan, si is beddellada ku jira nooca `Pin` loo ilaaliyo.
    /// Haddii koodhka adeegsanaya natiijada soo baxday ee `P` uusan sii wadin inuu ilaaliyo isbeddellada muraayadaha oo xad gudub ku ah heshiiska qandaraaska 'API' oo laga yaabo inuu u horseedo dhaqan aan la qeexin hawlgallada dambe ee (safe).
    ///
    ///
    /// Haddii xogta dahsoon waa [`Unpin`], [`Pin::into_inner`] waa in la isticmaalaa halkii.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Helo a iskula tixraaca mutable ka pointer this iskula.
    ///
    /// Tani waa qaab guud oo looga gudbo `&mut Pin<Pointer<T>>` ilaa `Pin<&mut T>`.
    /// Waa ammaan sababtoo ah, sida qeyb ka mid ah heshiiska of `Pin::new_unchecked`, pointee ma dhaqaajin karin ka dib markii lagu helay in `Pin<Pointer<T>>` abuuray.
    ///
    /// "Malicious" hirgelinta `Pointer::DerefMut` waxaa sidoo kale meesha ka saaraya qandaraaska `Pin::new_unchecked`.
    ///
    /// Habkani waa mid faa iido leh marka wicitaano badan loo sameeyo shaqooyinka cunta nooca jiidan.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // wax samee
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` wuxuu cunaa `self`, markaa dib ugu soo celi `Pin<&mut Self>` adigoo adeegsanaya `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // AMMAANKA: arko dukumentiyada ku saabsan shaqo this
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Waxay u qoondeysaa qiime cusub xusuusta ka dambeysa tixraaca jiidan.
    ///
    /// Tani overwrites iskula xogta, laakiin taasi waa Okay, ay destructor uu ordo ka hor inta overwritten, sidaa darteed ma salka damaanad la jebiyo.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Waxay ku dhistaa biin cusub adoo ku sawiraya qiimaha gudaha.
    ///
    /// Tusaale ahaan, haddii aad dooneysay inaad hesho `Pin` oo ah goob shay, waxaad u isticmaali kartaa tan si aad ugu hesho marinkaas hal xariiq oo koodh ah.
    /// Si kastaba ha noqotee, waxaa jira dhowr gotchas oo leh "pinning projections";
    /// fiiri dukumiintiyada [`pin` module] wixii faahfaahin dheeri ah ee ku saabsan mowduucaas.
    ///
    /// # Safety
    ///
    /// Shaqadani waa mid aan amaan ahayn.
    /// Waa in aad damaanad in xogta aad ku laabato ma dhaqaaqi doono inta qiimaha muran ma guuraan ah (tusaale ahaan, maxaa yeelay waxa ay mid ka mid ah beeraha oo qiimo leh waa), iyo sidoo kale in aad u ma guurto ah dood aad hesho si ay u shaqada gudaha.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // BADBAADADA: heshiiska qandaraaska ee `new_unchecked` waa inuu ahaadaa
        // uu taageeray qofka soo wacaya.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Wuxuu helayaa tixraac la wadaago biin ka dib.
    ///
    /// Tani waa amaan maxaa yeelay macquul maahan in laga guuro tixraac wadaag ah.
    /// Waa laga yaabaa oo kale waxaa la mutability gudaha waa arin halkan: dhab ahaantii, u *waa* suurto gal ah in ay u guuraan `T` ka soo baxay oo `&RefCell<T>` ah.
    /// Si kastaba ha ahaatee, tani ma aha dhibaato ilaa inta uu jiro aanu sidoo kale ma jiraan `Pin<&T>` a fiiqaya in ay xogta isku, iyo `RefCell<T>` ma ha aad la abuuro tixraac iskula in waxyaabaha ay.
    ///
    /// Ka eeg dooda ["pinning projections"] wixii faahfaahin dheeraad ah.
    ///
    /// Note: `Pin` sidoo kale waxay fulisaa `Deref` bartilmaameedka, kaas oo loo isticmaali karo in lagu galo qiimaha gudaha.
    /// Si kastaba ha noqotee, `Deref` kaliya waxay bixisaa tixraac nool illaa inta amaahda `Pin`, maahan inta uu nool yahay `Pin` laftiisa.
    /// Habkani wuxuu u oggolaanayaa inuu `Pin` u rogo tixraac isla noloshiisii hore oo ah tii `Pin` ee asalka ahayd.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Kuweeda `Pin<&mut T>` this galay `Pin<&T>` la noolaa isla.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Hesho tixraac isbeddel ah oo ku saabsan xogta ku jirta `Pin`-kan.
    ///
    /// Tani waxay u baahan tahay in xogta gudaha `Pin` ay tahay `Unpin`.
    ///
    /// Note: `Pin` sidoo kale waxay fulisaa `DerefMut` xogta, taas oo loo isticmaali karo in lagu galo qiimaha gudaha.
    /// Si kastaba ha noqotee, `DerefMut` kaliya waxay bixisaa tixraac nool illaa inta amaahda `Pin`, maahan inta uu nool yahay `Pin` laftiisa.
    ///
    /// Habkani wuxuu u oggolaanayaa inuu `Pin` u rogo tixraac isla noloshiisii hore oo ah tii `Pin` ee asalka ahayd.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Hesho tixraac isbeddel ah oo ku saabsan xogta ku jirta `Pin`-kan.
    ///
    /// # Safety
    ///
    /// Shaqadani waa mid aan amaan ahayn.
    /// Waa inaad dammaanad ka qaaddaa inaadan waligaa ka guurin doonin xogta tixraaca isbeddelka ah ee laguu soo diro markaad soo wacdo shaqadan, si kuwa aan is beddelin ee nooca `Pin` loo ilaaliyo.
    ///
    ///
    /// Haddii xogta hoose ay tahay `Unpin`, waa in la istcimaalo `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Samee biin cusub adoo ku sawiraya qiimaha gudaha.
    ///
    /// Tusaale ahaan, haddii aad dooneysay inaad hesho `Pin` oo ah goob shay, waxaad u isticmaali kartaa tan si aad ugu hesho marinkaas hal xariiq oo koodh ah.
    /// Si kastaba ha noqotee, waxaa jira dhowr gotchas oo leh "pinning projections";
    /// fiiri dukumiintiyada [`pin` module] wixii faahfaahin dheeri ah ee ku saabsan mowduucaas.
    ///
    /// # Safety
    ///
    /// Shaqadani waa mid aan amaan ahayn.
    /// Waa in aad damaanad in xogta aad ku laabato ma dhaqaaqi doono inta qiimaha muran ma guuraan ah (tusaale ahaan, maxaa yeelay waxa ay mid ka mid ah beeraha oo qiimo leh waa), iyo sidoo kale in aad u ma guurto ah dood aad hesho si ay u shaqada gudaha.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // BADBAADADA: Wicitaanku wuxuu mas'uul ka yahay dhaqaajinta
        // Qiimaha tixraacan.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // BADBAADADA: maadaama qiimaha `this` la damaanad qaaday inuusan lahayn
        // waa la guuray, wicitaankan `new_unchecked` waa aamin.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Ka hel tixraac jaanis ah tixraac ma guurto ah.
    ///
    /// Tani waa ammaan, maxaa yeelay `T` ayaa loo amaahan yahay nolosha `'static`, oo aan dhammaanayn.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // BADBAADADA: 'Amaahda joogtada ah ayaa dammaanad qaadaysa in xogta aysan noqon doonin
        // moved/invalidated ilaa uu hoos u dhacay (oo ma aha).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Ka hel tixraac beddelid is bedbeddelaya oo ka soo baxa tixraaca isbeddelka joogtada ah.
    ///
    /// Tani waa ammaan, maxaa yeelay `T` ayaa loo amaahan yahay nolosha `'static`, oo aan dhammaanayn.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // BADBAADADA: 'Amaahda joogtada ah ayaa dammaanad qaadaysa in xogta aysan noqon doonin
        // moved/invalidated ilaa uu hoos u dhacay (oo ma aha).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: Tan macnaheedu waa waxkasta oo `CoerceUnsized` ah oo u oggolaanaya ku khasbidda
// nooc soo jiita `Deref<Target=impl !Unpin>` nooc u roon `Deref<Target=Unpin>` waa unsound.
// Wax kasta oo noocan oo kale ah waxay u badan tahay inuusan fiicnayn sababo kale awgood, in kastoo, sidaa darteed waxaan u baahanahay oo keliya inaan ka taxaddarno inaan u oggolaanno soo-jeedinnada noocaas ah inay ku soo degaan std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}