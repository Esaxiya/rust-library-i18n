//! Taageerada Panic ee libcore
//!
//! maktabadda core ma qeexi karaan argagaxsanaayeen, laakiin waxa aanu *warramaynaa* argagaxsanaayeen.
//! Tani waxay ka dhigan tahay in howlaha ka socda libcore loo oggol yahay panic, laakiin si ay faa'iido u yeelato kor u kaca crate waa inuu qeexaa argagaxa loogu talagalay libcore inuu isticmaalo.
//! Xiriirka hadda ee argagaxa waa:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Taas macnaheedu waxaa u oggolaanaysa in argagaxsanaayeen oo fariin kasta oo guud, laakiin waxa aanu u ogolaan in ay ku guuldaraysteen la qiimaha `Box<Any>` ah.
//! (`PanicInfo` kaliya wuxuu ka kooban yahay `&(dyn Any + Send)`, kaas oo aan ugu buuxinayno qiimo wasakh ah `` PanicInfo: : Internal_constructor '') Sababta tan ayaa ah in libcore aan loo ogolayn inay qoondeeyaan.
//!
//!
//! Qaybtani waxay ka kooban tahay shaqooyin kale oo argagax leh, laakiin kuwani waa uun waxyaalaha loo baahan yahay ee loo yaqaan 'compiler'.Dhamaan panics waxaa lagu dhajiyay shaqadan kaliya.
//! Astaanta dhabta ah waxaa lagu cadeeyay astaamaha `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Hirgelinta salka of libcore ee Dhaqale `panic!` markii formatting ma waxaa loo isticmaalaa.
#[cold]
// marna Wabka haddii panic_immediate_abort si looga fogaado bloat code goobaha call intii macquul ah
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // loo baahan yahay by codegen for panic on dhulka qarqinaya, oo terminators kale `Assert` Mir
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Adeegso Arguments::new_v1 halkii aad kaheli laheyd format_args! ("{}", Expr) si aad uyareyso cabirka korkiisa.
    // Qaabka_waxayisticmaalka Dhaqale str ee Display trait in expr qortaa, kaas oo ku baaqay in Formatter::pad, taas waa in meel truncation string iyo kursiga (inkastoo midkoodna waxaa halkan loogu isticmaalayaa).
    //
    // Isticmaalka Arguments::new_v1 waxay u oggolaan kartaa isku-duwaha inuu ka reebo Formatter::pad binary-ka wax soo saarka, isagoo keydinaya ilaa dhowr kilobyte.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // loo baahan yahay si loo qiimeeyo panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // looga baahan yahay codegen loogu talagalay panic marinka OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Hirgelinta aasaasiga ah ee libcore ee `panic!` macro' markii qaabeynta la adeegsanayo.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Fiiro gaar ah Shaqadan waligeed kama talaabin soohdinta FFI;waa wicitaan Rust-to-Rust oo lagu xallinayo howlaha `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // BADBAADADA: `panic_impl` waxaa lagu qeexay nambarka Rust oo amaan ah sidaas awgeedna waa badbaado in la waco.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Hawlaha gudaha ee loogu talagalay `assert_eq!` iyo `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}