//! Soocelinta asynchronous isku dhafan.
//!
//! Haddii futures ay yihiin qiimeyaal asynchronous ah, markaa durdurradu waa isceliyayaal isku mid ah.
//! Haddii aad isku aragtay ururinta asynchronous nooc ka mid ah, oo aad u baahan tahay inaad ku sameyso qalliin astaamaha ururinta la sheegay, waxaad si dhakhso leh ugu ordi doontaa 'streams'.
//! Durdurrada waxaa si xoogan loo isticmaalo bogayna code Rust asynchronous, sidaa daraadeed waxa ee qiimihiisu noqdo yaqaanaan iyaga la.
//!
//! Kahor sharraxaad dheeraad ah, aan ka hadalno sida qaybtani u qaabaysan tahay:
//!
//! # Organization
//!
//! Qaybtani waxay inta badan u habeysan tahay nooca:
//!
//! * [Traits] waa qeybta ugu muhiimsan: traits-kani waxay qeexayaan nooca durdurrada jira iyo waxaad ku qaban karto.Hababka traits kuwanu waa qiimihiisu gelinaya qaar ka mid waqti dheeraad ah waxbarasho galay.
//! * Functions siiyaan qaar ka mid ah siyaabaha waxtar leh in la abuuro qaar ka mid ah durdurrada aasaasiga ah.
//! * Structs badanaa waa noocyada soo noqoshada ee qaababka kala duwan ee kujira modulekaan traits.Badanaa waxaad ubaahantahay inaad fiiriso habka abuura `struct`, halkii aad kaheli laheyd `struct` laftiisa.
//! Wixii faahfaahin dheeraad ah oo ku saabsan sababta, eeg '[Hirgalinta Stream](#hirgelinta-durdur)'.
//!
//! [Traits]: #traits
//!
//! Waa intaas!Let ee ka qodan galay durdurrada.
//!
//! # Stream
//!
//! The qalbi iyo naf bay of module tani waa trait [`Stream`] ah.Xudunta [`Stream`] waxay u egtahay sidan:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Si ka duwan `Iterator`, `Stream` kala duway hab [`poll_next`] taas oo loo isticmaalo marka la fulinayo `Stream` ah, iyo habka (to-be-implemented) `next` a kaas oo la isticmaalo marka wax baabbi'iya durdur.
//!
//! Macaamiisha ee `Stream` oo kaliya u baahan tahay si ay u eegaan `next`, taas oo markii loo yaqaan, soo laabtay future a kaas oo lagu edbiyey u `Option<Stream::Item>`.
//!
//! future ay soo celisay `next` wuxuu dhalin doonaa `Some(Item)` ilaa iyo inta ay jiraan curiyeyaal, isla markaana markay wada daalaan dhammaantood, waxay dhali doonaan `None` si ay u muujiyaan in soocelintu dhammaatay.
//! Haddii aan sugeyno wax aan isku mid ahayn si aan u xallino, future ayaa sugi doona illaa durdurku uu diyaar u yahay inuu mar kale soo baxo.
//!
//! durdurrada Individual dooran kartaa in siyaalaha u bilaabaan, iyo si wacaya `next` mar kale laga yaabaa ama laga yaabaa in aanay mar kale ugu danbeyn dhali `Some(Item)` barta qaar ka mid ah.
//!
//! [`Stream`] 's qeexitaanka buuxa waxaa ka mid ah tiro ka mid ah hababka kale, laakiin waxay yihiin hababka default, dhisay on top of [`poll_next`], iyo si aad u hesho lacag la'aan ah.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Hirgelinta Stream
//!
//! Abuuritaanka durdur ee adiga kuu gaar ah oo ku lug leh laba talaabo: abuuraya `struct` ah si uu u qabto gobolka durdur ee, ka dibna fulinta [`Stream`] for `struct` in.
//!
//! Aynu ka dhigi durdur la odhan jiray `Counter` oo u tiriyo `1` in `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Marka hore, qaabdhismeedka:
//!
//! /// Durdur laga tirinayo hal ilaa shan
//! struct Counter {
//!     count: usize,
//! }
//!
//! // waxaan dooneynaa in tiradeenu ay ka bilaabato mid, haddaba aan ku darno habka new() si aan u caawino.
//! // Tani si adag daruuri uma ahan, laakiin waa ku habboon tahay.
//! // Xusuusnow in aan ka bilaabayno `count` eber, waxaan ku arki doonnaa sababta hirgelinta `poll_next()`'s hoosta.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Kadib, waxaan u hirgelinnaa `Stream` `Counter`-keena:
//!
//! impl Stream for Counter {
//!     // waxaan ku xisaabtameynaa isticmaalka
//!     type Item = usize;
//!
//!     // poll_next() waa habka kaliya ee loo baahan yahay
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Kordhinta tirinteena.Tani waa sababta aan ugu bilownay eber.
//!         self.count += 1;
//!
//!         // Hubi si aad u aragto haddii aan dhahnaa tirinta dhammeeyayna ama ma.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Durdurradu waa *caajis*.Tani waxay ka dhigan tahay kaliya abuurista durdurku ma ahan _do_ wax badan.Runtii waxba ma dhacaan ilaa aad ka wacdo `next`.
//! Tani marmarka qaarkood waa isha jahwareerka marka la abuurayo durdur kaliya waxyeelooyinkiisa.
//! Isku-dubaridaha ayaa nooga digi doona hab-dhaqanka noocan ah:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;