use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// interface An ee wax looga qabanayo iterators asynchronous.
///
/// Tani waa durdurka ugu weyn ee trait.
/// Wixii intaa ka badan oo ku saabsan fikradda durdurrada guud ahaan, fadlan eeg [module-level documentation].
/// Gaar ahaan, waxaa laga yaabaa inaad rabto inaad ogaato sida loo sameeyo [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Nooca walxaha ay ka dhaleen durdurka.
    type Item;

    /// Isku day inaad la baxdo qiimaha soo socda ee durdurkan, adoo diiwaangelinaya hawsha hadda socota ee soo kicinta haddii qiimaha aan weli la helin, iyo soo celinta `None` haddii durdurku dhammaado.
    ///
    /// # Soo celinta qiimaha
    ///
    /// Waxaa jira dhowr qiimeyn suurtagal oo soo noqosho ah, mid walbana wuxuu muujinayaa xaalad durdur gaar ah:
    ///
    /// - `Poll::Pending` waxay ka dhigan tahay in durdurka qiimihiisa xiga uusan wali diyaar ahayn.Fulintii waxay xaqiijin doontaa in hawsha hadda lagu wargelin doonaa marka qiimaha soo socda diyaar laga yaabaa.
    ///
    /// - `Poll::Ready(Some(val))` hab in webigu ayaa si guul leh u soo saaray qiimaha a, `val`, waxayna soo saari karaan qiimaha dheeraad ah oo ku baaqay in xiga `poll_next`.
    ///
    /// - `Poll::Ready(None)` hab in webigu uu joojiyo, iyo `poll_next` ma aha in mar kale gawraco.
    ///
    /// # Panics
    ///
    /// Mar haddii durdurku dhammaado (soo celiyey `Ready(None)` from `poll_next`), isagoo wacaya habkiisa `poll_next` markale wuxuu panic, xannibayaa weligiis, ama sababi karaa noocyo kale oo dhibaatooyin ah; `Stream` trait wax shuruud ah kuma xidho saamaynta wicitaankan oo kale.
    ///
    /// Si kastaba ha ahaatee, sida habka `poll_next` aan la calaamadeeyay `unsafe`, sharciyada caadiga ah Rust ayaa codsan: wicitaanada waa in aan marnaba keeni dhaqanka undefined (musuqmaasuqa xasuusta, isticmaalka khaldan ee hawlaha `unsafe`, ama u eg), iyadoo aan loo eegin gobolka durdur ee.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Sooceliyaa soohdin ku saabsan dhererka ka haray webigu.
    ///
    /// Gaar ahaan, `size_hint()` laabtay tuple halkaas oo element ugu horeysay ee waa hoose ku xidhay, oo element labaad waa sare ku xidhay.
    ///
    /// Qeybtii labaad ee tuubada la soo celiyey waa [``Xulasho ']' '<`[' usize ']'>>.
    /// [`None`] halkan waxay ka dhigan tahay in ama uusan jirin xad sare oo la yaqaan, ama xadka kore uu ka weyn yahay [`usize`].
    ///
    /// # Qoraalada hirgelinta
    ///
    /// Lama fulin karo in hir durdurku uu dhaliyo tirada la sheegay ee canaasiirta.durdur buggy A soo baxaan wax ka yar hoose ku xidhay ama ka badan sare ku xidhay xubno.
    ///
    /// `size_hint()` ugu horayn waxa loogu tala galay in loo isticmaalo optimizations sida kaydin meel waxyaalaha aasaaska ah ee durdurka, laakiin waa in aan la aamini in tusaale, jeegag soohdin ogolow in code ammaanka ahayn.
    /// fulinta qaldan ee `size_hint()` waa noqonin mid horseeda in xadgudubyada ammaanka xasuusta.
    ///
    /// Taas oo uu sheegay, fulinta waa in ay bixiyaan qiimaysay sax ah, maxaa yeelay, haddii kale waxa uu noqon lahaa xadgudub ku ah hab maamuuska trait ee.
    ///
    /// The celinta fulinta default `(0,` [`None`]`) taasoo micneheedu yahay mid sax u il kasta.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}