#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Waxaa ku jira qeexitaan struct waayo, khariidad ee compiler dhisay-in noocyada.
//!
//! Waxaa loo isticmaali karaa bartilmaameedyada transmutes-ka ee koodhka amniga ah si toos ah loogu maareeyo matalaadda cayriin.
//!
//!
//! Qeexitaankoodu waa inuu had iyo jeer la mid ahaadaa ABI lagu qeexay `rustc_middle::ty::layout`.
//!

/// Matalaada sheyga trait sida `&dyn SomeTrait`.
///
/// Qaab dhismeedkani wuxuu leeyahay qaab isku mid ah noocyada sida `&dyn SomeTrait` iyo `Box<dyn AnotherTrait>`.
///
/// `TraitObject` waa la damaanad qaadayaa inuu la jaan qaadayo qaababka, laakiin maahan nooca walxaha trait (tusaale, meelaha si toos ah looma heli karo `&dyn SomeTrait`) mana maamusho qaabkaas (bedelida qeexitaanka ma beddeli doonto qaabka `&dyn SomeTrait`).
///
/// Waxaa kaliya loogu talagalay in loo isticmaalo koodh aan badbaado lahayn oo u baahan in lagu maareeyo faahfaahinta heerka hoose.
///
/// Ma jirto waddo loo gudbiyo dhammaan walxaha trait si jumlad ah, markaa sida kaliya ee loo abuuro qiyamka noocan ah waxay la mid tahay shaqooyinka sida [`std::mem::transmute`][transmute].
/// Sidoo kale, sida kaliya ee ay u abuuraan a trait wax run ka qiimo `TraitObject` waa la `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Ku-shaandheynta shay trait noocyo aan khaldaneyn-oo ah halka vtable-ku uusan u dhigmin nooca qiimaha ay tilmaamtu tilmaamayso-ay aad ugu dhowdahay inay u horseedo dabeecad aan la qeexin.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // tusaale trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // u soo diyaariyuhu inuu sameeyo shay trait ah
/// let object: &dyn Foo = &value;
///
/// // fiiri matalaadda ceyriinka ah
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // tilmaamaha xogta waa cinwaanka `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // Samee shay cusub, oo tilmaamaya `i32` ka duwan, ka taxaddar inaad isticmaasho qalabka `i32` vtable' ee ka socda `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // waa inay u shaqeysaa sidii oo kale inaan si toos ah uga dhisnay shey trait ah oo ka baxsan `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}