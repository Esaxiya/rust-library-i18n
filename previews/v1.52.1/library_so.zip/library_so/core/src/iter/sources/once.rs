use crate::iter::{FusedIterator, TrustedLen};

/// Waxay abuurtaa soo noqnoqosho soo saarta cunsur sida saxda ah hal mar.
///
/// Tan caadi ahaan loo isticmaalaa in lagu qabsado hal qiimaha ah oo wuxuu galay [`chain()`] ka mid ah noocyada kale ee siyaalaha.
/// Waxaa laga yaabaa in aad leedahay iterator in daboolida dhow wax walba, laakiin waxaad u baahan tahay kiiska dheeraad ah oo gaar ah.
/// Waxaa laga yaabaa inaad haysato shaqeyn ka shaqeysa kuwa soo saara, laakiin waxaad u baahan tahay oo keliya inaad qiimeyso hal qiime.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::iter;
///
/// // mid waa tirada ay gacal wadaag
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // mid kaliya, intaas ayaynu helaynaa
/// assert_eq!(None, one.next());
/// ```
///
/// wada Chaining la iterator kale.
/// Aan niraahno waxaan dooneynaa inaan iterate badan file kasta oo buugga `.foo` ah, laakiin sidoo kale file qaabeynta ah,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // waxaan u baahan nahay si loogu badalo ka iterator ah DirEntry-s in iterator ah PathBufs, sidaas darteed waxaan u isticmaali map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // hadda, kaaliyahayagu wuxuu kaliya u yahay faylka kaydinta
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // ku xidho labada istcimaaleeye hal jibbaare weyn
/// let files = dirs.chain(config);
///
/// // na siin doonaa dhammaan faylasha ee .foo iyo sidoo kale .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// iterator An in edbiyey element ah si sax ah mar.
///
/// `struct`-kan waxaa abuuray [`once()`] function.Eeg dukumiintiyadeeda wixii intaa ka badan.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}