use crate::iter::{FusedIterator, TrustedLen};

/// Waxay abuurtaa soo-celin cusub oo aan dhammaad lahayn ku soo celisa hal cunsur.
///
/// Shaqada `repeat()` waxay ku celcelisaa hal qiime marar badan.
///
/// Feejignaanta aan dhammaadka lahayn sida `repeat()` waxaa badanaa loo adeegsadaa adapters sida [`Iterator::take()`], si looga dhigo kuwo xaddidan.
///
/// Haddii nooca element of iterator aad u baahan tahay aanay fulin `Clone`, ama haddii aadan rabin in ay sii element ka soo noqnoqda ee xasuusta, waxaad isticmaali kartaa halkii shaqo [`repeat_with()`] ah.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::iter;
///
/// // tirada afaraad 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, weli afar
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Dhamaadka [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // tusaalihii ugu dambeeyay wuxuu ahaa afar aad u tiro badan.Aynu haysanno afar afar uun.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... hadana waan dhameynay
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Falanqeeye soo noqnoqda cunsur aan dhammaad lahayn.
///
/// `struct`-kan waxaa abuuray [`repeat()`] function.Eeg dukumiintiyadeeda wixii intaa ka badan.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}