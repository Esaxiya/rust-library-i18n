use crate::{fmt, iter::FusedIterator};

/// Abuuraa iterator cusub halkaas oo shay kasta oo isku xigta waxa lagu xisaabiyaa ku salaysan mid ka mid ah la soo dhaafay.
///
/// iterator wuxuu ku bilaabmayaa shayga siiyey hore (haddii ay jirto) iyo ku baaqay in la xiro siiyey `FnMut(&T) -> Option<T>` xisaabinta bedelka item kasta.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Haddii shaqo this laabtay `impl Iterator<Item=T>` waxaa lagu salayn karo `unfold` oo ma u baahan tahay nooc ka mid ah dadaalka badan.
    //
    // Si kastaba ha ahaatee isagoo la odhan jiray nooca `Successors<T, F>` uu ogolaanayaa in ay noqon `Clone` markii `T` iyo `F` yihiin.
    Successors { next: first, succ }
}

/// Tilmaame-yahan cusub oo shey kasta oo is xigxiga lagu xisaabiyo iyadoo lagu saleynayo kii hore.
///
/// `struct`-kan waxaa abuuray [`iter::successors()`] function.
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}