use crate::fmt;

/// Abuuraa iterator cusub siyaalaha kasta oo ku baaqay in la xiro `F: FnMut() -> Option<T>` la siiyo.
///
/// Tani waxay u oggolaaneysaa abuuritaanka sheeko-yaqaan caadil ah oo leh dabeecad kasta iyada oo aan la isticmaalin ereyada ereyada badan ee abuurista nooc gaar ah iyo hirgelinta [`Iterator`] trait.
///
/// Ogow in `FromFn` ku iterator ma dhigi fikrado ku saabsan dhaqanka xiritaanka, oo sidaas daraaddeed kabsado aanay fulin [`FusedIterator`], ama ka default `(0, None)` tirtirto [`Iterator::size_hint()`].
///
///
/// Xidhitaanka isticmaali kartaa qabsaday oo ay deegaanka si ay ula socdaan gobolka guud ahaan iterations.Iyada oo ku xidhan sida iterator la isticmaalo, taasi waxay u baahan yihiin waxaa laga yaabaa in la tilmaamayo keyword [`move`] ku saabsan xiritaanka.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Aynu dib-u-dhaqan-galino soo-celinta miisaanka ka soo baxa [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Kordhinta tirinteena.Tani waa sababta aan ugu bilownay eber.
///     count += 1;
///
///     // Hubi si aad u aragto haddii aan dhahnaa tirinta dhammeeyayna ama ma.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Falanqeeye halka soocelin kastaa ugu yeerto xiritaanka la bixiyay ee `F: FnMut() -> Option<T>`.
///
/// `struct`-kan waxaa abuuray [`iter::from_fn()`] function.
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}