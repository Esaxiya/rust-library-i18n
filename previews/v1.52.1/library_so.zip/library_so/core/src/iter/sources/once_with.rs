use crate::iter::{FusedIterator, TrustedLen};

/// Abuuraa iterator in wahsan abuuraa qiimaha saxda ah mar by lagu koofaaro xiritaanka bixiyo.
///
/// Tan caadi ahaan loo isticmaalaa in lagu qabsado hal matoor qiimaha galay [`chain()`] ka mid ah noocyada kale ee siyaalaha ah.
/// Waxaa laga yaabaa in aad leedahay iterator in daboolida dhow wax walba, laakiin waxaad u baahan tahay kiiska dheeraad ah oo gaar ah.
/// Waxaa laga yaabaa inaad haysato shaqeyn ka shaqeysa kuwa soo saara, laakiin waxaad u baahan tahay oo keliya inaad qiimeyso hal qiime.
///
/// Si ka duwan [`once()`], shaqadani waxay si caajis ah u soo saari doontaa qiimaha la codsado.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::iter;
///
/// // mid waa tirada ay gacal wadaag
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // mid kaliya, intaas ayaynu helaynaa
/// assert_eq!(None, one.next());
/// ```
///
/// wada Chaining la iterator kale.
/// Aan niraahno waxaan dooneynaa inaan iterate badan file kasta oo buugga `.foo` ah, laakiin sidoo kale file qaabeynta ah,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // waxaan u baahan nahay si loogu badalo ka iterator ah DirEntry-s in iterator ah PathBufs, sidaas darteed waxaan u isticmaali map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // hadda, kaaliyahayagu wuxuu kaliya u yahay faylka kaydinta
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ku xidho labada istcimaaleeye hal jibbaare weyn
/// let files = dirs.chain(config);
///
/// // na siin doonaa dhammaan faylasha ee .foo iyo sidoo kale .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Falanqeeye soo saara hal shay oo nooca `A` ah iyadoo la adeegsanayo xiritaanka la bixiyay ee `F: FnOnce() -> A`.
///
///
/// `struct` Tan waxaa loo abuuray by function [`once_with()`] ah.
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}