/// iterator An in had iyo jeer sii wadaan in ay dhali `None` markii daalan.
///
/// Wicitaanka soosocda ee soo-celinta isku-darka ah ee soo celisay `None` hal mar ayaa damaanad ah inuu soo celiyo [`None`] markale.
/// trait Tani waa in la fuliyo dhammaan iterators in u dhaqmaan hab sababtoo ah waxay u saamaxdaa fiican [`Iterator::fuse()`].
///
///
/// Note: Guud ahaan, waa in aad uma isticmaali `FusedIterator` in soohdin generic haddii aad u baahan tahay a iterator dhisnayd.
/// Halkii, waa in aad kaliya wac [`Iterator::fuse()`] on iterator ah.
/// Haddii soo-saaraha mar hore la isku duubay, duubista dheeriga ah ee [`Fuse`] waxay noqon doontaa maya-la'aan oo aan lahayn ciqaab waxqabad.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Falanqeeye ka warbixinaya dherer sax ah isagoo isticmaalaya cabbirka cabbirka.
///
/// iterator ayaa ku warameysa oggayn size halkaas oo ay sidoo kale waa sax (qeybta hoose ee ku xidhan tahay waa loo siman yahay si sare ku xidhnaan), ama sare ku xidhay waa [`None`].
///
/// The waa xidhxidhan sare oo kaliya [`None`] haddii dhererkiisu wuxuu iterator dhabta ah waa ka badan [`usize::MAX`].
/// Xaaladdaas, xadka hoose waa inuu ahaadaa [`usize::MAX`], taasoo keentay [`Iterator::size_hint()`] ee `(usize::MAX, None)`.
///
/// Tilmaamuhu waa inuu si sax ah u soo saaraa tirada walxaha uu soo sheegay ama uu kala leexiyay ka hor inta uusan gaarin dhamaadka.
///
/// # Safety
///
/// trait-kan waa in la dhaqan galiyaa oo keliya marka heshiiska la ilaaliyo.
/// Macaamiisha trait waa inay baaraan [`Iterator::size_hint()`]’s xadkiisa sare.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// iterator An in marka dhalaya item ah ayaa la qaadi doonaa ugu yaraan hal element ka salka [`SourceIter`].
///
/// U yeerida qaab kasta oo hormarinaya soo-saaraha, tusaale
/// [`next()`] ama [`try_fold()`], dammaanadaha in tallaabo kasta ugu yaraan hal qiimaha of il dahsoon iterator ah ayaa ka guuray iyo natiijada silsilad iterator ah la galin laga yaabaa in ay meel, haddii loo maleeyo in caqabado dhismaha ah isha ugu ogolaan galinta noocaas ah.
///
/// In si kale loo dhigo trait this muujinaysaa in dhuumaha iterator ah waxaa laga qaadan karaa meel.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}