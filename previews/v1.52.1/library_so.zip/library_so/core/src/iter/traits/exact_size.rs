/// Sooceliyaha garanaya dhererkiisa saxda ah.
///
/// Qaar badan oo ka [`Iterator`] s Ma aqaan inta jeer ee ay iterate doono, laakiin qaar ka mid ah sameeyo.
/// Haddii iterator ah ogyahay inta jeer waxaa iterate karaa, ee fidisa helitaanka macluumaadka in ay noqon kartaa mid waxtar leh.
/// Tusaale ahaan, haddii aad rabto in iterate gadaal, bilow wanaagsan waa in la ogaado meesha dhamaadka yahay.
///
/// Marka fulinta `ExactSizeIterator` ah, waa in aad sidoo kale fuliyaan [`Iterator`].
/// Marka sidaas samaynaya, hirgelinta [`Iterator::size_hint`]*waa* xajmiga saxda ah ee iterator soo noqdo.
///
/// Habka [`len`] waxay leedahay fulinta default ah, si aad sida caadiga ah waa in aan u fuliyo.
/// Si kastaba ha ahaatee, waxaad awoodi kartaa inaad si ay u siiyaan fulinta a more performant badan default ah, sidaas darteed waxaa khaas ah haddii ay taasi macno.
///
///
/// Ogow in trait tani waa ammaan trait ah iyo sida oo kale sameeyaa miyuu *aan* iyo * * Ma yeeli karno taas damaanad in dhererkiisu wuxuu ku soo laabtay sax yahay.
/// Tani waxay ka dhigan tahay in code `unsafe`**waa in aan** ku tiirsan yihiin saxnimada [`Iterator::size_hint`].
/// The deganayn iyo ammaan ahayn [`TrustedLen`](super::marker::TrustedLen) trait siinayaa this damaanad dheeraad ah.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// // kala duwan uguna ogyahay sida saxda ah inta jeer ee u iterate doonaa
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs], waxaan ka hirgelinay [`Iterator`], `Counter`.
/// Aynu u hirgelinno `ExactSizeIterator` sidoo kale:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Waxaan si fudud u xisaabin karnaa tirada harsan ee soo noqnoqoshada.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Oo hadda waan isticmaali karnaa!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Soocelisaa dhererka saxda ah ee soo-celinta.
    ///
    /// Hirgelinta waxay xaqiijineysaa in soo-celiyaha uu si sax ah u soo laaban doono `len()` marar badan oo ah qiimaha [`Some(T)`], ka hor inta uusan soo laaban [`None`].
    ///
    /// Habkani waxa uu leeyahay hirgelinta default ah, si aad sida caadiga ah waa in si toos ah ma fuliyo.
    /// Si kastaba ha ahaatee, haddii aad ku siin kara fulinta a ku ool ah, oo aad sidaas u samayn karaa.
    /// Tusaale ahaan ka eeg dukumentiyada [trait-level].
    ///
    /// shaqo waxa uu leeyahay in nidaamkan ammaanka la mid ah sida shaqo [`Iterator::size_hint`] ah.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// // kala duwan uguna ogyahay sida saxda ah inta jeer ee u iterate doonaa
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Sheegashadani waa mid si xad dhaaf ah u difaac ah, laakiin waxay hubineysaa isbeddel la'aanta
        // damaanad qaaday trait.
        // Haddii trait this ahaayeen rust-gudaha, waxaan isticmaali kartaa debug_assert !;sheeg_eq!wuxuu hubin doonaa dhammaan hirgelinta isticmaalaha Rust sidoo kale.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Dib `true` haddii iterator waa madhan.
    ///
    /// Habkani wuxuu leeyahay dhaqan gelin asaasi ah adoo adeegsanaya [`ExactSizeIterator::len()`], markaa uma baahnid inaad adigu fuliso.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}