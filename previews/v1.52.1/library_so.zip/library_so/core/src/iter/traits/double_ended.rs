use crate::ops::{ControlFlow, Try};

/// iterator An awoodaan in ay xubno ka dhalidda ka shishaysa.
///
/// Wax qalab `DoubleEndedIterator` uu leeyahay mid ka mid awood dheeraad ah in ka badan wax qalab [`Iterator`]: awood u leh inay sidoo kale qaadan `Item`s oo Gadaal ka, iyo sidoo kale hore.
///
///
/// Waxaa muhiim ah in la ogaado in dib iyo shaqada soo kala duwan la mid ah, oo aad u yeeli weydaan cross: siyaalaha waa ka badan marka ay ku kulmaan dhexe.
///
/// In fashion la mid ah hab maamuuska [`Iterator`] ah, mar `DoubleEndedIterator` a [`None`] ka [`next_back()`] a soo laabtay, waxa uu mar kale ugu yeeray ama aan mar dambe soo noqon karaan laga yaabaa [`Some`].
/// [`next()`] iyo [`next_back()`] waa la is weydaarsan karaa ujeedkan.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Saaraysaa iyo celinta element ka dhamaadka iterator ah.
    ///
    /// Sooceliyaa `None` marka aysan jirin walxo kale.
    ///
    /// Waraaqaha [trait-level] waxaa ku jira faahfaahin dheeraad ah.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Walxaha loo koreen by `hababka DoubleEndedIterator` ee kala duwan waxaa laga yaabaa in laga kuwa by [`Iterator`] 's hababka koreen:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Horumarka iterator ka dib ah by xubno `n`.
    ///
    /// `advance_back_by` waa version dambe ee [`advance_by`].Habkani hammuun boodi doonaa xubno `n` laga bilaabo dhabarka adigoo wacaya ilaa [`next_back`] in goor `n` ilaa [`None`] waxaa la kulmeen.
    ///
    /// `advance_back_by(n)` wuu soo celin doonaa [`Ok(())`] haddii soo-saaraha uu si guul leh ugu horumaro qaybaha `n`, ama [`Err(k)`] haddii [`None`] lala kulmo, halkaasoo `k` ay tahay tirada cunsurrada uu soo-saaraha horay u sii mariyay ka hor inta uusan walxaha dhammeyn (ie,
    /// dhererka jaangooyaha).
    /// Xusuusnow in `k` uu had iyo jeer ka yar yahay `n`.
    ///
    /// Wicitaanka `advance_back_by(0)` ma baabbi'in xubno kasta oo had iyo jeer soo laabtay [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // kaliya `&3` ayaa laga booday
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Celinta ku yidhi element n`th ka dhamaadka iterator ah.
    ///
    /// Tani asal ahaan waa nooca la rogay ee [`Iterator::nth()`].
    /// In kasta oo sida hawlgallada tilmaamtu badan yihiin, haddana tirintu waxay ka bilaabantaa eber, sidaa darteed `nth_back(0)` wuxuu ka soo celiyaa qiimaha koowaad dhammaadka, `nth_back(1)` labaad, iyo wixii la mid ah.
    ///
    ///
    /// Ogow in dhammaan waxyaabaha ka dhexeeya dhamaadka iyo element ku soo laabtay waa la wada baabbi'in doonaa, oo ay ku jiraan waxyaabaha soo noqday.
    /// sidoo kale Taas macnaheedu waa in wacaya `nth_back(0)` marar badan ku iterator isku soo laaban doona qaybaha kala duwan.
    ///
    /// `nth_back()` soo laaban doonaa [`None`] haddii `n` waa ka weyn yahay ama la mid ah dhererka iterator ah.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Wicitaanka marar badan `nth_back()` uusan dib u socon iterator ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Noqoshada `None` haddii ay jiraan wax ka yar xubno `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Tani waa version dambe ee [`Iterator::try_fold()`]: waxa ay qaadataa xubno bilaabo dambe ee iterator ah.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Sababta oo ah waxa gaaban-circuited, waxyaalaha haray weli waxaa laga heli karaa iyada oo loo marayo iterator ah.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Habka sooceliyaha oo yareynaya cunsurrada waxyaabaha ka kooban hal, qiime ugu dambeeya, oo ka bilaabanaya dhabarka.
    ///
    /// Tani waa version dambe ee [`Iterator::fold()`]: waxa ay qaadataa xubno bilaabo dambe ee iterator ah.
    ///
    /// `rfold()` waxay qaadataa laba doodood: qiime bilow ah, iyo xidhitaan leh laba doodood: 'accumulator', iyo cunsur.
    /// Xidhitaanka laabtay qiimaha in accumulator waxay leeyihiin waa in siyaalaha soo socda.
    ///
    /// Qiimaha bilowga ahi waa qiimaha shirkaddu ku yeelanayso wicitaanka ugu horreeya.
    ///
    /// Kadib markaad codsato xiritaankan qayb kasta oo ka mid ah soo-saaraha, `rfold()` wuxuu soo celiyaa isku-darka.
    ///
    /// Hawlgalkan waxaa mararka qaarkood loo yaqaan 'reduce' ama 'inject'.
    ///
    /// Isku laabiddu waxtar ayey leedahay markasta oo aad wax uruuriso, oo aad rabto inaad ka soo saarto hal qiime oo keliya.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // wadarta dhamaan astaamaha a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Tusaale ahaan Tani waxay dhistaa xarig ah, laga bilaabo qiimaha bilowga iyo sii element kasta ka dib ilaa hore:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Baadhitaanno ku saabsan shey soo noqnoqoshada dhabarka oo qancisa saadaal.
    ///
    /// `rfind()` qaadataa xiritaanka in laabtay `true` ama `false`.
    /// Waxay khuseysaa xiritaankan qayb kasta oo ka mid ah soo-celinta, laga bilaabo dhammaadka, iyo haddii midkoodna soo celiyo `true`, markaa `rfind()` wuxuu soo celiyaa [`Some(element)`].
    /// Hadday dhammaantood soo noqdaan `false`, waxay soo celisaa [`None`].
    ///
    /// `rfind()` waa-circuiting gaaban;in si kale loo dhigo, waxaa la joojin doonaa ka baaraandegidda sida ugu dhakhsaha badan xiritaanka laabtay `true`.
    ///
    /// Maxaa yeelay, `rfind()` qaadataa tixraac, iyo iterators badan iterate badan la tixraaci karo, raadad si ay xaaladda a suurto gal wareeriya halkaas oo muran uu yahay tixraac double.
    ///
    /// Waxaad ka arki kartaa saamayn this ee tusaalooyinka hoos ku qoran, la `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Joojinta ugu horeysa `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // wali waan isticmaali karnaa `iter`, maadaama ay jiraan waxyaabo badan.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}