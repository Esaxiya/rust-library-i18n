/// U beddelashada [`Iterator`]
///
/// By fulinta `FromIterator` nooca ah, aad u qeexaan sida ay u la abuuri doono ka iterator ah.
/// Tani waxay caan ku tahay noocyada sharraxaya nooc nooc ka mid ah.
///
/// [`FromIterator::from_iter()`] waa dhif si cad u yeedhay, oo waa halkii loo isticmaalo iyada oo loo marayo hab [`Iterator::collect()`].
///
/// Ka eeg dukumintiyada [`Iterator::collect()`]'s tusaalooyin dheeri ah.
///
/// Sidoo kale eeg: [`IntoIterator`].
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Isticmaalka [`Iterator::collect()`] si dadban u isticmaali `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Hirgelinta `FromIterator` noocaaga:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Ururinta muunad, taasi waa uun duub ka badan Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Aan ku siin hababka qaar ka mid ah si aan u abuuri karaan mid ka mid ah iyo in ay dar wax.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // waana fulin doonaa FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Hadda waxaan sameyn karnaa sheeko-yaqaan cusub ...
/// let iter = (0..5).into_iter();
///
/// // ... oo ka samee MyCollection-ka
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // ururiyaan shaqooyinka sidoo kale!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Waxay ka abuurtaa qiime ku-tiriye.
    ///
    /// Ka eeg [module-level documentation] wixii intaa ka badan.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// U beddelashada [`Iterator`].
///
/// By fulinta `IntoIterator` nooca ah, aad u qeexaan sida ay u soo noqon doonaan si ay u iterator ah.
/// Tani waxay caan ku tahay noocyada sharraxaya nooc nooc ka mid ah.
///
/// Faa'iidada mid ka mid ah hirgelinta `IntoIterator` ayaa ah in noocaagu uu noqon doono [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Sidoo kale eeg: [`FromIterator`].
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Hirgelinta `IntoIterator` noocaaga:
///
/// ```
/// // Ururinta muunad, taasi waa uun duub ka badan Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Aan ku siin hababka qaar ka mid ah si aan u abuuri karaan mid ka mid ah iyo in ay dar wax.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // waana fulin doonaa IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Hadda waxaan sameyn karnaa ururinta cusub ...
/// let mut c = MyCollection::new();
///
/// // ... walax ku dar ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ka dibna u rogo Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Waxaa caadi ah in la isticmaalo `IntoIterator` sida trait bound ah.Tani waxay u ogolaaneysaa nooca ururinta aqbasho in isbedel, inta weli waa iterator ah.
/// Soohdin dheeri ah ayaa lagu qeexi karaa iyadoo la xadidayo
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Nooca waxyaabaha lagu celiyay in ka badan.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Noocee noocee ah ayaan tan u beddeleynaa?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Abuuraa iterator ka qiimo.
    ///
    /// Ka eeg [module-level documentation] wixii intaa ka badan.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Kordhi aruurinta waxyaabaha ku jira soo-koobiyeha.
///
/// Iterators soo saaro taxane ah oo qiyamka, iyo ururinta ayaa sidoo kale la kara in ay yihiin taxane ah oo qiyamka.
/// `Extend` trait The buundada farqiga this, oggolaanayo in aad kordhiso ururinta a by ay ka mid yihiin waxyaabaha iterator in.
/// Marka kordhin ururinta a furaha hore u jiray, entry la updated ama, in ay dhacdo uruuriyaa in la oggalaado entries badan la furayaasha loo siman yahay, in gelitaanka la geliyo.
///
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// // Waxaad ku dheereyn kartaa xarig xargaha qaar:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Hirgalinta `Extend`:
///
/// ```
/// // Ururinta muunad, taasi waa uun duub ka badan Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Aan ku siin hababka qaar ka mid ah si aan u abuuri karaan mid ka mid ah iyo in ay dar wax.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // tan iyo MyCollection ayaa liiska i32s, waxaan fuliyo kordhisayna for i32
/// impl Extend<i32> for MyCollection {
///
///     // Tani waa yara fudud ula saxiixa nooca la taaban karo, oo waxaan wici kartaa kordhiyo wax taas oo galay Iterator ah oo ina siinayo i32s beddelmi karin.
///     // Maxaa yeelay, waxaan u baahan nahay in i32s rido MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Hirgelinta waa mid aad u sahlan: loop dhex iterator ah, iyo add() element kasta nafteena.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // aan ku sii dheereyno ururintayada seddex lambar oo dheeri ah
/// c.extend(vec![1, 2, 3]);
///
/// // Waxaan ku darnay walxahan dhamaadka
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Kordhiyay ururinta leh ka kooban iterator ah.
    ///
    /// Sida ay tani tahay habka kaliya ee loo baahan yahay trait this, ee DoCS [trait-level] ku jira faahfaahin dheeraad ah.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// // Waxaad ku dheereyn kartaa xarig xargaha qaar:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Kordhinaya ururinta leh hal cunsur.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Waxay keyd ugu jirtaa ururinta tirada la siiyay ee walxaha dheeriga ah.
    ///
    /// Hirgelinta asalka ahi waxba ma qabto.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}