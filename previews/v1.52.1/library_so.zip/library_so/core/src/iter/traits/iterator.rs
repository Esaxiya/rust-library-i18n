// iska indha-nidaamsan-filelength file Tani ida ka kooban tahay qeexidda `Iterator`.
// Uma kala qaybin karno taas faylal badan.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// interface An ee wax looga qabanayo iterators.
///
/// Kani waa soo-celinta ugu weyn ee trait.
/// Faahfaahin dheeraad ah oo ku saabsan fikradda guud ee guud ahaan, fadlan eeg [module-level documentation].
/// Gaar ahaan, waxaa laga yaabaa inaad rabto inaad ogaato sida loo sameeyo [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Nooca waxyaabaha lagu celiyay in ka badan.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Waxay horumarisaa soo-saaraha waxayna soo celisaa qiimaha xiga.
    ///
    /// Sooceliyaa [`None`] markii siyaalaha la dhammeeyo.
    /// Hirgelinta shaqsiyeed ee shaqsiyeed wuxuu dooran karaa inuu dib u bilaabo soo noqnoqoshada, sidaas darteed soo wicitaanka `next()` mar labaad ayaa laga yaabaa ama laga yaabaa inuusan ugu dambeyn bilaabin soo celinta [`Some(Item)`] mar uun.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Wicitaan loogu talagalay next() wuxuu soo celiyaa qiimaha xiga ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ka dibna Midkoodna marna ma dhamma.
    /// assert_eq!(None, iter.next());
    ///
    /// // Wicitaano badan ayaa soo celin kara ama soo celin kara `None`.Halkan, waxay had iyo jeer doonaan.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Sooceliyaa soohdin ku saabsan dhererka ka haray iterator ah.
    ///
    /// Gaar ahaan, `size_hint()` laabtay tuple halkaas oo element ugu horeysay ee waa hoose ku xidhay, oo element labaad waa sare ku xidhay.
    ///
    /// Qeybtii labaad ee tuubada la soo celiyey waa [``Xulasho ']' '<`[' usize ']'>>.
    /// [`None`] halkan waxay ka dhigan tahay in ama uusan jirin xad sare oo la yaqaan, ama xadka kore uu ka weyn yahay [`usize`].
    ///
    /// # Qoraalada hirgelinta
    ///
    /// Lama fulin karo in hirgelinteedu ay soo saarto tirooyinka la shaaciyey.Qalab-wade bug ayaa soo saari kara wax ka yar xadka hoose ama ka badan xadka sare ee canaasiirta.
    ///
    /// `size_hint()` waxaa ugu horeyn loogu talagay in loo isticmaalo kafiicinta sida keydinta boosaska cunsuriyada, laakiin waa inaan lagu kalsoonaan karin tusaale ahaan, iska dhaaf jeegaga xadidan ee koodhka aan amaanka lahayn.
    /// fulinta qaldan ee `size_hint()` waa noqonin mid horseeda in xadgudubyada ammaanka xasuusta.
    ///
    /// Taas oo uu sheegay, fulinta waa in ay bixiyaan qiimaysay sax ah, maxaa yeelay, haddii kale waxa uu noqon lahaa xadgudub ku ah hab maamuuska trait ee.
    ///
    /// The celinta fulinta default `(0,` [`None`]`) taasoo micneheedu yahay mid sax u iterator kasta.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Tusaale aad u adag:
    ///
    /// ```
    /// // Xitaa lambarrada eber ilaa toban.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Waxaa laga yaabaa inaan ka dhexbixino eber ilaa toban jeer.
    /// // Ogaanshaha in ee shan dhab ahaan ma noqon doono suurto gal ah oo aan fulinta filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Aan ku darno shan lambar oo dheeri ah chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // hadda labada soohdin waa sii korodhay by shan
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Ku noqoshada `None` xarka kore:
    ///
    /// ```
    /// // soo-koobiye aan dhammaad lahayn ma laha xadka sare iyo xadka ugu hooseeya ee ugu macquulsan
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Gubtay iterator ah, tirinta tirada iterations oo u soo laabtay.
    ///
    /// Habkani soo wici doonaa [`next`] si joogta ah ilaa [`None`] waxaa la kulmeen, soo laabtay tirada jeer arkeen [`Some`].
    /// Xusuusnow in [`next`] ay tahay in loogu yeero ugu yaraan hal jeer xitaa haddii qalabka wax soo saara uusan lahayn astaamo.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Akhlaaq Buuxsan
    ///
    /// Qaabku ma ilaalinayo daadad xad dhaaf ah, markaa tirinta walxaha aaladda soo-celinta oo leh in ka badan walxaha [`usize::MAX`] ama waxay soo saartaa natiijo qaldan ama panics.
    ///
    /// Haddii si waafi ah Debug yihiin karti, panic ah waa la damaanad qaaday.
    ///
    /// # Panics
    ///
    /// xooggiisii function Tani panic haddii iterator ku leedahay in ka badan xubno [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Gubtay iterator ah, soo laabtay element ee la soo dhaafay.
    ///
    /// Habkani qiimeyn doonaa iterator ilaa uu soo laabtay [`None`].
    /// Iyadoo sidaas la sameynayo, waxay la socotaa curiyaha hadda jira.
    /// Ka dib markii [`None`] la soo celiyo, `last()` dabadeedna soo noqda doonaa element ee la soo dhaafay waxa ay arkeen.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Wuxuu horumariyaa tifaftiraha astaamaha `n`.
    ///
    /// Habkani hammuun boodi doonaa xubno `n` wacaya ilaa [`next`] in goor `n` ilaa [`None`] waxaa la kulmeen.
    ///
    /// `advance_by(n)` wuu soo celin doonaa [`Ok(())`][Ok] haddii soo-saaraha uu si guul leh ugu horumaro qaybaha `n`, ama [`Err(k)`][Err] haddii [`None`] lala kulmo, halkaasoo `k` ay tahay tirada cunsurrada uu soo-saaraha hore u sii mariyay ka hor inta uusan cunsurradu dhammaan (ie.
    /// dhererka jaangooyaha).
    /// Xusuusnow in `k` uu had iyo jeer ka yar yahay `n`.
    ///
    /// Wicitaanka `advance_by(0)` ma baabbi'in xubno kasta oo had iyo jeer soo laabtay [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // kaliya `&4` waxaa u boodboodeen
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Celinta ku yidhi element n`th of iterator ah.
    ///
    /// Like hawlaha tusmaynta ugu, count bilaabo eber, sidaas `nth(0)` laabtay qiimaha ugu horeysay, `nth(1)` labaad, iyo wixii la mid ah.
    ///
    /// Note in dhamaan qaybaha horaysa, iyo sidoo kale waxyaabaha ku soo laabtay, waa la wada baabbi'in doonaa iterator ah.
    /// Taasi waxay ka dhigan tahay in walxaha horay loo soo tuuray la tuurayo, sidoo kale wicitaanka `nth(0)` dhowr jeer isla soo-noqoshadu waxay soo celin doontaa walxo kala duwan.
    ///
    ///
    /// `nth()` soo laaban doonaa [`None`] haddii `n` waa ka weyn yahay ama la mid ah dhererka iterator ah.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Wicitaanka marar badan `nth()` uusan dib u socon iterator ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Noqoshada `None` haddii ay jiraan wax ka yar xubno `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Waxay abuurtaa soo-celin ka bilaabanaysa isla bartaas, laakiin ku tallaabsanaysa inta la siiyay markasta oo soo-noqnoqod ah.
    ///
    /// Xusuusin 1: Cunsurka koowaad ee soo-celinta marwalba waa la soo celin doonaa, iyadoon loo eegin talaabada la bixiyay.
    ///
    /// Fiiro 2: Markii ugu at kaas oo xubno ka tiray waxaa soo jiidayaa aan go'an.
    /// `StepBy` u dhaqmo sida taxanaha `next(), nth(step-1), nth(step-1),…`, laakiin sidoo kale waa u xor inuu u dhaqmo sida taxanaha
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// War jidkee waxaa loo isticmaalaa beddeli kartaa qaar ka mid ah iterators sababo waxqabadka.
    /// Dariiqa labaad wuxuu horey usii hormarin doonaa soojeeraha goor hore waxaana laga yaabaa inuu isticmaalo waxyaabo badan.
    ///
    /// `advance_n_and_return_first` waxay u dhigantaa:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Qaabku waa panic haddii tallaabada la siiyay ay tahay `0`.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Waxay qaadataa laba tarjubaan oo waxay abuurtaa sheeko cusub oo labadoodaba isku xigxigta.
    ///
    /// `chain()` soo laaban doonaa iterator cusub oo hore u iterate doonaa qiimaha ka iterator ugu horeysay, ka dibna ka badan qiimaha ka iterator labaad.
    ///
    /// In si kale loo dhigo, waxa ay wada xidha laba iterators, Silsilad.🔗
    ///
    /// [`once`] waxaa caadi loo isticmaalaa si ay u qabsadaan qiimaha hal gelin silsilad ah noocyada kale ee siyaalaha.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Maaddaama doodda `chain()` ay adeegsaneyso [`IntoIterator`], waxaan u gudbin karnaa wax kasta oo loo rogi karo [`Iterator`], ma ahan oo keliya [`Iterator`] lafteeda.
    /// Tusaale ahaan, xaleef (`&[T]`) fuliyo [`IntoIterator`], iyo si loo si toos ah `chain()` gudbin karaa:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Haddii aad ku shaqeyso Windows API, waxaa laga yaabaa inaad rabto inaad u beddesho [`OsStr`] una beddelo `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Ilaa siibadaha' laba iterators galay iterator hal lammaane.
    ///
    /// `zip()` celinta iterator cusub oo iterate doonaan in ka badan laba iterators kale, soo laabtay tuple halkaas oo element ugu horeysay ee ka timaada iterator ugu horeysay, iyo element labaad ka timaadaa iterator labaad.
    ///
    ///
    /// In si kale loo dhigo, waxa ay wada siibadaha laba iterators, hal hal.
    ///
    /// Haddii labada iterator [`None`], [`next`] soo laabtay ka zipped ku iterator soo laaban doonaa [`None`].
    /// Haddii iterator ugu horeysay soo laabtay [`None`], `zip` gaaban-wareeg iyo `next` lama odhan doono doonaa iterator labaad.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tan iyo markii dood si `zip()` isticmaalaa [`IntoIterator`], waxaan u gudbin kartaa wax kasta oo loo roggi karaa [`Iterator`] ah, ma ahan oo keliya [`Iterator`] ah laftiisa.
    /// Tusaale ahaan, xaleef (`&[T]`) fuliyo [`IntoIterator`], iyo si loo si toos ah `zip()` gudbin karaa:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` waxaa badanaa loo isticmaalaa in lagu dhajiyo jaan-gooye aan dhammaad lahayn oo leh mid kooban.
    /// Tani waxay ka shaqeeya, waayo, uguna ku iterator ugu danbeyn ku soo noqon doona [`None`], afjaridda jiinyeer ah.Zipping la `(0..)` eegi kartaa wax badan sida [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Abuuraa iterator cusub taasoo ka dhigaysa nuqul ka mid ah `separator` u dhexeeya waxyaabaha ku xeeran ee iterator asalka ah.
    ///
    /// Xaaladdan oo `separator` aanay fulin [`Clone`] ama baahida in la xisaabiyaa mar kasta, waxay isticmaalaan [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Curiyeha ugu horreeya ee ka yimaada `a`.
    /// assert_eq!(a.next(), Some(&100)); // Kala soocaha
    /// assert_eq!(a.next(), Some(&1));   // Cunsurka xiga ee ka socda `a`.
    /// assert_eq!(a.next(), Some(&100)); // Kala soocaha
    /// assert_eq!(a.next(), Some(&2));   // element ugu danbeysay ee ka `a`.
    /// assert_eq!(a.next(), None);       // Tilmaamuhu wuu dhammaaday.
    /// ```
    ///
    /// `intersperse` faa iido badan ayey u yeelan kartaa inaad ku biirto walxaha soo noqnoqda iyadoo la adeegsanayo cunsur guud:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Abuuraa iterator cusub taasoo ka dhigaysa item ah ee ay `separator` u dhexeeya waxyaabaha ku xeeran ee iterator asalka ah.
    ///
    /// xiritaanka waxaa loogu yeedhi doonaa si sax ah mar mar kasta oo shay la dhigayaa u dhaxaysa laba waxyaabaha ku xeeran ka iterator salka;
    /// gaar ahaan, la xiro aan loo yeedhin haddii dahsoon wax-soosaarkooda iterator ka yar laba alaabta iyo ka dib item la soo dhaafay waxaa koreen.
    ///
    ///
    /// Haddii iterator ee qalab item [`Clone`], waxaa laga yaabaa in si fudud loo isticmaali [`intersperse`].
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Curiyeha ugu horreeya ee ka yimaada `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Kala soocaha
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Cunsurka xiga ee ka socda `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Kala soocaha
    /// assert_eq!(it.next(), Some(NotClone(2)));  // element ugu danbeysay ee ka `v`.
    /// assert_eq!(it.next(), None);               // Tilmaamuhu wuu dhammaaday.
    /// ```
    ///
    /// `intersperse_with` waxaa loo isticmaali karaa in xaaladaha ay SEPARATOR u baahan yahay in la xisaabiyaa:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Xiritaanka ayaa si amaah ah u amaahinaya macnaha guud si uu u abuuro shay.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Qaadataa xiritaan wuxuuna abuuraa soo noqnoqod leh kaas oo ku baaqaya in la xiro cunsur kasta.
    ///
    /// `map()` wuxuu u beddelaa hal ku-beddele mid kale, isagoo adeegsanaya dooddiisa:
    /// wax fuliya [`FnMut`].Waxay soo saartaa soo-saare cusub oo ugu yeera xiritaanka cunsur kasta oo asalka asalka ah.
    ///
    /// Haddii aad ku fiicantahay inaad ka fikirto noocyada, waxaad ka fikiri kartaa `map()` sidan oo kale:
    /// Haddii aad qabto iterator ah in aad siinaysaa xubno ka ah nooca qaar ka mid ah `A`, oo aad rabto in aad iterator ah ee qaar ka mid ah nooca kale `B`, waxaad isticmaali kartaa `map()`, marayay xiritaanka in qaadataa `A` ah oo soo laabtay `B` ah.
    ///
    ///
    /// `map()` fikrad ahaan waxay lamid tahay wareegga [`for`].Si kastaba ha noqotee, maaddaama `map()` uu caajis yahay, waxaa sida ugu wanaagsan loo isticmaalaa markii aad horayba ula shaqeyneysay qalabka kale ee wax soo saar.
    /// Haddii aad samaynaysaan sort qaar ka mid ah dabamariyey oo dhibaalka dhanka ah, waxa uu tixgeliyaa ka badan tahay ereyadan in ay isticmaalaan [`for`] badan `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Haddii aad samaynaysaan sort qaar ka mid ah xasaasiyaha daaweysa, door bidaan [`for`] in `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ha sameyn tan:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // xitaa ma fulin doono, maadaama ay caajis tahay.Rust idiin digi doonaa oo arrintan ku saabsan.
    ///
    /// // Taabadalkeed, u isticmaal:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Oo ku baaqay in la xiro a on element kasta oo iterator ah.
    ///
    /// Tani waxay u dhigantaa isticmaalaya loop [`for`] a on iterator ah, inkastoo `break` iyo `continue` ma waa u suurtoobaan ka xidho a.
    /// Waa guud ahaan ka badan tahay ereyadan in ay isticmaalaan loop `for` ah, laakiin `for_each` waxaa laga yaabaa in ka badan oo bayaan ah marka ay alaabta dhamaadka silsilado iterator dheer.
    ///
    /// Xaaladaha qaarkood `for_each` sidoo kale waxaa laga yaabaa in si ka dhaqso badan loop a, maxaa yeelay waxa ay u isticmaali doonaan siyaalaha gudaha on adapters sida `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Tusaalahan yar, nooca loo yaqaan `for` loop' ayaa laga yaabaa inuu ka nadiifsan yahay, laakiin `for_each` ayaa laga door bidaa in lagu ilaaliyo qaab shaqeysan leh istiraatiijiyaal dhaadheer:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Abuuraa iterator ah taas oo uu isticmaalaa la xidho si loo ogaado haddii element ah waa in la koreen.
    ///
    /// Marka la eego element ah xiritaanka waa in ku soo laabto `true` ama `false`.Ayaa ku soo laabtay iterator dhali doono oo kaliya waxyaabaha loogu talagalay taas oo xiritaanka laabtay run.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sababtoo ah xiritaanka loo gudbiyay `filter()` wuxuu qaadanayaa tixraac, iyo in badan oo ka mid ah kuwa ka faa'iideysta waxay ku dul wareegaan tixraacyada, tani waxay keenaysaa xaalad suurtagal ah oo jahwareer leh, halkaas oo nooca xiritaanka uu yahay tixraac labalaab ah:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // u baahan laba * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Waa wax caadi ah in halkii isticmaali destructuring on Xujada inay dharka iska mid:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // labadaba&iyo *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ama labadaba:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // laba &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ee lakabyadan.
    ///
    /// Ogsoonow in `iter.filter(f).next()` u dhiganta `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Waxay abuurtaa soo noqnoqod sameeye shaandheeya iyo khariidado labadaba.
    ///
    /// Ayaa ku soo laabtay iterator edbiyey ku yidhi value`s kaas oo xiritaanka bixisey laabtay `Some(value)` kaliya.
    ///
    /// `filter_map` waxaa loo isticmaali karaa si ay u sameeyaan silsiladood oo ah [`filter`] iyo [`map`] kooban dheeraad ah.
    /// Tusaale ahaan hoos ku muujiyay sida `map().filter().map()` ah loo gaabin karaan si ay hal call a in `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Waa kan isla tusaalahan, laakiin leh [`filter`] iyo [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Abuuraa iterator ah oo ku siinayaa tirinta siyaalaha hadda iyo sidoo kale qiimaha soo socda.
    ///
    /// iterator The wax-soosaarkooda noqdeen lammaane `(i, val)`, halkaas oo `i` waa index hadda siyaalaha ah iyo `val` waa qiimaha by iterator ku soo laabtay.
    ///
    ///
    /// `enumerate()` dhawraa ay count sida [`usize`] ah.
    /// Haddii aad rabto in aad tirisaan by a abyoonaha xajmi duwan, function [`zip`] bixisaa shaqeynta la mid ah.
    ///
    /// # Akhlaaq Buuxsan
    ///
    /// Qaabku ma ilaalinayo qulqulka xad dhaafka ah, sidaa darteed tirinta wax ka badan walxaha [`usize::MAX`] ama waxay soo saartaa natiijo qaldan ama panics.
    /// Haddii si waafi ah Debug yihiin karti, panic ah waa la damaanad qaaday.
    ///
    /// # Panics
    ///
    /// Soo-celinta soo-celinta ayaa laga yaabaa panic haddii tusmada la-soo-celiyo ay buuxin doonto [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Waxay abuurtaa soo-saare adeegsade ah oo isticmaali kara [`peek`] si uu u eego culeyska soo socda ee soo-saarista isagoo aan cunin.
    ///
    /// Darayaa habka [`peek`] ah in iterator ah.Eeg dukumiintiyadeeda wixii macluumaad dheeraad ah.
    ///
    /// Fiiro gaar ah in salka iterator weli hormartay markii [`peek`] waxaa loo yaqaan markii ugu horeysay, Si ay u soo ceshano element soo socda, [`next`] waxaa loo yaqaan ku saabsan iterator ku lammaan, halkan waxyeelo kasta (ie
    ///
    /// wax kasta oo aan ahayn soo qaadashada qiimaha xiga) ee habka [`next`] ayaa dhici doona.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ogolaanaysaa na aragtaan galay future ah
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // waxaan peek() karo marar badan, ka iterator maayo horay
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ka dib marka soo-gabehuhu dhammaado, sidoo kale waa peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Abuuraa iterator ah in [`skip`] s xubno ku salaysan la saadaalin karo a.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` xiritaanka dood ahaan.Waxay ugu yeeri doontaa xiritaanka cunsur kasta oo ka mid ah soo-saaraha, iskana indha tira waxyaabaha ilaa inta ay ka soo noqoneyso `false`.
    ///
    /// Ka dib markii la soo celiyo `false`, shaqadii `skip_while()`'s way dhammaatay, inta hartayna cunsuriyaddii ayaa la soo saaray.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Maxaa yeelay, xiritaanka in `skip_while()` maray qaadataa tixraac, iyo iterators badan iterate badan la tixraaci karo, raadad si ay xaaladda a suurto gal wareeriya, halkaas oo nooca muran xiritaanka waa tixraac double:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // u baahan laba * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Joojinta kadib `false` bilowga ah:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // halka tani been noqon laheyd, maadaama aan horeyba been u helnay, skip_while() mar dambe lama isticmaalin
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Waxay abuurtaa soo noqnoqosho soo saarta waxyaabo ku saleysan saadaal.
    ///
    /// `take_while()` xiritaanka dood ahaan.Waxaa soo wici doonaa xiritaanka this on element kasta oo iterator ah, iyo dhali xubno halka noqdo `true`.
    ///
    /// Ka dib markii `false` la soo celiyo, shaqo `take_while()`'s waa in ka badan, iyo inta kale ee xubno ka yihiin tiray.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sababtoo ah xiritaanka loo gudbiyay `take_while()` wuxuu qaadanayaa tixraac, iyo in badan oo ka mid ah kuwa ka faa'iideysta waxay ku dul wareegaan tixraacyada, tani waxay keenaysaa xaalad suurtagal ah oo jahwareer leh, halkaas oo nooca xiritaanka uu yahay tixraac labalaab ah:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // u baahan laba * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Joojinta kadib `false` bilowga ah:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Waxaan haynaa cunsurro badan oo ka yar eber, laakiin maadaama aan horay u helnay been, take_while() lama sii isticmaalin
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sababtoo ah `take_while()` waxay ubaahantahay inay eegto qiimaha si loo arko in lagu daro iyo inkale, cunida dadka isticmaala waxay arki doontaa in laga saaray:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` waa mar dambe ma ay jiraan, sababta oo ah waxa la wada baabbi'iyey si loo arko haddii siyaalaha ay joojiyaan, laakiin waa lama soo celin iterator kaalinta.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Waxay abuurtaa soo noqnoqod sameeye in labadaba soo saaraan waxyaabo ku saleysan isdifaac iyo khariidado.
    ///
    /// `map_while()` xiritaanka dood ahaan.
    /// Waxay ugu yeeri doontaa xiritaanka cunsur kasta oo ka mid ah soo-saaraha, soona saari doona walxaha inta ay soo noqoneyso [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Waa kan isla tusaalahan, laakiin leh [`take_while`] iyo [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Joojinta ka dib markii [`None`] hore:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Waxaan haynaa cunsurro badan oo ku habboon u32 (4, 5), laakiin `map_while` waxay soo celisay `None` ee `-3` (sida `predicate` u soo celisay `None`) iyo `collect` waxay joogsatay `None` ugu horreeyay ee la kulmay.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Maxaa yeelay, `map_while()` u baahan tahay in aad eegto qiimaha si ay u arkaan haddii ay tahay in lagu daro ama aan, wax baabbi'iya iterators arki doontaa in laga saaro:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` hadda ma joogo, maxaa yeelay waxaa loo isticmaalay si loo arko haddii soo-celinta ay joogsanayso, laakiin dib looma gelin soo-celinta.
    ///
    /// Fiiro gaar ah in ka duwan [`take_while`] iterator tani waa **ma** dhisnayd.
    /// Sidoo kale lama cayimin waxa soo-celiyuhu soo celiyo ka dib markii [`None`]-kii ugu horreeyay la soo celiyo.
    /// Haddii aad u baahan tahay qalab-soo-saar la isku daray, isticmaal [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Abuuraa iterator in sababi waxyaalaha ugu horeysay `n`.
    ///
    /// Ka dib markay wada baabbe'een, inta kale ee canaasiirta ah ayaa la soo saaray.
    /// Halkii toos khaas ah habkan, halkii ay tirtirto habka `nth` ah.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Abuuraa iterator in edbiyey xubno `n` ugu horeysay.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` waxaa badanaa loo isticmaalaa la iterator ah aan la koobi karayn, si ay u uguna:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Haddii in ka yar xubno `n` waxaa laga heli karaa, `take` laftiisa xadidi doonaa in size ee iterator sababaya:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// adabtarada iterator An mid ah [`fold`] in heysta gobolka gudaha iyo saarta iterator cusub.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` qaadataa laba dood: qiimaha bilowga oo miraha gobolka gudaha, iyo xiritaanka leh laba dood, marka hore isagoo tixraaca ah mutable gobolka gudaha iyo labaad element iterator ah.
    ///
    /// Xidhitaanka ku wareejin kartid in gobolka gudaha in ay share gobolka dhexeeya iterations.
    ///
    /// On siyaalaha, xiritaanka lagu saleyn doonaa in element kasta oo ka mid ah iterator iyo qiimaha ka soo laabtay xiritaanka, [`Option`] ah ee, waxaa la dhalaya by iterator ah.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // siyaalaha kasta, waxaan u tarmin doonaa gobolka by element ah
    ///     *state = *state * x;
    ///
    ///     // markaa, waxaan ku siin doonaa diidmada gobolka
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Waxay abuurtaa soo noqnoqe u shaqeeya oo u shaqeeya sida khariidada, laakiin fidiya qaabdhismeedka buulka.
    ///
    /// adabtarada [`map`] waa mid aad u faa'iido leh, laakiin kaliya markii muran xiritaanka saartaa qiimaha.
    /// Haddii ay soo saarto soo-celin beddelkeed, waxaa jira lakab dheeri ah oo aan leexasho lahayn.
    /// `flat_map()` ka saari doonaa lakabkan dheeriga ah kaligiis.
    ///
    /// Waxaad u malayn kartaa of `flat_map(f)` sida u dhiganta semantic ah [`map`] ping, ka dibna [`flatten`] nayaa sida in `map(f).flatten()`.
    ///
    /// Si kale oo loo fekerayo `flat_map()`: [`map`] 's xiritaanka celinta mid item for element kasta, iyo `flat_map()`'s xiritaanka celinta iterator ah element kasta.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() sooceliyaha sooceliyaha
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Waxay abuurtaa soo noqnoqod sameeya oo fidiya qaab dhismeedka buulka.
    ///
    /// Tani waa mid waxtar leh marka aad iterator ah iterators ama iterator ah waxyaalo la galay iterators jeestay karo oo aad rabto in aad ka saarto hal heer oo indirection.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Khariidadeynta ka dibna fidsanaan aad:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() sooceliyaha sooceliyaha
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Waxa kale oo aad ku qoroto karaa marka la eego [`flat_map()`], oo waxaa quman in kiiskan tan iyo markii ay gudbinaysaa more ujeedada si cad:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() sooceliyaha sooceliyaha
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Fidsanaan kaliya ka saaraysaa hal heer oo xilliga kulaylaha mar:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Halkaan waxaan ku aragnaa in `flatten()` uusan sameynin qaab dhismeedka "deep" flatten'.
    /// Taabadalkeed, kaliya hal heer oo buul ayaa laga saaray.Taasi waa, haddii aad `flatten()` ah oo saddex-geesood ah, natiijada waxay noqon doontaa laba-cabbir oo aan ahayn hal-cabbir.
    /// Si aad u hesho qaab-dhismeed hal-cabbir ah, waa inaad markale `flatten()` noqotaa.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Abuuraa iterator ah oo dhamaado ka dib markii [`None`] ugu horeysay.
    ///
    /// Ka dib markii iterator ah laabtay [`None`], wicitaanada future ama midho ma dhali laga yaabaa in laga yaabaa in [`Some(T)`] mar kale.
    /// `fuse()` islana iterator ah, in la hubiyo in dib markii [`None`] ah la siiyo, waxaa had iyo jeer ku soo laaban doona [`None`] weligiis.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// // iterator ah oo Gagadiyaa u dhexeeya qaar ka mid ah iyo None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // hadday xitaa tahay, Some(i32), kale MAYA
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // waxaan arki karnaa shaqadeena soo socota ee horay iyo gadaal u socota
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // si kastaba ha noqotee, markii aan isku dareyno ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // waxay had iyo jeer soo celin doontaa `None` markii ugu horreysay kadib.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Ma wax la element kasta oo iterator ah, oo marayay qiimaha on.
    ///
    /// Markaad isticmaaleyso qalabka socdaalka, waxaad inta badan isku xirxiran doontaa dhowr ka mid ah.
    /// Iyada oo ka shaqeeya code sida, laga yaabaa in aad rabto in aad si aad u hubiso soo baxay waxa ka dhacaya qaybaha kala duwan ee dhuumaha.Si taas loo sameeyo, wicitaan u dir `inspect()`.
    ///
    /// Way ku badan tahay in `inspect()` loo isticmaalo aalad khalad-ka-beddelka ah marka loo eego lambarkaaga ugu dambeeya, laakiin codsiyada ayaa laga yaabaa inay faa'iido u leeyihiin xaaladaha qaarkood marka khaladaadka loo baahan yahay in la qoro kahor intaan la tuurin.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // taxanahan soo noqnoqda waa mid adag
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // aan ku darno qaar ka mid ah wicitaanada inspect() si aan u baarno waxa dhacaya
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Tani waxay daabici doontaa:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Gelitaanka qaladaad ka hor inta ay qubaan:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Tani waxay daabici doontaa:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Waxay jabisaa soo noqnoqoshada, halkii aad ka cuni lahayd.
    ///
    /// Tani waxay faa iido u leedahay in loo ogolaado codsashada adapters-ka adoo adeegsanaya asagoo wali sii wadaya lahaanshaha asalka asalka ah.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // haddii aynu isku dayaan in ay mar kale isticmaali iter, ma shaqeyn doonaan.
    /// // Sadarka soo socdaa wuxuu bixinayaa "qalad: isticmaalka qiimaha la dhaqaajiyay: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // aan isku dayno markale
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // halkii, waxaan ku darnaa .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // hadda kani waa hagaagsan yahay:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Badalaa iterator galay ururinta.
    ///
    /// `collect()` waxay qaadan kartaa wax kasta oo lama-taaban karo, oo waxay u rogtaa ururinta ku habboon.
    /// Tani waa mid ka mid ah hababka awood badan maktabadda caadiga ah, loo isticmaalo kala duwan oo ka mid ah xaaladaha.
    ///
    /// Habku aasaasiga ah, taas oo `collect()` loo isticmaalo waa in ay soo jeedin ka mid ah ururinta kale.
    /// Waxaad qaadan ururinta ah, wac [`iter`] waxa on, samayn farabadan of transformations, ka dibna `collect()` dhamaadka.
    ///
    /// `collect()` sidoo kale abuuri kartaa dhacdooyin noocyada aan uruuriyaa caadiga ah.
    /// Tusaale ahaan, [`String`] ah waa la dhisi karaa [`char`] s, iyo iterator ah waxyaabaha [`Result<T, E>`][`Result`] la qaadi karaa galay `Result<Collection<T>, E>`.
    ///
    /// Fiiri tusaalooyinka hoose wixii intaa ka badan.
    ///
    /// Sababtoo ah `collect()` waa mid guud, waxay sababi kartaa dhibaatooyin laxiriira nooca.
    /// Sida oo kale, `collect()` waa mid ka mid ah wakhtiyada dhowr ah oo aad arki doonaa Saan u yaqaaneen 'turbofish' ah: `::<>`.
    /// Tani waxay ka caawineysaa fikradaha algorithm inay fahmaan gaar ahaan uruurinta aad isku dayeyso inaad ururiso.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Xusuusnow inaan ubaahanahay `: Vec<i32>` dhanka bidix.Tani waa sababta oo ah waxaan ku soo ururin karnaa, tusaale ahaan, [`VecDeque<T>`] halkii:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Isticmaalka 'turbofish' halkii annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Sababtoo ah `collect()` waxay danaynaysaa oo keliya waxa aad aruurinayso, waxaad wali u isticmaali kartaa nooc nus ah, `_`, oo leh turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Adeegsiga `collect()` si aad u sameyso [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Haddii aad hayso liis ah ``Natiijo<T, E>`][`Result`] s, waxaad isticmaali kartaa `collect()` si loo arko haddii wax kasta oo iyaga ku guuldareystay:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // wuxuu na siinayaa qaladka ugu horeeya
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // wuxuu na siinayaa liiska jawaabaha
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Waxay isticmaashaa jaan-gooye, iyadoo ka abuureysa laba aruurin.
    ///
    /// Saadaasha loo gudbiyey `partition()` waxay soo celin kartaa `true`, ama `false`.
    /// `partition()` Soo Laabtay labo ka mid ah, dhammaan qaybaha for taas oo ku soo laabtay `true`, oo dhan oo ka mid ah xubno ka kaas oo u soo noqdeen `false`.
    ///
    ///
    /// Sidoo kale eeg [`is_partitioned()`] iyo [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders waxyaalaha aasaaska ah ee iterator this *in-meel* sida ay la saadaalin karo la siiyo, sida in kuwii oo dhan in soo laabashada `true` hormaraan kuwa soo laabtay `false`.
    ///
    /// Sooceliyaa tirada cunsuriyada `true` ee la helay.
    ///
    /// Amarka qaraabada ah ee waxyaabaha lakala qaybiyay lama hayo.
    ///
    /// Sidoo kale eeg [`is_partitioned()`] iyo [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Barzakh in-meel u dhaxaysa evens oo u qalmay
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ma inaan ka walwalsanahay tirada tirida?Sida kaliya ee lagu helo wax ka badan
        // `usize::MAX` tixraacyada mutable waa la ZSTs, taas oo aan ay muhiim tahay in ay xijaab ...

        // Kuwaas waxaa la xiro hawlaha "factory" jiraan in ay ka fogaadaan genericity in `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Si joogta ah ka heli `false` ugu horeysay oo ay u bedelan la `true` ee la soo dhaafay.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Checks haddii waxyaalaha aasaaska ah ee this iterator waxaa xijaabi sida ay la saadaalin karo la siiyo, sida in kuwa soo laabtay `true` hormaraan kuwa soo laabtay `false` oo dhan.
    ///
    ///
    /// Sidoo kale eeg [`partition()`] iyo [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ama walxaha oo dhami waxay tijaabiyaan `true`, ama qodobka ugu horeeya ayaa istaagaya `false` waxaanan hubinaa inaanay jirin wax intaa ka badan oo ah `true` intaas kadib.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Habka iterator An khuseeya shaqo ah, inta soo laabtay sidii ay si guul leh, soo saarida hal qiimaha a, final.
    ///
    /// `try_fold()` waxay qaadataa laba doodood: qiime bilow ah, iyo xidhitaan leh laba doodood: 'accumulator', iyo cunsur.
    /// xiritaanka labada celinta si guul leh, iyadoo qiimaha in accumulator ah waa in ay leeyihiin waayo siyaalaha soo socda, ama noqdo failure, iyadoo qiimaha qalad waa in dib u faafin in wacay isla markiiba (short-circuiting).
    ///
    ///
    /// Qiimaha bilowga waa qiimaha accumulator ay ku yeelan doonto call ugu horeysay.Haddii aad codsaneysid xiritaanka guulaysteen ka dhanka ah element kasta oo iterator ah, `try_fold()` laabtay accumulator finalka guul.
    ///
    /// Isku laabiddu waxtar ayey leedahay markasta oo aad wax uruuriso, oo aad rabto inaad ka soo saarto hal qiime oo keliya.
    ///
    /// # Fiiro gaar ah si ay u Implementors
    ///
    /// Dhowr ka mid ah hababka kale ee (forward) leeyihiin fulintii default la eego this mid ka mid ah, sidaa darteed isku day in this fuliyo si cad haddii ay samayn kartaa wax ka khayr badan default `for` fulinta loop ka.
    ///
    /// Gaar ahaan, isku day in aad qabto call this `try_fold()` on qaybo ka mid ah gudaha oo ka kaas oo iterator this ka kooban yahay.
    /// Haddii loo baahan yahay wicitaanada badan, operator `?` waxaa laga yaabaa in ku haboon chaining qiimaha accumulator hareeraha, laakiin iska jira wax invariants in baahi loo qabo in la fuliyo ka hor inta kuwa celinta hore.
    /// Tani waa habka `&mut self` ah, si siyaalaha loo baahan yahay in resumable ka dib markii garaacid qalad halkan.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // wadarta la hubiyey ee dhammaan walxaha soo diyaariyey
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // wadarta Tani buuxdhaafaa markii isagoo intaa ku daray 100 element ah
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Sababta oo ah waxa gaaban-circuited, waxyaalaha haray weli waxaa laga heli karaa iyada oo loo marayo iterator ah.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Habka soocelinta ee khuseeya hawl lagu dhici karo shay kasta oo ka mid ah soo-celinta, joojinta qaladka ugu horreeya iyo soo celinta qaladkaas.
    ///
    ///
    /// Tan waxaa sidoo kale loo maleyn karaa inay tahay qaabka dhici kara ee [`for_each()`] ama nooca aan wadan lahayn ee [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Waxaa gaaban-circuited, sidaas oo kale ayaa waxyaabaha hartay ayaa weli ku jira iterator ah:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Xeryo element walba galay accumulator ah by codsanaya qaliin, soo laabtay natiijada kama dambaysta ah.
    ///
    /// `fold()` waxay qaadataa laba doodood: qiime bilow ah, iyo xidhitaan leh laba doodood: 'accumulator', iyo cunsur.
    /// Xidhitaanka laabtay qiimaha in accumulator waxay leeyihiin waa in siyaalaha soo socda.
    ///
    /// Qiimaha bilowga ahi waa qiimaha shirkaddu ku yeelanayso wicitaanka ugu horreeya.
    ///
    /// Ka dib codsanaya la xiro si element kasta oo iterator ah, `fold()` laabtay accumulator ah.
    ///
    /// Hawlgalkan waxaa mararka qaarkood loo yaqaan 'reduce' ama 'inject'.
    ///
    /// Isku laabiddu waxtar ayey leedahay markasta oo aad wax uruuriso, oo aad rabto inaad ka soo saarto hal qiime oo keliya.
    ///
    /// Note: `fold()`, iyo hababka la mid ah in uyeelay iterator oo dhan, laga yaabaa in aanay joojin waayo iterators aan la koobi karayn, xitaa on traits taas oo ay sabab u yahay determinable wakhtiga uguna.
    ///
    /// Note: [`reduce()`] waxaa loo isticmaali karaa si ay u isticmaalaan element ugu horeysay ee sida qiimaha bilowga ah, haddii nooca accumulator iyo nooca item waa isku mid.
    ///
    /// # Fiiro gaar ah si ay u Implementors
    ///
    /// Dhowr ka mid ah hababka kale ee (forward) leeyihiin fulintii default la eego this mid ka mid ah, sidaa darteed isku day in this fuliyo si cad haddii ay samayn kartaa wax ka khayr badan default `for` fulinta loop ka.
    ///
    ///
    /// Gaar ahaan, isku day in aad qabto call this `fold()` on qaybo ka mid ah gudaha oo ka kaas oo iterator this ka kooban yahay.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // wadarta dhamaan walxaha soo diyaariyey
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ha la socdaan iyada oo loo marayo talaabo kasta oo ka mid siyaalaha halkan:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Iyo sidaas, natiijada ugu dambeysa, `6`.
    ///
    /// Waa caadi in dadka iterators looma isticmaalo wax badan si ay u isticmaalaan loop `for` leh liiska waxyaabaha in la dhiso ilaa natiijo.Kuwaas waxaa loo rogi karaa `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // waa isku mid
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Yaraynaysaa canaasiirta in mid ka mid ah hal, by si joogta ah codsanaya hawlgal yareeyo.
    ///
    /// Haddii soo-saaraha uu faaruq yahay, wuxuu soo celinayaa [`None`];haddii kale, wuxuu soo celinayaa natiijada dhimista.
    ///
    /// Waayo, iterators leh ugu yaraan hal element, tani waa isku mid sida [`fold()`] la element ugu horeysay ee iterator sida qiimaha bilowga ah, marna laabi wax element kasta oo ku xiga u galay.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Soo hel qiimaha ugu badan:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Tijaabooyinka haddii qayb kasta oo ka mid ah soo-saareyaashu u dhigmayaan saadaal.
    ///
    /// `all()` qaadataa xiritaanka in laabtay `true` ama `false`.Waxay khusaysaa xiro si element kasta oo iterator ah, iyo haddii ay dhan ku soo laabto `true`, ka dibna sidaas ma `all()`.
    /// Haddii kasta oo iyaga ka mid ah soo laaban `false`, ka noqdo `false`.
    ///
    /// `all()` waa wareeg-gaaban;in si kale loo dhigo, waxaa la joojin doonaa ka baaraandegidda sida ugu dhakhsaha badan helo `false` ah, siin in wax dhib ah maleh waxa kale dhacdo, natiijada sidoo kale jiri doona `false`.
    ///
    ///
    /// iterator madhan laabtay `true`.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Joojinta at `false` koowaad:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // wali waan isticmaali karnaa `iter`, maadaama ay jiraan waxyaabo badan.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tijaabooyinka haddii qayb kasta oo ka mid ah soo-saaristu u dhigantaa saadaaliye.
    ///
    /// `any()` qaadataa xiritaanka in laabtay `true` ama `false`.Waxay khusaysaa xiro si element kasta oo iterator ah, iyo haddii ay mid iyaga ka mid soo laaban `true`, ka dibna sidaas ma `any()`.
    /// Haddii ay dhammaan soo laaban `false`, ka noqdo `false`.
    ///
    /// `any()` waa wareeg-gaaban;in si kale loo dhigo, waxaa la joojin doonaa ka baaraandegidda sida ugu dhakhsaha badan helo `true` ah, siin in wax dhib ah maleh waxa kale dhacdo, natiijada sidoo kale jiri doona `true`.
    ///
    ///
    /// Hadal faaruq ah ayaa soo celiya `false`.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Joojinta ugu horeysa `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // wali waan isticmaali karnaa `iter`, maadaama ay jiraan waxyaabo badan.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Raadinta cunsur soo noqnoqota oo qancisa saadaal hore.
    ///
    /// `find()` qaadataa xiritaanka in laabtay `true` ama `false`.
    /// Waxay khusaysaa xiro si element kasta oo iterator ah, iyo haddii ay mid iyaga ka mid `true` soo noqon, markaas `find()` laabtay [`Some(element)`].
    /// Hadday dhammaantood soo noqdaan `false`, waxay soo celisaa [`None`].
    ///
    /// `find()` waa-circuiting gaaban;in si kale loo dhigo, waxaa la joojin doonaa ka baaraandegidda sida ugu dhakhsaha badan xiritaanka laabtay `true`.
    ///
    /// Maxaa yeelay, `find()` qaadataa tixraac, iyo iterators badan iterate badan la tixraaci karo, raadad si ay xaaladda a suurto gal wareeriya halkaas oo muran uu yahay tixraac double.
    ///
    /// Waxaad ka arki kartaa saamayn this ee tusaalooyinka hoos ku qoran, la `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Joojinta ugu horeysa `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // wali waan isticmaali karnaa `iter`, maadaama ay jiraan waxyaabo badan.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Xusuusnow in `iter.find(f)` ay u dhigantaa `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Khuseysaa shaqo si canaasiirta iterator ah oo soo laabtay oo aan midkoodna natiijadii ugu horeysay.
    ///
    ///
    /// `iter.find_map(f)` waxay u dhigantaa `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Khuseysaa shaqo si canaasiirta iterator ah oo soo laabtay natiijada ugu horeysay run ama qalad ugu horeysay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Raadinta for element ah iterator ah, soo laabtay ay index.
    ///
    /// `position()` qaadataa xiritaanka in laabtay `true` ama `false`.
    /// Waxay khusaysaa xiro si element kasta oo iterator ah, iyo haddii ay mid ka mid ah ku soo laabtay `true`, ka dibna `position()` laabtay [`Some(index)`].
    /// Haddii dhan oo iyaga ka mid `false` soo laabto, ka noqdo [`None`].
    ///
    /// `position()` waa wareeg-gaaban;in si kale loo dhigo, waxaa la joojin doonaa ka baaraandegidda sida ugu dhakhsaha badan helo `true` ah.
    ///
    /// # Akhlaaq Buuxsan
    ///
    /// Habka ma lahayn ilaalinta ka dhanka ah Burqado, sidaas darteed haddii ay jiraan in ka badan xubno aan ku habboon [`usize::MAX`], waxaa sidoo kale soo saartaa natiijada qaldan ama panics.
    ///
    /// Haddii si waafi ah Debug yihiin karti, panic ah waa la damaanad qaaday.
    ///
    /// # Panics
    ///
    /// Shaqadani waa laga yaabaa panic haddii soo-saaraha uu leeyahay wax ka badan `usize::MAX` walxo aan u dhigmin.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Joojinta ugu horeysa `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // wali waan isticmaali karnaa `iter`, maadaama ay jiraan waxyaabo badan.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Tusmada la soo celiyey waxay kuxirantahay xaalada soosaarayaasha
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Raadinta for element ah iterator ka xaq, soo laabtay ay index.
    ///
    /// `rposition()` qaadataa xiritaanka in laabtay `true` ama `false`.
    /// Waxay khusaysaa xiro si element kasta oo iterator ah, laga bilaabo dhamaadka, oo haddii mid ka mid ah ku soo laabtay `true`, ka dibna `rposition()` laabtay [`Some(index)`].
    ///
    /// Haddii dhan oo iyaga ka mid `false` soo laabto, ka noqdo [`None`].
    ///
    /// `rposition()` waa wareeg-gaaban;in si kale loo dhigo, waxaa la joojin doonaa ka baaraandegidda sida ugu dhakhsaha badan helo `true` ah.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Joojinta ugu horeysa `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // wali waan isticmaali karnaa `iter`, maadaama ay jiraan waxyaabo badan.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Uma baahna dhulka qarqinaya ah halkan ka fiiri, maxaa yeelay, `ExactSizeIterator` oo muujinaysa in tirada qallalku xubno ka galay `usize` ah.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Sooceliya curiyeyaasha ugu badan ee soo noqnoqdaha.
    ///
    /// Haddii dhowr walxood ay si isku mid ah ugu sarreeyaan, cunsurkii ugu dambeeyay ayaa la soo celiyaa.
    /// Haddii iterator waa madhan, [`None`] la soo celiyo.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Sooceliyaa element ugu yar ee iterator ah ee.
    ///
    /// Haddii dhowr walxood ay si siman u yar yihiin, curiyihii ugu horreeyay ayaa la soo celiyaa.
    /// Haddii iterator waa madhan, [`None`] la soo celiyo.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Waxay soocelisaa cunsurka siiya qiimaha ugu badan shaqada la cayimay.
    ///
    ///
    /// Haddii dhowr walxood ay si isku mid ah ugu sarreeyaan, cunsurkii ugu dambeeyay ayaa la soo celiyaa.
    /// Haddii iterator waa madhan, [`None`] la soo celiyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Dib element in siinayaa qiimaha ugu badnaan marka la eego shaqada marka la barbardhigo cayiman.
    ///
    ///
    /// Haddii dhowr walxood ay si isku mid ah ugu sarreeyaan, cunsurkii ugu dambeeyay ayaa la soo celiyaa.
    /// Haddii iterator waa madhan, [`None`] la soo celiyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Waxay soocelisaa cunsurka siiya qiimaha ugu yar shaqada la cayimay.
    ///
    ///
    /// Haddii dhowr walxood ay si siman u yar yihiin, curiyihii ugu horreeyay ayaa la soo celiyaa.
    /// Haddii iterator waa madhan, [`None`] la soo celiyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Dib element in siinayaa qiimaha ugu yar marka la eego shaqada marka la barbardhigo cayiman.
    ///
    ///
    /// Haddii dhowr walxood ay si siman u yar yihiin, curiyihii ugu horreeyay ayaa la soo celiyaa.
    /// Haddii iterator waa madhan, [`None`] la soo celiyo.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Waxay leexisaa jihada jihada.
    ///
    /// Badanaa, tarjumeyaasha ayaa ka soocaa bidix ilaa midig.
    /// Ka dib markaad isticmaasho `rev()`, soo-saare ayaa beddelkeeda ka soocaya midig ilaa bidix.
    ///
    /// Tani waa suuragal ah keliya haddii iterator ah wuxuu leeyahay dhammaansho, sidaas `rev()` oo keliya shaqeeya [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Kuweeda iterator ah lammaane galay labo ka mid ah weel.
    ///
    /// `unzip()` gubtay iterator dhan ah labo-labo, soo saara laba ururinta, mid ka canaasiirta bidix ee yeeley, iyo mid ka mid ah xubno ka xaq.
    ///
    ///
    /// Shaqadani waa, macno ahaan, ka soo horjeedka [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Waxay abuurtaa soo noqnoqod sameeye nuqul ka sameeya dhammaan walxaha uu ka kooban yahay.
    ///
    /// Tani waxtar ayey leedahay marka aad leedahay soo-saare ka badan `&T`, laakiin waxaad u baahan tahay soo-saar ka badan `T`.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // la guuriyey waxay lamid tahay .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Abuuraa iterator ah oo [`clone`] s oo dhan ee canaasiirta ay.
    ///
    /// Tani waxtar ayey leedahay marka aad leedahay soo-saare ka badan `&T`, laakiin waxaad u baahan tahay soo-saar ka badan `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned waa isku mid sida .map(|&x| x), oo loogu talagalay lambarrada
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Ku celcelinta sooceliyaha si aan dhammaad lahayn.
    ///
    /// Halkii joojinta at [`None`], iterator halkii bilaaban doono mar kale, tan iyo bilowgii.Ka dib markaad dib u hawlgasho, waxay bilaabi doontaa bilawga markale.Iyo markale.
    /// Iyo markale.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Wuxuu soo koobayaa cunsuriyaha soo noqnoqda.
    ///
    /// Qaadataa element kasta, iyaga isugu darayaa, oo ku soo laabtay natiijada.
    ///
    /// Hadal faaruq ah ayaa soo celinaya qiimaha eber ee nooca.
    ///
    /// # Panics
    ///
    /// Markii ugu yeeray `sum()` iyo nooc abyoonaha heer hoose la soo noqdeen, habkan panic haddii Burqado xisaabinta iyo si waafi ah Debug yihiin awood doonaa.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Celinaysa badan iterator oo dhan, tarmo dhammaan waxyaabaha ku
    ///
    /// Hadal-haye madhan ayaa soo celiya hal nooc oo nooca ah.
    ///
    /// # Panics
    ///
    /// Markii la wacayo `product()` iyo nooc isku-dhafan oo hordhac ah ayaa la soo celinayaa, habka panic ayaa la sameyn doonaa haddii xisaabinta ay buuxsato iyo sheegashooyinka qashin-saarka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) wuxuu isbarbardhigayaa cunsurrada [`Iterator`] iyo kuwa kale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) wuxuu isbarbardhigayaa cunsurrada [`Iterator`] kan kuwa kale marka loo eego shaqooyinka isbarbar dhiga lagu qeexay.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) wuxuu isbarbardhigayaa cunsurrada [`Iterator`] iyo kuwa kale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) wuxuu isbarbardhigayaa cunsurrada [`Iterator`] kan kuwa kale marka loo eego shaqooyinka isbarbar dhiga lagu qeexay.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Go'aamiso haddii waxyaalaha aasaaska ah ee [`Iterator`] this waa u siman yihiin kuwa kale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Go'aamiso haddii waxyaalaha aasaaska ah ee [`Iterator`] this waa u siman yihiin kuwa kale marka la eego shaqada sinaanta cayiman.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Go'aamiyaa haddii walxaha [`Iterator`]-kan ay u siman yihiin kuwa kale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Go'aamiso haddii waxyaalaha aasaaska ah ee [`Iterator`] this yihiin [lexicographically](Ord#lexicographical-comparison) ka yar kuwa kale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Go'aamiso haddii waxyaalaha aasaaska ah ee [`Iterator`] this yihiin [lexicographically](Ord#lexicographical-comparison) ka yar ama la mid ah kuwa kale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Go'aamiso haddii waxyaalaha aasaaska ah ee [`Iterator`] this waa weyn [lexicographically](Ord#lexicographical-comparison) ka badan kuwa kale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Go'aamiso haddii waxyaalaha aasaaska ah ee [`Iterator`] this waa weyn [lexicographically](Ord#lexicographical-comparison) badan ama simanyihiin kuwa kale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Wuxuu hubinayaa haddii waxyaabaha cunsuriyahaan ka kooban la kala soocay.
    ///
    /// Taasi waa, waayo, element kasta `a` iyo element socda `b`, `a <= b` waa in ay haystaan.Haddii soo-saaraha uu dhaliyo eber ama hal cunsur, `true` ayaa la soo celiyey.
    ///
    /// Xusuusnow haddii `Self::Item` uu yahay `PartialOrd` oo keliya, laakiin uusan ahayn `Ord`, qeexitaanka kor ku xusan wuxuu muujinayaa in shaqadani ay soo celinayso `false` haddii ay jiraan laba shay oo is xiga aan la barbar dhigi karin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Checks haddii waxyaalaha aasaaska ah ee iterator this waxaa lagu kala soocaa iyadoo la isticmaalayo shaqada comparator siiyey.
    ///
    /// Halkii isticmaalaya `PartialOrd::partial_cmp`, shaqo this isticmaalaa function `compare` siiyo si loo ogaado gagadoonka laba walxood.
    /// Taas ka sokow, waxay u dhigantaa [`is_sorted`];arkaan ay waraaqo macluumaad dheeraad ah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Hubinta haddii walxaha ka soo baxa buuggan la kala soocayo iyadoo la adeegsanayo shaqeynta soo saaridda furaha.
    ///
    /// Halkii si toos ah loo barbar dhigi lahaa cunsurrayaasha, shaqadan ayaa isbarbar dhigaysa furayaasha astaamaha, sida lagu go'aamiyey `f`.
    /// Taas ka sokow, waxay u dhigantaa [`is_sorted`];arkaan ay waraaqo macluumaad dheeraad ah.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Fiiri [TrustedRandomAccess]
    // Magaca aan caadi ahayn waa in ay ka fogaadaan shilalka magacayga xallinta hab arki #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}