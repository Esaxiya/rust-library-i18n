//! siyaalaha dibadda Composable.
//!
//! Haddii aad naftaada helay ururinta ka mid ah nooc ka mid ah, oo loo baahan yahay in qalliin lagu samayn waxyaalaha aasaaska ah ee ururinta sheegay, inaad si dhakhso ah ordi doonaa galay 'iterators'.
//! Iterators waxaa si aad ah loogu adeegsadaa nambarka sarbeebta ah ee 'Rust code', sidaa darteed waxaa habboon in lala barto iyaga.
//!
//! Kahor sharraxaad dheeraad ah, aan ka hadalno sida qaybtani u qaabaysan tahay:
//!
//! # Organization
//!
//! Qaybtani waxay inta badan u habeysan tahay nooca:
//!
//! * [Traits] waa qayb xudunta: traits kuwaas oo qeexaya nooca iterators jira iyo waxa aad samayn karto iyaga la.Hababka traits kuwanu waa qiimihiisu gelinaya qaar ka mid waqti dheeraad ah waxbarasho galay.
//! * [Functions] siiyaan qaar ka mid ah siyaabaha waxtar leh in la abuuro qaar ka mid ah iterators aasaasiga ah.
//! * [Structs] had iyo jeer waa noocyada soo noqoshada ee qaababka kala duwan ee kujira barnaamijkan 'traits'.Badanaa waxaad ubaahantahay inaad fiiriso habka abuura `struct`, halkii aad kaheli laheyd `struct` laftiisa.
//! Wixii faahfaahin dheeraad ah oo ku saabsan sababta, eeg '[Hirgalinta Iterator](#hirgelinta-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Waa intaas!Aynu qodno daneeyeyaasha.
//!
//! # Iterator
//!
//! The qalbi iyo naf bay of module tani waa trait [`Iterator`] ah.muhimka ah ee [`Iterator`] u egtahay sidan oo kale:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Tilmaamuhu wuxuu leeyahay qaab, [`next`], oo markii la waco, soo celiya [``Xulasho ']' '<Item>``.
//! [`next`] soo laaban doonaa [`Some(Item)`] ilaa iyo inta ay jiraan xubno ka, iyo mar ay dhan la daalan, soo laaban doonaa `None` si ay u muujiyaan in siyaalaha la dhammeeyo.
//! iterators Individual dooran kartaa in siyaalaha u bilaabaan, iyo sidaas oo kale ugu yeeray [`next`] laga yaabaa ama laga yaabaa in aan ugu danbeyn u bilaabaan [`Some(Item)`] mar kale soo laabtay barta qaar ka mid ah (tusaale ahaan, arki [`TryIter`]).
//!
//!
//! [`Iterator`] 's qeexitaanka buuxa waxaa ka mid ah tiro ka mid ah hababka kale, laakiin waxay yihiin hababka default, dhisay on top of [`next`], iyo si aad u hesho lacag la'aan ah.
//!
//! Iterators sidoo kale composable, iyo waxa ee caadi ah in silsilad iyagii ku soo wada in la sameeyo noocyo badan oo adag of processing.Faahfaahin dheeraad ah ka eeg qaybta [Adapters](#adapters).
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Saddexda nooc ee siyaalaha
//!
//! Waxaa jira saddex hab caadi ah oo ka abuuri karaan iterators ka ururinta a:
//!
//! * `iter()`, taas oo ku celcelisa in ka badan `&T`.
//! * `iter_mut()`, taas oo ku celcelisa in ka badan `&mut T`.
//! * `into_iter()`, taas oo soo celinaysa ku badan `T`.
//!
//! Waxyaabo kala duwan oo maktabadda caadiga ah ayaa laga yaabaa inay hirgeliyaan mid ama saddex ka mid ah saddexda, meeshii ay ku habboon tahay.
//!
//! # Hirgelinta Iterator
//!
//! Abuuritaanka iterator ah oo adiga kuu gaar ah oo ku lug leh laba talaabo: abuuraya `struct` ah si uu u qabto gobolka iterator ee, ka dibna fulinta [`Iterator`] for `struct` in.
//! Tani waa sababta ay ugu jiraan waxyaabo badan oo 'qaab-dhismeed' ku jira qaybtan: waxaa jira hal mid oo ah soo-koobiye kasta iyo adabtarada soo-dhejiyeyaasha.
//!
//! Aynu ka dhigi iterator ah loo magacaabay `Counter` oo u tiriyo `1` in `5`:
//!
//! ```
//! // Marka hore, qaabdhismeedka:
//!
//! /// Hadal haye oo tiriya hal ilaa shan
//! struct Counter {
//!     count: usize,
//! }
//!
//! // waxaan dooneynaa in tiradeenu ay ka bilaabato mid, haddaba aan ku darno habka new() si aan u caawino.
//! // Tani si adag daruuri uma ahan, laakiin waa ku habboon tahay.
//! // Xusuusnow in aan ka bilaabayno `count` eber, waxaan ku arki doonnaa sababta hirgelinta `next()`'s hoosta.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Kadib, waxaan u hirgelinnaa `Iterator` `Counter`-keena:
//!
//! impl Iterator for Counter {
//!     // waxaan ku xisaabtameynaa isticmaalka
//!     type Item = usize;
//!
//!     // next() waa habka kaliya ee loo baahan yahay
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Kordhinta tirinteena.Tani waa sababta aan ugu bilownay eber.
//!         self.count += 1;
//!
//!         // Hubi si aad u aragto haddii aan dhahnaa tirinta dhammeeyayna ama ma.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Oo hadda waan isticmaali karnaa!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Wicitaanka [`next`] habkan wuxuu noqdaa mid soo noqnoqda.Rust leedahay dhisida ah oo wici kartaa [`next`] on your iterator, ilaa ay ka gaarayso `None`.Aan ka gudubno tan xigta.
//!
//! Sidoo kale ogsoonow in `Iterator` bixisaa fulinta default of hababka sida `nth` iyo `fold` oo wac `next` gudaha ah.
//! Si kastaba ha noqotee, sidoo kale waa suurtagal in la qoro hirgelinta qaababka qaababka sida `nth` iyo `fold` haddii qalabka wax lagu qoro uu ku xisaabtami karo si wax ku ool ah iyaga oo aan wicin `next`.
//!
//! # `for` siddo iyo `IntoIterator`
//!
//! Rust ee `for` Saan loop run ahaantii waa sonkor for iterators.Waa tan tusaalaha aasaasiga ah ee `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Tani daabacan doonaa mid ka mid ah tirada iyada oo shan, mid kasta oo ay line u gaar ah.Laakiin waxaad ku arki doontaa wax halkan: weligay wax ugama yeedhin vector-keena si aan u soo saarno soo-saare.Maxaa bixiya
//!
//! Maktabadda caadiga ah waxaa ku yaal trait oo wax loogu beddelayo soo noqnoqosho: [`IntoIterator`].
//! trait waxa uu leeyahay mid ka mid ah hab, [`into_iter`], taas oo badasha wax fulinta [`IntoIterator`] galay iterator ah.
//! Aynu mar kale eegno wareegga `for`, iyo waxa isku-duwaha u beddelayo:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sugars tan tan:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Marka hore, waxaan ugu yeernaa `into_iter()` qiimaha.Kadibna, waxaannu ku habboonaan doonnaa soo-celinta soo noqnoqota, wacaya [`next`] marar badan iyo ilaa aan ka aragno `None`.
//! Halkaa marka ay marayso, waxaan `break` ka baxnay wareegga, oo waxaan ku dhammeynay iterating.
//!
//! Halkan waxaa ku yaal hal xoogaa xeelad badan: maktabadda caadiga ah waxaa ku jira hirgelin xiiso leh oo ah [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! In si kale loo dhigo, oo dhan [`Iterator`] s fuliyo [`IntoIterator`], by kaliya isu soo laabtay.Tan macnaheedu waa laba waxyaalood:
//!
//! 1. Haddii aad qoraal [`Iterator`] ah, waxaad u isticmaali kartaa loop `for` ah.
//! 2. Haddii aad abuureyso ururinta, hirgelinta [`IntoIterator`] waxay u oggolaan doontaa ururintaada in loo isticmaalo wareegga loo yaqaan `for` loop'.
//!
//! # Iterate by tixraac
//!
//! Tan iyo [`into_iter()`] qaadataa `self` by qiimaha, iyadoo la isticmaalayo loop `for` a iterate in ka badan ka gubtay, ururinta in ururinta.Inta badan, waxaa laga yaabaa in aad rabto in aad iterate ka badan ururinta ah iyada oo aan wax baabbi'iya.
//! uruuriyaa badan ayaa bixiya hababka in ay bixiyaan iterators badan la tixraaci karo, conventionally yeedhay `iter()` iyo `iter_mut()` siday u kala horreeyaan,
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` wali waxaa leh shaqadan.
//! ```
//!
//! Haddii nooca ururinta `C` bixisaa `iter()`, waxaa inta badan sidoo kale fulisaa `IntoIterator` for `&C`, fulinta ah in kaliya oo ku baaqay in `iter()`.
//! Sidoo kale, ururinta `C` ee bixisa `iter_mut()` guud ahaan waxay fulisaa `IntoIterator` ee `&mut C` iyadoo loo wakiisho `iter_mut()`.Tani waxay awood u siineysaa habka gaaban:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // la mid ah `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // la mid ah `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Inkasta oo uu uruuriyaa badan bixiyaan `iter()`, oo dhan ma bixiyaan `iter_mut()`.
//! Tusaale ahaan, beddelashada furayaasha [`HashSet<T>`] ama [`HashMap<K, V>`] waxay ururinta gelin kartaa xaalad aan is-waafaqsanayn haddii fureyaasha fureyaashu is beddelaan, markaa ururintani waxay bixiyaan oo keliya `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Functions taas oo qaadan [`Iterator`] ah oo ku soo celi [`Iterator`] kale waxaa inta badan loo yaqaan 'adapters iterator', sida ay tahay nooc ka mid ah ay 'adabtarada
//! pattern'.
//!
//! adapters iterator Common waxaa ka mid ah [`map`], [`take`], iyo [`filter`].
//! Wixii dheeraad ah, fiiri ay waraaqo.
//!
//! Haddii iterator ah adabtarada panics, iterator waxay noqon doontaa in gobolka aan la cayimin (laakiin ammaan xasuusta).
//! gobolka waxaa sidoo kale ma hubo in la mid ah oo dhan versions of Rust joogaan, sidaa darteed waa in aad ka fogaato ku tiirsan qiimaha saxda ah by iterator ah oo argagax ku noqday.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (iyo iterator [adapters](#adapters)) yihiin * * caajis. Tani waxay ka dhigan tahay in kaliya la abuurayo ah iterator ma _do_ badan oo dhan. Wax run ahaantii dhacaya ilaa aad ka soo wici [`next`].
//! Tani mararka qaar waa il wareer marka la samaynayo iterator ah oo keliya, waayo, waxyeellooyin ay.
//! Tusaale ahaan, habka [`map`] wuxuu ku baaqayaa xiritaanka cunsur kasta oo ay ka soo baxdo:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Tani ma daabacan doonaa wax kasta oo la qiimeeyo, sida aynu abuuray oo keliya iterator ah, halkii la isticmaalayo.Isku-dubaridaha ayaa nooga digi doona hab-dhaqanka noocan ah:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Habka sarbeebta ah ee loo qoro [`map`] waxyeellooyinkeeda waa in la isticmaalo loox loo yaqaan `for` loop' ama la wac habka [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Hab kale oo caadi ah oo lagu qiimeeyo soo-celinta ayaa ah iyadoo la adeegsanayo habka [`collect`] si loo soo saaro urururin cusub.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Kiciyeyaashu maahan inay noqdaan kuwo kooban.Tusaale ahaan, kala duwan oo furan waa iterator ah aan la koobi karayn,
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Waxaa caadi ah in la isticmaalo adabtarada ku iterator [`take`] inuu ka soo leexdo iterator ah aan la koobi karayn galay mid ka mid ah uguna:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Tani daabacan doonaa lambarada `0` dhex `4`, mid kasta oo ay line u gaar ah.
//!
//! Xusuusnow in hababka on iterators aan la koobi karayn, xitaa kuwa taas oo ay sabab u la go'aamin karaa xisaab ahaan wakhtiga uguna, waxaa laga yaabaa in aan joojiyo.
//! Gaar ahaan, hababka sida [`min`], taas oo guud ahaan loo baahan yahay in la maro qayb kasta oo ka mid ah soo-saaraha, waxay u badan tahay inaysan si guul leh ugu laabanin qalab kasta oo aan dhammaad lahayn.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh maya!Wareeg aan dhammaad lahayn!
//! // `ones.min()` wuxuu keenaa wareeg aan dhammaad lahayn, markaa ma gaari doonno heerkan!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;