use crate::{iter::FusedIterator, ops::Try};

/// iterator An in weligiis soo Celin.
///
/// `struct` Tan waxaa loo abuuray by habka [`cycle`] ku [`Iterator`].
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // wareegtada wareega waa mid faaruq ah ama aan xad lahayn
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // si buuxda u dheji tirka hadda jira.
        // tani waa lagama maarmaan, maxaa yeelay, `self.iter` la madhin laga yaabaa in xataa marka `self.orig` ma aha
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // buuxiso wareegga a full, ilaalinta track ka mid ah in ordeen iterator madhan tahay ama aan.
        // waxaan u baahanahay inaan hore ku soo noqon lacala iterator madhan si looga hortago in loop ah aan la koobi karayn
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // No `fold` diidmada, maxaa yeelay, `fold` kama dhigo dareen badan `Cycle`, iyo waxaan waxba ma aan samayn karo ka khayr badan default ah.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}