//! Joogto ah oo gaar u ah nooca dhibic sabayn `f32`-saxda ah.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Tirooyin xisaab ahaan muhiim ah ayaa lagu bixiyaa qaybta hoose ee `consts`.
//!
//! Joogtada ah oo si toos ah loogu qeexay qaybtan (sida ay uga duwan tahay kuwa lagu qeexay qaybta hoose ee `consts`), koodh cusub ayaa halkii laga isticmaali lahaa istiraatiijiyadda la xidhiidha ee tooska loogu qeexay nooca `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Shucaaca ama saldhigga matalaadda gudaha ee `f32`.
/// Isticmaal [`f32::RADIX`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // habka loogu tala galay
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Tirada lambarro muhiim ah salka 2.
/// Isticmaal [`f32::MANTISSA_DIGITS`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // habka loogu tala galay
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Qiyaas ahaan lambarro muhiim ah oo kujira salka 10.
/// Isticmaal [`f32::DIGITS`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // habka loogu tala galay
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] qiimaha `f32`.
/// Isticmaal [`f32::EPSILON`] halkii.
///
/// Tani waa farqiga u dhexeeya `1.0` iyo lambarka xiga ee weyn ee matalaya.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // habka loogu tala galay
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Yar qiimaha `f32` uguna.
/// Isticmaal [`f32::MIN`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // habka loogu tala galay
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Yar qiimaha caadiga ah positive `f32`.
/// Isticmaal [`f32::MIN_POSITIVE`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // habka loogu tala galay
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Qiimaha ugu dambeeya ee `f32`.
/// Isticmaal [`f32::MAX`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // habka loogu tala galay
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Mid ka weyn awooda ugu yar ee suurtogalka ah ee 2 jibbaar.
/// Isticmaal [`f32::MIN_EXP`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // habka loogu tala galay
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Awoodda ugu badan ee suuragalka ah ee 2 jibbaar.
/// Isticmaal [`f32::MAX_EXP`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // habka loogu tala galay
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Awoodda ugu yar ee suurtogalka ah ee 10 jibbaar.
/// Isticmaal [`f32::MIN_10_EXP`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // habka loogu tala galay
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Awoodda ugu badan ee suurtagalka ah ee 10 jibbaar.
/// Isticmaal [`f32::MAX_10_EXP`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // habka loogu tala galay
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ma Number (NaN) ah.
/// Isticmaal [`f32::NAN`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // habka loogu tala galay
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Isticmaal [`f32::INFINITY`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // habka loogu tala galay
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Xaddidan xaddidan (−∞).
/// Isticmaal [`f32::NEG_INFINITY`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // habka loogu tala galay
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Joogtaynta xisaabta aasaasiga ah.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ku beddel xisaabaad joogto ah oo laga bilaabo cmath.

    /// Archimedes 'joogto ah (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Wareegga buuxa ee joogtada ah (τ)
    ///
    /// U dhigma 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Lambarka Euler ee (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Shucaaca ama saldhigga matalaadda gudaha ee `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Tirada lambarro muhiim ah salka 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Qiyaas ahaan lambarro muhiim ah oo kujira salka 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] qiimaha `f32`.
    ///
    /// Tani waa farqiga u dhexeeya `1.0` iyo lambarka xiga ee weyn ee matalaya.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Yar qiimaha `f32` uguna.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Yar qiimaha caadiga ah positive `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Qiimaha ugu dambeeya ee `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Mid ka weyn awooda ugu yar ee suurtogalka ah ee 2 jibbaar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Awoodda ugu badan ee suuragalka ah ee 2 jibbaar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Awoodda ugu yar ee suurtogalka ah ee 10 jibbaar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Awoodda ugu badan ee suurtagalka ah ee 10 jibbaar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ma Number (NaN) ah.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Xaddidan xaddidan (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Soocelinayaa `true` haddii qiimahani yahay `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` si cad looma heli karo libcore sababo la xiriira walaac laga qabo in la raaco, sidaa darteed hirgalintan waxaa loogu talagalay in si gaar ah loogu isticmaalo gudaha.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Soocelinayaa `true` haddii qiimahani yahay mid aan fiicnayn ama aan xad lahayn, iyo `false` haddii kale.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Soocelinayaa `true` haddii lambarkan aan la koobi karayn iyo `NaN` midna.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Looma baahna in si gooni ah loo maareeyo NaN: haddii isku yahay NaN, isbarbardhiggu run maahan, sida saxda ee la doonayo.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Soocelinayaa `true` haddii nambarku yahay [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Qiimayaasha u dhexeeya `0` iyo `min` waa Subnormal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Soocelinayaa `true` haddii nambarku uusan eber ahayn, aan dhammaad lahayn, [subnormal], ama `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Qiimayaasha u dhexeeya `0` iyo `min` waa Subnormal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Soocelisaa qeybta dhibcaha sabaynaysa ee lambarka.
    /// Haddii hal guri kaliya la tijaabinayo, guud ahaan way ka dhaqso badan tahay in la isticmaalo saadaaliyaha gaarka ah bedelkiisa.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Sooceliyaa `true` haddii `self` uu leeyahay calaamad togan, oo ay kujirto `+0.0`, ``NaN`s oo leh calaamado wanaagsan oo aan fiicnayn.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Sooceliyaa `true` haddii `self` uu leeyahay calaamado diidmo ah, oo ay kujiraan `-0.0`, ``NaN`s oo wata calaamado taban oo aan xaddidnayn.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 ayaa leh: isSignMinus(x) waa run haddii iyo haddii x ay leedahay calaamado diidmo ah.
        // isSignMinus wuxuu quseeyaa eber iyo NaN sidoo kale.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Waxay qaadataa (inverse) isdhaafsiga lambarka, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Waxay u badashaa shucaac ilaa darajo.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // U isticmaal mid joogto ah saxsanaanta wanaagsan.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Darajooyin ayuu u beddelaa radians.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Soocelinaya ugu badnaan labada lambar.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Haddii doodaha midkood uu yahay NA, markaa muranka kale ayaa la soo celiyaa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Sooceliyaa uguyar labada lambar.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Haddii doodaha midkood uu yahay NA, markaa muranka kale ayaa la soo celiyaa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Wareeg xagga eber iyo kuweeda in nooc kasta oo abyoonaha heer hoose ah, haddii loo maleeyo in qiimaha waa uguna iyo qallalku in nooca in.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Qiimaha waa inuu:
    ///
    /// * Ha noqonin `NaN`
    /// * Ma noqon doonto mid aan la koobi karayn
    /// * Noqo representable in nooca soo laabtay `Int`, ka dib markii truncating off ay qayb jajab
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// U gudbinta ceeriin `u32`.
    ///
    /// Tani hadda waxay lamid tahay `transmute::<f32, u32>(self)` dhammaan meerayaasha.
    ///
    /// U fiirso `from_bits` si aad uga dooddo xoog-u-qaadidda hawlgalkan (ma jiraan arrimo badan).
    ///
    /// Xusuusnow in shaqadani ay ka duwan tahay ridaha `as`, oo isku dayaysa inay ilaaliso qiimaha * lambar, oo aan ahayn qiimaha waxoogaa yar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() ma shubay!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // BADBAADADA: `u32` waa qaab duug ah oo duug ah oo caadi ah sidaa darteed marwalba waan u gudbin karnaa
        unsafe { mem::transmute(self) }
    }

    /// Ka gudbinta ceeriin ee ka socota `u32`.
    ///
    /// Tani hadda waxay lamid tahay `transmute::<u32, f32>(v)` dhammaan meerayaasha.
    /// Waxay soo baxday inay tani tahay mid si la yaab leh loo qaadan karo, laba sababood awgood:
    ///
    /// * Doomaha iyo Hantidhowrka waxay leeyihiin isku mid ahaansho dhammaan dhulalka la taageero.
    /// * IEEE-754 si hufan ayaa u qeexaysa qaabka yar ee sabeynta.
    ///
    /// Si kastaba ha noqotee waxaa jira hal digniin: kahor qaabkii 2008 ee IEEE-754, sida loo turjumo NaN waxyeellada yar dhab ahaan lama cayimin.
    /// Meelaha badankood (gaar ahaan x86 iyo ARM) waxay soo qaateen tarjumaadda ugu dambayntii la jaangooyay sanadkii 2008, laakiin qaarna ma (gaar ahaan MIPS).
    /// Natiijo ahaan, dhammaan calaamadaha NaNs ee MIPS waa NaNs deggan x86, iyo dhinaca kale.
    ///
    /// Halkii laga isku dayi lahaa in la ilaaliyo calaamadaha-ness cross-platform, hirgelintaani waxay door bidaa in la ilaaliyo jajabyada saxda ah.
    /// Tani waxay ka dhigan tahay in wixii lacag bixin ah ee lagu qoro NaN-yada la keydin doono xitaa haddii natiijada qaabkan looga diro shabakada mashiinka x86 illaa mid MIPS ah.
    ///
    ///
    /// Haddii natiijooyinka habkan kaliya lagu maareynayo isla qaab-dhismeedka iyaga soo saaray, markaa ma jiraan wax welwel ah oo laga qaadi karo.
    ///
    /// Hadday wax soo gelintu ahayn NaN, markaa ma jiro walaac la qaadi karo.
    ///
    /// Haddii aadan dan ka lahayn calaamadaha (aad bay u badan tahay), markaa ma jiro walaac la qaadi karo.
    ///
    /// Xusuusnow in shaqadani ay ka duwan tahay ridaha `as`, oo isku dayaysa inay ilaaliso qiimaha * lambar, oo aan ahayn qiimaha waxoogaa yar.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // BADBAADADA: `u32` waa qaab duug ah oo duug ah sidaa darteed marwalba waan ka gudbi karnaa
        // Waxaa soo baxday in arrimaha nabadgelyada ee sNaN ay ahaayeen kuwo xad dhaaf ah!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Ku soo celi matalaada xusuusta ee lambarkan dhibic sabayn sida soo noqnoqoshada ah ee loo yaqaan 'big-endian (network) byte byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// U soo celi matalaada xusuusta ee lambarkan dhibic sabayn ahaan u soo noqnoqda byte bayd yar oo amar ah byte-yar
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Ku soo celi matalaada xusuusta ee lambarkan dhibic sabayn ahaan u soo noqnoqda qaab ahaan bate ahaan.
    ///
    /// Maaddaama loo adeegsanayo ballaadhinta barta bar-tilmaameedka bartilmaameedka, koodhka la qaadan karo waa inuu adeegsadaa [`to_be_bytes`] ama [`to_le_bytes`], sida ku habboon, halkii.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Ku soo celi matalaada xusuusta ee lambarkan dhibic sabayn ahaan u soo noqnoqda qaab ahaan bate ahaan.
    ///
    ///
    /// [`to_ne_bytes`] waa in laga doorbido tan markasta oo ay suurta gal tahay.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // BADBAADADA: `f32` waa qaab duug ah oo duug ah oo caadi ah sidaa darteed marwalba waan u gudbin karnaa
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Abuur qiime dhibic sabayn ka tarjumaya matalaadeeda oo ah baaxad weyn oo endian ah.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Abuur qiime dhibic sabayn ka tarjumaya matalaaddeeda oo ah baaxad yar oo endian ah.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Abuur qiime dhibic sabayn ka tarjumaya matalaaddeeda oo ah baaxad weyn oo ka timaadda waddanka hooyo.
    ///
    /// Maaddaama loo adeegsanayo ballaadhinta barta bar-tilmaameedka bartilmaameedka, koodh la qaadan karo waxay u badan tahay inuu doonayo inuu isticmaalo [`from_be_bytes`] ama [`from_le_bytes`], sida ku habboon halkii.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Waxay soocelisaa amar kadhexeeya nafta iyo qiyamka kale.
    /// Si ka duwan marka la barbardhigo heerka qayb ahaan u dhexeeya tirooyinka dhibic sabayn, marka la barbardhigo tan mar walba soo saarta xigsiin ah si waafaqsan in la saadaalin karo totalOrder sida ku qeexan IEEE 754 (2008 dib u eegis) sabayn caadiga ah dhibic.
    /// Qiimaha waxaa lagu dalbadaa sida soo socota:
    /// - NaN aamusan
    /// - seylaanyenta xun NAN
    /// - Xaddidnaan taban
    /// - Tirooyinka taban
    /// - Tirooyinka aan caadiga ahayn ee xun
    /// - Eber xun
    /// - Eber macquul ah
    /// - lambarada subnormal Positive
    /// - Tirooyin togan
    /// - Xaddidan la'aan
    /// - Positive seylaanyenta NAN
    /// - NaN deggan
    ///
    /// Ogsoonow in shaqadani aysan had iyo jeer ku raacsaneyn hirgelinta [`PartialOrd`] iyo [`PartialEq`] ee `f32`.Gaar ahaan, waxay u arkaan eber diidmo iyo mid togan inay siman yihiin, halka `total_cmp` uusan u arag.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Haddii ay jiraan wax diidmo ah, rog dhammaan qeybaha oo dhan marka laga reebo calaamadda si aad u gaarto qaab isku mid ah oo ah laba isugeyn oo dhammaystiran
        //
        // Maxay tani u shaqeysaa?IEEE 754 sabeyntu waxay ka kooban tahay saddex aag:
        // Saxeex xoogaa, jibbaar iyo mantissa.Qaybaha jibbaarada iyo mantissa guud ahaan waxay leeyihiin hanti ay amarkooda xoogaa la mid yahay baaxadda tiro halka cabirka lagu qeexay.
        // Baaxadda sida caadiga ah laguma qeexin qiyamka NaN, laakiin IEEE 754 totalOrder wuxuu qeexayaa qiyamka NaN sidoo kale in la raaco amar yar.Tani waxay keenaysaa amar lagu sharraxay faallooyinka doc.
        // Si kastaba ha noqotee, matalaadda baaxadda ayaa la mid ah tirooyinka taban iyo kuwa togan-kaliya calaamadda waxoogaa ayaa ka duwan.
        // Si aan si fudud isbarbar dhig ugu sameeyno sabeynta sida lambarada la saxeexay, waxaan u baahanahay inaan rogno jibbaarada iyo mantissa bits haddii ay dhacdo tirooyin taban.
        // Waxaan si wax ku ool ah ugu beddeleynaa nambarada foomka "two's complement".
        //
        // Si loo sameeyo rogrogmada, waxaan dhisaynaa maaskaro iyo XOR oo ka soo horjeeda.
        // Waxaan si layaab leh u xisaabineynaa maaskaro "all-ones except for the sign bit" ah oo ka imanaya qiyamka saxeexan ee saxan: saxeexa saxda ah-wuxuu dheereeyaa isku-darka, sidaa darteed waxaan "fill" maaskarada ugu jirnaa calaamado goosgoos ah, ka dibna waxaan u beddeleynaa calaamadeyn la'aan si aan u riixno wax yar oo eber ah.
        //
        // Qiyamka togan, maaskaradu waa dhammaan eber, markaa waa iska diid.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Ku xaddid qiimaha wakhti go'an mooyee mooyee.
    ///
    /// Sooceliyaa `max` haddii `self` waa ka weyn yahay `max`, iyo `min` haddii `self` ka yar tahay `min`.
    /// Haddii kale tani waxay soo celinaysaa `self`.
    ///
    /// Ogsoonow in shaqadani soo celinayso NaN haddii qiimaha hore uu ahaa NaN sidoo kale.
    ///
    /// # Panics
    ///
    /// Panics haddii `min > max`, `min` uu yahay NaN, ama `max` uu yahay NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}