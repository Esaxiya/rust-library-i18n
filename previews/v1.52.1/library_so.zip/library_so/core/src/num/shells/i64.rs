//! Joogto u ah nooca tirakoobka ee 64-bit la saxiixay.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Koodhadh cusub waa inuu si toos ah ugu adeegsadaa joogtooyinka la socda nooca aasaasiga ah.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }