//! Joogtada ah nooca isku-darka ah ee 8-bit aan saxeexnayn.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Koodhadh cusub waa inuu si toos ah ugu adeegsadaa joogtooyinka la socda nooca aasaasiga ah.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }