//! Joogto u ah nooca integer-ga ah ee 16-bit la saxiixay.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Koodhadh cusub waa inuu si toos ah ugu adeegsadaa joogtooyinka la socda nooca aasaasiga ah.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }