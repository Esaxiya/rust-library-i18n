//! Joogto u ah nooca isku-darka 32-bit ee aan saxeexnayn.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Koodhadh cusub waa inuu si toos ah ugu adeegsadaa joogtooyinka la socda nooca aasaasiga ah.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }