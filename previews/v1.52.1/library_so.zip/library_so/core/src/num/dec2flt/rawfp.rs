//! Waxoogaa isdaba-marin ah oo ku saabsan sababaha wanaagsan ee IEEE 754.Tirooyinka taban ma aha mana u baahna in wax laga qabto.
//! Nambarada dhibcaha ee sabeeya ee caadiga ahi waxay leeyihiin matalaad qaynuun ah sida (frac, exp) sida oo ah qiimaha uu yahay 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) halkaas oo N ay tahay tirada jajabka.
//!
//! Submormals-yada wax yar ayaa ka duwan oo yaab leh, laakiin isla mabda'a ayaa khuseeya.
//!
//! Halkan, si kastaba ha noqotee, waxaan u metelnaa iyaga (sig, k) leh f togan, sida in qiimaha uu yahay f *
//! 2 <sup>e</sup> .Ka sokow sameynta "hidden bit" cad, tani waxay ku beddeleysaa jibbaaraha waxa loogu yeero mantissa shift.
//!
//! Si kale u dhig, sida caadiga ah sabaynta waxaa loo qoraa (1) laakiin halkan waxaa loogu qoray (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Waxaan ugu yeernaa (1)**matalaad jajab ah** iyo (2) ah **matalaad aan caadi aheyn**.
//!
//! Shaqooyin badan oo ku jira qaybtani waxay kaliya qabtaan lambarrada caadiga ah.Jadwalka dec2flt wuxuu si qumman u qaadaa waddo gaabis ah oo caalami ah (Algorithm M) tiro aad u yar oo aad u tiro badan.
//! Algorithm-kaasi wuxuu u baahan yahay oo keliya next_float() oo wax ka qabta dabeecadaha hoose iyo eber.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Caawiye trait si looga fogaado nuqul ka sameysashada asal ahaan dhammaan nambarka beddelashada ee `f32` iyo `f64`.
///
/// Eeg faallooyinka dougga qaybta waalidka sababta ay tani muhiim ugu tahay.
///
/// **Waa in waligiis** aan waligood loo hirgalin noocyada kale ama loo isticmaalin meel ka baxsan moduleka dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Nooca ay adeegsadaan `to_bits` iyo `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Waxay u gudbisaa tiro caymis ah tiro integer ah.
    fn to_bits(self) -> Self::Bits;

    /// Waxay ka sameysaa tarjumaad cayriin integer.
    fn from_bits(v: Self::Bits) -> Self;

    /// Sooceliyaa qaybta ay lambarkan kudhacdo.
    fn classify(self) -> FpCategory;

    /// Waxay soo celisaa mantissa, jibbaar ahaan iyo saxeex ahaan sida tiro ahaan.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Go'aanka sabeynta.
    fn unpack(self) -> Unpacked;

    /// Kufsiyo ka kooban tiro yar oo si sax ah loo matali karo.
    /// Panic haddii tirada aan la matali karin, koodhka kale ee ku jira qaybtani waxay hubineysaa inaanay taasi u oggolaan weligeed.
    fn from_int(x: u64) -> Self;

    /// Wuxuu ka helayaa qiimaha 10 <sup>e</sup> miiska horay loo xisaabiyey.
    /// Panics for `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Muxuu magacu sheegaa.
    /// Way fududahay in la adkeeyo koodhka marka loo eego xayeysiinta waxyaabaha muhiimka ah iyo rajada LLVM si joogto ah u laabo.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Muxaafid ku xiran tirooyinka tobanle ee wax-soo-saarka aan soo saari karin qulqulka ama eber ama
    /// subnormals.Malaha jajab tobanlaha qiimaha ugu badan ee caadiga ah, markaa magaca.
    const MAX_NORMAL_DIGITS: usize;

    /// Marka tirada ugu badan ee jajab tobanlaha ay leedahay meel qiime ka weyn tan, tirada waxaa hubaal ah in lagu koobayo tiro la'aan.
    ///
    const INF_CUTOFF: i64;

    /// Marka god tobanle weyn ugu leeyahay qiime-rugeedka ka yar this a, tirada hubaal waa koobay eber.
    ///
    const ZERO_CUTOFF: i64;

    /// Tirada jajabyada jibbaarada.
    const EXP_BITS: u8;

    /// Tirada waxoogaa yar oo muhiim ah,*oo ay ku jiraan* xoogaa qarsoon.
    const SIG_BITS: u8;

    /// Tirada gelinno significand ah,*marka laga reebo* qayb ka qarsoon.
    const EXPLICIT_SIG_BITS: u8;

    /// Joogtada ugu sarreysa xagga sharciga ee matalaadda jajabka ah.
    const MAX_EXP: i16;

    /// Joogtada ugu yar ee sharci ku metelaysa jajab, marka laga reebo submormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` matalaad lama huraan ah, yacni, wareejinta la adeegsaday.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` habaysan (yacni, eexasho miisaaman)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` matalaad lama huraan ah, yacni, wareejinta la adeegsaday.
    const MIN_EXP_INT: i16;

    /// Astaamaha ugu sarreeya ee caadiga ah ee matalaadda muhiimka ah.
    const MAX_SIG: u64;

    /// Waxyaabaha ugu yar ee caadiga ah ee matalaadda muhiimka ah.
    const MIN_SIG: u64;
}

// Badanaa shaqo-helid loogu talagalay #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Waxay soo celisaa mantissa, jibbaar ahaan iyo saxeex ahaan sida tiro ahaan.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Eex jibbaaranaha + mantissa beddelka
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ma hubo in `as` uu si sax ah ugu wareegayo dhamaan meheradaha.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Waxay soo celisaa mantissa, jibbaar ahaan iyo saxeex ahaan sida tiro ahaan.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Eex jibbaaranaha + mantissa beddelka
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ma hubo in `as` uu si sax ah ugu wareegayo dhamaan meheradaha.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Waxay u rogeysaa `Fp` nooca mashiinka ugu dhow ee sabeeya.
/// Wax ka qaban maayo natiijooyinka aan caadiga ahayn.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f waa 64 xoogaa, marka xe wuxuu leeyahay isbedel mantissa ah 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Ku meer meeris ah 64-bit xoogaa yar oo T::SIG_BITS ah nus-ilaa-xitaa.
/// Ma xamili karo jibbaar xad dhaaf ah.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Isku hagaaji wareegga mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Ka soo horjeedka `RawFloat::unpack()` ee tirooyinka caadiga ah.
/// Panics haddii muhiimadda ama jibbaarku aanu ansax u ahayn tirooyinka caadiga ah.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Ka saar xoogaa qarsoon
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ku hagaaji jibbaaraha dhinac u janjeersha iyo isbeddelka mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Ka tag calaamadda waxoogaa ah 0 ("+"), lambarradeennu dhammaantood way wanaagsan yihiin
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Samee wax aan caadi ahayn.Mantissa ah 0 waa la oggol yahay waxayna dhistaa eber.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Jibbaarlaha loodiray waa 0, calaamadda inyarna waa 0, marka waa inaan dib u tarjunaa jajabyada.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Qiyaas bignum leh Fp.Wareegyada ku dhex jira 0.5 ULP leh nus-ilaa-xitaa.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Waxaan jareynaa dhammaan jajabyada kahor tusmada `start`, ie, waxaan si sax ah ugu wareejinnaa qaddar `start` ah, marka tani sidoo kale waa jibbaaraha aan u baahan nahay.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Wareega (half-to-even) waxay kuxirantahay jajabyada la jarjaray.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Wuxuu helaa nambarka ugu weyn ee sabaynta si adag uga yar dooda.
/// Ma xamili karo submormals-ka hoose, eber, ama jibbaarrada hoostooda mara
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Soo hel lambarka ugu sabayn yar ee si xoog leh uga weyn dooda.
// Hawlgalkani waa mid dheregsan, ie, next_float(inf) ==inf.
// Si ka duwan inta badan koodhkan cutubkan, shaqadani waxay qabataa eber, waxyaabo dabiici ah, iyo tiro yar.
// Si kastaba ha noqotee, sida dhammaan koodhadhka kale ee halkan ku yaal, wax kama qabanayso NaN iyo tirooyinka taban.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Tani waxay umuuqataa inay aad ufiicantahay inay run noqoto, laakiin way shaqaysaa.
        // 0.0 waxaa loo qaabeeyey sida erayga oo dhan-eber.Submormals-ku waa 0x000m ... m meesha m ay tahay mantissa.
        // Gaar ahaan, waxa ugu yar ee aan caadiga ahayn waa 0x0 ... 01 kan ugu weyna waa 0x000F ... F.
        // Tirada ugu yar ee caadiga ahi waa 0x0010 ... 0, markaa kiiskan geeska ahi sidoo kale wuu shaqeeyaa.
        // Haddii korodhku ka buuxo mantissa, waxoogaa qaadku wuxuu kordhiyaa jibbaaraha sida aan doonayno, qaniinyada mantissa-na waxay noqotaa eber.
        // Sababtoo ah heshiiskii qarsoonaa ee qarsoonaa, tani sidoo kale waa waxa aan dooneyno!
        // Ugu dambeyntiina, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}