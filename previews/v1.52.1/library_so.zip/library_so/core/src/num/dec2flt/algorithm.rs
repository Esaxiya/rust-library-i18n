//! The algorithms kala duwan ka warqadda.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Tirada qeybaha muhiimka ah ee Fp
const P: u32 = 64;

// Waxaan si fudud u keydinaa qiyaasta ugu fiican ee *dhammaan* jibbaarayaasha, sidaas darteed isbeddelka "h" iyo xaaladaha la xiriira waa laga tagi karaa.
// Tani waxay ka ganacsataa waxqabadka laba kiiloomitir oo boos ah.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Dhismooyinka badankood, howlaha dhibcaha sabaynta waxay leeyihiin cabbir xoogaa cad, sidaa darteed saxnaanta xisaabinta waxaa lagu go'aamiyaa iyadoo lagu saleynayo hawlgal ahaan.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86, x87 FPU waxaa loo adeegsadaa howlaha sabeynta haddii kordhinta SSE/SSE2 aan la heli karin.
// x87 FPU wuxuu ku shaqeeyaa 80 qaybood oo sax ah asal ahaan, taas oo macnaheedu yahay in hawlgallada ay ku wareegi doonaan illaa 80 qaybood oo keenaya isugeyn labalaab ah inay dhacdo markii qiimaha ugu dambeyntii loo matalayo sidii
//
// 32/64 xoogaa qiimeyn dul sabayn ah.Si tan looga gudbo, ereyga xakamaynta FPU ayaa loo dejin karaa si xisaabinta loogu sameeyo saxsanaanta la rabay.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Qaab dhisme loo adeegsaday in lagu ilaaliyo qiimaha asalka ah ee ereyga xakamaynta FPU, si markaa dib loogu soo celiyo markii qaab dhismeedka la tuuro.
    ///
    ///
    /// x87 FPU waa diiwaangelin 16-yar oo goobahoodu yihiin sidan soo socota:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dukumiintiyada dhammaan beeraha waxaa laga heli karaa Buugga Soosaaraha Barnaamijka IA-32 Architectures Software Developer (Volume 1).
    ///
    /// Goobta kaliya ee ku habboon koodhka soo socdaa waa PC, Control Precision.
    /// Goobtani waxay go'aamisaa saxsanaanta hawlgallada ay fulisay FPU.
    /// Waxaa loo dejin karaa:
    ///  - 0b00, hal sax ah ie, 32-jajab
    ///  - 0b10, labo sax ah ie, 64-jajab
    ///  - 0b11, laba jibaarid la dheereeyey ie, 80-jajab (xaalad caadi ah) Qiimaha 0b01 waa la hayaa mana aha in la isticmaalo.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // BADBAADADA: tilmaamaha `fldcw` ayaa la hubiyey si ay awood ugu yeeshaan inay si sax ah ula shaqeeyaan
        // wixii `u16` ah
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Waxaan u adeegsaneynaa ATT syntax si aan u taageerno LLVM 8 iyo LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Qeexaa qaybta saxda ah ee FPU ilaa `T` waxayna soo celisaa `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Xisaabi qiimaha goobta xakamaynta saxnaanta ee ku habboon `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 jajab
            8 => 0x0200, // 64 jajab
            _ => 0x0300, // ugu talagal, 80 jajab
        };

        // Hel qiimaha asalka ah ee ereyga xakamaynta si aad hadhow u soo celiso, markii qaabdhismeedka `FPUControlWord` la tuuro AMMAAN: Tilmaamaha `fnstcw` ayaa la hubiyey si ay awood ugu yeeshaan inay si sax ah ula shaqeeyaan `u16` kasta
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Waxaan u adeegsaneynaa ATT syntax si aan u taageerno LLVM 8 iyo LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // U dhig ereyga xakamaynta saxda saxda ah.
        // Tan waxaa lagu gaaraa iyadoo la qarinayo saxnimadii hore (xoogaa 8 iyo 9, 0x300) laguna beddelo calanka saxda ah ee kor lagu xisaabiyey.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Wadada ugu dhakhsaha badan ee Bellerophon iyadoo la adeegsanayo iskudhaf makiinado cabbir ah iyo sabayn.
///
/// Tan waxaa loo soosaaray hawl gooni ah si markaa la isugu dayi karo kahor dhismaha bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Waxaan isbarbar dhigeynaa qiimaha saxda ah ee MAX_SIG meel udhaw dhamaadka, tani waa uun diidmo deg deg ah, oo raqiis ah (sidoo kale waxay ka xoreyneysaa inta kale ee koodhka walwalka ku saabsan qulqulka).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Wadada ugu dhakhsaha badan waxay kuxirantahay xisaabta oo lagu soo koobo tirada saxda ah ee qeybaha iyada oo aan la helin wareeg dhexdhexaad ah.
    // x86 (oo aan lahayn SSE ama SSE2) tani waxay u baahan tahay saxnaanta x87 FPU xidhmooyin si loo beddelo si ay si toos ah ugu wareegto xoogaa 64/32.
    // Hawsha `set_precision` waxay daryeeshaa dejinta saxda ah ee qaabdhismeedka dhismaha oo u baahan dejinta iyadoo la beddelayo xaaladda caalamiga ah (sida ereyga xakamaynta ee x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Kiiska e <0 looma laabi karo branch kale.
    // Awoodaha taban waxay keenaan qayb jajab ah oo soo noqnoqota oo binary ah, oo la soo koobay, taas oo keenta khaladaad dhab ah (oo mararka qaarkood aad u muhiim ah!) Natiijada ugu dambaysa.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon waa nambarka aan muhiimka ahayn ee lagu cadeeyo falanqaynta tirada aan yareyn.
///
/// Waxay ku wareegsan tahay `` f '' dul sabeyn leh 64 xoogaa muhiimad ah kuna dhufanaysa ugu dhowaanshaha ugu wanaagsan ee `10^e` (isla qaabkeeda sabeynta).Tani waxay badanaa ku filan tahay in la helo natiijada saxda ah.
/// Si kastaba ha noqotee, marka natiijadu u dhowdahay kalabar inta udhaxeysa laba dabaq oo (ordinary) ah, qalad isku-darka isku-darka isku-dhufashada laba qiyaasood waxay ka dhigan tahay in natiijada ay ka bixi karto xoogaa yar.
/// Markay taasi dhacdo, Algorithm-ka is-bedbeddelaya ayaa waxyaabaha hagaajiya.
///
/// Wareejinta gacanta ee "close to halfway" waxaa si sax ah loogu sameeyey falanqaynta tirada ee warqadda.
/// Erayada Clinger:
///
/// > Slop, oo lagu muujiyey cutubyada ugu yar ee muhiimka ah, waa mid loo wada dhan yahay oo loogu talagalay qaladka
/// > urursan inta lagu guda jiro xisaabinta barta sabeynta ee kudhowaad f * 10 ^ e.(Slop waa
/// > kuma xirna qaladka runta ah, laakiin wuxuu xaddidaa farqiga udhaxeeya z iyo
/// > Qiyaasta ugu fiican ee suurtogalka ah ee adeegsata qaybo yar oo muhiim ah.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Kiisaska abs(e) <log5(2^N) waxay kujiraan fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Miyuu u janjeeraa mid ballaaran oo isbeddel lagu samayn karo markii la isku soo koobayo?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Aligorid algorithm ah oo hagaajinaya qiyaasta dhibcaha sabaynta ee `f * 10^e`.
///
/// Jaangooyooyin kastaa waxay helayaan hal cutub oo ah meesha ugu dambeysa, taas oo dabcan si aad ah u qaadata waqti dheer si ay isugu soo ururto haddii `z0` xitaa si khafiif ah u baxo.
/// Nasiib wanaag, markii loo isticmaalo dib-u-dhac ku yimaada Bellerophon, qiyaasta bilowga ah waa la joojiyaa ugu badnaan hal ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Soo hel tirooyin wax ku ool ah `x`, `y` sida in `x / y` uu yahay `(f *10^e) / (m* 2^k)`.
        // Tani ma aha oo kaliya inay iska ilaalineyso wax ka qabashada astaamaha `e` iyo `k`, waxaan sidoo kale baabi'ineynaa awooda laba wadaagga ah ee `10^e` iyo `2^k` si aan tirada uga dhigno mid yar.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Tan waxaa loo qoraa xoogaa wareer ah maxaa yeelay bignumyadeenu ma taageeraan tirooyinka taban, sidaa darteed waxaan u adeegsannaa qiimaha saxda ah + macluumaadka saxiixa.
        // Isku dhufashada m_digits ma buuxin karto.
        // Haddii `x` ama `y` ay weyn yihiin oo aan u baahanahay inaan ka walwalsano qulqulka, ka dib iyaguna wey balaaran yihiin in `make_ratio` uu u yareeyay jajabka qayb 2 ^ 64 ama ka badan ah.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Ha u baahnayn x mar dambe, badbaadi clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Weli waxaad u baahan tahay y, nuqul ka samee.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Marka la eego `x = f` iyo `y = m` halka `f` ay u taagan tahay lambar tobanle aqbal ahaan sidii caadiga ahayd iyo `m` waa muhiimadda qiyaasta dhibcaha sabaynaysa, ka dhig saamiga `x / y` inuu la mid yahay `(f *10^e) / (m* 2^k)`, oo laga yaabo inay hoos u dhigto awood ay labaduba leeyihiin.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, marka laga reebo in aan yareeyo jajabka xoogga qaar ka mid ah labada.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Tani ma buuxsami karto maxaa yeelay waxay u baahan tahay `e` togan iyo `k` diidmo ah, taas oo ku dhici karta oo keliya qiyamka aadka ugu dhow 1, taas oo macnaheedu yahay in `e` iyo `k` ay isbarbardhig ahaan noqon doonaan kuwo aad u yar.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Tani sidoo kale ma buuxin karto, kor ka eeg.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), mar labaadna ku yaraynaya awood guud oo ah laba.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Fikrad ahaan, Algorithm M waa habka ugu fudud ee tobanle loogu badalo sabayn.
///
/// Waxaan sameyneynaa saamiga u dhigma `f * 10^e`, ka dibna ku tuurayno awoodo labo illaa ay ka siineyso muhiimadda sabaynta.
/// Jinka binary-ga ah `k` waa tirada jeer ee aan ku dhufannay tiro ama hooseeyaha labo, ie, mar walba `f *10^e` wuxuu la mid yahay `(u / v)* 2^k`.
/// Markii aan ogaanay muhiimad, waxaan kaliya ubaahanahay inaan ku wareejino annaga oo baarayna qaybta ka dhiman, taas oo lagu sameeyo howlaha caawinta ee hoosta ka hooseeya.
///
///
/// Algorithm-kaani waa mid aad u gaabis ah, xitaa marka la fiiriyo waxa lagu sharaxay `quick_start()`.
/// Si kastaba ha noqotee, waa midka ugu fudud ee algorithms si loo waafajiyo qulqulka, qulqulka, iyo natiijooyinka aan caadiga ahayn.
/// Hirgelintaani waxay la wareegeysaa markii Bellerophon iyo Algorithm R ay buuxdhaafaan.
/// Soo helida qulqulka qulqulka iyo qulqulka waa fududahay: Qiyaasta wali ma ahan mid muhiimad gaar ah u leh, hadana jibbaaraha minimum/maximum waa la gaaray.
/// Marka laga hadlayo qulqulka, waxaan si fudud ugu laabaneynaa xad la'aan.
///
/// Wax ka qabashada qulqulka hoosta iyo subnormals-ka ayaa khiyaamo badan.
/// Hal dhibaato oo weyn ayaa ah, iyadoo leh jibbaaraha ugu yar, saamiga laga yaabo inuu weli aad uga weyn yahay muhiimad ahaan.
/// Faahfaahin ka eeg underflow().
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME habeynta suurtagalka ah: guud guud big_to_fp si aan u sameyn karno wax u dhigma fp_to_float(big_to_fp(u)) halkan, kaliya iyada oo aan la kala qaadin labalaab.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Waxaan leenahay in ay joojiyaan at jibbaarada ugu yar, haddii aan sugno illaa `k < T::MIN_EXP_INT`, ka dibna waxaan ku noqon lahaa off by qodob ka mid ah labada.
            // Nasiib darrose taasi waxay ka dhigan tahay inaan gaar u qaadanno lambarro caadi ah oo leh jibbaaraha ugu yar.
            // FIXME waxay heshaa qaab ka qurux badan, laakiin samee tijaabada `tiny-pow10` si loo hubiyo inay runti sax tahay!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Ka boodo inta badan soo noqnoqoshada algorithm M adoo hubinaya dhererka yara.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Dhererka waxoogaa waa qiyaasta salka laba logarithm, iyo log(u / v) = log(u), log(v).
    // Qiyaasta waa la joojiyaa ugu badnaan 1, laakiin had iyo jeer waa la qiyaasaa, sidaas darteed qaladka log(u) iyo log(v) waa isku calaamad oo waa la joojiyaa (haddii labaduba waaweyn yihiin).
    // Sidaa darteed qaladka log(u / v) waa ugu badnaan sidoo kale.
    // Qiyaasta bartilmaameedka ayaa ah halka u/v ay ku jirto muhiimad gaar ah.Sidaa awgeed xaaladdeenna joojinta waa log2(u / v) oo ah xoogaa muhiim ah, plus/minus mid.
    // FIXME Markaad fiiriso xoogaa labaad waxay hagaajin kartaa qiyaasta oo ay ka fogaan kartaa xoogaa kala qeybsanaan ah.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Hoos u qulqulaya ama aan caadi ahayn.U daa shaqada ugu weyn.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Buuxdhaafiyay.U daa shaqada ugu weyn.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Saamigu maaha mid muhiimad gaar ah leh oo leh jibbaaraha ugu yar, sidaa darteed waxaan u baahanahay inaan soo koobno jajabka xad-dhaafka ah oo aan jaangooyaha u jaangooyo si waafaqsan.
    // Qiimaha dhabta ah hadda wuxuu umuuqdaa sidan:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(wakiil rem)
    //
    // Sidaa darteed, markay goosgoosyada la soo koobay yihiin!= 0.5 ULP, iyagu waxay go aansadaan wareejinta kaligood.
    // Markay siman yihiin inta hadhayna eber ahayn, weli qiimaha ayaa loo baahan yahay in la soo koobo.
    // Kaliya marka jajabyada la soo koobay ay yihiin 1/2 inta hartayna ay eber tahay, waxaan haysannaa xaalad nus-ilaa-xitaa ah.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Wareeg-caadi ah-ilaa-xitaa, oo lagu murmay iyadoo lagu qasbay iyadoo lagu saleynayo qaybta ka hartay qaybta.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}