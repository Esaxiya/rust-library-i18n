//! Hawlaha utility ee bignum-yada aan macno badan u samaynaynin inay u beddelaan qaabab.

// FIXME Qaybtani magacoodu waa waxoogaa nasiib darro ah, maaddaama qaybo kale ay iyaguna soo dajiyaan `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Tijaabi in la jaro dhammaan jajabyada ka hooseeya `ones_place` waxay soo bandhigaysaa qalad qaraabo ka yar, u dhigma, ama ka weyn 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Haddii dhammaan inta soo hartay ay eber yihiin, waa= 0.5 ULP, haddii kale> 0.5 Haddii aysan jirin wax dheellitir ah oo dheeri ah (half_bit==0), kan hoose wuxuu si sax ah u soo celinayaa Isku mid.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Waxay badashaa xarigga ASCII oo ay kujiraan kaliya lambar tobanle illaa `u64`.
///
/// Ma sameeyo jeegag xad dhaaf ah ama jilayaal aan ansax ahayn, markaa haddii qofka soo wacayaa aanu taxaddarin, natiijadu waa been oo way awoodaa panic (in kasta oo aanay noqon doonin `unsafe`).
/// Intaa waxaa sii dheer, xargaha madhan waxaa loola dhaqmaa sidii eber.
/// Shaqadani waxay jirtaa maxaa yeelay
///
/// 1. adeegsiga `FromStr` ee `&[u8]` waxay ubaahantahay `from_utf8_unchecked`, oo xun, iyo
/// 2. Isku soo wada duub natiijooyinka `integral.parse()` iyo `fractional.parse()` way ka dhib badan yihiin shaqadan oo dhan.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Waxay badashaa xarigga lambarrada ASCII ee loo yaqaan 'bignum'.
///
/// Sida `from_str_unchecked` oo kale, shaqadani waxay ku tiirsan tahay qallooca inuu ka baxo nambarada aan lambar ahayn.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Waxay u kala bixisaa bignum qadar yar oo 64 ah.Panics haddii nambarku aad u badan yahay.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Waxay soo saartaa dhowr qaybood.

/// Tusmada 0 ayaa ah waxa ugu yar ee la taaban karo oo kaladuwanaanta ayaa badh u furan sidii caadiga ahayd.
/// Panics haddii la waydiiyo inay soo saarto xoogaa ka badan intii ku habboonayd nooca soo noqoshada.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}