//! Xaqiijinta iyo kala-goynta xadhig jajab tobanle oo foomka ah:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Si kale haddii loo dhigo, jaangooyaha dhibcaha sabaynaya, marka laga reebo laba ka reebban: Calaamad la'aan, iyo qabasho la'aan "inf" iyo "NaN".Kuwaas waxaa gacanta ku haya shaqada darawalka ee (super::dec2flt).
//!
//! In kasta oo aqoonsiga wax-soo-saarka saxda ahi uu fudud yahay, haddana qaybtani waxay sidoo kale leedahay inay diido kala-duwanaanta aan tirakoobka lahayn, ee aan waligeed panic, oo ay ku sameeyaan hubinno badan oo qaybaha kale ay ku tiirsan yihiin oo aan ahayn panic (ama buux dhaafin) markooda.
//!
//! Waxaa kaaga sii dartay, dhammaan waxa ku dhaca hal mar oo dhaafsiisan wixii la geliyay.
//! Marka, taxaddar marka aad wax beddelayso, oo laba jeer ku hubi qaybaha kale.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Qaybaha xiisaha leh ee xarig jajab tobanle ah.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Qaybta jajab tobanlaha, oo loo ballanqaaday inay ka yar tahay 18 lambar tobanle.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Wuxuu hubiyaa haddii xarigga aqbalku uu yahay lambar dhibic oo sabayn kara haddii ay sidaas tahayna, hel qaybta muhiimka ah, qaybta jajabka, iyo jibbaarada ku jirta.
/// Aanu qaban calaamadaha.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Lambarro ma jiraan ka hor 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Waxaan ubaahanahay ugu yaraan hal lambar kahor ama kadib barta.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Raadinta qashinka ka dib qayb jajab ah
            }
        }
        _ => Invalid, // Ku dabajoogta qashinka ka dib markii xarigga lambar ee ugu horreeyay uu dhacay
    }
}

/// Wuxuu xardhaa lambar tobanle illaa astaamaha ugu horreeya ee aan lambar ahayn.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Soosaarida jibbaaraha iyo hubinta qaladka.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Ku dabajoogida qashinka ka dib jibbaar
    }
    if number.is_empty() {
        return Invalid; // Jibbaar madhan
    }
    // Waqtigan xaadirka ah, waxaan runtii haysannaa xargo nambarro ansax ah.Waxay noqon kartaa waqti aad u dheer in la geliyo `i64`, laakiin haddii ay intaas aad u weyn tahay, galintu waa eber ama dhammaad la'aan.
    // Maaddaama eber kasta ee lambar tobanle ah uu kaliya ku hagaajinayo jibbaaraha +/-1, at exp=10 ^ 18 soo galintu waa inay ahaataa 17 exabyte (!) ee eber si xitaa looga dhawaado inay ahaato mid kooban.
    //
    // Tani dhab ahaan maahan kiis adeegsi oo aan u baahannahay inaan wax ka qabanno.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}