macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Qiimaha ugu yar ee lagu matali karo noocan iskudhafka ah.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Qiimaha ugu weyn ee lagu matali karo nooca noocan ah.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Cabbirka noocyadan tiro ee ku dhex jira.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Waxay u beddeleysaa jeex xarig ah saldhig la siiyay tiro.
        ///
        /// Xadhigga ayaa la filayaa inuu noqdo calaamadda `+` ee ikhtiyaariga ah oo ay ku xigto lambarro.
        ///
        /// Hogaanka iyo dabagalka barta cad waxay u taagan tahay qalad.
        /// Lambar jira hoosaad ka mid ah jilayaasha waa kuwan, taas oo ku xidhan `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Hawshan panics haddii `radix` uusan ku jirin inta u dhexeysa 2 ilaa 36.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Ku soo celiyaa tirada kuwa ku jira matalaada binary ee `self`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Sooceliyaa tirada eber ee matalaadda binary ee `self`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Ku soo celiyaa tirada eber ee hogaaminaya matalaada binary ee `self`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Ku soo celiyaa tirada eber raadinta ku jirta matalaadda binary ee `self`.
        ///
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Sooceliyaa tirada hogaamiyaasha matalaada binary ee `self`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Sooceliyaa tirada kuwa soo raaca ee matalaadda binary ee `self`.
        ///
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Qeybaha bidix wuxuu ugu wareejiyaa qadar cayiman, `n`, isagoo ku duubaya jajabyada la jarjaray dhamaadka isku dhafka ka dhashay.
        ///
        ///
        /// Fadlan la soco tani maahan wax la mid ah hawlwadeenka wareejinta ee `<<`!
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Qeybaha midig wuxuu ugu wareejiyaa qadar cayiman, `n`, isagoo ku duubaya jajabyada la jarjaray bilowga isku-darka natiijada.
        ///
        ///
        /// Fadlan la soco tani maahan wax la mid ah hawlwadeenka wareejinta ee `>>`!
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Waxay dib u dhigeysaa amarka byte ee tirada.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ha loo daayo m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Waxay dib uga noqotaa amarka jajabyada kujira tirada.
        /// Waxyaabaha ugu yar ee ugu yar ayaa noqonaya kuwa ugu muhiimsan, wax yar ee ugu yar-yar ayaa noqonaya kan labaad ee ugu muhiimsan, iwm.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ha loo daayo m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Waxay badashaa tirooyin iskudhaf ah oo ka bilaabma endian weyn una weynaataa badnaanta bartilmaameedka.
        ///
        /// On endian weyn tani waa maya.
        /// On yar oo endian ah bytes waa la beddelay.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// haddii cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } kale {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Kuweeda abyoonaha ah ka endian yar in endianness bartilmaameedka ee.
        ///
        /// On yar oo endian tani waa a-op.
        /// On endian weyn baatiyada waa la isku badalayaa.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// haddii cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } kale {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Waxay u beddeleysaa `self` endian weyn oo ka imaaneysa culeyska bartilmaameedka.
        ///
        /// On endian weyn tani waa maya.
        /// On yar oo endian ah bytes waa la beddelay.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// haddii cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } kale { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // mise inaan la noqon?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Waxay u rogaa `self` waxoogaa yar oo ka soo baxa culeyska bartilmaameedka.
        ///
        /// On yar oo endian tani waa a-op.
        /// On endian weyn baatiyada waa la isku badalayaa.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// haddii cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } kale { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Isku darka isku darka tirooyinka.
        /// Xisaabiyaa `self + rhs`, soo celinta `None` haddii daadad badan ay dhaceen.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Isku darka tirada aan la hubinXisaabiyaa `self + rhs`, haddii loo maleeyo in daadku buuxsami karin.
        /// Tani waxay keeneysaa dabeecad aan la qeexin goorta
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Ka-goynta tiro isku-dhafan.
        /// Xisaabiyaa `self - rhs`, soo celinta `None` haddii daadad badan ay dhaceen.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kalagoynta lambarada aan la hubin.Xisaabiyaa `self - rhs`, haddii loo maleeyo in daadku buuxsami karin.
        /// Tani waxay keeneysaa dabeecad aan la qeexin goorta
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Isku dhufashada isku geynta tirooyinka.
        /// Xisaabiyaa `self * rhs`, soo celinta `None` haddii daadad badan ay dhaceen.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Isku-dhufashada isku-darka aan la hubinXisaabi `self * rhs`, haddii loo maleeyo in daadku buuxsami karin.
        /// Tani waxay keeneysaa dabeecad aan la qeexin goorta
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Qeybinta tirooyinka tirada.
        /// Xisaabi `self / rhs`, soocelinta `None` haddii `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // BADBAADADA: Eber eber ayaa kor lagu hubiyey noocyada aan la saxiixinna mid kale ma leh
                // hababka guuldarada ee kala qaybsanaanta
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Hubinta qaybta Euclidean.
        /// Xisaabi `self.div_euclid(rhs)`, soocelinta `None` haddii `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Inta ka hartay integer.
        /// Xisaabi `self % rhs`, soocelinta `None` haddii `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // BADBAADADA: Eber eber ayaa kor lagu hubiyey noocyada aan la saxiixinna mid kale ma leh
                // hababka guuldarada ee kala qaybsanaanta
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Hubinta Euclidean modulo.
        /// Xisaabi `self.rem_euclid(rhs)`, soocelinta `None` haddii `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Diidmada la hubiyey.Xisaabiya `-self`, soo celinta `None` mooyee 'is==
        /// 0`.
        ///
        /// Xusuusnow in la diido wax walboo isku mid ah oo wanaagsan ayaa buuxsami doona.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Bidix la hubiyay bidix
        /// Xisaabi `self << rhs`, soo celinta `None` haddii `rhs` ka weyn yahay ama u dhiganta tirada jajabyada ku jira `self`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Midig baa loo hubiyey
        /// Xisaabi `self >> rhs`, soo celinta `None` haddii `rhs` ka weyn yahay ama u dhiganta tirada jajabyada ku jira `self`.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kordhinta hubinta.
        /// Xisaabiyaa `self.pow(exp)`, soo celinta `None` haddii daadad badan ay dhaceen.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // tan iyo EXP!=0, ugu dambeyntii EXP waa in ay ahaadaan 1.
            // La macaamil qaybta ugu dambeysa ee jibbaarka si gooni gooni ah, maadaama isku xirka salka gadaashiisa dambe aan loo baahnayn oo laga yaabo inuu sababo buux-dhaaf aan loo baahnayn.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturating Intaa waxaa dheer abyoonaha.
        /// Xisaabiyaa `self + rhs`, oo ka dheregsan xuduudaha tirada halkii laga buuxin lahaa.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Ka-goynta isku-darka tirada
        /// Xisaabiyaa `self - rhs`, oo ka dheregsan xuduudaha tirada halkii laga buuxin lahaa.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Isku dhufashada isku dhufashada
        /// Xisaabiyaa `self * rhs`, oo ka dheregsan xuduudaha tirada halkii laga buuxin lahaa.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Kordhinta tirooyinka tirinta.
        /// Xisaabiyaa `self.pow(exp)`, oo ka dheregsan xuduudaha tirada halkii laga buuxin lahaa.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Isku duubista (modular).
        /// Xisaabiyaa `self + rhs`, kuna duudduba xadka nooca.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Duubista (modular)
        /// Xisaabiyaa `self - rhs`, kuna duudduba xadka nooca.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Isku duubnaanta (modular).
        /// Xisaabiyaa `self * rhs`, kuna duudduba xadka nooca.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// Fadlan ogow in tusaalahan la wadaago inta udhaxeysa noocyada iskudarka.
        /// Taas oo sharraxaysa sababta loo isticmaalo `u8` halkan.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Duubista qaybta (modular).Xisaabi `self / rhs`.
        /// Qaybta duuduuban ee noocyada aan saxeexnayn waa uun qayb caadi ah.
        /// Ma jiro waddo duubistu waligeed dhici karto.
        /// Shaqadani way jirtaa, si dhammaan hawlgallada loogu xisaabiyo hawlgallada duubista.
        ///
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Duubista qaybta Euclidean.Xisaabi `self.div_euclid(rhs)`.
        /// Qaybta duuduuban ee noocyada aan saxeexnayn waa uun qayb caadi ah.
        /// Ma jiro waddo duubistu waligeed dhici karto.
        /// Shaqadani way jirtaa, si dhammaan hawlgallada loogu xisaabiyo hawlgallada duubista.
        /// Maaddaama, tirooyinka togan, dhammaan qeexitaannada guud ee qaybintu ay siman yihiin, tani waxay si sax ah ula mid tahay `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Duubista (modular) Xisaabi `self % rhs`.
        /// Xisaabinta ka hartay ee ku duugan noocyada aan la saxeexin ayaa ah xisaabinta hadhay ee caadiga ah.
        ///
        /// Ma jiro waddo duubistu waligeed dhici karto.
        /// Shaqadani way jirtaa, si dhammaan hawlgallada loogu xisaabiyo hawlgallada duubista.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Duubista Euclidean modulo.Xisaabi `self.rem_euclid(rhs)`.
        /// Xisaabinta modulo ee ku duuban noocyada aan la saxeexin ayaa ah xisaabinta hadhay ee caadiga ah.
        /// Ma jiro waddo duubistu waligeed dhici karto.
        /// Shaqadani way jirtaa, si dhammaan hawlgallada loogu xisaabiyo hawlgallada duubista.
        /// Maaddaama, tirooyinka togan, dhammaan qeexitaannada guud ee qaybintu ay siman yihiin, tani waxay si sax ah ula mid tahay `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Duubista diidmada (modular).
        /// Xisaabiyaa `-self`, kuna duudduba xadka nooca.
        ///
        /// Maaddaama noocyada aan la saxiixin aysan lahayn wax u dhigma oo diidmo ah dhammaan codsiyada shaqadani way duubnaan doonaan (marka laga reebo `-0`).
        /// Qiimayaasha ka yar nooca saxeexan ee u dhigma ugu badnaan natiijadu waxay la mid tahay tuurista qiimaha u dhigma ee la saxeexay.
        ///
        /// Qiimayaal kasta oo ka waaweyni waxay u dhigmaan `MAX + 1 - (val - MAX - 1)` halkaasoo `MAX` uu yahay nooca la saxeexay ee ugu sarreeya.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// Fadlan ogow in tusaalahan la wadaago inta udhaxeysa noocyada iskudarka.
        /// Taas oo sharraxaysa sababta loo isticmaalo `i8` halkan.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-bilaash ahaan bidix-bidix;
        /// wuxuu soo saaraa `self << mask(rhs)`, halkaasoo `mask` ay ka saareyso xoogaa amarro sare ah oo ah `rhs` taas oo sababi lahayd isbeddelka inuu ka badiyo xawaaraha nooca.
        ///
        /// Xusuusnow in tani aysan * la mid ahayn wareegga bidix;ka DhM of a duubo wareeg-bidix la xadiday in kala duwan ee nooca, halkii jajabka wareejiyay baxay DhB la soo noqday ilaa darafka kale.
        /// Noocyada isugeynta aasaasiga ah dhammaantood waxay hirgeliyaan waxqabadka [`rotate_left`](Self::rotate_left), oo noqon kara waxaad rabto halkii.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // BADBAADADA: wejiga qarsoon ee nooc ka mid ah nooca ayaa hubinaya in aynaan beddelmin
            // xadka ka baxsan
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-bilaash ahaan u beddel-midig;
        /// wuxuu soo saaraa `self >> mask(rhs)`, halkaasoo `mask` ay ka saareyso xoogaa amarro sare ah oo ah `rhs` taas oo sababi lahayd isbeddelka inuu ka badiyo xawaaraha nooca.
        ///
        /// Xusuusnow in tani aysan * la mid ahayn wareegga-midig;RHS ee wareejinta wareejinta-midig ayaa ku xaddidan noocyada nooca, halkii ay ka noqon lahayd jajabyada ka baxa LHS ee lagu celiyo dhamaadka kale.
        /// Noocyada isugeynta aasaasiga ah dhammaantood waxay hirgeliyaan waxqabadka [`rotate_right`](Self::rotate_right), oo noqon kara waxaad rabto halkii.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // BADBAADADA: wejiga qarsoon ee nooc ka mid ah nooca ayaa hubinaya in aynaan beddelmin
            // xadka ka baxsan
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Duubista x00X.
        /// Xisaabiyaa `self.pow(exp)`, kuna duudduba xadka nooca.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // tan iyo EXP!=0, ugu dambeyntii EXP waa in ay ahaadaan 1.
            // La macaamil qaybta ugu dambeysa ee jibbaarka si gooni gooni ah, maadaama isku xirka salka gadaashiisa dambe aan loo baahnayn oo laga yaabo inuu sababo buux-dhaaf aan loo baahnayn.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Wuxuu xisaabiyaa `self` + `rhs`
        ///
        /// Waxay soo celineysaa qayb yar oo ah kudarka oo ay weheliso boole oo tilmaamaysa in xisaab xad dhaaf ah ay dhici doonto iyo in kale.
        /// Haddii daadku dhici lahaa markaa qiimaha duudduuban ayaa la soo celinayaa.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Wuxuu xisaabiyaa `self`, `rhs`
        ///
        /// Waxay soo celisaa qayb yar oo kalagoynta ah oo ay la socoto boole oo tilmaamaya in xisaab xisaabeedku buuxsamayo iyo in kale.
        /// Haddii daadku dhici lahaa markaa qiimaha duudduuban ayaa la soo celinayaa.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Wuxuu xisaabiyaa isku dhufashada `self` iyo `rhs`.
        ///
        /// Waxay soo celisaa laba jibbaaris isku dhufasho ah oo ay la socoto boole oo tilmaamaya haddii xisaabta ay buuxsamayso iyo in kale.
        /// Haddii daadku dhici lahaa markaa qiimaha duudduuban ayaa la soo celinayaa.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// Fadlan ogow in tusaalahan la wadaago inta udhaxeysa noocyada iskudarka.
        /// Taas oo sharraxaysa sababta loo isticmaalo `u32` halkan.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Wuxuu xisaabiyaa kala-qeybiyeha marka `self` loo qaybiyo `rhs`.
        ///
        /// Waxay soo celisaa qayb yar oo qaybiyaha ah oo ay la socoto boole oo tilmaamaya haddii xisaab xisaabeedku buuxsamo iyo in kale.
        /// Ogsoonow in tirooyinka aan saxeexnayn ee buux dhaafiya aysan waligood dhicin, sidaa darteed qiimaha labaad had iyo jeer waa `false`.
        ///
        /// # Panics
        ///
        /// Shaqadani waa panic hadii `rhs` uu yahay 0.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Xisaabiyaa qeybta Euclidean qaybteeda `self.div_euclid(rhs)`.
        ///
        /// Waxay soo celisaa qayb yar oo qaybiyaha ah oo ay la socoto boole oo tilmaamaya haddii xisaab xisaabeedku buuxsamo iyo in kale.
        /// Ogsoonow in tirooyinka aan saxeexnayn ee buux dhaafiya aysan waligood dhicin, sidaa darteed qiimaha labaad had iyo jeer waa `false`.
        /// Maaddaama, tirooyinka togan, dhammaan qeexitaannada guud ee qaybintu ay siman yihiin, tani waxay si sax ah ula mid tahay `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Shaqadani waa panic hadii `rhs` uu yahay 0.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Wuxuu xisaabiyaa inta soo hartay markii `self` loo qaybiyo `rhs`.
        ///
        /// Wuxuu soo celiyaa labalaab inta hartay kadib markuu qaybiyo oo uu weheliyo booli oo tilmaamaya in xisaab xisaabeedku buuxsamayo iyo in kale.
        /// Ogsoonow in tirooyinka aan saxeexnayn ee buux dhaafiya aysan waligood dhicin, sidaa darteed qiimaha labaad had iyo jeer waa `false`.
        ///
        /// # Panics
        ///
        /// Shaqadani waa panic hadii `rhs` uu yahay 0.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Wuxuu u xisaabinayaa inta hartay `self.rem_euclid(rhs)` sidii iyadoo loo eegayo qeybta Euclidean.
        ///
        /// Waxay soo celisaa qayb ka mid ah modulo ka dib markii la qaybiyo oo ay la socoto boole oo tilmaamaya in xisaab xisaabeed ay dhici doonto iyo in kale.
        /// Ogsoonow in tirooyinka aan saxeexnayn ee buux dhaafiya aysan waligood dhicin, sidaa darteed qiimaha labaad had iyo jeer waa `false`.
        /// Maaddaama, tirooyinka togan, dhammaan qeexitaannada guud ee qaybintu ay siman yihiin, hawlgalkani wuxuu si sax ah ula mid yahay `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Shaqadani waa panic hadii `rhs` uu yahay 0.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Is-diidsiinta nafta qaab moodo buux dhaaf ah.
        ///
        /// Sooceliyaa `!self + 1` iyadoo la adeegsanayo hawlgallada duubista si loo soo celiyo qiimaha matalaya diidmada qiimahaas aan la saxeexin.
        /// Ogsoonow in qiimayaasha wanaagsan ee aan la saxeexin ay had iyo jeer dhacaan, laakiin diidmada 0 ma buuxsamayso.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Isbedelada iskiis ah ee looga tago x00X.
        ///
        /// Waxay soo celineysaa qayb ka mid ah is-beddelka is-beddelashada oo ay la socoto booli oo tilmaamaya in qiimaha isbeddelka uu ka weynaa ama u dhigmayay tirada jajabka.
        /// Haddii qiimaha isbeddelka uu aad u ballaaran yahay, markaa qiimaha waxaa lagu daboolay (N-1) halkaas oo N ay tahay tirada waxoogaa yar, oo qiimahan ayaa markaa loo isticmaalaa in lagu sameeyo wareegga.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Iskiis ayuu ugu wareegaa `rhs` bits.
        ///
        /// Waxay soo celineysaa qayb ka mid ah is-beddelka is-beddelashada oo ay la socoto booli oo tilmaamaya in qiimaha isbeddelka uu ka weynaa ama u dhigmayay tirada jajabka.
        /// Haddii qiimaha isbeddelka uu aad u ballaaran yahay, markaa qiimaha waxaa lagu daboolay (N-1) halkaas oo N ay tahay tirada waxoogaa yar, oo qiimahan ayaa markaa loo isticmaalaa in lagu sameeyo wareegga.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Waxay sare ugu qaadaysaa awooda `exp`, iyadoo la adeegsanayo iskucelcelinta isugeynta.
        ///
        /// Waxay soo celisaa laba jibbaar qiimaynta oo ay weheliso bool oo tilmaamaysa in daadku qarxay iyo in kale.
        ///
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, run));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Meel xoq si aad u keydiso natiijooyinka qulqulka_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // tan iyo EXP!=0, ugu dambeyntii EXP waa in ay ahaadaan 1.
            // La macaamil qaybta ugu dambeysa ee jibbaarka si gooni gooni ah, maadaama isku xirka salka gadaashiisa dambe aan loo baahnayn oo laga yaabo inuu sababo buux-dhaaf aan loo baahnayn.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Waxay sare ugu qaadaysaa awooda `exp`, iyadoo la adeegsanayo iskucelcelinta isugeynta.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // tan iyo EXP!=0, ugu dambeyntii EXP waa in ay ahaadaan 1.
            // La macaamil qaybta ugu dambeysa ee jibbaarka si gooni gooni ah, maadaama isku xirka salka gadaashiisa dambe aan loo baahnayn oo laga yaabo inuu sababo buux-dhaaf aan loo baahnayn.
            //
            //
            acc * base
        }

        /// Waxay qabataa qaybta Euclidean.
        ///
        /// Maaddaama, tirooyinka togan, dhammaan qeexitaannada guud ee qaybintu ay siman yihiin, tani waxay si sax ah ula mid tahay `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Shaqadani waa panic hadii `rhs` uu yahay 0.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Xisaabinayaa inta ugu yar ee ka hartay `self (mod rhs)`.
        ///
        /// Tan iyo markii, waayo, abyoonayaasha togan, dhan sharaxyo badan ee horyaalka heerka siman yihiin, taasi waa dhab siman u `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Shaqadani waa panic hadii `rhs` uu yahay 0.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Sooceliyaa `true` haddii iyo kaliya haddii `self == 2^k` qaar `k` ah.
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Waxay soo celisaa hal kayar awoodda xigta ee laba.
        // (8u8 awooda xigta ee laba waa 8u8 kan 6u8na waa 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Habkani ma faafi karto, sida in xaaladaha faafi `next_power_of_two` waxaa halkii kor u dhamaado laabtay qiimaha ugu badan ee nooca ah, oo noqon karin 0 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // AMMAAN: Sababtoo ah `p > 0`, kama koobnaan karo gabi ahaanba eber.
            // Taas macnaheedu waa wareejintu had iyo jeer waa xaddidan tahay, qaar ka mid ah processor-yada (sida intel pre-haswell) waxay leeyihiin ctlz wax ku ool ah marka dooddu tahay eber.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Sooceliyaa awoodda ugu yar ee laba ka weyn ama u dhiganta `self`.
        ///
        /// Marka qiimaha laabto buuxdhaafaa (ie, `self > (1 << (N-1))` nooca `uN`), waxaa panics in hab Debug iyo qiimaha laabashada duudduubay 0 hab sii daayo (xaaladda oo keliya, taas oo ah habka ugu noqon karin 0).
        ///
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Sooceliyaa awoodda ugu yar ee laba ka weyn ama u dhiganta `n`.
        /// Haddii awoodda xigta ee laba ay ka weyn tahay nooca ugu badan ee qiimaha, `None` waa la soo celiyaa, haddii kale awoodda labada ayaa lagu duubay `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Sooceliyaa awoodda ugu yar ee laba ka weyn ama u dhiganta `n`.
        /// Haddii awoodda xigta ee laba ay ka weyn tahay nooca ugu badan ee qiimaha, qiimaha soo-celinta ayaa lagu duubay `0`.
        ///
        ///
        /// # Examples
        ///
        /// Adeegsiga aasaasiga ah:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Ku soo celi matalaada xusuusta ee iskudar intey le'eg tahay qaab-baadiye weyn oo ah (network) byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Ku soo celi matalaada xusuusta ee iskudar intey le'eg tahay qaab-byte yar-endian
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Ku soo celi matalaada xusuusta ee iskudar intey le'eg tahay qaab isu dheelitiran
        ///
        /// Maaddaama loo adeegsanayo ballaadhinta barta bar-tilmaameedka bartilmaameedka, koodhka la qaadan karo waa inuu adeegsadaa [`to_be_bytes`] ama [`to_le_bytes`], sida ku habboon, halkii.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, haddii cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } kale {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // BADBAADADA: waa codka dhawaaqa maxaa yeelay iskudhafku waa noocyo duug ah oo duug ah si aan markasta u awoodno
        // ugu beddel magacyadooda bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // BADBAADADA: isku-dhafku waa noocyo duug ah oo duug ah si aan had iyo jeer ugu beddeli karno iyaga
            // abaabul bytes
            unsafe { mem::transmute(self) }
        }

        /// Ku soo celi matalaada xusuusta ee iskudar intey le'eg tahay qaab isu dheelitiran
        ///
        ///
        /// [`to_ne_bytes`] waa in laga doorbido tan markasta oo ay suurta gal tahay.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ha bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, haddii cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } kale {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // BADBAADADA: isku-dhafku waa noocyo duug ah oo duug ah si aan had iyo jeer ugu beddeli karno iyaga
            // abaabul bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Abuur qaddar isugeyn ah oo endian ah oo ka soo jeeda matalaaddeeda oo ah byte array in endian weyn.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// isticmaal std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * Aqbasho=nasasho,
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Abuur qaddar iskudhaf ah oo isugeyn ah oo asal ahaan ka soo jeeda matalaaddeeda oo ah byte array in yar oo endian ah.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// isticmaal std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * Aqbasho=nasasho,
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Abuur qaddar iskudhaf ah oo isugeyn ah oo asal ahaan ka soo jeeda matalaaddeeda xusuusta oo ah isugeyn baaxad leh oo ku saabsan baaxadda deegaanka.
        ///
        /// Maaddaama loo adeegsanayo ballaadhinta barta bar-tilmaameedka bartilmaameedka, koodh la qaadan karo waxay u badan tahay inuu doonayo inuu isticmaalo [`from_be_bytes`] ama [`from_le_bytes`], sida ku habboon halkii.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } kale {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// isticmaal std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * Aqbasho=nasasho,
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // BADBAADADA: waa codka dhawaaqa maxaa yeelay iskudhafku waa noocyo duug ah oo duug ah si aan markasta u awoodno
        // iyaga transmute iyaga
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // BADBAADADA: isku-dhafku waa noocyo duug ah oo duug ah sidaa darteed marwalba waan u badali karnaa iyaga
            unsafe { mem::transmute(bytes) }
        }

        /// Koodh cusub waa inuu doorbidaa inuu isticmaalo
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Waxay soo celineysaa qiimaha ugu yar ee lagu matali karo noocan iskudhafka ah.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Koodh cusub waa inuu doorbidaa inuu isticmaalo
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Waxay soo celineysaa qiimaha ugu weyn ee lagu matali karo noocan iskudhafka ah.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}