//! Ku xaddidaya dhibic dhibic-dhibic qaybaha shaqsiyeed iyo khaladaadka u dhexeeya.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Qiime xaddidan oo aan la saxeexin, sida in:
///
/// - Qiimaha asalka ahi wuxuu u dhigmaa `mant * 2^exp`.
///
/// - Lambar kasta oo ka yimaada `(mant - minus)*2^exp` illaa `(mant + plus)* 2^exp` wuxuu ku wareegi doonaa qiimaha asalka ah.
/// Baaxadda ayaa loo wada dhan yahay oo keliya marka `inclusive` ay tahay `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantissa miisaan leh.
    pub mant: u64,
    /// Xadka qaladka hoose.
    pub minus: u64,
    /// Xadka qaladka kore.
    pub plus: u64,
    /// Qaybaha la wadaago ee salka 2.
    pub exp: i16,
    /// Run markii xadka qaladka uu yahay mid loo dhan yahay.
    ///
    /// IEEE 754, tani waa run markii mantissa asalka ahayd xitaa.
    pub inclusive: bool,
}

/// Qiime aan la saxiixin
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Xadgudubyo, mid togan ama mid taban.
    Infinite,
    /// Sifir, mid togan ama mid taban.
    Zero,
    /// Nambarro dhammaad ah oo leh beero dheellitiran
    Finite(Decoded),
}

/// Nooca dul sabaynta oo noqon kara ``decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Qiimaha ugu hooseeya ee wanaagsan.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Waxay soo celisaa calaamad (run markii taban) iyo qiimaha `FullDecoded` oo laga soo qaatay lambarka barta sabaynaysa.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // deriska: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode had iyo jeer wuxuu ilaaliyaa jibbaaraha, sidaa darteed mantissa ayaa loo miisaamayaa subinormals-ka.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // deriska: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // meesha maxmant=yaryahay * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // deriska: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}