//! La qabsashada Rust ee Grisu3 algorithm ee lagu sharaxay "Daabacaadda Lambarada sabayn-dhibic si dhakhso leh oo sax ah ula leh" Integers "[^ 1].
//! Waxa uu isticmaalaa saabsan 1KB horyaalka precomputed, oo haddana, waa mid aad u deg deg ah waayo gashiga ugu.
//!
//! [^1]: Florian Loitsch2010. Daabacida tirooyinka dhibcaha sabaynaya si dhakhso leh iyo
//!   si sax ah ula tiro.SAXIIX Maaha.45, 6 (Juunyo 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// fiiri faallooyinka ku qoran `format_shortest_opt` wixii macquul ah.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Marka la eego `x > 0`, wuxuu soo celiyaa `(k, 10^k)` sida `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Hirgelinta qaabka ugu gaaban Grisu.
///
/// Waxay soo celinaysaa `None` markay soo celin lahayd matalaad aan dhammaystirnayn haddii kale.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // waxaan u baahanahay ugu yaraan seddex qaybood oo sax ah oo dheeri ah

    // ka bilow qiyamka caadiga ee jibbaaraha la wadaago
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // ka heli wax kasta oo `cached = 10^minusk` sida in `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // maaddaama `plus` caadi yahay, tani macnaheedu waa `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // oo la siiyay xulashadeena `ALPHA` iyo `GAMMA`, tani waxay `plus * cached` gelineysaa `[4, 2^32)`.
    //
    // waa iska cadahay in la kordhiyo `GAMMA - ALPHA`, sidaa darteed uma baahnin awoodo badan oo keyd ah oo 10 ah, laakiin waxaa jira tixgelinno qaarkood:
    //
    //
    // 1. waxaan dooneynaa inaan ku heyno `floor(plus * cached)` gudaha `u32` maadaama ay ubaahantahay kala qeybsanaan qaali ah.
    //    (tani run ahaantii maaha mid laga hortagi karo, inta soo hartay ayaa loo baahan yahay si loo qiyaaso saxsanaanta.)
    // 2.
    // inta hartay ee `floor(plus * cached)` si isdaba joog ah ayaa loogu dhufanayaa 10, waana inaysan badneyn.
    //
    // midka hore wuxuu siinayaa `64 + GAMMA <= 32`, halka kan labaadna uu siinayo `10 * 2^-ALPHA <= 2^64`;
    // -60 iyo -32 waa xaddiga ugu sarreeya ee xaddidan, V8 sidoo kale iyaga ayaa adeegsada.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // qiyaasta fps.Tani waxay siinaysaa qaladka ugu badan ee 1 ulp (oo laga caddeeyay Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-kala duwanaanta dhabta ah ee laga jaray
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // kor ku xusan `minus`, `v` iyo `plus` waa *tiro la qiyaasay* qiyaas ahaan (qalad <1 ulp).
    // maaddaama aynaan ogayn in khaladku yahay mid togan ama taban, waxaan u adeegsannaa laba qiyaasood oo si siman u kala fog isla markaana aan leenahay qaladka ugu sarreeya ee 2 boogood.
    //
    // "unsafe region" waa kala-furnaan xor ah oo aan markii hore abuurnay.
    // "safe region" waa kala-guur muxaafid ah oo aan aqbalno kaliya.
    // waxaan ku bilaabaynaa repr sax ah gudaha gobolka aan nabdooneyn, iskuna daynaa inaan helno repr-ka ugu dhaw `v` oo isna kujira gudaha gobolka nabdoon.
    // hadaanan kari karin, waan iska quusaneynaa.
    //
    let plus1 = plus.f + 1;
    // ha u ogolaado plus0 = plus.f, 1;//kaliya sharraxaad ha u ogolaato minus0 = minus.f + 1;//kaliya sharaxaad
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // wadaag jibbaar

    // u kala qaybi `plus1` qaybo muhiim ah oo jajab ah.
    // qaybaha muhiimka ah ayaa la damaanad qaadayaa inay ku habboon yihiin u32, maaddaama awoodda kaydinta ay damaanad qaadayso `plus < 2^32` iyo caadi ahaan `plus.f` ay had iyo jeer ka yar tahay `2^64 - 2^4` sababtoo ah shuruudaha saxda ah.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // xisaabi `10^max_kappa`-ka ugu weyn oo aan ka badnayn `plus1` (sidaasna ah `plus1 < 10^(max_kappa+1)`).
    // tani waa xadka sare ee `kappa` hoosta.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Aragtida 6.2: haddii `k` uu yahay integerka ugu weyn st
    // `0 <= y mod 10^k <= y - x`,              markaa `V = floor(y / 10^k) * 10^k` wuxuu ku jiraa `[x, y]` iyo mid ka mid ah matalaadaha ugu gaaban (oo leh tirada ugu yar ee lambarro muhiim ah) tiradaas.
    //
    //
    // hel dhererka lambar `kappa` inta udhaxeysa `(minus1, plus1)` sida ku xusan Theorem 6.2.
    // Theorem 6.2 waa la qaadan karaa si looga saaro `x` adoo u baahan `y mod 10^k < y - x` halkii.
    // (tusaale, `x` =32000, `y` =32777; `kappa` =2 tan iyo 'y mod 10 ^ 3=777 <y, x=777`.) algorithm wuxuu ku tiirsan yahay wajiga xaqiijinta dambe si looga saaro `y`.
    //
    let delta1 = plus1 - minus1;
    // delta1int=(delta1>> e) ha u adeegsado;//kaliya sharaxaad
    let delta1frac = delta1 & ((1 << e) - 1);

    // samee qaybo muhiim ah, adigoo hubinaya saxnaanta talaabo kasta.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // lambarro aan weli la bixin
    loop {
        // waxaan had iyo jeer haysannaa ugu yaraan hal lambar oo aan bixinno, maaddaama `plus1 >= 10^kappa` aan is beddel lahayn:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (waxay raacaysaa `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // u qaybi `remainder` `10^kappa`.labadaba waxaa qiyaasaya `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; waxaan helnay `kappa` sax ah.
            let ten_kappa = (ten_kappa as u64) << e; // miisaanka 10 ^ kappa dib loogu celiyo jibbaaraha la wadaago
            return round_and_weed(
                // BADBAADADA: waxaan bilownay xusuustaas kor ku xusan.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // jabinta wareegga markii aan soo bandhignay dhammaan tirooyinka muhiimka ah.
        // tirada saxda ah ee lambarradu waa `max_kappa + 1` oo ah `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // soo celi kuwa aan waxba galabsan
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // samee qaybo jajab ah, adigoo hubinaya saxnaanta tillaabo kasta.
    // markan waxaan ku tiirsan nahay isku dhufashada soo noqnoqota, maadaama kala qeybsanaanta ay lumineyso saxnaanta.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // tirada soo socota waa inay ahaato mid muhiim ah sidii aan u tijaabinay kahor intaanan dillaacin kuwa aan isbadal sameynin, halkaasoo `m = max_kappa + 1` (#lambar ee qeybta muhiimka ah):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ma buuxsami doono, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // u qaybi `remainder` una dhig `10^kappa`.
        // labadaba waxaa qiyaasaya `2^e / 10^kappa`, sidaa darteed tan dambe ayaa ah mid maldahan halkan.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // kala qaybiye aan toos ahayn
            return round_and_weed(
                // BADBAADADA: waxaan bilownay xusuustaas kor ku xusan.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // soo celi kuwa aan waxba galabsan
        kappa -= 1;
        remainder = r;
    }

    // waxaan soo saarnay dhammaan lambarrada muhiimka ah ee `plus1`, laakiin ma hubo inay tahay midka ugu wanaagsan.
    // tusaale ahaan, haddii `minus1` uu yahay 3.14153 ... iyo `plus1` uu yahay 3.14158 ..., waxaa jira 5 wakiillo ugu gaaban oo kala duwan oo ka yimid 3.14154 ilaa 3.14158 laakiin waxaan haysannaa tan ugu weyn oo keliya.
    // waa inaan si isdaba-joog ah u yareynnaa lambarka ugu dambeeya oo aan hubinno haddii kani yahay kan ugu habboon ee wax soo celiya
    // waxaa jira ugu badnaan 9 musharax (..1 ilaa ..9), marka tani waa cadaalad deg deg ah.(Wajiga "rounding")
    //
    // shaqada ayaa hubineysa haddii XRXXXXXXXXX dhab ahaan uu ku dhexjiro kala duwanaanta boogta, sidoo kale, waxaa suurtagal ah in "second-to-optimal" repr uu dhab ahaan noqon karo mid ku habboon qaladka wareega.
    // labada xaaladoodba kani wuxuu soo celinayaa `None`.
    // (Wajiga "weeding")
    //
    // dhammaan doodaha halkan waxaa cabiray qiimaha guud (laakiin aan muuqan) ee `k`, sidaa darteed:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (iyo sidoo kale, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (iyo sidoo kale, `threshold > plus1v` laga soo bilaabo xilliyadii hore)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // soo saar laba ku dhowaad illaa `v` (dhab ahaan `plus1 - v`) gudaha boogaha 1.5.
        // matalaadda ka dhalataa waa inay noqotaa matalaadda ugu dhow labadaba.
        //
        // halkan `plus1 - v` waxaa loo isticmaalaa tan iyo xisaabaha lagu sameeyo marka la eego `plus1` si looga fogaado overflow/underflow (Halkan magacyada u muuqda doorsanayaan).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // hoos u dhig tirada ugu dambeysa oo istaag matalaadda ugu dhow illaa `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // waxaan la shaqeynaa tirooyinka la qiyaasay ee `w(n)`, oo marka hore u dhigma `plus1 - plus1 % 10^kappa`.ka dib markaad socodsiiso jirka loop `n` jeer, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // waxaan u dejinay `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (sidaas darteed 'hadhay= plus1w(0)`) si loo fududeeyo jeegagga.
            // ogow `plus1w(n)` marwalba wuu kordhayaa.
            //
            // waxaan haysannaa saddex shuruudood oo aan ku joojin karno.mid kasta oo ka mid ah ayaa ka dhigi doona wareegga aan awoodin inuu sii socdo, laakiin waxaan markaa haysannaa ugu yaraan hal wakiil matalaya oo loo yaqaan inuu ugu dhow yahay `v + 1 ulp` si kasta.
            // waxaan u tilmaami doonnaa sida TC1 illaa TC3 jajab ahaan.
            //
            // TC1: `w(n) <= v + 1 ulp`, yacni, kani waa repr-kii ugu dambeeyay ee noqon kara kan ugu dhow.
            // tani waxay u dhigantaa `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // oo ay weheliso TC2 (taas oo hubinaysa haddii `w(n+1)` is valid), tani waxay ka hortageysaa qulqulka suurtagalka ah ee xisaabinta `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, yacni, repr-ka soosocdaa hubaal uma wareego `v`.
            // this u dhiganta `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // dhinaca bidix ee bidix waa buuxsami karaan, laakiin waxaan ognahay `threshold > plus1v`, markaa haddii TC1 been yahay, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` waxaanna si ammaan ah u tijaabin karnaa haddii `threshold - plus1w(n) < 10^kappa` halkii.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, yacni, repr xiga waa
            // ugama dhowaan karo `v + 1 ulp` marka loo eego repr-ka hadda jira.
            // la siiyay `z(n) = plus1v_up - plus1w(n)`, tani waxay noqoneysaa `abs(z(n)) <= abs(z(n+1))`.mar haddii loo maleeyo in TC1 waa been, waxaan leenahay `z(n) > 0`.waxaan leenahay laba kiis oo aan tixgelinno:
            //
            // - marka `z(n+1) >= 0`: TC3 noqdo `z(n) <= z(n+1)`.
            // maaddaama `plus1w(n)` uu sii kordhayo, `z(n)` waa in uu yaraadaa tanina si cad bey u tahay.
            // - goorma `z(n+1) < 0`:
            //   - TC3a: shuruudda waa `plus1v_up < plus1w(n) + 10^kappa`.haddii loo maleeyo in TC2 ay been tahay, `threshold >= plus1w(n) + 10^kappa` marka ma buuxin karto.
            //   - TC3b: TC3 wuxuu noqdaa `z(n) <= -z(n+1)`, ie, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   diidmada TC1 waxay siineysaa `plus1v_up > plus1w(n)`, marka ma buuxin karo ama ma qulquli karto markii lagu daro TC3a.
            //
            // Sidaa awgeed, waa inaan joojinno goorta `TC1 || TC2 || (TC3a && TC3b)`.soo socda waa loo siman yahay in ay rogan, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repr-ka ugu gaaban kuma dhamaan karo `0`
                plus1w += ten_kappa;
            }
        }

        // hubi haddii matalaadan sidoo kale ay tahay matalaada ugu dhow `v - 1 ulp`.
        //
        // tani waxay la mid tahay shuruudaha joojinta ee `v + 1 ulp`, iyada oo dhammaan `plus1v_up` lagu beddelay `plus1v_down` halkii.
        // falanqaynta qulqulka ayaa si siman u haysa.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // hadda waxaan haysannaa matalaad noogu dhow `v` inta udhaxeysa `plus1` iyo `minus1`.
        // Tani waa mid aad ufudud, in kastoo, sidaa darteed waxaan diidnay wixii `w(n)` ah ee udhaxeeya `plus0` iyo `minus0`, ie, `plus1 - plus1w(n) <= minus0` ama `plus1 - plus1w(n) >= plus0`.
        // waxaan isticmaalnaa xaqiiqooyinka `threshold = plus1 - minus1` iyo `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Hirgelinta qaabka ugu gaaban ee Grisu oo ay weheliso Dragonbackback.
///
/// Tani waa in loo adeegsadaa kiisaska badankood.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // BADBAADADA: Hubiyaha amaahdu caqli kuma filna inuu noo oggolaado inaan adeegsanno `buf`
    // qeybta labaad ee 'branch', sidaa darteed waxaan nolosha ku wada shaqeyneynaa halkan.
    // Laakiin waxaan dib u isticmaalnaa oo kaliya `buf` haddii `format_shortest_opt` soo celiyay `None` marka tani waa caadi.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Hirgelinta qaabka saxda ah iyo go'an ee Grisu.
///
/// Waxay soo celinaysaa `None` markay soo celin lahayd matalaad aan dhammaystirnayn haddii kale.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // waxaan u baahanahay ugu yaraan seddex qaybood oo sax ah oo dheeri ah
    assert!(!buf.is_empty());

    // caadi iyo cabir `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // u kala qaybi `v` qaybo muhiim ah oo jajab ah.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // labadaba `v` duug ah iyo `v` cusub (oo lagu qiyaasay `10^-k`) waxay leeyihiin khalad ah <1 ulp (Theorem 5.1).
    // maaddaama aynaan ogayn in khaladku yahay mid togan ama taban, waxaan u adeegsannaa laba qiyaasood oo si siman u kala fog isla markaana waxaan leenahay qaladka ugu badan ee 2 boogood (oo la mid ah tan ugu gaaban).
    //
    //
    // hadafku waa in la helo taxane saxan oo wareegsan oo nambarro ah oo ay wadaagaan labada `v - 1 ulp` iyo `v + 1 ulp`, si aan ugu kalsooni badnaano.
    // haddii tani aysan macquul ahayn, ma ogin midka soo saaraya saxda ah ee `v`, sidaas darteed waan iska daynay oo dib ayaan u laabannay.
    //
    // `err` waxaa lagu qeexay `1 ulp * 2^e` halkan (oo la mid ah boogta ku jirta `vfrac`), waanan qiyaasi doonaa markasta oo `v` la miisaamo.
    //
    //
    //
    let mut err = 1;

    // xisaabi `10^max_kappa`-ka ugu weyn oo aan ka badnayn `v` (sidaasna ah `v < 10^(max_kappa+1)`).
    // tani waa xadka sare ee `kappa` hoosta.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // haddii aan la shaqeyneyno xaddidaadda lambar-dambe, waxaan u baahannahay inaan soo gaabinno keydka ka hor inta aan si dhab ah loo bixin si aan uga fogaanno laba-laabista.
    //
    // ogow waa inaan markale balaarineynaa keydka marka isku soo aruurintu dhacdo!
    let len = if exp <= limit {
        // ooy, xitaa ma soo saari karno *hal* god.
        // tani waa suurtagal markii la yiraahdo, waxaan helnay wax la mid ah 9.5 waxaana lagu wareejinayaa 10.
        //
        // mabda 'ahaan waxaan isla markiiba u wici karnaa `possibly_round` oo leh bakhaar madhan, laakiin miisaanka' `max_ten_kappa << e` '10 wuxuu keeni karaa qulqulka.
        //
        // sidaa darteed waxaan ku jilicsan nahay halkan oo waxaan ku ballaarineynaa inta qaladka ah 10.
        // tani waxay kordhin doontaa sicirka taban ee beenta ah, laakiin kaliya aad,*aad* yar;
        // waxaa la dareemi karaa macno ah oo keliya marka mantissa waa ka weyn tahay 60 gaballo.
        //
        // BADBAADADA: `len=0`, sidaa darteed waajibka ah in la bilaabo xusuustani waa wax yar.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // samee qaybo muhiim ah.
    // Khaladku gebi ahaanba waa jajab, markaa uma baahnin inaan ku hubino qaybtaan.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // lambarro aan weli la bixin
    loop {
        // waxaan had iyo jeer haysannaa ugu yaraan hal lambar oo aan ku siino kuwa aan beddelmin:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (waxay raacaysaa `remainder = vint % 10^(kappa+1)`)
        //
        //

        // u qaybi `remainder` `10^kappa`.labadaba waxaa qiyaasaya `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // keydku ma buuxaa?ku orod kaadhka wareejinta inta hartay.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // BADBAADADA: waxaan bilownay `len` bytes badan.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // jabinta wareegga markii aan soo bandhignay dhammaan tirooyinka muhiimka ah.
        // tirada saxda ah ee lambarradu waa `max_kappa + 1` oo ah `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // soo celi kuwa aan waxba galabsan
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // samee qaybo jajab ah
    //
    // mabda 'ahaan waxaan ku sii socon karnaa lambarkii ugu dambeeyay ee la heli karo oo aan hubin karno saxsanaanta.
    // nasiib daro waxaan la shaqeyneynaa tirooyinka xadidan, sidaa darteed waxaan u baahanahay xoogaa qiimeyn ah si aan u ogaanno qulqulka.
    // V8 isticmaalaa `remainder > err`, kaasoo noqda been ah marka `i` ee lambar marka hore muhiim ah `v - 1 ulp` iyo `v` kala duwan.
    // si kastaba ha noqotee tani waxay diidaysaa talooyin badan oo kale oo sax ah.
    //
    // maaddaama wajiga dambe uu leeyahay baaris sax ah oo buux dhaaf ah, waxaan bedelkeeda adeegsannaa shuruudo adag:
    // Waxaan sii wadaynaa illaa `err` uu ka sarreeyo `10^kappa / 2`, sidaa darteed inta u dhexeysa `v - 1 ulp` iyo `v + 1 ulp` xaqiiqdii waxay ka kooban tahay laba ama in ka badan oo wakiillo wareegsan ah.
    //
    // tani waxay la mid tahay labada isbarbardhig ee u horeeya ee ka imanaya `possibly_round`, tixraac ahaan.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // is bedbeddelayaal, halkaasoo `m = max_kappa + 1` (#lambar ee qeybta muhiimka ah):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ma buuxsami doono, `2^e * 10 < 2^64`
        err *= 10; // ma buuxsami doono, `err * 10 < 2^e * 5 < 2^64`

        // u qaybi `remainder` una dhig `10^kappa`.
        // labadaba waxaa qiyaasaya `2^e / 10^kappa`, sidaa darteed tan dambe ayaa ah mid maldahan halkan.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // keydku ma buuxaa?ku orod kaadhka wareejinta inta hartay.
        if i == len {
            // BADBAADADA: waxaan bilownay `len` bytes badan.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // soo celi kuwa aan waxba galabsan
        remainder = r;
    }

    // xisaab dheeraad ah waa mid aan faa'iido lahayn (`possibly_round` xaqiiqdii wuu ku guuldareystaa), markaa waan iska daynay.
    return None;

    // waxaan soo saarnay dhammaan lambarada la codsaday ee `v`, oo sidoo kale la mid noqon kara lambarada u dhigma ee `v - 1 ulp`.
    // hadda waxaan hubinaynaa haddii ay jiraan matalaad gaar ah oo ay wadaagaan labada `v - 1 ulp` iyo `v + 1 ulp`;tani waxay la mid noqon kartaa lambarada la soo saaray, ama nooca la soo koobay ee lambarradaas.
    //
    // haddii baaxadda ay ku jiraan wakiillo badan oo isla dherer ah, ma hubi karno oo waa inaan celino `None` halkii.
    //
    // dhammaan doodaha halkan waxaa cabiray qiimaha guud (laakiin aan muuqan) ee `k`, sidaa darteed:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // BADBAADADA: `len`-da ugu horreeya ee `buf` waa in la bilaabaa.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (tixraac ahaan, xariiqda dhibcaha ayaa tilmaamaysa qiimaha saxda ah ee matalaadda suuragalka ah ee tirada lambarada la siiyay.)
        //
        //
        // Khaladku waa mid aad u weyn oo ay jiraan ugu yaraan seddex matalaad suurtagal ah inta udhaxeysa `v - 1 ulp` iyo `v + 1 ulp`.
        // ma go`aamin karno midka saxda ah.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // dhab ahaan, 1/2 ulp ayaa ku filan in lagu soo bandhigo laba wakiil oo suurtagal ah.
        // (Xusuusnow inaan ubaahanahay matalaad u gaar ah labada `v - 1 ulp` iyo `` v + 1 ulp '') kani ma buuxin doono, sida `ulp < ten_kappa` laga bilaabo jeegga koowaad.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // haddii `v + 1 ulp` uu ku dhow yahay matalaadda hoos loo soo koobay (oo horayba ugu jirtay `buf`), markaa si ammaan ah ayaan u soo laaban karnaa.
        // Xusuusnow in `v - 1 ulp`*ay* ka yaraan karto matalaadda hadda jirta, laakiin sida `1 ulp < 10^kappa / 2`, xaaladdan ayaa ku filan:
        // masaafada u dhexeysa `v - 1 ulp` iyo matalaad hadda kama badan karto `10^kappa / 2`.
        //
        // xaaladdu waxay la mid tahay `remainder + ulp < 10^kappa / 2`.
        // maadaama tani ay si fudud u buuxsami karto, marka hore hubi haddii `remainder < 10^kappa / 2`.
        // Waxaan horey u xaqiijinay in `ulp < 10^kappa / 2`, hadba inta `10^kappa` uusan buux dhaafin kadib, jeegga labaad wuu fiicanyahay.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // BADBAADADA: Wicitaankeennu wuxuu curiyay xusuustaas.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------soo hadhay-- ----> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // dhinaca kale, haddii `v - 1 ulp` uu u dhow yahay matalaadda la soo koobay, waa inaan soo koobno oo aan soo laabannaa.
        // isla sababtaas awgeed uma baahnin inaan hubino `v + 1 ulp`.
        //
        // xaaladdu waxay la mid tahay `remainder - ulp >= 10^kappa / 2`.
        // mar labaad waxaan marka hore hubineynaa haddii `remainder > ulp` (ogow in tani aysan aheyn `remainder >= ulp`, maadaama `10^kappa` weligeed eber aheyn).
        //
        // sidoo kale la soco in `remainder - ulp <= 10^kappa`, markaa jeegga labaad ma buuxsamayo.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // BADBAADADA: qofka na soo wacaya waa inuu bilaabay xusuustaas.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // kaliya ku dar lambar dheeraad ah markii nalaga codsaday sax ahaanta.
                // Waxaan sidoo kale u baahanahay inaan hubino taas, haddii keydkii asalka ahaa uu madhan yahay, lambar dheeraad ah ayaa lagu dari karaa oo keliya marka `exp == limit` (kiis edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // BADBAADADA: annaga iyo qofka soo wacayba waxaan bilownay xusuustaas.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // haddii kale waynu halaagsan nahay (yacni, qiimayaasha qaar ee u dhexeeya `v - 1 ulp` iyo `v + 1 ulp` way isdaba wareegayaan kuwa kalena way soo ururayaan) oo way quusanayaan.
        //
        None
    }
}

/// Hirgelinta qaabka saxda ah ee go'an ee loogu talagalay Grisu oo leh dib u dhac Dragon.
///
/// Tani waa in loo adeegsadaa kiisaska badankood.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // BADBAADADA: Hubiyaha amaahdu caqli kuma filna inuu noo oggolaado inaan adeegsanno `buf`
    // qeybta labaad ee 'branch', sidaa darteed waxaan nolosha ku wada shaqeyneynaa halkan.
    // Laakiin waxaan dib u isticmaalnaa oo kaliya `buf` haddii `format_exact_opt` soo celiyay `None` marka tani waa caadi.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}