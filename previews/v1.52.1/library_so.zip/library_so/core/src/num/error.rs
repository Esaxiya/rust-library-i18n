//! Noocyada khaladaadka loogu beddelayo noocyada muhiimka ah.

use crate::convert::Infallible;
use crate::fmt;

/// Nooca qaladku wuu soo noqday markii nooc ka mid ah noocyada isku dhafan ee la hubiyay uu fashilmo.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Isku aadi halkii aad ku qasbi lahayd si aad u hubiso in koodhka sida `From<Infallible> for TryFromIntError` ee kor ku xusan uu sii shaqeyn doono marka `Infallible` uu noqdo magac u yaal `!`.
        //
        //
        match never {}
    }
}

/// Khalad la soo celin karo marka la baarayo integer.
///
/// Ciladan waxaa loo adeegsadaa inay tahay nooca cilad ee shaqooyinka `from_str_radix()` ee noocyada isku dhafan ee aasaasiga ah, sida [`i8::from_str_radix`].
///
/// # Sababaha keeni kara
///
/// Sababaha kale awgood, `ParseIntError` waa la tuuri karaa sababta oo ah hogaaminta ama dabagalka meelaha cad ee xarigga tusaale ahaan, marka laga helo soo gelinta caadiga ah.
///
/// Isticmaalka habka [`str::trim()`] wuxuu xaqiijinayaa inaysan jirin meel cad oo haray kahor baarista.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// U qor si aad u kaydiso noocyada khaladaad ee kala duwan ee sababi kara kala-goynta tiro intee la'eg.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Qiimaha la saarayo waa faaruq
    ///
    /// Sababaha kale awgood, noocani waa la dhisi doonaa marka la falanqeynayo xarig maran.
    Empty,
    /// Waxay ka kooban tahay lambar aan ansax ahayn oo ku jira macnaheeda.
    ///
    /// Sababaha kale awgood, kala duwanaanshahan ayaa la dhisi doonaa markii la falanqeynayo xarig ay ku jiraan shax aan ahayn ASCII.
    ///
    /// Kala duwanaanshahan waxaa sidoo kale la dhisay markii `+` ama `-` lagu khaldo xarig gudahiisa ama keligiis ama dhexda lambar.
    ///
    ///
    InvalidDigit,
    /// Isku-dhafka ayaa aad u ballaaran oo lagu kaydin karo nooca isku-darka tirada.
    PosOverflow,
    /// Abyoonaha waa mid aad u yar in dukaanka in nooca abyoonaha bartilmaameedka.
    NegOverflow,
    /// Qiimaha wuxuu ahaa Eber
    ///
    /// Kala duwanaanshahan ayaa la sii deyn doonaa marka xarigga kala-baxa uu leeyahay qiimo eber ah, taasoo sharci-darro u noqon doonta noocyada aan eber-ka ahayn.
    ///
    Zero,
}

impl ParseIntError {
    /// Waxay soo saartaa sababaha faahfaahsan ee kala-goynta tira dhan.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}