//! Joogto ah oo gaar u ah nooca dhibic sabayn laba-geesoodka ah ee `f64`.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Tirooyin xisaab ahaan muhiim ah ayaa lagu bixiyaa qaybta hoose ee `consts`.
//!
//! Joogtada ah oo si toos ah loogu qeexay qaybtan (sida ay uga duwan tahay kuwa lagu qeexay qaybta hoose ee `consts`), koodh cusub ayaa halkii laga isticmaali lahaa istiraatiijiyadda la xidhiidha ee tooska loogu qeexay nooca `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Shucaaca ama saldhigga matalaadda gudaha ee `f64`.
/// Isticmaal [`f64::RADIX`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // habka loogu tala galay
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Tirada lambarro muhiim ah salka 2.
/// Isticmaal [`f64::MANTISSA_DIGITS`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // habka loogu tala galay
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Qiyaas ahaan lambarro muhiim ah oo kujira salka 10.
/// Isticmaal [`f64::DIGITS`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // habka loogu tala galay
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] qiimaha `f64`.
/// Isticmaal [`f64::EPSILON`] halkii.
///
/// Tani waa farqiga u dhexeeya `1.0` iyo lambarka xiga ee weyn ee matalaya.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // habka loogu tala galay
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Qiimaha ugu yar ee `f64`.
/// Isticmaal [`f64::MIN`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // habka loogu tala galay
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Qiimaha ugu yar ee caadiga ah `f64`.
/// Isticmaal [`f64::MIN_POSITIVE`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // habka loogu tala galay
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Qiimaha ugu dambeeya ee `f64`.
/// Isticmaal [`f64::MAX`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // habka loogu tala galay
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Mid ka weyn awooda ugu yar ee suurtogalka ah ee 2 jibbaar.
/// Isticmaal [`f64::MIN_EXP`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // habka loogu tala galay
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Awoodda ugu badan ee suuragalka ah ee 2 jibbaar.
/// Isticmaal [`f64::MAX_EXP`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // habka loogu tala galay
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Awoodda ugu yar ee suurtogalka ah ee 10 jibbaar.
/// Isticmaal [`f64::MIN_10_EXP`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // habka loogu tala galay
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Awoodda ugu badan ee suurtagalka ah ee 10 jibbaar.
/// Isticmaal [`f64::MAX_10_EXP`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // habka loogu tala galay
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Ma Number (NaN) ah.
/// Isticmaal [`f64::NAN`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // habka loogu tala galay
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Isticmaal [`f64::INFINITY`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // habka loogu tala galay
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Xaddidan xaddidan (−∞).
/// Isticmaal [`f64::NEG_INFINITY`] halkii.
///
/// # Examples
///
/// ```rust
/// // dariiqa
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // habka loogu tala galay
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Joogtaynta xisaabta aasaasiga ah.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ku beddel xisaabaad joogto ah oo laga bilaabo cmath.

    /// Archimedes 'joogto ah (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Wareegga buuxa ee joogtada ah (τ)
    ///
    /// U dhigma 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Lambarka Euler ee (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// Shucaaca ama saldhigga matalaadda gudaha ee `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Tirada lambarro muhiim ah salka 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Qiyaas ahaan lambarro muhiim ah oo kujira salka 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] qiimaha `f64`.
    ///
    /// Tani waa farqiga u dhexeeya `1.0` iyo lambarka xiga ee weyn ee matalaya.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Qiimaha ugu yar ee `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Qiimaha ugu yar ee caadiga ah `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Qiimaha ugu dambeeya ee `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Mid ka weyn awooda ugu yar ee suurtogalka ah ee 2 jibbaar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Awoodda ugu badan ee suuragalka ah ee 2 jibbaar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Awoodda ugu yar ee suurtogalka ah ee 10 jibbaar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Awoodda ugu badan ee suurtagalka ah ee 10 jibbaar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Ma Number (NaN) ah.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Xaddidan xaddidan (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Soocelinayaa `true` haddii qiimahani yahay `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` si cad looma heli karo libcore sababo la xiriira walaac laga qabo in la raaco, sidaa darteed hirgalintan waxaa loogu talagalay in si gaar ah loogu isticmaalo gudaha.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Soocelinayaa `true` haddii qiimahani yahay mid aan fiicnayn ama aan xad lahayn, iyo `false` haddii kale.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Soocelinayaa `true` haddii lambarkan aan la koobi karayn iyo `NaN` midna.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Looma baahna in si gooni ah loo maareeyo NaN: haddii isku yahay NaN, isbarbardhiggu run maahan, sida saxda ee la doonayo.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Soocelinayaa `true` haddii nambarku yahay [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Qiimayaasha u dhexeeya `0` iyo `min` waa Subnormal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Soocelinayaa `true` haddii nambarku uusan eber ahayn, aan dhammaad lahayn, [subnormal], ama `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Qiimayaasha u dhexeeya `0` iyo `min` waa Subnormal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Soocelisaa qeybta dhibcaha sabaynaysa ee lambarka.
    /// Haddii hal guri kaliya la tijaabinayo, guud ahaan way ka dhaqso badan tahay in la isticmaalo saadaaliyaha gaarka ah bedelkiisa.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Sooceliyaa `true` haddii `self` uu leeyahay calaamad togan, oo ay kujirto `+0.0`, ``NaN`s oo leh calaamado wanaagsan oo aan fiicnayn.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Sooceliyaa `true` haddii `self` uu leeyahay calaamado diidmo ah, oo ay kujiraan `-0.0`, ``NaN`s oo wata calaamado taban oo aan xaddidnayn.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Waxay qaadataa (inverse) isdhaafsiga lambarka, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Waxay u badashaa shucaac ilaa darajo.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Qeybinta halkan ayaa si sax ah loo soo koobay iyadoo loo eegayo qiimaha dhabta ah ee 180/π.
        // (Tani way ka duwan tahay f32, halkaas oo joogto ah waa in loo adeegsadaa si loo hubiyo natiijo sax ah oo wareegsan.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Darajooyin ayuu u beddelaa radians.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Soocelinaya ugu badnaan labada lambar.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Haddii doodaha midkood uu yahay NA, markaa muranka kale ayaa la soo celiyaa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Sooceliyaa uguyar labada lambar.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Haddii doodaha midkood uu yahay NA, markaa muranka kale ayaa la soo celiyaa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Wareeg xagga eber iyo kuweeda in nooc kasta oo abyoonaha heer hoose ah, haddii loo maleeyo in qiimaha waa uguna iyo qallalku in nooca in.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Qiimaha waa inuu:
    ///
    /// * Ha noqonin `NaN`
    /// * Ma noqon doonto mid aan la koobi karayn
    /// * Noqo representable in nooca soo laabtay `Int`, ka dib markii truncating off ay qayb jajab
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// U gudbinta ceeriin `u64`.
    ///
    /// Tani hadda waxay lamid tahay `transmute::<f64, u64>(self)` dhammaan meerayaasha.
    ///
    /// U fiirso `from_bits` si aad uga dooddo xoog-u-qaadidda hawlgalkan (ma jiraan arrimo badan).
    ///
    /// Xusuusnow in shaqadani ay ka duwan tahay ridaha `as`, oo isku dayaysa inay ilaaliso qiimaha * lambar, oo aan ahayn qiimaha waxoogaa yar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() ma shubay!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // BADBAADADA: `u64` waa qaab duug ah oo duug ah sidaa darteed marwalba waan ku badali karnaa
        unsafe { mem::transmute(self) }
    }

    /// Ka gudbinta ceeriin ee ka socota `u64`.
    ///
    /// Tani hadda waxay lamid tahay `transmute::<u64, f64>(v)` dhammaan meerayaasha.
    /// Waxay soo baxday inay tani tahay mid si la yaab leh loo qaadan karo, laba sababood awgood:
    ///
    /// * Doomaha iyo Hantidhowrka waxay leeyihiin isku mid ahaansho dhammaan dhulalka la taageero.
    /// * IEEE-754 si hufan ayaa u qeexaysa qaabka yar ee sabeynta.
    ///
    /// Si kastaba ha noqotee waxaa jira hal digniin: kahor qaabkii 2008 ee IEEE-754, sida loo turjumo NaN waxyeellada yar dhab ahaan lama cayimin.
    /// Meelaha badankood (gaar ahaan x86 iyo ARM) waxay soo qaateen tarjumaadda ugu dambayntii la jaangooyay sanadkii 2008, laakiin qaarna ma (gaar ahaan MIPS).
    /// Natiijo ahaan, dhammaan calaamadaha NaNs ee MIPS waa NaNs deggan x86, iyo dhinaca kale.
    ///
    /// Halkii laga isku dayi lahaa in la ilaaliyo calaamadaha-ness cross-platform, hirgelintaani waxay door bidaa in la ilaaliyo jajabyada saxda ah.
    /// Tani waxay ka dhigan tahay in wixii lacag bixin ah ee lagu qoro NaN-yada la keydin doono xitaa haddii natiijada qaabkan looga diro shabakada mashiinka x86 illaa mid MIPS ah.
    ///
    ///
    /// Haddii natiijooyinka habkan kaliya lagu maareynayo isla qaab-dhismeedka iyaga soo saaray, markaa ma jiraan wax welwel ah oo laga qaadi karo.
    ///
    /// Hadday wax soo gelintu ahayn NaN, markaa ma jiro walaac la qaadi karo.
    ///
    /// Haddii aadan daryeeli ku saabsan digayaan-raag (u badan tahay), markaas ma jirto walaac karo.
    ///
    /// Xusuusnow in shaqadani ay ka duwan tahay ridaha `as`, oo isku dayaysa inay ilaaliso qiimaha * lambar, oo aan ahayn qiimaha waxoogaa yar.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // BADBAADADA: `u64` waa qaab duug ah oo duug ah sidaa darteed marwalba waan ka gudbi karnaa
        // Waxaa soo baxday in arrimaha nabadgelyada ee sNaN ay ahaayeen kuwo xad dhaaf ah!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Ku soo celi matalaada xusuusta ee lambarkan dhibic sabayn sida soo noqnoqoshada ah ee loo yaqaan 'big-endian (network) byte byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// U soo celi matalaada xusuusta ee lambarkan dhibic sabayn ahaan u soo noqnoqda byte bayd yar oo amar ah byte-yar
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Ku soo celi matalaada xusuusta ee lambarkan dhibic sabayn ahaan u soo noqnoqda qaab ahaan bate ahaan.
    ///
    /// Maaddaama loo adeegsanayo ballaadhinta barta bar-tilmaameedka bartilmaameedka, koodhka la qaadan karo waa inuu adeegsadaa [`to_be_bytes`] ama [`to_le_bytes`], sida ku habboon, halkii.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Ku soo celi matalaada xusuusta ee lambarkan dhibic sabayn ahaan u soo noqnoqda qaab ahaan bate ahaan.
    ///
    ///
    /// [`to_ne_bytes`] waa in laga doorbido tan markasta oo ay suurta gal tahay.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // BADBAADADA: `f64` waa qaab duug ah oo duug ah oo caadi ah sidaa darteed marwalba waan u gudbin karnaa
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Abuur qiime dhibic sabayn ka tarjumaya matalaadeeda oo ah baaxad weyn oo endian ah.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Abuur qiime dhibic sabayn ka tarjumaya matalaaddeeda oo ah baaxad yar oo endian ah.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Abuur qiime dhibic sabayn ka tarjumaya matalaaddeeda oo ah baaxad weyn oo ka timaadda waddanka hooyo.
    ///
    /// Maaddaama loo adeegsanayo ballaadhinta barta bar-tilmaameedka bartilmaameedka, koodh la qaadan karo waxay u badan tahay inuu doonayo inuu isticmaalo [`from_be_bytes`] ama [`from_le_bytes`], sida ku habboon halkii.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Waxay soocelisaa amar kadhexeeya nafta iyo qiyamka kale.
    /// Si ka duwan marka la barbardhigo heerka qayb ahaan u dhexeeya tirooyinka dhibic sabayn, marka la barbardhigo tan mar walba soo saarta xigsiin ah si waafaqsan in la saadaalin karo totalOrder sida ku qeexan IEEE 754 (2008 dib u eegis) sabayn caadiga ah dhibic.
    /// Qiimaha waxaa lagu dalbadaa sida soo socota:
    /// - NaN aamusan
    /// - seylaanyenta xun NAN
    /// - Xaddidnaan taban
    /// - Tirooyinka taban
    /// - Tirooyinka aan caadiga ahayn ee xun
    /// - Eber xun
    /// - Eber macquul ah
    /// - lambarada subnormal Positive
    /// - Tirooyin togan
    /// - Xaddidan la'aan
    /// - Positive seylaanyenta NAN
    /// - NaN deggan
    ///
    /// Ogsoonow in shaqadani aysan had iyo jeer ku raacsaneyn hirgelinta [`PartialOrd`] iyo [`PartialEq`] ee `f64`.Gaar ahaan, waxay u arkaan eber diidmo iyo mid togan mid la mid ah, halka `total_cmp` uusan u arag.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Haddii ay jiraan wax diidmo ah, rog dhammaan qeybaha oo dhan marka laga reebo calaamadda si aad u gaarto qaab isku mid ah oo ah laba isugeyn oo dhammaystiran
        //
        // Maxay tani u shaqeysaa?IEEE 754 sabeyntu waxay ka kooban tahay saddex aag:
        // Saxeex xoogaa, jibbaar iyo mantissa.Qaybaha jibbaarada iyo mantissa guud ahaan waxay leeyihiin hanti ay amarkooda xoogaa la mid yahay baaxadda tiro halka cabirka lagu qeexay.
        // Baaxadda sida caadiga ah laguma qeexin qiyamka NaN, laakiin IEEE 754 totalOrder wuxuu qeexayaa qiyamka NaN sidoo kale in la raaco amar yar.Tani waxay keenaysaa amar lagu sharraxay faallooyinka doc.
        // Si kastaba ha noqotee, matalaadda baaxadda ayaa la mid ah tirooyinka taban iyo kuwa togan-kaliya calaamadda waxoogaa ayaa ka duwan.
        // Si aan si fudud isbarbar dhig ugu sameeyno sabeynta sida lambarada la saxeexay, waxaan u baahanahay inaan rogno jibbaarada iyo mantissa bits haddii ay dhacdo tirooyin taban.
        // Waxaan si wax ku ool ah ugu beddeleynaa nambarada foomka "two's complement".
        //
        // Si loo sameeyo rogrogmada, waxaan dhisaynaa maaskaro iyo XOR oo ka soo horjeeda.
        // Waxaan si layaab leh u xisaabineynaa maaskaro "all-ones except for the sign bit" ah oo ka imanaya qiyamka saxeexan ee saxan: saxeexa saxda ah-wuxuu dheereeyaa isku-darka, sidaa darteed waxaan "fill" maaskarada ugu jirnaa calaamado goosgoos ah, ka dibna waxaan u beddeleynaa calaamadeyn la'aan si aan u riixno wax yar oo eber ah.
        //
        // Qiyamka togan, maaskaradu waa dhammaan eber, markaa waa iska diid.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Ku xaddid qiimaha wakhti go'an mooyee mooyee.
    ///
    /// Sooceliyaa `max` haddii `self` waa ka weyn yahay `max`, iyo `min` haddii `self` ka yar tahay `min`.
    /// Haddii kale tani waxay soo celinaysaa `self`.
    ///
    /// Ogsoonow in shaqadani soo celinayso NaN haddii qiimaha hore uu ahaa NaN sidoo kale.
    ///
    /// # Panics
    ///
    /// Panics haddii `min > max`, `min` uu yahay NaN, ama `max` uu yahay NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}