#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// Nooca [Unicode](http://www.unicode.org/) in qaybaha Unicode ee hababka `char` iyo `str` ay ku saleysan yihiin.
///
/// versions of New koodh caalamiga si joogto ah la sii daayay iyo markii danbe oo dhan hababka maktabadda caadiga ah ku xiran tahay koodh caalamiga ayaa la cusbooneysiiyaa.
/// Sidaa darteed habdhaqanka qaar ka mid ah hababka `char` iyo `str` iyo qiimaha isbeddelladan joogtada ahi muddo isku beddelayso.
/// Tani * looma arko inay tahay isbedel jabis ah.
///
/// nidaamka version tiradoodii waxaa la sharaxay in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Si loogu isticmaalo liballoc, dib looma dhoofiyo libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;