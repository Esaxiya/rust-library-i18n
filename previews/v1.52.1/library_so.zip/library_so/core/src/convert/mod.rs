//! Traits loogu talagalay is-beddelka u dhexeeya noocyada.
//!
//! traits The buuggan siiyaan hab si loogu badalo ka mid ah nooca in nooc kale.
//! trait kasta wuxuu u adeegaa ujeedo kale:
//!
//! - Dhaqangelinta trait [`AsRef`] ee beddelaad cheap tixraac-to-tixraaca
//! - Ku hirgeli [`AsMut`] trait ku beddelashada isku beddelka ah ee jaban
//! - Dhaqangelinta trait [`From`] ee gubaya beddelaad qiimaha-to-qiimaha
//! - U hirgeli [`Into`] trait si aad ugu isticmaasho beddelaad qiimo-ku-beddel ah noocyada ka baxsan crate hadda
//! - [`TryFrom`] iyo [`TryInto`] traits waxay u dhaqmaan sida [`From`] iyo [`Into`], laakiin waa in la dhaqan galiyaa marka beddelka uu fashilmi karo.
//!
//! traits The buuggan ayaa badanaa loo isticmaalaa trait bounds for hawlaha guud sida in doodaha noocyada kala duwan yihiin oo ay taageerayaan.Fiiri warqadaha ee trait kasta tusaalayaal.
//!
//! Sida qoraaga ah maktabadda, waa in aad had iyo jeer door bidaan fulinta [`From<T>`][`From`] ama [`TryFrom<T>`][`TryFrom`] halkii [`Into<U>`][`Into`] ama [`TryInto<U>`][`TryInto`], sida [`From`] iyo [`TryFrom`] bixiyaan dabacsanaan weyn oo waxaad bixisaa fulintii [`Into`] ama [`TryInto`] u dhiganta lacag la'aan ah, si ay fulinta buste maktabadda heer mahad.
//! Markaad beegsanayso nooc kahor Rust 1.41, waxaa laga yaabaa inay lagama maarmaan noqoto in si toos ah loo hirgeliyo [`Into`] ama [`TryInto`] marka loo beddelayo nooc ka baxsan crate hadda.
//!
//! # Hirgelinta Guud
//!
//! - [`AsRef`] iyo [`AsMut`] otomaatig-ka-dhigis haddii nooca gudaha uu yahay tixraac
//! - [``Laga bilaabo`] ``<U>waayo '' T waxay tilmaamaysaa [`` Gudaha '' '</u><T><U>loogu talagalay U`</u>
//! - [`TryFrom`] <U>Waayo, T`muujinaysaa [` TryInto`]`</u><T><U>loogu talagalay U`</u>
//! - [`From`] iyo [`Into`] waa awtomatik ah, taas oo macnaheedu yahay in dhamaan noocyada naftooda iyo naftooda `from` `into` karaa
//!
//! Ka eeg trait kasta tusaalooyinka isticmaalka.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Shaqada aqoonsiga.
///
/// Laba arrimood ayaa muhiim ah in la ogaado shaqadan:
///
/// - Waxaa had iyo jeer ma u dhigantaa xiritaanka ah sida `|x| x`, tan iyo xiritaanka khasbaan laga yaabaa `x` galay nooc oo kala duwan.
///
/// - Waxay dhaqaajineysaa gelinta `x` ee loo gudbiyay shaqada.
///
/// Inkastoo ay u muuqato la yaab leh in ay shaqo ah in celinta kaliya dib talooyin ah, waxaa jira qaar ka mid ah isticmaalka xiiso leh.
///
///
/// # Examples
///
/// Isticmaalka `identity` in waxba ma samayn ee isku xigxiga oo ka mid ah oo kale, oo xiiso leh, hawlaha:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Aynu iska dhigno in mid lagu daro ay tahay shaqo xiise leh.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// U adeegsiga `identity` sidii kiiska aasaasiga ah ee "do nothing" xaalad shuruudaysan:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Samee waxyaabo badan oo xiiso leh ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Isticmaalka `identity` in ay sii `Some` ku duwanaanshaha of iterator ah `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Waxaa loo adeegsaday in lagu sameeyo tixraac jaban tixraac tixraac ah.
///
/// trait Tani waxay la mid tahay [`AsMut`] kaasoo loo isticmaalo diinta u dhexeeya tixraacyada mutable.
/// Haddii aad u baahan tahay in la sameeyo qaab beddelidda qaali ah waxaa wanaagsan in ay hirgeliyaan [`From`] nooca `&T` ama u qor shaqada caado.
///
/// `AsRef` ayaa saxiixa la mid ah sida [`Borrow`], laakiin [`Borrow`] waa kala duwan ee dhinacyada yar:
///
/// - Si ka duwan `AsRef`, [`Borrow`] wuxuu leeyahay tallaabo buste ah oo loogu talagalay wixii `T` ah, waxaana loo isticmaali karaa in lagu aqbalo tixraac ama qiimo.
/// - [`Borrow`] sidoo kale waxay u baahan tahay in [`Hash`], [`Eq`] iyo [`Ord`] loogu talagalay qiimaha amaahdu ay u dhigmaan kuwa qiimaha la leeyahay.
/// Sababtan awgeed, haddii aad rabto in aad ka amaahan kaliya beerta hal struct aad hirgelin karaan `AsRef`, laakiin ma [`Borrow`].
///
/// **Note: trait-kan waa inuusan fashilmin **.Haddii qaab beddelidda dafiri karto, isticmaal hab u gaar ah oo soo laabtay [`Option<T>`] ama [`Result<T, E>`] ah.
///
/// # Hirgelinta Guud
///
/// - `AsRef` auto-dereferences haddii nooca hoose waa tixraac ama tixraac mutable (tusaale ahaan: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Adoo adeegsanaya trait bounds waxaan aqbali karnaa doodaha noocyada kala geddisan illaa iyo inta loo rogi karo nooca la cayimay ee `T`.
///
/// Tusaale ahaan: Abuuritaanka hawl guud oo qaadata `AsRef<str>` waxaan muujineynaa inaan dooneyno inaan aqbalno dhammaan tixraacyada loo rogi karo [`&str`] dood ahaan.
/// Maaddaama labada [`String`] iyo [`&str`] ay hirgelinayaan `AsRef<str>` waxaan aqbali karnaa labadaba sida doodda fikradda.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Waxay qabataa beddelaad
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Waxaa loo adeegsaday in lagu sameeyo tixraac jaban oo beddelaad ah oo beddelaad ah.
///
/// trait kani wuxuu lamid yahay [`AsRef`] laakiin waxaa loo isticmaalay inuu udhaxeeyo tixraacyada la beddeli karo.
/// Haddii aad u baahan tahay inaad sameyso beddelaad qaali ah waxaa fiican inaad hirgeliso [`From`] oo leh nooca `&mut T` ama qor waxqabad caadiya.
///
/// **Note: trait-kan waa inuusan fashilmin **.Haddii qaab beddelidda dafiri karto, isticmaal hab u gaar ah oo soo laabtay [`Option<T>`] ama [`Result<T, E>`] ah.
///
/// # Hirgelinta Guud
///
/// - `AsMut` otomaatiga ka-saarida haddii nooca gudaha uu yahay tixraac la beddeli karo (tusaale: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Isticmaalka `AsMut` sida trait bound shaqo ah generic aqbali karno dhammaan tixraacyada mutable in loo rogi karaa in nooca `&mut T`.
/// Sababtoo ah [`Box<T>`] wuxuu hirgeliyaa `AsMut<T>` waxaan qori karnaa hawl `add_one` ah oo qaadata dhammaan doodaha loo rogi karo `&mut u64`.
/// Sababtoo ah [`Box<T>`] wuxuu hirgeliyaa `AsMut<T>`, `add_one` wuxuu aqbalaa doodaha nooca `&mut Box<u64>` sidoo kale:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Waxay qabataa beddelaad
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// U-beddelasho qiimo-u-qiimo leh oo cunaysa qiimaha soo-galinta.soo horjeeda ee [`From`].
///
/// Mid waa inuu iska ilaaliyaa hirgelinta [`Into`] oo uu hirgeliyaa [`From`] bedelkiisa.
/// Hirgalinta [`From`] si toos ah siisaa mid la fulin ah [`Into`] mahad fulinta buste maktabadda calanka.
///
/// Jecli isticmaalaya [`Into`] badan [`From`] marka la tilmaamayo trait bounds on shaqo generic si loo hubiyo in nooc oo kaliya fuliyo [`Into`] waxaa loo isticmaali karaa sidoo kale.
///
/// **Note: trait-kan waa inuusan fashilmin **.Haddii beddelka uu ku guuldareysto, isticmaal [`TryInto`].
///
/// # Hirgelinta Guud
///
/// - [``Ka '' '<T>U` wuxuu tilmaamayaa `Into<U> for T`
/// - [`Into`] waa falcelin, taas oo macnaheedu yahay in `Into<T> for T` la hirgeliyey
///
/// # Fulinta [`Into`] for beddelaad noocyada dibadda ee qoraalkii jir ah oo Rust
///
/// Ka hor inta aan Rust 1.41, haddii nooca caga qayb ka mid ah crate hadda ma ahaa ka dibna aadan si toos ah u hirgeliyaan yaabaa [`From`].
/// Tusaale ahaan, qaado lambarkan:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Tani waxay ku guuldareysan doonaan inay isku ururiso in qoraalkii ka weyn oo ah afka, sababtoo ah xeerarka orphaning Rust ayaa in yar sii yara adag ahaan loo isticmaalo.
/// Si looga gudbo tan, waxaad si toos ah u hirgelin kartaa [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Waa muhiim in la fahmo in [`Into`] uusan bixin hirgelinta [`From`] (sida [`From`] u sameeyo [`Into`]).
/// Sidaa darteed, waa inaad had iyo jeer isku daydaa inaad hirgeliso [`From`] ka dibna aad dib ugu noqotaa [`Into`] haddii [`From`] aan la hirgelin karin.
///
/// # Examples
///
/// [`String`] fuliyaa [``Into`] '' <`['' Vec`]`<`[`u8`] `` >>:
///
/// Si loo muujiyo in aan dooneyno hawl guud oo aan ku qaadno dhammaan doodaha loo rogi karo nooc cayiman oo ah `T`, waxaan isticmaali karnaa trait bound ee [``Into`] ''<T>``.
///
/// Tusaale ahaan: Shaqada `is_hello` waxay qaadataa dhammaan doodaha loo rogi karo [``Vec`] '' <`[` u8`]`>>.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Waxay qabataa beddelaad
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Loo adeegsaday in lagu sameeyo beddelaad qiimo-ilaa-qiime iyadoo la isticmaalayo qiimaha soo galinta.Waa isweydaarsiga [`Into`].
///
/// Mid ka mid ah mar walba door bidaan waa fulinta `From` badan [`Into`] sababtoo ah fulinta `From` si toos ah siisaa mid la fulin ah [`Into`] mahad fulinta buste maktabadda calanka.
///
///
/// Kaliya hirgeli [`Into`] markaad bartilmaameedsaneysid nooc kahor Rust 1.41 oo aad ubadasho nooc ka baxsan crate hadda.
/// `From` ma u awoodin inuu sameeyo noocan ah beddelaad in qoraalkii hore sababtoo ah sharciga orphaning Rust ee.
/// Ka eeg [`Into`] wixii faahfaahin dheeraad ah.
///
/// Ka doorbido adeegsiga [`Into`] intaad isticmaaleyso `From` markaad ku qeexeyso trait bounds waxqabadka guud.
/// Sidan, noocyada sida tooska ah u hirgeliya [`Into`] waxaa loo isticmaali karaa dood ahaan sidoo kale.
///
/// `From` sidoo kale waa mid aad waxtar u leh marka la qabanayo qaladka wax ka qabashada.Markaad dhisayso hawl karti u leh fashilka, nooca soo noqoshada guud ahaan wuxuu noqon doonaa foomka `Result<T, E>`.
/// `From` trait wuxuu fududeynayaa maaraynta qaladka asaga oo u oggolaanaya howl inuu soo celiyo hal nooc qalad ah oo koobaya noocyo badan oo qalad ah.Eeg qaybta "Examples" iyo [the book][book] wixii faahfaahin dheeraad ah.
///
/// **Note: trait-kan waa inuusan fashilmin **.Haddii beddelka uu ku guuldareysto, isticmaal [`TryFrom`].
///
/// # Hirgelinta Guud
///
/// - `From<T> for U` waxay tilmaamaysaa [``Ino`] ' <U>' T`</u>
/// - `From` waa falcelin, taas oo macnaheedu yahay in `From<T> for T` la hirgeliyey
///
/// # Examples
///
/// [`String`] qalab `From<&str>`:
///
/// diinta ka cad ka `&str` ah in String ah waxaa loo sameeyaa sida soo socota:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Iyadoo fulineynin qalad qabashada inta badan waa waxtar leh si ay u hirgeliyaan `From` waayo adiga ku gaar ah nooca baadi.
/// By diinta noocyada baadi dahsoon to our caadadii gaar ah nooca qalad in islamarkaana nooca baadi dahsoon, waannu soo noqon karaa hal nooc qalad ah oo aan laga badinin macluumaad ku saabsan sababta dahsoon.
/// operator '?' ayaa si toos ah kuweeda nooca baadi dahsoon caadadii our nooca baadi adigoo wacaya `Into<CliError>::into` kaas oo si toos ah la siiyo marka la fulinayo `From`.
/// Isku-duwaha ayaa markaa soo bandhigaya hirgelinta `Into` waa in la isticmaalo.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Waxay qabataa beddelaad
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Beddelaad isku day ah oo cunaysa `self`, oo qaali noqon karta ama qaali noqon karto.
///
/// qorayaasha Library waa in sida caadiga ah ma si toos ah loo fuliyo trait this, laakiin waa in door bidaan fulinta [`TryFrom`] trait ah, taas oo bixisa dabacsanaan weyn oo ka bixisaa ah hirgelinta `TryInto` u dhiganta lacag la'aan ah, mahad fulinta buste maktabadda heer.
/// Wixii macluumaad dheeraad ah oo arrintan ku saabsan, ka eeg warqadaha ee [`Into`].
///
/// # Hirgalinta `TryInto`
///
/// Tani waxay la kulantaa xayiraado isku mid ah iyo sababayn la mid ah hirgelinta [`Into`], ka eeg halkaas faahfaahinta.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Nooca ayaa soo noqday haddii ay dhacdo qalad beddelaad.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Waxay qabataa beddelaad
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Simple iyo beddelaad nooca ammaan ah si hab gacanta xaaladaha qaarkood ku fashilmaan.Waa isweydaarsiga [`TryInto`].
///
/// Tani waa mid waxtar leh marka aad samaynayso diinta nooc ka mid ah waxaa laga yaabaa in trivially guulaysan laakiin sidoo kale waxay u baahan karaan gaar ah looga hawlgalaa.
/// Tusaale ahaan, ma jiraan wax jid si loogu badalo [`i64`] galay [`i32`] ah oo isticmaalaya trait [`From`] ah, maxaa yeelay, [`i64`] ah ku jiri kara qiimaha a in [`i32`] ah ma meteli karo oo si diinta ka soo lumin lahaa xogta.
///
/// Tan waxaa loo maareeyay si ay truncating [`i64`] si [`i32`] ah (muhiimad la siiyo [`i64`] 's qiimaha modulo [`i32::MAX`]) ama si fudud u soo laabtay [`i32::MAX`], ama qaar ka mid ah hab kale.
/// [`From`] trait waxaa loogu talagalay in si buuxda loogu beddelo, sidaa darteed `TryFrom` trait wuxuu ku wargeliyaa barnaamij-yaqaanha marka nooc beddelidda ay xumaan karto oo u oggolaaneysa inay go'aan ka gaaraan sida loo maareeyo.
///
/// # Hirgelinta Guud
///
/// - `TryFrom<T> for U` waxay tilmaamaysaa [``TryInto`] ``<U>ee T`</u>
/// - [`try_from`] waa awtomatik ah, taas oo macnaheedu yahay in `TryFrom<T> for T` la fuliyo iyo ma dafiri karto-la xidhiidha nooca `Error` for wacaya `T::try_from()` on qiimaha nooca `T` waa [`Infallible`].
/// Marka nooca [`!`] la xasiliyo [`Infallible`] iyo [`!`] ayaa u dhigmi doona.
///
/// `TryFrom<T>` waxaa loo hirgelin karaa sida soo socota:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Sida lagu qeexay, qalab [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Aamusnaan truncates `big_number`, waxay u baahan tahay baadhista iyo ka qabashada truncation ka dib markii xaqiiqda ah.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Sooceliyaa qalad maxaa yeelay `big_number` waa mid aad u weyn oo ku haboon in `i32` ah.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Sooceliyaa `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Nooca ayaa soo noqday haddii ay dhacdo qalad beddelaad.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Waxay qabataa beddelaad
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLSKA GUUD
////////////////////////////////////////////////////////////////////////////////

// Markuu kor u kaco&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Sida kor u qaadista &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): badalo impls kore&/&mut la socda mid ka mid ah guud:
// // Sida kor looga qaado Deref
// soo raaca <D: ?Sized + Deref<Target: AsRef<U>>, U:? Qiyaas ahaan> AsRef <U>loogu talagalay D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut wiishashka ka badan &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): badalo impl kore &mut la socda mid ka mid ah guud:
// // AsMut wuxuu kor u qaadayaa DerefMut
// soo raaca <D: ?Sized + Deref<Target: AsMut<U>>, U:? Xajmi> AsMut <U>for D {FN as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Laga soo bilaabo waxa ay tilmaamaysaa lagu
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Laga soo bilaabo (oo sidaas ku galay) waa falcelin
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Xasiloonida xasilloonida:** Qalabkani wali ma jiro, laakiin waxaan nahay "reserving space" inaan ku darno future.
/// Eeg [rust-lang/rust#64715][#64715] wixii faahfaahin ah.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): Samee hagaajin mabda 'ah.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom tilmaamaysaa TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// beddelaad isku hallayn karo waa semantically u dhiganta beddelaad ummado la nooca baadi Anfaco.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// KHUDBADAHA IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// THE NOOCA ma-LADAAD
////////////////////////////////////////////////////////////////////////////////

/// nooca baadi The for khaladaad in marnaba dhici kartaa.
///
/// Maaddaama enumkani uusan lahayn kala duwanaansho, qiimaha noocan ah weligiis runti ma jiri karo.
/// Tani waxay noqon kartaa mid faa'iido u isdiyaari, generic isticmaala [`Result`] iyo parameterize nooca qaladka, si ay u muujiyaan in natiijada had iyo jeer waa [`Ok`].
///
/// Tusaale ahaan, trait [`TryFrom`] ah (diinta in celinta [`Result`] a) uu leeyahay hirgelinta buste, waayo, dhammaan noocyada kala duwan halkaas oo a fulinta [`Into`] dambe jira ah.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Waafaqid Future
///
/// enum waxa uu leeyahay door la mid ah sida [the `!`“never”type][never], taas oo aan degganayn ee version this of Rust.
/// Marka `!` la xasiliyo, waxaan qorsheyneynaa inaan ka dhigno `Infallible` nooc la yiraahdo:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Oo aakhirka qiimo dhac ku sameeya `Infallible`.
///
/// Si kastaba ha ahaatee waxaa jira hal kiis meesha `!` Saan waxaa loo isticmaali karaa ka hor inta `!` la dejiyo sida nooca buuxa fuliya: booska shaqada ee nooca soo laabtay.
/// Gaar ahaan, waa fulintii suuragal ah in laba nooc oo kala duwan tilmaamaha shaqada:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Iyada oo `Infallible` isagoo enum ah, code this ansax tahay.
/// Si kastaba ha noqotee markii `Infallible` uu magac u noqdo never type, labada ``impl`s '' waxay bilaabi doonaan inay isdulsaaraan sidaa darteedna waxaa diidi doona xeerarka isku xirnaanta luqadda ee 'trait'.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}