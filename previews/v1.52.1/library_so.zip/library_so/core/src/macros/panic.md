Panics dunta hadda jirta.

Tani waxay u ogolaaneysaa barnaamij ay si degdeg ah u joojiyo iyo in Yeedhe barnaamijka bixiyaan jawaab celin.
`panic!` waa in la istcimaalaa marka barnaamijku gaaro dowlad aan la soo celin karin.

Dhaqale Tani waa habka ugu fiican in xaaladaha tilmaamaysaan in tusaale ahaan code iyo imtixaanada.
`panic!` ula xidhan la habka `unwrap` labada enums [`Option`][ounwrap] iyo [`Result`][runwrap].
Labada fulintii wac `panic!` marka ay qarka u saaran inuu [`None`] ama [`Err`] duwanaanshaha.

Marka la isticmaalayo `panic!()` waxaad cayimi kartaa payload string ah, oo la dhisay la isticmaalayo Saan [`format!`] ah.
payload oo loo isticmaalo marka la isku duro panic galay yeedhistii thread Rust, keenaya dunta si panic oo gebi ahaanba.

Dabeecadda `std` hook ee caadiga ah, ie
code in waddaa si toos ah ka dib markii panic la gawraco, waa in la daabaco payload fariin u `stderr` ah oo ay la socdaan macluumaadka file/line/column ee call `panic!()` ah.

Waxaad tirtirto karaa hook panic isticmaalaya [`std::panic::set_hook()`].
Inside hook ku panic ah laga heli karaa sida `&dyn Any + Send` ah, taas oo sidoo kale ku jira `&str` ama `String` for ducadaas `panic!()` joogto ah.
Si panic la qiimo ah nooc kale oo kale, [`panic_any`] waxaa loo isticmaali karaa.

[`Result`] enum inta badan waa xal wanaagsan uu ka soo kabsaday qalad tahay isticmaalka Dhaqale `panic!` ah.
Macro waa in loo adeegsadaa si looga fogaado sii wadista iyadoo la isticmaalayo qiyam qaldan, sida ilaha dibadda.
Macluumaad faahfaahsan oo ku saabsan maaraynta qaladka waxaa laga helayaa [book].

sidoo kale [`compile_error!`] ah Dhaqale eeg, waayo, kor qaladaad inta lagu jiro ururinta.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Hirgelinta hadda

Haddii thread ugu weyn panics waxay dhammayn doonaan threads oo dhan iyo la joojiyo barnaamijka aad la code `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





