#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Soo Kordhiyay in labada `$crate::panic::panic_2015` ama `$crate::panic::panic_2021` ku xiran edition ee wacaha.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Waxa uu sheegayaa in laba tibaaxaha waa u siman yihiin in kasta oo kale (iyadoo la isticmaalayo [`PartialEq`]).
///
/// On panic, Dhaqale this daabacan doonaa qiyamka tibaaxaha la Wakiilada Debug ay.
///
///
/// Like [`assert!`], Dhaqale waxay leedahay qaab labaad, halkaas oo ah caadada panic fariin lagu bixin karaa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // reborrows hoose waa ula kac ah.
                    // iyaga oo aan, Afyare xidhmooyin, waayo, wax buu amaahdaa ee la initialized xitaa ka hor inta qiimaha yihiin marka la barbar dhigo, taasoo keentay in hoos u gaabiyaa dareemi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // reborrows hoose waa ula kac ah.
                    // iyaga oo aan, Afyare xidhmooyin, waayo, wax buu amaahdaa ee la initialized xitaa ka hor inta qiimaha yihiin marka la barbar dhigo, taasoo keentay in hoos u gaabiyaa dareemi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Waxa uu sheegayaa in laba tibaaxaha aan waa u siman yihiin in kasta oo kale (iyadoo la isticmaalayo [`PartialEq`]).
///
/// On panic, Dhaqale this daabacan doonaa qiyamka tibaaxaha la Wakiilada Debug ay.
///
///
/// Like [`assert!`], Dhaqale waxay leedahay qaab labaad, halkaas oo ah caadada panic fariin lagu bixin karaa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // reborrows hoose waa ula kac ah.
                    // iyaga oo aan, Afyare xidhmooyin, waayo, wax buu amaahdaa ee la initialized xitaa ka hor inta qiimaha yihiin marka la barbar dhigo, taasoo keentay in hoos u gaabiyaa dareemi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // reborrows hoose waa ula kac ah.
                    // iyaga oo aan, Afyare xidhmooyin, waayo, wax buu amaahdaa ee la initialized xitaa ka hor inta qiimaha yihiin marka la barbar dhigo, taasoo keentay in hoos u gaabiyaa dareemi.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Waxa uu sheegayaa in hadal ah boolean waa `true` at Runtime.
///
/// Tani waxay baryi Dhaqale [`panic!`] haddii hadal la siiyo oo aan la qiimayn karaa si `true` at Runtime.
///
/// Like [`assert!`], Dhaqale this sidoo kale leeyahay version labaad, halkaas oo ah caadada panic fariin lagu bixin karaa.
///
/// # Uses
///
/// Si ka duwan [`assert!`], statements `debug_assert!` kaliya karti aan filaayo in dhistaa default.
/// dhista An filaayo in aan soo dejin doonaa statements `debug_assert!` haddii `-C debug-assertions` maray in compiler ah.
/// Tani waxay `debug_assert!` ka dhigeysaa mid waxtar u leh jeegaga oo aad qaali u ah in lagu sii daayo dhisme la sii daayo laakiin waxay noqon kartaa mid waxtar leh inta lagu jiro horumarka.
/// Natiijada ballaarinta `debug_assert!` had iyo jeer waa nooc la hubiyaa.
///
/// caddaynta An qaban ogolaanaya barnaamij gobolka ah oo khilaafsan in ay sii socda, taas oo laga yaabo in cawaaqib aan la filayn laakiin ma soo bandhigo unsafety ilaa iyo inta tani waxay dhacdaa keliya ee code ammaan ah.
///
/// Qiimaha waxqabadka ee sheegashooyinka, si kastaba ha noqotee, lama cabbiri karo guud ahaan.
/// Bedelaadda [`assert!`] la `debug_assert!` waa sidaas oo kaliya lagu dhiirigelinayaa ka dib markii dhamaystiran muuqaalka, iyo ka sii muhiimsan, keliya ee code ammaan ah!
///
/// # Examples
///
/// ```
/// // farriinta panic ee caddayntani waa qiimaha adag ee muujinta la bixiyay.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // hawl aad u fudud
/// debug_assert!(some_expensive_computation());
///
/// // ku caddee farriin qaas ah
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Wuxuu caddeynayaa in laba tibaaxood ay isleeyihiin midba midka kale.
///
/// On panic, Dhaqale this daabacan doonaa qiyamka tibaaxaha la Wakiilada Debug ay.
///
/// Si ka duwan [`assert_eq!`], statements `debug_assert_eq!` kaliya karti aan filaayo in dhistaa default.
/// dhista An filaayo in aan soo dejin doonaa statements `debug_assert_eq!` haddii `-C debug-assertions` maray in compiler ah.
/// Tani waxay `debug_assert_eq!` ka dhigeysaa mid waxtar u leh jeegaga oo aad qaali u ah in lagu sii daayo dhisme la sii daayo laakiin waxay noqon kartaa mid waxtar leh inta lagu jiro horumarka.
///
/// Natiijada ballaarinta `debug_assert_eq!` had iyo jeer waa nooc la hubiyaa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Wuxuu caddeynayaa in labo tibaaxood aysan sinnayn midba midka kale.
///
/// On panic, Dhaqale this daabacan doonaa qiyamka tibaaxaha la Wakiilada Debug ay.
///
/// Si ka duwan [`assert_ne!`], statements `debug_assert_ne!` kaliya karti aan filaayo in dhistaa default.
/// Dhisme la hagaajiyay ma fulin doono bayaanka `debug_assert_ne!` illaa `-C debug-assertions` loo gudbiyo isku-duwaha.
/// Taas ayaa ka dhigaysa `debug_assert_ne!` faa'iido badan ee jeeg in ay yihiin mid aad u qaali ah ku sugan dhismaha saamaxaad noqon laakiin waxaa laga yaabaa in waxtar leh inta lagu guda jiro horumarinta.
///
/// Natiijada ballaarinta `debug_assert_ne!` had iyo jeer waa nooc la hubiyaa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Soocelinayaa haddii muujinta la bixiyay ay u dhigantaa mid ka mid ah qaababka la bixiyay.
///
/// Like in hadal `match` ah, tilmaantii la optionally raacay karo by `if` iyo hadal askartu in uu heli karo magacyada ku xidhan hannaankii ah.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Waxay soo saartaa natiijo ama waxay faafisaa qaladkeeda.
///
/// operator `?` The lagu daray si uu u bedelo `try!` iyo waa in la isticmaalaa halkii.
/// Intaas waxaa sii dheer, `try` waa eray ku hayaa Rust 2018, sidaas darteed haddii Waa in aad isticmaasho, waxaad u baahan doontaa in aad isticmaasho [raw-identifier syntax][ris] ah: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` u dhigma [`Result`] la siiyay.In case of duwanaansho `Ok` ah, hadal uu leeyahay qiimaha qiimaha ku duudduubay.
///
/// In case of duwanaansho `Err` ah, waxa ay dib u baadi gudaha.`try!` ayaa markaa sameeya beddelaad iyadoo la adeegsanayo `From`.
/// Tani waxay bixisaa beddelaad otomaatig ah oo u dhexeeya khaladaadka khaaska ah iyo kuwa guud ee guud.
/// Khaladka ka dhashay ayaa markaa isla markiiba la soo celiyaa.
///
/// Sababta oo ah soo celinta hore, `try!` kaliya loo isticmaali karaa in hawlaha noqon [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Habka koowaad ee Khaladaadka soo laabtay degdeg ah
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Habka hore ee Khaladaadka soo laabtay degdeg ah
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Tani waxay u dhigantaa:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Waxay uqortaa xog qaabaysan keyd.
///
/// Dhaqale Tani aqbala 'writer' ah, string format ah, iyo liiska dood.
/// Dood la formatted doonaa si waafaqsan qaabka string qeexan iyo natiijada in qoraaga loo gudbin doonaa.
/// Qoraagu wuxuu noqon karaa qiime kasta oo leh habka `write_fmt`;guud ahaan tani waxay ka timaaddaa hirgelinta mid ka mid ah [`fmt::Write`] ama [`io::Write`] trait.
/// Macro wuxuu soo celiyaa wax kasta oo habka `write_fmt` soo celiyo;caadi [`fmt::Result`] ah, ama [`io::Result`] ah.
///
/// Eeg [`std::fmt`] wixii macluumaad dheeraad ah oo ku saabsan Saan format xarig ah.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// module A dajiyaan karaa labada `std::fmt::Write` iyo `std::io::Write` iyo call `write!` alaabta fulinta midkood, sida alaabta aadan caadi ahaan loo fuliyo labada.
///
/// Si kastaba ha ahaatee, module waa in dajiyaan traits ka baxday sidaas magacyadooda aan samayn isku dhaca:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // isticmaalaa fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // wuxuu adeegsadaa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Dhaqale Tani waxaa loo isticmaali karaa in dhismeedkan `no_std` iyo sidoo.
/// In Mudanayaasha `no_std` ah waxaad masuul ka tahay faahfaahinta fulinta qaybaha ka.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Qor xogta formatted galay kayd, iyadoo newline a lifaaqo.
///
/// On oo dhan dhufto, newline waa qof daaqi LINE (`\n`/`U+000A`) oo keliya (no dheeraad ah qaadee NOQOSHADDA (`\r`/`U+000D`).
///
/// Wixii macluumaad dheeraad ah, eeg [`write!`].Macluumaad ku saabsan qaabka xargaha qaabeynta, eeg [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// module A dajiyaan karaa labada `std::fmt::Write` iyo `std::io::Write` iyo call `write!` alaabta fulinta midkood, sida alaabta aadan caadi ahaan loo fuliyo labada.
/// Si kastaba ha ahaatee, module waa in dajiyaan traits ka baxday sidaas magacyadooda aan samayn isku dhaca:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // isticmaalaa fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // wuxuu adeegsadaa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Waxay muujineysaa koodh aan la gaari karin.
///
/// Tani waa waqti kasta in compiler ah ma cadayn karto in code qaar ka mid ah waa gaari waxtar leh.Tusaale ahaan:
///
/// * Kulanka hubka qaba xaaladaha waardiyayaasha.
/// * Loops oo si firfircoon u joojiya.
/// * Iskuduwaha si firfircoon u joojiya.
///
/// Haddii go'aanka ah in code waa gaari daliil sax ahayn, barnaamijka isla markiiba joojiso la [`panic!`] ah.
///
/// dhigiisa The ammaan ahayn ee Dhaqale tani waa shaqo [`unreachable_unchecked`] ah, taas oo ka dhigi doonaa in dhaqanka undefined haddii xeerka la gaaro.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Tani waxay had iyo jeer doonaysaa [`panic!`].
///
/// # Examples
///
/// Gacmaha ciyaarta:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // ururiso baadi haddii hadashay baxay
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // mid ka mid ah fulinta ugu liidata ee x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Waxay muujineysaa koodh aan la hirgelin iyadoo argagax leh fariin "not implemented" ah.
///
/// Tani waxay u ogolaaneysaa in aad code nooca-jeeg, taas oo waxtar leh haddii aad wadanay ama fulinta trait u baahan in habab badan oo aadan samayn qorshe la isticmaalayo oo dhan.
///
/// Farqiga u dhexeeya `unimplemented!` iyo [`todo!`] waa in halka `todo!` xambaarsanyahay, ujeedadu ah fulinta shaqeynta ka dib iyo fariinta waa "not yet implemented", `unimplemented!` ka dhigaa jirin sheegashooyinka sida.
/// Farriinteedu waa "not implemented".
/// Sidoo kale qaar ka mid ah IDEs calaamadee doonaa `todo!` S.
///
/// # Panics
///
/// doonistii Tani waxay had iyo jeer [`panic!`] maxaa yeelay `unimplemented!` waa uun saarista ah `panic!` leh go'an, fariin gaar ah.
///
/// Like `panic!`, Dhaqale waxay leedahay qaab labaad oo ay u soo bandhigeen qiimaha caadadii.
///
/// # Examples
///
/// Waxaad dhahdaa waxaan leenahay trait `Foo` ah:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Waxaan rabnaa in aan fuliyo `Foo` for 'MyStruct', laakiin sabab qaar ka mid ah waxa keliya oo macno si loo fuliyo shaqo `bar()` ah.
/// `baz()` iyo `qux()` weli u baahan doontaa inaad la qeexay hirgelinta `Foo` our, laakiin waxaan isticmaali kartaa `unimplemented!` in sharaxyo ay u oggolaadaan in our code inay isku ururiso.
///
/// Waxaan weli dooneynaa in barnaamijkeenu joojiyo socodkiisa haddii qaababka aan la hirgelin la gaaro.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Waxaa macno lahayn in `baz` `MyStruct` ah, sidaasi darteed waa inaan macquulka ma halkan at dhan.
/////
///         // Tani waxay muujin doonaa "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Waxaan halkaan ku haynaa caqli gal, Waxaan ku dari karnaa farriin aan la fulin!si loo muujiyo ka tagitaankeena.
///         // Tani waxay muujin doontaa: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Waxay muujineysaa koodh aan dhammaystirnayn.
///
/// Tani waxay noqon kartaa mid waxtar leh haddii aad wadanay oo kaliya raadinaya u leedahay in typecheck code.
///
/// Farqiga u dhexeeya [`unimplemented!`] iyo `todo!` waa in halka `todo!` xambaarsanyahay, ujeedadu ah fulinta shaqeynta ka dib iyo fariinta waa "not yet implemented", `unimplemented!` ka dhigaa jirin sheegashooyinka sida.
/// Farriinteedu waa "not implemented".
/// Sidoo kale qaar ka mid ah IDEs calaamadee doonaa `todo!` S.
///
/// # Panics
///
/// Tani waxay had iyo jeer doonaysaa [`panic!`].
///
/// # Examples
///
/// Waa kuwan tusaale qaar ka mid ah koodhka socda.Waxaan haynaa trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Waxaan rabnaa in aan fuliyo `Foo` on mid ka mid ah noocyada our, laakiin waxaan sidoo kale doonayaa in aan shaqada on kaliya `bar()` ugu horeysay.Si code our inay isku ururiso, waxaan u baahan nahay si ay u hirgeliyaan `baz()`, sidaas darteed waxaan u isticmaali kartaa `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // hirgelinta halkaan ayey tagtaa
///     }
///
///     fn baz(&self) {
///         // aynu ka welwelin ku saabsan hirgelinta baz() waayo, haatan
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // xitaa ma isticmaaleyno baz(), marka tani way fiicantahay.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Qeexitaannada makroosyada la dhisay.
///
/// Inta badan oo ka mid ah guryaha Dhaqale (xasiloonida, aragti, iwm) waxaa laga qaadaa code source halkan, marka laga reebo hawlaha fidinta ekaysiinaya gashiga Dhaqale galay soo saarka, hawlaha kuwa la siiyaa by compiler ah.
///
///
pub(crate) mod builtin {

    /// Waxay keenaysaa isku-duwidda inay ku fashilanto farriinta qaladka la siiyay markay la kulanto.
    ///
    /// Dhaqale Tani waa in la isticmaalaa marka crate isticmaalo istaraatijiyad duwidda shuruud si ay u bixiyaan fariimaha fiican baadi xaaladaha khalad.
    ///
    /// Waa qaab heer-compiler ah [`panic!`] ah, laakiin shanqarta qalad inta lagu guda jiro isku duwidda * * halkii at Runtime * *.
    ///
    /// # Examples
    ///
    /// Laba tusaale oo noocaas ah waa deegaanka makro iyo `#[cfg]`.
    ///
    /// Dhaadheer baadi compiler fiican haddii Dhaqale la maray qiimaha sax ahayn.
    /// Iyadoo aan la helin branch-ka ugu dambeeya, isku-duwaha ayaa wali sii deyn doona qalad, laakiin farriinta qaladku ma xusi doonto labada qiime ee saxda ah.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// U daa khaladka isku-darka haddii mid ka mid ah astaamaha aan la heli karin.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Dhista koobin ee macros kale string-formatting.
    ///
    /// Tani Dhaqale hawlaha by qaadashada string ah formatting suugaan ay ku jiraan `{}` tusaale muran kasta oo dheeraad ah maray.
    /// `format_args!` wuxuu diyaariyaa cabirro dheeri ah si loo hubiyo in soosaarka loo tarjumi karo inuu yahay xarig isla markaana uu doodaha hal nooc unoqon karo.
    /// qiimaha kasta oo qalab trait [`Display`] ah la isugu gudbin karaa in `format_args!`, sida fulinta wixii [`Debug`] lagu `{:?}` a gudbin karaa gudahood xadhigga formatting.
    ///
    ///
    /// Dhaqale Tani waxay soo saartaa qiimaha nooca [`fmt::Arguments`].Qiimaha Tani waxay si macros la gudbin karaa gudahood [`std::fmt`] hawl dib u tilmaamid waxtar leh.
    /// All macros formatting kale ([`format!`], [`write!`], [`println!`], iwm) waxaa lagu proxied iyada oo tani ka mid ah.
    /// `format_args!`, Si ka duwan macroskeeda la soo saaray, wuxuu ka fogaadaa qoondayn badan.
    ///
    /// Waxaad isticmaali kartaa qiimaha [`fmt::Arguments`] in `format_args!` laabtay xaaladaha `Debug` iyo `Display` sida hoos ku arkay.
    /// Tusaalaha ayaa sidoo kale muujinaya in qaabka `Debug` iyo `Display` isla shayga: qaabka xariiqa isku dhexjira ee `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Wixii macluumaad dheeraad ah, ka eeg dukumentiyada ku qoran [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// La mid ah sida `format_args`, laakiin ku darayaa newline ah in dhamaadka.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Waxay kormeertaa jawiga deegaanka isbeddelka waqtiga la soo uruurinayo.
    ///
    /// Dhaqale Tani waxay ballaarin doonto in qiimaha variable ku magacaaban deegaanka waqti isku ururiso, dhalaya hadal ah oo nooca `&'static str`.
    ///
    ///
    /// Haddii doorsoomaha deegaanka aan la qeexin, markaa qalad uruurinta ayaa la daadin doonaa.
    /// Si aadan u soo saarin qalad la soo uruuriyay, isticmaal macro [`option_env!`] ah.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Waad habeyn kartaa farriinta qaladka adoo u maraya xarig ah halbeegga labaad:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Haddii isbeddelka deegaanka `documentation` aan la qeexin, waxaad heli doontaa qaladka soo socda:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Optionally kormeerta variable jawi waqti isku ururiso.
    ///
    /// Haddii doorsoomaha deegaanka la magacaabay uu joogo waqtiga la soo ururinayo, tani waxay u ballaadhi doontaa muujinta nooca `Option<&'static str>` oo qiimihiisu yahay `Some` ee qiimaha isbeddelka deegaanka.
    /// Haddii variable deegaanka ma joogo, ka dibna this fidi doonto si ay `None`.
    /// Eeg [`Option<T>`][Option] wixii macluumaad dheeraad ah oo ku saabsan nooca this.
    ///
    /// A baadi waqti isku ururiso marna timaada marka la isticmaalayo Dhaqale this loo eegin in variable deegaanka joogo ama aan.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Wuxuu isku daraa aqoonsiyeyaasha hal aqoonsi.
    ///
    /// Macro-kani wuxuu qaadaa lambar kasta oo aqoonsiyo kala-jajab ah, oo dhammaantoodna wuxuu isugu geeyaa mid, isagoo keenaya hadal ah aqoonsi cusub.
    /// Fiiro gaar ah nadaafadda ka dhigaya sida in Dhaqale tani ma qabsan karo doorsoomayaal maxaliga ah.
    /// Sidoo kale, sida caadiga ah, macros waxaa loo ogol yahay in item, hadal ama meel qowlka.
    /// Taasi hab inta aad isticmaali kartaa Dhaqale this for tilmaamayo jira doorsoomayaasha, hawlaha ama modules iwm, ma waxaad u qeexi kartaa mid cusub la.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // concat_idents FN (cusub, madadaalo, magaca) { }//ma isticmaali karo hab this!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates literals galay jeex guurto ah string ah.
    ///
    /// Macro-kani wuxuu qaadaa tiro kasta oo suugaan-yaasha comma-kala-go'an ah, taasoo bixinaysa muujinta nooca `&'static str` oo matalaya dhammaan suugaan-wadayaasha bidixda-midigta la isugu geeyay.
    ///
    ///
    /// Abyoonaha iyo dhibic sabayn literals waxaa stringified si loo concatenated.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ballaadhiyaa lambarka xariiqda ee laga codsaday.
    ///
    /// Iyada oo [`column!`] iyo [`file!`], macros kuwaas bixiyaan macluumaad debugging loogu talagalay horumarinta ku saabsan meesha uu gudahood isha.
    ///
    /// Tibaaxda balaariyay leeyahay nooca `u32` oo waa 1-ku salaysan, si safka ugu horreeya ee kasta qiimeeyaan file 1, kii labaadna 2, iwm
    /// Tani waa inay waafaqsan yihiin fariimaha qalad by compilers caadi ah ama tafatirayaasha caan ah.
    /// line soo noqdeen waa *daruuri ma aha* line ee ogyn `line!` laftiisa, laakiin halkii ogyn ugu horeysay Dhaqale ilaa taasoo keentay in ogyn ee Dhaqale `line!` ah.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ballaarinaya in tiro column ee taas oo loo yeedho.
    ///
    /// Iyadoo la adeegsanayo [`line!`] iyo [`file!`], macros-yadaani waxay bixiyaan macluumaad khalad ah oo loogu talagalay horumariyeyaasha ku saabsan meesha ay ku taal isha.
    ///
    /// Tibaaxda balaariyay leeyahay nooca `u32` oo waa 1-ku salaysan, si column ugu horeysay walba qiimeeyaan line 1, kii labaadna 2, iwm
    /// Tani waa inay waafaqsan yihiin fariimaha qalad by compilers caadi ah ama tafatirayaasha caan ah.
    /// column soo noqdeen waa *daruuri ma aha* line ee ogyn `column!` laftiisa, laakiin halkii ogyn ugu horeysay Dhaqale ilaa taasoo keentay in ogyn ee Dhaqale `column!` ah.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Ballaarinaya magaca file kuwaas oo waxaa loo yeedho ah.
    ///
    /// Iyadoo la adeegsanayo [`line!`] iyo [`column!`], macros-yadaani waxay bixiyaan macluumaad khalad ah oo loogu talagalay horumariyeyaasha ku saabsan meesha ay ku taal isha.
    ///
    /// Muujinta la ballaariyey waxay leedahay nooca `&'static str`, feylka la soo celiyeyna ma aha baryootanka `file!` macro laftiisa, laakiin waa baryada ugu horreysa ee loo yaqaan 'macro' oo loo horseedo baaqashada macruufka `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Wuxuu xaddidayaa dooddiisa.
    ///
    /// Dhaqale Tani waxay dhali doono hadal ah oo nooca `&'static str` taas oo stringification oo dhan tokens si Dhaqale ka gudbay.
    /// Wax xayiraad ah lama saarin sintirka macruufka laftiisa.
    ///
    /// Xusuusnow in natiijooyinka la ballaariyey ee gelinta tokens ay wax ka beddeli karto future.Waa inaad taxaddar sameysaa haddii aad ku tiirsan tahay wax soo saarka.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Waxaa ka mid ah encoded file UTF-8 sida string ah.
    ///
    /// Faylka wuxuu ku yaal meel u dhow faylka hadda jira (si la mid ah sida modules loo helo).
    /// Jidka bixiyo waxaa lagu micneeyey jidka madal-gaar ah waqti isku ururiso ah.
    /// Sidaas daraaddeed, tusaale ahaan, ogyn la Jidka Windows ka kooban backslashes `\` aan si sax ah isku ururiso lahaa Unix.
    ///
    ///
    /// Dhaqale Tani waxay dhali doono hadal ah oo nooca `&'static str` taas oo ka kooban faylka.
    ///
    /// # Examples
    ///
    /// Qabtaan in ay jiraan laba faylasha ee buugga tusaha isku waxyaabaha soo socda:
    ///
    /// Fayl 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fayl 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Uruurinta 'main.rs' iyo socodsiinta binary-ga soo baxa ayaa daabacan doonta "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Waxaa ka mid ah file a sidii marjic u soo diyaariyeen byte ah.
    ///
    /// Faylka wuxuu ku yaal meel u dhow faylka hadda jira (si la mid ah sida modules loo helo).
    /// Jidka bixiyo waxaa lagu micneeyey jidka madal-gaar ah waqti isku ururiso ah.
    /// Sidaas daraaddeed, tusaale ahaan, ogyn la Jidka Windows ka kooban backslashes `\` aan si sax ah isku ururiso lahaa Unix.
    ///
    ///
    /// Dhaqale Tani waxay dhali doono hadal ah oo nooca `&'static [u8; N]` taas oo ka kooban faylka.
    ///
    /// # Examples
    ///
    /// Qabtaan in ay jiraan laba faylasha ee buugga tusaha isku waxyaabaha soo socda:
    ///
    /// Fayl 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fayl 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Uruurinta 'main.rs' iyo socodsiinta binary-ga soo baxa ayaa daabacan doonta "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ballaarinaya in string ah in ay ka dhigan tahay waddada module hadda.
    ///
    /// Jidka moduleka hadda jira waxaa loo maleyn karaa inuu yahay jaangooyooyin qayb ka mid ah dib u soo celinta crate root.
    /// qayb koowaad ee jidka ku soo laabtay waa magaca crate hadda la diyaarinayaa.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Qiimeeyaan isku boolean of calanka qaabeynta at-waqti isku ururiso.
    ///
    /// Marka lagu daro astaamaha `#[cfg]`, makro-kan waxaa loo bixiyay si loogu oggolaado qiimeynta muujinta boolaha ee calanka qaabeynta.
    /// Tani waxay si joogto ah raadad si code yar labalaabka.
    ///
    /// Saan la siiyay Dhaqale tani waa Saan la mid ah sida sifo [`cfg`] ah.
    ///
    /// `cfg!`, ka duwan `#[cfg]`, ma ka saari code kasta oo kaliya qiimeysaa in ay run tahay ama been ah.
    /// Tusaale ahaan, dhan blocks in an u baahan hadal if/else in ay ansax ahaato marka `cfg!` waxaa loo isticmaalaa xaaladda, iyadoo aan loo eegin waxa `cfg!` waxaa la qiimeeyo.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Wuxuu fayl gareeyaa feker ahaan sida shay ama shay iyadoo loo eegayo macnaha guud.
    ///
    /// Faylka wuxuu ku yaal meel u dhow faylka hadda jira (si la mid ah sida modules loo helo).Jidka bixiyo waxaa lagu micneeyey jidka madal-gaar ah waqti isku ururiso ah.
    /// Sidaas daraaddeed, tusaale ahaan, ogyn la Jidka Windows ka kooban backslashes `\` aan si sax ah isku ururiso lahaa Unix.
    ///
    /// Isticmaalka Dhaqale this inta badan waa fikrad xun, sababtoo ah haddii file waxaa parsed sida weer, waxaa la doonayo in la geeyaa code ku xeeran booraha.
    /// Tani waxay keeni kartaa in doorsoomayaasha ama hawlaha isagoo ka faylka la filayaa kala duwan haddii ay jiraan doorsoomayaal ama hawlaha in ay leeyihiin magac la mid ah in file hadda.
    ///
    ///
    /// # Examples
    ///
    /// Qabtaan in ay jiraan laba faylasha ee buugga tusaha isku waxyaabaha soo socda:
    ///
    /// Fayl 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fayl 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Uruurinta 'main.rs' iyo socodsiinta binary-ga soo baxa ayaa daabacan doonta "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Waxa uu sheegayaa in hadal ah boolean waa `true` at Runtime.
    ///
    /// Tani waxay baryi Dhaqale [`panic!`] haddii hadal la siiyo oo aan la qiimayn karaa si `true` at Runtime.
    ///
    /// # Uses
    ///
    /// Si waafi ah mar walba hubiyaa in Debug iyo sii daayo labada dhistaa, oo aan la naafo karo.
    /// Ka eeg [`debug_assert!`] sheegashooyinka aan karti u siin sii deynta dhisme ahaan.
    ///
    /// code Nabadla 'tiirsan waxaa laga yaabaa on `assert!` si uu u dhaqan invariants-time ay maamulaan in, haddii xad keeni kara in unsafety.
    ///
    /// isticmaalka-kiisaska kale ee `assert!` ka mid ah tijaabinta iyo hirgelinta invariants-time orod ee code ammaan ah (kuwaas oo xadgudub ma keeni kartaa unsafety).
    ///
    ///
    /// # Farriimaha Custom
    ///
    /// Macro-kani wuxuu leeyahay qaab labaad, halkaas oo fariin panic ah oo caadiya lagu bixin karo ama aan lahayn doodo ku saabsan qaabeynta.
    /// Eeg [`std::fmt`] for Saan for foomkan.
    /// Weer loo isticmaalaa sida dood format la qiimayn doonaa oo kaliya haddii caddaynta ku fashilanto.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // farriinta panic ee caddayntani waa qiimaha adag ee muujinta la bixiyay.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // hawl aad u fudud
    ///
    /// assert!(some_computation());
    ///
    /// // ku caddee farriin qaas ah
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Isku xirka khadka.
    ///
    /// Read [unstable book] ee diinta.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-style Wabka shirka.
    ///
    /// Read [unstable book] ee diinta.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Isku-xirka khadadka heerka Module-ka ah.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Daabacashooyinka maray tokens galay wax soo saarka caadiga ah.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Awood ama disables baafinta ka shaqeynayaan loo isticmaalo debugging macros kale.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Sifee dhaqaatiirta loo isticmaalo in lagu mariyo dhadhanka macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Dhaqale sifo codsatay in shaqo ah si ay u leexdo xagga imtixaanka qeybta ah.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Sifee dhaqalo lagu dabaqay hawl si ay ugu rogto tijaabada cabbirka.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// si faahfaahsan fulinta An ah macros `#[test]` iyo `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Dhaqale sifo codsatay in ay guurto ah si ay u diiwaan sida allocator caalami ah.
    ///
    /// Sidoo kale eeg [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Waxay haysaa sheyga lagu dabaqay haddii dariiqa la maray la heli karo, oo si kale ayuu uga saarayaa.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Ballaarinaya `#[cfg]` oo dhan iyo `#[cfg_attr]` sifooyinkii in jab code waxa uu codsatay in ay ku.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// si faahfaahsan fulinta deganayn ee compiler `rustc` ah, ha isticmaalin.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// si faahfaahsan fulinta deganayn ee compiler `rustc` ah, ha isticmaalin.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}