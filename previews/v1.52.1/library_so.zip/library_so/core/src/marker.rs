//! Heer hoose traits iyo nooc oo wakiil ka ah guryaha aasaasiga ah ee noocyada.
//!
//! noocyada Rust loo kala saari karaa siyaabo kala duwan oo waxtar leh sida ay xoolahooda kala go'lahayn.
//! Kala soocyadan waxaa loo metelaa sida traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Noocyada loo gudbin karo xuduudaha dunta.
///
/// trait-kan ayaa si otomaatig ah loo hirgeliyaa marka isku-duwaha uu go'aamiyo inuu habboon yahay.
///
/// Tusaale ka mid ah a nooca aan `Send` waa tilmaamaha tixraac-tirinta [`rc::Rc`][`Rc`] ah.
/// Haddii laba threads isku dayaan in ay Gadzhiyev [`Rc`] s dhibic in si qiime isku mid tixraac-tirin, waxay isku dayi kartaa inaad cusboonaysiiso count tixraaca waqti isku mid ah, taas oo ah sababta oo ah [undefined behavior][ub] [`Rc`] uusan isticmaalin hawlaha qaaradda.
///
/// Its adeer [`sync::Arc`][arc] ma isticmaali hawlgallada qaaradda (kharaj dusha qaar ka mid ah) iyo sidaas waa `Send`.
///
/// Ka eeg [the Nomicon](../../nomicon/send-and-sync.html) wixii faahfaahin dheeraad ah.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Noocyada la size si joogto ah loo yaqaan wakhtiga ururinta.
///
/// Dhammaan cabbiraadaha nooca waxay leeyihiin xaddid aan toos ahayn oo ah `Sized`.Qaaciddada qaaska ah ee `?Sized` waxaa loo isticmaali karaa in laga saaro xariggan haddii aysan habboonayn.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // dhismaha FooUse(Foo<[i32]>);//qalad: Qiyaasta looma hirgelin [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// The marka laga reebo mid ka mid ah waa nooca `Self` awaamiir of trait ah.
/// trait ma laha `Sized` aan toos ahayn oo ku xidhan maaddaama tani aysan la jaan qaadi karin [trait shayga] halkaasoo, qeexitaan ahaan, trait ay u baahan tahay inay la shaqeyso dhammaan fuliyaasha suurtagalka ah, sidaas darteedna waxay noqon kartaa cabir kasta.
///
///
/// Inkastoo Rust sii dayn doonaa inaad ku xidhaa `Sized` in trait ah, ma awoodi doonaan in ay u isticmaalaan si ay u sameeyaan wax trait ka dib:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ha y: &dyn Bar= &Impl;//baadi: `Bar` trait loo sameeyey karaa shay
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // Default, tusaale ahaan, oo u baahan in `[T]: !Default` la qiimeyn karo
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Noocyada in ay noqon kartaa "unsized" nooc dynamically yimaa-.
///
/// Tusaale ahaan, nooca xajmiga xajmiga ah ee `[i8; 2]` wuxuu hirgeliyaa `Unsize<[i8]>` iyo `Unsize<dyn fmt::Debug>`.
///
/// Dhammaan hirgelinta `Unsize` waxaa si otomaatig ah u keena isku-duwaha.
///
/// `Unsize` waxaa loo fuliyaa:
///
/// - `[T; N]` waa `Unsize<[T]>`
/// - `T` waa `Unsize<dyn Trait>` markii `T: Trait`
/// - `Foo<..., T, ...>` waa `Unsize<Foo<..., U, ...>>` haddii:
///   - `T: Unsize<U>`
///   - Foo waa dhisme
///   - Kaliya qaybta ugu dambeysa ee `Foo` waxay leedahay nooc ku lug leh `T`
///   - `T` qayb kama aha nooca beero kale
///   - `Bar<T>: Unsize<Bar<U>>`, haddii duurka ugu dambeeyey ee `Foo` ayaa `Bar<T>` nooca
///
/// `Unsize` waxaa loo isticmaalaa oo ay la socdaan [`ops::CoerceUnsized`] in ay oggolaadaan in weelasha "user-defined" sida [`Rc`] in ay ku jiraan noocyo kala dynamically yimaa-.
/// Ka eeg [DST coercion RFC][RFC982] iyo [the nomicon entry on coercion][nomicon-coerce] wixii faahfaahin dheeraad ah.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Loo baahan yahay trait for geysid loo isticmaalo in kulan hannaankii.
///
/// nooca kasta oo waxuu ka `PartialEq` si toos ah fulisaa trait this,* * eegin in nooca-beegyada ay hirgeliyaan `Eq`.
///
/// Haddii item `const` ah waxaa ku jira qaar ka mid ah nooca in aanay fulin trait this, ka dibna in nooca labada (1.) aanay fulin `PartialEq` (taas oo macnaheedu yahay si joogto ah ma ku siin doonaa hab la barbardhigo in, taas oo qarniga code qabanayaa waa la heli karo), ama waxaa (2.) qalab *u gaar ah* version of `PartialEq` (taas oo aynu ka fikirno aan isaga waafaqsanaynina, in la barbardhigo dhismaha-sinaanta a).
///
///
/// Labada xaaladood ee kor ku xusan midkood, waxaan diidnay adeegsiga sida joogtada ah ee ciyaarta qaab ahaanta.
///
/// sidoo kale eeg [structural match RFC][RFC1445], iyo [issue 63438] oo guuraysaa dano ka design sifo ku salaysan in trait this.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Loo baahan yahay trait for geysid loo isticmaalo in kulan hannaankii.
///
/// nooca kasta oo waxuu ka `Eq` si toos ah fulisaa trait this,* * eegin in xuduudaheedu nooca ay hirgeliyaan `Eq`.
///
/// Tani waa khawano lagu shaqeynayo hareeraha xaddidnaanta nidaamkayaga nooca ah.
///
/// # Background
///
/// Waxaan dooneynaa inaan ubaahano in noocyada cufnaanta ee loo isticmaalo qaababka isku dheelitirku ay leeyihiin astaan `#[derive(PartialEq, Eq)]`.
///
/// Adduun ka fiican, waxaan ku hubin karnaa shuruudda annaga oo kaliya iska hubinna in nooca la siiyay uu fulinayo labadaba `StructuralPartialEq` trait *iyo* the `Eq` trait.
/// Si kastaba ha noqotee, waxaad heli kartaa ADT-yada *samee*`derive(PartialEq, Eq)`, oo noqo kiis aan dooneyno isku-duwaha inuu aqbalo, oo haddana nooca joogtada ah uu ku guuldareysto inuu hirgeliyo `Eq`.
///
/// Magac ahaan, kiis sidan oo kale ah:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Dhibaatada ku jirta koodhka kor ku xusan waa in `Wrap<fn(&())>` uusan fulin `PartialEq`, ama `Eq`, maxaa yeelay `` <'a> fn(&'a _)` does not implement those traits.))
///
/// Sidaa darteed, waxaan aan ku kalsoonaan kartaa jeeg arinku for `StructuralPartialEq` iyo Diintooda `Eq`.
///
/// Fursad ahaan inaan ka shaqeyno tan, waxaan isticmaalnaa laba traits oo kala duwan oo lagu durayo mid kasta oo ka mid ah labada dariiqo ee kala ah (`#[derive(PartialEq)]` iyo `#[derive(Eq)]`) oo hubi in labadoodaba ay joogaan qayb ka mid ah hubinta qaabdhismeedka ciyaarta.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Noocyada kuwaas oo qiimaha la labalaabka karaa si fudud by dayanayaan gelinno.
///
/// By default, bindings variable leeyihiin 'kelmedo ku biiro. "Si kale haddii loo dhigo:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` wuxuu u gudbay `y`, sidaa darteedna lama isticmaali karo
///
/// // println! ("{: ?}", x);//qalad: isticmaalka qiimaha la dhaqaajiyay
/// ```
///
/// Si kastaba ha ahaatee, haddii a qalab nooca `Copy`, waxaa halkii uu leeyahay 'nuqul kelmedo':
///
/// ```
/// // Waxaan ka soo qaadan karnaa hirgelinta `Copy`.
/// // `Clone` waxaa kale oo loo baahan yahay, sida ay tahay supertrait ah `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` waa nuqul ka mid ah `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Waxa muhiim ah in la ogaado in labadan tusaale, farqiga kaliya ee waa in aad loo ogol yahay in ay helaan `x` ka dib shaqo ka.
/// Daboosho, labada nuqul oo dhaqaaqo waxay keeni kartaa in gelinno la soo guuriyeen ee xasuusta, inkasta oo ay tani waxaa mararka qaarkood iska filaayo.
///
/// ## Sideen ku hirgelin karaa `Copy`?
///
/// Waxaa jira laba qaab oo loo hirgaliyo `Copy` noocaaga.Midda ugu fudud ayaa ah in la isticmaalo `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Waxa kale oo aad hirgelin karaan `Copy` iyo `Clone` gacanta:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Waxaa jira farqi u yar ayaa labada u dhexeeya: istiraatiijiyad `derive` ayaa sidoo kale ka dhigi doonaa `Copy` ah ku xidhay on-beegyada uu nooc, taas oo had iyo jeer ma doonayo.
///
/// ## Waa maxay farqiga u dhexeeya `Copy` iyo `Clone`?
///
/// Nuqulada si dadban dhici, tusaale ahaan qayb ka ah hawl `y = x`.Dabeecadda `Copy` ma aha mid la rari karo;had iyo jeer waa nuqul fudud oo xoogaa caqli yar.
///
/// Cloning waa tallaabo cad, `x.clone()`.hirgelinta [`Clone`] ku siin kara wax kasta oo dabeecad nooc-gaar ah lagama maarmaan ah in nuqul qiimaha si ammaan ah.
/// Tusaale ahaan, hirgelinta [`Clone`] ee [`String`] waxay u baahan tahay inay nuqul ka dhigto xarig-tilmaameedka xargaha.
/// Nuqul fudud oo ka mid ah qiimaha [`String`] ayaa kaliya koobiyeyn doona tilmaamaha, taasoo u horseedi doonta khadka labalaab la'aan.
/// Sababtan awgeed, [`String`] waa [`Clone`] laakiin ma `Copy`.
///
/// [`Clone`] waa supertrait ah `Copy`, sidaa darteed wax walba oo ah `Copy` waa inay sidoo kale hirgeliyaan [`Clone`].
/// Haddii nooc ka mid ah waa `Copy` markaas hirgelintiisa [`Clone`] kaliya u baahan yahay inuu ku soo laabto `*self` (eeg tusaalaha kore).
///
/// ## Goorma nuuceygu noqon karaa `Copy`?
///
/// nooca A hirgelin karaan `Copy` haddii dhammaan qaybaha ay hirgeliyaan `Copy`.Tusaale ahaan, qaab-dhismeedkani wuxuu noqon karaa `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Qaab dhismeedku wuxuu noqon karaa `Copy`, [`i32`]-na waa `Copy`, sidaa darteed `Point` wuxuu xaq u leeyahay inuu noqdo `Copy`.
/// Taas bedelkeeda, tixgeli
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` struct The ma meel marin karo `Copy`, maxaa yeelay, [`Vec<T>`] ma aha `Copy`.Haddii aan isku dayo in la soo dheegato fulinta `Copy` ah, waxaan ka heli doonaa qalad:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// tixraacyada wadaago (`&T`) sidoo kale `Copy`, sidaas nooc ka mid ah noqon kartaa `Copy`, xitaa marka la tixraaci karo noocyada `T` in *ma*`Copy` jac la wadaago.
/// Tixgeli struct soo socda, kuwaas oo meel marin karo `Copy`, sababta oo ah waxa kaliya ee heysta a *tixraaca la wadaago* to our nooca aan `Copy` `PointList` ka kor ku xusan:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Goorma * * noocaygu noqon karin `Copy`?
///
/// Noocyada qaar looma guurin karo si badbaado leh.Tusaale ahaan, dayanayaan `&mut T` abuuri lahaa ah aliased tixraaca mutable.
/// Dayanayaan [`String`] nuqul lahaa mas'uuliyadda maaraynta [`String`] 's baseka, taasoo keentay in a free double.
///
/// Guud Xaalada danbe, nooc kasta oo fulinaya [`Drop`] ma noqon karo `Copy`, maxaa yeelay waxa uu ku maareeyo khayraadka qaar ka mid ah ka soo hadhay ee u gaarka ah [`size_of::<T>`] bytes.
///
/// Haddii aad isku daydo in ay hirgeliyaan `Copy` on struct ama enum ay ku jiraan xogta aan `Copy`, waxaad ka heli doontaa qaladka [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Goorma * ** noocaygu noqonayaa `Copy`?
///
/// Guud ahaan, haddii nooca _can_ fuliyo `Copy`, ku habboonayd.
/// Maskaxda ku hay, in kastoo, in hirgelinta `Copy` waa qayb ka mid ah API dadweynaha ee nooca.
/// Haddii nooca noqdaan non-`Copy` in future ah, waxa laga yaabaa in ay miyir ka tegid fulinta `Copy` hadda, si looga fogaado in isbedel API jabiyay.
///
/// ## Fuliyeyaal dheeri ah
///
/// Waxa intaa dheer in [implementors listed below][impls] ah, noocyada soo socda sidoo kale la hirgeliyo `Copy`:
///
/// * noocyada item Function (ie, noocyada kala duwan lagu qeexay shaqo kasta)
/// * Noocyada tilmaamaha shaqada (tusaale, `fn() -> i32`)
/// * Noocyada kala duwan, ee dhammaan cabbirka, haddii nooca walxaha sidoo kale fuliyo `Copy` (tusaale, `[i32; 123456]`)
/// * noocyada Tuple, haddii qayb kasta oo sidoo kale fulisaa `Copy` (tusaale ahaan, `()`, `(i32, bool)`)
/// * Noocyada xiritaanka, haddii aysan wax qiimo ah ka qaadan deegaanka ama haddii dhammaan qiyamka la qabtay ay hirgeliyaan `Copy` naftooda.
///   Ogow in doorsoomayaasha qabtay tixraaca la wadaago mar walba fuliyo `Copy` (xitaa haddii tixraaca ee ma aha), halka doorsoomayaasha qabtay tixraaca mutable marnaba fuliyo `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Tani waxay u ogolaaneysaa dayanayaan nooc ka mid ah in aanay fulin `Copy` sababtoo ah soohdin noolaa qanacsanayn (dayanayaan `A<'_>` markii `A<'static>: Copy` oo kaliya `A<'_>: Clone`).
// Waxaan leenahay halkan sifo this waayo, hadda oo kaliya sababtoo ah waxaa jira garoomo dhowr ah takhasuso jira on `Copy` in hore u jirin maktabadda caadiga ah, oo ma jirto si ay si ammaan ah ay leeyihiin dhaqanka this hadda.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Dhaqale dheegato guud impl ah `Copy` trait ah.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Noocyada kaas oo nabdoon tahay in la tixraacyada share dhexeeya threads.
///
/// trait-kan ayaa si otomaatig ah loo hirgeliyaa marka isku-duwaha uu go'aamiyo inuu habboon yahay.
///
/// Qeexidda saxda ah waa: nooc `T` waa [`Sync`] haddii oo kaliya haddii `&T` waa [`Send`].
/// In si kale loo dhigo, haddii ay jiraan waa wax macquul ma [undefined behavior][ub] (oo ay ku jiraan jinsiyadaha data) marka la kaadinayo tixraacyada `&T` dhexeeya threads.
///
/// Sida qofku filan karo, noocyada asaasiga ah sida [`u8`] iyo [`f64`] dhammaantood waa [`Sync`], sidaas oo kalena waa noocyada wadarta fudud ee ka kooban iyaga, sida tuples, structs iyo enum.
/// tusaalooyin More noocyada aasaasiga ah [`Sync`] ka mid ah noocyada "immutable" sida `&T`, iyo kuwa fudud dhaxlay mutability, sida [`Box<T>`][box], [`Vec<T>`][vec] iyo inta badan noocyada kale ururinta.
///
/// (Xuduudaheedu jeneerigga ah u baahan tahay inaad [`Sync`] ay weel u noqon [`Sync`].)
///
/// A natiijo xoogaa la yaab leh ee qeexidda waa in `&mut T` waa `Sync` (haddii `T` waa `Sync`) inkastoo ay u muuqato sida in laga yaabo in ay bixiyaan waxaa isbeddel unsynchronized.
/// trick waa in tixraac mutable dambeeya tixraaca la wadaago (waa, `& &mut T`) noqdo ka akhrisan-kaliya, sida haddii ay ahaayeen `& &T` ah.
/// Sidaa darteed ma jiraan wax khatar ah oo ku saabsan tartan xog ah.
///
/// Noocyada aan ahayn `Sync` waa kuwa leh "interior mutability" qaab aan badbaado lahayn, sida [`Cell`][cell] iyo [`RefCell`][refcell].
/// Noocyadaas ogolaan waayo isbedel ayaa ku jira ay xitaa iyada oo aan beddelmi karin, tixraac ah la wadaago.
/// Tusaale ahaan habka `set` ku [`Cell<T>`][cell] qaadataa `&self`, sidaas darteed waxay u baahan tahay oo kaliya tixraaca la wadaago [`&Cell<T>`][cell].
/// Qaabku ma qabanayo is waafajin, sidaas awgeed [`Cell`][cell] ma noqon karo `Sync`.
///
/// Tusaale kale oo ah nooca ``Sync` '' waa tilmaamaha tirinta tixraaca [`Rc`][rc].
/// Marka la eego wixii tixraac [`&Rc<T>`][rc], aad Gadzhiyev kartaa [`Rc<T>`][rc] cusub, bedelayaan ee dacwadood tixraaca hab non-qaaradda.
///
/// Xaaladaha marka qofku ubaahan yahay isbeddel gudaha ah oo ammaan ah, Rust wuxuu bixiyaa [atomic data types], iyo sidoo kale xiritaan cad oo loo maro [`sync::Mutex`][mutex] iyo [`sync::RwLock`][rwlock].
/// Noocyadaas hubiyo in isbedel kasta oo aan sabab xogta jinsiyadaha, halkan noocyada ay yihiin kartaa `Sync`.
/// Sidoo kale, [`sync::Arc`][arc] bixisaa analoogga thread-ammaan ah [`Rc`][rc] ah.
///
/// nooc kasta oo la mutability gudaha waa in sidoo kale isticmaali duuban [`cell::UnsafeCell`][unsafecell] ku wareegsan value(s) oo lagu qaadheen karaa iyada oo la tixraacayo la wadaago.
/// Guuldareysteen inay tan sameeyaan waa [undefined behavior][ub].
/// Tusaale ahaan, [`transmute`][transmute]-ing ka `&T` in `&mut T` waa baadil Eebe.
///
/// Ka eeg [the Nomicon][nomicon-send-and-sync] wixii faahfaahin dheeraad ah ee ku saabsan `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): mar taageero ku darto qoraalada in `rustc_on_unimplemented` matalo in beta, oo waxaa la kordhiyay si loo hubiyo in la xiro waa meel kasta oo silsilad looga baahan yahay, waxa la kordhiyo sida (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero yimaa-nooca loo isticmaalo si ay u xusaan waxyaalo "act like" ay leedahay `T` ah.
///
/// Ku darista beerta `PhantomData<T>` ah in aad nooca sheegayaa compiler ah in aad nooca u dhaqmo sidii isagoo qabaneysa qiimaha nooca `T`, inkastoo uusan dhab ahaantii.
/// Macluumaadkan waxaa loo isticmaalaa marka la xisaabinayo guryaha badbaadada qaarkood.
///
/// Wixii sharaxaad ka mid ah sida loo isticmaalo `PhantomData<T>` more qoto-dheer, fadlan eeg [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Xusuusin xasaasi ah 👻👻👻
///
/// In kastoo labada ay leeyihiin magacyo cabsi, `PhantomData` iyo noocyada phantom 'la xiriira, laakiin ma aha isku mid.Halbeegga nooc ka mid ah jaantuska ayaa ah nooca halbeegga oo aan waligiis la isticmaalin.
/// Rust, tani waxay badanaa keentaa isku-duwaha inuu ka cawdo, xalkuna waa in lagu daro isticmaalka "dummy" iyadoo loo marayo `PhantomData`.
///
/// # Examples
///
/// ## Xuduudaha nolosha aan la isticmaalin
///
/// Waxaa laga yaabaa in kiiska ugu isticmaalka caadi ah `PhantomData` waa struct a in uu leeyahay ah dhimaya ee Meyeydaan wax aan la isticmaalin, caadi ahaan qayb ka mid ah qaar ka mid ah code ammaan ahayn.
/// Tusaale ahaan, waa kan qaabdhismeedka `Slice` oo leh laba tilmaamood oo ah nooca `*const T`, oo loo maleynayo inuu tilmaamayo meel:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ujeedadu waa in xogta dahsoon waa ansax ah oo keliya ee Meyeydaan ee `'a`, sidaas `Slice` ayan nolo `'a`.
/// Si kastaba ha ahaatee, sidaas ugula aan la qeexay xeerka, tan iyo ma jiraan isticmaalka noolyihiin `'a` iyo halkan aan la cadeeyo waxa xogta u khusaysaa.
/// Waxaan ku sixi karnaa tan u sheegta isku-duwaha inuu u dhaqmo *sida haddii* qaabka `Slice` uu ku jiro tixraac `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// sidoo kale waxa ay noqonaysaa Tani waxay u baahan annotation `T: 'a` ah, oo tilmaamaysa in tixraacyada kasta oo `T` waa ansax badan noolyihiin `'a`.
///
/// Markaad bilaabeysid `Slice` waxaad si fudud u bixinaysaa qiimaha `PhantomData` ee goobta `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Noocyada aan la adeegsan
///
/// Waxaa mararka qaar ay dhacdo in aad leedahay oo xuduudaheedu nooca aan la isticmaalin taas oo muujinaysa nooca xogta struct waa "tied" in, inkastoo xogta in si dhab ah inaan laga helin struct laftiisa.
/// Halkan waxaa ku qoran tusaale ah halka ay tani soo baxdo la [FFI].
/// The isticmaalka interface shisheeye gacanta nooca `*mut ()` in ay tixraac qiimaha Rust ee noocyada kala duwan.
/// Waxaan ula socdaan nooca Rust isticmaalaya dhimaya nooca phantom a on struct `ExternalResource` taasoo wuxuuuna inaanu a.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Lahaanshaha iyo jeegga dhibcaha
///
/// Isagoo intaa ku daray beer nooca `PhantomData<T>` muujinaysaa in nooca leh xogta nooca `T`.Tani markeeda waxay tusineysaa in markii noocaaga la tuuro, ay dhici karto hal ama in ka badan oo ah nooca `T`.
/// Tani waxay saameyn ku yeelaneysaa falanqaynta 'Rust' ee falanqaynta [drop check].
///
/// Haddii struct uusan dhab ahaantii *gaar ah* xogta nooca `T`, waxaa wanaagsan in la isticmaalo nooca tixraac, sida `PhantomData<&'a T>` (ideally) ama `PhantomData<*const T>` (haddii uu nool yahay ma khusaysaa), si aanay u tilmaamaya lahaanshaha.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-gudaha trait loo isticmaalo si ay u muujiyaan nooca discriminants enum.
///
/// trait Tani waxaa si toos ah fulin nooc kasta oo aanu ku dar wax kasta oo ballan qaado in [`mem::Discriminant`].
/// Waa dabeecad undefined ** ** si transmute dhexeeya `DiscriminantKind::Discriminant` iyo `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Nooca discriminant ah, waa taas oo ka dhergin bounds trait ah by `mem::Discriminant` loo baahan yahay.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-Gudaha trait ayaa loo isticmaalay in lagu go'aamiyo in nooc uu ku jiro wax `UnsafeCell` ah oo gudaha ah, laakiin aan loo soo marin.
///
/// Tani waxay saamayn ku, tusaale ahaan, haddii `static` ka mid ah nooca in lagu meeleeyo akhri kaliya xasuusta ma guurto ah ama ma guurto ah xasuusta writable.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Noocyada si aamin ah loo dhaqaajin karo ka dib marka la xidho.
///
/// Rust laftiisa ayaa fikradda ma noocyada aan dhaqaaqayn, oo tixgelinaysaa guuro (tusaale ahaan, iyada oo loo marayo shaqo ama [`mem::replace`]) in had iyo jeer nabad.
///
/// nooca [`Pin`][Pin] waxaa loo isticmaalaa halkii si looga hortago guuro iyadoo la marayo nidaamka nooca.Tilmaamayaasha `P<T>` ee ku duuban duubka [`Pin<P<T>>`][Pin] lama dhaqaajin karo.
/// Fiiri warqadaha [`pin` module] u hesho macluumaad dheeraad ah oo ku saabsan salka.
///
/// Fulinta trait `Unpin` ee `T` qaadda xayiraad ee salka off nooca, taas oo ka dibna waxay u ogolaaneysaa `T` baxay [`Pin<P<T>>`][Pin] dhaqaaqin hawlo sida [`mem::replace`].
///
///
/// `Unpin` ma laha natiijo ah oo dhan, waayo, xogta aan iskula.
/// Gaar ahaan, [`mem::replace`] farxad guuro xogta `!Unpin` (u shaqeeya `&mut T` kasta, ma marka kaliya `T: Unpin`).
/// Si kastaba ha ahaatee, aad uma isticmaali karo [`mem::replace`] xogta ku duudduubtay gudaha [`Pin<P<T>>`][Pin] ah sababtoo ah ma waxaad ka heli kartaa `&mut T` ee aad u baahan tahay in, iyo * * in uu yahay waxa ay ka dhigeysaa shaqada nidaamka this.
///
/// Sidaas this, tusaale ahaan, keliya waxaa la samayn karaa on nooc fulinta `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Waxaan ubaahanahay tixraac isbedel ah si aan u wacno `mem::replace`.
/// // Waxaan ka heli karnaa tixraac noocan oo kale ah (implicitly) oo u yeeraya `Pin::deref_mut`, laakiin taasi waa suuragal oo keliya maxaa yeelay `String` wuxuu fuliyaa `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait Tani waxaa si toos ah fulin muddo ku dhow kasta oo nooc.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Nooca sumadeeyayaasha oo aan hirgelinaynin `Unpin`.
///
/// Haddii nooc ka mid yahay `PhantomPinned`, ma fulin doono `Unpin` asal ahaan.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Fulintii of `Copy` noocyada heer hoose ah.
///
/// Hirgelinta aan lagu sifeyn karin Rust waxaa laga fuliyaa `traits::SelectionContext::copy_clone_conditions()` gudaha `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Tixraacyo wadaag ah waa la koobiyeyn karaa, laakiin tixraacyo la beddeli karo *ma* noqon karaan *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}