#![stable(feature = "core_hint", since = "1.27.0")]

//! Tilmaamo isku dubaridaha oo saameeya sida koodhka loo siidayn karo ama loo hagaajin karo.
//! Tilmaamuhu waxay noqon karaan wakhti ama wakhti go'an.

use crate::intrinsics;

/// Wuxuu ogeysiinayaa isku-duwaha in qodobkan koodhku aanu ahayn mid la gaari karo, taasoo awood u siineysa in la sii hagaajiyo.
///
/// # Safety
///
/// Gaaritaanka shaqo this oo gebi ahaanba waa *dhaqanka undefined*(UB).Gaar ahaan, compiler qabanayaa in UB oo dhan waa in aan marnaba dhici, oo sidaas daraaddeed baabi'iyo doonaa laamood oo dhan in gaari karin si call a in `unreachable_unchecked()`.
///
/// Sida dhammaan dhacdooyin UB, haddii malo this soo baxday in ay qalad ah, ie, call `unreachable_unchecked()` waa run ahaantii ka mid ah socodka gacanta suurto gal ah oo dhan Ieexdo, compiler codsan doonaa istiraatiijiyad ah ayna qalad ah, waxaana laga yaabaa in mararka qaar xitaa musuqmaasuq code darradaas la xidhiidhin, ee keenaya adag to-Debug dhibaatooyinka.
///
///
/// Adeegso shaqadan kaliya markaad cadeyn karto in koodhku waligiis wici doonin.
/// Haddii kale, waxaad fiirisaa adeegsiga Dhaqale [`unreachable!`] ah, taas oo aan u oggolayn optimizations laakiin panic markii dili doonaa.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` had iyo jeer waa wax fiican (ma eber), markaa `checked_div` waligiis ma soo laaban doono `None`.
/////
///     // Sidaa darteed, tan kale branch lama gaari karo.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // BADBAADADA: qandaraaska amniga ee `intrinsics::unreachable` waa inuu
    // uu u hiilinayo qofka soo wacaya.
    unsafe { intrinsics::unreachable() }
}

/// Waxay soo saartaa tilmaamaha mashiinka si ay ugu muujiso processor-ka inuu ku socdo mashquul-sugid wareejin (loox wareega)
///
/// Marka la helo signal wareejin-loop ku processor ay tayadoodii karaa ay dabeecad, tusaale ahaan, awood badbaadiyo ama baddalidda hyper-threads.
///
/// Shaqadani way ka duwan tahay [`thread::yield_now`] oo si toos ah ugu soo saareysa jadwalka nidaamka, halka `spin_loop` uusan la macaamilin nidaamka qalliinka.
///
/// A kiiska isticmaalka caadi ah `spin_loop` waxaa fulinaya kumyadu fur rajo in loop CAS in primitives .Wadashaqayntaas ah.
/// Si aad u dhibaato ka dheeraw sida inversion mudnaanta, waxaa aad loogu talinayaa in loop Lataliyihii waa la joojiyay ka dib markii qadar uguna of iterations iyo syscall ku furid ku haboon la sameeyo.
///
///
/// **Xusuusin**: Meelaha aan taageerin helitaanka tilmaamaha wareegga shaqadani waxba kama qabanayso.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Qiimaha A wadaago qaaradda in threads isticmaali doonaa si la isugu duwo
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Mawduuc dambe waxaan aakhirka dejin doonnaa qiimaha
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Shaqada qaar samee, ka dibna qiimaha noolee
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Ku noqoshada xariiqeenna hadda, waxaan sugeynaa qiimaha la dejinayo
/// while !live.load(Ordering::Acquire) {
///     // loop Lataliyihii waa oggayn in processor in aan la sugayo, laakiin malaha ma for aad u dheer
/////
///     hint::spin_loop();
/// }
///
/// // Qiimaha ayaa haatan qarka u saaran
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // AMMAAN: `cfg` attr wuxuu hubiyaa inaan kaliya ku fulino tan bartilmaameedyada x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // AMMAANKA: `cfg` wuxuu hubinayaa attr in aan kaliya u fuliyaan this on bartilmaameed x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // AMMAAN: `cfg` attr wuxuu hubiyaa inaan kaliya ku fulino tan bartilmaameedyada aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // AMMAANKA: `cfg` wuxuu hubinayaa attr in aan kaliya u fuliyaan this on bartilmaameed gacanta
            // iyada oo la taageerayo muuqaalka v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Shaqada aqoonsiga ee *__ tilmaamaysa __* isku-duwaha inuu ugu badnaan rajo ka muujiyo waxa `black_box` sameyn lahaa.
///
/// Si ka duwan [`std::convert::identity`], isku xiraha 'Rust' waxaa lagu dhiirigelinayaa inuu u maleeyo in `black_box` u adeegsan karo `dummy` si kasta oo macquul ah oo macquul ah oo lambar Rust loo oggol yahay iyada oo aan la soo bandhigin habdhaqan aan qeexnayn koodhka wicitaanka.
///
/// hantida Taas ayaa ka dhigaysa `black_box` faa'iido badan ee qoraal code taas oo optimizations qaarkood aan doonayo, sida bartilmaameedyo.
///
/// Si kastaba ha noqotee, xusuusnow, in `black_box` kaliya yahay (oo kaliya la bixin karo) oo lagu bixiyay qaab "best-effort" ah.Baaxadda ay u xanibi karto yididiilada ayaa laga yaabaa inay ku kala duwanaanto hadba meertada iyo koodh genend loo isticmaalo.
/// Barnaamijyadu kuma tiirsanaan karaan `black_box`*saxsanaanta* sinnaba.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Waxaan ubaahanahay inaan "use" doodda si uun LLVM u horjoogsan karin, bartilmaameedyada taageerana waxaan caadi ahaan ka faa'iideysan karnaa iskuxirka qadka si tan loo sameeyo.
    // Fasiraadda LLVM ee iskuxirka qadka ayaa ah, waa hagaag, sanduuq madow.
    // Tani ma aha hirgelinta weyn tan iyo markii ay u badan tahay deoptimizes badan waxaan rabnaa, laakiin waxa ilaa hadda ku filan wanaagsan.
    //
    //

    #[cfg(not(miri))] // Tani waa kaliya dareen, sidaas darteed waxaa wanaagsan inay u boodboodaan in Tintin.
    // AMMAANKA: Wabka shirka waa no-op.
    unsafe {
        // FIXME: Ma isticmaali karo `asm!` maxaa yeelay ma taageerto MIPS iyo naqshadaha kale.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}