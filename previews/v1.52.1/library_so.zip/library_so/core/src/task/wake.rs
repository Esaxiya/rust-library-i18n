#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` ogolaanaya implementor ee fuliyaha hawl si ay u abuuraan [`Waker`] a kaas oo bixiya dhaqanka khuseeysa kartoo.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Waxay ka kooban tahay tilmaamaha xogta iyo [virtual function pointer table (vtable)][vtable] in customizes dhaqanka `RawWaker` ah.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Tilmaamaha xogta, kaas oo loo isticmaali karo in lagu kaydiyo xogta aan macquul ahayn sida uu u baahan yahay fuliyaha.
    /// Tani waxay noqon kartaa tusaale ahaan
    /// tilmaan-bixiye nooca-tirtiray oo loo yaqaan `Arc` oo la xidhiidha hawsha.
    /// Qiimaha arimahan uu maray in dhammaan hawlaha in ay yihiin qayb ka mid ah vtable sida dhimaya ugu horeysay.
    ///
    data: *const (),
    /// Shaxda tilmaamaha ficil ahaaneed ee habeeya habdhaqanka toosan.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Waxay ka abuurtaa `RawWaker` cusub tilmaamaha la siiyay ee `data` iyo `vtable`.
    ///
    /// pointer `data` waxaa loo isticmaali karaa in ay ku kaydiso xogta loo aabo yeelin sida uu fuliyaha loo baahan yahay.Tani waxay noqon kartaa tusaale ahaan
    /// tilmaan-bixiye nooca-tirtiray oo loo yaqaan `Arc` oo la xidhiidha hawsha.
    /// Qiimaha tilmaamahan ayaa loo gudbin doonaa dhammaan shaqooyinka ka tirsan `vtable` oo ah halbeegga koowaad.
    ///
    /// `vtable` wuxuu habeeyaa dabeecada `Waker` kaas oo laga abuuray `RawWaker`.
    /// Wixii hawlgal kasta on `Waker` ah, shaqo la xiriira ee `vtable` of `RawWaker` salka loogu yeedhi doonaa.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Shaxda tilmaanta ficil-celinta ah ee muuqaalka (vtable) oo tilmaamaysa hab-dhaqanka [`RawWaker`].
///
/// Tilmaamuhu wuxuu u gudbiyay dhamaan shaqooyinka gudaha vtable-ka waa tilmaamaha `data` ee ka imanaya sheyga xiranaya [`RawWaker`].
///
/// Hawlaha ku jira qaab-dhismeedkan waxaa loogu talagalay oo keliya in loogu yeero tilmaamaha `data` ee shayga si wanaagsan loo dhisay ee loo yaqaan [`RawWaker`] shay' oo ka socda gudaha hirgelinta [`RawWaker`].
/// Wicitaanka mid ka mid ah hawlaha ku jira oo isticmaalaya wax pointer kale `data` dhigi doonaa habdhaqanka undefined.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// function Tani waxaa loogu yeedhi doonaa marka [`RawWaker`] ee uu gjærceler, tusaale ahaan marka [`Waker`] taas oo [`RawWaker`] waxaa loo kaydiyaa uu gjærceler.
    ///
    /// fulinta shaqada this waa in xajisto oo dhan khayraadka loo baahan yahay, waayo, taasu tusaale dheeraad ah [`RawWaker`] ah iyo hawsha la xiriira.
    /// Wicitaanka `wake` ee natiijada [`RawWaker`] waa inay keentaa baraarug isla hawshaas oo lagu toosin lahaa [`RawWaker`] asalka ah.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Shaqadan waxaa loogu yeedhi doonaa marka `wake` looga yeedho [`Waker`].
    /// Waa inay toosisaa hawsha la xiriirta [`RawWaker`]-kan.
    ///
    /// fulinta shaqada this waa in uu hubiyaa in ay sii daayaan khayraadka kasta oo la xidhiidha tusaale ahaan this of [`RawWaker`] ah iyo hawsha la xiriira ka dhigi.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// function Tani waxaa loogu yeedhi doonaa marka `wake_by_ref` waxa loo yaqaan on [`Waker`] ah.
    /// Waa inay toosisaa hawsha la xiriirta [`RawWaker`]-kan.
    ///
    /// function Tani waxay la mid tahay `wake`, laakiin waa in aan baabbi'iyee pointer xogta ay bixiyaan.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Hawshan ayaa loo yaqaan [`RawWaker`] marka la tuuro.
    ///
    /// fulinta shaqada this waa in uu hubiyaa in ay sii daayaan khayraadka kasta oo la xidhiidha tusaale ahaan this of [`RawWaker`] ah iyo hawsha la xiriira ka dhigi.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Waxay ka abuurtaa `RawWakerVTable` cusub shaqooyinka `clone`, `wake`, `wake_by_ref`, iyo `drop`.
    ///
    /// # `clone`
    ///
    /// function Tani waxaa loogu yeedhi doonaa marka [`RawWaker`] ee uu gjærceler, tusaale ahaan marka [`Waker`] taas oo [`RawWaker`] waxaa loo kaydiyaa uu gjærceler.
    ///
    /// fulinta shaqada this waa in xajisto oo dhan khayraadka loo baahan yahay, waayo, taasu tusaale dheeraad ah [`RawWaker`] ah iyo hawsha la xiriira.
    /// Wicitaanka `wake` ee natiijada [`RawWaker`] waa inay keentaa baraarug isla hawshaas oo lagu toosin lahaa [`RawWaker`] asalka ah.
    ///
    /// # `wake`
    ///
    /// Shaqadan waxaa loogu yeedhi doonaa marka `wake` looga yeedho [`Waker`].
    /// Waa inay toosisaa hawsha la xiriirta [`RawWaker`]-kan.
    ///
    /// fulinta shaqada this waa in uu hubiyaa in ay sii daayaan khayraadka kasta oo la xidhiidha tusaale ahaan this of [`RawWaker`] ah iyo hawsha la xiriira ka dhigi.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// function Tani waxaa loogu yeedhi doonaa marka `wake_by_ref` waxa loo yaqaan on [`Waker`] ah.
    /// Waa inay toosisaa hawsha la xiriirta [`RawWaker`]-kan.
    ///
    /// function Tani waxay la mid tahay `wake`, laakiin waa in aan baabbi'iyee pointer xogta ay bixiyaan.
    ///
    /// # `drop`
    ///
    /// Hawshan ayaa loo yaqaan [`RawWaker`] marka la tuuro.
    ///
    /// fulinta shaqada this waa in uu hubiyaa in ay sii daayaan khayraadka kasta oo la xidhiidha tusaale ahaan this of [`RawWaker`] ah iyo hawsha la xiriira ka dhigi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` ee hawl asynchronous ah.
///
/// Currently, `Context` keliya u adeegta si ay u bixiyaan helitaanka `&Waker` ah oo loo isticmaali karaa in uu toosaa hawsha hadda.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Hubi inaanu future-caddeyn u leenahay isbeddelada isbeddelka adoo ku qasbaya nolosha oo dhan inay noqdaan kuwo aan isbeddel lahayn (cimriga doodaha mowqifku waa mid is khilaafsan halka noloshu ku soo noqoshada tahay mid isweydaarsi leh).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Ka abuur `Context` cusub `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Sooceliyaa inay marjic u `Waker` ee hawsha hadda.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` waa gacan qabasho toosinta hawl iyadoo la ogeysiinayo fuliyaha inay diyaar u tahay in la maamulo.
///
/// Wax ka qabashadani waxay soo koobeysaa tusaale [`RawWaker`], oo qeexaya dhaqanka tooska ah ee tooska fulinta.
///
///
/// Waxay fulisaa [`Clone`], [`Send`], iyo [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Ka kac shaqada la xiriirta `Waker`-kan.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Wicitaanka tooska ah ee tooska ah ayaa loo wakiishay iyada oo loo marayo wicitaan ficil-celin ah oo loogu talagalay hirgelinta kaas oo lagu qeexay fuliyaha.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ha u wicin `drop`-toosaha waxaa baabi'in doona `wake`.
        crate::mem::forget(self);

        // BADBAADADA: Tani waa ammaan maxaa yeelay `Waker::from_raw` waa habka keliya
        // si loo bilaabo `wake` iyo `data` oo looga baahan yahay isticmaalaha inuu qirto in heshiiska `RawWaker` la ilaaliyo.
        //
        unsafe { (wake)(data) };
    }

    /// Ka kac shaqada la xiriirta tan `Waker` adiga oo aan cunin `Waker`.
    ///
    /// Tani waxay la mid tahay `wake`, laakiin waxaa laga yaabaa inay wax yar ka waxtar yar tahay kiiska meesha laga heli karo `Waker`.
    /// Habkani waa in laga door bidaa in la waco `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Wicitaanka tooska ah ee tooska ah ayaa loo wakiishay iyada oo loo marayo wicitaan ficil-celin ah oo loogu talagalay hirgelinta kaas oo lagu qeexay fuliyaha.
        //

        // BADBAADADA: eeg `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Dib `true` haddii this `Waker` iyo `Waker` kale ayaa dawakhsan hawl isku mid ah.
    ///
    /// function Tani waxay ka shaqeeya on sal-fiican dadaal, iyo noqon karaa been ah xitaa marka ku yidhi Waker`s toosi lahaa hawl isku mid ah.
    /// Si kastaba ha noqotee, haddii shaqadani soo noqoto `true`, waxaa la damaanad qaadayaa in ``Waker`s uu kicin doono isla hawshaas.
    ///
    /// function Arrintan ayaa aasaasi ahaan loo isticmaalo ujeeddooyin ayna.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Abuuraa `Waker` cusub ka [`RawWaker`].
    ///
    /// dhaqanka ee `Waker` ku soo laabtay waxaa undefined haddii heshiiska lagu qeexay [`RawWaker`] 's iyo [`RawWakerVTable`]' s waraaqo aan la fuliyo.
    ///
    /// Sidaa darteed qaabkani waa mid aan amaan ahayn.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // BADBAADADA: Tani waa ammaan maxaa yeelay `Waker::from_raw` waa habka keliya
            // in initialize `clone` iyo `data` baahan user u caddayso in heshiiska of [`RawWaker`] waa la taageerayaa.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // BADBAADADA: Tani waa ammaan maxaa yeelay `Waker::from_raw` waa habka keliya
        // in initialize `drop` iyo `data` baahan user u caddayso in heshiiska of `RawWaker` waa la taageerayaa.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}