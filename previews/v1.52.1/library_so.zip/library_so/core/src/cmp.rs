//! Shaqaynta amar bixinta iyo isbarbar dhigga.
//!
//! Sawirkan waxa uu ka kooban yahay qalab kala duwan oo ku amro oo barbar qiyamka.Marka la soo koobo:
//!
//! * [`Eq`] iyo [`PartialEq`] waa traits oo kuu oggolaanaya inaad qeexdo wadarta iyo sinnaanta udhaxeysa qiyamka, siday u kala horreeyaan.
//! Iyagoo fulinaya iyaga culeysyo xad dhaaf ah wadayaasha `==` iyo `!=`.
//! * [`Ord`] iyo [`PartialOrd`] waa traits in laguu ogolaado in aad si ay u qeexaan awowgood guud ahaan iyo qayb ahaan u dhaxeeya qiyamka, siday u kala horreeyaan.
//!
//! Iyagoo fulinaya iyaga culeysyo xad dhaaf ah hawl wadeennada `<`, `<=`, `>`, iyo `>=`.
//! * [`Ordering`] waa enum ay soo celiyeen shaqooyinka ugu waaweyn ee [`Ord`] iyo [`PartialOrd`], waxayna qeexaysaa amar bixinta.
//! * [`Reverse`] waa struct u ogolaanaya in aad si fudud u beddeli xigsiin ah.
//! * [`max`] iyo [`min`] waa shaqooyin ka dhisma [`Ord`] oo kuu oggolaanaya inaad hesho ugu badnaan ama ugu yar ee laba qiime.
//!
//! Wixii faahfaahin dheeraad ah, ka eeg warqadaha la kala of item kasta oo ku jira liiska.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait for barbardhigo sinnaanta kuwaas oo [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// trait Tani waxay u ogolaaneysaa for sinnaanta qayb ahaan, noocyada aan lahayn xiriir isu-buuxa.
/// Tusaale ahaan, in tiro dhibic sabayn `NaN != NaN`, sidaas noocyada sabayn dhibic fuliyo `PartialEq` laakiin ma [`trait@Eq`].
///
/// Si rasmi ah, sinnaanta waa inay ahaataa (dhammaan `a`, `b`, `c` nooca `A`, `B`, `C`):
///
/// - ** ** Symmetric: haddii `A: PartialEq<B>` iyo `B: PartialEq<A>`, ka dibna **`a==b` tilmaamaysaa`b==a`**;iyo
///
/// - **Transitive**: haddii `A: PartialEq<B>` iyo `B: PartialEq<C>` iyo `` A:
///   Qayb ahaanEq<C>`, Ka dibna **` b`==iyo `b == c` tilmaamaysaa`a==c`**.
///
/// Ogow in impls `B: PartialEq<A>` (symmetric) iyo `A: PartialEq<C>` (transitive) aan lagu qasbay in ay ka jiraan, laakiin shuruudahan codsan mar kasta oo ay jiraan.
///
/// ## Derivable
///
/// trait waxaa loo isticmaali karaa `#[derive]`.Marka `derive`d on structs, laba dhacdooyin siman yihiin haddii beeraha oo dhan waa u siman yihiin, iyo ma simanyihiin haddii beeraha kasta oo aan waa u siman yihiin.Marka `derive`d on enums, kala duwanaansho walba waa loo siman yahay laftiisa iyo ma simanyihiin in Lahjadaha kale.
///
/// ## Sideen ku hirgelin karaa `PartialEq`?
///
/// `PartialEq` kaliya waxay u baahan tahay habka [`eq`] in la hirgaliyo;[`ne`] waxaa lagu qeexaa marka la eego iyada oo ah mid iska caadi ah.Fulin kasta oo gacanta ah oo ah [`ne`]*waa inay* ixtiraamtaa qaanuunka in [`eq`] uu yahay mid si adag uga soo horjeedda [`ne`];in uu yahay, `!(a == b)` haddii oo kaliya haddii `a != b`.
///
/// Fulintii of `PartialEq`, [`PartialOrd`], iyo [`Ord`]*waa* heshiin kasta oo kale.Way fududahay in si qalad ah looga dhigo iyaga oo diida iyadoo la helayo qaar ka mid ah traits iyo in gacanta lagu fuliyo kuwa kale.
///
/// Tusaale fulin ah oo ah labo buug oo loo tixgelinayo isku buug haddii isbntoodu iswaafajiyaan, xitaa haddii qaababku kala duwan yihiin:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Sideen isu barbar dhigi karaa laba nooc oo kala duwan?
///
/// Nooca aad isbarbar dhigi karto waxaa xukuma cabirka nooca 'PartialEq'.
/// Tusaale ahaan, aan yara yaraynno koodhkeennii hore:
///
/// ```
/// // Qalabka laga helo<BookFormat>==<BookFormat>isbarbardhiga
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Hirgalinta<Book>==<BookFormat>isbarbardhiga
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Hirgalinta<BookFormat>==<Book>isbarbardhiga
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Adoo badalaya `impl PartialEq for Book` ilaa `impl PartialEq<BookFormat> for Book`, waxaan u ogolaaneynaa ``BookFormat`s in lala barbardhigo '' Book`s.
///
/// Isbarbardhig sida kan kor ku xusan, oo iska indhatiraya qaybaha qaarkood ee qaabdhismeedka, wuxuu noqon karaa mid khatar ah.Waxay si fudud ugu horseedi kartaa xadgudub lama filaan ah oo ku saabsan shuruudaha xiriir isku mid ah oo u dhigma.
/// Tusaale ahaan, haddii aan lagu hayaa fulinta ee kor ku xusan ee `PartialEq<Book>` for `BookFormat` iyo ku daray hirgelinta ah `PartialEq<Book>` for `Book` (labada via `#[derive]` ama via hirgelinta buuga ka tusaale ugu horeysay) ka dibna natiijada xadgudub ku noqon doono transitivity:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// imtixaanada habka for `self` iyo `other` Tani qiimeeyo in loo siman yahay, iyo waxaa loo isticmaalaa by `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Habkani wuxuu tijaabiyaa `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Dhaqale dheegato guud impl ah `PartialEq` trait ah.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait isbarbardhigga sinnaanta kuwaas oo ah [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Tani waxay ka dhigan tahay, in lagu daro `a == b` iyo `a != b` isagoo inverses adag, sinnaanta waa in ay ahaadaan (waayo, kulli `a`, `b` iyo `c`):
///
/// - reflexive: `a == a`;
/// - isku dheelitiran: `a == b` wuxuu tilmaamayaa `b == a`;iyo
/// - Transitive: `a == b` iyo `b == c` tilmaamaysaa `a == c`.
///
/// hantida lama eegi karo by compiler ah, oo sidaas daraaddeed `Eq` tilmaamaysaa [`PartialEq`], oo ma laha habab dheeraad ah.
///
/// ## Derivable
///
/// trait-kan waxaa loo isticmaali karaa `#[derive]`.
/// Marka `derive`d, maxaa yeelay, `Eq` ma laha habab dheeraad ah, waxaa lagu war compiler keliya in tani ay tahay la xiriirta isu ah halkii ay xiriir isu-qayb.
///
/// Xusuusnow in istiraatiijiyadda `derive` ay u baahan tahay dhammaan qaybaha inay yihiin `Eq`, oo had iyo jeer aan la rabin.
///
/// ## Sidee baan u hirgelin karaan `Eq`?
///
/// Haddii aadan isticmaali karin istaraatijiyad `derive` ah, sheeg in aad qalab nooca `Eq`, taas oo uu leeyahay hababka no:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // habkan waxaa keliya loo isticmaalo by#[tobanaad] isaga oo sheegaya in qayb kasta oo ah qalab nooca#[tobanaad] laftiisa, habka kaabayaasha iyo tobanaad hadda samaynaya caddaynta this iyada oo aan la isticmaalayo habka a on trait tani waa ku dhawaad aan macquul aheyn.
    //
    //
    // Tani waa in aan marnaba la fulin by gacanta.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Dhaqale dheegato guud impl ah `Eq` trait ah.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: Qaab dhismeedkan waxaa kaliya loo isticmaalaa#[derive] in
// caddeeyaa in qayb kasta oo nooc ka mid ah ay fuliso Eq.
//
// Qaab dhismeedkani waa inuusan waligiis ka muuqan koodhka isticmaalaha.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// An `Ordering` waa natiijada la barbardhigo u dhexeeya laba qiimeeyo.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// xigsiin An halkaas oo qiimaha marka la barbar dhigo ka yar tahay oo kale.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Dalbasho halka qiimaha isbarbar dhiga uu la mid yahay mid kale.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Dalbasho halka qiimaha isbarbardhiga ahi ka weyn yahay midka kale.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Soocelinayaa `true` haddii amarku yahay nooca `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Sooceliyaa `true` haddii gagadoonka ma kala duwanaansho `Equal` ah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Sooceliyaa `true` haddii gagadoonka kala duwanaansho `Less` ah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Soocelinayaa `true` haddii amarku yahay nooca `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Soocelinayaa `true` haddii dalabku yahay mid `Less` ama `Equal` nooc ah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Soocelinayaa `true` haddii dalabku yahay mid `Greater` ama `Equal` nooc ah.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Dumiso `Ordering` ah.
    ///
    /// * `Less` noqda `Greater`.
    /// * `Greater` noqda `Less`.
    /// * `Equal` noqda `Equal`.
    ///
    /// # Examples
    ///
    /// Dabeecadda aasaasiga ah:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Habkan waxaa loo isticmaali karaa in lagu beddelo isbarbardhiga:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // kala sooc safka ugu weyn ilaa kan ugu yar.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Silsilado laba dalbo.
    ///
    /// Sooceliyaa `self` markay ahayn `Equal`.Haddii kale wuxuu soo celiyaa `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Waxay kuxirantahay amar bixinta hawsha la siiyay.
    ///
    /// Sooceliyaa `self` markay ahayn `Equal`.
    /// Haddii kale wuxuu wacaa `f` wuuna soo celiyaa natiijada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Qaabdhisme caawiye u ah dalbashada gadaal.
///
/// Qaab-dhismeedkani waa caawiye loo adeegsado shaqooyinka sida [`Vec::sort_by_key`] oo waxaa loo isticmaali karaa in lagu beddelo qayb ka mid ah furaha.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait noocyada sameeya [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Amarku waa amar guud haddii uu yahay (dhammaan `a`, `b` iyo `c`):
///
/// - wadarta iyo asymmetric: sida saxda ah mid ka mid ah `a < b`, `a == b` ama `a > b` waa run;iyo
/// - Transitive, `a < b` iyo `b < c` tilmaamaysaa `a < c`.Waa in ay qabataa isku mid ah labada `==` iyo `>`.
///
/// ## Derivable
///
/// trait-kan waxaa loo isticmaali karaa `#[derive]`.
/// Markii `` laga soo baxo qodobada '' structs, waxay soo saari doontaa amar [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ah oo ku saleysan amarka cadeynta ee kor ilaa-hoose ee xubnaha dhismaha.
///
/// Marka ``derive`d on enum '', noocyada kala duwan ayaa lagu amraa amarkooda midab kala sooca xagga sare ilaa hoose.
///
/// ## Isbarbardhiga lexicographical
///
/// Marka la barbardhigo Lexicographical waa qalliin la sifooyinka soo socda:
///  - Laba isku xigxiga ayaa isbarbar dhig ku ah cunsur.
///  - Qaybta ugu horreysa ee aan is khaldamin waxay qeexaysaa taxanaha lixicographically ahaan ka yar ama ka weyn kan kale.
///  - Haddii mid ka mid ah isku xigxiga waa horgale kale, taxanaha gaaban lexicographically ka yar oo kale oo ay tahay.
///  - Haddii laba isku xigxiga ay leeyihiin walxo u dhigma oo dhererkoodu isku mid yahay, markaa isku xigxigu qaab-dhismeedkoodu waa siman yahay.
///  - Tixraac madhan ayaa qaab-tilmaameed ahaan ka yar taxane kasta oo aan madhan ahayn.
///  - Laba isku xigxiga oo madhan ayaa eray bixin ahaan loo siman yahay.
///
/// ## Sidee baan u hirgelin karaan `Ord`?
///
/// `Ord` waxay u baahan tahay in nooca uu sidoo kale noqdo [`PartialOrd`] iyo [`Eq`] (oo u baahan [`PartialEq`]).
///
/// Markaa waa inaad qeexdaa hirgelinta [`cmp`].Waxaa laga yaabaa inaad waxtar u leedahay inaad u isticmaasho [`cmp`] meelaha noocaaga ah.
///
/// Hirgelinta [`PartialEq`], [`PartialOrd`], iyo `Ord`*waa inay* isla ogolaadaan midba midka kale.
/// Taasi waa, `a.cmp(b) == Ordering::Equal` haddii oo kaliya haddii `a == b` iyo `Some(a.cmp(b)) == a.partial_cmp(b)` for `a` oo dhan iyo `b`.
/// Way fududahay in si qalad ah looga dhigo iyaga oo diida iyadoo la helayo qaar ka mid ah traits iyo in gacanta lagu fuliyo kuwa kale.
///
/// Halkan tusaale halkaas oo aad rabto in aad xalliso dadka height kaliya, fulinayaan `id` iyo `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Habkani wuxuu soo celiyaa [`Ordering`] inta udhaxeysa `self` iyo `other`.
    ///
    /// Heshiis ahaan, `self.cmp(&other)` wuxuu soo celiyaa dalab u dhigma muujinta `self <operator> other` haddii ay run tahay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Isbarbardhiga oo soo celiya ugu badnaan laba qiime.
    ///
    /// Waxay soo celineysaa doodda labaad haddii isbarbardhiggu go'aamiyo inay siman yihiin.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Isbarbar dhiga oo soo celiya uguyaraan laba qiime.
    ///
    /// Waxay soo celineysaa doodda koowaad haddii isbarbardhiggu go'aamiyo inay siman yihiin.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Xaddid qiimaha a in bareeg gaar ah.
    ///
    /// Sooceliyaa `max` haddii `self` waa ka weyn yahay `max`, iyo `min` haddii `self` ka yar tahay `min`.
    /// Haddii kale tani waxay soo celinaysaa `self`.
    ///
    /// # Panics
    ///
    /// Panics haddii `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Dhalinta makro oo soosaara impl ah trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait qiimaha in la barbar dhigi karaa for a sort-si.
///
/// Isbarbardhiggu waa inuu qanciyaa, dhammaan `a`, `b` iyo `c`:
///
/// - kaqabto: haddii `a < b` markaas `!(a > b)`, iyo sidoo kale `a > b` micnahoodu `!(a < b)`;iyo
/// - transitivity: `a < b` iyo `b < c` tilmaamaysaa `a < c`.Waa in ay qabataa isku mid ah labada `==` iyo `>`.
///
/// Xusuusnow in shuruudahan macnahoodu yahay trait lafteeda waa in loo hirgaliyaa si iskumar ahaan iyo tartiib tartiib tartiib tartiib tartiib tartiib tartiib tartiib tartiib tartiib tartiib tartiib tartiib ah: haddii `T: PartialOrd<U>` iyo `U: PartialOrd<V>` ah kadib `U: PartialOrd<T>` iyo `` T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait waxaa loo isticmaali karaa `#[derive]`.Goortii `` laga soo baxo 'structs, waxay soo saari doontaa amar qoraal ah oo ku saleysan amarka ku dhawaaqida dusha-hoose ilaa-hoose ee xubnaha dhismaha.
/// Marka ``derive`d on enum '', noocyada kala duwan ayaa lagu amraa amarkooda midab kala sooca xagga sare ilaa hoose.
///
/// ## Sidee baan u hirgelin karaan `PartialOrd`?
///
/// `PartialOrd` kaliya waxay ubaahantahay hirgalinta habka [`partial_cmp`], kuwa kalena laga soosaaray dhaqan galkii ugu dambeeyay.
///
/// Si kastaba ha noqotee waxaa suurtagal ah in kuwa kale loo hirgeliyo si gooni gooni ah noocyada aan lahayn amar guud.
/// Tusaale ahaan, lambarada dhibcaha sabayn, `NaN < 0 == false` iyo `NaN >= 0 == false` (cf.
/// IEEE 754-2008 qaybta 5.11).
///
/// `PartialOrd` waxay u baahan tahay noocaagu inuu noqdo [`PartialEq`].
///
/// Fulintii of [`PartialEq`], `PartialOrd`, iyo [`Ord`]*waa* heshiin kasta oo kale.
/// Way fududahay in si qalad ah looga dhigo iyaga oo diida iyadoo la helayo qaar ka mid ah traits iyo in gacanta lagu fuliyo kuwa kale.
///
/// Haddii noocaagu yahay [`Ord`], waad hirgelin kartaa [`partial_cmp`] adoo adeegsanaya [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Waxa kale oo aad ka heli laga yaabaa in ay waxtar leh in la isticmaalo [`partial_cmp`] on beerihiinna nooc ee.
/// Halkan waxaa ku yaal tusaale noocyada `Person` oo leh aag sabeyn-dhibic ah `height` oo ah kan keliya ee loo adeegsado kala-soocidda:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Habkani wuxuu soo celinayaa dalab u dhexeeya qiimaha `self` iyo `other` haddii mid jiro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Marka isbarbardhiggu aanu macquul ahayn
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Habkani wuxuu tijaabiyaa wax ka yar (`self` iyo `other`) waxaana adeegsada hawlwadeenka `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Habkani wuxuu tijaabiyaa wax ka yar ama u dhigma (`self` iyo `other`) waxaana adeegsada hawlwadeenka `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Habkani waxa u ku imtixaamaa weyn yahay, (waayo, `self` iyo `other`) waxaana loo isticmaalaa by operator `>` ah.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Habkani waxa u ku imtixaamaa weyn yahay ama la mid ah, (waayo, `self` iyo `other`) waxaana loo isticmaalaa by operator `>=` ah.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Dhaqale dheegato guud impl ah `PartialOrd` trait ah.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Isbarbar dhiga oo soo celiya uguyaraan laba qiime.
///
/// Waxay soo celineysaa doodda koowaad haddii isbarbardhiggu go'aamiyo inay siman yihiin.
///
/// Gudaha ayaa adeegsanaya magac loo yaqaan [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Sooceliyaa uguyaraan laba qiime marka loo eego shaqada isbarbar dhiga lagu qeexay.
///
/// Waxay soo celineysaa doodda koowaad haddii isbarbardhiggu go'aamiyo inay siman yihiin.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Waxay soocelisaa cunsurka siiya qiimaha ugu yar shaqada la cayimay.
///
/// Waxay soo celineysaa doodda koowaad haddii isbarbardhiggu go'aamiyo inay siman yihiin.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Isbarbardhiga oo soo celiya ugu badnaan laba qiime.
///
/// Waxay soo celineysaa doodda labaad haddii isbarbardhiggu go'aamiyo inay siman yihiin.
///
/// Gudaha isticmaalaa alias ah in [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Sooceliyaa ugu badnaan laba qiimahood marka loo eego shaqada isbarbar dhiga lagu qeexay.
///
/// Waxay soo celineysaa doodda labaad haddii isbarbardhiggu go'aamiyo inay siman yihiin.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Waxay soocelisaa cunsurka siiya qiimaha ugu badan shaqada la cayimay.
///
/// Waxay soo celineysaa doodda labaad haddii isbarbardhiggu go'aamiyo inay siman yihiin.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Hirgelinta PartialEq, Equatorial, PartialOrd iyo Ord noocyada heer hoose
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Amarka halkan ayaa muhiim u ah in la abuuro isku imaatin wanaagsan.
                    // Ka eeg <https://github.com/rust-lang/rust/issues/63758> wixii macluumaad dheeraad ah.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Ku ridaya i8's iyo u beddelka farqiga u ah Ordering wuxuu abuuraa isku imaatin wanaagsan.
            //
            // Ka eeg <https://github.com/rust-lang/rust/issues/66780> wixii macluumaad dheeraad ah.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // BADBAADADA: bool sida i8 u soo celiyo 0 ama 1, markaa farqiga ma noqon karo wax kale
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &tilmaamayaasha

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}