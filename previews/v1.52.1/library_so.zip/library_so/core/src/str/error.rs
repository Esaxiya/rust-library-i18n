//! Qeexaa nooca qaladka utf8.

use crate::fmt;

/// Khaladaadka dhici kara marka la isku dayayo in loo turjumo taxanaha [`u8`] sida xarig.
///
/// Sida oo kale, qoyska `from_utf8` ee hawlaha iyo hababka labada [`String`] iyo [`&str`] s samaynaysaa isticmaalka baadi this, tusaale ahaan.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Hababka nooca qaladka ah waxaa loo isticmaali karaa in lagu abuuro shaqooyin la mid ah `String::from_utf8_lossy` iyadoon loo qoondeynin xusuusta taalada:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Sooceliyaa tusmada xariga la siiyay ilaa iyo inta laga xaqiijiyay UTF-8 ansax ah.
    ///
    /// Waa tusmada ugu badan sida `from_utf8(&input[..index])` uu ku celin lahaa `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::str;
    ///
    /// // xoogaa bytes aan ansax ahayn, oo ku jira vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Soo Laabtay Utf8Error a
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // byte labaad waa baadil halkan
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Waxay bixisaa macluumaad dheeraad ah oo ku saabsan fashilka:
    ///
    /// * `None`: dhamaadka talooyin ah ayaa si lama filaan gaadhay.
    ///   `self.valid_up_to()` waa 1 ilaa 3 bytes oo ka bilaabmaysa dhamaadka galinta.
    ///   Haddii durdur byte ah (sida fayl ama shabakad god ah) si xawli ah loo gogol xaarayo, tani waxay noqon kartaa `char` ansax ah oo isku xigxigta x01X ay faafayso qaybo badan.
    ///
    ///
    /// * `Some(len)`: byte lama filaan ah ayaa lala kulmay.
    ///   oo dhererkeedu wuxuu la siiyaa waa in la gooyo byte sax ahayn in bilowday at index la siiyo by `valid_up_to()`.
    ///   Kelmadaha waa in dib loo bilaabo ka dib markii isku xigxiga in (ka dib markii galinta a [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) ee case of kelmadaha lossy.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Cilad ayaa soo noqotey markii lafa-gurayo `bool` iyadoo la adeegsanayo [`from_str`] way fashilantay
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}