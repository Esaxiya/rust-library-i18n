//! Xadhiga Qaabka API.
//!
//! Qaabka API wuxuu bixiyaa farsamo guud oo loo adeegsado noocyada qaababka kala duwan marka la raadinayo xarig.
//!
//! Faahfaahin dheeraad ah, ka eeg traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], iyo [`DoubleEndedSearcher`].
//!
//! Inkastoo API tani waa deganayn, waxaa soo if-via isdiyaari deggan nooca [`str`] ah.
//!
//! # Examples
//!
//! [`Pattern`] waa [implemented][pattern-impls] ee API deggan, waayo, [`&str`][`str`], [`char`], xaleef [`char`], iyo hawlaha iyo xiritaanka fulinta `FnMut(char) -> bool` ah.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // qaabka char
//! assert_eq!(s.find('n'), Some(2));
//! // jeex jeexan qaabka
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // qaabka xiritaanka
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Qaab xarig ah.
///
/// A `Pattern<'a>` ku muujinayaa in nooca fulinta waxaa loo isticmaali karaa sida hannaankii string goobidda in [`&'a str`][str] a a.
///
/// Tusaale ahaan, labadaba `'a'` iyo `"aa"` waa qaabab u dhigma doona isbarbar dhiga `1` ee xarigga `"baaaab"`.
///
/// trait laftiisu u dhaqmo sida dhisaha ah an la xidhiidha nooca [`Searcher`], kaas oo sameeya shaqada dhabta ah ee helida dhacdooyinka of hannaanka ee string ah.
///
///
/// Waxay kuxirantahay nooca qaabka, habdhaqanka hababka sida [`str::find`] iyo [`str::contains`] way isbadali karaan.
/// Shaxda hoose waxay sharaxaysaa qaar ka mid ah dabeecadaha kuwa.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Raadiyaha kuxiran qaabkan
    type Searcher: Searcher<'a>;

    /// Wuxuu ka dhisayaa raadiye laxiriira `self` iyo `haystack` inuu wax ka raadiyo.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Wuxuu hubiyaa in qaabku u dhigmayo meel kasta oo cawsku ku jiro
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Wuxuu hubiyaa in qaabku u dhigmayo xagga hore ee cawska
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Wuxuu hubiyaa in qaabku u dhigmayo xagga dambe ee cowska
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Wuxuu ka saarayaa qaabka hore cawska, haddii uu u dhigmo.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // BADBAADADA: `Searcher` waxaa lagu yaqaan inay soo celiso indices sax ah.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Bixisaa hannaankii ka dambe ee buur caws laga sameyey, haddii ay kulan.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // BADBAADADA: `Searcher` waxaa lagu yaqaan inay soo celiso indices sax ah.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Natiijo yeeray [`Searcher::next()`] ama [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Muujinayaa in ciyaar qaabeedka laga helay `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Muujinayaa in `haystack[a..b]` loo diiday inay u dhigantaa qaabka.
    ///
    /// Xusuusnow in ay jiri karaan wax ka badan hal `Reject` inta udhaxeysa laba ``Match`es, ma jirto wax shuruud ah oo ay ku midoobayaan hal.
    ///
    ///
    Reject(usize, usize),
    /// Muujinayaa in byte kasta oo buur caws laga sameyey ayaa booqday, afjaridda siyaalaha ka.
    ///
    Done,
}

/// Raadiyaha qaab xarig ah.
///
/// trait waxay bixisaa habab Boogaadin kulan aan isa of qaab bilaabo hore (left) of xarig ah.
///
/// Waxaa lagu fulin doonaa by la xidhiidha noocyada `Searcher` of trait [`Pattern`] ah.
///
/// trait waxaa lagu calaamadeeyay mid aan aamin aheyn maxaa yeelay tusmooyinka ay soo celiyeen qaababka [`next()`][Searcher::next] ayaa looga baahan yahay inay ku jiifsadaan xuduudaha utf8 ee ansaxa ah.
/// Tani waxay awood u macaamiisha ee trait si cad ama buur caws laga sameyey oo aan jeeg Runtime dheeraad ah.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter ee xarigga hoose si loo baaro
    ///
    /// had iyo jeer soo laaban doono isla [`&str`][str] ah.
    fn haystack(&self) -> &'a str;

    /// Waxay qabataa tallaabada xigta ee raadinta laga bilaabo hore.
    ///
    /// - Sooceliyaa [`Match(a, b)`][SearchStep::Match] haddii `haystack[a..b]` u dhigma qaabka.
    /// - Sooceliyaa [`Reject(a, b)`][SearchStep::Reject] haddii `haystack[a..b]` uusan u dhigmin karin qaabka, xitaa qayb ahaan.
    /// - Dib [`Done`][SearchStep::Done] haddii byte kasta oo buur caws laga sameyey ayaa booqday.
    ///
    /// socodka [`Match`][SearchStep::Match] iyo [`Reject`][SearchStep::Reject] qiimeeyo ilaa [`Done`][SearchStep::Done] ah ku jiri doona safafka index kuwa ku xiga, oo aan is dul saaran, oo daboolaya buur caws laga sameyey oo dhan, oo yeynan on xuduudaha utf8.
    ///
    ///
    /// Natiijada A [`Match`][SearchStep::Match] u baahan yahay inuu ku jira naqshad oo dhan kulan, si kastaba ha ahaatee natiijada [`Reject`][SearchStep::Reject] loo kala qaybin karo kor u aabo yeelin jajabkii badan oo ku xeeran.Labada noocba waxay yeelan karaan dherer eber ah.
    ///
    /// Tusaale ahaan, qaabka `"aaa"` iyo cawska x01X ayaa soo saari kara durdurka
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Wuxuu helaa natiijada xigta ee [`Match`][SearchStep::Match].Fiiri [`next()`][Searcher::next].
    ///
    /// Si ka duwan [`next()`][Searcher::next], ma jirto wax damaanad ah in safafka la soo celiyey ee kan iyo [`next_reject`][Searcher::next_reject] ay is dul mari doonaan.
    /// Tani waxay ku soo laaban doona `(start_match, end_match)`, halkaas oo start_match waa index of halkaas oo ciyaarta ka bilaabmaa, iyo end_match waa index ka dib markii dhamaadka ciyaarta.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Wuxuu helaa natiijada xigta ee [`Reject`][SearchStep::Reject].Eeg [`next()`][Searcher::next] iyo [`next_match()`][Searcher::next_match].
    ///
    /// Si ka duwan [`next()`][Searcher::next], ma jirto wax damaanad ah in safafka la soo celiyey ee kan iyo [`next_match`][Searcher::next_match] ay is dul mari doonaan.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Raadiye A dambe masaal string ah.
///
/// trait-kani wuxuu bixiyaa habab lagu raadiyo isbarbar dhigyo aan is dul-dhigneyn oo ah qaab ka bilaabmaya dhabarka (right) ee xarigga.
///
/// Waxaa lagu fulin doonaa by la xidhiidha noocyada [`Searcher`] of trait [`Pattern`] haddii taageero tilmaantii raadinaya Gadaal ka.
///
///
/// Heerarka tusmada ee ay soo celisay trait looma baahna inay si sax ah isugu dhigmaan kuwa raadinta horay u socota.
///
/// Sababta sababta trait-kan loogu calaamadeeyay mid aan aamin ahayn, u arag iyaga waalidkood trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Waxay qabataa tallaabada xigta ee raadinta laga bilaabo dhabarka.
    ///
    /// - Sooceliyaa [`Match(a, b)`][SearchStep::Match] haddii `haystack[a..b]` u dhigmo qaabka.
    /// - Dib [`Reject(a, b)`][SearchStep::Reject] haddii `haystack[a..b]` ma u dhigma karaan hannaanka, xitaa qayb ahaan.
    /// - Soocelinayaa [`Done`][SearchStep::Done] haddii baay kasta oo ciidda ka mid ah la booqday
    ///
    /// socodka [`Match`][SearchStep::Match] iyo [`Reject`][SearchStep::Reject] qiimeeyo ilaa [`Done`][SearchStep::Done] ah ku jiri doona safafka index kuwa ku xiga, oo aan is dul saaran, oo daboolaya buur caws laga sameyey oo dhan, oo yeynan on xuduudaha utf8.
    ///
    ///
    /// Natiijada A [`Match`][SearchStep::Match] u baahan yahay inuu ku jira naqshad oo dhan kulan, si kastaba ha ahaatee natiijada [`Reject`][SearchStep::Reject] loo kala qaybin karo kor u aabo yeelin jajabkii badan oo ku xeeran.Labada noocba waxay yeelan karaan dherer eber ah.
    ///
    /// Tusaale ahaan, hannaanka `"aaa"` iyo buur caws laga sameyey `"cbaaaaab"` laga yaabaa in ay soo saaraan webigu ku `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Wuxuu helaa natiijada soo socota ee [`Match`][SearchStep::Match].
    /// Fiiri [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Wuxuu helaa natiijada soo socota ee [`Reject`][SearchStep::Reject].
    /// Fiiri [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Calaamadeeye trait si loo muujiyo in [`ReverseSearcher`] loo isticmaali karo hirgelinta [`DoubleEndedIterator`].
///
/// Waayo, kanu, impl ee [`Searcher`] iyo [`ReverseSearcher`] u baahan tahay in la raaco shuruudaha soo socda:
///
/// - Dhammaan natiijooyinka `next()` waxay u baahan yihiin inay la mid noqdaan natiijooyinka `next_back()` ee isku xigxiga.
/// - `next()` iyo `next_back()` waxay u baahan yihiin inay u dhaqmaan sida labada daraf ee qiyam kala duwan, taasi waa inaysan ahayn "walk past each other".
///
/// # Examples
///
/// `char::Searcher` waa `DoubleEndedSearcher` sababtoo ah Boogaadin [`char`] ah kaliya waxay u baahan tahay eegaya hal mar, taas oo u dhaqmo isku mid ka shishaysa.
///
/// `(&str)::Searcher` maahan `DoubleEndedSearcher` maxaa yeelay qaabka `"aa"` ee cowska `"aaa"` wuxuu u dhigmaa sida `"[aa]a"` ama `"a[aa]"` midkood, iyadoo kuxiran dhanka laga raadinayo.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl loogu talagalay char
/////////////////////////////////////////////////////////////////////////////

/// La xidhiidha nooca for `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariant badbaadada: `finger`/`finger_back` waa in ay utf8 index a byte ansax ah `haystack` invariant Tani jebin karo *gudahood next_match* iyo next_match_back, si kastaba ha ahaatee waa in ay faraha ku saabsan xudduudaha dhibic code ansax baxdo.
    //
    //
    /// `finger` waa tilmaanta baay ee hadda raadinta hore u socota.
    /// Ka soo qaad in ay jirto ka hor baaytka tusmadiisa, tusaale
    /// `haystack[finger]` waa bajisada ugu horeysa ee jeexan waa inaan baarno inta lagu gudajiro raadinta
    ///
    finger: usize,
    /// `finger_back` waa tilmaanta baate ee hadda raadinta gadaal.
    /// Qiyaas inay jirto ka dib baaytka tusmadiisa, tusaale
    /// cowsack [far_back, 1] waa baytkii ugu dambeeyay ee jeexan waa inaan baarnaa inta lagu gudajiro raadinta (sidaasna ay tahay baytkii ugu horreeyay ee la kormeero markii aan wacayo next_back()).
    ///
    finger_back: usize,
    /// Dabeecadda la raadinayo
    needle: char,

    // badbaado la'aan: `utf8_size` waa inuu ka yaraadaa 5
    /// Tirada bytes `needle` waxay qaadataa marka lagu qoro utf8.
    utf8_size: usize,
    /// A utf8 encoded koobi `needle` ah
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // BADBAADADA: 1-4 ayaa dammaanad qaadaya badbaadada `get_unchecked`
        // 1. `self.finger` iyo `self.finger_back` waxaa lagu hayaa on xuduudaha koodh caalamiga (tani waa invariant)
        // 2. `self.finger >= 0` tan iyo markii ay ku bilaabataa at 0 iyo korodhka kaliya
        // 3. `self.finger < self.finger_back` maxaa yeelay, haddii kale char ku `iter` laaban doono `SearchStep::Done`
        // 4.
        // `self.finger` yimaado ka hor dhamaadka buur caws laga sameyey sababtoo ah `self.finger_back` bilaabmaa dhammaadka oo kaliya hoos u
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // kudhiso cabirka meertada dabeecadda hadda aan dib-u-qorin sida utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // hel cawska kadib dabeecaddii ugu dambeysay ee la helo
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // byte ugu dambeeyey ee utf8 ku encoded BADBAADADA irbad: waxaan leenahay invariant in `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Farta cusubi waa tusmada halbeegga aan helnay, iyo mid, oo lagu daray, tan iyo markii aan memchr'd u noqonayno baytkii ugu dambeeyay ee astaamaha.
                //
                // Xusuusnow in tani aysan marwalba far naga siinin soohdinta UTF8.
                // Haddii aan * * ma heli our qof laga yaabaa in aan ku xaddiday in byte aan ugu dambeeyey ee 3-byte ama 4-byte dabeecad.
                // Kaliya uma boodi karno halbeegga soo socda ee bilowga ah ee ansaxa ah maxaa yeelay dabeecad sida ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ayaa naga heleysa marwalba baat labaad markaan raadineyno kan saddexaad.
                //
                //
                // Si kastaba ha noqotee, tani gebi ahaanba waa caadi.
                // Inkasta oo aan wax invariant in self.finger waa soohdinta UTF8 ah, invariant this aan la isku halleeyeen habkan gudahood (waxaa la isku halleeyeen in CharSearcher::next()).
                //
                // Waxaan kaliya uga baxa habkan marka aan gaadho dhammaadka xarig ah, ama hadii aan helno wax.Marka aan helno wax `finger` la fadhiisin doonaa in xuduud UTF8 ah.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // waxba ma helin, ka bax
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // Next_reject ha u adeegsado hirgelinta asaasiga ah Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // BADBAADADA: Arag faallada next() ee kore
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // byte Kala jar mowjadda ee qof hadda aan dib-u-habaynteeda sida utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // hel cawska ilaa laakiin ha ku darin astaamihii ugu dambeeyay ee la baaray
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // byte ugu dambeeyey ee utf8 ku encoded BADBAADADA irbad: waxaan leenahay invariant in `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // waxaan baadhay jeex ah oo la socdo meelo kale self.finger, ku dar self.finger in lagu iibin doono index asalka
                //
                let index = self.finger + index;
                // memrchr wuxuu soo celin doonaa tusmada baytka aan rabno inaan helno.
                // In case of qof ASCII ah, tani waxaa la ahaayeen waxaannu doonaynaa our farta cusub in uu noqdo ("after" char helay ee qaabka of siyaalaha kale).
                //
                // Meelaha badan ee loo yaqaan 'multibyte chars' waxaan u baahanahay inaan uga boodno tirada baatiyada ay ka badan yihiin ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // guurto farta ka hor inta qof ee laga helay (ie, at index ay bilow)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Ma isticmaali karno far_caaw=tusmo, cabir + 1 halkan.
                // Haddii aan helay char ugu dambeeyey ee qof a kala duwan oo cabbirkooda (ama byte dhexe dabeecad ka duwan yahay) Waxaan u baahanahay inaan garaac finger_back hoos ugu soo `index`.
                // Tani waxay si lamid ah ka dhigeysaa `finger_back` inay awood u leedahay inaysan ku sii jiri karin soohdinta, laakiin tani waa caadi tan iyo markii aan ka baxno shaqadan kaliya xadka ama markii cawska la wada baaray.
                //
                //
                // Si ka duwan next_match this ma laha dhibaatada bytes soo noqnoqda ee utf-8 maxaa yeelay aannu baadi byte ee la soo dhaafay, waxa keliya oo aanu ku heli karaa byte ee la soo dhaafay marka raadinta dambe.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // waxba ma helin, ka bax
                return None;
            }
        }
    }

    // next_reject_back ha u adeegsado hirgelinta aasaasiga ah Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Baadhitaanno loogu talagalay kuraasta oo u dhiganta [`char`] la siiyay.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl duub MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Isbarbar dhig dhererka jajabka bajaajleyda gudaha si aad uhesho dhererka jaantuska hadda jira
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Isbarbar dhig dhererka jajabka bajaajleyda gudaha si aad uhesho dhererka jaantuska hadda jira
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl loogu talagalay&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Change/saar sabab u madmadowga ku sugan taasoo la micno ah.

/// Nooca ku xiran `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Baadhitaanno loogu talagalay silsilado u dhigma mid ka mid ah [`` char ''] ku jira jeexdan.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Caawinta F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Nooca ku xiran `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Raadinta [`` char '] ee u dhigma saadaasha la bixiyay.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl loogu talagalay&&str
/////////////////////////////////////////////////////////////////////////////

/// Wufuudda ka socota `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl loogu talagalay &str
/////////////////////////////////////////////////////////////////////////////

/// Non-qoondaynta substring search.
///
/// Wax ka qaban doonaa hannaankii `""` sidii soo celinta ciyaaro madhan xadka dabeecad kasta.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Wuxuu hubiyaa in qaabku u dhigmayo xagga hore ee cawska.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Wuxuu ka saarayaa qaabka hore cawska, haddii uu u dhigmo.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // BADBAADADA: Horgalaha ayaa hadda la xaqiijiyey inuu jiro.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Checks in kulan hannaankii dambe ee buur caws laga sameyey ah.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Bixisaa hannaankii ka dambe ee buur caws laga sameyey, haddii ay kulan.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // BADBAADADA: ku-xirnaanta ayaa hadda la xaqiijiyay inay jirto.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Raadiyaha Laba Wade
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Nooca ku xiran `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // irbad madhan ayaa diidaya char kasta oo waxay u dhigantaa xarig kasta oo faaruq ah oo u dhexeeya
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher saarta *ansax Kulanka* indices in kala at xuduudaha char inta ay ma ku habboon oo sax ah iyo buur caws laga sameyey iyo irbad waa ansax UTF-8 *oo diiday* ka geynta ku dhici karaa indices kasta, laakiin waxaan ku socon doonaa gacanta si soohdinta qof soo socda, si ay u yihiin utf-8 badbaado.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // u gudub xadka xiga char
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // waxaad u qortaa baxay kiisaska `true` iyo `false` si loo dhiiri compiler in ay ku takhasusaan labada xaaladood si gooni gooni ah.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // u gudub xadka xiga char
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // qor `true` iyo `false`, sida `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Xaaladda gudaha ee algorithm-ka raadinta laba-geesoodka ah.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// index factorization muhiim ah
    crit_pos: usize,
    /// index factorization muhiim u irbad beddeli
    crit_pos_back: usize,
    period: usize,
    /// `byteset` waa kordhin (ma aha qayb ka mid ah labada hab algorithm);
    /// waxaa "fingerprint" 64-bit ah halka ay set kasta qaniintay waafaqsantahay `j` in a (byte&63)==joogo j ee irbadda.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// ku muuji cirbadda ka hor taas oo aan horeyba u waafaqnay
    memory: usize,
    /// tus galka ka dib kaas oo aan mar hore iswaafajinnay
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Faahfaahin gaar ah oo la akhrin karo oo ku saabsan waxa halkan ka socda ayaa laga heli karaa buuga Crochemore iyo Rytter ee "Text Algorithms", ch 13.
        // Gaar ahaan ka eeg koodhka "Algorithm CP" p.
        // 323.
        //
        // Waxa socda waa qaar ka mid ah waxaan leenahay factorization muhiim ah (u, v) irbadda, iyo waxaan rabnaa in aan ogaado haddii u yahay xarfaha a of&v [.. muddo].
        // Hadday tahay, waxaan isticmaalnaa "Algorithm CP1".
        // Haddii aan u isticmaalno "Algorithm CP2", kaas oo la filaayo in marka muddada irbad waa ballaadhan yahay.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // kiis muddo gaaban ah-muddada ayaa si sax ah u xisaabisa isir gaar ah oo muhiim ah oo loogu talagalay cirbadda la rogay x=u 'v' where | v '|<period(x).
            //
            // Tani waxaa ay kor u falkaasi by jirnaa muddo hore u ogeysiiyaan.
            // Xusuusnow in kiis la mid ah x= "acba" laga yaabo in si sax ah horay loogu socodsiiyo (crit_pos=1, period=3) halka lagudaweynayo mudo qiyaasi ah oo kaduwan (crit_pos=2, mudo=2).
            // Waxaan u isticmaali factorization la siiyey dambe Laakiinse ay xajiyaan waqtiga saxda ah.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // kiiska muddo dheer-waxaan leenahay ku dhaw in mudada dhabta ah, iyo ha isticmaalin xasuusta.
            //
            //
            // Ku qiyaaso muddada xadka hoose ee max(|u|, |v|) + 1.
            // factorization muhiim waa ku ool ah si ay u isticmaalaan for search Weeraryahanka iyo dambe labadaba.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Qiimaha Dummy si loo muujiyo in muddadu dheer tahay
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Mid ka mid ah fikradaha ugu waaweyn ee Laba-Weyn ayaa ah inaan irbadda u kala qaadno laba qaybood, (u, v), oo aan bilowno isku dayga inaan ku helno v qashin-qubka adoo iskaanka bidix ilaa midig u sawiraya.
    // Haddii kulan v, waxaan isku dayaan in ay u dhigma iyadoo lagu eegayo xaq u leeyahay inuu ka tagay.
    // Intee in le'eg ayaan ka boodi karnaa marka aan la kulanno isku dheelitirnaan la'aanteed waxay ku saleysan tahay xaqiiqda ah in (u, v) ay muhiim u tahay cirbadda.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` wuxuu adeegsadaa `self.position` calaamadee ahaan
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Hubi inaan haysanno meel aan ku baadhi karno booska + cirbadda-ugu dambeeya oo aan buuxin karin haddii aan u malayno in jeexjeexyada ay ku xiran yihiin xaddiga isise.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Si dhakhso leh uga bood qaybo badan oo aan ku xidhnayn qalabka wax lagu xidho
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Eeg haddii qaybta midig ee cirbaddu ay is leedahay
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Eeg haddii qayb bidix kulan irbadda
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Waannu helnay kulan!
            let match_pos = self.position;

            // Note: kudar self.period halkii aad kaheli lahayd needle.len() si aad uhesho ciyaaro is dulsaaran
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // qarka u saaran inuu needle.len(), self.period for isa kulan
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Raac fikradaha ku jira `next()`.
    //
    // qeexitaan waa symmetrical, la period(x) = period(reverse(x)) iyo local_period(u, v) = local_period(reverse(v), reverse(u)), sidaas darteed haddii (u, v) waxaa factorization muhiim ah, sidaa darteed waa (reverse(v), reverse(u)).
    //
    //
    // Kiiska gadaashiisa waxaan u xisaabnay qodob muhiim ah x=u 'v' (beerta `crit_pos_back`).Waxaan ubaahanahay | u |<period(x) dacwada horay loo soo gudbiyay iyo sidaas | v '|<period(x) dhanka dambe.
    //
    // Si aad u raadiso oo cagsi ah iyada oo buur caws laga sameyey ah, waxaan hore u raadin iyada oo buur caws laga sameyey a beddeli irbad beddeli, tallaabadaas ugu horeysay u 'ka dibna v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` wuxuu adeegsadaa `self.end` inuu yahay dulqabad-si markaa `next()` iyo `next_back()` ay u madax bannaan yihiin.
        //
        let old_end = self.end;
        'search: loop {
            // Hubi in aan qolka si aad u raadiso in dhamaadka, needle.len() duub doonaa marka uu jiro qol mar dambe, laakiin ay sabab u tahay dhererka xadka jeex marnaba qof huwan karo oo dhan dib u soo galeen dhererka buur caws laga sameyey ah.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Si dhakhso leh uga bood qaybo badan oo aan ku xidhnayn qalabka wax lagu xidho
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Eeg haddii qayb bidix kulan irbadda
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Eeg haddii qaybta midig ee cirbaddu ay is leedahay
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Waannu helnay kulan!
            let match_pos = self.end - needle.len();
            // Note: sub self.period halkii needle.len() in ay kulan isa
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Xisaabi dhejiska ugu sarreeya ee `arr`.
    //
    // galaha maximal waa factorization muhiim suurto gal ah (u, v) ee `arr`.
    //
    // Celinta (`i`, `p`) halkaas oo `i` waa index-upka ah v iyo `p` waa muddada v.
    //
    // `order_greater` go'aaminaya haddii amarka ereyga uu yahay `<` ama `>`.
    // Labada amar waa in lagu xisaabiyaa-ku dalbashada ugu weyn ee `i` waxay siinaysaa isir ahaansho muhiim ah.
    //
    //
    // Kiisaska muddada dheer, muddada ka soo baxaysa sax ma aha (way gaaban tahay).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Waxay u dhigantaa aniga warqadda
        let mut right = 1; // Waxay u dhigantaa j warqadda
        let mut offset = 0; // Waxay u dhigantaa k warqadda, laakiin waxay ka bilaabaneysaa 0
        // si loo waafajiyo tusmada 0-ku saleysan.
        let mut period = 1; // U dhiganta p in warqada

        while let Some(&a) = arr.get(right + offset) {
            // `left` noqon doonaa inbounds markii `right` waa.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suufiyada waa yartahay, mudada ayaa ah horgale ilaa iyo hada.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ku sii soco ku celcelinta xilliga hadda jira.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suufiyadu waa weyn tahay, ka bilow meesha hadda.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Xisaabi dhejiska ugu sarreeya ee xagga dambe ee `arr`.
    //
    // galaha maximal waa factorization muhiim suurto gal ah (u ', v') ee `arr`.
    //
    // Sooceliyaa `i` halka `i` uu yahay tusmada bilowga ee v ', xaga dambe;
    // isla markiiba soo noqdaa marka muddada `known_period` la gaaro.
    //
    // `order_greater` go'aaminaya haddii amarka ereyga uu yahay `<` ama `>`.
    // Labada amar waa in lagu xisaabiyaa-ku dalbashada ugu weyn ee `i` waxay siinaysaa isir ahaansho muhiim ah.
    //
    //
    // Kiisaska muddada dheer, muddada ka soo baxaysa sax ma aha (way gaaban tahay).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Waxay u dhigantaa aniga warqadda
        let mut right = 1; // Waxay u dhigantaa j warqadda
        let mut offset = 0; // Waxay u dhigantaa k warqadda, laakiin waxay ka bilaabaneysaa 0
        // si loo waafajiyo tusmada 0-ku saleysan.
        let mut period = 1; // U dhiganta p in warqada
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suufiyada waa yartahay, mudada ayaa ah horgale ilaa iyo hada.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ku sii soco ku celcelinta xilliga hadda jira.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suufiyadu waa weyn tahay, ka bilow meesha hadda.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// SecondWayStrategy waxay u oggolaaneysaa algorithm inuu ka boodo kuwa aan cayaaraha ahayn sida ugu dhakhsaha badan ee suurtogalka ah, ama inuu uga shaqeeyo qaab uu ku sii daayo Diidmada si dhakhso leh.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// U gudub si aad uhesho muddooyinka sida ugu dhaqsaha badan
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Diidmada si joogto ah
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}