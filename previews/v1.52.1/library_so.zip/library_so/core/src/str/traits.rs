//! Fulinta Trait ee `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Waxay fulisaa amarka xadhkaha.
///
/// Xargaha waxaa lagu dalbadaa [lexicographically](Ord#lexicographical-comparison) qiimahooda byte.
/// Amarkani wuxuu amrayaa dhibcaha koodhka Unicode iyadoo lagu saleynayo boosaska ay ku leeyihiin jaantusyada koodhka.
/// Tani daruuri maahan inay la mid tahay amarka "alphabetical", oo ku kala duwan luqad iyo degaan ahaan.
/// Kala soocida xargaha iyadoo loo eegayo heerarka dhaqan ahaan la aqbalay waxay u baahan tahay xog u gaar ah deegaanka oo ka baxsan baaxadda nooca `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Waxay ku fulisaa howlaha isbarbar dhigga xadhkaha.
///
/// Xargaha waxaa lagu barbardhigayaa [lexicographically](Ord#lexicographical-comparison) qiyamkooda baate.
/// Tani barbardhigay dhibcood code koodh caalamiga ku salaysan ay ku gooldhalinta xeerka.
/// Tani daruuri maahan inay la mid tahay amarka "alphabetical", oo ku kala duwan luqad iyo degaan ahaan.
/// Isbarbardhiga xargaha iyadoo loo eegayo heerarka dhaqan ahaan la aqbalay waxay u baahan tahay xog u gaar ah deegaanka oo ka baxsan baaxadda nooca `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Qalab substring oo tuban la Saan `&self[..]` ama `&mut self[..]`.
///
/// Waxay soocelisaa gabal xadhig dhan ah, ie, waxay soocelisaa `&self` ama `&mut self`.Oo u dhiganta ku yidhi&is [0 ..
/// Len] `` ama&mut is [0 ..
/// len]`.
/// Si ka duwan howlgallada kale tusmaynta, taasi marnaba kartaan panic.
///
/// Hawlgalkani waa *O*(1).
///
/// Ka hor inta aan 1.20.0, hawlgallada tusmaynta ka mid ah ayaa weli ay taageerto fulinta si toos ah `Index` iyo `IndexMut`.
///
/// U dhiganta `&self[0 .. len]` ama `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Qalab substring oo tuban la Saan `&self[begin .. end]` ama `&mut self[begin .. end]`.
///
/// Waxay ka soo celisaa qayb ka mid ah xadhigii xadhkaha la bixiyay '' Start ', `end`).
///
/// Hawlgalkani waa *O*(1).
///
/// Ka hor inta aan 1.20.0, hawlgallada tusmaynta ka mid ah ayaa weli ay taageerto fulinta si toos ah `Index` iyo `IndexMut`.
///
/// # Panics
///
/// Panics haddii `begin` ama `end` uusan tilmaameynin bilawga bilowga dabeecad (sida lagu qeexay `is_char_boundary`), haddii `begin > end`, ama haddii `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // panic doonista kuwan:
/// // byte 2 waxay ku taal gudaha `ö`:
/// // &s [2 ..3];
///
/// // byte 8 been gudahood `老`&s [1 ..
/// // 8];
///
/// // byte 100 ka baxsan waa xarig ah&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BADBAADADA: hadda waa la hubiyey in `start` iyo `end` ay ku jiraan xuduud char ah,
            // waxaanna ku gudbeynaa tixraac aamin ah, sidaa darteed qiimaha soo noqoshada sidoo kale mid ayuu noqon doonaa.
            // Waxaan sidoo kale hubinay xuduudaha char, marka tani waa ansax UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BADBAADADA: hadda waa la hubiyey in `start` iyo `end` ay ku jiraan xuduud char ah.
            // Waan ognahay tilmaanta inay gaar tahay maxaa yeelay waxaan ka helnay `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BADBAADADA: Wicitaanku wuxuu dammaanad qaadayaa in `self` ay ku egtahay xuduudaha `slice`
        // taas oo uu dhergiyey oo dhan shuruudaha `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // AMMAANKA: arki comments for `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // jeegaga is_char_boundary in index waa in [0, .len()] karin reuse `get` sida kor ku xusan, sababta oo ah NLL dhibaato
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BADBAADADA: hadda waa la hubiyey in `start` iyo `end` ay ku jiraan xuduud char ah,
            // waxaanna ku gudbeynaa tixraac aamin ah, sidaa darteed qiimaha soo noqoshada sidoo kale mid ayuu noqon doonaa.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Waxay hirgelisaa jarjaran jaranjarooyinka iyadoo loo adeegsanayo qaabeynta `&self[.. end]` ama `&mut self[.. end]`.
///
/// Ka soo celisaa qayb ka mid ah xadhigii xadhiga '' 0`, `end`)
/// U dhiganta `&self[0 .. end]` ama `&mut self[0 .. end]`.
///
/// Hawlgalkani waa *O*(1).
///
/// Ka hor inta aan 1.20.0, hawlgallada tusmaynta ka mid ah ayaa weli ay taageerto fulinta si toos ah `Index` iyo `IndexMut`.
///
/// # Panics
///
/// Panics haddii `end` uusan tilmaameynin bilawga bilawga dabeecadda (sida lagu qeexay `is_char_boundary`), ama haddii `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BADBAADADA: hadda waa la hubiyey in `end` uu ku jiro soohdinta xadka,
            // waxaanna ku gudbeynaa tixraac aamin ah, sidaa darteed qiimaha soo noqoshada sidoo kale mid ayuu noqon doonaa.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BADBAADADA: hadda waa la hubiyey in `end` uu ku jiro soohdinta xadka,
            // waxaanna ku gudbeynaa tixraac aamin ah, sidaa darteed qiimaha soo noqoshada sidoo kale mid ayuu noqon doonaa.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // BADBAADADA: hadda waa la hubiyey in `end` uu ku jiro soohdinta xadka,
            // waxaanna ku gudbeynaa tixraac aamin ah, sidaa darteed qiimaha soo noqoshada sidoo kale mid ayuu noqon doonaa.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Waxay hirgelisaa jarjaran jaranjarooyinka iyadoo loo adeegsanayo qaabeynta `&self[begin ..]` ama `&mut self[begin ..]`.
///
/// Dib jeex ah string la siiyey kala duwan byte ah [`begin`, `len`).U dhiganta ``&is [bilow ..
/// Len] `` ama&is mut [bilaabaan ..
/// len]`.
///
/// Hawlgalkani waa *O*(1).
///
/// Ka hor inta aan 1.20.0, hawlgallada tusmaynta ka mid ah ayaa weli ay taageerto fulinta si toos ah `Index` iyo `IndexMut`.
///
/// # Panics
///
/// Panics haddii `begin` ma farta byte-upka mowjadda of dabeecad (sida lagu qeexay by `is_char_boundary`), ama haddii `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BADBAADADA: hadda waa la hubiyey in `start` uu ku jiro soohdinta xadka,
            // waxaanna ku gudbeynaa tixraac aamin ah, sidaa darteed qiimaha soo noqoshada sidoo kale mid ayuu noqon doonaa.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BADBAADADA: hadda waa la hubiyey in `start` uu ku jiro soohdinta xadka,
            // waxaanna ku gudbeynaa tixraac aamin ah, sidaa darteed qiimaha soo noqoshada sidoo kale mid ayuu noqon doonaa.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BADBAADADA: Wicitaanku wuxuu dammaanad qaadayaa in `self` ay ku egtahay xuduudaha `slice`
        // taas oo uu dhergiyey oo dhan shuruudaha `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // AMMAANKA: inay isku `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // BADBAADADA: hadda waa la hubiyey in `start` uu ku jiro soohdinta xadka,
            // waxaanna ku gudbeynaa tixraac aamin ah, sidaa darteed qiimaha soo noqoshada sidoo kale mid ayuu noqon doonaa.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Waxay hirgelisaa jarjaran jaranjarooyinka iyadoo loo adeegsanayo qaabeynta `&self[begin ..= end]` ama `&mut self[begin ..= end]`.
///
/// Sooceliyaa jeex ah string la siiyey kala duwan byte ku [`begin`, `end`].U dhiganta `&self [begin .. end + 1]` ama `&mut self[begin .. end + 1]`, ahayn haddii `end` uu qiimo ugu badan ee `usize` ah.
///
/// Hawlgalkani waa *O*(1).
///
/// # Panics
///
/// Panics haddii `begin` ma farta byte-upka mowjadda of dabeecad (sida lagu qeexay by `is_char_boundary`), haddii `end` ma dhibic si byte ku dhamaaday mowjadda of dabeecad (`end + 1` waa mid byte ah laga bilaabo mowjadda ama simanyihiin inay `len`), haddii `begin > end`, ama haddii `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Waxay hirgelisaa jarjaran jaranjarooyinka iyadoo loo adeegsanayo qaabeynta `&self[..= end]` ama `&mut self[..= end]`.
///
/// Sooceliyaa jeex ah string la siiyey kala duwan byte ku [0, `end`].
/// U dhiganta `&self [0 .. end + 1]`, ahayn haddii `end` uu qiimo ugu badan ee `usize` ah.
///
/// Hawlgalkani waa *O*(1).
///
/// # Panics
///
/// Panics hadii `end` uusan tilmaamaynin dhamaadka bajadka astaamo (`end + 1` waa mid bilaw ah oo biet ah sida lagu qeexay `is_char_boundary`, ama u dhigma `len`), ama hadii `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Ka qiimee xadhigga
///
/// `Habka [`from_str`] FromStr` ayaa waxaa inta badan si dadban loo isticmaalo, iyada oo [`str`] 's habka [`parse`].
/// Ka eeg dukumintiyada [`parse`] tusaalayaal.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ma laha dhimaya Meyeydaan, iyo si aad awoodo kaliya noocyada qladad in aadan ku jira ee Meyeydaan wax isu dhimaya.
///
/// In si kale loo dhigo, waxaad quburada kartaa `i32` la `FromStr`, laakiin ma `&i32` ah.
/// Waxaad quburada kartaa struct ah ay ku jiraan `i32` ah, laakiin ma aha mid ku jira `&i32` ah.
///
/// # Examples
///
/// fulinta aasaasiga ah ee `FromStr` on tusaale nooca `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Cilad la xiriirta oo laga soo celin karo baaritaanka.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parses string `s` si loo soo celiyo qiimaha noocan ah.
    ///
    /// Haddii parsing guuleysto, ku soo laabto qiimaha gudaha [`Ok`], haddii kale marka string waa soo laabtay xanuunsan-formatted gaar qalad in ay gudaha [`Err`].
    /// nooca qalad ay gaar u tahay hirgelinta trait ah.
    ///
    /// # Examples
    ///
    /// Isticmaalka aasaasiga ah ee leh [`i32`], oo ah nooc fuliya `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Ka baar `bool` xarig.
    ///
    /// Waxay keentaa `Result<bool, ParseBoolError>`, maxaa yeelay `s` ayaa laga yaabaa ama laga yaabaa inaan dhab ahaan la beddeli karin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Xusuusnow, xaalado badan, habka `.parse()` ee `str` ayaa ka habboon.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}