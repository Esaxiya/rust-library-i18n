//! Siyaabaha ay u abuuraan `str` ka cad bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Kuweeda jeex ah bytes si cad string ah.
///
/// Xadhig jeex ah ([`&str`]) waxaa laga sameeyaa bytes ([`u8`]), halka bate ([`&[u8]`][byteslice]) ah ayaa laga sameeyaa bytes, markaa shaqadani waxay isu beddeleysaa labada.
/// Dhammaan balastar gacmeedku ma aha xaleef xargo ansax ah, hase yeeshe: [`&str`] wuxuu u baahan yahay inuu sax yahay UTF-8.
/// `from_utf8()` jeegaga si loo hubiyo in bytes waa ansax UTF-8, ka dibna sameeya qaab beddelidda.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Haddii aad hubto in jeex-jeexku ansax yahay UTF-8, oo aadan rabin inaad soo gasho dusha sare ee baaritaanka ansaxnimada, waxaa jira nooc aan badbaado lahayn oo shaqadan ah, [`from_utf8_unchecked`], oo leh dhaqan isku mid ah laakiin jeegga iska dhaafaya.
///
///
/// Haddii aad u baahan tahay `String` halkii aad ka heli lahayd `&str`, tixgeli [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Sababtoo ah waad isdhibi kartaa-qoondeyn kartaa `[u8; N]`, waadna ka qaadan kartaa [`&[u8]`][byteslice], howshani waa hal dariiqo oo lagu helo xargo loo qoondeeyey xirmo.Waxaa tusaale u ah tan qaybta tusaalooyinka hoos ku qoran.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Sooceliyaa `Err` haddii jeex ma aha UTF-8 leh sharaxaad ah oo sabab u cad la siiyo ma aha UTF-8.
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::str;
///
/// // bytes qaar, vector ah
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Waan ognahay in baaydhaan ay ansax yihiin, markaa isticmaal kaliya `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bytes qaldan
///
/// ```
/// use std::str;
///
/// // xoogaa bytes aan ansax ahayn, oo ku jira vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Eeg DoCS ee [`Utf8Error`] wixii faahfaahin dheeraad ah oo ku saabsan noocyada kala duwan ee qalad in loo soo celin karaa.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // bytes qaar ka mid ah, oo ku jira qaab isu-geddisan
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Waan ognahay in baaydhaan ay ansax yihiin, markaa isticmaal kaliya `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // AMMAANKA: Just orday ansixinta.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Kuweeda jeex ah mutable of bytes in jeex ah string mutable.
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" sida vector oo la beddeli karo
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Sidaan ognahay baayisyadan inay ansax yihiin, waxaan isticmaali karnaa `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bytes qaldan
///
/// ```
/// use std::str;
///
/// // Qaar ka mid ah bayta aan ansax ahayn oo ku yaal vector oo la beddeli karo
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Eeg DoCS ee [`Utf8Error`] wixii faahfaahin dheeraad ah oo ku saabsan noocyada kala duwan ee qalad in loo soo celin karaa.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // AMMAANKA: Just orday ansixinta.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Kuweeda jeex ah bytes si cad string oo aan hubin in xarig ah ku jira oo sax ah UTF-8.
///
/// Eeg nooca nabdoon, [`from_utf8`], wixii macluumaad dheeraad ah.
///
/// # Safety
///
/// Shaqadani waa mid aan amaan aheyn maxaa yeelay ma hubineyso in baaytka loo gudbiyey ay sax yihiin UTF-8.
/// Haddii xaddidan la jebiyo, natiijooyinka habdhaqanka aan la qeexin, maadaama inta kale ee Rust ay u maleyneyso in ``&str '' ay ansax yihiin UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::str;
///
/// // bytes qaar, vector ah
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // BADBAADADA: Wicitaanku waa inuu damaanad qaadaa in baaytka `v` ay ansax yihiin UTF-8.
    // Sidoo kale ku tiirsan `&str` iyo `&[u8]` isagoo khariidad la mid ah.
    unsafe { mem::transmute(v) }
}

/// Kuweeda jeex ah bytes si cad string oo aan hubin in xarig ah ku jira oo sax ah UTF-8;nooca isbeddelka
///
///
/// Eeg nooca aan beddelmi karin, [`from_utf8_unchecked()`] wixii macluumaad dheeraad ah.
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // AMMAANKA: dammaanadda waa wacay in bytes `v`
    // waa ansax yihiin UTF-8, sidaas awgeed dadka loo tuuray `*mut str` waa aamin.
    // Sidoo kale, dereference tilmaamaha waa amaan waayo tilmaamaha ka timaada tixraac, taas oo waa la hubaa in ay ansax qoray.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}