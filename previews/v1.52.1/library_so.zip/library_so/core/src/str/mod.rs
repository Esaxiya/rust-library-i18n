//! Khalkhalgelinta xarigga.
//!
//! Faahfaahin dheeraad ah, ka eeg qaybta [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. xadka ka baxsan
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. bilaabaan <=dhamaadka
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. soohdinta qof
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // heli dabeecadda
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` waa inuu ka yaryahay amaah iyo xadka char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Sooceliyaa dhererka `self`.
    ///
    /// dhererka Tani waa in bytes, ma [`char`] s ama graphemes.
    /// Si kale haddii loo dhigo, ma noqon karto waxa bini aadamku tixgeliyo dhererka xadhigga.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // f fanaaniinta cusub!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Sooceliyaa `true` haddii `self` uu leeyahay dherer eber ah
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Wuxuu hubiyaa in 'index`-th byte' uu yahay baaytkii ugu horreeyay ee isku xigxigta barta lambarka UTF-8 ama dhammaadka xarigga.
    ///
    ///
    /// The bilowga iyo dhammaadka xarig ah (marka `index== self.len()`) arkaa in ay yihiin xuduudaha.
    ///
    /// Sooceliyaa `false` haddii `index` ka weyn yahay `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // bilaabaan of `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // baytkii labaad ee `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // saddexaad byte oo ah `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 iyo Len mar walba waa ok.
        // Tijaabi 0 si cad si ay u wanaajin karto jeegga si fudud una dhaafto akhrinta xogta xarigga ee kiiskaas.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Kani waa sixir qayb u dhiganta: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Waxay u beddeleysaa jeex xarig ah baay.
    /// Si aad ugu beddesho jeexjeexa bateetka jeex jeexan, adeegso shaqada [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // BADBAADADA: dhawaaqa maxaa yeelay waxaan ku beddeleynaa laba nooc oo isku qaab ah
        unsafe { mem::transmute(self) }
    }

    /// Waxay u rogtaa jeex jeexan xarig isku beddeli kara
    ///
    /// # Safety
    ///
    /// Wicitaanku waa inuu hubiyaa in waxa ku qoran jeexku uu ansax yahay UTF-8 ka hor inta amaahdu dhammaan iyo `str` gundhig loo adeegsado.
    ///
    ///
    /// Isticmaalka `str` oo waxyaabaha ku jira aysan ansax ahayn UTF-8 waa dhaqan aan la qeexin.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // BADBAADADA: Jilayaasha laga bilaabo `&str` ilaa `&[u8]` waa aamin tan iyo `str`
        // wuxuu leeyahay qaab isku mid ah sida `&[u8]` (kaliya libstd ayaa dammaanad qaadi kara).
        // dereference pointer waa amaan tan iyo markii ay timaado ka tixraac mutable oo waa la hubaa in ay ansax qoray.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Kuweeda jeex string in tilmaamaha a ceeriin ah.
    ///
    /// Sida string xaleef waa jeex ah bytes, qodobada pointer ceeriin in [`u8`] ah.
    /// pointer Tan waxaa lagu tilmaamay doonaa in byte koowaad ee cad xarig ah.
    ///
    /// wacaha waa in ay hubisaa in tilmaamaha soo laabtay marna qoraal ah.
    /// Haddii aad u baahan tahay inaad beddelo waxa ku jira jeex jeex, isticmaal [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Kuweeda jeex ah string mutable in tilmaamaha a ceeriin.
    ///
    /// Sida string xaleef waa jeex ah bytes, qodobada pointer ceeriin in [`u8`] ah.
    /// pointer Tan waxaa lagu tilmaamay doonaa in byte koowaad ee cad xarig ah.
    ///
    /// Waa masuuliyadaada in la hubiyo in jeex string kaliya uu dib u habaynta hab in weli aan dhicin UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Soocelinaya qeyb kamid ah `str`.
    ///
    /// Kani waa beddelka aan cabsida lahayn ee tilmaamaya `str`.
    /// Dib [`None`] mar kasta oo howlgal tusmaynta u dhigma lahaa panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indices ma ku saabsan xudduudaha isku xigxiga UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // xadka ka baxsan
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Wuxuu soo celiyaa qayb yar oo la beddeli karo oo ah `str`.
    ///
    /// Kani waa beddelka aan cabsida lahayn ee tilmaamaya `str`.
    /// Dib [`None`] mar kasta oo howlgal tusmaynta u dhigma lahaa panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // dhererka saxda ah
    /// assert!(v.get_mut(0..5).is_some());
    /// // xadka ka baxsan
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Sooceliyaa qayb yar oo aan la hubin oo ah `str`.
    ///
    /// Tani waa beddelka aan la hubin ee tilmaamaya `str`.
    ///
    /// # Safety
    ///
    /// Soo wacaya ee shaqada this ayaa ka mas'uul ah in shuruud kuwaas oo ku qanacsanayn:
    ///
    /// * index-upka waa in aan ka badnayn index ku dhamaaday;
    /// * Tusayaashu waa inay ku ekaadaan xadka cutubka asalka ah;
    /// * Tusayaashu waa inay ku jiifsadaan xuduudaha UTF-8.
    ///
    /// Guuldareysteen in, ka jeex string laabtay tixraaca laga yaabaa xasuusta sax ahayn ama xad invariants ku gaadhsiiyo nooca `str` ah.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // AMMAANKA: wacaha waa in ay ilaaliyaan heshiiska ammaanka `get_unchecked` ah;
        // jeex waa la diidi karaa sababtoo ah `self` waa tixraac aamin ah.
        // Tilmaame-celinta la soo celiyey waa ammaan maxaa yeelay soo-jeedimaha `SliceIndex` waa inay dammaanad-qaadaan inay tahay.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Sooceliyaa mutable, subslice a qaban of `str`.
    ///
    /// Tani waa beddelka aan la hubin ee tilmaamaya `str`.
    ///
    /// # Safety
    ///
    /// Soo wacaya ee shaqada this ayaa ka mas'uul ah in shuruud kuwaas oo ku qanacsanayn:
    ///
    /// * index-upka waa in aan ka badnayn index ku dhamaaday;
    /// * Tusayaashu waa inay ku ekaadaan xadka cutubka asalka ah;
    /// * Tusayaashu waa inay ku jiifsadaan xuduudaha UTF-8.
    ///
    /// Guuldareysteen in, ka jeex string laabtay tixraaca laga yaabaa xasuusta sax ahayn ama xad invariants ku gaadhsiiyo nooca `str` ah.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `get_unchecked_mut`;
        // jeex waa la diidi karaa sababtoo ah `self` waa tixraac aamin ah.
        // Tilmaame-celinta la soo celiyey waa ammaan maxaa yeelay soo-jeedimaha `SliceIndex` waa inay dammaanad-qaadaan inay tahay.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Abuuraa jeex string ka jeex kale string, Goldogob hubinta ammaanka.
    ///
    /// Tani guud ahaan laguma talinayo, u isticmaal taxaddar!Beddelka bedqabka ah arag [`str`] iyo [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Qaybtan cusub waxay ka socotaa `begin` illaa `end`, oo ay ku jiraan `begin` laakiin marka laga reebo `end`.
    ///
    /// Si aad u hesho jeex jeexan xarig beddelkiisa, eeg habka [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Soo wacaya ee shaqada this ayaa ka mas'uul ah in saddex shuruud ku qanacsanayn:
    ///
    /// * `begin` waa inuusan ka badnaan `end`.
    /// * `begin` iyo `end` waa inay ahaadaan boosas baaytka dhexdiisa.
    /// * `begin` iyo `end` waa been ka on xuduudaha xigxiga UTF-8.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // AMMAANKA: wacaha waa in ay ilaaliyaan heshiiska ammaanka `get_unchecked` ah;
        // jeex waa la diidi karaa sababtoo ah `self` waa tixraac aamin ah.
        // Tilmaame-celinta la soo celiyey waa ammaan maxaa yeelay soo-jeedimaha `SliceIndex` waa inay dammaanad-qaadaan inay tahay.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Abuuraa jeex string ka jeex kale string, Goldogob hubinta ammaanka.
    /// Tani guud ahaan laguma talinayo, u isticmaal taxaddar!Wixii kale oo ammaan ah arki [`str`] iyo [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Qaybtan cusub waxay ka socotaa `begin` illaa `end`, oo ay ku jiraan `begin` laakiin marka laga reebo `end`.
    ///
    /// Si aad u hesho ah jeex string aan beddelmi karin halkii, arki hab [`slice_unchecked`] ah.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Soo wacaya ee shaqada this ayaa ka mas'uul ah in saddex shuruud ku qanacsanayn:
    ///
    /// * `begin` waa inuusan ka badnaan `end`.
    /// * `begin` iyo `end` waa inay ahaadaan boosas baaytka dhexdiisa.
    /// * `begin` iyo `end` waa been ka on xuduudaha xigxiga UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `get_unchecked_mut`;
        // jeex waa la diidi karaa sababtoo ah `self` waa tixraac aamin ah.
        // Tilmaame-celinta la soo celiyey waa ammaan maxaa yeelay soo-jeedimaha `SliceIndex` waa inay dammaanad-qaadaan inay tahay.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// U qaybi ka mid jeex string laba at index ah.
    ///
    /// Doodda, `mid`, waa inay ahaataa mid laga dheelitiro bilowga xarigga.
    /// Sidoo kale waa inay ahaataa soohdinta barta code ee UTF-8.
    ///
    /// Labada xaleef laga bilaabo jeex string in `mid` ku soo laabtay go, oo ka `mid` dhammaadka jeex xarig ah.
    ///
    /// Si aad u hesho xaleef string mutable halkii, arki hab [`split_at_mut`] ah.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics haddii `mid` uusan kujirin xadka xadka lambarka UTF-8, ama haddii uu dhaafay dhammaadka barta ugu dambeysa ee qodobka xariga.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // Hubinta_xad-dhaafka ah in jaantusku ku jiro [0, .len()]
        if self.is_char_boundary(mid) {
            // BADBAADADA: hadda waa la hubiyey in `mid` uu ku jiro soohdinta xadka.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// U kala qaybi hal jeex jeexan oo is bedbeddelaya laba tixraac.
    ///
    /// Doodda, `mid`, waa inay ahaataa mid laga dheelitiro bilowga xarigga.
    /// Sidoo kale waa inay ahaataa soohdinta barta code ee UTF-8.
    ///
    /// Labada xaleef laga bilaabo jeex string in `mid` ku soo laabtay go, oo ka `mid` dhammaadka jeex xarig ah.
    ///
    /// Si aad u hesho jeexjeexyada xargaha ee aan beddelmi karin, eeg habka [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics haddii `mid` uusan kujirin xadka xadka lambarka UTF-8, ama haddii uu dhaafay dhammaadka barta ugu dambeysa ee qodobka xariga.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // Hubinta_xad-dhaafka ah in jaantusku ku jiro [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // BADBAADADA: hadda waa la hubiyey in `mid` uu ku jiro soohdinta xadka.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Ku celceliya soo-celiyaha dul 'jeex' xarig ah.
    ///
    /// Maadaama jeex jeexku ka kooban yahay UTF-8 ansax ah, waxaan dhex dhexaadin karnaa jeex jeexan oo ah [`char`].
    /// Habkani wuxuu soo celiyaa sida soo-celinta.
    ///
    /// Waxaa muhiim ah in la xasuusto in [`char`] uu matalayo Unicode Scalar Value, lagana yaabo inuusan u dhigmin fikirkaaga waxa uu yahay 'character'.
    ///
    /// Cuncun fara badan oo ka mid ah kooxaha grapheme ayaa noqon kara waxaad dhab ahaan rabto.
    /// shaqeynta Tani ma aha bixiya maktabadda Heerka Rust ee, hubi crates.io halkii.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Xusuusnow, [`` char ''] ayaa laga yaabaa inaysan u dhigmin caqligaaga ku saabsan jilayaasha:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ma ahan 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Ku soo celiyaa soo-celiyaha dul-jeex jeex jeexan xargaha, iyo meelahooda.
    ///
    /// Maadaama jeex jeexku ka kooban yahay UTF-8 ansax ah, waxaan dhex dhexaadin karnaa jeex jeexan oo ah [`char`].
    /// Qaabkani wuxuu soo celinayaa soo-celiyaha labadan 'shay' labadaba, iyo sidoo kale boosaska ay ka soo jeedaan.
    ///
    /// Tilmaamuhu wuxuu soo saaraa tufaax.Mawqifku waa kan koowaad, [`char`] waa kan labaad.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Xusuusnow, [`` char ''] ayaa laga yaabaa inaysan u dhigmin caqligaaga ku saabsan jilayaasha:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // maahan (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // 3 ka ogow halkaan, dabeecadii ugu dambeysay waxay qaadatay labo baayt
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Kucelceliyaha bajaajka jeex jeexan.
    ///
    /// Sida cad string ah waxay ka kooban tahay isku xigxiga oo ka mid ah bytes, waxaan iterate karaa jeex string by byte ah.
    /// Habkani wuxuu soo celiyaa sida soo-celinta.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Jajabiyaa jeex string by whitespace ah.
    ///
    /// Sooceliyaha soo celiyey wuxuu soo celin doonaa xaleefyada xargaha oo ah jajabyo yar yar oo jeex ah xarig asalka ah, oo lagu kala saaray qadar kasta oo hareeraha.
    ///
    ///
    /// 'Whitespace' waxaa lagu qeexaa iyadoo la raacayo shuruudaha Unicode laga soosaaray Dhisme Muhiim ah `White_Space`.
    /// Haddii aad kaliya rabto inaad ku kala qaybsanaato goobta cad ee ASCII, isticmaal [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Dhammaan noocyada kala duwan ee goobta bannaan ayaa loo tixgeliyaa:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Jajabiyaa jeex string by whitespace ASCII ah.
    ///
    /// Sooceliyaha soo celiyey wuxuu soo celin doonaa jeexjeexyada xargaha oo ah qaybo yaryar oo jeexjeex ah asalka asalka ah, oo lagu kala soocay qadar kasta oo ka mid ah caddadka ASCII.
    ///
    ///
    /// Si aad ugu kala jarto Unicode `Whitespace` bedelkeeda, isticmaal [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Dhammaan noocyada kala duwan ee goobta bannaan ee ASCII waxaa loo tixgeliyaa:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Falanqeeye kahadlaya xadhkaha xadhkaha, sida xargaha xargaha.
    ///
    /// Lines way dhammaadeen la mid newline a (`\n`) ama soo laabtay qaadee la feed line a (`\r\n`) ah.
    ///
    /// Dhamaadka khadka ugu dambeeya waa ikhtiyaari.
    /// Xarig ku dhamaada xariiq dhamaadka dhamaadka ayaa soo celin doona isla xariiqyada xarig kale oo isku mid ah iyada oo aan laynin dhamaadka dhamaadka.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Khadka dhamaadka kama dambaysta ah looma baahna:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Falanqeeye kahadlaya xadhkaha xadhkaha.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Sooceliyaa iterator ah `u16` badan xadhigga encoded sida UTF-16.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Soocelinayaa `true` haddii qaabka la siiyay uu u dhigmo qayb-jeex jeexan xariggan.
    ///
    /// Sooceliyaa `false` haddii uusan.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Sooceliyaa `true` haddii qaabka lasiwayay uu lamid yahay horgalaha xariga xariga.
    ///
    /// Sooceliyaa `false` haddii uusan.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Soocelinayaa `true` haddii qaabku u dhigmo dhejiska jeexdan.
    ///
    /// Sooceliyaa `false` haddii uusan.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Soocelisaa tusmada byte ee astaamaha koowaad ee jeexdan xarigga ah ee u dhigma qaabka.
    ///
    /// Soocelinayaa [`None`] haddii qaabku uusan u dhigmin.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Qaabab fudud:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// kakanaan badan iyagoo isticmaalaya hab iyo xiritaanka dhibic-free:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Ma helin qaabka:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Sooceliyaa tusmada byte ee astaamaha uguhoreeya ee ciyaarta saxda ah ee qaabka kujira jeexan xariggan.
    ///
    /// Soocelinayaa [`None`] haddii qaabku uusan u dhigmin.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Qaabab fudud:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// kakanaan badan la xiritaanka:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Ma helin qaabka:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Falanqeeye ka hadlaya noocyada jeexan xariggan, oo loo kala saaray astaamo u dhigma qaab.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Dabeecadda hadalka
    ///
    /// Sooceliyaha soo celiyey wuxuu noqon doonaa [`DoubleEndedIterator`] haddii qaabku u oggolaado raadin gadaal ah iyo raadinta forward/reverse waxay soo saartaa isla cunsurradii.
    /// Tani waa run, tusaale ahaan, [`char`], laakiin maahan `&str`.
    ///
    /// Haddii qaabku u oggolaado raadinta gadaal laakiin natiijooyinkiisu way ka duwanaan karaan raadinta hore, habka [`rsplit`] waa la isticmaali karaa.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Qaabab fudud:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Haddii qaabku yahay jeex jeexjeexyo ah, ku kala qaybso dhacdo kasta oo ka mid ah astaamaha:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Naqshad aad u adag, oo la adeegsanayo xiritaan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Haddii xadhig uu ka kooban yahay kala-gooyeyaal isku xidhan oo kala duwan, waxaad ku dambayn doontaa xadhko madhan wax soo saarka:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Kala-saarayaasha isku-dhafan ayaa lagu kala soocayaa xarigga maran.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Separators bilowga ama dhammaadka xarig ah waa la deriska by xadhig madhan.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Marka xarig madhan waxaa loo isticmaalaa sida SEPARATOR ah, waxay kala qof kasta oo xarig ah, oo ay la socdaan bilowgii iyo dhammaadka xarig ah.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Kala soocayaasha isdaba jooga ah waxay u horseedi karaan dhaqan suurta gal ah oo la yaab leh marka loo isticmaalo goobta cad sida kala-sooca.Koodhkani waa sax:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Waxay ku siinaysaa _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// U isticmaal [`split_whitespace`] habdhaqankan.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Falanqeeye ka hadlaya noocyada jeexan xariggan, oo loo kala saaray astaamo u dhigma qaab.
    /// Waxay ku kala duwan yihiin qalabka wax soo saara ee ay soo saartay `split` ee ku jirta `split_inclusive` wuxuu ka tagayaa qaybta isku aaddan ee ah joojiyaha xargaha.
    ///
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Haddii qaybta ugu dambeysa ee xarigga ay iswaafajiso, cunsurkaas waxaa loo tixgelin doonaa inuu yahay joojiyaha xargaha hore.
    /// Subring-kaasi wuxuu noqonayaa sheyga ugu dambeeya ee sooceliyaha soo celiyo.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// iterator An badan substrings of jeex ah string siiyey, kala characters aadiyo by qaab oo ay midho dhaleen si cagsi ah.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Dabeecadda hadalka
    ///
    /// Ayaa ku soo laabtay iterator u baahan yahay in hannaanka taageertaa search a dambe, iyo waxa ay noqon doontaa [`DoubleEndedIterator`] haddii search forward/reverse ah lagu edbiyey u ah xubno ka mid ah.
    ///
    ///
    /// Ka shaqeynta xagga hore, habka [`split`] waa la isticmaali karaa.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Qaabab fudud:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Naqshad aad u adag, oo la adeegsanayo xiritaan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// iterator An badan substrings of jeex ah string siiyey, kala characters aadiyo by qaab.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// U dhiganta [`split`], ahayn in substring ka danbeysa waxaa u boodboodeen haddii madhan.
    ///
    /// [`split`]: str::split
    ///
    /// Qaabkan waxaa loo isticmaali karaa xogta xargaha ee ah _terminated_, halkii laga isticmaali lahaa _separated_ qaab ahaan.
    ///
    /// # Dabeecadda hadalka
    ///
    /// Sooceliyaha soo celiyey wuxuu noqon doonaa [`DoubleEndedIterator`] haddii qaabku u oggolaado raadin gadaal ah iyo raadinta forward/reverse waxay soo saartaa isla cunsurradii.
    /// Tani waa run, tusaale ahaan, [`char`], laakiin maahan `&str`.
    ///
    /// Haddii qaabku u oggolaado raadinta gadaal laakiin natiijooyinkiisu way ka duwanaan karaan raadinta hore, habka [`rsplit_terminator`] waa la isticmaali karaa.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// iterator An badan substrings of `self`, kala characters aadiyo by qaab oo ay midho dhaleen si cagsi ah.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// U dhiganta [`split`], ahayn in substring ka danbeysa waxaa u boodboodeen haddii madhan.
    ///
    /// [`split`]: str::split
    ///
    /// Qaabkan waxaa loo isticmaali karaa xogta xargaha ee ah _terminated_, halkii laga isticmaali lahaa _separated_ qaab ahaan.
    ///
    /// # Dabeecadda hadalka
    ///
    /// Ayaa ku soo laabtay iterator u baahan yahay in hannaanka taageertaa search a dambe, oo waxaa loo double dhamaaday doonaa haddii search forward/reverse ah lagu edbiyey u ah xubno ka mid ah.
    ///
    ///
    /// Waayo, iterating xagga hore, hab [`split_terminator`] waxaa loo isticmaali karaa.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Falanqeeye ka hadlaya noocyada kala duwan ee jeex jeex jeexan, oo lagu kala saaray qaab, lagu xaddiday soo noqoshada ugu badnaan waxyaabaha `n`.
    ///
    /// Haddii `n` xarigayaal la soo celiyo, silsiladda ugu dambeysa (``n`th substring '') ayaa ka koobnaan doonta inta hartay.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Dabeecadda hadalka
    ///
    /// Sooceliyaha soo laabtay labalaab lama dhamayn doono, maxaa yeelay waxtar ma leh in la taageero.
    ///
    /// Haddii qaabku u oggolaado raadinta gadaal, habka [`rsplitn`] waa la isticmaali karaa.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Qaabab fudud:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Naqshad aad u adag, oo la adeegsanayo xiritaan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Falanqeeye ka hadlaya noocyada jeexjeexyada xariggan, oo lagu kala saaray qaab, laga bilaabo dhammaadka xarigga, oo lagu xaddiday inuu ku soo noqdo ugu badnaan waxyaabaha `n`.
    ///
    ///
    /// Haddii `n` xarigayaal la soo celiyo, silsiladda ugu dambeysa (``n`th substring '') ayaa ka koobnaan doonta inta hartay.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Dabeecadda hadalka
    ///
    /// Sooceliyaha soo laabtay labalaab lama dhamayn doono, maxaa yeelay waxtar ma leh in la taageero.
    ///
    /// Kala-bixinta xagga hore, habka [`splitn`] waa la isticmaali karaa.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Qaabab fudud:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Naqshad aad u adag, oo la adeegsanayo xiritaan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Jajabiyaa string ku dhacdo koowaad ee delimiter ku qeexan iyo celinta hor delimiter iyo qadarin ah ka dib markii delimiter Horgalaha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Jajabiyaa xarig ah ku dhacdo ee la soo dhaafay delimiter ku qeexan iyo celinta hor delimiter iyo qadarin ah ka dib markii delimiter Horgalaha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// iterator An badan disjoint ka kulan ee qaab gudahood jeex ah string siiyey.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Dabeecadda hadalka
    ///
    /// Sooceliyaha soo celiyey wuxuu noqon doonaa [`DoubleEndedIterator`] haddii qaabku u oggolaado raadin gadaal ah iyo raadinta forward/reverse waxay soo saartaa isla cunsurradii.
    /// Tani waa run, tusaale ahaan, [`char`], laakiin maahan `&str`.
    ///
    /// Haddii hannaankii ogol search a dambe laakiin natiijada ay ka search hore ku kala duwan yihiin laga yaabo in, habka [`rmatches`] waxaa loo isticmaali karaa.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Falanqeeye ka hadlaya isku dheelitirnaan la'aanta qaab ka mid ah jeexdan xariggan, ayaa loo soo saaray si isdaba-joog ah.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Dabeecadda hadalka
    ///
    /// Ayaa ku soo laabtay iterator u baahan yahay in hannaanka taageertaa search a dambe, iyo waxa ay noqon doontaa [`DoubleEndedIterator`] haddii search forward/reverse ah lagu edbiyey u ah xubno ka mid ah.
    ///
    ///
    /// Ka shaqeynta xagga hore, habka [`matches`] waa la isticmaali karaa.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Falanqeeye ka hadlaya isku dheelitirnaan la'aanta qaab ka mid ah xariggan xariggan iyo sidoo kale tusmada uu ciyaarta ka bilaabmayo.
    ///
    /// Waayo, kulan ee `pat` gudahood `self` in daboolaa, kaliya indices u dhiganta kulanka ugu horeeya la soo celiyo.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Dabeecadda hadalka
    ///
    /// Sooceliyaha soo celiyey wuxuu noqon doonaa [`DoubleEndedIterator`] haddii qaabku u oggolaado raadin gadaal ah iyo raadinta forward/reverse waxay soo saartaa isla cunsurradii.
    /// Tani waa run, tusaale ahaan, [`char`], laakiin maahan `&str`.
    ///
    /// Haddii hannaankii ogol search a dambe laakiin natiijada ay ka search hore ku kala duwan yihiin laga yaabo in, habka [`rmatch_indices`] waxaa loo isticmaali karaa.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // kaliya `aba` koowaad
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Falanqeeye ka hadlaya isku dheelitirnaanta isku dheelitirka ee qaabka gudaha `self`, ayaa loo soo saaray si isdaba-joog ah oo ay weheliso tusmada ciyaarta.
    ///
    /// Waayo, kulan ee `pat` gudahood `self` in daboolaa, kaliya indices u dhiganta kulan ee la soo dhaafay waxaa ku soo laabtay.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Dabeecadda hadalka
    ///
    /// Ayaa ku soo laabtay iterator u baahan yahay in hannaanka taageertaa search a dambe, iyo waxa ay noqon doontaa [`DoubleEndedIterator`] haddii search forward/reverse ah lagu edbiyey u ah xubno ka mid ah.
    ///
    ///
    /// Ka shaqeynta xagga hore, habka [`match_indices`] waa la isticmaali karaa.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // kaliya `aba` ugu dambeeya
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Dib jeex string la sare iyo ka danbeysa whitespace saaro a.
    ///
    /// 'Whitespace' waxaa lagu qeexaa iyadoo la raacayo shuruudaha Unicode laga soosaaray Dhisme Muhiim ah `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Soo celisaa gabal xadhig leh meesha cad ee horseedka laga saaray.
    ///
    /// 'Whitespace' waxaa lagu qeexaa iyadoo la raacayo shuruudaha Unicode laga soosaaray Dhisme Muhiim ah `White_Space`.
    ///
    /// # jihooyinka text
    ///
    /// Xarig waa taxane ah baaytyo.
    /// `start` macnaha halkan ka dhigan tahay booska koowaad ee byte string in;waayo, luqad bidix-midig sida Ingiriisi ama Ruush, tani waxay noqon doontaa dhinacaaga bidix, iyo luqadaha tagay xaq-to-sida Carabi ama Hebrew, tani waxay noqon doontaa dhinaca midig.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Sooceliyaa jeex xarig ah oo lagaarey meesha cad ee lasaaray.
    ///
    /// 'Whitespace' waxaa lagu qeexaa iyadoo la raacayo shuruudaha Unicode laga soosaaray Dhisme Muhiim ah `White_Space`.
    ///
    /// # jihooyinka text
    ///
    /// Xarig waa taxane ah baaytyo.
    /// `end` macnaha halkan ku jira macnaheedu waa booska ugu dambeeya ee xarigga baaytkaas;waayo, luqad bidix-midig sida Ingiriisi ama Ruush, tani waxay noqon doontaa dhinacaaga midig, iyo luqadaha tagay xaq-to-sida Carabi ama Hebrew, tani waxay noqon doontaa dhanka bidix.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Soo celisaa gabal xadhig leh meesha cad ee horseedka laga saaray.
    ///
    /// 'Whitespace' waxaa lagu qeexaa iyadoo la raacayo shuruudaha Unicode laga soosaaray Dhisme Muhiim ah `White_Space`.
    ///
    /// # jihooyinka text
    ///
    /// Xarig waa taxane ah baaytyo.
    /// 'Left' macnaha halkan ku jira macnihiisu waa booska koowaad ee xarigga baaytkaas;luqad sida Carabiga ama Cibraaniga ah 'midigta bidix' halkii 'bidix ilaa midig', tani waxay noqon doontaa dhinaca _right_, ee ma noqon doono bidix.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Sooceliyaa jeex xarig ah oo lagaarey meesha cad ee lasaaray.
    ///
    /// 'Whitespace' waxaa lagu qeexaa iyadoo la raacayo shuruudaha Unicode laga soosaaray Dhisme Muhiim ah `White_Space`.
    ///
    /// # jihooyinka text
    ///
    /// Xarig waa taxane ah baaytyo.
    /// 'Right' macnaha halkan ku jira macnaheedu waa booska ugu dambeeya ee xarigga baaytkaas;luqad sida Carabiga ama Cibraaniga oo kale ah 'midigta bidix' halkii 'bidix ilaa midig', tani waxay noqon doontaa dhinaca _left_, ee maahan midig.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Ku soo celiyaa jeex xarig ah dhammaan horgalaha iyo ku dhejiska u dhigma hannaankii marar badan la saaray.
    ///
    /// [pattern] wuxuu noqon karaa [`char`] ah, jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Qaabab fudud:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Naqshad aad u adag, oo la adeegsanayo xiritaan:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Xusuusta kulanka la garanayo ee ugu horreeya, waxaa la saxo hoose haddii
            // ciyaartii ugu dambeysay way ka duwan tahay
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // BADBAADADA: `Searcher` waxaa lagu yaqaan inay soo celiso indices sax ah.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Sooceliyaa jeex xarig ah oo leh horgaleyaal dhan oo u dhigma qaab marar badan la saaray.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # jihooyinka text
    ///
    /// Xarig waa taxane ah baaytyo.
    /// `start` macnaha halkan ka dhigan tahay booska koowaad ee byte string in;waayo, luqad bidix-midig sida Ingiriisi ama Ruush, tani waxay noqon doontaa dhinacaaga bidix, iyo luqadaha tagay xaq-to-sida Carabi ama Hebrew, tani waxay noqon doontaa dhinaca midig.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // BADBAADADA: `Searcher` waxaa lagu yaqaan inay soo celiso indices sax ah.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Soo celiyaa jeex xarig ah iyadoo horgalaha la saaray.
    ///
    /// Haddii string bilaabo qaabka la `prefix` ah, soo laabtay ka dib markii substring horgalaha, ku duudduubtay oo `Some`.
    /// Si ka duwan `trim_start_matches`, qaabkani wuxuu ka saaraa horgalaha si sax ah hal jeer.
    ///
    /// Haddii xariggu uusan ka bilaaban `prefix`, wuxuu soo celinayaa `None`.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Sooceliyaa jeex string la socdo daba-galaha saaro a.
    ///
    /// Haddii xariggu ku dhammaado qaabka `suffix`, wuxuu soo celinayaa xarigga ka hor xarafka, ku duuban `Some`.
    /// Si ka duwan `trim_end_matches`, qaabkani wuxuu ka saaraa habeynta si sax ah hal mar.
    ///
    /// Haddii uusan xarig ah ku dhammaadaan `suffix` ma, soo laabtay `None`.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Ku soo celiyaa jeex xarig ah dhammaan sifooyinka oo u dhigma qaab si isdaba joog ah looga saaray.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # jihooyinka text
    ///
    /// Xarig waa taxane ah baaytyo.
    /// `end` macnaha halkan ku jira macnaheedu waa booska ugu dambeeya ee xarigga baaytkaas;waayo, luqad bidix-midig sida Ingiriisi ama Ruush, tani waxay noqon doontaa dhinacaaga midig, iyo luqadaha tagay xaq-to-sida Carabi ama Hebrew, tani waxay noqon doontaa dhanka bidix.
    ///
    ///
    /// # Examples
    ///
    /// Qaabab fudud:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Naqshad aad u adag, oo la adeegsanayo xiritaan:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // BADBAADADA: `Searcher` waxaa lagu yaqaan inay soo celiso indices sax ah.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Sooceliyaa jeex xarig ah oo leh horgaleyaal dhan oo u dhigma qaab marar badan la saaray.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # jihooyinka text
    ///
    /// Xarig waa taxane ah baaytyo.
    /// 'Left' macnaha halkan ku jira macnihiisu waa booska koowaad ee xarigga baaytkaas;luqad sida Carabiga ama Cibraaniga ah 'midigta bidix' halkii 'bidix ilaa midig', tani waxay noqon doontaa dhinaca _right_, ee ma noqon doono bidix.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Ku soo celiyaa jeex xarig ah dhammaan sifooyinka oo u dhigma qaab si isdaba joog ah looga saaray.
    ///
    /// [pattern] waxay noqon kartaa a `&str`, [`char`], jeex ah [`char`] s, ama shaqo ama la xiro in ay go'aamiso haddii kulan dabeecad.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # jihooyinka text
    ///
    /// Xarig waa taxane ah baaytyo.
    /// 'Right' macnaha halkan ku jira macnaheedu waa booska ugu dambeeya ee xarigga baaytkaas;luqad sida Carabiga ama Cibraaniga oo kale ah 'midigta bidix' halkii 'bidix ilaa midig', tani waxay noqon doontaa dhinaca _left_, ee maahan midig.
    ///
    ///
    /// # Examples
    ///
    /// Qaabab fudud:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Naqshad aad u adag, oo la adeegsanayo xiritaan:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses jeex string this galay nooc kale.
    ///
    /// Sababtoo ah `parse` waa mid guud, waxay sababi kartaa dhibaatooyin laxiriira nooca.
    /// Sida oo kale, `parse` waa mid ka mid ah wakhtiyada dhowr ah oo aad arki doonaa Saan u yaqaaneen 'turbofish' ah: `::<>`.
    ///
    /// Tani waxay ka caawineysaa fikradaha algorithm inay fahmaan gaar ahaan nooca aad isku dayeyso inaad ku dhex gasho.
    ///
    /// `parse` quburada karaa nooc kasta oo fulisaa trait [`FromStr`] ah.
    ///

    /// # Errors
    ///
    /// Soo celin doonaa [`Err`] haddii aysan suurtagal ahayn in lagu jajabiyo jeex jeexan nooca la doonayo.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Isticmaalka 'turbofish' halkii annotating `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Ka gaabin
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Checks haddii dhan jilayaasha string this kuwa gudaha ku kala duwan ASCII ah.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Waxaan ula dhaqmi karnaa byte kasta dabeecad ahaan halkaan: dhamaan astaamaha multibyte waxay kubilaabmayaan byte aan kujirin qaybaha kaladuwan, sidaa darteed halkaas ayaan horey ugu sii joogi doonaa.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Hubinta in laba xarig ay yihiin isku dheelitir la'aanta kiiska ASCII.
    ///
    /// La mid ah `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, laakiin iyadoon loo qoondayn oo la koobiyeyn kulaylka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Waxay xariggan u beddeleysaa kiiskeeda sare ee ASCII ee u dhigma meesha.
    ///
    /// Waraaqaha ASCII 'a' ilaa 'z' waxaa lagu sawiray 'A' ilaa 'Z', laakiin waraaqaha aan ahayn ASCII isma beddelin.
    ///
    /// Si aad u soo ceshato qiimo cusub oo kore ah adigoon wax ka badalin midka jira, isticmaal [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // BADBAADADA: waa ammaan maxaa yeelay waxaan ku beddeleynaa laba nooc oo isku qaab ah.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Kuweeda string si ay ASCII kiiska hoose oo u dhiganta in-meel.
    ///
    /// warqado ASCII 'A' in 'Z' waxaa baa'bin in 'a' in 'z', laakiin waraaqaha non-ASCII waa iska beddelin.
    ///
    /// Si aad u soo laaban a qiimaha cusub lowercased aan bedelayaan ka mid ah ee hadda jira, isticmaali [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // BADBAADADA: waa ammaan maxaa yeelay waxaan ku beddeleynaa laba nooc oo isku qaab ah.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Ku noqo iterator in Badbaaday char kasta `self` la [`char::escape_debug`].
    ///
    ///
    /// Note: kordhin kaliya codepoints grapheme in ay bilaabaan string la baxsaday doonaa.
    ///
    /// # Examples
    ///
    /// Hadal ahaan:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Si toos ah u adeegsiga `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Labaduba waxay u dhigmaan:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Adeegsiga `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// U soo celi jalaqle ka baxsanaya shax kasta `self` iyo [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Hadal ahaan:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Si toos ah u adeegsiga `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Labaduba waxay u dhigmaan:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Adeegsiga `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// U soo celi jalaqle ka baxsanaya shax kasta `self` iyo [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Hadal ahaan:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Si toos ah u adeegsiga `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Labaduba waxay u dhigmaan:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Adeegsiga `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Waxay abuurtaa str madhan
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Waxay abuurtaa ster
    #[inline]
    fn default() -> Self {
        // AMMAANKA: Xariga maran wuxuu ansax yahay UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Nooc magac leh, nooc fn ah
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // BADBAADADA: ma ahan ammaan
        unsafe { from_utf8_unchecked(bytes) }
    };
}