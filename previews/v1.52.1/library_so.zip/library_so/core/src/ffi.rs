#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Adeegyada laxiriira isdhexgalka howlaha shisheeye ee (FFI).

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// U dhiganta nooca C ee `void` marka loo isticmaalo sidii [pointer].
///
/// In jiritaan, `*const c_void` u dhiganta C ee `const void*` iyo `*mut c_void` u dhiganta C ee `void*`.
/// Taas oo uu sheegay, this *ma aha* la mid ah sida C ee `void` nooca laabto, taas oo Rust ee nooca `()`.
///
/// Si loo tusaaleeyo tilmaamayaasha noocyada madmadowga ah ee FFI, illaa `extern type` laga xasilinayo, waxaa lagugula talinayaa inaad u isticmaasho duub newtype hareeraha goob bateed madhan.
///
/// Ka eeg [Nomicon] wixii faahfaahin ah.
///
/// Mid ka mid ah isticmaali kartaa `std::os::raw::c_void` haddii ay doonayaan in ay taageeraan jir Rust hoos compiler in 1.1.0.
/// Rust 1.30.0 kadib, waxaa dib loogu dhoofiyay qeexitaankan.
/// Wixii macluumaad dheeraad ah, fadlan akhri [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// FG, LLVM si loo aqoonsado nooca tilmaanta maran iyo sida loo kordhiyo shaqooyinka sida malloc(), waxaan u baahanahay inaan u taagno sidii i8 * ee LLVM bitcode.
// enum halkan loo isticmaalo ay hubisaa in this iyo horjoogsadaa si xun loo isticmaalo nooca "raw" ah adigoo keliya kala duwanaansho gaar ah.
// Waxaan u baahan nahay laba kala duwanaansho, maxaa yeelay, compiler ka cabanaya oo ku saabsan sifo repr haddii kale iyo waxaan u baahan nahay ugu yaraan hal duwanaansho kale enum la Anfaco lahaa iyo ugu yaraan dereferencing tilmaamo sida uu noqon doono UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// fulinta aasaasiga ah ee `va_list` ah.
// Magaca waa WIP, adoo adeegsanaya `VaListImpl` hadda.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Kala duwanaan ka badan `'f`, marka shay kasta oo `VaListImpl<'f>` ah wuxuu ku xiran yahay gobolka shaqada lagu qeexay
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI hirgelinta `va_list`.
/// Eeg [AArch64 Procedure Call Standard] wixii faahfaahin dheeraad ah.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI hirgelinta `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI hirgelinta `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Duub loogu talagalay `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// U beddelo `VaListImpl` `VaList` kaas oo ah mid laba-geesood ah oo la jaan qaada C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// U beddelo `VaListImpl` `VaList` kaas oo ah mid laba-geesood ah oo la jaan qaada C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait waxay ubaahantahay in loo adeegsado isdhexgalka bulshada, si kastaba ha noqotee, trait lafteeda waa in aan loo ogolaan in loo isticmaalo banaanka qaabkan.
// U oggolaanshaha isticmaaleyaasha inay hirgeliyaan trait nooc cusub (oo markaa u oggolaanaya va_arg asalka ah in loo isticmaalo nooc cusub) waxay u badan tahay inay keento dabeecad aan la qeexin.
//
// FIXME(dlrobertson): Si loogu isticmaalo VaArgSafe trait dhex-dhexaadka dadweynaha laakiin sidoo kale la hubiyo inaan lagu isticmaali karin meelo kale, trait waxay u baahan tahay inay ahaato mid dadweynaha ku dhex jira qayb gaar ah.
// Marka RFC 2145 ayaa la hirgeliyey eegno galay hagaajinta this.
//
//
//
//
mod sealed_trait {
    /// Trait kaas oo u oggolaanaya noocyada la oggol yahay in lagu isticmaalo [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Horay u sii wad arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Nuqulada `va_list` ee meesha hada.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // AMMAANKA: wacaha waa in ay ilaaliyaan heshiiska ammaanka `va_end` ah.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // AMMAANKA: waxaan u qor `MaybeUninit` ah, sidaas waxaa initialized iyo `assume_init` waa sharci
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: this waa inay wacaan `va_end`, laakiin waxaa jira hab nadiif ah u lahayn in ay
        // damaanad in `drop` had iyo jeer uu inlined galay ay soo wacay, si `va_end` ee aad si toos ah uga shaqo la mid ah sida `va_copy` dhiganta yeedhay lahaa.
        // `man va_end` waxay sheegaysaa in C ay tan u baahan tahay, LLVM-na asal ahaan wuxuu raacayaa C semantics-ka, markaa waxaan u baahanahay inaan hubinno in `va_end` marwalba looga yeero isla shaqada `va_copy`.
        //
        // Faahfaahin dheeraad ah, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Tani waxay ka shaqeeya hadda, tan iyo `va_end` waa no-op oo dhan diirada u LLVM hadda.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Dumiya `ap` ku arglist ka dib markii initialization la `va_start` ama `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Nuqulada meesha hada ah arglist `src` in `dst` ku arglist.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Xamuulka muran nooca `T` ka `ap` `va_list` iyo inremantiga Xujada dhibcood `ap` in.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}