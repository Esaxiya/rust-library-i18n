//! Isku soo koobida waxyaabaha muhiimka ah.
//!
//! Qeexitaannada u dhigma waxay ku jiraan `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Fulinta isku midka ah ee fulintu waxay ku jirtaa `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # intrinsics Const
//!
//! Note: wax isbedel ah constness ee intrinsics waa in lagala hadlaa kooxda afka.
//! Tan waxaa ka mid ah isbeddelada xasilloonida xayiraadda.
//!
//! Si loo sameeyo waxyaabo la adeegsan karo marka la soo uruurinayo, qofku wuxuu u baahan yahay inuu nuqul ka sameeyo hirgelinta laga bilaabo <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> illaa `compiler/rustc_mir/src/interpret/intrinsics.rs` oo uu ku daro `#[rustc_const_unstable(feature = "foo", issue = "01234")]` nuxurka.
//!
//!
//! Haddii waxyaabaha la rabo in laga isticmaalo laga soo qaado `const fn` oo leh astaamo `rustc_const_stable` ah, astaanta astaantu waa inay noqotaa `rustc_const_stable`, sidoo kale.
//! Isbedelka noocan oo kale ah waa in aan la samayn iyada oo aan lagala tashan T-lang, maxaa yeelay waxay ku dubaysaa muuqaal luqadda oo aan lagu soo koobi karin lambarka isticmaalaha iyada oo aan la helin isku-duwaha taageerada.
//!
//! # Volatiles
//!
//! The intrinsics kacsan siiyaan hawlaha loogu tala galay inay wax ka qabtaan on xasuusta I/O, taas oo aad loogu balan qaadayo in aan la reordered by compiler oo dhan intrinsics kale kacsan.Fiiri warqadaha LLVM on [[volatile]] ah.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! The intrinsics qaaradda siiyaan hawlaha caadiga ah qaaradda on erayada mashiinka, la awowgood xasuusta suurto gal badan.Waxay adeecin kelmedo la mid ah sida C++ 11.Ka eeg dukumintiyada LLVM [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Cusboonaysiin deg deg ah oo ku saabsan amarka xusuusta:
//!
//! * Hesho, caqabad ku ah helitaanka qufulka.Xiga qoro, akhriyo dhacaan ka dib markii caqabad ku.
//! * Siidaynta, caqabad ku ah sii deynta qufulka.Akhrinta iyo qorista kahoreysani waxay dhacaan kahor caqabadda.
//! * Sequentially joogto ah, hawlaha sequentially joogto ah loogu ballan qaaday in ay ka dhacaan si.Kani waa habka caadiga ah ee loogu shaqeeyo noocyada atomikada wuxuuna u dhigmaa Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// keeno Kuwani waxaa loo isticmaalaa fududaynta links intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // BADBAADADA: eeg `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // FG, intrinsics, kuwaas oo qaadan tilmaamo cayriin maxaa yeelay, iyagu way isbaddali xasuusta aliased, taas oo aan sax ah waayo `&` ama `&mut`.
    //

    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange` ku maraya [`Ordering::SeqCst`] sida labada xuduudaha `success` iyo `failure`.
    ///
    /// Tusaale ahaan, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange` ku maraya [`Ordering::Acquire`] sida labada xuduudaha `success` iyo `failure`.
    ///
    /// Tusaale ahaan, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange` ku maraya [`Ordering::Release`] sida `success` iyo [`Ordering::Relaxed`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `compare_exchange` adoo maraya [`Ordering::AcqRel`] sida `success` iyo [`Ordering::Acquire`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange` ku maraya [`Ordering::Relaxed`] sida labada xuduudaha `success` iyo `failure`.
    ///
    /// Tusaale ahaan, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange` ku maraya [`Ordering::SeqCst`] sida `success` iyo [`Ordering::Relaxed`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange` ku maraya [`Ordering::SeqCst`] sida `success` iyo [`Ordering::Acquire`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `compare_exchange` adoo maraya [`Ordering::Acquire`] sida `success` iyo [`Ordering::Relaxed`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange` ku maraya [`Ordering::AcqRel`] sida `success` iyo [`Ordering::Relaxed`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `compare_exchange_weak` adoo maraya [`Ordering::SeqCst`] labadaba xuduudaha `success` iyo `failure`.
    ///
    /// Tusaale ahaan, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `compare_exchange_weak` adoo maraya [`Ordering::Acquire`] labadaba xuduudaha `success` iyo `failure`.
    ///
    /// Tusaale ahaan, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `compare_exchange_weak` adoo maraya [`Ordering::Release`] sida `success` iyo [`Ordering::Relaxed`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `compare_exchange_weak` adoo maraya [`Ordering::AcqRel`] sida `success` iyo [`Ordering::Acquire`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange_weak` ku maraya [`Ordering::Relaxed`] sida labada xuduudaha `success` iyo `failure`.
    ///
    /// Tusaale ahaan, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange_weak` ku maraya [`Ordering::SeqCst`] sida `success` iyo [`Ordering::Relaxed`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `compare_exchange_weak` ku maraya [`Ordering::SeqCst`] sida `success` iyo [`Ordering::Acquire`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `compare_exchange_weak` adoo maraya [`Ordering::Acquire`] sida `success` iyo [`Ordering::Relaxed`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Waxay keydisaa qiime haddii qiimaha hadda jiraa uu lamid yahay qiimaha `old`.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `compare_exchange_weak` adoo maraya [`Ordering::AcqRel`] sida `success` iyo [`Ordering::Relaxed`] sida xuduudaha `failure`.
    /// Tusaale ahaan, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Waxay xamuusheysaa qiimaha hadda tilmaamaya.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `load` ku maraya [`Ordering::SeqCst`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Waxay xamuusheysaa qiimaha hadda tilmaamaya.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `load` ku maraya [`Ordering::Acquire`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Waxay xamuusheysaa qiimaha hadda tilmaamaya.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `load` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Wuxuu ku kaydiyaa qiimaha meesha xusuusta lagu cayimay.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `store` ku maraya [`Ordering::SeqCst`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Wuxuu ku kaydiyaa qiimaha meesha xusuusta lagu cayimay.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `store` ku maraya [`Ordering::Release`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Wuxuu ku kaydiyaa qiimaha meesha xusuusta lagu cayimay.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `store` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Kaydiya qiimaha goobta xasuusta ku qeexan, soo laabtay qiimaha jir.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `swap` adoo marinaya [`Ordering::SeqCst`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kaydiya qiimaha goobta xasuusta ku qeexan, soo laabtay qiimaha jir.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `swap` adoo marinaya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kaydiya qiimaha goobta xasuusta ku qeexan, soo laabtay qiimaha jir.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `swap` ku maraya [`Ordering::Release`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kaydiya qiimaha goobta xasuusta ku qeexan, soo laabtay qiimaha jir.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `swap` ku maraya [`Ordering::AcqRel`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kaydiya qiimaha goobta xasuusta ku qeexan, soo laabtay qiimaha jir.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `swap` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Waxay ku dareysaa qiimaha hadda jira, iyagoo soo celinaya qiimihii hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_add` ku maraya [`Ordering::SeqCst`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Waxay ku dareysaa qiimaha hadda jira, iyagoo soo celinaya qiimihii hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_add` adoo marinaya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Waxay ku dareysaa qiimaha hadda jira, iyagoo soo celinaya qiimihii hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_add` ku maraya [`Ordering::Release`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Waxay ku dareysaa qiimaha hadda jira, iyagoo soo celinaya qiimihii hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_add` ku maraya [`Ordering::AcqRel`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Waxay ku dareysaa qiimaha hadda jira, iyagoo soo celinaya qiimihii hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_add` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ka jar qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_sub` ku maraya [`Ordering::SeqCst`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka jar qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_sub` adoo marinaya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka jar qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_sub` adoo marinaya [`Ordering::Release`] sida `order`.
    /// Tusaale ahaan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka jar qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_sub` ku maraya [`Ordering::AcqRel`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ka jar qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah ayaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_sub` adoo marinaya [`Ordering::Relaxed`] sida `order`.
    /// Tusaale ahaan, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise iyo qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_and` ku maraya [`Ordering::SeqCst`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise iyo qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_and` adoo marinaya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise iyo qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_and` ku maraya [`Ordering::Release`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise iyo qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_and` adoo marinaya [`Ordering::AcqRel`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise iyo qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_and` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand oo leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa nooca [`AtomicBool`] ka via habka `fetch_nand` ku maraya [`Ordering::SeqCst`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand oo leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// Nooca la xasiliyey ee asalka ah waxaa lagu heli karaa nooca [`AtomicBool`] iyadoo loo marayo habka `fetch_nand` adoo marinaya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand oo leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa nooca [`AtomicBool`] ka via habka `fetch_nand` ku maraya [`Ordering::Release`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand oo leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa nooca [`AtomicBool`] iyadoo loo marayo habka `fetch_nand` adoo maraya [`Ordering::AcqRel`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand oo leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa nooca [`AtomicBool`] ka via habka `fetch_nand` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Si tartiib ah ama leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_or` adoo marinaya [`Ordering::SeqCst`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Si tartiib ah ama leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_or` adoo marinaya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Si tartiib ah ama leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_or` ku maraya [`Ordering::Release`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Si tartiib ah ama leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_or` adoo marinaya [`Ordering::AcqRel`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Si tartiib ah ama leh qiimaha hadda, soo celinta qiimihii hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_or` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Miyeydnaan Bitwise leh qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_xor` adoo marinaya [`Ordering::SeqCst`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Miyeydnaan Bitwise leh qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah ayaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_xor` adoo marinaya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Miyeydnaan Bitwise leh qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_xor` ku maraya [`Ordering::Release`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Miyeydnaan Bitwise leh qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// Nooca xasilloon ee aasaasiga ah waxaa laga heli karaa noocyada [`atomic`] iyada oo loo marayo habka `fetch_xor` adoo marinaya [`Ordering::AcqRel`] sida `order`.
    /// Tusaale ahaan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Miyeydnaan Bitwise leh qiimaha hadda, soo laabtay qiimaha hore.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa noocyada [`atomic`] via habka `fetch_xor` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ugu badnaan qiimaha hadda jira iyadoo la adeegsanayo isbarbardhig la saxiixay.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa [`atomic`] saxiixay abyoonaha noocyada via habka `fetch_max` ku maraya [`Ordering::SeqCst`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ugu badnaan qiimaha hadda jira iyadoo la adeegsanayo isbarbardhig la saxiixay.
    ///
    /// Nooca la xasiliyey ee asalka ah waxaa laga heli karaa noocyada isku-darka ah ee saxeexan ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_max` adoo maraya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ugu badnaan qiimaha hadda jira iyadoo la adeegsanayo isbarbardhig la saxiixay.
    ///
    /// Nooca la xasiliyey ee asalka ah waxaa laga heli karaa noocyada isku-darka ah ee saxeexan ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_max` adoo maraya [`Ordering::Release`] sida `order`.
    /// Tusaale ahaan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ugu badnaan qiimaha hadda jira iyadoo la adeegsanayo isbarbardhig la saxiixay.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa [`atomic`] saxiixay abyoonaha noocyada via habka `fetch_max` ku maraya [`Ordering::AcqRel`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ugu badnaan la qiimaha hadda.
    ///
    /// Nooca la xasiliyey ee asalka ah waxaa laga heli karaa noocyada isku-darka ah ee saxeexan ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_max` adoo maraya [`Ordering::Relaxed`] sida `order`.
    /// Tusaale ahaan, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig la saxiixay.
    ///
    /// Nooca la xasiliyey ee asalka ah waxaa laga heli karaa noocyada isku-darka ah ee saxeexan ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_min` adoo maraya [`Ordering::SeqCst`] sida `order`.
    /// Tusaale ahaan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig la saxiixay.
    ///
    /// Nooca la xasiliyey ee asalka ah waxaa laga heli karaa noocyada isku-darka ah ee saxeexan ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_min` adoo maraya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig la saxiixay.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa [`atomic`] saxiixay abyoonaha noocyada via habka `fetch_min` ku maraya [`Ordering::Release`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig la saxiixay.
    ///
    /// Nooca la xasiliyey ee asalka ah waxaa laga heli karaa noocyada isku-darka ah ee saxeexan ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_min` adoo maraya [`Ordering::AcqRel`] sida `order`.
    /// Tusaale ahaan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig la saxiixay.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa [`atomic`] saxiixay abyoonaha noocyada via habka `fetch_min` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig aan saxiixneyn.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada isku-darka ah ee aan saxeexnayn ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_min` adoo maraya [`Ordering::SeqCst`] sida `order`.
    /// Tusaale ahaan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig aan saxiixneyn.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada isku-darka ah ee aan saxeexnayn ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_min` adoo maraya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig aan saxiixneyn.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa [`atomic`] noocyada abyoonaha sixiixin via habka `fetch_min` ku maraya [`Ordering::Release`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig aan saxiixneyn.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa [`atomic`] noocyada abyoonaha sixiixin via habka `fetch_min` ku maraya [`Ordering::AcqRel`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uguyaraan qiimaha hadda jira adoo adeegsanaya isbarbar dhig aan saxiixneyn.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa [`atomic`] noocyada abyoonaha sixiixin via habka `fetch_min` ku maraya [`Ordering::Relaxed`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ugu badnaan qiimaha hadda la isticmaalayo isbarbardhig aan la saxiixin.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa [`atomic`] noocyada abyoonaha sixiixin via habka `fetch_max` ku maraya [`Ordering::SeqCst`] sida `order` ah.
    /// Tusaale ahaan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ugu badnaan qiimaha hadda la isticmaalayo isbarbardhig aan la saxiixin.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada isku-darka ah ee aan saxeexnayn ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_max` adoo maraya [`Ordering::Acquire`] sida `order`.
    /// Tusaale ahaan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ugu badnaan qiimaha hadda la isticmaalayo isbarbardhig aan la saxiixin.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada isku-darka ah ee aan saxeexnayn ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_max` adoo maraya [`Ordering::Release`] sida `order`.
    /// Tusaale ahaan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ugu badnaan qiimaha hadda la isticmaalayo isbarbardhig aan la saxiixin.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada isku-darka ah ee aan saxeexnayn ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_max` adoo maraya [`Ordering::AcqRel`] sida `order`.
    /// Tusaale ahaan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ugu badnaan qiimaha hadda la isticmaalayo isbarbardhig aan la saxiixin.
    ///
    /// Nooca xasilloon ee muuqaalkan aasaasiga ah waxaa laga heli karaa noocyada isku-darka ah ee aan saxeexnayn ee loo yaqaan [`atomic`] iyada oo loo marayo habka `fetch_max` adoo maraya [`Ordering::Relaxed`] sida `order`.
    /// Tusaale ahaan, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// jaleelada `prefetch` waa oggayn in matoor code in aad is geliso barashada prefetch ah haddii ay taageerto ah;haddii kale, waa maya-diid.
    /// Prefetches leeyihiin saameyn ah kuma laha dhaqanka ee barnaamijka laakiin bedeli kartaa dabeecadaha qaab ay.
    ///
    /// Doodda `locality` waa inay ahaataa mid isku dhafan oo joogto ah waana tilmaame ku-meel-gaadh ah oo ku-meel-gaadh ah oo ka bilaabma (0), oo aan lahayn meel ku taal, illaa (3), oo aad u xaddidan ku haynta deegaanka
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// jaleelada `prefetch` waa oggayn in matoor code in aad is geliso barashada prefetch ah haddii ay taageerto ah;haddii kale, waa maya-diid.
    /// Prefetches leeyihiin saameyn ah kuma laha dhaqanka ee barnaamijka laakiin bedeli kartaa dabeecadaha qaab ay.
    ///
    /// Doodda `locality` waa inay ahaataa mid isku dhafan oo joogto ah waana tilmaame ku-meel-gaadh ah oo ku-meel-gaadh ah oo ka bilaabma (0), oo aan lahayn meel ku taal, illaa (3), oo aad u xaddidan ku haynta deegaanka
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// jaleelada `prefetch` waa oggayn in matoor code in aad is geliso barashada prefetch ah haddii ay taageerto ah;haddii kale, waa maya-diid.
    /// Prefetches leeyihiin saameyn ah kuma laha dhaqanka ee barnaamijka laakiin bedeli kartaa dabeecadaha qaab ay.
    ///
    /// Doodda `locality` waa inay ahaataa mid isku dhafan oo joogto ah waana tilmaame ku-meel-gaadh ah oo ku-meel-gaadh ah oo ka bilaabma (0), oo aan lahayn meel ku taal, illaa (3), oo aad u xaddidan ku haynta deegaanka
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// jaleelada `prefetch` waa oggayn in matoor code in aad is geliso barashada prefetch ah haddii ay taageerto ah;haddii kale, waa maya-diid.
    /// Prefetches leeyihiin saameyn ah kuma laha dhaqanka ee barnaamijka laakiin bedeli kartaa dabeecadaha qaab ay.
    ///
    /// Doodda `locality` waa inay ahaataa mid isku dhafan oo joogto ah waana tilmaame ku-meel-gaadh ah oo ku-meel-gaadh ah oo ka bilaabma (0), oo aan lahayn meel ku taal, illaa (3), oo aad u xaddidan ku haynta deegaanka
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Xayndaab atom ah.
    ///
    /// Nooca xasilloon ee aasaasiga ah ayaa laga heli karaa [`atomic::fence`] adoo maraya [`Ordering::SeqCst`] sida `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Xayndaab atom ah.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa in [`atomic::fence`] maraya [`Ordering::Acquire`] sida `order` ah.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Xayndaab atom ah.
    ///
    /// Nooca xasilloon ee aasaasiga ah ayaa laga heli karaa [`atomic::fence`] adoo maraya [`Ordering::Release`] sida `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Xayndaab atom ah.
    ///
    /// Nooca xasilloon ee aasaasiga ah ayaa laga heli karaa [`atomic::fence`] adoo maraya [`Ordering::AcqRel`] sida `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Caqabad-xusuusin isku-dubbarid ah.
    ///
    /// Furidda Memory marnaba la reordered doona dhamaan caqabad this by compiler ah, laakiin tilmaamaha ma la timaada doonaa.
    /// Tani waxay ku habboon tahay hawlgallada isla xariiqda ah ee laga yaabo in la iskudayo, sida marka lala falgalayo ilaaliyeyaasha isha.
    ///
    /// Nooca xasilloon ee aasaasiga ah ayaa laga heli karaa [`atomic::compiler_fence`] adoo maraya [`Ordering::SeqCst`] sida `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Caqabad-xusuusin isku-dubbarid ah.
    ///
    /// Furidda Memory marnaba la reordered doona dhamaan caqabad this by compiler ah, laakiin tilmaamaha ma la timaada doonaa.
    /// Tani waxay ku habboon tahay hawlgallada isla xariiqda ah ee laga yaabo in la iskudayo, sida marka lala falgalayo ilaaliyeyaasha isha.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa in [`atomic::compiler_fence`] maraya [`Ordering::Acquire`] sida `order` ah.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Caqabad-xusuusin isku-dubbarid ah.
    ///
    /// Furidda Memory marnaba la reordered doona dhamaan caqabad this by compiler ah, laakiin tilmaamaha ma la timaada doonaa.
    /// Tani waxay ku habboon tahay hawlgallada isla xariiqda ah ee laga yaabo in la iskudayo, sida marka lala falgalayo ilaaliyeyaasha isha.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa in [`atomic::compiler_fence`] maraya [`Ordering::Release`] sida `order` ah.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Caqabad-xusuusin isku-dubbarid ah.
    ///
    /// Furidda Memory marnaba la reordered doona dhamaan caqabad this by compiler ah, laakiin tilmaamaha ma la timaada doonaa.
    /// Tani waxay ku habboon tahay hawlgallada isla xariiqda ah ee laga yaabo in la iskudayo, sida marka lala falgalayo ilaaliyeyaasha isha.
    ///
    /// version The xasilin of jaleelada waxa loo heli karaa in [`atomic::compiler_fence`] maraya [`Ordering::AcqRel`] sida `order` ah.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Sixiro sixir ah oo macnaheeda kahelaya sifooyin kuxiran shaqada.
    ///
    /// Tusaale ahaan, qulqulka xogta ayaa tan u adeegsata inay ku muddo sheegashooyin taagan si markaa `rustc_peek(potentially_uninitialized)` ay dhab ahaan u laba-jibbaarto in qulqulka xogta ay dhab ahaan xisaabisay inay tahay mid aan la ogaan karin bartaas ay ka socoto xakamaynta.
    ///
    ///
    /// jaleelada Tani waa in aanay noqon ka baxsan used of compiler ah.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Waxay diidaysaa fulinta howsha.
    ///
    /// version A user-saaxiibtinimo iyo mid deggan dheeraad ah hawlgalka this waa [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Ogeysiin optimizer in markan in code ma aha Ieexdo, awood optimizations dheeraad ah.
    ///
    /// FG, tani waa mid aad u kala duwan oo ka Dhaqale `unreachable!()` ah: Si ka duwan Dhaqale ah, taas oo panics marka lagu qaybshay, waa *dhaqanka undefined* in ay gaaraan code la function this calaamadeeyay.
    ///
    ///
    /// version The xasilin of jaleelada tani waa [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Wuxuu ku wargaliyaa kaaliyaha wax qabadka in xaaladdu had iyo jeer run tahay.
    /// Haddii xaaladdu been tahay, habdhaqanka lama qeexin.
    ///
    /// Ma jiro wax koodh ah oo loo soo saaray qaabkan gaarka ah, laakiin yididiilada ayaa isku dayi doona inuu ilaaliyo (iyo xaaladdiisa) inta udhaxeysa baaska, taas oo carqaladeyn karta hagaajinta koodhka hareeraha iyo yareynta waxqabadka.
    /// Waa in aan la isticmaalin haddii invariant ah in la helay karaa by optimizer ku gaar ah, ama haddii aysan awood kasta oo optimizations weyn.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Tilmaamo ku saabsan isku-duwaha in xaaladda branch ay u badan tahay inay run tahay.
    /// Sooceliyaa qiimaha loo gudbiyey.
    ///
    /// isticmaalka kasta oo kale oo aan ahayn la statements `if` malaha ma yeelan doonaa saamayn.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Tilmaamo in compiler in xaalad branch u badan tahay in ay khalad tahay.
    /// Sooceliyaa qiimaha loo gudbiyey.
    ///
    /// isticmaalka kasta oo kale oo aan ahayn la statements `if` malaha ma yeelan doonaa saamayn.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Waxay fulisaa dabin kala go ', si loogu baaro khalad sameeye.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn breakpoint();

    /// Cabirka nooc ka mid ah baaytyada.
    ///
    /// More si gaar ah, tani waxaa ku kabayso in bytes dhexeeya alaabta isdaba joog ah oo nooca la mid ah, oo ay ku jiraan kursiga in lays.
    ///
    ///
    /// Nooca xasilloon ee aasaasiga ah waa [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// in lays ugu yar ee nooca ah.
    ///
    /// version The xasilin of jaleelada tani waa [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// in lays The door nooc ka mid ah.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Cabirka qiimaha tixraaca ah ee bytes.
    ///
    /// Nooca xasilloon ee aasaasiga ah waa [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Iswaafajinta loo baahan yahay ee qiimaha la tixraacay.
    ///
    /// version The xasilin of jaleelada tani waa [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Helo jeex ah string ma guurto ah oo ka kooban magaca nooc ka mid ah.
    ///
    /// version The xasilin of jaleelada tani waa [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Helo aqoonsi ah oo aduunka oo gaar ah si ay nooca khaaska ah.
    /// function Tani waxay ku noqon doonaa qiimo isku mid ah nooc ka mid ah iyadoo aan loo eegin hadba waxa crate la baryo in.
    ///
    ///
    /// version The xasilin of jaleelada tani waa [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Waardiye for hawlaha ammaan ahayn oo aan weligood la dili karaa haddii `T` waa Anfaco:
    /// Tani doono jiidasho midkood panic, ama waxba ma samayn.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Waardiye for hawlaha ammaan ahayn oo aan weligood la dili karaa haddii `T` ma oggolaan eber-initialization: Tani jiidasho doono midkood panic, ama waxba ma samayn.
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn assert_zero_valid<T>();

    /// Waardiye for hawlaha ammaan ahayn oo aan weligood la dili karaa haddii `T` uu leeyahay astaamo qayb aan sax ahayn: Tani jiidasho doono midkood panic, ama waxba ma samayn.
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn assert_uninit_valid<T>();

    /// Wuxuu helayaa tixraac `Location` taagan oo tilmaamaya meeshii looga yeedhay.
    ///
    /// Ka feker inaad isticmaasho [`core::panic::Location::caller`](crate::panic::Location::caller) bedelkeeda.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Waxay ka dhaqaajineysaa qiime ka baxsan baaxadda iyada oo aan la socon xabagta dhibcaha.
    ///
    /// Tani oo keliya lagaga [`mem::forget_unsized`];caadiga ah `forget` wuxuu adeegsadaa `ManuallyDrop` halkii.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Dib-ugu-tarjumayaa qeybaha qiimaha hal nooc oo nooc kale ah.
    ///
    /// Labada noocba waa inay lahaadaan cabir isku mid ah.
    /// Midkoodna asalka ah, mana natiijada, waxaa laga yaabaa in [invalid value](../../nomicon/what-unsafe-does.html) ah.
    ///
    /// `transmute` waxay u dhigantaa xoogaa yar oo nooc ah oo nooc kale ah.Waxaa nuqul jajabka ka qiimo isha galay qiimaha Ahaado, ka dibna is-illoobaa asalka ah.
    /// Waxay u dhigantaa C's `memcpy` hoosta daboolka, sida `transmute_copy` oo kale.
    ///
    /// Maxaa yeelay, `transmute` waa hawlgal by-qiimaha, in lays of *transmuted qiimaha naftooda* ma aha walaac ah.
    /// Sida shaqo kasta oo kale, isku-duwaha wuxuu horeyba u hubiyaa in labada `T` iyo `U` ay si sax ah isugu habboon yihiin.
    /// Si kastaba ha ahaatee, marka transmuting qiyamka in dhibic *meelo kale*(sida tilmaamo, tixraacyo, sanduuqyada ...), Yeedhe u leeyahay si loo xaqiijiyo in lays ku habboon oo ka mid ah qiyamka wadno-ka.
    ///
    /// `transmute` waa **si aan caadi aheyn** amaan ma ahan.Waxaa jira tiro badan oo siyaabo in ay keeni [undefined behavior][ub] la function this.`transmute` waa inuu noqdaa midka ugu dambeeya ee ugu dambeeya.
    ///
    /// [nomicon](../../nomicon/transmutes.html) waxay leedahay warqado dheeraad ah.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Waxaa jira dhawr waxyaalood in `transmute` waa run ahaantii waxtar u leh.
    ///
    /// U rogida tilmaame tilmaame shaqo.Tani waa *aan* qaadan karo si mashiinada meesha tilmaamo shaqo iyo tilmaamo xogta leenahay kala duwan.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Kordhinta Meyeydaan, ama yaraynta uu nool ah invariant.Tani waa horumarsan tahay, Rust oo aan ammaan ahayn!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ha ka quusanina, isticmaalka badan ee `transmute` lagu gaari karaa iyada oo loo marayo hab kale.
    /// Hoos waxaa ku yaal codsiyada guud ee `transmute` oo lagu beddeli karo dhismayaal nabdoon.
    ///
    /// U rogaya ceyriin bytes(`&[u8]`) illaa `u32`, `f64`, iwm .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // isticmaal `u32::from_ne_bytes` halkii
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ama isticmaal `u32::from_le_bytes` ama `u32::from_be_bytes` in la qeexo endianness ah
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Jihada tilmaame u rogo `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Isticmaal kabka `as` halkii
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// U roga `*mut T` `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Isticmaal reborrow bedelkeeda
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// U roga `&mut T` `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Haddaba, isugu `as` iyo reborrowing, ogow chaining ee `as` `as` ma aha transitive
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// U roga `&str` `&[u8]`:
    ///
    /// ```
    /// // tani maahan hab wanaagsan oo tan lagu sameeyo.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Waxaad isticmaali kartaa `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Or, kaliya isticmaali string byte ah, haddii aad leedahay gacanta suugaan xarig ah
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// U rogaya `Vec<&T>` `Vec<Option<&T>>`.
    ///
    /// Si transmute nooca hoose oo ka kooban weel, waa in aad u hubiso in ay kuma xadgudbayaan mid ka mid ah invariants weelka ee.
    /// `Vec`, tan macnaheedu waxa weeye in cabirka *iyo toosinta* ee noocyada gudaha ay u dhigmayaan.
    /// weelasha kale ee ku tiirsan laga yaabaa in on size of nooca, in lays, ama xataa `TypeId` ah, taas oo transmuting kiiska ma noqon doono suurto gal ah oo dhan iyada oo aan xad invariants weelka.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // Gadzhiyev vector sida aan mar dambe iyaga isticmaalin doonaa
    /// let v_clone = v_orig.clone();
    ///
    /// // Isticmaalka transmute: tani waxay ku tiirsan tahay qaabka xogta aan la cayimin ee `Vec`, taas oo ah fikrad xun oo sababi karta Habdhaqan aan la qeexin.
    /////
    /// // Si kastaba ha noqotee, waa nuqul-nuqul.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Tani waa habka la soo jeediyay, ee nabdoon.
    /// // Waxa aanu nuqul vector oo dhan, in kastoo, galay soo diyaariyeen cusub.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Kani waa nuqul-nuqul sax ah, dariiqa aan aaminka ahayn ee "transmuting" a `Vec`, iyada oo aan lagu tiirsanayn qaabka xogta.
    /// // Halkii macno wacaya `transmute` ah, aan u oofiyo kabka pointer ah, laakiin marka la eego diinta nooca asalka gudaha (`&i32`) cusub mid (`Option<&i32>`) ah, waxaas oo dhan ayaa ku digniinahaa isku.
    /////
    /// // Ka sokow macluumaadka kor ku xusan la siiyaa, sidoo kale la tashan waraaqo [`from_raw_parts`] ah.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Cusboonaysii tan markii vec_into_raw_parts la xasiliyo.
    ///     // Hubso in asalka vector aan hoos loo dhigin.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Hirgelinta `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Waxaa jira siyaabo badan oo tan loo sameeyo, waxaana jira dhibaatooyin badan oo la xiriira habka soo socda ee (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // marka hore: transmute ma aha nooc aamin ah;waxa kaliya ee la hubiyaa waa T iyo
    ///         // U waa isku cabir.
    ///         // Second, xaq halkan, waxaad leedahay laba tixraacyada mutable fiiqaya in ay xasuusta ka mid ah.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tani waxay ka takhalusaysaa dhibaatooyinka xagga amniga ah;`&mut *` wuxuu* kaliya *kaa siin doonaa `&mut T` `&mut T` ama `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // Si kastaba ha ahaatee, waxaad weli u leeyihiin laba tixraacyada mutable fiiqaya in ay xasuusta ka mid ah.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tani waa sida maktabadda caadiga sameeyaa.
    /// // Tani waa habka ugu fiican, haddii aad u baahato inaad wax sidan oo kale ah sameyso
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Tani hadda waxay leedahay saddex tixraac oo la beddelayo oo tilmaamaya isla xusuusta.`slice`, ret.0 ku rvalue, iyo rvalue ku ret.1.
    ///         // `slice` marna looma ka dib markii `let ptr = ...`, iyo sidaas oo kale qof ula dhaqmi karta sidii "dead", oo sidaas daraaddeed, kaliya aad qabto laba xaleef mutable dhabta ah.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Iyada oo ay tani ka dhigaysaa deggan const jaleelada, waxaan heysanaa qaar ka mid ah code caadadii in FN const
    // jeegaga in looga hortago in ay la isticmaalo gudahood `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Sooceliyaa `true` haddii nooca dhabta ah la siiyo sida `T` u baahan tahay xabagta dhibic,soo celiyaa `false` haddii nooca dhabta ah ee loo bixiyay `T` fuliyo `Copy`.
    ///
    ///
    /// Haddii nooca dhabta ah mana u baahan tahay xabagta dhibic mana qalab `Copy`, ka dibna qiimaha celinta shaqada this waa la cayimin.
    ///
    /// version The xasilin of jaleelada tani waa [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Xisaabinta dheelitirka tilmaame.
    ///
    /// Tan waxaa fuliyey sida jaleelada ah si looga fogaado in diinta iyo abyoonaha ah, tan iyo markii uu qaab beddelidda tuur lahaa iska aliasing macluumaadka.
    ///
    /// # Safety
    ///
    /// Labada tilmaame ee bilaabaya iyo natiijada ka soo baxdaa waa inay ahaadaan mid xuduud ama hal baati dhaafsan dhamaadka shayga loo qoondeeyay.
    /// Haddii pointer midkood waa out of soohdin ama faafi xisaabta dhacdaa ka dibna wax kasta oo la isticmaalo dheeraad ah oo qiimo leh ayuu ka noqday waxay keeni doontaa in dhaqanka undefined.
    ///
    ///
    /// Nooca xasilloon ee aasaasiga ah waa [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Xisaabin mowjadda ka tilmaamaha ah, laga yaabo duubo.
    ///
    /// Tan waxaa loo hirgaliyay inay tahay mid qarsoodi ah si looga fogaado in loo beddelo ama laga soo qaato isku-dhaf ah, maaddaama beddelku uu joojinayo waxyaabaha qaarkood.
    ///
    /// # Safety
    ///
    /// Si ka duwan `offset` asal ahaanta, tan asalka ahi ma xadidayso tilmaamaha soo baxa inuu tilmaamo ama hal baayt u dhaafay dhamaadka shay loo qoondeeyay, waxayna ku duuban tahay laba xisaabeed oo dhammaystiran.
    /// Qiimaha keentay khasab ma aha in aan dhicin in loo isticmaalo si dhab ah u helaan xasuusta.
    ///
    /// Nooca xasilloon ee aasaasiga ah waa [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// U dhiganta `llvm.memcpy.p0i8.0i8.*` habboon, oo cabirkeedu yahay `count`*`size_of::<T>()` iyo iswaafajinta
    ///
    /// `min_align_of::<T>()`
    ///
    /// Halbeegga The kacsan ayaa lagu wadaa inuu `true`, sidaa daraadeed waxa aan la filaayo doonaa haddii size waa loo siman yahay si eber.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Waxay u dhigantaa `llvm.memmove.p0i8.0i8.*` ku habboon, oo cabbirkiisu yahay `count* size_of::<T>()` iyo isku dheellitir
    ///
    /// `min_align_of::<T>()`
    ///
    /// Halbeegga The kacsan ayaa lagu wadaa inuu `true`, sidaa daraadeed waxa aan la filaayo doonaa haddii size waa loo siman yahay si eber.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// U dhiganta mid ku habboon `llvm.memset.p0i8.*` asal ah, oo leh cabbirka `count* size_of::<T>()` iyo iswaafajinta `min_align_of::<T>()`.
    ///
    ///
    /// Halbeegga The kacsan ayaa lagu wadaa inuu `true`, sidaa daraadeed waxa aan la filaayo doonaa haddii size waa loo siman yahay si eber.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Qabata load a kacsan ka pointer `src` ah.
    ///
    /// Nooca xasilloon ee aasaasiga ah waa [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Qabata dukaan kacsan si pointer `dst` ah.
    ///
    /// version The xasilin of jaleelada tani waa [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Matalaa load a kacsan ka pointer `src` Daliil The looma baahna in la toosiyaa.
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Qabata dukaan kacsan si pointer `dst` ah.
    /// tilmaamaha aan loo baahnayn in la toosiyaa.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Sooceliyaa xididka labajibaaran ee `f32`
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Sooceliyaa xididka labajibaaran ee `f64`
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Waxay kor u qaadaysaa `f32` illaa iyo integer power.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Waxay kor u qaadaysaa `f64` illaa iyo integer power.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Sooceliyaa Culumida Soomaaliyeed ee `f32` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Soo celiyaa sino-ga `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Sooceliyaa cosine ee `f32` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Sooceliyaa cosine ee `f64` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Oo kordhisay `f32` ah in awood `f32` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Oo kordhisay `f64` ah in awood `f64` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Soocelisaa jibbaarada `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Soocelisaa jibbaarada `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Soocelinta 2 ee kor loogu qaaday awoodda `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Soocelinta 2 ee kor loogu qaaday awoodda `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Soocelinayaa logarithm-ka dabiiciga ah ee `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Soocelinayaa logarithm-ka dabiiciga ah ee `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Soocelinayaa salka 10 logarithm ee `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Sooceliyaa logarithm salka 10 ee `f64` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Sooceliyaa salka 2 logarithm ee `f32` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Sooceliyaa salka 2 logarithm ee `f64` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Sooceliyaa `a * b + c` qiimaha `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Sooceliyaa `a * b + c` qiimaha `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Soocelisaa qiimaha saxda ah ee `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Soocelisaa qiimaha saxda ah ee `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Waxay soo celisaa ugu yaraan laba qiimeeyo `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Soo celiyaa uguyaraan laba qiime `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Sooceliyaa ugu badnaan laba qiimaha `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Waxay soo celisaa ugu badnaan laba qiimeeyo `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Nuqulada calaamad ka `y` in `x` qiimaha `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Nuqulada calaamad ka `y` in `x` qiimaha `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Soo celiyaa tiradii ugu badneyd ee ka yar ama u dhiganta `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Dib abyoonaha ugu weyn ee ka yar ama ka badan simanyihiin inay `f64` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Sooceliyaa weyn ugu yar abyoonaha badan ama simanyihiin inay `f32` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Sooceliyaa weyn ugu yar abyoonaha badan ama simanyihiin inay `f64` ah.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Sooceliyaa qaybtii iskudarka ee `f32`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Sooceliyaa qaybtii iskudarka ee `f64`.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Sooceliyaa abyoonaha ugu dhow in ay `f32` ah.
    /// Waxaa laga yaabaa kicin ah inexact laga reebo sabayn-dhibcood haddii muran ma aha abyoonaha ah.
    pub fn rintf32(x: f32) -> f32;
    /// Ku soo celiya tiradii udambeysay `f64`.
    /// Waxaa laga yaabaa kicin ah inexact laga reebo sabayn-dhibcood haddii muran ma aha abyoonaha ah.
    pub fn rintf64(x: f64) -> f64;

    /// Sooceliyaa abyoonaha ugu dhow in ay `f32` ah.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Ku soo celiya tiradii udambeysay `f64`.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Ku soo celiya tiradii udambeysay `f32`.Wareeg kiisaska nus-ka-baxsan eber.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Ku soo celiya tiradii udambeysay `f64`.Wareeg kiisaska nus-ka-baxsan eber.
    ///
    /// version The xasilin of jaleelada tani waa
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Sabeyn Intaa waxaa dheer in u ogolaanaya optimizations ku salaysan xeerarka aljabrada.
    /// qaadan waxaa laga yaabaa in gashiga yihiin uguna.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Ka-goynta sabeynta oo kuu oggolaaneysa wax-ku-habboonaanta oo ku saleysan xeerarka aljabrada.
    /// qaadan waxaa laga yaabaa in gashiga yihiin uguna.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Sabeyn dhufashada u ogolaanaya optimizations ku salaysan xeerarka aljabrada.
    /// qaadan waxaa laga yaabaa in gashiga yihiin uguna.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Sabeyn qeybinta u ogolaanaya optimizations ku salaysan xeerarka aljabrada.
    /// qaadan waxaa laga yaabaa in gashiga yihiin uguna.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Sabeyn ka dhiman u ogolaanaya optimizations ku salaysan xeerarka aljabrada.
    /// qaadan waxaa laga yaabaa in gashiga yihiin uguna.
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// U beddel LLVM's fptoui/fptosi, oo soo celin kara undef qiimeyaasha ka baxsan
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Waxaa loo xasiliyay sidii [`f32::to_int_unchecked`] iyo [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Celinta tirada jajabka dhigay nooca abyoonaha ah `T`
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `count_ones` ah.
    /// Tusaale ahaan,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Sooceliyaa tirada hogaaminta yar yar ee furfurashada (zeroes) nooc isku dhafan `T`.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `leading_zeros` ah.
    /// Tusaale ahaan,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// An `x` la qiimaha `0` soo laaban doona width yara of `T` ah.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Like `ctlz`, laakiin dheeri ah ammaan ahayn ka noqdo `undef` sida marka la siiyo `x` la qiimaha `0`.
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Waxay soo celisaa tirada ka danbeysa gelinno unset (zeroes) in nooca abyoonaha ah `T`.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `trailing_zeros` ah.
    /// Tusaale ahaan,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// An `x` la qiimaha `0` soo laaban doona width yara of `T` ah:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Sida `cttz`, laakiin ammaan-darro dheeraad ah maadaama ay soo celineyso `undef` markii la siiyo `x` qiime leh `0`.
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Dumiso bytes ee nooca abyoonaha ah `T`.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `swap_bytes` ah.
    /// Tusaale ahaan,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Dumiso gelinno in nooca abyoonaha ah `T`.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `reverse_bits` ah.
    /// Tusaale ahaan,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Waxay qabataa isku darka tirada.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `overflowing_add` ah.
    /// Tusaale ahaan,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Wuxuu qabtaa kalagoyn isku dhafan
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `overflowing_sub` ah.
    /// Tusaale ahaan,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Waxay qabataa isku dhufashada isku dhafan
    ///
    /// Noocyada la xasiliyey ee aasaasiga ah waxaa laga heli karaa inta jeer ee integer-ka iyada oo loo marayo habka `overflowing_mul`.
    /// Tusaale ahaan,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Waxay qabataa qayb sax ah, taasoo dhalisay dabeecad aan la qeexin halka `x % y != 0` ama `y == 0` ama `x == T::MIN && y == -1`
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Qabata qeybinta ah laga qaban, taasoo keentay in dhaqanka undefined meesha `y == 0` ama `x == T::MIN && y == -1`
    ///
    ///
    /// Qalabka wax lagu duubo ee aaminka ah ee aasaasiga ah waxaa laga heli karaa inta jeer ee integer-ka iyada oo loo marayo habka `checked_div`.
    /// Tusaale ahaan,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Waxay soo celisaa inta ka dhiman horyaalka heerka an laga qaban, taasoo keentay in dhaqanka undefined markii `y == 0` ama `x == T::MIN && y == -1`
    ///
    ///
    /// Qalabka wax lagu duubo ee aaminka ah ee aasaasiga ah waxaa laga heli karaa inta jeer ee integer-ka iyada oo loo marayo habka `checked_rem`.
    /// Tusaale ahaan,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Waxay qabataa wareejin bidix oo aan la hubin, taasoo dhalisay dabeecad aan la qeexin markii `y < 0` ama `y >= N`, halkaasoo N uu yahay ballaca T ee qaniinyada.
    ///
    ///
    /// Qalabka wax lagu duubo ee aaminka ah ee aasaasiga ah waxaa laga heli karaa inta jeer ee integer-ka iyada oo loo marayo habka `checked_shl`.
    /// Tusaale ahaan,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Waxay qabataa isbeddel midig oo aan la hubin, taasoo keentay dabeecad aan la qeexin markii `y < 0` ama `y >= N`, halkaasoo N uu yahay ballaca T ee qaniinyada.
    ///
    ///
    /// qolfaha nabdoon ee jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `checked_shr` ah.
    /// Tusaale ahaan,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Waxay soocelisaa natiijada isugeyn aan la hubin, taasoo dhalisay dabeecad aan la qeexin markii `x + y > T::MAX` ama `x + y < T::MIN`.
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Ku soocelisaa natiijada kalagoyn aan la hubin, taasoo dhalisay dabeecad aan la qeexin markii `x - y > T::MAX` ama `x - y < T::MIN`.
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Sooceliyaa natiijada isku dhufashada ah qaban, taasoo keentay in dhaqanka undefined markii `x *y > T::MAX` ama `x* y < T::MIN`.
    ///
    ///
    /// Waxyaabaha aasaasiga ahi malaha dhigge deggan.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Matalaa isku shaandheyn ku tagay.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `rotate_left` ah.
    /// Tusaale ahaan,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Wax qabad wareejiya midig.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `rotate_right` ah.
    /// Tusaale ahaan,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Soocelinta (a + b) mod 2 <sup>N</sup>, halkaas oo N ay tahay baaxadda T goos gooska.
    ///
    /// Noocyada la xasiliyey ee aasaasiga ah waxaa laga heli karaa inta jeer ee integer-ka iyada oo loo marayo habka `wrapping_add`.
    /// Tusaale ahaan,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Celinta (a, b) mod 2 <sup>N,</sup> N, halkaas oo waa width of T ee gelinno.
    ///
    /// Noocyada la xasiliyey ee aasaasiga ah waxaa laga heli karaa inta jeer ee integer-ka iyada oo loo marayo habka `wrapping_sub`.
    /// Tusaale ahaan,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Celinta (b a *) mod 2 <sup>N,</sup> N, halkaas oo waa width of T ee gelinno.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `wrapping_mul` ah.
    /// Tusaale ahaan,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, saturating at soohdin tiro.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `saturating_add` ah.
    /// Tusaale ahaan,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Xisaabiyaa `a - b`, oo ka dheregsan xadka tirada.
    ///
    /// The versions of xasilin jaleelada this waxaa laga heli karaa primitives abyoonaha via habka `saturating_sub` ah.
    /// Tusaale ahaan,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Sooceliyaa qiimaha discriminant ee kala duwanaansho ee 'v';
    /// haddii `T` ayaa discriminant lahayn, soo laabtay `0`.
    ///
    /// version The xasilin of jaleelada tani waa [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Sooceliyaa tirada noocyada nooca `T` loo tuuray `usize`;
    /// haddii `T` uusan lahayn noocyo, wuxuu soo celiyaa `0`.Noocyada aan la noolayn ayaa la tirin doonaa.
    ///
    /// version waxaa la-dejiyo si-of jaleelada tani waa [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust ee dhisida "try catch" oo baryi tilmaamaha shaqada `try_fn` la pointer xogta `data`.
    ///
    /// Doodda saddexaad waa shaqo la yiraahdo haddii panic dhacdo.
    /// function waxay qaadataa pointer xogta iyo tilmaamaha ah in laga reebo shay target-gaarka ah ee in lagu qabtay.
    ///
    /// Wixii macluumaad dheeraad ah ka eeg il compiler ee sidoo kale fulinta std ee qabsado.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Shanqarta dukaanka `!nontemporal` sidii LLVM (eeg DoCS) oo.
    /// Malaha marnaba noqon doonaa mid deggan.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Faahfaahin ka eeg dukumintiyada `<*const T>::offset_from`.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Faahfaahin ka eeg dukumintiyada `<*const T>::guaranteed_eq`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Faahfaahin ka eeg dukumintiyada `<*const T>::guaranteed_ne`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Qoondee wakhti isku ururiso.Waa inaan loo yeerin waqtiga shaqada.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Hawlaha qaarkood ayaa halkan lagu qeexay maxaa yeelay waxay si kadis ah u heleen qaybtani qaybtani iyada oo xasiloon.
// Fiiri <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` sidoo kale ku dhacaa this category, laakiin ma aha in la duudduubay kartaa sabab u tahay jeegga in `T` iyo `U` leeyihiin isku qiyaas.)
//

/// Wuxuu hubiyaa in `ptr` uu si sax ah ula jaan qaadayo `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Nuqulada `count *size_of::<T>()` bytes ka `src` in `dst`.Ilaha iyo halka loo socdo* waa inaysan * iskudhaafin.
///
/// Waayo, gobollada xusuusta oo daboolaa laga yaabaa, isticmaali [`copy`] halkii.
///
/// `copy_nonoverlapping` waa semantically u dhiganta C ee [`memcpy`], laakiin si muran ku bedesheen ah.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `src` waa in ay ahaadaan [valid] for akhriya ee `count * size_of::<T>()` bytes.
///
/// * `dst` waa in ay ahaadaan [valid] waayo, ayuu qoray wargayska of bytes `count * size_of::<T>()`.
///
/// * Labadaba `src` iyo `dst` waa in ay si sax ah isu waafajiyaan.
///
/// * Gobolka xasuusta laga bilaabo `src` la size a of `tirin *
///   cabirka_of<T>() `` bytes '' waa inaysan * * iskudhicin aagga xusuusta ee ka bilaabmaya `dst` oo leh cabir isku mid ah.
///
/// Like [`read`], `copy_nonoverlapping` abuurtaa nuqul bitwise of `T` ah, iyadoo aan loo eegin in `T` waa [`Copy`].
/// Haddii `T` ma aha [`Copy`], iyadoo la isticmaalayo *labada* qiimaha ee gobolka laga bilaabo `*src` iyo gobolka laga bilaabo `* dst` [violate memory safety][read-ownership] kartaan.
///
///
/// Xusuusnow in xitaa haddii cabirka wax ku oolka ah la koobiyay (``tiriyo * cabbir_of: :<T>()`) Waa `0`, tilmaamo waa in ay ahaadaan kuwa aan waxba si fiican u safan.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Adigu gacanta ku hirgeli [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Waxay u guurisaa dhammaan walxaha `src` `dst`, iyadoo laga tegayo `src` madhan.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Hubi in `dst` uu leeyahay awood ku filan oo uu ku hayn karo dhammaan `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Wicitaanka si loo dheellitiro had iyo jeer waa aamin maxaa yeelay `Vec` waligeed ma qoondeyn doonto wax ka badan `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` adigoon daadinin waxa ku jira.
///         // Waxaan ugu horeysay tan loo sameeyo, si dhibaatooyinka ka dheeraw in kiiska wax dheeraad ah hoos panics.
///         src.set_len(0);
///
///         // Labada gobol isma dhaafi karaan maxaa yeelay tixraacyada la beddeli karo magac xumo ma leh, iyo laba vectors oo kala duwan ma lahaan karaan xusuus isku mid ah.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Ogeysii `dst` in ay hadda ka haya kooban `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Samee jeegaggan kaliya waqtiga socodka
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Kama nixineyso inay yareyso saameynta codegen.
        abort();
    }*/

    // AMMAANKA: heshiis ammaanka `copy_nonoverlapping` waa in ay ahaadaan
    // uu taageeray qofka soo wacaya.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Nuqulada `count * size_of::<T>()` bytes ka `src` in `dst`.Ilaha iyo halka loo socdo ayaa is dulsaari kara.
///
/// Haddii isha iyo halka loo socdo *waligeed* isdhaafin, [`copy_nonoverlapping`] waa la isticmaali karaa halkii.
///
/// `copy` waa semantically u dhiganta C ee [`memmove`], laakiin si muran ku bedesheen ah.
/// Nuqul guurintu waxay u dhacdaa sidii in baytiyada laga soo guuriyay `src` oo loo diyaariyey meel ku meelgaar ah ka dibna laga soo min guuriyey safafka ilaa `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `src` waa in ay ahaadaan [valid] for akhriya ee `count * size_of::<T>()` bytes.
///
/// * `dst` waa in ay ahaadaan [valid] waayo, ayuu qoray wargayska of bytes `count * size_of::<T>()`.
///
/// * Labadaba `src` iyo `dst` waa in ay si sax ah isu waafajiyaan.
///
/// Like [`read`], `copy` abuurtaa nuqul bitwise of `T` ah, iyadoo aan loo eegin in `T` waa [`Copy`].
/// Haddii `T` ma aha [`Copy`], adigoo isticmaalaya labada qiyamka ee gobolka laga bilaabo `*src` iyo gobolka laga bilaabo `* dst` [violate memory safety][read-ownership] kartaan.
///
///
/// Xusuusnow in xitaa haddii cabirka wax ku oolka ah la koobiyay (``tiriyo * cabbir_of: :<T>()`) Waa `0`, tilmaamo waa in ay ahaadaan kuwa aan waxba si fiican u safan.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Si hufan ka kayd nabadla abuuro Rust vector ah:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` waa in si sax ah loo waafajiyaa nooca iyo eber-ka.
/// /// * `ptr` waa inuu ansax ku ahaadaa akhrinta `elts` walxaha iskuxirka ee nooca `T`.
/// /// * Cunsurradaas waa in aan la isticmaalin ka dib markay soo wacaan shaqadan illaa `T: Copy` mooyee.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // BADBAADADA: Shuruuddeena ugu horreysa waxay hubineysaa in ilaha la waafajiyay oo ansax yahay,
///     // iyo `Vec::with_capacity` waxay hubisaa inaan haysanno meel la isticmaali karo oo lagu qoro.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // AMMAANKA: Waxaan u abuuray oo leh awood this ka badan sidii hore,
///     // iyo `copy` kii hore ayaa bilaabay waxyaabahan.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Samee jeegaggan kaliya waqtiga socodka
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Kama nixineyso inay yareyso saameynta codegen.
        abort();
    }*/

    // BADBAADADA: heshiiska nabadgelyada ee `copy` waa inuu ilaaliyaa qofka soo wacaya.
    unsafe { copy(src, dst, count) }
}

/// Waxay dejisaa `count * size_of::<T>()` bytes ee xasuusta oo ka bilaabmaysa `dst` ilaa `val`.
///
/// `write_bytes` wuxuu la mid yahay C's [`memset`], laakiin wuxuu dejiyaa `count * size_of::<T>()` bytes ilaa `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `dst` waa in ay ahaadaan [valid] waayo, ayuu qoray wargayska of bytes `count * size_of::<T>()`.
///
/// * `dst` waa in si sax ah loo waafajiyaa.
///
/// Intaa waxaa sii dheer, qofka soo wacaya waa inuu hubiyaa in qorista `count * size_of::<T>()` bytes ee gobolka la siiyay ee xasuusta ay keento qiime sax ah oo ah `T`.
/// Isticmaalka Gobolka ee xasuusta ku qortay sida `T` uu ku jiro qiimaha khaldan ee `T` waa dhaqan undefined.
///
/// Xusuusnow in xitaa haddii cabirka wax ku oolka ah la koobiyay (``tiriyo * cabbir_of: :<T>()`) Waa `0`, tilmaamaha waa in ay ahaadaan kuwa aan waxba si fiican u safan.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Abuuritaanka qiime aan ansax ahayn:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Daadinayo qiimaha uu horay u hayey overwriting `Box<T>` la pointer waxba a.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Halkaa marka ay marayso, iyadoo la isticmaalayo ama hoos natiijada `v` dabeecadda undefined.
/// // drop(v); // ERROR
///
/// // Xitaa daadinta `v` "uses" waa, oo markaa waa dabeecad aan la qeexin.
/// // mem::forget(v); // ERROR
///
/// // Xaqiiqdii, `v` waa mid aan ansax ahayn marka loo eego noocyada aasaasiga ah ee isbeddelayayaasha, marka *hawlgal* kasta oo taabanaya waa dabeecad aan la qeexin.
/////
/// // ha u baneeyo v2 =v;//KHALAD
///
/// unsafe {
///     // Ha noo ahaanaysaa riday qiimo sax ah
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Hadda sanduuqa waa hagaagsan yahay
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // BADBAADADA: heshiiska nabadgelyada ee `write_bytes` waa inuu ilaaliyaa qofka soo wacaya.
    unsafe { write_bytes(dst, val, count) }
}