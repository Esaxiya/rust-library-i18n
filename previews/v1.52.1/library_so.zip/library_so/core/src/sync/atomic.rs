//! Noocyada atomiga
//!
//! Noocyada Atomiga waxay bixiyaan isgaarsiinta xasuusta wadaagga ah ee udhaxeysa dunta, waana dhismooyinka noocyada kale ee isku midka ah.
//!
//! Sawirkan waxa uu qeexayaa versions qaaradda ka mid ah tiro ka mid dooro noocyada heer hoose ah, oo ay ku jiraan [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], iwm
//! noocyada Atoomikada hawlgallada joogo in, marka si sax ah loo isticmaalo, updates waafajinta dhexeeya threads.
//!
//! Hab kastaa wuxuu qaadaa [`Ordering`] oo matalaya xoogga ciladaha xusuusta ee hawlgalkaas.Amaradaani waxay lamid yihiin [C++20 atomic orderings][1].Wixii macluumaad dheeraad ah ka eeg [nomicon][2] ah.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! doorsoomayaasha Atoomikada yihiin ammaan si ay u wadaagaan dhexeeya threads (ay hirgeliyaan [`Sync`]) laakiin waxay ahaayeen naftooda ma samayn siiyaan hab ay for sharing oo raaca [threading model](../../../std/thread/index.html#the-threading-model) of Rust.
//!
//! Habka ugu badan oo ay ku wadaagaan variable ah qaaradda waa inuu dhex geliyaa [`Arc`][arc] ah (pointer ah atomically-tixraac-tirin la wadaago).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Noocyada Atomiga waxaa lagu kaydin karaa isbeddelayaal ma guurto ah, oo la bilaabay iyadoo la adeegsanayo kuwa wax bilaaba ee joogtada ah sida [`AtomicBool::new`].statics Atoomikada waxaa inta badan loo isticmaalaa initialization caalamka caajis.
//!
//! # Portability
//!
//! Dhammaan noocyada qaaradda buuggan ayaa la hubaa inay noqon [lock-free] haddii ay tahay heli karo.Taas macnaheedu waxa weeye, ma gudaha u bartaan mutex caalami ah.Noocyada Atomiga iyo hawlgallada looma balan qaadayo inay ka sugnaan doonaan sugitaan la`aan.
//! Tani waxay ka dhigan tahay in hawlgallada sida `fetch_or` oo kale ah lagu fulin karo iswaafajin-iyo-wareejin.
//!
//! hawlgallada Atoomikada la fulin karaa lakabka edbinta la atomics weyn-size.Tusaale ahaan meheradaha qaarkood waxay adeegsadaan tilmaamaha atomiga 4-byte ah si ay u hirgeliyaan `AtomicI8`.
//! Ogsoonow in ku dayashadaani aysan aheyn inay saameyn ku yeelato saxnaanta lambarka, waa uun wax laga warqabo.
//!
//! Noocyada atomiga ee ku jira qaybtaan waxaa laga yaabaa inaan laga helin dhammaan meerayaasha.Noocyada atomiga ee halkan ku yaal dhammaantood si ballaadhan ayaa loo heli karaa, si kastaba ha noqotee, guud ahaanna waxaa lagu tashan karaa jira.Qaar ka mid ah marka laga reebo caan ah waa:
//!
//! * PowerPC iyo barnaamijyada MIPS oo leh 32-bit tilmaamayaal malaha noocyada `AtomicU64` ama `AtomicI64`.
//! * ARM barxadaha sida `armv5te` ee aan ahayn Linux kaliya waxay bixiyaan hawlgallada `load` iyo `store`, mana taageeraan howlaha Isbarbardhiga iyo Isweydaarsiga (CAS), sida `swap`, `fetch_add`, iwm.
//! Intaa waxaa dheer on Linux, hawlgallada CAS, kuwaas oo la fuliyo via [operating system support], kaas oo rigoore qaab iman karaan.
//! * ARM bartilmaameedyada la `thumbv6m` bixiyaan oo kaliya hawlaha `load` iyo `store`, hana taageera hawlaheeda Isbarbardhigga iyo isku bedelasho (CAS), sida `swap`, `fetch_add`, iwm
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Ogow in dhufto ee future laga yaabaa in lagu daray in sidoo kale aan haysan taageero qaar ka mid ah hawlaha qaaradda.Maximally code qaadi karo baahan doontaa in aad ka taxadartaa ku saabsan noocyada qaaradda waxaa loo isticmaalaa.
//! `AtomicUsize` iyo `AtomicIsize` guud ahaan waa kuwa la qaadi karo, laakiin xitaa markaa meel walba lagama heli karo.
//! Tixraac ahaan, maktabadda `std` waxay u baahan tahay atomik cabbirkoodu sarreeyo, in kastoo `core` uusan rabin.
//!
//! Waqtigan xaadirka ah waxaad u baahan doontaa inaad adeegsato `#[cfg(target_arch)]` ugu horreyntii si shardi ah aad ugu soo uruuriso lambarka atomikadaWaxaa jira `#[cfg(target_has_atomic)]` oo aan degganeyn sidoo kale kaas oo lagu xasilin karo future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Wareeg fudud:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Sug mawduuca kale inuu sii daayo qufulka
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Hayso tirinta adduunka ee mawduucyada tooska ah:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// nooca boolean A taas oo si ammaan ah la wadaago karaa inta u dhaxaysa threads.
///
/// Noocani wuxuu leeyahay matalaad xusuusta oo la mid ah [`bool`].
///
/// **Xusuusin**: Noocaan waxaa laga heli karaa oo keliya meheradaha taageeraya culeyska atomiga iyo dukaamada `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Waxay abuurtaa `AtomicBool` lagu bilaabay `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send waxaa si dadban fulin waayo AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// A nooca pointer cayriin oo si ammaan ah la wadaago karaa inta u dhaxaysa threads.
///
/// Noocani wuxuu leeyahay matalaad xusuusta oo la mid ah `*mut T`.
///
/// **Xusuusin**: Noocaan waxaa laga heli karaa oo keliya meheradaha taageera culeyska atomiga iyo dukaamada tilmaamayaasha.
/// Baaxaddiisu waxay kuxirantahay cabirka tilmaamaha cabirkiisa.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Waxay abuurtaa `AtomicPtr<T>` aan waxba ka jirin
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Amarada xasuusta Atomiga
///
/// Amarada xusuusta waxay cadeynayaan sida hawlgalada atomku u waafajiyaan xusuusta.
/// [`Ordering::Relaxed`]-keeda ugu daciifka ah, kaliya xusuusta si toos ah u taabata qalliinka ayaa la waafajinayaa.
/// Dhinaca kale, labada nin dukaan-load hawlgallada [`Ordering::SeqCst`] ah waafajinta xasuusta kale halka wixii intaa Dhawrista amar guud ee hawlaha sida dhamaan threads.
///
///
/// awowgood xasuusta Rust waa [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Wixii macluumaad dheeraad ah eeg [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Caqabado dalban malahan, kaliya howlaha atomiga.
    ///
    /// Waxay u dhigantaa [`memory_order_relaxed`] gudaha C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Marka ay weheliyaan dukaan, dhammaan hawlgallada hore noqoto amar ku hor load ka mid ah qiimaha la [`Acquire`] (ama xoog) xigsiin.
    ///
    /// Gaar ahaan, dhammaan ayuu qoray wargayska hore noqdaan la arki karo oo dhan threads in oofin [`Acquire`] ah (ama ka xoog) load of qiimaha this.
    ///
    /// Ogsoonow in adeegsiga amarkan hawlgal isku darka culeysyada iyo dukaamada ay horseed u tahay hawl xamuul x00X ah!
    ///
    /// Amarkani wuxuu khuseeyaa oo keliya hawlgallada samayn kara dukaan.
    ///
    /// U dhiganta [`memory_order_release`] in C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Marka lagu daro xamuul, haddii qiimaha la raray uu qoray hawlgal dukaan oo ay la socoto [`Release`] (ama ka xoog badan) dalbashada, ka dib dhammaan hawlgallada ku xiga ayaa la dalbanayaa dukaankaas ka dib.
    /// Gaar ahaan, dhammaan xamuulka soo socda waxay arki doonaan xogta lagu qoray dukaanka hortiisa.
    ///
    /// Ogsoonow in adeegsiga amarkan ee hawlgal isku dhafan culeysyo iyo dukaamo ay horseed u tahay hawl dukaanka [`Relaxed`]!
    ///
    /// Amarkani wuxuu khuseeyaa oo keliya hawlgallada fulin kara culeys.
    ///
    /// U dhiganta [`memory_order_acquire`] in C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Miyuu saamaynta wada [`Acquire`] iyo [`Release`] labadaba:
    /// Waayo, naf dhibkeed u adeegsanayaa xigsiin [`Acquire`].Waayo, dukaamada waxa uu u adeegsanayaa xigsiin [`Release`] ah.
    ///
    /// Notice in ay dhacdo `compare_and_swap`, waxaa macquul ah in hawlgalka kor u dhamaado uma muuqdaan dukaanka kasta oo halkan waxa ay leedahay oo keliya xigsiin [`Acquire`].
    ///
    /// Si kastaba ha ahaatee, `AcqRel` marnaba samayn doonaa Furidda [`Relaxed`].
    ///
    /// Amarkani wuxuu khuseeyaa oo keliya hawlgallada isku daraya culeysyada iyo dukaamada.
    ///
    /// U dhiganta [`memory_order_acq_rel`] in C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Like [`Acquire`]/[`Release`]/[`AcqRel`], (waayo, load, dukaanka, iyo load-la-dukaanka hawlgallada, siday u kala horreeyaan) la damaanad dheeraad ah oo dhan threads oo dhan arkaynin hawlgallada sequentially joogto ah si la mid ah .
    ///
    ///
    /// U dhiganta [`memory_order_seq_cst`] in C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] ayaa lagu bilaabay `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Waxay abuurtaa `AtomicBool` cusub.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Ku soo celiyaa tixraac la beddeli karo salka [`bool`].
    ///
    /// Tani waa amaan maxaa yeelay tixraaca la beddeli karo ayaa dammaanad ka qaadaya in dunyo kale aysan isla markaa marin u helin xogta atomiga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // AMMAANKA: tixraaca mutable damaanad lahaanshaha gaar ah.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Hel marin atomik ah `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // AMMAANKA: tixraaca mutable damaanad lahaanshaha gaarka ah, iyo
        // in lays labada `bool` iyo `Self` waa 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Wuxuu cunaa atomiga wuxuuna soo celiyaa qiimaha kujira.
    ///
    /// Tani waa amaan maxaa yeelay ku dhaafida `self` qiime ahaan waxay damaanad qaadeysaa inaysan jirin xargo kale oo si isku mid ah u helaya xogta atomiga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Xamuulka qiimaha ka bool ah.
    ///
    /// `load` qaadataa dood [`Ordering`] ah oo qeexeysa amar bixinta xusuusta ee hawlgalkan.
    /// qiimaha macquulka ah waa [`SeqCst`], [`Acquire`] iyo [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics haddii `order` uu yahay [`Release`] ama [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // AMMAANKA: kasta jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda iyo cayriin ah
        // tilmaamaha la soo gudbiyay ayaa sax ah maxaa yeelay waxaan ka helnay tixraac.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Kaydiya qiimaha ah oo wuxuu galay bool ah.
    ///
    /// `store` qaadataa dood [`Ordering`] ah oo qeexeysa amar bixinta xusuusta ee hawlgalkan.
    /// Qiimaha suuragalka ah waa [`SeqCst`], [`Release`] iyo [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics haddii `order` waa [`Acquire`] ama [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // AMMAANKA: kasta jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda iyo cayriin ah
        // tilmaamaha la soo gudbiyay ayaa sax ah maxaa yeelay waxaan ka helnay tixraac.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Waxay ku keydisaa qiime bool, oo soo celineysa qiimihii hore.
    ///
    /// `swap` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
    /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
    ///
    ///
    /// **Note:** Qaabkan waxaa laga heli karaa oo keliya meheradaha taageera hawlgallada atomiga ee `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Waxay ku kaydineysaa qiimo [`bool`] haddii qiimaha hadda uu la mid yahay qiimaha `current`.
    ///
    /// qiimaha laabashada had iyo jeer waa qiimaha hore.Haddii ay u dhigantaa `current`, markaa qiimaha waa la cusbooneysiiyay.
    ///
    /// `compare_and_swap` sidoo kale waxay qaadataa dood [`Ordering`] ah oo sharraxaysa amarka xusuusta ee hawlgalkan.
    /// Ogsoonow in xitaa markaad isticmaaleyso [`AcqRel`], qalliinka laga yaabo inuu fashilmo oo markaa kaliya la sameeyo xamuulka `Acquire`, laakiin uusan lahayn `Release` semantics.
    /// Isticmaalka [`Acquire`] waxay ka dhigeysaa dukaanka qeyb ka mid ah qalliinkan [`Relaxed`] haddii ay dhacdo, iyo isticmaalka [`Release`] wuxuu ka dhigayaa qaybta xamuulka [`Relaxed`].
    ///
    /// **Note:** Qaabkan waxaa laga heli karaa oo keliya meheradaha taageera hawlgallada atomiga ee `u8`.
    ///
    /// # U haajirida `compare_exchange` iyo `compare_exchange_weak`
    ///
    /// `compare_and_swap` waxay u dhigantaa `compare_exchange` oo leh khariidadaynta soo socota ee xusuusta la dalbanayo:
    ///
    /// Asal |Guul |Ka gaabinta
    /// -------- | ------- | -------
    /// Nasasho |Nasasho |Hesho Nasasho |Hesho |Helitaan Siidayn |Release |Dabacsan AcqRel |AcqRel |La helo SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` waxaa loo ogol yahay in ay ku guul darreysato unkay xitaa marka la barbardhigo ku guulaysto, kaas oo u ogolaanaya compiler si wanaagsan dhalin shirka code marka is barbar dhig iyo isku bedelasho ah waxaa loo isticmaalaa in loop a.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Waxay ku kaydineysaa qiimo [`bool`] haddii qiimaha hadda uu la mid yahay qiimaha `current`.
    ///
    /// Qiimaha soo laabtay ayaa ka dhashay oo muujinaysa in qiimaha cusub ee la qoray oo ay ku jirto qiimaha hore.
    /// Guul ahaan qiimahan waxaa loo balan qaadayaa inuu la mid yahay `current`.
    ///
    /// `compare_exchange` qaadataa laba dood [`Ordering`] in lagu qeexo xigsiin xusuusta ee hawlgalka this ah.
    /// `success` wuxuu sharaxayaa amarka loo baahan yahay ee hawlgalka aqrinta-wax ka beddelka-qoritaanka ee dhacaya haddii isbarbar dhiga `current` uu guuleysto.
    /// `failure` wuxuu sharaxayaa dalabka loo baahan yahay ee hawlgalka xamuulka ee dhacaya marka isbarbardhiggu fashilmo.
    /// Isticmaalka [`Acquire`] sida xigsiin guul ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] dhigaysa load guul [`Relaxed`].
    ///
    /// Dalbashada guuldaradu waxay noqon kartaa oo kaliya [`SeqCst`], [`Acquire`] ama [`Relaxed`] waana inay u dhigantaa ama ka daciifaysaa amarka guusha.
    ///
    /// **Note:** Qaabkan waxaa laga heli karaa oo keliya meheradaha taageera hawlgallada atomiga ee `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Waxay ku kaydineysaa qiimo [`bool`] haddii qiimaha hadda uu la mid yahay qiimaha `current`.
    ///
    /// Si ka duwan [`AtomicBool::compare_exchange`], shaqadan waxaa loo oggol yahay inay si aan macquul ahayn u fashilanto xitaa marka isbarbardhiggu guuleysto, taas oo ka dhalan karta koodh wax ku ool ah meelaha qaarkood.
    ///
    /// Qiimaha soo laabtay ayaa ka dhashay oo muujinaysa in qiimaha cusub ee la qoray oo ay ku jirto qiimaha hore.
    ///
    /// `compare_exchange_weak` qaadataa laba dood [`Ordering`] in lagu qeexo xigsiin xusuusta ee hawlgalka this ah.
    /// `success` wuxuu sharaxayaa amarka loo baahan yahay ee hawlgalka aqrinta-wax ka beddelka-qoritaanka ee dhacaya haddii isbarbar dhiga `current` uu guuleysto.
    /// `failure` wuxuu sharaxayaa dalabka loo baahan yahay ee hawlgalka xamuulka ee dhacaya marka isbarbardhiggu fashilmo.
    /// Isticmaalka [`Acquire`] sida xigsiin guul ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] dhigaysa load guul [`Relaxed`].
    /// Dalbashada guuldaradu waxay noqon kartaa oo kaliya [`SeqCst`], [`Acquire`] ama [`Relaxed`] waana inay u dhigantaa ama ka daciifaysaa amarka guusha.
    ///
    /// **Note:** Qaabkan waxaa laga heli karaa oo keliya meheradaha taageera hawlgallada atomiga ee `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Caqli gal ah "and" oo leh qiime goolal ah.
    ///
    /// Waxay ku qabataa hawl "and" macquul ah qiimaha hadda jira iyo dooda `val`, waxayna dejineysaa qiimaha cusub natiijada.
    ///
    /// Sooceliyaa qiimaha hore.
    ///
    /// `fetch_and` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
    /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
    ///
    ///
    /// **Note:** Qaabkan waxaa laga heli karaa oo keliya meheradaha taageera hawlgallada atomiga ee `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Caqli gal ah "nand" oo leh qiime goolal ah.
    ///
    /// Waxay ku qabataa hawl "nand" macquul ah qiimaha hadda jira iyo dooda `val`, waxayna dejineysaa qiimaha cusub natiijada.
    ///
    /// Sooceliyaa qiimaha hore.
    ///
    /// `fetch_nand` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
    /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
    ///
    ///
    /// **Note:** Qaabkan waxaa laga heli karaa oo keliya meheradaha taageera hawlgallada atomiga ee `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Waxaan uma isticmaali karo atomic_nand halkan sababtoo ah waxa ay keeni kartaa in bool leh qiimaha khaldan.
        // Tani waxay dhacdaa sababtoo ah hawlgalka qaaradda lagu sameeyaa abyoonaha 8-bit ah gudaha, taas oo ka dhigi doonta in 7 gelinno sare.
        //
        // Sidaas oo kaliya aan u isticmaalno fetch_xor ama isku bedelasho ah halkii.
        if val {
            // (X&run)== !x Waa in aan invert bool ah.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&been)==run Waa inaan u dhigno bool run.
            //
            self.swap(true, order)
        }
    }

    /// Caqli gal ah "or" oo leh qiime goolal ah.
    ///
    /// Matalaa ah hawlgalka "or" macquul ah oo ku saabsan qiimaha hadda jira iyo wax xuja ah `val`, iyo nooc qiimaha cusub in natiijada.
    ///
    /// Sooceliyaa qiimaha hore.
    ///
    /// `fetch_or` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
    /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
    ///
    ///
    /// **Note:** Qaabkan waxaa laga heli karaa oo keliya meheradaha taageera hawlgallada atomiga ee `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" macquul ah leh qiimaha boolean.
    ///
    /// Waxay ku qabataa hawl "xor" macquul ah qiimaha hadda jira iyo dooda `val`, waxayna dejineysaa qiimaha cusub natiijada.
    ///
    /// Sooceliyaa qiimaha hore.
    ///
    /// `fetch_xor` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
    /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
    ///
    ///
    /// **Note:** Qaabkan waxaa laga heli karaa oo keliya meheradaha taageera hawlgallada atomiga ee `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Sooceliyaa Daliil mutable in [`bool`] salka.
    ///
    /// Ku sameynta akhrinta iyo qorista non-atomiga ee kudhaca tirada isku dhafan waxay noqon kartaa tartan xog ah.
    /// Habkani inta badan waxtar buu u leeyahay FFI, halkaasoo saxeexa hawshu u isticmaali karo `*mut bool` halkii uu ka isticmaali lahaa `&AtomicBool`.
    ///
    /// Soo celinta tilmaamaha `*mut` ee tixraaca la wadaago ee atomkan waa aamin maxaa yeelay noocyada atomiga waxay ku shaqeeyaan isbadal gudaha ah.
    /// All badalitaan isbedel ah qaaradda qiimaha iyada oo tixraac la wadaago, iyo samayn karaa si ammaan ah inta ay isticmaali hawlgallada qaaradda.
    /// Isticmaalka mid ka mid ah tilmaamaha ugu soo laabtay cayriin baahan yahay block `unsafe` ah iyo weli in ay ilaaliyaan xanibaad la mid ah: hawlgallada waxa on waa in ay ahaadaan qaaradda.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Landcruiser qiimaha, iyo ku shaqayn ah in celinta ah qiimaha cusub optional.Sooceliyaa `Result` ah `Ok(previous_value)` haddii function soo celiyey `Some(_)`, kale `Err(previous_value)`.
    ///
    /// Note: Tani waxay ugu yeeri kartaa shaqada dhowr jeer haddii qiimaha laga beddelay mawduucyada kale inta u dhexeysa, illaa iyo inta ay shaqadu soo noqoneyso `Some(_)`, laakiin howsha waxaa lagu dabaqi doonaa hal mar oo keliya qiimaha la keydiyay.
    ///
    ///
    /// `fetch_update` qaadataa laba dood [`Ordering`] in lagu qeexo xigsiin xusuusta ee hawlgalka this ah.
    /// Midkii kowaad wuxuu u qeexayaa gagadoonka looga baahan yahay marka qaliinka ugu dambeyntii ku guuleysto, halka kii labaad wuxuu qeexayaa gagadoonka looga baahan yahay xamuulka.
    /// Kuwani waxay u dhigmaan guusha iyo guul darrooyinka [`AtomicBool::compare_exchange`] siday u kala horreeyaan.
    ///
    /// Isticmaalka [`Acquire`] sida xigsiin guul ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] dhigaysa load finalka guul [`Relaxed`].
    /// The xigsiin load (failed) noqon karaa oo kaliya [`SeqCst`], [`Acquire`] ama [`Relaxed`] iyo waa in ay ahaadaan u dhiganta ama ka nugul yihiin dalbashada guusha.
    ///
    /// **Note:** Qaabkan waxaa laga heli karaa oo keliya meheradaha taageera hawlgallada atomiga ee `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Waxay abuurtaa `AtomicPtr` cusub.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Waxay ku celineysaa tixraaca isbeddelaya ee tilmaamaha salka ku haya.
    ///
    /// Tani waa amaan maxaa yeelay tixraaca la beddeli karo ayaa dammaanad ka qaadaya in dunyo kale aysan isla markaa marin u helin xogta atomiga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Hel marin atomik tilmaame.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - tixraaca mutable damaanad lahaanshaha gaar ah.
        //  - isku waafajinta `*mut T` iyo `Self` waa isku mid dhammaan meheradaha ay taageerayaan rust, sida kor lagu caddeeyay.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Wuxuu cunaa atomiga wuxuuna soo celiyaa qiimaha kujira.
    ///
    /// Tani waa amaan maxaa yeelay ku dhaafida `self` qiime ahaan waxay damaanad qaadeysaa inaysan jirin xargo kale oo si isku mid ah u helaya xogta atomiga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Xamuulka qiimaha ka tilmaamaha.
    ///
    /// `load` qaadataa dood [`Ordering`] ah oo qeexeysa amar bixinta xusuusta ee hawlgalkan.
    /// qiimaha macquulka ah waa [`SeqCst`], [`Acquire`] iyo [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics haddii `order` uu yahay [`Release`] ama [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Waxay ku kaydisaa qiimeeyaha tilmaamaha.
    ///
    /// `store` qaadataa dood [`Ordering`] ah oo qeexeysa amar bixinta xusuusta ee hawlgalkan.
    /// Qiimaha suuragalka ah waa [`SeqCst`], [`Release`] iyo [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics haddii `order` waa [`Acquire`] ama [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Wuxuu ku kaydiyaa qiime tilmaame, isagoo soo celinaya qiimihii hore.
    ///
    /// `swap` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
    /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
    ///
    ///
    /// **Note:** Habkani waxaa kaliya laga heli karaa meheradaha taageera hawlgallada atomiga ee tilmaamayaasha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Kaydiya qiimaha ah oo wuxuu galay pointer haddii qiimaha hadda waa isku mid sida qiimaha `current` ah.
    ///
    /// qiimaha laabashada had iyo jeer waa qiimaha hore.Haddii ay u dhigantaa `current`, markaa qiimaha waa la cusbooneysiiyay.
    ///
    /// `compare_and_swap` sidoo kale waxay qaadataa dood [`Ordering`] ah oo sharraxaysa amarka xusuusta ee hawlgalkan.
    /// Ogsoonow in xitaa markaad isticmaaleyso [`AcqRel`], qalliinka laga yaabo inuu fashilmo oo markaa kaliya la sameeyo xamuulka `Acquire`, laakiin uusan lahayn `Release` semantics.
    /// Isticmaalka [`Acquire`] waxay ka dhigeysaa dukaanka qeyb ka mid ah qalliinkan [`Relaxed`] haddii ay dhacdo, iyo isticmaalka [`Release`] wuxuu ka dhigayaa qaybta xamuulka [`Relaxed`].
    ///
    /// **Note:** Habkani waxaa kaliya laga heli karaa meheradaha taageera hawlgallada atomiga ee tilmaamayaasha.
    ///
    /// # U haajirida `compare_exchange` iyo `compare_exchange_weak`
    ///
    /// `compare_and_swap` waxay u dhigantaa `compare_exchange` oo leh khariidadaynta soo socota ee xusuusta la dalbanayo:
    ///
    /// Asal |Guul |Ka gaabinta
    /// -------- | ------- | -------
    /// Nasasho |Nasasho |Hesho Nasasho |Hesho |Helitaan Siidayn |Release |Dabacsan AcqRel |AcqRel |La helo SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` waxaa loo ogol yahay in ay ku guul darreysato unkay xitaa marka la barbardhigo ku guulaysto, kaas oo u ogolaanaya compiler si wanaagsan dhalin shirka code marka is barbar dhig iyo isku bedelasho ah waxaa loo isticmaalaa in loop a.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Kaydiya qiimaha ah oo wuxuu galay pointer haddii qiimaha hadda waa isku mid sida qiimaha `current` ah.
    ///
    /// Qiimaha soo laabtay ayaa ka dhashay oo muujinaysa in qiimaha cusub ee la qoray oo ay ku jirto qiimaha hore.
    /// Guul ahaan qiimahan waxaa loo balan qaadayaa inuu la mid yahay `current`.
    ///
    /// `compare_exchange` qaadataa laba dood [`Ordering`] in lagu qeexo xigsiin xusuusta ee hawlgalka this ah.
    /// `success` wuxuu sharaxayaa amarka loo baahan yahay ee hawlgalka aqrinta-wax ka beddelka-qoritaanka ee dhacaya haddii isbarbar dhiga `current` uu guuleysto.
    /// `failure` wuxuu sharaxayaa dalabka loo baahan yahay ee hawlgalka xamuulka ee dhacaya marka isbarbardhiggu fashilmo.
    /// Isticmaalka [`Acquire`] sida xigsiin guul ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] dhigaysa load guul [`Relaxed`].
    ///
    /// Dalbashada guuldaradu waxay noqon kartaa oo kaliya [`SeqCst`], [`Acquire`] ama [`Relaxed`] waana inay u dhigantaa ama ka daciifaysaa amarka guusha.
    ///
    /// **Note:** Habkani waxaa kaliya laga heli karaa meheradaha taageera hawlgallada atomiga ee tilmaamayaasha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Kaydiya qiimaha ah oo wuxuu galay pointer haddii qiimaha hadda waa isku mid sida qiimaha `current` ah.
    ///
    /// Si ka duwan [`AtomicPtr::compare_exchange`], shaqadan waxaa loo oggol yahay inay si aan macquul ahayn u fashilanto xitaa marka isbarbardhiggu guuleysto, taas oo ka dhalan karta koodh wax ku ool ah meelaha qaarkood.
    ///
    /// Qiimaha soo laabtay ayaa ka dhashay oo muujinaysa in qiimaha cusub ee la qoray oo ay ku jirto qiimaha hore.
    ///
    /// `compare_exchange_weak` qaadataa laba dood [`Ordering`] in lagu qeexo xigsiin xusuusta ee hawlgalka this ah.
    /// `success` wuxuu sharaxayaa amarka loo baahan yahay ee hawlgalka aqrinta-wax ka beddelka-qoritaanka ee dhacaya haddii isbarbar dhiga `current` uu guuleysto.
    /// `failure` wuxuu sharaxayaa dalabka loo baahan yahay ee hawlgalka xamuulka ee dhacaya marka isbarbardhiggu fashilmo.
    /// Isticmaalka [`Acquire`] sida xigsiin guul ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] dhigaysa load guul [`Relaxed`].
    /// Dalbashada guuldaradu waxay noqon kartaa oo kaliya [`SeqCst`], [`Acquire`] ama [`Relaxed`] waana inay u dhigantaa ama ka daciifaysaa amarka guusha.
    ///
    /// **Note:** Habkani waxaa kaliya laga heli karaa meheradaha taageera hawlgallada atomiga ee tilmaamayaasha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // BADBAADADA: Muhiimaddaani waa mid aan aamin ahayn maxaa yeelay waxay ku shaqeysaa tilmaame cayriin
        // laakiin waxaan si hubaal ah u ognahay in tilmaamuhu ansax yahay (waxaan hadda ka helnay `UnsafeCell` oo aan ku haysanno tixraac) hawlgalka atomiga laftiisuna wuxuu noo oggolaanayaa inaan si ammaan ah u beddelno waxyaabaha ku jira `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Landcruiser qiimaha, iyo ku shaqayn ah in celinta ah qiimaha cusub optional.Sooceliyaa `Result` ah `Ok(previous_value)` haddii function soo celiyey `Some(_)`, kale `Err(previous_value)`.
    ///
    /// Note: Tani waxay ugu yeeri kartaa shaqada dhowr jeer haddii qiimaha laga beddelay mawduucyada kale inta u dhexeysa, illaa iyo inta ay shaqadu soo noqoneyso `Some(_)`, laakiin howsha waxaa lagu dabaqi doonaa hal mar oo keliya qiimaha la keydiyay.
    ///
    ///
    /// `fetch_update` qaadataa laba dood [`Ordering`] in lagu qeexo xigsiin xusuusta ee hawlgalka this ah.
    /// Midkii kowaad wuxuu u qeexayaa gagadoonka looga baahan yahay marka qaliinka ugu dambeyntii ku guuleysto, halka kii labaad wuxuu qeexayaa gagadoonka looga baahan yahay xamuulka.
    /// Kuwani waxay u dhigmaan guusha iyo guul darrooyinka [`AtomicPtr::compare_exchange`] siday u kala horreeyaan.
    ///
    /// Isticmaalka [`Acquire`] sida xigsiin guul ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] dhigaysa load finalka guul [`Relaxed`].
    /// The xigsiin load (failed) noqon karaa oo kaliya [`SeqCst`], [`Acquire`] ama [`Relaxed`] iyo waa in ay ahaadaan u dhiganta ama ka nugul yihiin dalbashada guusha.
    ///
    /// **Note:** Habkani waxaa kaliya laga heli karaa meheradaha taageera hawlgallada atomiga ee tilmaamayaasha.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// U rogaa `bool` una beddelaa `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Tani Dhaqale darafyadiisa ilaa isagoo aan la isticmaalin on naqshadaba qaar ka mid ah.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Nooc inteeroole ah oo si ammaan ah loo wadaagi karo inta u dhexeysa dunta.
        ///
        /// Noocani wuxuu leeyahay matalaad xusuusta oo lamid ah nooca isku-dhafan ee hoose, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Wixii faahfaahin dheeraad ah ee ku saabsan farqiga u dhexeeya noocyada atomiga iyo noocyada aan atomiga ahayn iyo sidoo kale macluumaadka ku saabsan qaadista noocaan ah, fadlan eeg [module-level documentation].
        ///
        ///
        /// **Note:** Noocaan waxaa laga heli karaa oo keliya on dhufto ee taageera xamuulka qaaradda wuxuuna ku kaydiyey [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// abyoonaha An qaaradda initialized in `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Soo dir si toos ah ayaa loo hirgaliyay.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Waxay abuurtaa a abyoonaha cusub qaaradda.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Ku soo celiyaa tixraac la beddeli karo isku-xidhka hoose.
            ///
            /// Tani waa amaan maxaa yeelay tixraaca la beddeli karo ayaa dammaanad ka qaadaya in dunyo kale aysan isla markaa marin u helin xogta atomiga.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// ha u beddelo xoogaa_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// sheeg sheeg! (xoogaa_galin, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - tixraaca mutable damaanad lahaanshaha gaar ah.
                //  - in lays ee `$int_type` iyo `Self` waa isku mid, sida yaboohay by $cfg_align iyo xaqiijin kor ku xusan.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Wuxuu cunaa atomiga wuxuuna soo celiyaa qiimaha kujira.
            ///
            /// Tani waa amaan maxaa yeelay ku dhaafida `self` qiime ahaan waxay damaanad qaadeysaa inaysan jirin xargo kale oo si isku mid ah u helaya xogta atomiga.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Xamuulka qiimaha ka abyoonaha ah qaaradda.
            ///
            /// `load` qaadataa dood [`Ordering`] ah oo qeexeysa amar bixinta xusuusta ee hawlgalkan.
            /// qiimaha macquulka ah waa [`SeqCst`], [`Acquire`] iyo [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics haddii `order` uu yahay [`Release`] ama [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Waxay ku keydisaa qiime isku-dhafka atomiga ah.
            ///
            /// `store` qaadataa dood [`Ordering`] ah oo qeexeysa amar bixinta xusuusta ee hawlgalkan.
            ///  Qiimaha suuragalka ah waa [`SeqCst`], [`Release`] iyo [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics haddii `order` waa [`Acquire`] ama [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Kaydiya qiimaha ah oo wuxuu galay abyoonaha ah qaaradda, soo laabtay qiimaha hore.
            ///
            /// `swap` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
            /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
            ///
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Kaydiya qiimaha ah oo wuxuu galay abyoonaha ah qaaradda haddii qiimaha hadda waa isku mid sida qiimaha `current` ah.
            ///
            /// qiimaha laabashada had iyo jeer waa qiimaha hore.Haddii ay u dhigantaa `current`, markaa qiimaha waa la cusbooneysiiyay.
            ///
            /// `compare_and_swap` sidoo kale waxay qaadataa dood [`Ordering`] ah oo sharraxaysa amarka xusuusta ee hawlgalkan.
            /// Ogsoonow in xitaa markaad isticmaaleyso [`AcqRel`], qalliinka laga yaabo inuu fashilmo oo markaa kaliya la sameeyo xamuulka `Acquire`, laakiin uusan lahayn `Release` semantics.
            ///
            /// Isticmaalka [`Acquire`] waxay ka dhigeysaa dukaanka qeyb ka mid ah qalliinkan [`Relaxed`] haddii ay dhacdo, iyo isticmaalka [`Release`] wuxuu ka dhigayaa qaybta xamuulka [`Relaxed`].
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # U haajirida `compare_exchange` iyo `compare_exchange_weak`
            ///
            /// `compare_and_swap` waxay u dhigantaa `compare_exchange` oo leh khariidadaynta soo socota ee xusuusta la dalbanayo:
            ///
            /// Asal |Guul |Ka gaabinta
            /// -------- | ------- | -------
            /// Nasasho |Nasasho |Hesho Nasasho |Hesho |Helitaan Siidayn |Release |Dabacsan AcqRel |AcqRel |La helo SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` waxaa loo ogol yahay in ay ku guul darreysato unkay xitaa marka la barbardhigo ku guulaysto, kaas oo u ogolaanaya compiler si wanaagsan dhalin shirka code marka is barbar dhig iyo isku bedelasho ah waxaa loo isticmaalaa in loop a.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Kaydiya qiimaha ah oo wuxuu galay abyoonaha ah qaaradda haddii qiimaha hadda waa isku mid sida qiimaha `current` ah.
            ///
            /// Qiimaha soo laabtay ayaa ka dhashay oo muujinaysa in qiimaha cusub ee la qoray oo ay ku jirto qiimaha hore.
            /// Guul ahaan qiimahan waxaa loo balan qaadayaa inuu la mid yahay `current`.
            ///
            /// `compare_exchange` qaadataa laba dood [`Ordering`] in lagu qeexo xigsiin xusuusta ee hawlgalka this ah.
            /// `success` wuxuu sharaxayaa amarka loo baahan yahay ee hawlgalka aqrinta-wax ka beddelka-qoritaanka ee dhacaya haddii isbarbar dhiga `current` uu guuleysto.
            /// `failure` wuxuu sharaxayaa dalabka loo baahan yahay ee hawlgalka xamuulka ee dhacaya marka isbarbardhiggu fashilmo.
            /// Isticmaalka [`Acquire`] sida xigsiin guul ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] dhigaysa load guul [`Relaxed`].
            ///
            /// Dalbashada guuldaradu waxay noqon kartaa oo kaliya [`SeqCst`], [`Acquire`] ama [`Relaxed`] waana inay u dhigantaa ama ka daciifaysaa amarka guusha.
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Kaydiya qiimaha ah oo wuxuu galay abyoonaha ah qaaradda haddii qiimaha hadda waa isku mid sida qiimaha `current` ah.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// shaqo taas waxaa loo ogol yahay in ay ku guul darreysato unkay xitaa marka la barbardhigo ku guulaysto, taas oo keeni kartaa in code ku ool ah ku dhufto ee qaar ka mid ah.
            /// Qiimaha soo laabtay ayaa ka dhashay oo muujinaysa in qiimaha cusub ee la qoray oo ay ku jirto qiimaha hore.
            ///
            /// `compare_exchange_weak` qaadataa laba dood [`Ordering`] in lagu qeexo xigsiin xusuusta ee hawlgalka this ah.
            /// `success` wuxuu sharaxayaa amarka loo baahan yahay ee hawlgalka aqrinta-wax ka beddelka-qoritaanka ee dhacaya haddii isbarbar dhiga `current` uu guuleysto.
            /// `failure` wuxuu sharaxayaa dalabka loo baahan yahay ee hawlgalka xamuulka ee dhacaya marka isbarbardhiggu fashilmo.
            /// Isticmaalka [`Acquire`] sida xigsiin guul ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] dhigaysa load guul [`Relaxed`].
            ///
            /// Dalbashada guuldaradu waxay noqon kartaa oo kaliya [`SeqCst`], [`Acquire`] ama [`Relaxed`] waana inay u dhigantaa ama ka daciifaysaa amarka guusha.
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// ha duugoobo= val.load(Ordering::Relaxed);
            /// loop {ha cusub=duug * 2;
            ///     u dhigma val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Waxay ku dareysaa qiimaha hadda jira, iyagoo soo celinaya qiimihii hore.
            ///
            /// Hawlgalkani wuxuu ku wareegsan yahay qulqulka.
            ///
            /// `fetch_add` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
            /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
            ///
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Ka jaro qiimaha hadda jira, oo soo celinaya qiimihii hore.
            ///
            /// Hawlgalkani wuxuu ku wareegsan yahay qulqulka.
            ///
            /// `fetch_sub` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
            /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
            ///
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" oo leh qiimaha hadda jira.
            ///
            /// Matalaa a bitwise "and" hawlgalka on qiimaha hadda jira iyo wax xuja ah `val`, iyo nooc qiimaha cusub in natiijada.
            ///
            /// Sooceliyaa qiimaha hore.
            ///
            /// `fetch_and` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
            /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
            ///
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" oo leh qiimaha hadda jira.
            ///
            /// Waxay qabataa hawl yar oo ah "nand" qiimaha hadda jira iyo dooda `val`, waxayna dejineysaa qiimaha cusub natiijada.
            ///
            /// Sooceliyaa qiimaha hore.
            ///
            /// `fetch_nand` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
            /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
            ///
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ((0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" oo leh qiimaha hadda jira.
            ///
            /// Matalaa a bitwise "or" hawlgalka on qiimaha hadda jira iyo wax xuja ah `val`, iyo nooc qiimaha cusub in natiijada.
            ///
            /// Sooceliyaa qiimaha hore.
            ///
            /// `fetch_or` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
            /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
            ///
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" leh qiimaha hadda.
            ///
            /// Waxay ku qabataa hawl yar oo "xor" ah qiimaha hadda jira iyo dooda `val`, waxayna dejineysaa qiimaha cusub natiijada.
            ///
            /// Sooceliyaa qiimaha hore.
            ///
            /// `fetch_xor` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
            /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
            ///
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Landcruiser qiimaha, iyo ku shaqayn ah in celinta ah qiimaha cusub optional.Sooceliyaa `Result` ah `Ok(previous_value)` haddii function soo celiyey `Some(_)`, kale `Err(previous_value)`.
            ///
            /// Note: Tani waxay ugu yeeri kartaa shaqada dhowr jeer haddii qiimaha laga beddelay mawduucyada kale inta u dhexeysa, illaa iyo inta ay shaqadu soo noqoneyso `Some(_)`, laakiin howsha waxaa lagu dabaqi doonaa hal mar oo keliya qiimaha la keydiyay.
            ///
            ///
            /// `fetch_update` qaadataa laba dood [`Ordering`] in lagu qeexo xigsiin xusuusta ee hawlgalka this ah.
            /// Midka koowaad wuxuu qeexayaa amarka loo baahan yahay marka hawlgalku ugu dambayn guuleysto halka kan labaad uu qeexayo dalbashada xamuulka.Kuwani waxay u dhigmaan amarada guusha iyo fashilka ee
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Isticmaalka [`Acquire`] sida xigsiin guul ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] dhigaysa load finalka guul [`Relaxed`].
            /// The xigsiin load (failed) noqon karaa oo kaliya [`SeqCst`], [`Acquire`] ama [`Relaxed`] iyo waa in ay ahaadaan u dhiganta ama ka nugul yihiin dalbashada guusha.
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq (x.fetch_update (Dalbashada: : SeqCst, Ordering::SeqCst, |! x | Some(x + 1)), Ok(7));
            /// assert_eq (x.fetch_update (Dalbashada: : SeqCst, Ordering::SeqCst, |! x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Ugu badnaan la qiimaha hadda.
            ///
            /// Raadiyaa ugu badnaan qiimaha hadda jira iyo muran `val` ah, iyo sharxayaa qiimaha cusub in natiijada.
            ///
            /// Sooceliyaa qiimaha hore.
            ///
            /// `fetch_max` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
            /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
            ///
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ha bar=42;
            /// sii daa max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// sheeg! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Ugu yar qiimaha hadda jira.
            ///
            /// Raadiyaa ugu yar ee qiimaha hadda jira iyo muran `val` ah, iyo sharxayaa qiimaha cusub in natiijada.
            ///
            /// Sooceliyaa qiimaha hore.
            ///
            /// `fetch_min` qaadataa dood [`Ordering`] ah oo qeexaysa amar bixinta xusuusta ee hawlgalkan.Dhammaan qaababka dalbashada waa suurtagal.
            /// Ogow in la isticmaalayo [`Acquire`] ka dhigaysa qayb dukaanka hawlgalka this [`Relaxed`] ah, iyo isticmaalka [`Release`] ka dhigaysa qayb Xamuulka [`Relaxed`].
            ///
            ///
            /// **Ogoow**: Habkani waa la heli karaa oo keliya on dhufto ee taageera hawlaha qaaradda on
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// daa bar=12;
            /// ha min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// ! Assert_eq (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // AMMAANKA: jinsiyadaha xogta waxaa looga hortagi by intrinsics qaaradda.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Ku soo celiyaa tilmaame isbeddelaya isugeynta hoose.
            ///
            /// Ku sameynta akhrinta iyo qorista non-atomiga ee kudhaca tirada isku dhafan waxay noqon kartaa tartan xog ah.
            /// Habkani inta badan waxtar buu u leeyahay FFI, halkaas oo saxeexa hawshu isticmaali karo
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Soo celinta tilmaamaha `*mut` ee tixraaca la wadaago ee atomkan waa aamin maxaa yeelay noocyada atomiga waxay ku shaqeeyaan isbadal gudaha ah.
            /// All badalitaan isbedel ah qaaradda qiimaha iyada oo tixraac la wadaago, iyo samayn karaa si ammaan ah inta ay isticmaali hawlgallada qaaradda.
            /// Isticmaalka mid ka mid ah tilmaamaha ugu soo laabtay cayriin baahan yahay block `unsafe` ah iyo weli in ay ilaaliyaan xanibaad la mid ah: hawlgallada waxa on waa in ay ahaadaan qaaradda.
            ///
            ///
            /// # Examples
            ///
            /// Iska dheji (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// bannaanka "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // BADBAADADA: Waa ammaan inta `my_atomic_op` yahay atom.
            /// aan aamin ahayn
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Sooceliyaa qiimihii hore (sida __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Soocelisaa qiimihii hore (sida __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// soo celiyaa qiimaha ugu badan (isbarbar dhig saxiixan)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // AMMAANKA: wacaha waa in ay ilaaliyaan heshiiska ammaanka `atomic_max` ah
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// soo celiyaa qiimaha min (isbarbar dhig saxiixan)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// soo celiyaa qiimaha ugu badan (isbarbar dhig aan la saxiixin)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// soo celiyaa qiimaha min (isbarbardhiga aan saxeexnayn)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Xayndaab atom ah.
///
/// Iyada oo ku xidhan amarka la cayimay, xayndaabku wuxuu ka horjoogsadaa isku-duwaha iyo processor-ka inay dib u laaban karaan noocyo ka mid ah hawlgallada xusuusta ee ku hareeraysan.
/// Taasi waxay abuureysaa isku-xirnaan-xiriiryo ka dhexeeya iyo hawlgallada atomiga ama xayndaabyada mawduucyada kale.
///
/// Xaydaanka 'A' oo leh (uguyaraan) [`Release`] oo amraya semantic, wuxuu kudhex egyahay xayndaabka 'B' oo leh (uguyaraan) [`Acquire`] semantics, hadii iyo hadii kaliya ay jiraan hawlgalo X iyo Y, labaduba waxay ku shaqeeyaan shey yar oo atomic ah 'M' sida tan oo kale A ayaa horay looxakameeyay X, Y waa la waafajinayaa kahor B iyo Y waxay u kuur galayaan M.
/// Tani waxay bixisaa dhacdo-kahor ku tiirsanaanta A iyo B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// hawlgallada Atoomikada la kelmedo [`Release`] ama [`Acquire`] sidoo kale waafajinta karaa teed.
///
/// Xayndaab leh [`SeqCst`] oo dalbanaya, marka lagu daro lahaanshaha labadaba [`Acquire`] iyo [`Release`], wuxuu ka qaybqaataa nidaamka barnaamijka caalamiga ah ee hawlgallada kale ee [`SeqCst`] iyo/ama deyrka.
///
/// Wuxuu aqbalaa dalabyada [`Acquire`], [`Release`], [`AcqRel`] iyo [`SeqCst`].
///
/// # Panics
///
/// Panics haddii `order` uu yahay [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Ka-saaris wada-jir ah oo ku saleysan wareegga wareegga.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Sug ilaa qiimaha duugga ahi yahay `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Xayndaabkan ayaa iswaafajinaya-dukaanka ku yaal `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // AMMAANKA: adeegsiga xayndaabka atomku waa ammaan.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Xayndaabka xusuusta isu geeyo.
///
/// `compiler_fence` ma dhaadheer kasta oo code mashiinka, laakiin wuxuu xadidayaa noocyada xasuusta dib-u-amro compiler ah loo ogol yahay in ay sameeyaan.Gaar ahaan, iyadoo ku xiran kelmedo [`Ordering`] siiyey, compiler la diiday waxaa laga yaabaa in ka dhaqaaqaan akhriya ama qoray ka hor ama ka dib markii call si ay dhinaca kale ee call si `compiler_fence` ka.Ogsoonow inaysan **ka hor istaageynin* qalabka * inuu sameeyo dib-u-dalbashada sidan oo kale ah.
///
/// Tani maaha wax dhibaato ah in hal-ku dhafnaa, macnaha dil ah, laakiin markii threads kale ka beddeli laga yaabaa in xasuusta waqti isku mid ah, primitives .Wadashaqayntaas xoog sida [`fence`] waxaa looga baahan yahay.
///
/// dib-u-xigsiin The hortagi by ee kelmedo xigsiin kala duwan yihiin:
///
///  - leh [`SeqCst`], dib uma dalbeyn akhrinta iyo qorista qodobkaan oo dhan lama oggola.
///  - leh [`Release`], aqrinta iyo qorista kahoreysa lama dhaqaajin karo qoraaladii xigay.
///  - iyadoo la raacayo [`Acquire`], akhriska iyo qorista soo socota lama dhaqaajin karo ka hor aqrinta hore.
///  - leh [`AcqRel`], labada qawaani ee kor ku xusan ayaa la fuliyaa.
///
/// `compiler_fence` guud ahaan waxtar ayey u leedahay oo keliya ka-hortagga dunta la tartanta *lafteeda*.Taasi waa, haddii xariiq la siiyay uu fulinayo hal xabbo oo koodh ah, ka dibna la joojiyo, oo uu bilaabo inuu meel kale ka hirgeliyo koodh (isagoo weli ku jira isla isku midka, iyo feker ahaan weli isla xudunta).Barnaamijyada soojireenka ah, tani waxay dhici kartaa oo keliya markii la diiwaangeliyo aalad isha ku haysa.
/// In ka badan code heerka hoose, xaaladaha sida kartaa sidoo kale kac marka galisa, marka la fulinayo threads cagaaran leh pre-emption, iwm
/// Akhristayaasha xiisaha leh waxaa lagu dhiirigelinayaa inay akhriyaan doodaha kernel ee Linux ee [memory barriers].
///
/// # Panics
///
/// Panics haddii `order` uu yahay [`Relaxed`].
///
/// # Examples
///
/// Aan `compiler_fence`, `assert_eq!` ee soo socda code waa *aan* ballan qaaday inay ku guuleystaan, inkastoo wax walba oo ka dhacaya hal dun.
/// Si aad u aragto sababta, xusuusnow in isku-duwaha uu xor u yahay in dukaamada loo kala beddelo `IMPORTANT_VARIABLE` iyo `IS_READ` maadaama ay labaduba yihiin `Ordering::Relaxed`.Haddii ay dhacdo, iyo Handler signal la gawraco midig ka dib markii `IS_READY` waa la cusboonaysiiyaa, ka dibna Handler signalka arki doonaa `IS_READY=1`, laakiin `IMPORTANT_VARIABLE=0`.
/// Isticmaalka daawooyinka `compiler_fence` xaaladdan.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // ka ilaali qoraalada hore in laga gudbo halkaan
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // AMMAANKA: adeegsiga xayndaabka atomku waa ammaan.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Calaamadaha processor-ka inay ku jiraan gudaha mashquul sugid wareejin ah ("wareejinta wareejinta").
///
/// Shaqadani waa mid hoos loo dhigay iyada oo loo rogay [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}