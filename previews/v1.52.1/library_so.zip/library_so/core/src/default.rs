//! `Default` trait noocyada laga yaabo inay leeyihiin qiimayaal asal ah oo macno leh.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait loogu talagalay nooc siinta adeeg qiimo qiimo leh.
///
/// Mararka qaarkood, aad rabto in aad dib u dhacaan nooc ka mid ah qiimaha default, iyo gaar ahaan ma kala jecli waxa ay tahay.
/// Tani waxay kor u yimaado inta badan la `struct`s in la qeexo go'an fursado:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Sideen u qeexi karnaa qaar ka mid ah qiimaha aasaasiga ah?Waxaad isticmaali kartaa `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Hadda, waxaad heleysaa dhammaan qiimaha caadiga ah.Rust fulisaa `Default` noocyada primitives kala duwan.
///
/// Haddii aad rabto inaad ka takhalusto ikhtiyaar gaar ah, laakiin weli hayso astaamaha kale:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// trait waxaa loo isticmaali karaa `#[derive]` haddii dhammaan noocyada noocyadu ay hirgeliyaan `Default`.
/// Marka `derive`d, u isticmaali doonaa qiimaha default nooca beerta kasta ah.
///
/// ## Sideen ku hirgelin karaa `Default`?
///
/// Bixi hirgelinta habka `default()` ee soo celinaya qiimaha noocaaga oo noqon lahaa kan ugu sarreeya:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Sooceliyaa "default value" nooc.
    ///
    /// Qiimayaasha asalka ah ayaa badanaa nooc ka mid ah qiimaha bilowga ah, qiimaha aqoonsiga, ama wax kasta oo kale oo macno ahaan u samayn kara.
    ///
    ///
    /// # Examples
    ///
    /// Isticmaalka qiyamka aasaasiga ah ee la dhisay:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Sameynta naftaada:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Ku noqo qiimaha default of nooc ka mid ah sida ay trait `Default` ah.
///
/// Nooca loo soo Celin waxaa hubo laga eego macnaha;tani waxay u dhigantaa `Default::default()` laakiin gaaban ayaa loo qoraa.
///
/// Tusaale ahaan:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Dhalinta makro oo soosaara impl ah trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }