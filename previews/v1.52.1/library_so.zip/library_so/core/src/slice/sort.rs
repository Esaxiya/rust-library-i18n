//! Kala sooc jeex
//!
//! Sawirkan waxa uu ka kooban yahay isku geynta kala sooca ku salaysan quicksort naqshad-jabinta Orson Peters ', la daabacay ee: <https://github.com/orlp/pdqsort>
//!
//!
//! Kala soocida xasilloonida waxay la jaan qaadi kartaa libcore sababtoo ah ma qoondeyso xusuusta, oo ka duwan hirgelinta kala soocida xasilloon.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Marka hoos, nuqul ka `src` galay `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // BADBAADADA: Kani waa fasal caawiya.
        //          Fadlan tixraac ay isticmaalka loogu talagalay sax.
        //          Magac ahaan, qofku waa inuu hubiyaa in `src` iyo `dst` aysan isdhaafsanayn sida ay ubaahantahay `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Cunsurka kowaad wuxuu u wareejiyaa dhanka midig ilaa uu lakulmo cunsur ka weyn ama lamid ah.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // AMMAANKA: Hawlgallada aan sugnayn ee hoos ku xusan waxay ku lug leeyihiin tixraac la'aan iyada oo aan la hubin jeeg (`get_unchecked` iyo `get_unchecked_mut`)
    // iyo koobiyeynta xusuusta (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Waxaan hubinay cabirka xarfaha>=2.
    //  2. tusmaynta dhan waannu wada yeeli doonnaa had iyo jeer waa u dhexeeya {0 <= index < len} ugu badnaan.
    //
    // b.Nuqul nuqulka
    //  1. Waxaan heleynaa tilmaamayaal tixraacyo la hubo inay ansax yihiin.
    //  2. Iyagu iskama soo dhaafi karaan maxaa yeelay waxaan helnay tilmaamayaal farqiga u dhexeeya jajabka.
    //     Magac ahaan, `i` iyo `i-1`.
    //  3. Haddii jeexdu si sax ah isugu habboon tahay, canaasiirta si habboon ayaa loo waafajiyaa.
    //     Waa wacaha ayaa mas'uul ka ah si loo hubiyo cad waxaa si fiican u safan.
    //
    // Eeg faallooyinka hoose si aad u hesho faahfaahin dheeraad ah.
    unsafe {
        // Haddii labada xubno hore waa out-of-si ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Read element ugu horeysay galay variable raso-qoondeeyey a.
            // Haddii hawlgal ka dib markii la barbardhigo panics, `hole` aad hoos doonaa oo si toos ah u qori dib element galay jeex ah.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // U dhaqaaq ``i`-th element hal meel oo dhanka bidix ah, markaa daloolka dhanka midig.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` hoos ayuu u dhacaa sidaas awgeedna wuxuu nuquliyaa `tmp` godka haray ee `v`.
        }
    }
}

/// Gelinba element la soo dhaafay bidixda ilaa ay ka horyimaadeen element a yar ama loo siman yahay.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // AMMAANKA: Hawlgallada aan sugnayn ee hoos ku xusan waxay ku lug leeyihiin tixraac la'aan iyada oo aan la hubin jeeg (`get_unchecked` iyo `get_unchecked_mut`)
    // iyo koobiyeynta xusuusta (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Waxaan hubinay cabirka xarfaha>=2.
    //  2. Dhamaan tusmooyinka aan sameyn doono waa had iyo jeer inta udhaxeysa `0 <= index < len-1`.
    //
    // b.Nuqul nuqulka
    //  1. Waxaan heleynaa tilmaamayaal tixraacyo la hubo inay ansax yihiin.
    //  2. Iyagu iskama soo dhaafi karaan maxaa yeelay waxaan helnay tilmaamayaal farqiga u dhexeeya jajabka.
    //     Magac ahaan, `i` iyo `i+1`.
    //  3. Haddii jeexdu si sax ah isugu habboon tahay, canaasiirta si habboon ayaa loo waafajiyaa.
    //     Waa wacaha ayaa mas'uul ka ah si loo hubiyo cad waxaa si fiican u safan.
    //
    // Eeg faallooyinka hoose si aad u hesho faahfaahin dheeraad ah.
    unsafe {
        // Haddii labada xubno la soo dhaafay waa out-of-si ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Akhriso cunsurka ugu dambeeya ee doorsoomaha qoondeysan.
            // Haddii hawlgal ka dib markii la barbardhigo panics, `hole` aad hoos doonaa oo si toos ah u qori dib element galay jeex ah.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // U dhaqaaq ``i`-th element hal meel oo dhinaca midigta ah, sidaasna godka bidix ugu weecinaya.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` hoos ayuu u dhacaa sidaas awgeedna wuxuu nuquliyaa `tmp` godka haray ee `v`.
        }
    }
}

/// Qayb dhunsan jeex ah by wareegaayo dhowr cunsur-ka-si ku wareegsan.
///
/// Soocelinayaa `true` haddii cad cad loo kala soocayo dhamaadka.function Tani waa *O*(*n*) ugu xun-case.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Tirada ugu badan ee ku xiga laba laba-ka-si aad wareejiyay doonaa.
    const MAX_STEPS: usize = 5;
    // Haddii jeexdu ka gaaban tahay tan, ha u wareegin waxyaabo kasta.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // BADBAADADA: Waxaan horeyba si cad ugu sameynay baaritaanka xarka leh `i < len`.
        // All our tusmaynta xiga waa kaliya in kala duwan ee `0 <= index < len`
        unsafe {
            // Raadi labada soo socda qaybaha xiga out-of-si.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Miyaynu dhammaynay?
        if i == len {
            return true;
        }

        // Ha ku wareejin walxaha qaababka gaaban, ee leh kharash waxqabadka ah.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Kala beddel canaasiirta la helay.Tani waxay ka dhigeysaa iyaga nidaam sax ah.
        v.swap(i - 1, i);

        // Baddalo element yar bidixda.
        shift_tail(&mut v[..i], is_less);
        // U wareeji qaybta weyn dhinaca midig.
        shift_head(&mut v[i..], is_less);
    }

    // Maanan maamulin kala-soocidda tirada tallaabooyinka xaddidan.
    false
}

/// Cayn jeex ah oo isticmaalaya galinta sort, taas oo ah *O*(*n*^ 2)-kiiska ugu xumaa.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Kala sooca `v` adoo adeegsanaya qalab culus, kaas oo dammaanad qaadaya *O*(*n*\*log(* n*))-kiiskii ugu xumaa.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Taalladan laba-geesoodka ahi waxay ixtiraamaysaa isbeddel la'aanta `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Carruurta `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Dooro ilmaha weyn.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Jooji haddii invariant ku haya at `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Kala beddel `node` cunugga weyn, u dhaqaaq hal tallaabo hoos u sii wad, isla markaana sii wad shaandhaynta.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Dhismo taallo waqtiga toosan.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Ka soo saar qodobbada ugu badan
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Maqaal qoruhu `v` galay xubno ka yar `pivot`, raaceen by canaasiirta ka weyn tahay ama simanyihiin inay `pivot`.
///
///
/// Waxay soo celisaa tirada xubno ka yar `pivot`.
///
/// Partitioning waxaa la sameeyaa block-by-block si loo yareeyo kharashka branching hawlgallada.
/// Fikraddan waxaa lagu soo bandhigay warqadda [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Tirada walxaha ku jira baloogga caadiga ah.
    const BLOCK: usize = 128;

    // Kala soocidda algorithm waxay ku celcelisaa tallaabooyinka soo socda illaa dhammaystirka:
    //
    // 1. Raadi baloog dhinaca bidix ah si aad u ogaato cunsur ka weyn ama u dhigma udub-dhexaadka.
    // 2. Raad block a dhankeeda midigta si ay u aqoonsadaan xubno ka yar pivot ah.
    // 3. Isweydaarso waxyaabaha la aqoonsaday ee u dhexeeya bidix iyo midig.
    //
    // Waxaan u haynaa doorsoomayaasha soo socda xaddiga walxaha:
    //
    // 1. `block` - Tirada cunsurrada ku jira dhismaha.
    // 2. `start` - Bilow pointer gelin isugu soo `offsets` ah.
    // 3. `end` - End pointer gelin isugu soo `offsets` ah.
    // 4. 'dejinta', Tusmooyinka waxyaabaha ka baxsan amar-bixinta ee ku dhex jira guriga.

    // Xannibaadda hadda ku taal dhinaca bidix (laga bilaabo `l` illaa `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Xannibaadda hadda ku taal dhinaca midig (laga bilaabo `r.sub(block_r)` to `r`).
    // BADBAADADA: Dukumiintiyada loogu talagalay .add() waxay si gaar ah u xusayaan in `vec.as_ptr().add(vec.len())` had iyo jeer uu badbaado yahay '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Markii aan helno VLAs, iskuday inaad sameysid hal nooc oo dherer ah `min(v.len(), 2 * BLOCK) `` halkii
    // ka badan laba Arrays go'an-size of dhererka `BLOCK`.VLAs ayaa laga yaabaa inay ka waxtar badan yihiin kaydinta.

    // Sooceliyaa tirada walxaha u dhexeeya tilmaamayaasha `l` (inclusive) iyo `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Waxaan ku dhammeynay kala-saarid qayb-goos ah markii `l` iyo `r` aad isugu soo dhowaadaan.
        // Haddaba, waxaan sameeyo qaar ka mid ah shaqada jaan-up si ay u Risaalo xubno ka haray ee u dhexeeya.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Number of xubno ka haray (weli ma la barbar dhigo pivot ah).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Dheellitir cabbirrada baloogga si bidixda iyo bidixda midig aysan isugu soo laaban, laakiin si fiican u la jaan qaado si aad u daboosho dhammaan farqiga haray.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Trace `block_l` xubno ka dhanka bidix.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // BADBAADADA: Hawlgallada nabadgelyo darrada ah ee hoos ku xusan waxay ku lug leeyihiin adeegsiga `offset`.
                //         Marka loo eego shuruudaha shaqada looga baahan yahay, waanu ku qanacsan nahay maxaa yeelay:
                //         1. `offsets_l` ayaa loo qoondeeyey, sidaas awgeedna loo tixgeliyaa walax gaar ah oo loo qoondeeyey.
                //         2. Shaqada `is_less` waxay soo celisaa `bool`.
                //            Ridaya `bool` ah marnaba la buuxdhaafi doonaan `isize`.
                //         3. Waxaan damaanad qaadnay in `block_l` uu noqon doono `<= BLOCK`.
                //            Waxaa intaa sii dheer, `end_l` markii hore waxaa loo dejiyay tilmaamaha bilawga ah ee `offsets_` kaas oo lagu dhawaaqay xiritaanka.
                //            Sidaas darteed, waxaynu og nahay in xitaa ay dhacdo ugu xumaa (oo dhan ducadaas of `is_less` laabtay been ah) waxaan noqon doonaa oo keliya ugu badnaan 1 byte mari dhammaadka.
                //        Hawlgal kale oo aan ammaan ahayn halkan ayaa laga xusayaa `elem`.
                //        Si kastaba ha noqotee, `elem` wuxuu markii hore ahaa bilawga tilmaamida jeexitaanka kaas oo had iyo jeer ansax ah.
                unsafe {
                    // Isbarbar dhig la'aanta.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Raadi walxaha `block_r` ee dhinaca midig.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // BADBAADADA: Hawlgallada nabadgelyo darrada ah ee hoos ku xusan waxay ku lug leeyihiin adeegsiga `offset`.
                //         Marka loo eego shuruudaha shaqada looga baahan yahay, waanu ku qanacsan nahay maxaa yeelay:
                //         1. `offsets_r` ayaa loo qoondeeyey, sidaas awgeedna loo tixgeliyaa walax gaar ah oo loo qoondeeyey.
                //         2. Shaqada `is_less` waxay soo celisaa `bool`.
                //            Ridaya `bool` ah marnaba la buuxdhaafi doonaan `isize`.
                //         3. Waxaan damaanad qaadnay in `block_r` uu noqon doono `<= BLOCK`.
                //            Waxaa intaa sii dheer, `end_r` markii hore waxaa loo dejiyay tilmaamaha bilawga ah ee `offsets_` kaas oo lagu dhawaaqay xiritaanka.
                //            Marka, waxaan ognahay in xitaa xaalada ugu xun (dhammaan codsiyada `is_less` ay run ku soo noqdaan) waxaan kaliya ugu badnaan ahaan doonaa 1 byte dhamaadka.
                //        Hawlgal kale oo aan ammaan ahayn halkan ayaa laga xusayaa `elem`.
                //        Si kastaba ha ahaatee, `elem` markii hore ahaa `1 *sizeof(T)` ee la soo dhaafay dhammaadka oo waannu halwareegto by `1* sizeof(T)` ka hor inta helitaanka.
                //        Waxaa intaa sii dheer, `block_r` waxaa la cadeeyay inuu ka yar yahay `BLOCK` iyo `elem` ayaa ugu badnaan tilmaameysa bilowga jeexitaanka.
                unsafe {
                    // Isbarbar dhig la'aanta.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Tirada walxaha amarka ka baxsan si ay isugu dhaafsadaan dhanka bidix iyo midig.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Halkii lagu kala beddeli lahaa labada lamaane waqtigaas, way ka waxtar badan tahay in la sameeyo xinjir wareeg ah.
            // Tani si adag uma dhigna beddelidda, laakiin waxay soo saartaa natiijo isku mid ah iyadoo la adeegsanayo hawlgallada xusuusta oo yar.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Dhamaan xubno ka out-of-si block tagay laga dhaqaajiyey.U gudub xayndaabka xiga.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Dhamaan xubno ka out-of-amarka in xisbiyada garabka midig ayaa u dhaqaaqay.U dhaqaaq dhanka hore.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // All in hadhaagii hadda waa ugu badnaan hal block (labada bidix ama midig) oo la cunsur-ka-si baahida loo qabo in la dhaqdhaqaajiyo.
    // Waxyaalaha noocan ah ee hadhay waxaa si fudud loogu wareejin karaa dhamaadka gudaha xayndaabkooda.
    //

    if start_l < end_l {
        // Baloogga bidix ayaa weli ah.
        // U wareeji cunsurradeeda harsan amar-midigta midig.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Xannibaadda saxda ah ayaa weli ah.
        // Dhaqaaq haray xubno ay-ka-si aad u fog ka tagay.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Wax kale oo la sameeyo, waanu dhamaynay.
        width(v.as_mut_ptr(), l)
    }
}

/// Qeybinta `v` oo loo raro cunsurro ka yar `v[pivot]`, waxaa ku xiga cunsurro ka weyn ama u dhigma `v[pivot]`.
///
///
/// Sooceliyaa tuple ka mid ah:
///
/// 1. Number of xubno ka yar `v[pivot]`.
/// 2. Run haddii `v` horey loo qaybiyey.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Dhig pivot ee bilowga ah ee cad.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Read pivot galay variable raso-qoondeeyay hufnaan ah.
        // Haddii hawlgal ka dib markii la barbardhigo panics, pivot waxaa si otomaatik ah qori doonaa dib jeex ah.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Raadi walxaha ugu horreeya ee ka-amar-la`aanta.
        let mut l = 0;
        let mut r = v.len();

        // AMMAANKA: unsafety hoos ku lug tusmaynta diyaariyeen ah.
        // Waayo, mid ugu horeysay, waxaana hore u samayn soohdin halkan la `l < r` hubinta.
        // Waayo, mid labaad: Waxaan marka hore ay leeyihiin `l == 0` iyo `r == v.len()` oo aan hubiyaa `l < r` in hawlgal kasta oo tusmaynta.
        //                     Halkan waxaan ka ogaaneynaa in `r` ay tahay inuu ahaado ugu yaraan `r == l` taas oo la muujiyay inay ansax tahay tan koowaad.
        unsafe {
            // Raadi weyn ugu horeysay element ka badan ama simanyihiin inay pivot ah.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Soo hel curiyaha ugu dambeeya ee udub-dhexaadka u ah.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` baxa baaxadda iyo qoray pivot ah (taas oo ah variable raso-qoondeeyey a) dib jeex halkaas oo markii hore ahaa.
        // Tallaabadani waxay muhiim u tahay sugidda amniga!
        //
    };

    // Dhex dhig udub-dhexaadka labada qaybood.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Qeybinta `v` oo u dhiganta cunsurro u dhigma `v[pivot]` oo ay ku xigto xubno ka weyn `v[pivot]`.
///
/// Sooceliyaa tirada cunsurrada ee udub-dhexaadka u ah.
/// Waxaa la malaysan in `v` kuma jiraan xubno ka yar pivot ah.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Dhig pivot ee bilowga ah ee cad.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Read pivot galay variable raso-qoondeeyay hufnaan ah.
    // Haddii hawlgal ka dib markii la barbardhigo panics, pivot waxaa si otomaatik ah qori doonaa dib jeex ah.
    // BADBAADADA: Tilmaamaha halkan ayaa ansax ah maxaa yeelay waxaa laga helay tixraac jeex ah.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Hadda xijaab jeex.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // AMMAANKA: unsafety hoos ku lug tusmaynta diyaariyeen ah.
        // Waayo, mid ugu horeysay, waxaana hore u samayn soohdin halkan la `l < r` hubinta.
        // Waayo, mid labaad: Waxaan marka hore ay leeyihiin `l == 0` iyo `r == v.len()` oo aan hubiyaa `l < r` in hawlgal kasta oo tusmaynta.
        //                     Halkan waxaan ka ogaaneynaa in `r` ay tahay inuu ahaado ugu yaraan `r == l` taas oo la muujiyay inay ansax tahay tan koowaad.
        unsafe {
            // Soo hel cunsurka koowaad ee ka weyn udub-dhexaadka.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Soo hel curiyaha ugu dambeeya ee u dhigma udub-dhexaadka.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Miyaynu dhammaynay?
            if l >= r {
                break;
            }

            // Kala beddel canaasiirta la helay ee canshuuraha ka baxsan.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Waxaan helnay xubno `l` ah oo u dhigma udub-dhexaadka.Ku dar 1 si aad ugula xisaabtamto udub-weynaha laftiisa.
    l + 1

    // `_pivot_guard` baxa baaxadda iyo qoray pivot ah (taas oo ah variable raso-qoondeeyey a) dib jeex halkaas oo markii hore ahaa.
    // Tallaabadani waxay muhiim u tahay sugidda amniga!
}

/// Wuxuu kala firdhiyaa qaybo ka mid ah isku dayga ah inuu jebiyo qaababka sababi kara kala qaybsanaan la'aanta habka degdegga ah.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Tirada Pseudorandom matoor ka warqad "Xorshift RNGs" ah by George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Qaado nambarro nasiib ah oo loo yaqaan 'modulo' lambarkan.
        // qallalku Tirada galay `usize` maxaa yeelay `len` kama weyna `isize::MAX`.
        let modulus = len.next_power_of_two();

        // musharax pivot Qaar ka mid ah noqon doona ee u dhow ee index this.Aynu kala soocno.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Abuuri karo tiro random modulo `len`.
            // Si kastaba ha ahaatee, si looga fogaado hawlgallada qaali ah in aan marka hore qaado waxaa modulo xoog ah laba, ka dibna hoos by `len` ilaa ay ugu aadayso kala duwan ee `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` waxaa loo balan qaadayaa inuu kayaryahay `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Doortaa pivot ah `v` iyo celinta index iyo `true` haddii jeex ah waxa laga yaabaa inay hore u kala soocaa.
///
/// Qaybaha in `v` laga yaabaa in reordered in geeddi-socodka.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Dhererka ugu yar si loo doorto habka dhexdhexaadka-dhexdhexaadka.
    // Kalagoynta gaagaaban waxay adeegsadaan habka dhexdhexaadka-of-saddex ah.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Tirada ugu badan ee isku bedelashada in la samayn karaa in shaqo this.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Saddex indices oo dhow oo aan dooran doonno udub dhexaad.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Wuxuu tirinayaa tirada guud ee isku beddelka aan sameyn doonno inta aan kala soocno indices.
    let mut swaps = 0;

    if len >= 8 {
        // Bedelashada indices si `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Swaps indices si `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Raadiyaa dhexdhexaadka ah ee `v[a - 1], v[a], v[a + 1]` iyo dukaamada index galay `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Raadi medians ee xaafadaha `a`, `b`, iyo `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Ka hel bartamaha dhexdiisa `a`, `b`, iyo `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Tirada ugu badan ee isku bedelashada ayaa la sameeyaa.
        // Fursadaha ayaa ah in jeexdu ay soo degayso ama inta badan soo degayso, markaa dib u rogista ayaa laga yaabaa inay gacan ka geysato kala-soocidda si dhakhso leh.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Noocyada `v` soo noqnoqda.
///
/// Haddii jeex uu lahaa horreeyay a soo diyaariyeen asalka ah, waxaa lagu tilmaamaa sida `pred`.
///
/// `limit` waa tirada loo oggol yahay qoruhu isku dheelitirka ka hor inta aan loo wareegin `heapsort`.
/// Hadday eber tahay, shaqadani waxay isla markiiba u beddeleysaa goob culus.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Xaleef ilaa karaa dhererka this soocaa isticmaalaya sort galinta.
    const MAX_INSERTION: usize = 20;

    // Run haddii kala qaybsanaantii ugu dambaysay ay si macquul ah isu dheellitirtay.
    let mut was_balanced = true;
    // Run haddii qaybtii ugu dambaysay aysan shubeynin walxaha (jeexjeexa horay ayaa looqeexay).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Googooyo aad u gaagaaban ayaa lagu kala saaraa iyadoo la isticmaalayo nooca gelinta.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Haddii doorashooyin aad u badan pivot xun loo sameeyey, si fudud u dhici back to heapsort si ay u damaanad `O(n * log(n))` xun ee.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Haddii qaybinta ugu dambaysa ay isu dheellitirnayn, iskuday inaad ku jabiso qaababka jajabka adigoo isku shaandheyn ku sameynaya qaar ka mid ah waxyaabaha ku xeeran.
        // Waxaan rajeyneynaa inaan dooran doonno udub-dhexaad ka wanaagsan markan.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Xullo udub dhexaad iskuna day inaad maleyso in gogosha horay loo kala soocay iyo in kale.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Haddii qaybinta ugu dambaysay ay ahayd mid si miisaaman isu dheellitiran oo aan isku shaandheyn xubno, iyo haddii xulashada muhiimada ay saadaaliso in jeexdu ay u badan tahay in horey loo kala saaray ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Isku day aqoonsashada dhowr cunsur out-of-dambaynta iyo iyaga wareegaayo in jagooyinka ay sax.
            // Haddii darafyadiisa jeex ilaa la gabi ahaanba kala soocaa, aan sameeyey.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Haddii udubka la doortay uu la mid yahay kii ka horreeyay, markaa waa qaybta ugu yar ee ku jirta jeex.
        // Qaybi jeex qaybo ka mid ah walxaha u dhigma iyo walxaha ka weyn udub-dhexaadka.
        // Kiiskan badanaa waa la garaacaa marka jeexku ka kooban yahay waxyaabo badan oo nuqul ah.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Sii wad kala soocida walxaha ka weyn udub-dhexaadka.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Risaalo jeex ah.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Kala jabeen jeex ka galay `left`, `pivot`, iyo `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurse galay dhinaca gaaban oo keliya si loo yareeyo tirada guud ee wicitaanada recursive oo ha baabbi'iyo meel yar xidhmooyin.
        // Kadib sii wad dhinaca dheer (tani waxay la mid tahay dib u soo noqoshada dabada).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Cayn `v` isticmaalaya quicksort naqshad-jabinta, taas oo ah *O*(*n*\*log(* n*)) xun ee.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kala soocidu malahan dabeecad macno leh noocyada qiyaasta eber-ka ah.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Xaddid tirada qaybaha aan dheellitirnayn ee `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Xaleefyada ilaa dhererkaan waxaa laga yaabaa inay ka dhakhso badan tahay in si fudud loo kala sooco.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Xulo udub dhexaad
        let (pivot, _) = choose_pivot(v, is_less);

        // Haddii udubka la doortay uu la mid yahay kii ka horreeyay, markaa waa qaybta ugu yar ee ku jirta jeex.
        // Qaybi jeex qaybo ka mid ah walxaha u dhigma iyo walxaha ka weyn udub-dhexaadka.
        // Kiiskan badanaa waa la garaacaa marka jeexku ka kooban yahay waxyaabo badan oo nuqul ah.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Haddii aan dhaafnay tixraackeena, markaa waan fiicanahay.
                if mid > index {
                    return;
                }

                // Haddii kale, sii wad kala soocida walxaha ka weyn udub-dhexaadka.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Kala jabeen jeex ka galay `left`, `pivot`, iyo `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Haddii mid==index, markaa waan dhammeynay, tan iyo markii partition() uu dammaanad qaaday in dhammaan walxaha ka dambeeya bartamaha ay ka weyn yihiin ama la mid yihiin bartamaha.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Kala soocidu malahan dabeecad macno leh noocyada qiyaasta eber-ka ah.Waxba ha qaban.
    } else if index == v.len() - 1 {
        // Raadi curiyaha ugu sarreeya oo ku dheji booska ugu dambeeya ee safka.
        // Waxaan xor u nahay inaan halkaan ku isticmaalno `unwrap()` maxaa yeelay waan ognahay inaanay v noqon mid faaruq ah.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Raadi walxaha yar oo ku dheji meesha ugu horeysa ee safka.
        // Waxaan xor u nahay inaan halkaan ku isticmaalno `unwrap()` maxaa yeelay waan ognahay inaanay v noqon mid faaruq ah.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}