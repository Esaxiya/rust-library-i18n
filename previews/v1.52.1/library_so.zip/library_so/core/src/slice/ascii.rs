//! Hawlgallada ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Checks haddii dhan bytes in jeex this kuwa gudaha ku kala duwan ASCII ah.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Hubinta in laba jeex ay yihiin ASCII kiis aan dareen lahayn.
    ///
    /// La mid ah `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, laakiin iyadoon loo qoondayn oo la koobiyeyn kulaylka.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Waxay u rogeysaa jeexitaankeeda ASCII kiiskeeda sare ee u dhigma goobta.
    ///
    /// Waraaqaha ASCII 'a' ilaa 'z' waxaa lagu sawiray 'A' ilaa 'Z', laakiin waraaqaha aan ahayn ASCII isma beddelin.
    ///
    /// Si aad u soo ceshato qiimo cusub oo kore ah adigoon wax ka badalin midka jira, isticmaal [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Waxay u rogeysaa jeexitaankeeda ASCII kiiskeeda hoose ee u dhigma goobta.
    ///
    /// warqado ASCII 'A' in 'Z' waxaa baa'bin in 'a' in 'z', laakiin waraaqaha non-ASCII waa iska beddelin.
    ///
    /// Si aad ugu soo celiso qiimo jaban oo cusub adigoon wax ka badalin midka jira, isticmaal [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Sooceliyaa `true` haddii wax byte ah erayga `v` uu yahay nonascii (>=128).
/// Snarfed ka `../str/mod.rs`, oo sameeya wax la mid ah ansaxinta utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Tijaabinta tijaabada ASCII ee adeegsan doonta adeegsiga-mar-marka halkii laga isticmaali lahaa hawlgal-waqti-mar ah (markay suurtagal tahay).
///
/// Algorithmka aan halkan ku isticmaalno waa mid fudud.Hadday `s` aad u gaaban tahay, waxaan eegnaa uun bayt oo waa lagu dhammeeyaa.Haddii kale:
///
/// - Read erayga kowaad oo load ah unaligned.
/// - Ku teedo tilmaamaha, akhriyo erayada ku xiga ilaa iyo dhamaadka la xamuulka waafaqsan.
/// - Akhriso `usize`-kii ugu dambeeyay ee ka socday `s` oo xamuul aan dheellitiran lahayn.
///
/// Haddii mid ka mid ah xamuulladani soo saaraan wax `contains_nonascii` (above) runta ku soo laabto, markaa waxaan ognahay inay jawaabtu been tahay.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Haddii aynaan waxba ka helayn hirgelinta eray-mar-mar, dib ugu noqo wareegga miisaanka.
    //
    // Waxa kale oo aanu this sameeyo naqshadaba meesha `size_of::<usize>()` ma aha in lays ku filan `usize`, sababtoo ah waa kiis edge cajiib ah.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Waxaan had iyo jeer aqrinaa ereyga ugu horeeya ee aan jaangooyo lahayn, oo macnaheedu yahay `align_offset` waa
    // 0, waxaan ka akhrisan lahaa qiime isku mid mar kale u qoran ee la safan.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // BADBAADADA: Waxaan xaqiijineynaa `len < USIZE_SIZE` kore.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Waxaan kor ku hubinay kor, xoogaa si maldahan.
    // Xusuusnow in `offset_to_aligned` ay tahay `align_offset` ama `USIZE_SIZE`, labaduba si cad ayaa kor looga hubiyey.
    //
    debug_assert!(offset_to_aligned <= len);

    // AMMAANKA: word_ptr yahay (si fiican u safan) usize ptr aan u isticmaalno si akhri
    // gunta dhexe ee jeex.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` waa index byte ee `word_ptr`, loo isticmaalo jeegaga dhamaadka loop.
    let mut byte_pos = offset_to_aligned;

    // Shaki badan jeeg ah oo ku saabsan in lays, tan iyo markii aynu ku jirno oo ku saabsan in la sameeyo farabadan xamuulka unaligned.
    // Ficil ahaan tani waa inay noqotaa mid aan macquul aheyn in laga hortago cilad ku jirta `align_offset` in kastoo.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Read erayada ku xiga ilaa ereyga la soo dhaafay la safan, marka laga reebo ereyga la soo dhaafay safka keligeed in la sameeyo baaritaan dabada ka dib, si loo hubiyo in dabada in had iyo jeer waa mid `usize` ugu badnaan in dheeraad ah branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Hubso fayo-qabka in aqrintu ay tahay mid xadidan
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Iyo in fikradaha ku saabsan `byte_pos` qaban.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // BADBAADADA: Waan ognahay in `word_ptr` si sax ah loo waafajiyay (sababtoo ah
        // `` align_offset '), waanan ognahay inaan haysanno baaytyo nagu filan inta udhaxeysa `word_ptr` iyo dhamaadka
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // AMMAANKA: Waxaan ognahay in `byte_pos <= len - USIZE_SIZE`, taas oo macnaheedu yahay in
        // wixii ka dambeeya `add`, `word_ptr` wuxuu ugu badnaan ahaan doonaa hal-dhaaf-dhammaad.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // hubi Miyir in halkaas loo xaqiijiyo dhab ahaantii waa mid ka mid kaliya `usize` tagay.
    // Tan waa in lagu damaanad qaadaa xaaladdeenna wareegga.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // BADBAADADA: Tani waxay ku tiirsan tahay `len >= USIZE_SIZE`, oo aan hubinno bilowga.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}