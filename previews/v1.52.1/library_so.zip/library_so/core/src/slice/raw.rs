//! Hawlo bilaash ah si loo abuuro `&[T]` iyo `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Wuxuu ka sameeyaa jeex tilmaame iyo dherer.
///
/// dood `len` waa tirada xubno ** **, ma tirada bytes.
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `data` waa in ay ahaadaan [valid] for akhriya waayo `len * mem::size_of::<T>()` bytes badan, oo waa in la si fiican u safan.Tan macnaheedu waa gaar ahaan:
///
///     * Xusuusta xasuusta ee jeexdan oo dhan waa inay ku jirtaa hal shay oo loo qoondeeyay!
///       Jeexyada waligood kama soo dhex bixi karaan walxaha badan ee loo qoondeeyay.Eeg [below](#incorrect-usage) tusaale ah si qaldan ma qaadan this account galay.
///     * `data` waa inuu noqdaa mid aan waxba ka jirin oo la isla jaan qaadayaa xitaa jeexjeexyada dhererka eber.
///     Mid ka mid ah sababaha tan ayaa ah in qaabeynta qaabeynta enum ay ku tiirsanaan karaan tixraacyada (oo ay ku jiraan jeexjeexyada dherer kasta) oo la waafajiyo oo aan waxba ka jirin si looga sooco xogta kale.
///     Waxaad ka heli kartaa tilmaame loo isticmaali karo sida `data` jeexjeexyada dhererka eber isticmaalaya [`NonNull::dangling()`].
///
/// * `data` waa inuu tilmaamaa `len` isku xigxiga oo si sax ah loo bilaabay qiyamka nooca `T`.
///
/// * Xusuusta uu tixraacay jeexitaanka la soo celiyay waa inaan la beddelin inta uu nool yahay `'a`, marka laga reebo gudaha `UnsafeCell`.
///
/// * total size `len * mem::size_of::<T>()` ee cad waa in ay ahaadaan ma ka badan `isize::MAX`.
///   Eeg dukumiintiyada amniga ee [`pointer::offset`].
///
/// # Caveat
///
/// Meyeydaan ee jeex ku soo laabtay ayaa la hubo ka adeegsigii.
/// Si looga hortago si xun u isticmaalka, waxaa loo soo jeedinayaa in lagu xiro inta uu nool yahay hadba isha nololeed ee ay ku badbaadi karto macnaha guud, sida iyadoo la siinayo waxqabad caawiye inta nolosha oo dhan martida u ah qiimaha gogosha, ama sharaxaad cad.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // cad u muuji hal cunsur
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### isticmaalka khaldan
///
/// Shaqada `join_slices` ee soo socota waa **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // caddaynta kor ku dammaanad-`fst` iyo `snd` jira jiidda, laakiin weli waxaa laga yaabaa in ay ku qoran gudahood _different allocated objects_, kaas oo kiiska la abuuro cad tani waa dabeecad undefined.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` iyo `b` yihiin walxo kala duwan loo qoondeeyay ...
///     let a = 42;
///     let b = 27;
///     // ... taas oo si kastaba ha ahaatee loo dhigi karo si qarsoodi ah xusuusta: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Waxay qabataa isla shaqeynta sida [`from_raw_parts`], marka laga reebo in jeex la beddelo la soo celiyo.
///
/// # Safety
///
/// Dabeecadda lama qeexin haddii mid ka mid ah shuruudaha soo socda la jebiyo:
///
/// * `data` waa inuu noqdaa [valid] labada aqrin iyo wax u qor `len * mem::size_of::<T>()` badan oo bayte ah, waana inuu ahaadaa mid si sax ah loo waafajiyay.Tan macnaheedu waa gaar ahaan:
///
///     * Xusuusta xasuusta ee jeexdan oo dhan waa inay ku jirtaa hal shay oo loo qoondeeyay!
///       Xaleef marnaba noqon karaan guud ahaan waxyaabaha badan loo qoondeeyey.
///     * `data` waa inuu noqdaa mid aan waxba ka jirin oo la isla jaan qaadayaa xitaa jeexjeexyada dhererka eber.
///     Mid ka mid ah sababaha tan ayaa ah in qaabeynta qaabeynta enum ay ku tiirsanaan karaan tixraacyada (oo ay ku jiraan jeexjeexyada dherer kasta) oo la waafajiyo oo aan waxba ka jirin si looga sooco xogta kale.
///
///     Waxaad ka heli kartaa tilmaame loo isticmaali karo sida `data` jeexjeexyada dhererka eber isticmaalaya [`NonNull::dangling()`].
///
/// * `data` waa inuu tilmaamaa `len` isku xigxiga oo si sax ah loo bilaabay qiyamka nooca `T`.
///
/// * Xusuusta uu tixraacay jeex la soo celiyey waa inaan laga dhex helin tilmaam kale (oo aan laga soo qaadin qiimaha soo noqoshada) inta uu nool yahay `'a`.
///   Helitaanka akhriska iyo qorista labaduba waa mamnuuc.
///
/// * total size `len * mem::size_of::<T>()` ee cad waa in ay ahaadaan ma ka badan `isize::MAX`.
///   Eeg dukumiintiyada amniga ee [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BADBAADADA: Wicitaanku waa inuu ilaaliyaa heshiiska badbaadada ee `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// U rogaa tixraac T qayb cad oo dherer ah 1 (iyadoon la koobiyeyn).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// U rogaa tixraac T qayb cad oo dherer ah 1 (iyadoon la koobiyeyn).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}