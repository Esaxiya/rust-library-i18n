// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Bedbedeli kala duwan ee `[mid-left, mid+right)` sida in element ee `mid` noqdo element ugu horeysay.Equivalently, isku bedbedeli doono kala duwan xubno `left` bidixda ama `right` canaasiirta in ay xaq u leeyihiin.
///
/// # Safety
///
/// Baaxadda la cayimay waa inay ansax ku ahaataa akhriska iyo qorista.
///
/// # Algorithm
///
/// Algorithm 1 waxaa loo isticmaalaa qiimayaasha yaryar ee `left + right` ama loogu talagalay `T` weyn.
/// Walxaha loo wareejiyo galay ay final ka mid ah waqti ka bilaabanta `mid - left` iyo horumarinta sallaan `right` modulo `left + right`, sida in loo baahan yahay mid ku meel gaar ah oo kaliya.
/// Ugu dambayntii, waxaan timaado dib ugu `mid - left`.
/// Si kastaba ha noqotee, haddii `gcd(left + right, right)` uusan ahayn 1, talaabooyinka kor ku xusan ayaa ka booday cunsurro.
/// Tusaale ahaan:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Nasiib wanaagse, tirada laga booday walxaha inta udhaxeysa walxaha dhammeystiran had iyo jeer waa loo siman yahay, sidaa darteed waxaan iska yareyn karnaa booskeenna bilowga oo waxaan sameyn karnaa wareegyo badan (wadarta tirada wareegyada waa `gcd(left + right, right)` value).
///
/// Natiijada ugu dambeysa ayaa ah in walxaha oo dhan la dhammeeyo hal mar oo keliya.
///
/// Algorithm 2 ayaa la adeegsadaa haddii `left + right` uu weyn yahay laakiin `min(left, right)` uu yar yahay oo ku filan inuu ku xirnaado keydka xariga.
/// Curiyeyaasha `min(left, right)` waxaa lagu soo guuriyey keydka, `memmove` waxaa lagu dabaqayaa kuwa kale, kuwa ku kaydsanna dib ayaa loogu celiyaa godka dhinaca ka soo horjeedka ah meeshii ay asal ahaan ka yimaadeen.
///
/// Algorithms in la vectorized kartaa iskhexgalida kor ku xusan mar `left + right` noqdo filan weyn.
/// Algorithm 1 waxaa lagu kala saari karaa iyadoo la jajabayo oo la sameynayo wareegyo badan hal mar, laakiin waxaa jira wareegyo aad u yar oo isku celcelis ah illaa iyo `left + right` ay aad u weyn tahay, kiiskii ugu xumaa ee hal wareeg ayaa marwalba jira.
/// Beddelkeeda, algorithm 3 wuxuu adeegsadaa isku-beddelka soo noqnoqda ee walxaha `min(left, right)` illaa ay ka harto dhibaato yar oo wareeg ah.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// marka `left < right` bedelo ka dhacaya ka bidix halkii.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. hoose algorithms dafiri karto haddii xaaladahan ka mid ahi ma hubiyay
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks waxay muujineysaa in celceliska waxqabadka wareegyada aan kala sooca lahayn uu ka fiican yahay illaa iyo inta laga gaarayo `left + right == 32`, laakiin waxqabadka ugu xun ee ugu hooseeya wuxuu jabayaa xitaa illaa 16.
            // 24 waxaa loo doortay inuu noqdo dhul dhexe.
            // Haddii cabirka `T` ka weyn yahay 4 ``usize`s, algorithm wuxuu sidoo kale ka sarreeyaa algorithms kale.
            //
            //
            let x = unsafe { mid.sub(left) };
            // bilowgii wareegii koowaad
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` waxaa laga heli karaa gacanta ka hor adoo xisaabinaya `gcd(left + right, right)`, laakiin way ka dhakhso badan tahay in la sameeyo hal loop kaas oo xisaabinaya gcd saameyn ahaan, ka dibna sameeya inta ka hartay gunta
            //
            //
            let mut gcd = right;
            // jaangooyooyinku waxay muujinayaan inay ka dhakhso badan tahay isku beddelka ku-meel-gaadhka ah ee jidka oo dhan ah halkii aad hal mar ku wada akhrin lahayd ku-meel-gaadh ah, oo gadaal looga deyrinayo, ka dibna loo qoro ku-meelgaarka dhammaadka.
            // Tani waxay suurto gal ah waxaa sabab u ah xaqiiqada ah in nayo ama bedelida temporaries isticmaalaa oo kaliya hal cinwaan xasuusta in loop halkii u baahan si ay u maareeyaan laba.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // halkii incrementing `i` oo markaas hubinaya haddii ay tahay meel ka baxsan soohdin ah, waxaan hubin haddii `i` tegi doonaa ka baxsan soohdin ku inremantiga soo socda.
                // Tani waxay ka hortagtaa duubo mid ka mid ah tilmaamo ama `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // dhamaadka wareega koowaad
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // shardi waa inuu ahaadaa halkan haddii `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // dhameysan waslad la wareeg more
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ma aha nooc eber ah, markaa waa caadi in loo qaybiyo cabbirkiisa.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Geynta 2 `[T; 0]` halkan waa in la hubiyo this waxaa habboon waafaqsan for T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Waxaa jira qaab kale oo lagu beddelo oo ku lug leh helitaanka halka isku beddelka ugu dambeeya ee algorithm-kan uu noqon doono, iyo isku beddelashada iyadoo la adeegsanayo gabbaadka ugu dambeeya halkii laga beddeli lahaa guntimaha ku dhow sida algorithm-kan ay sameyneyso, laakiin habkan ayaa weli ka dhaqso badan.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}