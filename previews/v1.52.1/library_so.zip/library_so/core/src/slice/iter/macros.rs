//! Macros oo ay adeegsadaan qalabka wax lagu gooyo.

// Inlining is_empty iyo Len faraq fulin weyn
macro_rules! is_empty {
    // Qaabka aan uqorno dhererka wax soosaaraha ZST, kani wuxuu u shaqeeyaa ZST iyo non-ZST labadaba.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Si looga takhaluso jeegagga soohdimaha qaarkood (eeg `position`), waxaan ku xisaabinaynaa dhererka qaab aan la filayn.
// (Waxaa tijaabiyey 'codegen/jeexjeexin-boos-soohdin-hubin'.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // mararka qaarkood waxaa nalagu isticmaalaa meel aan ammaan ahayn

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_-kani wuxuu adeegsadaa `unchecked_sub` maxaa yeelay waxaan ku tiirsannahay duubista si aan u metello dhererka istiraatiirooyinka jeex jeexjeexa ah ee dheer.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Waxaan ognahay in `start <= end`, si fiican u sameyn karo ka badan `offset_from`, taas oo loo baahan yahay in in saxiixay macaamilo.
            // By dejinta calamada ku haboon halkan waxaan ku sheegi kara LLVM this, taas oo ka caawisaa ka saartid jeegaga gudbee.
            // BADBAADADA: Nooca aan is beddeli karin, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Adoo sidoo kale u sheegaya LLVM in tilmaamayaasha ay ku kala duwan yihiin dhowr nooc oo sax ah, waxay ku hagaajin kartaa `len() == 0` illaa `start == end` halkii laga heli lahaa `(end - start) < size`.
            //
            // BADBAADADA: Nooca aan is beddeli karin, tilmaamayaasha ayaa la mid ah sidaas
            //         Masaafada u dhaxeeya waa in ay ahaadaan kala duwan ah oo size pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Qeexidda la wadaago oo ka mid ah iterators `Iter` iyo `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Ku soo celiyaa cunsurihii ugu horreeyay uguna dhaqaajiyaa bilowga soo-celinta jawaabaha 1.
        // Si weyn u wanaajisaa waxqabadka marka la barbardhigo hawl la tilmaamay.
        // Tilmaamuhu ma aha inuu faaruq noqdo.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Dib element ee la soo dhaafay oo u dhaqaaqdo dhamaadka gadaal iterator ah by 1.
        // Si weyn u wanaajisaa waxqabadka marka la barbardhigo hawl la tilmaamay.
        // Tilmaamuhu ma aha inuu faaruq noqdo.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Ihin iterator marka T waa ZST a, by dhaqaaqin dhamaadka gadaal iterator by `n` ah.
        // `n` waa inuusan ka badnaan `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Kaaliyaha ayaa u shaqeynaya abuurista jeex ka soo baxa soo-celinta.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // BADBAADADA: soo-celinta ayaa laga abuuray jeex leh tilmaanta
                // `self.ptr` iyo dherer `len!(self)`.
                // Tani waxay damaanad qaadaysaa in dhammaan shuruudaha looga baahan yahay `from_raw_parts` la buuxiyo.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Gargaare function dhaqdhaqaajin bilowga iterator ah weeraryahanada by xubno `offset`, soo laabtay bilowga hore.
            //
            // Nabadla ', maxaa yeelay, waa ku kabayso aan ka badnayn `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // BADBAADADA: Wicitaanku wuxuu dammaanad qaadayaa in `offset` uusan ka badneyn `self.len()`,
                    // markaa tilmaame cusubi wuxuu ku dhex jiraa `self` oo sidaas ayaa lagu dammaanad qaadayaa inuu yahay mid aan waxba ka jirin.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Kaaliyaha ayaa u dhaqaaqaya si uu gadaal ugu riixo dhamaadka soo-celinta waxyaallaha `offset`, soo celinta dhamaadka cusub.
            //
            // Nabadla ', maxaa yeelay, waa ku kabayso aan ka badnayn `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // BADBAADADA: Wicitaanku wuxuu dammaanad qaadayaa in `offset` uusan ka badneyn `self.len()`,
                    // kaas oo la hubo in aan dhulka qarqinaya `isize` ah.
                    // Sidoo kale, tilmaamaha keentay waa in soohdimaha `slice`, kaas oo buuxiya shuruudaha kale ee `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // waxaa lagu fulin karaa xaleefyo, laakiin tani waxay ka hortageysaa hubinta xuduudaha

                // BADBAADADA: Wicitaanada `assume` waa ammaan tan iyo markii la jeexayo tilmaame bilowgiisa
                // waa inuu noqdaa mid aan waxba ka jirin, oo xaleefyada ka baxsan kuwa aan ahayn 'ZSTs' waa inay sidoo kale lahaadaan tilmaam dhammaad aan waxba ka jirin.
                // Baaqa in `next_unchecked!` waa ammaan ah tan iyo markii aan hubi haddii iterator ka madhan tahay marka hore.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // iterator Tanu hadda waa madhan.
                    if mem::size_of::<T>() == 0 {
                        // Waa inaan ku sameeynaa sidan maadaama `ptr` uusan waligiis noqon karin 0, laakiin `end` wuxuu noqon karaa (duubis darteed).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // AMMAANKA: dhamaadka ma noqon karo 0 haddii T ma aha ZST maxaa yeelay ptr ma aha 0 iyo dhamaadka>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // AMMAANKA: Waxaan nahay in soohdin.`post_inc_start` wuxuu sameeyaa wax sax ah xitaa ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Waxaan ka takhalusnay hirgelinta aasaasiga ah, ee adeegsata `try_fold`, maxaa yeelay hirgalintan fudud waxay soo saartaa wax ka yar LLVM IR waana ka dhaqso badan in la soo uruuriyo.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Waxaan ka takhalusnay hirgelinta aasaasiga ah, ee adeegsata `try_fold`, maxaa yeelay hirgalintan fudud waxay soo saartaa wax ka yar LLVM IR waana ka dhaqso badan in la soo uruuriyo.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Waxaan ka takhalusnay hirgelinta aasaasiga ah, ee adeegsata `try_fold`, maxaa yeelay hirgalintan fudud waxay soo saartaa wax ka yar LLVM IR waana ka dhaqso badan in la soo uruuriyo.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Waxaan ka takhalusnay hirgelinta aasaasiga ah, ee adeegsata `try_fold`, maxaa yeelay hirgalintan fudud waxay soo saartaa wax ka yar LLVM IR waana ka dhaqso badan in la soo uruuriyo.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Waxaan ka takhalusnay hirgelinta aasaasiga ah, ee adeegsata `try_fold`, maxaa yeelay hirgalintan fudud waxay soo saartaa wax ka yar LLVM IR waana ka dhaqso badan in la soo uruuriyo.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Waxaan ka takhalusnay hirgelinta aasaasiga ah, ee adeegsata `try_fold`, maxaa yeelay hirgalintan fudud waxay soo saartaa wax ka yar LLVM IR waana ka dhaqso badan in la soo uruuriyo.
            // Sidoo kale, `assume` wuxuu iska ilaaliyaa baaritaanka xuduudaha.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // AMMAANKA: waxaan aad loogu balan qaadayo in uu noqdo in soohdin by invariant loop ka:
                        // marka `i >= n`, `self.next()` laabtay `None` iyo nasashada loop ka.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Waxaan ka takhalusnay hirgelinta aasaasiga ah, ee adeegsata `try_fold`, maxaa yeelay hirgalintan fudud waxay soo saartaa wax ka yar LLVM IR waana ka dhaqso badan in la soo uruuriyo.
            // Sidoo kale, `assume` wuxuu iska ilaaliyaa baaritaanka xuduudaha.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // BADBAADADA: `i` waa inuu ka hooseeyaa `n` maadaama uu ka bilaabmayo `n`
                        // iyo hoos kaliya.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // AMMAANKA: damaanad waajib wacaha in `i` waa in soohdimaha
                // jeex ku dahsoon, si `i` ma qarqin karaan `isize` ah, iyo tixraacyada ku soo laabtay si hubaal ah u tixraac element ah oo cad iyo sidaas ballan qaaday in ay ansax ahaato.
                //
                // Sidoo kale ogsoonow in wacaha sidoo kale ballan qaadayaa in aan marnaba loo yaqaan la index isla mar kale, iyo in jirin habab kale oo ka heli doonaa subslice this waxaa loo yaqaan, si ay sax tahay tixraac ku soo laabtay noqon mutable in ay dhacdo
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // waxaa lagu fulin karaa xaleefyo, laakiin tani waxay ka hortageysaa hubinta xuduudaha

                // AMMAANKA: calls `assume` waa nabad tan iyo tilmaamaha bilowga jeex ah ee waa inuu ahaado mid aan waxba,
                // iyo jeexjeexyada aan ahayn ZSTs waa inay sidoo kale lahaadaan tilmaam dhammaad aan waxba ka jirin.
                // Wicitaanka `next_back_unchecked!` waa amaan tan iyo markii aan hubinay in soo-saaraha uu faaruq yahay marka hore.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // iterator Tanu hadda waa madhan.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // AMMAANKA: Waxaan nahay in soohdin.`pre_dec_end` wuxuu sameeyaa wax sax ah xitaa ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}