// fulinta Original soo qaatay rust-memchr.
// Copyright 2015 Andrew geesiyaasha, bluss iyo Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Isticmaal goyn.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Sooceliyaa `true` haddii `x` kujiro wax eber ah.
///
/// Laga soo bilaabo *Arrimaha Xisaabinta*, J. Arndt:
///
/// "Fikradda waa in ay kala gooyaan hal ka mid ah bytes ka dibna raadi bytes meesha weyddiisto ku faafin jidka oo dhan si ay ugu weyn
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Sooceliyaa tusmada uguhoreysa ee lamid ah baytka `x` ee `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Waddo dhakhso ah oo loogu talagalay xaleefyada yaryar
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Skane ku qiimee hal baiti adoo aqrinaya labo eray oo `usize` ah markiiba.
    //
    // U kala qaad `text` saddex qaybood
    // - qayb bilaw ah oo aan iswaafaqsanayn, kahor erayga ugu horeeya ee cinwaanka toosan loogu qoro qoraalka
    // - jirka, iska mari 2 eray markiiba
    // - qaybta ugu dambeysa ee harsan, <2 word size

    // Raadi ilaa soohdinta la waafajiyey
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // raadi jirka qoraalka
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // AMMAANKA: saadaalin karo halka ee damaanad qaadaya fogaan ah ugu yaraan 2 usize_bytes *
        // inta udhaxeysa isugeynta iyo dhamaadka jeexitaanka.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // jab haddii ay jirto byte u dhigma
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Raadi byte ka dib markii meesha ugu loop jidhka joojiyay.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Sooceliyaa tusmada ugu dambeysa ee u dhiganta bayte `x` ee `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Skane ku qiimee hal baiti adoo aqrinaya labo eray oo `usize` ah markiiba.
    //
    // U kala qaad `text` saddex qaybood:
    // - dabada aan toosnayn, ka dib ereyga ugu dambeeya cinwaanka waafaqsan qoraalka,
    // - jirka, waxaa lagu marsiiyaa 2 eray markiiba
    // - bytes-kii uhoreeyay ee haray, <2 cabbirka erayga.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Waxaan this wac oo kaliya si aad u hesho dhererka ka horgale iyo qadarin ah.
        // Dhexda waxaan marwalba ka shaqeynaa laba qaybood hal mar.
        // AMMAANKA: transmuting `[u8]` in `[usize]` waa amaan marka laga reebo kala duwan size oo waxaa qabta `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Raadi qoraalka qoraalka, hubi inaanaan dhaafin min_aligned_offset.
    // mowjadda waxaa had iyo jeer la safan, sidaas oo kaliya jirrabaya `>` ku filan oo iska ilaalisaa in ay suurtogal tahay dhulka qarqinaya.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // AMMAANKA: isugeynta waxay ka bilaabataa len, suffix.len(), inta ay ka weyntahay
        // min_aligned_offset (prefix.len()) masaafada harsan waa ugu yaraan 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Jebi haddii uu jiro byte u dhigma
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Raadi baaytka kahor barta barta wareegga jirka uu istaagay.
    text[..offset].iter().rposition(|elt| *elt == x)
}