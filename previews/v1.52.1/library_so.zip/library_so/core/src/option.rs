//! Qiyamyada ikhtiyaariga ah.
//!
//! Nooca [`Option`] ka dhigan qiimo optional: [`Option`] kasta waa mid [`Some`] oo ku jira qiimaha, ama [`None`], oo ma aha.
//! [`Option`] noocyada kala yihiin aad caadi u ah in code Rust, sida ay leeyihiin tiro ka mid ah isticmaalka:
//!
//! * Qiimaha bilowga ah
//! * Soo celi qiyamka shaqooyinka aan lagu qeexin inta ay le'eg yihiin oo dhan (shaqooyinka qayb ahaan)
//! * Return qiimaha waayo haddii kale warbixinta qaladaad fudud, halkaas oo [`None`] waxaa ku soo laabtay on baadi
//! * Meelaha qaab-dhismeedka ikhtiyaariga ah
//! * Dhiso beero amaah lagu bixin karo ama "taken"
//! * Dood-hawleedyo ikhtiyaari ah
//! * tilmaamo Nullable
//! * Wax ka beddelashada xaaladaha adag
//!
//! ['Xulashada'] s waxaa badanaa lagu lammaaneeyaa qaab u dhigma si loo weyddiiyo jiritaanka qiimaha oo loo qaado tallaabo, marwalbana lagu xisaabtamo kiiska [`None`].
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // Qiimaha soo celinta shaqadu waa ikhtiyaar
//! let result = divide(2.0, 3.0);
//!
//! // Tartan qaab si aad uhesho qiimaha
//! match result {
//!     // Qeybintu waa ansax
//!     Some(x) => println!("Result: {}", x),
//!     // Qeybintu waxay ahayd mid aan ansax ahayn
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: Muuji sida `Option` loogu isticmaalo ficil ahaan, habab badan
//
//! # Ikhtiyaarrada iyo tilmaamayaasha ("nullable" tilmaamayaasha)
//!
//! Noocyada tilmaamaha Rust waa in had iyo jeer farta ku meel sax ah,ma jiraan tixraacyo "null" ah.Taabadalkeed, Rust waxay leedahay tilmaamayaal *ikhtiyaari ah*, sida sanduuqa ikhtiyaariga ah ee ay leeyihiin, [``Xulasho ']' '<`[' 'Box<T>```` ''.
//!
//! Tusaalaha soo socda wuxuu adeegsanayaa [`Option`] si loo abuuro sanduuq ikhtiyaari ah oo ah [`i32`].
//! Fiiro u yeelo si marka hore loo isticmaalo qiimaha gudaha [`i32`], shaqada `check_optional` waxay u baahan tahay inay isticmaasho qaab u dhigma si loo go'aamiyo in sanduuqa uu qiimo leeyahay (ie, waa [`Some(...)`][`Some`]) ama maahan ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust wuxuu dammaanad ka qaadayaa inuu hagaajiyo noocyada soo socda ee `T` sida tan [`Option<T>`] ay le'eg tahay tan `T`:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` qaab dhismeedka hareeraha mid ka mid ah noocyada ku jira liistadaan.
//!
//! Waxaa kale oo la damaanad qaadayaa in, kiisaska kor ku xusan, mid ka mid ah uu ka qaadi karo [`mem::transmute`] dhammaan qiimayaasha saxda ah ee `T` ilaa `Option<T>` iyo laga bilaabo `Some::<T>(_)` ilaa `T` (laakiin u wareejinta `None::<T>` illaa `T` waa dabeecad aan la qeexin).
//!
//! # Examples
//!
//! kusaabsan hannaanka Basic on [`Option`]:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // U qaado tixraac xarigga ku jira
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Ka qaad xariga ku jira, adigoo baabi'inaya Xulashada
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! Initialize natiijo in [`None`] hor loop a:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // Liiska xogta la raadin karo.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // Waxaan raadineynaa magaca xayawaanka ugu weyn, laakiin waxaan ku bilaabaynaa hadda waxaan helnay `None`.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // Hadda waxaan helnay magaca xayawaan weyn
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// Nooca `Option`.Ka eeg [the module level documentation](self) wixii intaa ka badan.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// Qiime malahan
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// Qaar baa qiimeeya `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// Nooca hirgelinta
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Waydiinta qiimayaasha kujira
    /////////////////////////////////////////////////////////////////////////

    /// Soocelinayaa `true` haddii ikhtiyaarku yahay qiime [`Some`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// Soocelinayaa `true` haddii ikhtiyaarku yahay qiime [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// Soocelinayaa `true` haddii ikhtiyaarka uu yahay qiime [`Some`] oo ay kujiraan qiimaha lasiiyay.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adabtarad loogu talagalay la shaqaynta tixraacyada
    /////////////////////////////////////////////////////////////////////////

    /// Ka beddelaya `&Option<T>` illaa `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Waxay badashaa 'Ikhtiyaar <' ['String`]'>`` ikhtiyaar <'' '' 'usize`]`>, iyadoo la ilaalinayo asalka.
    /// Habka [`map`] wuxuu ku qaataa doodda `self` qiime ahaan, isagoo isticmaalaya kan asalka ah, sidaa darteed farsamadan ayaa adeegsata `as_ref` si marka hore loo qaato `Option` tixraaca qiimaha gudaha asalka ah.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // Marka hore, ku tuur `Option<String>` illaa `Option<&String>` oo leh `as_ref`, ka dibna ku cun *taasi* oo leh `map`, adigoo uga tagaya `text` xargaha.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// Ka beddelaya `&mut Option<T>` illaa `Option<&mut T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// Ku beddelashooyinka ka socda [`Pin`]`<&Xulashada<T>>`` Xulashada <`['' Pin`]`<&T>>``.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // BADBAADADA: `x` waa la damaanad qaaday in la xidho sababta oo ah waxay ka timaaddaa `self`
        // kaas oo ku dhagan.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// Kuweeda ka [`Pin`]`<&Xulashada mut<T>>`` Xulashada <'[' Pin`]`<&mut T>> '.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // BADBAADADA: `get_unchecked_mut` waligeed looma adeegsan dhaqaajinta `Option` gudaha `self`.
        // `x` waa la damaanad qaadayaa in la xidho sababta oo ah waxay ka timaaddaa `self` oo la xidho.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // Helitaanka qiyamka ku jira
    /////////////////////////////////////////////////////////////////////////

    /// Sooceliyaa qiimaha [`Some`] ku jira, baabbi'iya qiimaha `self` ah.
    ///
    /// # Panics
    ///
    /// Panics haddii qiimuhu yahay [`None`] oo leh fariin caadifadeed panic oo ay bixiso `msg`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// Sooceliyaa qiimaha [`Some`] ku jira, baabbi'iya qiimaha `self` ah.
    ///
    /// Sababtoo ah shaqadani waa panic, isticmaalkeeda guud ahaan waa laga niyadjabay.
    /// Taabadalkeed, doorbid inaad isticmaasho qaab u dhigma oo aad si cad u maamusho kiiska [`None`], ama wac [`unwrap_or`], [`unwrap_or_else`], ama [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics haddii qiimaha naftiisu u dhigmo [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// Sooceliyaa qiimaha [`Some`] ee kujira ama udiyaar la bixiyay.
    ///
    /// Doodaha loo gudbiyay `unwrap_or` si xamaasad leh ayaa loo qiimeeyaa;haddii aad gudbineyso natiijada wicitaan shaqo, waxaa lagugula talinayaa inaad isticmaasho [`unwrap_or_else`], oo caajis lagu qiimeeyo.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// Soo celiyaa qiimaha [`Some`] ee kujira ama ka xisaabiyaa xiritaanka.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// Sooceliyaa qiimaha [`Some`] ee kujira, cunida qiimaha `self`, adigoon hubin in qiimaha uusan aheyn [`None`].
    ///
    ///
    /// # Safety
    ///
    /// Ku wacida qaabkan [`None`] waa *[dhaqan aan la qeexin]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Dabeecad aan la qeexin!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // AMMAANKA: heshiis ammaanka waa in la fuliyo ay wacaha.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Wax ka beddelka qiimaha ku jira
    /////////////////////////////////////////////////////////////////////////

    /// Khariidadaha `Option<T>` ilaa `Option<U>` adoo adeegsanaya hawl ku jira qiime ku jira.
    ///
    /// # Examples
    ///
    /// Waxay badashaa 'Ikhtiyaar <' ['String`]'> 'oo loo beddelaa' Ikhtiyaar <'[' usize ']'>>, iyadoo isticmaaleysa asalka:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` wuxuu qaataa naftiisa *qiimo ahaan*, wuxuu cunaa `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// Waxay ku dabaqeysaa shaqeyn qiimaha ku jira (haddii ay jirto), ama waxay soo celineysaa asalka bixinta (haddii kale).
    ///
    /// Doodo si ay `map_or` maray ayaa sugi la qiimeeyo;haddii aad gudbineyso natiijada wicitaan shaqo, waxaa lagugula talinayaa inaad isticmaasho [`map_or_else`], oo caajis lagu qiimeeyo.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// Waxay ku dabaqeysaa shaqeyn qiimaha ku jira (haddii ay jirto), ama waxay xisaabineysaa mid caadi ah (haddii kale).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// Badalaa `Option<T>` galay [`Result<T, E>`] ah, Khariidadeynta [`Some(v)`] in [`Ok(v)`] iyo [`None`] in [`Err(err)`].
    ///
    /// Doodo si ay `ok_or` maray ayaa sugi la qiimeeyo;haddii aad gudbineyso natiijada wicitaan shaqo, waxaa lagugula talinayaa inaad isticmaasho [`ok_or_else`], oo caajis lagu qiimeeyo.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` wuxuu u beddelaa [`Result<T, E>`], khariidadeynta [`Some(v)`] illaa [`Ok(v)`] iyo [`None`] illaa [`Err(err())`].
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// Geliya `value` xulashada ka dibna ku soo celisa tixraac la beddeli karo.
    ///
    /// Haddii ikhtiyaarka horeyba u ka koobnaa qiime, qiimihii hore waa la tuurayaa.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // AMMAANKA: code ee kor ku xusan oo kaliya fursad u buuxsantay
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Dhismayaasha Iterator
    /////////////////////////////////////////////////////////////////////////

    /// Wuxuu kucelceliyaa qiimeeyaha suuragalka ah inuu kujiro.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// Ku soo celiyaa soo-celiyaha la beddeli karo qiimaha suurtagalka ah ee ku jira.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Hawlaha Boolean ee qiyamka, xiisaha iyo caajiska
    /////////////////////////////////////////////////////////////////////////

    /// Dib [`None`] haddii doorasho waa [`None`], haddii kale laabtay `optb`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// Soocelinayaa [`None`] haddii ikhtiyaarku yahay [`None`], haddii kale wuxuu ugu yeeraa `f` qiimaha duudduuban oo natiijada ku celiya.
    ///
    ///
    /// Qaar ka mid ah luqadaha wac flatmap howlgalkan.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// Sooceliyaa [`None`] haddii ikhtiyaarku yahay [`None`], haddii kale wuxuu ugu yeeraa `predicate` qiimaha duudduuban oo soo laaban:
    ///
    ///
    /// - [`Some(t)`] haddii `predicate` soo celiyo `true` (halka `t` uu yahay qiimaha duudduuban), iyo
    /// - [`None`] haddii `predicate` laabtay `false`.
    ///
    /// Shaqadani waxay u shaqeysaa si la mid ah [`Iterator::filter()`].
    /// Waad qiyaasi kartaa in `Option<T>` uu yahay mid soosaara hal ama eber walxo.
    /// `filter()` kuu ogolaanaysaa inaad go'aan xubno si ay u sii.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// Sooceliyaa ikhtiyaarka haddii waxa ku jira qiimaha, haddii kale laabtay `optb`.
    ///
    /// Doodaha loo gudbiyay `or` si xamaasad leh ayaa loo qiimeeyaa;haddii aad gudbineyso natiijada wicitaan shaqo, waxaa lagugula talinayaa inaad isticmaasho [`or_else`], oo caajis lagu qiimeeyo.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// Sooceliyaa ikhtiyaarka haddii ay kujirto qiime, haddii kale wuxuu wacaa `f` wuuna sooceliyaa natiijada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// Sooceliyaa [`Some`] haddii dhab ahaan mid kamid ah `self`, `optb` uu yahay [`Some`], haddii kale wuxuu soo celiyaa [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Howlaha u eg gelitaanka si aad u geliso hadaanay jirin iyo soo celinta tixraac
    /////////////////////////////////////////////////////////////////////////

    /// Geliya `value` xulashada haddii ay tahay [`None`], ka dibna ku soo celinayo tixraac la beddeli karo qiimaha ku jira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// Geliya qiimaha asalka ah ikhtiyaarka haddii ay tahay [`None`], ka dibna ku soo celinayo tixraac la beddeli karo qiimaha ku jira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// Gelisaa qiime laga soosaaray `f` xulashada hadii ay tahay [`None`], kadib wuxuu kusoo celinayaa tixraac la beddeli karo qiimaha kujira.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // BADBAADADA: nooc ka mid ah `None` oo loogu talagalay `self` waxaa lagu beddeli lahaa `Some`
            // kala duwanaanshaha koodhka kor ku xusan.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// Qiimaha wuxuu ka qaadaa ikhtiyaarka, wuxuu uga tagayaa [`None`] meeshiisa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Badalay qiimaha dhabta ah ee ikhtiyaarka by qiimaha siiyey in dhimaya, soo laabtay qiimaha jir haddii la joogo, taasoo ka dhigeysa [`Some`] ah in ay meel aan deinitializing mid ka mid ah.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// Siibadaha `self` la `Option` kale.
    ///
    /// Haddii `self` uu yahay `Some(s)` iyo `other` uu yahay `Some(o)`, qaabkani wuxuu soo celinayaa `Some((s, o))`.
    /// Haddii kale, `None` waa la soo celiyey.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Zips `self` iyo `Option` kale oo leh shaqeynta `f`.
    ///
    /// Haddii `self` uu yahay `Some(s)` iyo `other` uu yahay `Some(o)`, qaabkani wuxuu soo celinayaa `Some(f(s, o))`.
    /// Haddii kale, `None` waa la soo celiyey.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// Khariidadaha `Option<&T>` illaa `Option<T>` adoo koobiyeya waxyaabaha ku jira xulashada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// Khariidadaha `Option<&mut T>` illaa `Option<T>` adoo koobiyeya waxyaabaha ku jira xulashada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// Khariidadaha `Option<&T>` iyo `Option<T>` adoo kaashanaya waxyaabaha ku jira xulashada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// Khariidadaha `Option<&mut T>` iyo `Option<T>` adoo kaashanaya waxyaabaha ku jira xulashada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// Wuxuu cunaa `self` isagoo filaya [`None`] oo uusan waxba soo celin.
    ///
    /// # Panics
    ///
    /// Panics hadii qiimuhu yahay [`Some`], oo leh fariin panic oo ay kujiraan fariin la gudbiyay, iyo waxyaabaha kujira [`Some`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Tani panic ma noqon doonto, maadaama furayaasha oo dhami ay yihiin kuwo gaar ah.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// Wuxuu cunaa `self` isagoo filaya [`None`] oo uusan waxba soo celin.
    ///
    /// # Panics
    ///
    /// Panics haddii qiimuhu yahay [`Some`], oo leh fariin caadadiisu tahay panic oo ay bixisay qiimaha [``Some`] ''.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Tani panic ma noqon doonto, maadaama furayaasha oo dhami ay yihiin kuwo gaar ah.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// Sooceliyaa qiimaha [`Some`] ee kujira ama kan caadiga ah
    ///
    /// Waxay qaadataa doodda `self` markaa, haddii [`Some`], ay sooceliso qiimaha kujira, haddii kale haddii [`None`], wuxuu kusooceliyaa [default value] noocaas.
    ///
    ///
    /// # Examples
    ///
    /// U beddelaya xadhig tiro, isaga oo u beddelaya xadhig aan si wanaagsan u samaysnayn 0 (qiimaha asalka u ah tirooyinka).
    /// [`parse`] wuxuu xarig u beddelaa nooc kasta oo kale oo fuliya [`FromStr`], kuna sooceliyaa [`None`] qalad.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// Ka beddelaya `Option<T>` (ama `&Option<T>`) una beddelaya `Option<&T::Target>`.
    ///
    /// Ka tag Xulashada asalka ah goobta, abuurista mid cusub oo tixraac u leh kii asalka ahaa, iyadoo lagu sii xoojinayo waxyaabaha ku jira [`Deref`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// Ka beddelaya `Option<T>` (ama `&mut Option<T>`) una beddelaya `Option<&mut T::Target>`.
    ///
    /// Ka tag `Option` asalka ah goobta, abuurista mid cusub oo ay ku jiraan tixraac la beddeli karo nooca gudaha ee nooca `Deref::Target`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// U rogaa `Option` ee [`Result`] una beddelaa [`Result`] oo ah `Option`.
    ///
    /// [`None`] waxaa lagu sawirayaa [``Ok`] '' (`` (Midna)] '').
    /// [``Some`] ``('' (`` Ok`] '(_))' 'and (`` Some`]' '(`` (' 'Err`]`(_))``Waxaa lagu soo sawirayaa [` `Ok`]' '((``Some`] '(_))' and (``Err`] '' (_) '.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// Tani waa hawl gooni ah si loo yareeyo cabbirka koodhka ee .expect() laftiisa.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// Tani waa shaqo gooni ah si loo yareeyo size code of .expect_none() laftiisa ah.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Fulinta Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// Sooceliyaa [`None`][Option::None].
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Waxay ku celisaa soo-celiyaha wax cunaya qiimaha suuragalka ah ee ku jira.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// Nuqulada `val` oo loo rogay `Some` cusub.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// Ka beddelaya `&Option<T>` illaa `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Waxay badashaa 'Ikhtiyaar <' ['String`]'>`` ikhtiyaar <'' '' 'usize`]`>, iyadoo la ilaalinayo asalka.
    /// Habka [`map`] wuxuu ku qaataa doodda `self` qiime ahaan, isagoo isticmaalaya kan asalka ah, sidaa darteed farsamadan ayaa adeegsata `as_ref` si marka hore loo qaato `Option` tixraaca qiimaha gudaha asalka ah.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// Ka beddelaya `&mut Option<T>` illaa `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Ikhtiyaariyada Ikhtiyaariga ah
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// Falanqeeye ka hadlaya tixraaca nooca [`Some`] ee [`Option`].
///
/// Tilmaamuhu wuxuu keenaa hal qiime haddii [`Option`] uu yahay [`Some`], haddii kale midna.
///
/// `struct`-kan waxaa abuuray [`Option::iter`] function.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// Falanqeeye ka hadlaya tixraac isbeddel ah oo ku saabsan nooca [`Some`] ee [`Option`].
///
/// Tilmaamuhu wuxuu keenaa hal qiime haddii [`Option`] uu yahay [`Some`], haddii kale midna.
///
/// `struct`-kan waxaa abuuray [`Option::iter_mut`] function.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Falanqeeye ka sarreeya qiimaha ku jira noocyada [`Some`] ee [`Option`].
///
/// Tilmaamuhu wuxuu keenaa hal qiime haddii [`Option`] uu yahay [`Some`], haddii kale midna.
///
/// `struct`-kan waxaa abuuray [`Option::into_iter`] function.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// Waxay qaadataa walx kasta oo ka mid ah [`Iterator`]: haddii ay tahay [`None`][Option::None], walxo kale lama qaadanayo, [`None`][Option::None]-na waa la soo celinayaa.
    /// Waa in [`None`][Option::None] ma dhacaan, weel la qiyamka [`Option`] kasta waxaa ku soo laabtay.
    ///
    /// # Examples
    ///
    /// Halkan waxaa ku qoran tusaale ah oo isabdal abyoonaha kasta oo vector ah.
    /// Waxaan u adeegsanaa noocyada la hubiyey ee `add` ee soo celiya `None` markii xisaabintu ay sababi doonto qulqulka.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Sidaad u aragto, tani waxay soo celin doontaa waxyaabaha la filayo, ee ansaxa ah.
    ///
    /// Halkan waxaa ku yaal tusaale kale oo isku dayaya inuu ka jaro mid ka mid ah liisaska kale ee tirada, markan hubinaya hoosta:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// Tan iyo element ee la soo dhaafay waa eber, waxaa underflow lahaa.Sidaas darteed, qiimaha keentay waa `None`.
    ///
    /// Halkan waa kala duwanaansho ah oo ku saabsan tusaale ahaan hore, taas oo muujinaysa in jirin xubno dheeraad ah waxaa laga qaadaa `iter` ka dib markii `None` ugu horeysay.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Tan iyo element saddexaad sababay underflow ah, ma xubno dheeraad ah la geeyay, sidaa qiimaha ugu dambeeya ee `shared` waa 6 (= `3 + 2 + 1`), ma 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Tan waxaa lagu badali karaa Iterator::scan marka cilladan waxqabadka la xirayo.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// Nooca qaladka ee ka dhasha codsashada isku dayga hawlwadeenka (`?`) qiime `None`.
/// Haddii aad rabto inaad u oggolaato `x?` (halka `x` uu yahay `Option<T>`) in loogu beddelo nooca qaladkaaga, waad hirgelin kartaa `impl From<NoneError>` ee `YourErrorType`.
///
/// Xaaladdaas, `x?` gudahood hawl soo celinaysa `Result<_, YourErrorType>` wuxuu u tarjumi doonaa qiimaha `None` natiijada `Err`.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// Kuweeda ka `Option<Option<T>>` in `Option<T>`
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// Fidsanaan kaliya ka saaraysaa hal heer oo xilliga kulaylaha mar:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}