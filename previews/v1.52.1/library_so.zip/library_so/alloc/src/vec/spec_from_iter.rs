use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Takhasuska trait waxaa loo adeegsaday Vec::from_iter
///
/// ## Garaafka waftiga:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Kiis caadi ah ayaa u gudbinaya vector hawl isla markiiba dib isugu ururisa vector.
        // Waan soo gaabin karnaa tan haddii IntoIter aan horay loo sii wadin.
        // Markii ay horumarsan tahay Waxaan sidoo kale dib u isticmaali karnaa xusuusta oo waxaan u dhaqaajin karnaa xogta dhinaca hore.
        // Laakiin waxaan kaliya sidaas yeelnaa marka natiijada Vec aysan lahaan doonin awood aan la adeegsan intii laga abuuri lahaa iyada oo loo marayo guud ahaan hirgelinta FromIterator.
        //
        // Xaddidaaddaas si adag daruuri uma aha maadaama habdhaqanka qoondaynta Vec si ula kac ah aan loo cayimin.
        // Laakiin waa doorasho muxaafidka ah.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // waa in soo dhaweeyo in spec_extend() tan extend() laftiisa ergooyinka inay spec_from for madhan VECs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Tani waxay adeegsaneysaa `iterator.as_slice().to_vec()` maxaa yeelay spec_extend waa inuu qaadaa tillaabooyin dheeri ah si looga jawaabo awoodda ugu dambeysa + dhererka oo markaa shaqo badan u qabato.
// `to_vec()` wuxuu si toos ah ugu qoondeeyaa qadarka saxda ah oo uu si sax ah u buuxiyo
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): leh cfg(test) habka `[T]::to_vec` ee dabiiciga ah, ee looga baahan yahay qeexitaankan, lama heli karo.
    // Halkii ay isticmaalaan shaqo `slice::to_vec` taasoo ah waxaa laga heli karaa oo keliya cfg(test) FG arki module slice::hack ee slice.rs wixii macluumaad dheeraad ah
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}