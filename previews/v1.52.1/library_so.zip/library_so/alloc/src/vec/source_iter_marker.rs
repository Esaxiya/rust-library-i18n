use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Tilmaame-yaqaan takhasus leh oo loogu talagalay in lagu soo ururiyo dhuumaha soo-noqda ee loo yaqaan 'Vec' iyadoo la isticmaalayo qoondaynta isha, ie
/// fulinta tuubada meesha taal.
///
/// SourceIter-ka waalidkiis trait ayaa lagama maarmaan u ah howlaha takhasuska leh si loo helo qoondaynta oo dib loo isticmaali doono.
/// Laakiin kuma filna in takhasusku ansax noqdo.
/// Ka eeg soohdin dheeri ah dusha.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-gudaha SourceIter/InPlaceIterable traits waxaa kaliya lagu fuliyaa silsiladaha Adapter <Adapter<Adapter<IntoIter>>> (dhammaantood waxaa iska leh core/std).
// Soohdinno dheeri ah oo ku saabsan hirgelinta adabtarada (wixii ka dambeeya `impl<I: Trait> Trait for Adapter<I>`) waxay kaliya ku tiirsan yihiin traits kale oo horey loogu calaamadeeyay takhasus ahaan traits (Nuqul, TrustedRandomAccess, FusedIterator).
//
// I.e. calaamadeyuhu kuma xirna nolosha inta nooc ee adeegsaduhu bixiyo.Modulo daloolka nuqul, oo takhasusyo kale oo dhowr ah horeyba ugu tiirsanaayeen.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Shuruudo dheeri ah oo aan lagu muujin karin trait bounds.Waxaan ku tiirsan eval const halkii:
        // a) ma ZSTs oo kale waxaa ay noqon doontaa qoondeeyntii u lahayn in ay isticmaalin iyo xisaabta pointer lahaa panic b) ciyaarta size sida looga baahan yahay Alloc heshiis c) alignments u dhigma sida ay heshiis Alloc loo baahan yahay
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // dib ugu noqoshada hirgelinta guud
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // isticmaal isku day-tan iyo
        // - waxay si fiican u xoojineysaa qaar ka mid ah adapters-yada
        // - si ka duwan inta badan qaababka soo noqnoqodka gudaha, waxay qaadataa oo keliya is &mut
        // - waxay noo oggolaanaysaa inaan tilmaamaha tilmaamaha ka soo saarno caloosha oo aan dib ugu soo celino dhamaadka
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // soo noqnoqoshada ayaa ku guuleysatay, madaxa ha u dhicin
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // hubi haddii SourceIter qandaraaska loo cuskaday digniin: haddii aysan ahaan lahayn xitaa ma gaari karno illaa heerkan
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // hubi qandaraaska InPlaceIterable.Tani waxay suurtogal tahay oo keliya haddii soo-saaraha uu horumariyay tilmaamaha isha gabi ahaanba.
        // Haddii ay isticmaasho marin aan la hubin iyada oo loo marayo TrustedRandomAccess markaa tilmaamaha isha ayaa ku sii jiri doona meeshiisii hore mana u adeegsan karno tixraac ahaan
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ku rid wax kasta oo haray dabada isha laakiin ka hor tag dhibicda qoondaynta lafteeda mar IntoIter ay ka baxdo baaxadda haddii dhibicda panics markaa waxaan sidoo kale daadineynaa walxo kasta oo lagu soo ururiyey dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // heshiiska InPlaceIterable aan la hufan halkan tan try_fold ayaa tixraac gaar ah si ay u pointer isha xaqiijin karo oo dhan aan samayn karnaa waa jeeg haddii ay weli ku kala duwan
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}