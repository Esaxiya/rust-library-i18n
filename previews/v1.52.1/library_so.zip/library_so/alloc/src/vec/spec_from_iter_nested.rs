use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// takhasuska kale trait for Vec::from_iter lagama maarmaan ah in takhasuso gacanta ay mudnaanta isa arki [`SpecFromIter`](super::SpecFromIter) wixii faahfaahin ah.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Aayar siyaalaha ugu horeysay, sida vector la doonayo in la balaariyay on siyaalaha this in kiis kasta markii iterable ma waxaa u faaruqiso, laakiin loop ee extend_desugared() ma si aad u aragto vector ka buuxo ee iterations loop ku xiga yar.
        //
        // Marka waxaan sifiican u helaynaa saadaasha branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // waa in soo dhaweeyo in spec_extend() tan extend() laftiisa ergooyinka inay spec_from for madhan VECs
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // waa in soo dhaweeyo in spec_extend() tan extend() laftiisa ergooyinka inay spec_from for madhan VECs
        //
        vector.spec_extend(iterator);
        vector
    }
}