//! Nooc isdaba-joog ah oo koriin ah oo ka kooban waxyaabo loo qoondeeyay, oo qoran `Vec<T>`.
//!
//! Vectors waxay leeyihiin tusmaynta `O(1)`, riix x01X ah (ilaa dhamaadka) iyo x02X pop (laga bilaabo dhamaadka).
//!
//!
//! Vectors waxay hubisaa inaysan waligood qoondayn wax ka badan `isize::MAX` bytes.
//!
//! # Examples
//!
//! Waxaad si cad u abuuri kartaa [`Vec`] leh [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ama adoo adeegsanaya makro [`vec!`] ah:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // toban eber
//! ```
//!
//! Waad ku qiimeyn kartaa [`push`] dhamaadka vector (kaas oo kori doona vector sida loogu baahdo):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Qiimaha badeecaddu waxay u shaqeysaa si isku mid ah:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors sidoo kale waxay taageertaa tusmeynta (iyada oo loo marayo [`Index`] iyo [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Nooc diyaarsan oo isdaba joog ah, loona qoro `Vec<T>` laguna dhawaaqo 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Dhaqale [`vec!`] waxaa la siiyaa initialization samaynaysaa sahlan:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Waxa kale oo initialize karo element kasta oo `Vec<T>` la qiimo ah la siiyo.
/// Tani waxay ka waxtar badan tahay fulinta qoondaynta iyo bilaabidda tallaabooyin gaar ah, gaar ahaan marka la bilaabayo vector eber ah:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Waxyaabaha soo socdaa waa u dhigmayaan, laakiin waa suuragal inay gaabis noqdaan:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Wixii macluumaad dheeraad ah, eeg [Capacity and Reallocation](#capacity-and-reallocation).
///
/// U isticmaal `Vec<T>` sidii isku-dheelitirnaan hufan:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Daabacadaha 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Nooca `Vec` wuxuu u oggolaanayaa helitaanka qiyamka tusmada, maxaa yeelay wuxuu hirgeliyaa [`Index`] trait.Tusaale ayaa noqon doona mid aad u cad:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // waxay soo bandhigi doontaa '2'
/// ```
///
/// Si kastaba ha noqotee taxaddar: haddii aad isku daydo inaad gasho tusmo aan ku jirin `Vec`, barnaamijkaaga ayaa panic!Ma sameyn kartid tan:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Adeegso [`get`] iyo [`get_mut`] haddii aad rabto inaad hubiso in tilmaantu ku jirto `Vec` iyo in kale.
///
/// # Slicing
///
/// `Vec` wuxuu noqon karaa mutable.Dhinaca kale, jeexjeexyada ayaa ah walxo akhrin kara oo keliya.
/// Si aad u hesho [slice][prim@slice], isticmaal [`&`].Tusaale:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... waana intaas!
/// // sidoo kale waad u samayn kartaa sidan:
/// let u: &[usize] = &v;
/// // ama sidan oo kale:
/// let u: &[_] = &v;
/// ```
///
/// Rust, waa wax caadi ah in loo gudbiyo xaleefyo dood ahaan halkii laga dhaafi lahaa vectors markaad rabto inaad siiso akhris.Waxaa la mid ah [`String`] iyo [`&str`].
///
/// # Awood iyo dib u dejin
///
/// Awoodda vector waa xaddiga meel bannaan oo loo qoondeeyay kasta oo xubno ka future in lagu dari doonaa gal vector ah.Tan laguma qaldi karo *dhererka* vector, oo tilmaamaysa tirada walxaha dhabta ah ee ku jira vector.
/// Haddii dhererka 'vector' uu ka bato awoodiisa, awoodeeda si otomaatig ah ayaa loo kordhin doonaa, laakiin canaasiirtiisa waa in dib loo qoondeeyo.
///
/// Tusaale ahaan, vector oo leh awood 10 iyo dherer 0 wuxuu noqon lahaa vector madhan oo leh 10 cunsur oo dheeri ah.Ku riixida 10 ama walxo ka yar vector ma badali doonto awoodeeda ama ma keeneyso dib u dejin inay dhacdo.
/// Si kastaba ha noqotee, haddii dhererka 'vector' laga dhigo 11, waa inuu dib u qoondeeyaa, taas oo gaabis noqon karta.Sababtaas awgeed, waxaa lagugula talinayaa inaad isticmaasho [`Vec::with_capacity`] markasta oo ay suurtagal tahay si loo caddeeyo inta weyn ee la filayo vector inay hesho.
///
/// # Guarantees
///
/// Iyada oo ay ugu wacan tahay dabeecadeeda aasaasiga ah ee cajiibka ah, `Vec` waxay samaysaa dammaanad badan oo ku saabsan qaabkeeda.Tani waxay hubineysaa inay tahay sida ugu hooseysa ee suurtogalka ah kiiska guud, oo si sax ah loogu maareyn karo siyaabo hore iyadoo loo marayo koodh aan aamin ahayn.Ogsoonow in dammaanad qaadyadan ay tixraacayaan `Vec<T>` aan u qalmin.
/// Haddii cabirro noocyo dheeri ah lagu daro (tusaale, si loo taageero qoondeeyayaasha caadada ah), xad-dhaafka ka bixitaankooda ayaa beddeli kara dhaqanka.
///
/// Inta badan aasaas ahaan, `Vec` waa oo had iyo jeer wuxuu noqon doonaa (tilmaame, awood, dherer) saddex-jibbaar.No more, no less.Amarka goobahan gabi ahaanba lama cayimin, waana inaad isticmaashaa habab ku habboon si aad wax uga beddelo kuwan.
/// Tilmaameyuhu waligiis waxba ma noqon doono, markaa noocan ayaa ah null-tilmaame-fiicnaanaya.
///
/// Si kastaba ha noqotee, tilmaame ayaa laga yaabaa inuusan dhab ahaantii tilmaamin xusuusta loo qoondeeyay.
/// Gaar ahaan, haddii aad dhisto `Vec` lehna awood 0 adoo adeegsanaya [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], ama aad ugu yeeraysid [`shrink_to_fit`] Vec madhan, ma qoondeyn doono xusuusta.Sidoo kale, haddii aad ku keydiso noocyada cabbirkoodu yahay eber ee gudaha `Vec`, boos uma qoondeyn doono iyaga.
/// *Xusuusnow in kiiskan `Vec` uusan soo sheegi karin [`capacity`] ee 0*.
/// `Vec` qoondeyn doonaa haddii iyo haddii kaliya [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Guud ahaan, faahfaahinta qoondaynta Vec` waa mid aad u khiyaano badan-haddii aad damacsan tahay inaad qoondayso xusuusta adoo adeegsanaya `Vec` oo aad u isticmaasho wax kale (ama inaad u gudubto koodh aan aamin ahayn, ama aad dhisto urur kuu gaar ah oo xusuusta lagu taageeray), hubi si loola macaamilo xusuustaan adoo adeegsanaya `from_raw_parts` si aad uga soo kabato `Vec` ka dibna aad u daadiso.
///
/// Hadday `Vec`*leedahay* xasuus loo qoondeeyay, markaa xusuusta ay tilmaamaysaa waxay taal taallada (sida lagu qeexay qoondeeyaha Rust waxaa loo qaabeeyey in loo isticmaalo si ku habboon), oo tilmaamteeda tilmaamaysa [`len`] ayaa la bilaabay, walxo isku xigxig ah si waafaqsan (maxaad eeg haddii aad ku qasabtay jeex), oo ay ku xigto [``awoodda ']' ',`` (' 'len`] si macquul ah oo aan la ogaan karin, waxyaabo isku mid ah.
///
///
/// A vector ay ku jiraan xubno ka `'a'` iyo `'b'` leh awoodda 4 lagu visualized karaa sida hoos ku.qayb ka top waa struct `Vec` ah, waxa ku jira tilmaamaha ah in madaxa qoondaynta in taalladan, oo dhererkiisu iyo awoodda.
/// Qaybta ugu hooseysa waa qoondaynta taallada, oo ah aalad isku xidhan oo xasuusta ah.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** waxay u taagan tahay xusuusta aan la bilaabin, eeg [`MaybeUninit`].
/// - Note: ABI ma ahan mid xasilloon oo `Vec` wax dammaanad ah kama qaadin qaabka xusuusta (oo ay ku jiraan amarka beeraha).
///
/// `Vec` waligood ma qaban doono "small optimization" halkaas oo walxaha dhabta ah ay ku kaydsan yihiin xargaha laba sababood awgood:
///
/// * Way ka sii adkayn lahayd koodhka aan ammaanka lahayn in si sax ah loo maareeyo `Vec`.Waxyaabaha ku jira `Vec` ma lahaan doonaan cinwaan xasilloon haddii la dhaqaajiyo oo keliya, waana ka sii adkaan lahayd in la ogaado haddii `Vec` uu dhab ahaan u qoondeeyay xusuusta.
///
/// * Waxay ciqaabi laheyd kiiska guud, oo ku soo kordhinaya branch marin kasta.
///
/// `Vec` si otomaatig ah iskama dhimi doono, xitaa haddii ay gebi ahaanba madhan tahay.Tani waxay xaqiijineysaa inaysan jirin qoondeyn aan loo baahnayn ama heshiisyo wax lagu kala iibsanayo.Faaruqinta `Vec` ka dibna dib loogu soo celinayo isla isla [`len`] waa inaan wax wicitaan ah loogu yeerin qoondeeyaha.Haddii aad rabto inaad lacag la'aan ah ilaa xusuusta aan la isticmaalin, isticmaali [`shrink_to_fit`] ama [`shrink_to`].
///
/// [`push`] iyo [`insert`] marna (dib) uma qoondeyn doono haddii awoodda la soo sheegay ay ku filan tahay.[`push`] iyo [`insert`]* *(dib) ayey u qoondeyn doonaan haddii [``len`]] '==' ['awoodda'].Taasi waa, awoodda la soo sheegay waa mid gebi ahaanba sax ah, laguna tiirsanaan karo.Xitaa waxaa loo isticmaali karaa in gacanta lagu xoreeyo xasuusta loo qoondeeyay `Vec` haddii la doonayo.
/// Hababka gelinta jumlada ah *way* qonayn karaan, xitaa marka aan loo baahnayn.
///
/// `Vec` dammaanad kama qaadayso istiraatiijiyad kobcitaan gaar ah marka dib loo qoondeeyo markii la buuxinayo, ama marka la yiraahdo [`reserve`].Istiraatiijiyadda hadda waa aasaasiga ah iyo waxaa laga yaabaa in la caddeeyo suurad wacan si ay u isticmaalaan arrin aan joogto ah koritaanka.Istaraatiijiyad kasta oo la adeegsado waxay dabcan damaanad qaadeysaa *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, iyo [`Vec::with_capacity(n)`][`Vec::with_capacity`], dhammaantood waxay soo saari doonaan `Vec` oo leh sida saxda ah awoodda la codsaday.
/// Haddii [``len`]] '==``' 'power`], (sida kiiska loo yaqaan' [`vec!`] macro '), markaa `Vec<T>` ayaa loo rogi karaa ama laga soo saari karaa [`Box<[T]>`][owned slice] iyada oo aan dib loo sii deyn ama loo dhaqaajin canaasiirta.
///
/// `Vec` si gaar ah uma dulmarin doono wixii xog ah ee laga saaray, laakiin sidoo kale si gaar ah uma ilaalin doono.Its xasuusta uninitialized waa meel bannaan oo la xoqo in ay isticmaali karaan si kastaba ha ahaatee waxa uu doonayo.Waxay guud ahaan uun sameyn doontaa wax kasta oo ugu waxtar badan ama haddii kale si fudud loo hirgelin karo.Ha ku tiirsan yihiin xog saaro in laga tirtirayaa ujeedooyin ammaanka.
/// Xitaa haddii aad hoos u dhigto `Vec`, keydkeeda waxaa laga yaabaa in si fudud dib loogu isticmaalo `Vec` kale.
/// Xitaa haddii aanad eber xasuusin `` Vec '' ah lahayn, taasi dhab ahaan ma dhici karto maxaa yeelay yididiilluhu uma tixgeliyo tan waxyeellooyin ay tahay in la ilaaliyo.
/// Waxaa jira hal kiis oo aanan jabin doonin, si kastaba ha noqotee: adeegsiga lambarka `unsafe` si loogu qoro awoodda xad-dhaafka ah, ka dibna kordhinta dhererka iswaafajinta, had iyo jeer waa ansax.
///
/// Waqtigaan la joogo, `Vec` ma damaanad qaadayo sida ay walxaha u soo tuurayaan.
/// Amarku wuu is badalay waagii hore waxaana laga yaabaa inuu markale is badalo.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Hababka dhaxalka ah
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Wuxuu dhisaa `Vec<T>` cusub, oo madhan.
    ///
    /// vector ma qoondeyn doono ilaa walxaha lagu riixo.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Wuxuu dhisaa `Vec<T>` cusub, oo madhan oo leh awoodda la cayimay.
    ///
    /// vector wuxuu awoodi doonaa inuu si sax ah u haysto walxaha `capacity` iyadoon dib loo qoondeyn karin.
    /// Haddii `capacity` uu yahay 0, vector ma qoondeyn doono.
    ///
    /// Waxaa muhiim ah in la ogaado in kastoo vector soo laabtay uu leeyahay *awoodda* lagu qeexay, vector wuxuu yeelan doonaa eber *dherer*.
    ///
    /// Faahfaahinta farqiga u dhexeeya dhererka iyo awoodda, eeg *[Awoodda iyo dib u dejinta]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector wuxuu ka kooban yahay waxyaabaha jirin, inkasta oo uu leeyahay awood ka badan
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Kuwan dhammaantood waxaa lagu sameeyaa iyada oo aan dib loo qoondeynin ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... laakiin tani waxay ka dhigi kartaa vector dib u habeyn
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Wuxuu si toos ah uga abuuraa `Vec<T>` qaybaha cayriin ee vector kale.
    ///
    /// # Safety
    ///
    /// Tani waa mid aad u khatar ah, sababo la xiriira tirada soo-galootiga aan la hubin:
    ///
    /// * `ptr` waxay ubaahantahay in horey loogu qoondeeyay iyada oo loo marayo "'String`]/`Vec<T>`(Ugu yaraan, waxaa aad u badan tahay in uu noqdo mid aan sax ahayn, haddii waxa aan ahaa).
    /// * `T` baahan yahay in ay isku qiyaas iyo in lays sida waxa `ptr` waxaa loo qoondeeyey la.
    ///   (`T` oo leh isku dheelitirnaan aan sidaa u sii badnayn kuma filna, iswaafajintu runti waxay u baahan tahay in loo siman yahay si loo qanciyo shuruudaha [`dealloc`] ee ah in xusuusta loo qoondeeyo oo lagu wareejiyo isla qaabeynta.)
    ///
    /// * `length` wuxuu ubaahanyahay inuu kayaryahay ama udhigma `capacity`.
    /// * `capacity` waxay u baahan tahay inay noqoto kartida tilmaanta lagu qoondeeyay.
    ///
    /// Ku xad gudubka kuwan waxay sababi kartaa dhibaatooyin sida musuqmaasuq qaab dhismeedka xogta qoondada.Tusaale ahaan **maahan** amaan in laga dhiso `Vec<u8>` tilmaame ilaa C `char` soohdin leh dherer `size_t` ah.
    /// Sidoo kale amaan maahan in laga dhiso mid ka mid ah `Vec<u16>` iyo dhererkiisa, maxaa yeelay qeybiyaha ayaa daneynaya isku xirnaanta, labadan noocna waxay leeyihiin iswaafajinno kala duwan.
    /// Kaydinta waxaa loo qoondeeyay isugeynta 2 (ee `u16`), laakiin ka dib markii loo rogo `Vec<u8>` waxaa lagu wareejin doonaa isugeynta 1.
    ///
    /// Lahaanshaha `ptr` waxaa si hufan loogu wareejiyaa `Vec<T>` oo markaa laga yaabo in uu meeleeyo, dib u qoondeeyo ama beddelo waxyaabaha ku jira xusuusta uu tilmaameyuhu tilmaamayo sida uu doono.
    /// Hubso inaanay wax kale isticmaalin tilmaamaha ka dib markaad wacdo shaqadan.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Cusboonaysii tan markii vec_into_raw_parts la xasiliyo.
    ///     // Kahortag orodka `` v '' wax burburiyaha sidaa darteed waxaan si buuxda gacanta ugu haynaa qoondaynta.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Soo jiid qaybaha kala duwan ee muhiimka ah ee macluumaadka ku saabsan `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Ku dul qor xasuusta 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Wax walba dib ugu celi Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Wuxuu dhisaa `Vec<T, A>` cusub, oo madhan.
    ///
    /// vector ma qoondeyn doono ilaa walxaha lagu riixo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Wuxuu dhisayaa `Vec<T, A>` cusub, oo madhan oo leh awooda la cayimay ee loo qoondeeyay.
    ///
    /// vector wuxuu awoodi doonaa inuu si sax ah u haysto walxaha `capacity` iyadoon dib loo qoondeyn karin.
    /// Haddii `capacity` uu yahay 0, vector ma qoondeyn doono.
    ///
    /// Waxaa muhiim ah in la ogaado in kastoo vector soo laabtay uu leeyahay *awoodda* lagu qeexay, vector wuxuu yeelan doonaa eber *dherer*.
    ///
    /// Faahfaahinta farqiga u dhexeeya dhererka iyo awoodda, eeg *[Awoodda iyo dib u dejinta]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector wuxuu ka kooban yahay waxyaabaha jirin, inkasta oo uu leeyahay awood ka badan
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Kuwan dhammaantood waxaa lagu sameeyaa iyada oo aan dib loo qoondeynin ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... laakiin tani waxay ka dhigi kartaa vector dib u habeyn
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Wuxuu si toos ah uga abuuraa `Vec<T, A>` qaybaha cayriin ee vector kale.
    ///
    /// # Safety
    ///
    /// Tani waa mid aad u khatar ah, sababo la xiriira tirada soo-galootiga aan la hubin:
    ///
    /// * `ptr` waxay ubaahantahay in horey loogu qoondeeyay iyada oo loo marayo "'String`]/`Vec<T>`(Ugu yaraan, waxaa aad u badan tahay in uu noqdo mid aan sax ahayn, haddii waxa aan ahaa).
    /// * `T` baahan yahay in ay isku qiyaas iyo in lays sida waxa `ptr` waxaa loo qoondeeyey la.
    ///   (`T` oo leh isku dheelitirnaan aan sidaa u sii badnayn kuma filna, iswaafajintu runti waxay u baahan tahay in loo siman yahay si loo qanciyo shuruudaha [`dealloc`] ee ah in xusuusta loo qoondeeyo oo lagu wareejiyo isla qaabeynta.)
    ///
    /// * `length` wuxuu ubaahanyahay inuu kayaryahay ama udhigma `capacity`.
    /// * `capacity` waxay u baahan tahay inay noqoto kartida tilmaanta lagu qoondeeyay.
    ///
    /// Ku xad gudubka kuwan waxay sababi kartaa dhibaatooyin sida musuqmaasuq qaab dhismeedka xogta qoondada.Tusaale ahaan **maahan** amaan in laga dhiso `Vec<u8>` tilmaame ilaa C `char` soohdin leh dherer `size_t` ah.
    /// Sidoo kale amaan maahan in laga dhiso mid ka mid ah `Vec<u16>` iyo dhererkiisa, maxaa yeelay qeybiyaha ayaa daneynaya isku xirnaanta, labadan noocna waxay leeyihiin iswaafajinno kala duwan.
    /// Kaydinta waxaa loo qoondeeyay isugeynta 2 (ee `u16`), laakiin ka dib markii loo rogo `Vec<u8>` waxaa lagu wareejin doonaa isugeynta 1.
    ///
    /// Lahaanshaha `ptr` waxaa si hufan loogu wareejiyaa `Vec<T>` oo markaa laga yaabo in uu meeleeyo, dib u qoondeeyo ama beddelo waxyaabaha ku jira xusuusta uu tilmaameyuhu tilmaamayo sida uu doono.
    /// Hubso inaanay wax kale isticmaalin tilmaamaha ka dib markaad wacdo shaqadan.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Cusboonaysii tan markii vec_into_raw_parts la xasiliyo.
    ///     // Kahortag orodka `` v '' wax burburiyaha sidaa darteed waxaan si buuxda gacanta ugu haynaa qoondaynta.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Soo jiid qaybaha kala duwan ee muhiimka ah ee macluumaadka ku saabsan `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Ku dul qor xasuusta 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Wax walba dib ugu celi Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Waxay u kala qaaddaa `Vec<T>` qaybaha ceeriin ee ay ka kooban tahay.
    ///
    /// Waxay kucelisaa tilmaamaha ceyriinka xogta salka, dhererka vector (canaasiirta), iyo awooda loo qoondeeyay xogta (canaasiirta).
    /// Kuwani waa doodo isku mid ah oo isku mid ah sida doodaha loo qaado [`from_raw_parts`].
    ///
    /// Kadib markuu wacay shaqadan, soo wacaha ayaa mas'uul ka ah xasuusta uu horey u maamuli jiray `Vec`.
    /// Sida kaliya ee tan lagu sameyn karo waa in lagu beddelo tilmaamaha ceyriinka, dhererka, iyo awoodda oo dib loogu celiyo `Vec` oo leh shaqadii [`from_raw_parts`], taas oo u oggolaaneysa burburiyaha inuu sameeyo nadiifinta.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Hadda waxaan ku sameyn karnaa isbedel qaybaha, sida ku wareejinta tilmaamaha ceyriinka nooc u dhigma.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Waxay u kala qaaddaa `Vec<T>` qaybaha ceeriin ee ay ka kooban tahay.
    ///
    /// Waxay ku celineysaa tilmaamaha ceyriinka ah xogta gundhigga, dhererka vector (canaasiir ahaan), awoodda loo qoondeeyay xogta (canaasiirta), iyo qeybiyaha.
    /// Kuwanu waa dood la mid ah si la mid ah sida doodo si [`from_raw_parts_in`].
    ///
    /// Kadib markuu wacay shaqadan, soo wacaha ayaa mas'uul ka ah xasuusta uu horey u maamuli jiray `Vec`.
    /// Sida kaliya ee tan lagu sameyn karo waa in lagu beddelo tilmaamaha ceyriinka, dhererka, iyo awoodda oo dib loogu celiyo `Vec` oo leh shaqadii [`from_raw_parts_in`], taas oo u oggolaaneysa burburiyaha inuu sameeyo nadiifinta.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Hadda waxaan ku sameyn karnaa isbedel qaybaha, sida ku wareejinta tilmaamaha ceyriinka nooc u dhigma.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Sooceliyaa tirada cunsurrada 'vector' hayn karo iyadoon dib loo qoondeyn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Wuxuu keyd u hayaa ugu yaraan `additional` canaasiir dheeri ah oo la gelinayo `Vec<T>` la siiyay.
    /// Ururinta ayaa laga yaabaa inay keydiso meelo badan si looga fogaado dib-u-dejinno badan
    /// Ka dib markaad wacdo `reserve`, awooddu way ka weynaan doontaa ama la mid noqon doontaa `self.len() + additional`.
    /// Waxba ma qabanayso haddii awoodda mar horeba ku filan tahay.
    ///
    /// # Panics
    ///
    /// Panics hadii awooda cusubi ka badato `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Kaydka awoodda ugu yar ee xubno ka dhab `additional` dheeraad ah in la geliyo `Vec<T>` la siiyey.
    ///
    /// Ka dib markaad wacdo `reserve_exact`, awooddu way ka weynaan doontaa ama la mid noqon doontaa `self.len() + additional`.
    /// Waxba ma qabanayso haddii awoodda mar horeba ku filan tahay.
    ///
    /// Ogsoonow in qoondeeyaha uu siin karo ururinta meel ka badan inta ay codsato.
    /// Sidaa darteed, awoodda laguma halleyn karo inay si uun ugu yar tahay.
    /// Doorbido `reserve` haddii la filayo gelinta future.
    ///
    /// # Panics
    ///
    /// Panics haddii awoodda cusubi buux dhaafiso `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Wuxuu isku dayayaa inuu keydiyo awoodda ugu yaraan `additional` canaasiir dheeri ah oo la gelinayo `Vec<T>` la siiyay.
    /// Ururinta ayaa laga yaabaa inay keydiso meelo badan si looga fogaado dib-u-dejinno badan
    /// Ka dib markaad wacdo `try_reserve`, awooddu way ka weynaan doontaa ama la mid noqon doontaa `self.len() + additional`.
    /// Waxba ma qabanayso haddii awoodda mar horeba ku filan tahay.
    ///
    /// # Errors
    ///
    /// Haddii awooddu buux dhaafto, ama qoondaduhu ku soo warramo guuldarro, markaa qalad ayaa la soo celiyaa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Sii-keydi xusuusta, kana bax haddii aynaan kari karin
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Hadda waxaan ognahay inaysan tani OOM ku dhex dheeli karin shaqadeenna adag
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // aad u dhib badan
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Wuxuu isku dayayaa inuu keydiyo awoodda ugu yar ee walxaha saxda ah ee `additional` si loogu daro `Vec<T>` la siiyay.
    /// Ka dib markaad wacdo `try_reserve_exact`, awooddu way ka weynaan doontaa ama la mid noqon doontaa `self.len() + additional` haddii ay soo celiso `Ok(())`.
    ///
    /// Waxba ma qabanayso haddii awoodda mar horeba ku filan tahay.
    ///
    /// Ogsoonow in qoondeeyaha uu siin karo ururinta meel ka badan inta ay codsato.
    /// Sidaa darteed, awoodda laguma halleyn karo inay si uun ugu yar tahay.
    /// Doorbido `reserve` haddii la filayo gelinta future.
    ///
    /// # Errors
    ///
    /// Haddii awooddu buux dhaafto, ama qoondaduhu ku soo warramo guuldarro, markaa qalad ayaa la soo celiyaa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Sii-keydi xusuusta, kana bax haddii aynaan kari karin
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Hadda waxaan ognahay inaysan tani OOM ku dhex dheeli karin shaqadeenna adag
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // aad u dhib badan
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Ihin awooda vector ah intii suurtogal ah.
    ///
    /// Waxay hoos u dhici doontaa sida ugu dhow ee suurtogalka ah dhererka laakiin qoondeeyaha ayaa wali ku wargelin kara vector inay jiraan meel ay ku yaalliin curiyeyaal dheeri ah.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Awooddu marna kama yaraanayso dhererka, mana jiraan wax la sameeyo markay siman yihiin, sidaa darteed waan iska ilaalin karnaa kiiska panic ee `RawVec::shrink_to_fit` anaga oo kaliya ugu yeerna karti weyn.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Waxay yareysaa awoodda vector oo leh xadhig hoose.
    ///
    /// Awoodda ayaa sii ahaan doonta ugu yaraan mid weyn sida dhererka iyo qiimaha la keenay.
    ///
    ///
    /// Haddii awoodda hadda jirta ay ka yar tahay xadka ugu hooseeya, tani waa maya-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// U baddela vector x00X.
    ///
    /// Ogsoonow in tani ay hoos u dhigeyso awood kasta oo xad-dhaaf ah.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Awood kasta oo xad-dhaaf ah ayaa laga saaraa:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Gaabiyo vector, haynta walxaha ugu horreeya ee `len` iyo intiisa kale la dhigo.
    ///
    /// Haddii `len` waa ka weyn yahay dhererka hadda vector ee, tani saameyn ah kuma laha.
    ///
    /// Habka [`drain`] wuxuu ku dayan karaa `truncate`, laakiin wuxuu sababayaa in canaasiirta xad-dhaafka ah la soo celiyo halkii laga daadin lahaa.
    ///
    ///
    /// Ogsoonow in qaabkani uusan wax saameyn ah ku yeelanaynin awooda loo qoondeeyay ee 'vector'.
    ///
    /// # Examples
    ///
    /// U jajabinta shan walxaha vector illaa laba cunsur:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Wax goyn ah ma dhacdo marka `len` ka weynaado dhererka hadda jira ee vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncating markii `len == 0` u dhiganta wacaya habka [`clear`] ah.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Tani waa ammaan maxaa yeelay:
        //
        // * jeexitaanka loo gudbiyay `drop_in_place` waa ansax;kiiska `len > self.len` wuxuu ka fogaanayaa inuu abuuro jeex aan ansax ahayn, iyo
        // * `len` ee vector wuu yaraaday kahor inta uusan wicin `drop_in_place`, sida in wax qiimo ah aan labalaaban doonin hadii `drop_in_place` ay ahaan laheyd panic hal mar (haduu panics labo jeer yahay, barnaamijku wuu soo ridayaa).
        //
        //
        //
        unsafe {
            // Note: Waa ula kac in kani yahay `>` oo uusan ahayn `>=`.
            //       Ku beddelkiisa `>=` waxay leedahay saameyn waxqabad xumo mararka qaarkood.
            //       Ka eeg #78884 wixii intaa ka badan.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Waxay soo saartaa jeex ka kooban dhammaan vector.
    ///
    /// U dhiganta `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Waxay soo saartaa jeex jeexan oo dhan vector.
    ///
    /// U dhiganta `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Kuceliyaa tilmaame cayriin keydka vector.
    ///
    /// Wicitaanku waa inuu hubiyaa in vector uu ka cimri dheer yahay tilmaamaha shaqadan ay soo noqotay, haddii kale waxay ku dambaynaysaa tilmaamidda qashinka.
    /// Wax ka beddelka vector wuxuu sababi karaa in keydkeeda dib loo qoondeeyo, taas oo waliba ka dhigaysa tilmaam kasta oo ku saabsan iyada oo aan ansax ahayn.
    ///
    /// Wicitaanku waa inuu sidoo kale hubiyaa in xusuusta tilmaame (non-transitively) tilmaamaya aan waligeed loo qorin (marka laga reebo gudaha `UnsafeCell`) iyadoo la adeegsanayo tilmaamahan ama tilmaame kasta oo laga soo dheegtay.
    /// Haddii aad u baahan tahay in ay isbaddali ka kooban jeex, isticmaal [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Waxaan hoos u dhignaa habka jeexitaanka ee isla magaca si looga fogaado in loo maro `deref`, oo abuuraya tixraac dhexdhexaad ah.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Ku soo celiya tilmaame la beddeli karo oo aan aamin ahayn oo lagu keydiyo vector.
    ///
    /// Wicitaanku waa inuu hubiyaa in vector uu ka cimri dheer yahay tilmaamaha shaqadan ay soo noqotay, haddii kale waxay ku dambaynaysaa tilmaamidda qashinka.
    ///
    /// Wax ka beddelka vector wuxuu sababi karaa in keydkeeda dib loo qoondeeyo, taas oo waliba ka dhigaysa tilmaam kasta oo ku saabsan iyada oo aan ansax ahayn.
    ///
    /// # Examples
    ///
    /// ```
    /// // U qoondee vector weyn oo ku filan 4 cunsur.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Ku bilaabi walxaha adoo qoraya tilmaamaha cayriin, ka dibna dherer deji.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Waxaan hoos u dhignaa habka jeexitaanka ee isla magaca si looga fogaado in loo maro `deref_mut`, oo abuuraya tixraac dhexdhexaad ah.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Sooceliyaa inay marjic u allocator sababaya.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Waxay ku qasbeysaa dhererka vector illaa `new_len`.
    ///
    /// Tani waa hawlgal heer-hoose ah oo aan haynin mid ka mid ah kuwa isbeddelaya ee caadiga ah ee nooca.
    /// Caadi ahaan beddelida dhererka vector waxaa lagu sameeyaa iyadoo la adeegsanayo mid ka mid ah howlaha badbaadada badalkeeda, sida [`truncate`], [`resize`], [`extend`], ama [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` waa inuu kayaryahay ama la egyahay [`capacity()`].
    /// - Cunsurrada ku jirta `old_len..new_len` waa in la bilaabaa.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Habkani wuxuu faa'iido u yeelan karaa xaaladaha uu vector ugu adeegayo keydka koodh kale, gaar ahaan FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Tani waa uun lafaha yar tusaale ahaan doc ah;
    /// # // ma u isticmaali sida dhibic-upka maktabadda dhab ah.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Marka loo eego dukumiintiyada habka FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // AMMAANKA: Markuu `deflateGetDictionary` soo celiyo `Z_OK`, wuxuu hayaa taas:
    ///     // 1. `dict_length` canaasiirta ayaa la bilaabay.
    ///     // 2.
    ///     // `dict_length` <=awoodda (32_768) taasoo ka dhigaysa `set_len` mid aamin ah oo la wici karo.
    ///     unsafe {
    ///         // Samee wicitaanka FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... kuna cusboonaysii dhererka wixii la bilaabay.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// In kasta oo tusaalaha soo socdaa uu yahay mid dhawaq leh, waxaa jira xuub xusuus ah tan iyo markii vectors gudihiisa aan la siidayn kahor wicitaanka `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` waa madhan tahay markaa cunsurro uma baahna in la bilaabo.
    /// // 2. `0 <= capacity` had iyo jeer wuxuu hayaa wax kasta oo `capacity` ah.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Caadi ahaan, halkan, qofku wuxuu isticmaali lahaa [`clear`] halkii uu si sax ah ugu daadin lahaa waxyaabaha ku jira isla markaana uusan u daadin xusuusta.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Bixisaa element ah ka vector oo u celinta.
    ///
    /// Cunsurka laga saaray waxaa lagu beddelay cunsurkii ugu dambeeyay ee vector.
    ///
    /// Tani ma ilaalineyso dalbashada, laakiin waa O(1).
    ///
    /// # Panics
    ///
    /// Panics haddii `index` ka baxsan yahay.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Waxaan ku beddeleynaa is-tuska [index] cunsurka ugu dambeeya.
            // Ogsoonow in haddii jeegga soohdimaha kor ku xusan uu guuleysto waa inay jirtaa cunsur ugu dambeeya (kaasoo noqon kara naftiisa [index] lafteeda).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Gelinaysa curiye meel `index` ah oo ka mid ah vector, oo u rogaya dhammaan walxaha ka dib midigta.
    ///
    ///
    /// # Panics
    ///
    /// Panics haddii `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // meel loogu talagalay cunsurka cusub
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // isku hallayn karo kaalinta The in ay ku riday qiimaha cusub
            //
            {
                let p = self.as_mut_ptr().add(index);
                // U wareeji wax walba si aad boos ugu hesho.
                // (Ku-nuqulka qaybta 'index`th' laba meelood oo isku xigxigta)
                ptr::copy(p, p.offset(1), len - index);
                // Ku qor, adoo dib u qoraya nuqulkii ugu horreeyay ee 'index`th element'.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Wuxuu ka saaraa kuna soo celiyaa cunsurka meesha uu ka taagan yahay `index` ee vector, isagoo u rogaya dhan walxaha bidix.
    ///
    ///
    /// # Panics
    ///
    /// Panics haddii `index` ka baxsan yahay.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // meesha aan ka qaadaneyno.
                let ptr = self.as_mut_ptr().add(index);
                // nuqul ka soo sameyso, adigoon badbaado qabin haysana nuqul qiimaha salka ku haya iyo vector isla waqtigaas.
                //
                ret = ptr::read(ptr);

                // Shift wax walba hoos si dheregtaan barta in.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Haysanayaa kaliya walxaha uu cayimay saadaashu.
    ///
    /// Si kale haddii loo dhigo, ka saar dhammaan walxaha `e` sida `f(&e)` u soo celiyo `false`.
    /// Habkani wuxuu ku shaqeeyaa meesha, booqashada walxaha si sax ah hal mar asalka asalka ah, wuxuuna ilaaliyaa amarka walxaha haray.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Maxaa yeelay, xubno ka yihiin booqday si sax ah mar si asalka, gobolka dibadda waxaa loo isticmaali karaa si ay u go'aamiyaan xubno si ay u sii.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Ka fogow dhibic laba jibbaaran haddii ilaaliyaha dhibcaha aan la fulin, maadaama aan sameyn karno godad qaar inta hawshu socoto.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-processing len-> |^-xigta si loo hubiyo
        //                  | <-tirtiray cnt-> |
        //      | <-original_len-> |La ilaaliyey: Qaybaha saadaashu waxay ku soo noqdaan run ahaan.
        //
        // Hole: Dhaqdhaqaaqa ama hoos udhaca qaybta curiyaha.
        // Hubin: Waxyaabaha ansax ah oo aan la hubin.
        //
        // Ilaaliyahaan dhibcaha ah ayaa loo yeeri doonaa marka la saadaaliyo ama `drop` ee walxaha argaggaxsan.
        // Waxay u wareejisaa walxaha aan la hubin si ay u daboolaan godadka iyo `set_len` dhererka saxda ah.
        // Xaaladaha markii la saadaalinayo iyo `drop` aan waligood baqin, waa la hagaajin doonaa.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // BADBAADADA: Raadinta waxyaabaha aan la hubin waa inay ansax noqotaa tan iyo weligeen ma taabanayno.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // AMMAANKA: Ka dib markii buuxinta godadka, alaabta oo dhan waa in xasuusta jiidda.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // BADBAADADA: Cunsurka aan la hubin waa inuu ansax yahay.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Horumariyo hore si looga fogaado double dhibic haddii `drop_in_place` hadalladaas.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // BADBAADADA: Weligeen waligeen taaban mayno curyaamintan ka dib markii aannu hoos u dhicin.
                unsafe { ptr::drop_in_place(cur) };
                // Waxaan horay u horumarinay miiska.
                continue;
            }
            if g.deleted_cnt > 0 {
                // BADBAADADA: `deleted_cnt`> 0, markaa daloolka daloolku waa inuusan ku soo koobin curiyaha hadda jira.
                // Waxaan u isticmaalnaa nuqul dhaqaajin, waligana waligeen taaban walxahaas.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Shayga oo dhan waa la shaqeynayaa.Tan waxaa lagu hagaajin karaa `set_len` LLVM.
        drop(g);
    }

    /// Wuxuu tirtirayaa dhammaan laakiin kan ugu horreeya ee walxaha isku xiga ee 'vector' ee ku xallinaya isla furaha.
    ///
    ///
    /// Haddii vector la kala sooco, tani waxay ka saareysaa dhammaan nuqullada.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Wuxuu tirtirayaa dhammaan laakiin kan ugu horreeya ee walxaha isku xigxiga ee 'vector' isagoo qancinaya xiriir sinnaan la siiyay.
    ///
    /// Shaqada `same_bucket` waxaa loo gudbiyaa tixraacyada laba walx oo ka yimid vector waana inay go'aamisaa haddii walxaha isbarbar dhigaan.
    /// Cunsurrada waxaa loo kala hormariyaa sida ay u kala horreeyaan amarkooda, sidaas darteed haddii `same_bucket(a, b)` soo celiyo `true`, `a` waa laga saarayaa.
    ///
    ///
    /// Haddii vector la kala sooco, tani waxay ka saareysaa dhammaan nuqullada.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Waxay ku dhajineysaa shey gadaasha aruurinta.
    ///
    /// # Panics
    ///
    /// Panics hadii awooda cusubi ka badato `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Tani waxay panic ama soo saari doontaa haddii aan u qoondeyn lahayn> isize::MAX bytes ama haddii dhererka dhererku uu buuxin doono noocyada eber-cabbirkoodu yahay.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Wuxuu ka saaraa walxaha ugu dambeeya vector wuuna soo celiyaa, ama [`None`] haddii ay madhan tahay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Waxay u guurisaa dhammaan walxaha `other` `Self`, iyadoo laga tegayo `other` madhan.
    ///
    /// # Panics
    ///
    /// Panics haddii tirada cunsur ee ku jira vector ay buux dhaafiyaan `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Wuxuu kudariyaa walxaha `Self` ee keydka kale.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Waxay abuurtaa a iterator dheecaan in ka saaraysaa kala duwan ee khaaska ah ee vector iyo edbiyey waxyaabaha saaro.
    ///
    /// Marka soo-saarka **la** la tuuro, dhammaan walxaha ku jira aagga waxaa laga saaraa vector, xitaa haddii kuleyliyuhu uusan si buuxda u wada cunin.
    /// Haddii jileeyaha **aan la dhigin**(oo leh tusaale ahaan [`mem::forget`]), lama sheegi karo inta walxo laga saaray.
    ///
    /// # Panics
    ///
    /// Panics haddii barta bilowgu ka weyn tahay barta dhammaadka ama haddii barta dhammaadka ka weyn tahay dhererka vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Xaddiga buuxa ayaa nadiifiya vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Badbaadada xusuusta
        //
        // Marka Drain marka ugu horreysa la abuuro, waxay gaabinaysaa dhererka isha vector si loo hubiyo in waxyaabo aan la aqoon ama laga dhaqaajiyay la heli karin dhammaantood haddii wax baabi'iyaha Drain uusan waligiis ordi doonin.
        //
        //
        // Drain wuxuu ptr::read ka saari doonaa qiimayaasha laga saarayo.
        // Markii la dhammeeyo, dabada hadhay ee vec-ka ayaa dib loo soo guuriyaa si loo daboolo daloolka, oo dhererka vector ayaa lagu soo celiyaa dhererka cusub.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // dejiso dhererka self.vec si loo bilaabo, si loo badbaado haddii Drain ay daadato
            self.set_len(start);
            // U adeegso amaahda IterMut si aad u muujiso dabeecadda amaahda ee dhammaan soosaaraha Drain (sida &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Wuxuu tirtirayaa vector, isaga oo tirtiraya dhammaan qiimayaasha.
    ///
    /// Ogsoonow in qaabkani uusan wax saameyn ah ku yeelanaynin awooda loo qoondeeyay ee 'vector'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Sooceliyaa tirada walxaha ee vector, sidoo kale loo yaqaan 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Soocelinayaa `true` haddii vector kujiro waxyaabo la'aan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ururinta waxay u kala qaaddaa laba jaantus ahaan.
    ///
    /// Sooceliyaa vector cusub oo loo qoondeeyay oo ay kujiraan curiyeyaasha kujira xadka `[at, len)`.
    /// Wicitaanka kadib, asalka vector ayaa laga tagi doonaa iyadoo ay kujiraan walxaha `[0, at)` oo awoodeedii hore aan isbadal laheyn.
    ///
    ///
    /// # Panics
    ///
    /// Panics haddii `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // cusub vector wuxuu la wareegi karaa keydka asalka ah wuxuuna iska ilaalin karaa nuqulka
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` aan badbaado lahayn oo nuqul ka soo duub `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Resizes `Vec` ee-meel si `len` waa loo siman yahay si `new_len`.
    ///
    /// Haddii `new_len` uu ka weyn yahay `len`, `Vec` waxaa lagu kordhiyay farqiga, iyadoo boos kasta oo dheeri ah lagu buuxiyay natiijada wicitaanka xiritaanka `f`.
    ///
    /// Qiimaha soo celinta ee `f` waxay ku dhammaan doontaa `Vec` sida ay u kala sarreeyaan.
    ///
    /// Haddii `new_len` uu ka yar yahay `len`, `Vec` si fudud ayaa loo jarjaray.
    ///
    /// Habkani wuxuu isticmaalaa xiro si loo abuuro qiyam cusub oo ku saabsan riix kasta.Haddii aad doorbidi lahayd [`Clone`] qiime la siiyay, isticmaal [`Vec::resize`].
    /// Haddii aad rabto inaad isticmaasho [`Default`] trait si aad u abuurto qiyam, waxaad u gudbin kartaa [`Default::default`] sidii doodda labaad.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Gubtaa oo daadinaysaa `Vec`, oo soo celinaysa tixraac la beddeli karo oo ku jira waxa ku jira, `&'a mut [T]`.
    /// Xusuusnow in nooca `T` ay tahay inuu ka cimri dheeraado nolosha la doortay ee `'a`.
    /// Haddii nooca uu leeyahay oo keliya tixraacyo ma guurto ah, ama midkoodna uusan jirin, markaa tan waxaa loo dooran karaa inuu noqdo `'static`.
    ///
    /// Shaqadani waxay lamid tahay shaqadii [`leak`][Box::leak] ee [`Box`] marka laga reebo in aysan jirin wado lagu soo cesho xusuusta xaday.
    ///
    ///
    /// Shaqadani waxay inta badan waxtar u leedahay xogta nooshahay inta ka dhiman nolosha barnaamijka.
    /// Joojinta tixraaca la soo celiyey ayaa sababi doona xusuus daadasho.
    ///
    /// # Examples
    ///
    /// Isticmaal fudud:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Sooceliyaa inta hartay ee vector jeex ah `MaybeUninit<T>`.
    ///
    /// jeex ayaa ku soo laabtay waxaa loo isticmaali karaa si ay u buuxiyaan vector la xogta (tusaale
    /// adoo ka akhrinaya feyl) kahor intaadan calaamadin xogta sida lagu bilaabay adoo adeegsanaya habka [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // U qoondee vector weyn oo ku filan 10 cunsur.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Buuxi 3-da cunsur ee ugu horreeya.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Calaamadee 3da walxood ee ugu horeeya vector sidii loo bilaabay.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Qaabkan looma hirgaliyo marka loo eego `split_at_spare_mut`, si looga hortago in xumaanta tilmaamayaasha keydku ay ansax noqdaan.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Sooceliyaa vector qayb ahaan `T`, oo ay weheliso inta hartay ee vector oo ah jeex `MaybeUninit<T>` ah.
    ///
    /// Jeegga awooda wax soo saarka ee la soo celiyey ayaa loo isticmaali karaa in lagu buuxiyo vector xog ah (tusaale adiga oo ka akhriyaya faylka) ka hor intaadan calaamadin xogta sida la bilaabay iyadoo la adeegsanayo habka [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Xusuusnow in tani ay tahay heer-hoose API, oo ay tahay in si taxaddar leh loogu isticmaalo ujeeddooyinka is-hagaajinta.
    /// Haddii aad u baahan tahay inaad ku lifaaqdo xogta `Vec` waxaad isticmaali kartaa [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ama [`resize_with`], iyadoo ku xiran baahidaada saxda ah.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Kaydso meel dheeraad ah oo weyn oo ku filan 10 cunsur.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Buuxi 4ta cunsur ee soo socda.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Calaamadee 4ta cunsur ee 'vector' sidii loo bilaabay.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len waa la iska indhatiray oo markaa waligiis isma beddelin
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Ammaanka: beddelka la soo celiyey .2 (&mut usize) waxaa loo tixgeliyaa inay la mid tahay wacitaanka `.set_len(_)`.
    ///
    /// Qaabkan waxaa loo isticmaalaa in lagu helo marin u gaar ah dhammaan qaybaha vec isla mar ahaantaana `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` waa la damaanad qaadayaa inuu ansax u yahay walxaha `len`
        // - `spare_ptr` ayaa farta ku fiiqaysa hal cunsur oo dhaafaya keydka, sidaa darteed kuma dulmareyso `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Resizes `Vec` ee-meel si `len` waa loo siman yahay si `new_len`.
    ///
    /// Haddii `new_len` uu ka weyn yahay `len`, `Vec` waxaa lagu kordhiyay farqiga, iyadoo boos kasta oo dheeri ah lagu buuxiyo `value`.
    ///
    /// Haddii `new_len` uu ka yar yahay `len`, `Vec` si fudud ayaa loo jarjaray.
    ///
    /// Habkani wuxuu u baahan yahay `T` inuu hirgeliyo [`Clone`], si uu awood ugu yeesho inuu isku dhejiyo qiimaha la dhaafay.
    /// Haddii aad u baahan tahay dabacsanaan badan (ama aad rabto inaad ku tiirsanaato [`Default`] halkii aad ka heli lahayd [`Clone`]), isticmaal [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones iyo ku lifaaq dhammaan walxaha ku jira jeex illaa `Vec`.
    ///
    /// Iterates ka jeex jeexan `other`, clones element kasta, ka dibna ku lifaaqan this `Vec`.
    /// `other` vector si nidaam ah ayaa loogu dhex maraa.
    ///
    /// Xusuusnow in shaqadani ay lamid tahay [`extend`] marka laga reebo inay takhasus gaar ah u leedahay inay ku shaqayso xaleefyada halkii laga samayn lahaa.
    ///
    /// Hadday iyo goorta uu Rust helo takhasuska shaqadan waxay u badan tahay inay hoos u dhici doonto (laakiin wali waa la heli karaa).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Nuqulada walxaha laga soo bilaabo `src` ilaa dhamaadka vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` wuxuu dammaanad ka qaadayaa in qiyaasta la siiyay ay ku habboon tahay tusmeynta nafsaddaada
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Koodhkani wuxuu guud ka dhigayaa `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Kordhi qiimaha vector ee `n`, adoo isticmaalaya koronto dhaliyaha la siiyay.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Isticmaal SetLenOnDrop inay shaqada ku wareegsan cayayaanka halkaas oo laga yaabaa in compiler ma oga dukaanka dhex `ptr` dhex self.set_len() ma samayn alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Qor dhammaan walxaha mooyee midka ugu dambeeya
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Kordhinta dhererka tallaabo kasta haddii ay dhacdo next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Waxaan qori karnaa curiyaha ugu dambeeya si toos ah adoon u adeegsan bilaa falid
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // amaah dejiyey by baaxadda waardiye
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Waxay ka saartaa walxo isdaba joog ah vector sida ku xusan hirgelinta [`PartialEq`] trait.
    ///
    ///
    /// Haddii vector la kala sooco, tani waxay ka saareysaa dhammaan nuqullada.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Hababka gudaha iyo shaqooyinka
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` waxay u baahan tahay inay noqoto mid sax ah
    /// - `self.capacity() - self.len()` waa in ay ahaadaan `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len waxaa la kordhiyay oo keliya ka dib markii la bilaabay walxaha
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - gudiga wacayaasha ee src waa tixraac ansax ah
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Cunsurka waxaa kaliya initialized la `MaybeUninit::write`, sidaas darteed waa ok in Len increace
            // - len waa la kordhiyay ka dib qayb kasta si looga hortago daadinta (fiiri arrinta #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - guaratees Yeedhe in `src` waa index oo sax ah
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Labada tilmaamoodba waxaa laga abuuray tixraacyo jeex ah oo gaar ah (`&mut [_]` `) markaa way ansax yihiin oo iskama dulmaro.
            //
            // - Cunsurraduhu waa: Nuqul sidaa darteed waa caadi in la koobiyeeyo, iyadoo aan waxba lagu samaynaynin qiimaha asalka ah
            // - `count` waxay u dhigantaa lenka `source`, markaa isha waxay ku ansaxaysaa akhrinta `count`
            // - `.reserve(count)` wuxuu dammaanad ka qaadayaa in `spare.len() >= count` si dheeri ahi u ansax yahay qorista `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Cunsurrada waxaa hadda bilaabay `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Fulinta guud ee trait ee Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): leh cfg(test) habka `[T]::to_vec` ee dabiiciga ah, ee looga baahan yahay qeexitaankan, lama heli karo.
    // Halkii ay isticmaalaan shaqo `slice::to_vec` taasoo ah waxaa laga heli karaa oo keliya cfg(test) FG arki module slice::hack ee slice.rs wixii macluumaad dheeraad ah
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // daadi wax kasta oo aan dib loo qori doonin
        self.truncate(other.len());

        // self.len <= other.len sababtuna tahay truncate-ka kor ku xusan, markaa googo'yada halkan ku yaal ayaa had iyo jeer xaddidan.
        //
        let (init, tail) = other.split_at(self.len());

        // dib u isticmaal qiimaha allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Waxay abuurtaa soo noqnoqosho wax cunaysa, taas oo ah, mid qiime kasta ka saarta vector (bilow ilaa dhammaad).
    /// vector looma adeegsan karo ka dib markaad tan soo wacdid.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s wuxuu leeyahay nooc Xarig, ma ahan &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // Habka caleen kaas oo fulintiisa kala duwan ee SpecFrom/SpecExtend ay u wakiilato marka aysan haysan wax ka fiicnaasho dheeraad ah oo ay ku dalbadaan
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Tani waa kiiska loogu talagalay soo-celinta guud.
        //
        // Shaqadani waa inay noqotaa mid u dhiganta akhlaaq ahaan:
        //
        //      sheyga kucelceliyaha
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // FG ma faafi tan iyo markii aan heli lahaayeen kartaa in alloc meel cinwaanka
                self.set_len(len + 1);
            }
        }
    }

    /// Waxay abuurtaa kala-soocid kala-goynaya oo beddelaya xaddiga cayiman ee vector iyada oo la siinayo qalabka loo yaqaan `replace_with` iterator' oo soo saarta waxyaabaha laga saaray.
    ///
    /// `replace_with` uma baahna inuu ahaado dherer la mid ah `range`.
    ///
    /// `range` waa la saaraa xitaa haddii qalabka wax soo saara aan la wada baabbi'in ilaa dhammaadka.
    ///
    /// Waa cayimin inta canaasiirta la saaraa ka vector haddii qiimaha `Splice` la xaday.
    ///
    /// Qalabka soo-geliyaha soo-galeyaasha `replace_with` waxaa la cunaa oo keliya marka qiimaha `Splice` hoos loo dhigo.
    ///
    /// Tani waa fiicantahay haddii:
    ///
    /// * Dabada (walxaha ku jira vector kadib `range`) waa faaruq,
    /// * ama `replace_with` wuxuu soo saaraa wax ka yar ama ka siman yahay dhererka 'range'
    /// * ama xarka hoose ee `size_hint()` uu yahay mid sax ah.
    ///
    /// Haddii kale, vector ku meelgaar ah ayaa loo qoondeeyay dabada ayaa la dhaqaajiyaa laba jeer.
    ///
    /// # Panics
    ///
    /// Panics haddii barta bilowgu ka weyn tahay barta dhammaadka ama haddii barta dhammaadka ka weyn tahay dhererka vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Waxay abuurtaa soo noqnoqe adeegsade xiritaanka si loo go'aamiyo haddii walxo laga saarayo.
    ///
    /// Haddii xiritaanku run ku soo noqdo, markaa curiyaha ayaa laga saaraa oo la dhalaa.
    /// Haddii xiritaanku been ku soo noqdo, cunsurku wuxuu ku sii jiri doonaa aagga 'vector' mana soo saari doono soo-saaraha.
    ///
    /// Isticmaalidda habkani waxay u dhigantaa nambarka soo socda:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // lambarkaaga halkan
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Laakiin `drain_filter` waa u fududahay in la isticmaalo.
    /// `drain_filter` Sidoo kale waa ku ool ah, maxaa yeelay waxa ay backshift kartaa waxyaalaha aasaaska ah ee soo diyaariyeen ee bulk.
    ///
    /// Xusuusnow in `drain_filter` ay sidoo kale kuu oggolaaneyso inaad beddesho cunsur kasta oo ku jira xiritaanka shaandhada, iyadoon loo eegin inaad dooratay inaad haysato ama ka saarto.
    ///
    ///
    /// # Examples
    ///
    /// Tageynaa isugu soo galay evens oo u qalmay, dibna qoondaynta asalka ah:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Iska ilaali inaanu daadno (kordhinta dheecaanka)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Ku dheeree hirgelinta nuqulada cunsuriyada tixraacyada kahor intaadan ku riixin Vec.
///
/// Hirgelintaani waxay ku takhasusay isugeynta jajabyada, halkaas oo ay u adeegsaneyso [`copy_from_slice`] si loogu daro dhammaan jeexyada hal mar.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Waxay fulisaa isbarbar dhiga vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Waxay fulisaa amarka vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // U isticmaal dhibic [T] isticmaal jeex ceeriin ah si aad ugu tixraacdo waxyaabaha vector sida nooca ugu liita ee lagama maarmaanka ah;
            //
            // way iska ilaalin kartaa su'aalaha ku saabsan ansaxnimada kiisaska qaarkood
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec waxay wax ka qabataa heshiiska heshiiska
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Waxay abuurtaa `Vec<T>` madhan.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: tijaabada ayaa soo jiidaneysa libstd, taas oo keeneysa qaladaad halkan
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: tijaabada ayaa soo jiidaneysa libstd, taas oo keeneysa qaladaad halkan
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Uu helo waxyaabaha oo dhan `Vec<T>` sida diyaariyeen ah, haddii ay size bxiyey in of isugu soo codsaday.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Haddii dhererku uusan u dhigmin, gelinta waxay ku soo noqotaa `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Hadaad kufiicantahay inaad helayso horgale ah `Vec<T>`, waad wici kartaa marka hore [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // AMMAANKA: `.set_len(0)` had iyo jeer waa dhawaaqa.
        unsafe { vec.set_len(0) };

        // BADBAADADA: Tilmaamaha 'Vec' ayaa had iyo jeer si habboon loo waafajiyaa, iyo
        // in lays la dagaallamaan u baahan yahay waa isku mid sida alaabta.
        // Waxaan hore in aan waxyaabaha ku filan hubiyaa.
        // Alaabtu laba-laabmi maayaan sida `set_len` uu u sheegayo `Vec` inuusan sidoo kale hoos u dhigin.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}