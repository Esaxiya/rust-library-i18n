use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Si ku meelgaar ah ayey u soo saartaa mid kale oo u dhigma oo isku mid ah una dhigma.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Waxay heshaa geesaha caleen ee kaladuwan ee xadidaya inta u dhexeysa geed.
    /// Ku soo celiyaa mid ka mid ah labada gacmood ee kala duwan isla geedkii ama laba ikhtiyaar oo madhan.
    ///
    /// # Safety
    ///
    /// Ilaa `BorrowType` ay tahay `Immut` mooyee, ha u isticmaalin qabashada nuqul si aad u booqato isla KV laba jeer.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// U dhiganta `(root1.first_leaf_edge(), root2.last_leaf_edge())` laakiin ka waxtar badan.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Wuxuu helaa labada gees ee caleen oo xadidaya xad u gaar ah geed.
    ///
    /// Natiijadu waa macno kaliya haddii geedka lagu dalbado furaha, sida geedka ku jira `BTreeMap` uu yahay.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // BADBAADADA: nooca amaahdeennu waa mid aan la beddeli karin.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Waxay heshaa labada gees ee caleenta oo xadaynaysa geed dhan.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Jajabiyaa tixraac gaar ah galay labo ka mid ah geesaha caleen la xadeeyo waxyaalaha kala duwan oo ku qeexan.
    /// Natiijadu waa tixraacyo aan gaar ahayn oo u oggolaanaya isbeddelka (some), oo ay tahay in si taxaddar leh loo isticmaalo.
    ///
    /// Natiijadu waa macno kaliya haddii geedka lagu dalbado furaha, sida geedka ku jira `BTreeMap` uu yahay.
    ///
    ///
    /// # Safety
    /// Ha u isticmaalin qabashada nuqul si aad u booqato isla KV laba jeer.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Wuxuu u kala qaadaa tixraac gaar ah labo gees oo caleen ah oo xadidaya geedka geedka kala duwan.
    /// Natiijooyinka waa tixraacyo aan gaar ahayn oo u oggolaanaya isbeddel (qiyamka kaliya), sidaas darteed waa in si taxaddar leh loogu adeegsadaa.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Waxaan ku soo qaadaneynaa xididka NodeRef halkan-waligey booqan mayno isla KV labo jeer, oo waligeen kuma dhamaan doonno tixraacyo qiime oo is dul saaran.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Wuxuu u kala qaadaa tixraac gaar ah labo gees oo caleen ah oo xadidaya geedka geedka kala duwan.
    /// Natiijooyinka waa tixraacyo aan gaar ahayn oo u oggolaanaya isbeddel ballaaran oo waxyeello geysta, sidaas darteed waa in loo adeegsadaa taxaddarrada ugu weyn.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Waxaan ku soo qaadaneynaa xididka NodeRef halkan-waligeen kuma heli doonno qaab isku soo koobaya tixraacyada laga helay xididka.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Marka la siiyo caleenta edge, waxay ku soo celinaysaa [`Result::Ok`] oo leh gacan ku haynta KV deriska ah oo ku taal dhinaca midig, taas oo ku taal isla caleen isku mid ah ama aabbeyaasha awoowgood.
    ///
    /// Haddii caleen edge ay tahay tan ugu dambeysa geedka, waxay ku laabanaysaa [`Result::Err`] xididka noodhka.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Marka la siiyo caleenta edge, waxay ku soo celinaysaa [`Result::Ok`] oo leh gacan ku haynta KV deriska ah ee dhinaca bidix, taas oo ku taal isla buudda caleen ama aabbeyaasha aabbehood.
    ///
    /// Haddii caleen edge ay tahay tan koowaad ee geedka, waxay ku laabanaysaa [`Result::Err`] xididka noodhka.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Marka la eego aaladda edge ee gudaha ah, waxay ku soo celinaysaa [`Result::Ok`] oo leh gacan ku haynta KV deriska ah dhinaca midigta, taas oo ku taal isla buro gudaha ah ama aabbeyaasha awgood.
    ///
    /// Haddii gudaha edge uu yahay kan ugu dambeeya geedka, wuxuu ku soo celinayaa [`Result::Err`] xididka noodhka.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Marka la siiyo caleenta edge ee geedka dhimanaya, wuxuu ku soo celinayaa caleen xigta edge dhinaca midig, iyo labada qiimaha-furaha ee u dhexeeya, oo ah isla caleen isku mid ah, aabbeyaasha aabbehood, ama aan jirin.
    ///
    ///
    /// Habkani wuxuu kaloo kala wareejiyaa wixii node(s) ah ee uu gaaro dhammaadka.
    /// Tani waxay tusineysaa in haddii aysan jirin labo-qiimo-furaha muhiimka ah, geedka intiisa kale oo dhan waa lakala wareegi doonaa mana jiraan wax harsan oo soo noqda.
    ///
    /// # Safety
    /// edge la siiyay waa inuusan horey uhelin dhigiisa `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Marka la siiyo caleenta edge ee geedka dhimanaya, wuxuu ku soo celinayaa caleenta xigta edge dhinaca bidix, iyo lammaanaha qiimaha-muhiimka ah ee u dhexeeya, oo ah isla caleen isku mid ah, aabbeyaasha aabbehood, ama aan jirin.
    ///
    ///
    /// Habkani wuxuu kaloo kala wareejiyaa wixii node(s) ah ee uu gaaro dhammaadka.
    /// Tani waxay tusineysaa in haddii aysan jirin labo-qiimo-furaha muhiimka ah, geedka intiisa kale oo dhan waa lakala wareegi doonaa mana jiraan wax harsan oo soo noqda.
    ///
    /// # Safety
    /// edge la siiyay waa inuusan horey uhelin dhigiisa `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Waxay qayb ka dhigeysaa noodhadh ka soo baxa caleen ilaa xididka.
    /// Tani waa sida kaliya ee lagu kala bixin karo inta ka hartay geed kadib markii `deallocating_next` iyo `deallocating_next_back` ay ka nibbinayeen labada dhinac ee geedka, isla markaana ay ku dhufteen isla edge.
    /// Maaddaama loogu talagalay oo keliya in loo yeero markii dhammaan furayaasha iyo qiimayaasha la soo celiyo, wax nadiifin ah laguma sameyn mid ka mid ah furayaasha ama qiimayaasha.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Waxay udhaqaajisaa caleenta edge caleenta xigta edge waxayna kucelisaa tixraacyada furaha iyo qiimaha udhaxeeya.
    ///
    ///
    /// # Safety
    /// Waa inuu jiraa KV kale jihada loo socdaalay.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Waxay u wareejisaa caleenta edge xalka caleentii hore ee edge waxayna ku celineysaa tixraacyada furaha iyo qiimaha u dhexeeya.
    ///
    ///
    /// # Safety
    /// Waa inuu jiraa KV kale jihada loo socdaalay.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Waxay udhaqaajisaa caleenta edge caleenta xigta edge waxayna kucelisaa tixraacyada furaha iyo qiimaha udhaxeeya.
    ///
    ///
    /// # Safety
    /// Waa inuu jiraa KV kale jihada loo socdaalay.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Sameynta tan ugu dambeysa ayaa ka dhakhso badan, sida ku cad jaangooyooyinka.
        kv.into_kv_valmut()
    }

    /// Waxay u dhaqaajisaa caleenta edge caleenta hore waxayna ku celineysaa tixraacyada furaha iyo qiimaha udhaxeeya.
    ///
    ///
    /// # Safety
    /// Waa inuu jiraa KV kale jihada loo socdaalay.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Sameynta tan ugu dambeysa ayaa ka dhakhso badan, sida ku cad jaangooyooyinka.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Waxay u guurisaa caleenta edge caleenta xigta edge waxayna soo celineysaa fure iyo qiimaha udhaxeeya, iyadoo loo qeybinaayo node kasta oo laga tagay iyadoo laga tagayo edge u dhigma ee ku xirnaaneysa waalidkeed.
    ///
    /// # Safety
    /// - Waa inuu jiraa KV kale jihada loo socdaalay.
    /// - KV-gaas horey looma soo celin dhiggiisa `next_back_unchecked` nuskhad kasta oo gacantooda ah oo loo adeegsado in geed la maro.
    ///
    /// Dariiqa keliya ee nabdoon ee lagu sii wadi karo cusboonaysiinta waa in la isbarbar dhigo, la tuuro, loo waco qaabkan mar kale iyadoo la raacayo xaaladdiisa nabadgelyo, ama la wac dhiggiisa `next_back_unchecked` iyadoo la raacayo xaaladdiisa nabadgelyo.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Waxay u guurisaa caleenta edge caleenta hore edge waxayna soo celineysaa furaha iyo qiimaha inta udhaxeysa, iyadoo looqaybinayo noodh kasta oo laga tago iyadoo laga tagayo edge u dhigma ee ku xirnaanaysa waalidkeed.
    ///
    /// # Safety
    /// - Waa inuu jiraa KV kale jihada loo socdaalay.
    /// - Caleentaas 'edge' horey ugama soo celin dhiggeeda `next_unchecked` nuskhad kasta oo ka mid ah xarkaha loo adeegsado in geed la maro.
    ///
    /// Dariiqa keliya ee nabdoon ee lagu sii wadi karo cusboonaysiinta waa in la isbarbar dhigo, la tuuro, loo waco qaabkan mar kale iyadoo la raacayo xaaladdiisa nabadgelyo, ama la wac dhiggiisa `next_unchecked` iyadoo la raacayo xaaladdiisa nabadgelyo
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Waxay soocelisaa caleenka bidix ee edge qeybta ama hoosta buqda, si kale haddii loo dhigo, edge waxaad ubaahantahay marka hore markaad horay u socoto (ama ugu dambeyso markaad gadaal u socoto).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Waxay kucelisaa caleemaha ugufiican edge noodhka ama hoostiisa, haddii si kale loo dhigo, edge aad ubaahantahay ugu dambeeya markaad horay usocoto (ama marka uguhoreysa markaad gadaal usocoto).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Booqo node noodhka iyo KV-yada gudaha si ay u fuulaan furayaasha, iyo sidoo kale wuxuu booqdaa noodhadhka gudaha guud ahaan si qoto dheer uhooseeya, taas oo macnaheedu yahay in noodhooyinka gudaha ay ka horeeyaan KV-yadooda gaarka ah iyo noodhadhka ilmahooda.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Wuxuu xisaabiyaa tirada cunsurrada geed-hoosaad (sub).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Waxay soocelinaysaa caleen edge oo kudhow KV-ga marinka udhigista.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Waxay soocelinaysaa caleen edge oo ugu dhaw KV-da ee gadaal u socodka.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}