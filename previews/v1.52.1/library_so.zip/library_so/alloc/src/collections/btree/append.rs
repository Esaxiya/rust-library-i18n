use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Waxay ku dhejisaa dhammaan lammaanaha qiimaha-muhiimka ah ee ka imanaya midowga laba kor-ka-kacayaasha kor u kacaya, oo ku kordhinaya `length` variable' jidka.Qaybta dambe waxay u sahlaysaa qofka soo wacaya inuu iska ilaaliyo daadinta marka ilaaliyaha dhibicdu argaggaxo.
    ///
    /// Hadday labada tarjubayaal soo saaraan isla furaha, qaabkani wuxuu ka tuurayaa labada dhinac bidix-hayaha oo wuxuu ku dhejinayaa labada dhinac midigta saxda ah.
    ///
    /// Haddii aad rabto geedka inuu ku dhammaado amar si adag kor ugu kacaya, sida `BTreeMap` oo kale, labada socod bixiyeyaasha waa inay soo saaraan furayaal si adag kor ugu kacaya, mid kasta oo ka weyn dhammaan furayaasha geedka, oo ay ku jiraan furayaasha horeyba ugu jiray geedka markii la soo galayay.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Waxaan u diyaar garoobeynaa inaan ku milno `left` iyo `right` oo isku xigxigta taxane ahaan waqtiga toosan.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Dhanka kale, waxaan ka dhiseynaa geed ka soocan isku xigxiga waqtiga toosan.
        self.bulk_push(iter, length)
    }

    /// Ku riix dhammaan lammaanaha qiimaha-muhiimka ah illaa geedka dhammaadkiisa, isagoo ku kordhinaya isbeddel `length` ah oo jidka socda.
    /// Qaybta dambe waxay u sahlaysaa qofka soo wacaya inuu iska ilaaliyo daadinta marka uu alaabtu qaylo dhacdo.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Kabiro dhammaan lamaanaha qiimaha-muhiimka ah, iyaga oo ku riixaya noodhadhka heerka saxda ah.
        for (key, value) in iter {
            // Isku day inaad ku riixdo lammaanaha qiimaha-muhiimka ah guntin caleen hadda ah.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Meel bannaan uma harin, kor u kac oo halkaa ku riix.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // La helay guntin leh booska bidix, riix halkan.
                                open_node = parent;
                                break;
                            } else {
                                // Mar kale kor u kac.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Waxaan joognaa xagga sare, waxaan abuureynaa guntin xidid cusub oo halkaas ku riix.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Riix labada lamaane ee qiimaha-muhiimka ah iyo subtreega midig ee cusub.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Hoos ugu dhaadhac caleen-midigta inteeda badan.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Dhererka kordhinta soocelin kasta, si loo hubiyo in khariidada ay hoos u dhigeyso walxaha ku lifaaqan xitaa haddii horay loo marinayo soo-saaraha dhawaaqa.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Falanqeeye ku biirista laba taxane oo isdaba jooga oo mid ah
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Haddii laba fure ay siman yihiin, wuxuu ka soo celiyaa lammaanaha-qiimaha muhiimka ah isha saxda ah.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}