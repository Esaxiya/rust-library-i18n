// Tani waa isku day fulin la raacayo sida ugu fiican
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Maaddaama Rust uusan dhab ahaan lahayn noocyo ku tiirsan iyo dib-u-soo-celinta polymorphic, waxaan ku sameynaa waxyaabo badan oo aan ammaan ahayn.
//

// Ujeeddada ugu weyn ee qaybtani waa in laga fogaado kakanaanta iyadoo loo daaweynayo geedka sida weel guud (haddii qaab qaab aan caadi ahayn) loogana ilaaliyo la macaamilka inta badan B-Tree isbedel la'aan.
//
// Sidan oo kale, qaybtani ma danaynayso in waxyaabaha la soosaaray la kala soocay, iyo noodhadhyada hoos iman kara, ama xitaa macnaha hoose.Si kastaba ha noqotee, waxaan ku tiirsan nahay xoogaa yar oo isbeddelayaal ah:
//
// - Geedaha waa inay lahaadaan labis depth/height ah.Tan macnaheedu waxa weeye in waddo kasta oo hoos u socota ilaa caleen ka timaadda buundada la siiyaa ay leedahay dherer isku mid ah.
// - Noodh dhererka `n` wuxuu leeyahay furaha `n`, qiimaha `n`, iyo geesaha `n + 1`.
//   Tani waxay muujineysaa in xitaa noodh madhan uu leeyahay ugu yaraan hal edge.
//   Xuddunta caleen, "having an edge" kaliya waxay ka dhigan tahay inaan aqoonsan karno boos ku yaal buundada, maadaama geesaha caleen ay madhan yihiin oo aysan u baahnayn matalaad xog ah.
// Qeybta gudaha, edge labaduba waxay tilmaamayaan boos waxayna kujiraan tilmaame barta ilmaha.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Matalaadda hoose ee noodhadhka caleen iyo qayb ka mid ah matalaadda qanjirrada gudaha.
struct LeafNode<K, V> {
    /// Waxaan dooneynaa inaan noqono kuwo ku xeel dheer `K` iyo `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Tusmada noodhka ee galka waalidka ee `edges`.
    /// `*node.parent.edges[node.parent_idx]` waa inuu noqdaa wax la mid ah `node`.
    /// Tan waxaa kaliya oo la damaanad qaadayaa in la bilaabo marka `parent` aan waxba ka jirin.
    parent_idx: MaybeUninit<u16>,

    /// Tirada furayaasha iyo qiimayaasha noodhadhka noocan ahi.
    len: u16,

    /// Iskuduwaha kaydinta xogta dhabta ah ee barta.
    /// Kaliya walxaha ugu horreeya ee `len` ee nooc kasta ayaa la bilaabay oo ansax ah.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Wuxuu bilaabayaa meel cusub oo ah `LeafNode`.
    unsafe fn init(this: *mut Self) {
        // Siyaasad guud ahaan, waxaan uga tageynaa meelaha aan la ogeyn haddii ay noqon karaan, maadaama tani ay tahay inay labadaba ka yara dhakhso badan tahay oo ay fududahay in lala socdo Valgrind.
        //
        unsafe {
            // parent_idx, furayaasha, iyo guluubyada dhammaantood waa MayUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Waxay abuurtaa `LeafNode` sanduuq cusub.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Matalaadda hoose ee noodhadhka gudaha.Sida ``LeafNode`s '', kuwan waa in lagu qariyaa gadaasha ``BoxedNode`s '' si looga hortago daadinta furayaasha iyo qiimayaasha aan lagaranayn.
/// Tilmaame kasta oo muujinaya `InternalNode` waxaa si toos ah loogu tuuri karaa tilmaame qeybta hoose ee `LeafNode`, taasoo u oggolaaneysa koodhka inuu ku dhaqmo caleemaha iyo qanjidhada gudaha asal ahaan isagoo aan xitaa hubin midka labada tilmaamuhu tilmaamayo.
///
/// Hantidan waxaa awood u leh isticmaalka `repr(C)`.
///
#[repr(C)]
// gdb_providers.py wuxuu adeegsadaa magaca noocan ah is-dhexgal.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Tilmaamayaasha carruurta ee bartaan.
    /// `len + 1` kuwan waxaa loo arkaa inay yihiin kuwo bilow ah oo ansax ah, marka laga reebo inta u dhow dhamaadka, halka geedka lagu haysto nooca amaahda ee `Dying`, qaar ka mid ah tilmaamayaashaan ayaa gilgilaya.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Waxay abuurtaa a `InternalNode` cusub xerad.
    ///
    /// # Safety
    /// Mid aan isbeddeleynin noodhadhka gudaha waa inay leeyihiin ugu yaraan hal edge oo la bilaabay oo ansax ah.
    /// Hawshani ma dejiso edge oo kale.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Waxaan kaliya u baahanahay inaan bilowno xogta;geesaha ayaa ah MayUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Tilmaame la maareeyay, oo aan waxba ka jirin oo barta ku yaal.Kani waa tilmaame lahaansho `LeafNode<K, V>` ama tilmaam lahaansho u leh `InternalNode<K, V>`.
///
/// Si kastaba ha noqotee, `BoxedNode` ma laha wax macluumaad ah oo ku saabsan labada nooc ee noodhadhka ah ee ay dhab ahaantii ku jirto, iyo, qayb ahaan sababtoo ah macluumaad la'aanta, ma aha nooc gaar ah mana laha wax wax dumin kara.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Guntin xidid geed leh.
///
/// Ogsoonow in tani aysan lahayn wax wax dumin, waana in lagu nadiifiyo gacanta.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Waxay soo celisaa geed cusub oo leh, oo leh xididkiisa xidid kaas oo markii horaba madhan.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` waa inuusan eber noqon.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Iskudhaf ahaan ayaa amaahda noodhka xididka la leeyahay.
    /// Si ka duwan `reborrow_mut`, tani waa ammaan maxaa yeelay qiimaha soo celinta looma isticmaali karo in lagu burburiyo xididka, mana jiri karaan tixraacyo kale oo geedka ah.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Si yar ayaa si isdaba-joog ah loo amaahiyaa noodhka xididka la leeyahay
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Si aan leex leexad lahayn loogu beddelay tixraac u oggolaanaya rogidda isla markaana bixisa habab wax burburiya iyo wax kale oo yar.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Waxay ku dareysaa buro cusub oo gudaha ah oo leh hal edge oo tilmaameysa guntintii hore, sameyso noodhkaas cusub noodhka xididka, oo soo celi.
    /// Tani waxay kordhinaysaa dhererka 1 waana ka soo horjeedka `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, marka laga reebo inaan kaliya ilaaway inaan nahay gudaha hada:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Waxay ka saareysaa noodhka xididka gudaha, iyadoo isticmaaleysa ilmaheeda ugu horreeya sidii noodhka xididka cusub.
    /// Maaddaama loogu talagalay in loogu yeero oo keliya marka xididka xididku yeesho hal cunug oo keliya, wax nadiifin ah laguma sameyn mid ka mid ah furayaasha, qiimayaasha iyo carruurta kale.
    ///
    /// Tani waxay hoos u dhigeysaa dhererka 1 waana ka soo horjeedka `push_internal_level`.
    ///
    /// Waxay ubaahantahay marin gaar ah shayga `Root` laakiin looma baahna node xididka;
    /// ma burineyso qabashooyinka kale ama tixraacyada noodhka xididka.
    ///
    /// Panics haddii uusan jirin heer gudaha ah, yacni, haddii node xididka uu yahay caleen.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // BADBAADADA: waxaan ku adkaynay gudaha.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // BADBAADADA: waxaan amaahanay `self` si khaas ah nooca deyntiisa waa mid gaar ah.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // BADBAADADA: edge-ka ugu horreeya had iyo jeer waa la bilaabay.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` had iyo jeer waa isweydaarsi `K` iyo `V` ah, xitaa marka `BorrowType` uu yahay `Mut`.
// Tani farsamo ahaan waa khaldan tahay, laakiin ma keeni karto wax amaan daro ah sababo la xiriira isticmaalka gudaha ee `NodeRef` maxaa yeelay waxaan gebi ahaanba ku sii nagaaneynaa guud ahaan `K` iyo `V`.
//
// Si kastaba ha noqotee, mar kasta oo nooc dadweyne ah uu duubo `NodeRef`, hubi inuu leeyahay kala duwanaansho sax ah.
//
/// Tixraac barta.
///
/// Noocani wuxuu leeyahay tiro xuduudayaal xakameeya sida ay u shaqeyso:
/// - `BorrowType`: Nooc dummy ah oo sharraxaya nooca amaahda oo sidata nolosha oo dhan.
///    - Markay tani tahay `Immut<'a>`, `NodeRef` wuxuu u dhaqmaa si qallafsan sida `&'a Node`.
///    - Markay tani tahay `ValMut<'a>`, `NodeRef` wuxuu u dhaqmaa si qumman sida `&'a Node` marka loo eego furayaasha iyo qaabdhismeedka geedka, laakiin sidoo kale wuxuu u oggolaanayaa tixraacyo badan oo isbeddelaya oo ku saabsan qiyamka geedka oo dhan inay wada noolaadaan.
///    - Markay tani tahay `Mut<'a>`, `NodeRef` wuxuu u dhaqmaa si qumman sida `&'a mut Node`, in kasta oo hababka gelintu ay u oggolaanayaan tilmaame la beddeli karo si uu u noolaado.
///    - Markuu kani yahay `Owned`, `NodeRef` wuxuu u dhaqmaa si qallafsan sida `Box<Node>`, laakiin ma haysto wax burburiya, waana in lagu nadiifiyo gacanta.
///    - Markay tani tahay `Dying`, `NodeRef` wali wuxuu u dhaqmaa si qallafsan sida `Box<Node>`, laakiin wuxuu leeyahay habab lagu burburiyo geedka xoogaa yar, iyo hababka caadiga ah, iyadoo aan loo calaamadinayn mid aan badbaado lahayn oo la wici karo, waxay soo wici kartaa UB haddii si qaldan loogu yeero.
///
///   Maaddaama `NodeRef` kasta uu oggolaado in lagu dhex wareego geedka, `BorrowType` wuxuu si wax ku ool ah u khuseeyaa geedka oo dhan, maahan oo keliya barta lafteeda.
/// - `K` iyo `V`: Kuwani waa noocyada furaha iyo qiimayaasha ku kaydsan qanjirrada.
/// - `Type`: Tani waxay noqon kartaa `Leaf`, `Internal`, ama `LeafOrInternal`.
/// Markuu kani yahay `Leaf`, `NodeRef` wuxuu tilmaamayaa node caleen, markay tani tahay `Internal` `NodeRef` wuxuu tilmaamayaa buro gudaha ah, markuu `LeafOrInternal` yahayna `NodeRef` wuxuu tilmaamayaa midkood node.
///   `Type` waxaa lagu magacaabaa `NodeType` markii laga isticmaalo banaanka `NodeRef`.
///
/// Labadaba `BorrowType` iyo `NodeType` waxay xaddidayaan qaababka aan u hirgelinno, si looga faa'iideysto badbaadada nooca caadiga ah.Waxaa jira xadeynno habka aan u adeegsan karno xannibaadahaas:
/// - Nooc walba oo dhimaya, waxaan kaliya ku qeexi karnaa hab guud ahaan ama nooc gaar ah.
/// Tusaale ahaan, kuma qeexi karno hab sida `into_kv` generically for all `BorrowType`, ama hal mar dhammaan noocyada nolosha wada, maxaa yeelay waxaan dooneynaa inay soo celiso tixraacyada `&'a`.
///   Sidaa darteed, waxaan u qeexaan oo kaliya nooca ugu yaraan awood `Immut<'a>`.
/// - Kama heli karno qasab qasab ah dhaha `Mut<'a>` ilaa `Immut<'a>`.
///   Sidaa darteed, waa inaan si cad ugu wacnaa `reborrow` taleefanka xoogga badan ee `NodeRef` si loo gaaro qaab sida `into_kv` ah.
///
/// Dhammaan hababka ku yaal `NodeRef` ee soo celiya nooc tixraac ah, midkoodna:
/// - Qaado `self` qiime ahaan, oo soo celi intaad nooshahay oo ay siddo `BorrowType`.
///   Mararka qaarkood, si aan ugu baaqno qaabkan oo kale, waxaan u baahan nahay inaan wacno `reborrow_mut`.
/// - U qaado `self` tixraac, iyo (implicitly) soo celi tixraacaas noloshiisa oo dhan, halkii aad ka noolayn lahayd `BorrowType`.
/// Habkaas, hubiyaha amaahdu wuxuu dammaanad qaadayaa in `NodeRef` uu weli amaahdo illaa iyo inta tixraaca la soo celiyay la adeegsanayo.
///   Hababka taageeraya gelinta qalooca qaanuunkan iyaga oo soo celinaya tilmaame cayriin ah, tusaale ahaan, tixraac aan nolol lahayn.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Tirada heerarka node iyo heerka caleemo ay kala fogyihiin, joogto ah buundada oo aan gebi ahaanba lagu sharixi karin `Type`, iyo in guntiga laftiisa uusan keydin.
    /// Waxaan kaliya u baahanahay inaan kaydino dhererka noodhka xididka, oo aan ka soo qaadanno dherer kasta oo node kale.
    /// Waa inuu noqdaa eber haddii `Type` uu yahay `Leaf` iyo mid aan eber ahayn haddii `Type` uu yahay `Internal`.
    ///
    ///
    height: usize,
    /// Tilmaamaha caleemaha ama noodhka gudaha.
    /// Qeexitaanka `InternalNode` wuxuu xaqiijinayaa in tilmaamuhu uu sax yahay labada dhinacba.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Kala bixi tixraaca buundada ee looxidhay sidii `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Waxay banaanka soo dhigeysaa xogta node gudaha ah.
    ///
    /// Ku soo celiyaa ptr ceyriin ah si looga fogaado inuu baabi'iyo tixraacyada kale ee noodhkan.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // BADBAADADA: nooca node ee joogtada ah waa `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Wuxuu qaadaa marin u helida macluumaadka guntin gudaha ah.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Wuxuu helaa dhererka barta.Tani waa tirada furayaasha ama qiyamka.
    /// Tirada geesaha waa `len() + 1`.
    /// Xusuusnow, in kasta oo aad amaan tahay, soo wicitaanka shaqadan waxay yeelan kartaa waxyeelo dhanka burinta tixraacyada la beddeli karo oo koodh aan ammaan ahayn uu abuuray.
    ///
    pub fn len(&self) -> usize {
        // Muhiimad ahaan, waxaan kaliya ku galeynaa goobta `len` halkan.
        // Haddii BorrowType uu yahay marker::ValMut, waxaa jiri kara tixraacyo la beddeli kara oo aad u sarreeya oo xagga qiyamka ah oo ay tahay in aanaan ka noqonin.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Sooceliyaa tirada heerarka ay buudda iyo caleemaha kala fogyihiin.
    /// Dhererka eberka micnaheedu waa node waa caleen lafteeda.
    /// Haddii aad sawirto geedo leh xididka dushiisa, nambarku wuxuu sheegayaa meesha sare ee noodhku ka muuqanayo.
    /// Haddii aad sawirto geedo leh caleemo dusha sare, nambarku wuxuu sheegayaa sida ay geedku ugu fidsan yahay kor ku xusan barta.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Si ku meel gaar ah waxay u soo saartaa tixraac kale, oo aan la beddeli karin isla guntintaas.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Waxay banaanka soo dhigaysaa qaybta caleen ee caleen kasta ama node gudaha ah.
    ///
    /// Ku soo celiyaa ptr ceyriin ah si looga fogaado inuu baabi'iyo tixraacyada kale ee noodhkan.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Boodhku waa inuu ahaadaa mid ansax ah ugu yaraan qaybta LeafNode.
        // Tani tixraac uma ahan nooca NodeRef maxaa yeelay ma ogin haddii ay ahaan lahayd mid gaar ah ama wadaag ah.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Wuxuu helaa waalidka barta hadda jirta.
    /// Soocelinayaa `Ok(handle)` haddii noodhka hadda jira uu runtii leeyahay waalid, halkaasoo `handle` uu tilmaamayo edge ee waalidka tilmaamaya barta hadda jirta.
    ///
    /// Sooceliyaa `Err(self)` haddii noodhka hadda uusan waalid laheyn, asagoo dib ugu celinaya `NodeRef` asalka ah.
    ///
    /// Magaca habka ayaa kuu maleynaya inaad sawireysid geedo leh noodhka xididka dushiisa.
    ///
    /// `edge.descend().ascend().unwrap()` iyo `node.ascend().unwrap().descend()` waa inay labaduba, markay guuleystaan, aysan waxba qaban.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Waxaan u baahanahay inaan u adeegsanno tilmaamayaasha ceyriinka ah noodhadhka maxaa yeelay, haddii BorrowType uu yahay marker::ValMut, waxaa jiri kara tixraacyo la beddeli kara oo aad u sarreeya oo xagga qiyamka ah oo ay tahay inaannaan burin.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Xusuusnow in `self` waa inuu ahaadaa mid faaruq ah.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Xusuusnow in `self` waa inuu ahaadaa mid faaruq ah.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Waxay banaanka u soo saartaa qaybta caleen ee caleen kasta ama node gudaha ah oo ku yaal geed aan la beddeli karin.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // BADBAADADA: ma jiri karaan tixraacyo la beddeli karo oo geedkaan loo amaahday sida `Immut`.
        unsafe { &*ptr }
    }

    /// Jebinaya aragti furayaasha ku keydsan barta.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Si la mid ah `ascend`, wuxuu helayaa tixraac node node node, laakiin sidoo kale wuxuu kala bixiyaa noodhka hadda socda hawsha.
    /// Tani amaan maahan maxaa yeelay buundada hada socota wali waa la heli karaa inkasta oo meel kale lakala dhigay.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Si nabadgelyo la'aan ah ayuu ugu sheegayaa isku-duwaha macluumaadka ma guurtada ah ee noodhadhkani yahay `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Si nabadgelyo la'aan ah ayuu ugu sheegayaa isku-duwaha macluumaadka ma guurtada ah ee noodhadhkani yahay `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Si ku meel gaar ah waxay u soo saartaa tixraac kale oo is beddel ah isla guntintaas.Ka digtoonow, maadaama qaabkani uu yahay mid aad khatar u ah, laba-laablaab sidaasna tan iyo markii ay markiiba u muuqan karin khatar.
    ///
    /// Sababtoo ah tilmaamayaasha is beddeli kara waxay ku meeraysan karaan meel kasta oo geedka ah, tilmaamaha la soo celiyey ayaa si fudud loogu isticmaali karaa in lagu muujiyo tilmaamaha asalka ah, ee ka baxsan soohdimaha, ama aan ansax ahayn marka la eego xeerarka amaahda la adkeeyay
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) tixgeli inaad ku darto nooc kale nooc `NodeRef` ah oo xaddidaya adeegsiga hababka hagidda ee tilmaamayaasha dib loo soo celiyey, iyadoo laga hortagayo ammaan darridaas.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Waxay si gaar ah u jabisaa qaybta caleen ee caleen kasta ama node gudaha ah.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // BADBAADADA: waxaan marin gaar ah u leenahay dhammaan guntinta.
        unsafe { &mut *ptr }
    }

    /// Waxay bixisaa marin u gaar ah qaybta caleen ee caleen kasta ama node gudaha ah.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // BADBAADADA: waxaan marin gaar ah u leenahay dhammaan guntinta.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Wuxuu qaadaa marin u gaar ah qayb ka mid ah aagga keydinta furaha.
    ///
    /// # Safety
    /// `index` waxay ku egtahay xuduudaha 0..AQAALAHA
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // BADBAADADA: Wicitaanku ma awoodi doono inuu ugu yeero habab dheeraad ah iskiis
        // ilaa tixraaca jeex furaha la tuuro, maadaama aan marin gaar ah u leenahay inta amaahda lagu jiro.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Waxay jabisaa marin u gaar ah cunsur ama jeex aagga qiimaha keydka.
    ///
    /// # Safety
    /// `index` waxay ku egtahay xuduudaha 0..AQAALAHA
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // BADBAADADA: Wicitaanku ma awoodi doono inuu ugu yeero habab dheeraad ah iskiis
        // ilaa tixraaca jeexista qiimaha la tuurayo, maadaama aan marin gaar ah u leenahay inta uu nool yahay amaahdu.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Wuxuu qaadaa marin u gaar ah cunsur ama jeex aagga kaydinta node ee waxyaabaha ku jira edge.
    ///
    /// # Safety
    /// `index` waxay ku egtahay xuduudaha 0..XAQAALKA + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // BADBAADADA: Wicitaanku ma awoodi doono inuu ugu yeero habab dheeraad ah iskiis
        // ilaa tixraaca jeexitaanka edge la tuurayo, maadaama aan marin gaar ah u leenahay inta amaahdu nooshahay.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Noodhka ayaa leh in kabadan `idx` walxaha la bilaabay.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Waxaan kaliya u abuureynaa tixraac hal cunsur aan xiiseyneyno, si looga fogaado in lagu naaneyso tixraacyo muuqda oo ku saabsan canaasiirta kale, gaar ahaan, kuwa lagu soo celiyey wicitaankii hore.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Waa inaan ku qasabnaa tilmaamayaasha xariijinta aan la qiyaasi karin sababta oo ah arinta Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Wuxuu qaadaa marin u gaar ah dhererka barta.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Qeexaa iskuxiraha buundada ee waalidkiis edge, isagoon baabi'in tixraacyada kale ee barta.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Wuxuu tirtirayaa isku xidhka xididkiisa waalidkiis edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Waxay ku dareysaa lammaane qiime-qiime ah dhamaadka noodhka.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Shay kasta oo ay soo celiso `range` waa sax tusmada edge ee barta.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Waxay ku dareysaa lammaane qiime-muhiim ah, iyo edge si aad ugu aaddo dhinaca midig ee lammaanahaas, illaa dhamaadka noodhka.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Wuxuu hubiyaa inuu node yahay `Internal` node ama node `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Tixraac lammaane gaar ah oo qiime-fure ah ama edge oo ku yaal noodh.
/// Halbeegga `Node` waa inuu noqdaa `NodeRef`, halka `Type` uu noqon karo `KV` (oo tilmaamaysa gacan qabashada labada lamaane ee muhiimka ah) ama `Edge` (oo tilmaamaysa gacan qabsiga edge).
///
/// Xusuusnow in xitaa noodhadhka `Leaf` ay lahaan karaan xalalka `Edge`.
/// Halkii aad ka matali lahayd tilmaame barta noodhka, kuwani waxay matalayaan meelaha ay tilmaamayaasha carruurtu u dhexayn doonaan lammaanaha qiimaha muhiimka ah.
/// Tusaale ahaan, guntin dhererkeedu yahay 2, waxaa jiri lahaa 3 goobood oo suurtagal ah edge, mid bidixda bidix ee barta, mid u dhexeeya labada lammaane, iyo midig midigta barta.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Uma baahnin guud ahaan guud ahaan `#[derive(Clone)]`, maadaama waqtiga kaliya ee `Node` uu noqon doono ``Clone`able 'ay tahay marka ay tahay tixraac aan la beddeli karin iyo sidaas darteed `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Waxay soo ceshanaysaa noodhka ay kujirto edge ama lammaanaha qiimaha muhiimka ah ee gacan qabadkani tilmaamayo.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Soocelisaa booska gacan-qabsi ee ku yaal barta.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Waxay u abuureysaa gacan qabsi cusub lammaanaha qiimaha muhiimka ah ee `node`.
    /// Amaan maleh maxaa yeelay qofka soo wacaya waa inuu hubiyaa `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Waxay noqon kartaa hirgelinta dadweynaha ee 'PartialEq', laakiin waxaa kaliya loogu adeegsaday qaybtan.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Si ku meelgaar ah waxay ula soo baxaysaa gacan kale oo aan la beddeli karin isla goobtaas.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ma isticmaali karno Handle::new_kv ama Handle::new_edge maxaa yeelay garan mayno noocayaga
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Si aan badbaado lahayn ayuu ugu adkaysanayaa isku-duwaha macluumaadka ma guurtada ah ee ah in noodhka gacanta uu yahay `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Si ku meel gaar ah waxay u soo qaaddaa mid kale, wax laga qaban karo isla goobtaas.
    /// Ka digtoonow, maadaama qaabkani uu yahay mid aad khatar u ah, laba-laablaab sidaasna tan iyo markii ay markiiba u muuqan karin khatar.
    ///
    ///
    /// Wixii faahfaahin ah, eeg `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ma isticmaali karno Handle::new_kv ama Handle::new_edge maxaa yeelay garan mayno noocayaga
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Waxay ku abuureysaa gacan qabsi cusub edge gudaha `node`.
    /// Nabadla 'maxaa yeelay wacaha waa in ay hubisaa in `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Marka la eego tilmaanta 'edge' halka aan dooneyno inaan gelino noodh buuxsamay awood ahaan, ayaa xisaabineynaa istiraatiijiyad macquul ah oo ah 'KV index' oo ah barta kala qeybsan iyo halka laga sameynayo galinta.
///
/// Hadafka barta loo kala qaybiyey ayaa ah in fureheeda iyo qiimaheedu ku dhammaado barta waalid;
/// furayaasha, qiyamka iyo geesaha bidix ee barta kala qeybsan ayaa noqda ilmaha bidix;
/// furayaasha, qiyamka iyo geesaha midigta barta kala jaban ayaa noqda ilmaha saxda ah.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Arrinta Rust #74834 waxay isku dayeysaa inay sharraxdo sharciyadan qaabeysan.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Waxay gelineysaa lammaane-qiime-cusub oo u dhexeeya lammaanaha qiimaha muhiimka u ah midigta iyo bidixda edge.
    /// Habkani wuxuu u maleynayaa inay jirto meel ku filan oo ku taal barta si ay labada qof ee cusub ugu habboonaan karaan.
    ///
    /// Tilmaame soo celinta ayaa tilmaamaysa qiimaha la geliyay.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Waxay gelineysaa lammaane-qiime-cusub oo u dhexeeya lammaanaha qiimaha muhiimka u ah midigta iyo bidixda edge.
    /// Habkani wuxuu kala qaybiyaa bu'da haddii aysan jirin meel ku filan.
    ///
    /// Tilmaame soo celinta ayaa tilmaamaysa qiimaha la geliyay.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Wuxuu hagaajiyaa tilmaamaha waalidka iyo tusmada guntinta cunugga ee edge ku xirmayo.
    /// Tani waxay waxtar leedahay marka amarka geesaha la beddelay,
    fn correct_parent_link(self) {
        // Samee dib-u-xisaabiyaha adiga oo aan baabi'in tixraacyada kale ee barta.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Gashaa lammaane cusub oo qiimo leh iyo edge oo aadaya dhanka midig ee lammaanaha cusub ee u dhexeeya edge iyo lammaanaha qiimaha muhiimka ah ee midigta edge.
    /// Habkani wuxuu u maleynayaa inay jirto meel ku filan oo ku taal barta si ay labada qof ee cusub ugu habboonaan karaan.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Gashaa lammaane cusub oo qiimo leh iyo edge oo aadaya dhanka midig ee lammaanaha cusub ee u dhexeeya edge iyo lammaanaha qiimaha muhiimka ah ee midigta edge.
    /// Habkani wuxuu kala qaybiyaa bu'da haddii aysan jirin meel ku filan.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Waxay gelineysaa lammaane-qiime-cusub oo u dhexeeya lammaanaha qiimaha muhiimka u ah midigta iyo bidixda edge.
    /// Qaabkani wuxuu kala qaybiyaa bu'da haddii aysan jirin qol ku filan, oo wuxuu isku dayaa inuu galiyo qaybta kala qaybsan galka waalidka si tartiib tartiib ah, illaa xididka la gaadhayo.
    ///
    ///
    /// Haddii natiijada la soo celiyey ay tahay `Fit`, noodhka gacantiisa ayaa noqon kara bucda edge ama awoowe.
    /// Haddii natiijada la soo celiyey ay tahay `Split`, goobta `left` ayaa noqon doonta node xididka.
    /// Tilmaame soo celinta ayaa tilmaamaysa qiimaha la geliyay.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Wuxuu helaa buqda uu ku tilmaamay tan edge.
    ///
    /// Magaca habka ayaa kuu maleynaya inaad sawireysid geedo leh noodhka xididka dushiisa.
    ///
    /// `edge.descend().ascend().unwrap()` iyo `node.ascend().unwrap().descend()` waa inay labaduba, markay guuleystaan, aysan waxba qaban.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Waxaan u baahanahay inaan u adeegsanno tilmaamayaasha ceyriinka ah noodhadhka maxaa yeelay, haddii BorrowType uu yahay marker::ValMut, waxaa jiri kara tixraacyo la beddeli kara oo aad u sarreeya oo xagga qiyamka ah oo ay tahay inaannaan burin.
        // Ma jiraan wax walwal ah oo laga qabo helitaanka dhererka dhererka maxaa yeelay qiimahaas waa la koobiyeeyay.
        // Iska jir, mar pointer Guntin la dereferenced, waxaan heli geesaha soo diyaariyeen la tixraac (arrinta Rust #73987) iyo buriyaan wax walba oo raadraac kale ama gudaha oo isdiyaarin kara, waa in wax kasta oo noqon ku wareegsan.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ma soo wici karno qaabab kala duwan oo muhiim ah iyo kuwo qiimo leh, maxaa yeelay wicitaanka midka labaad wuxuu burinayaa tixraaca uu soo celiyey kan hore.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Beddel fure iyo qiimaha uu gacanta ku hayo KV uu tilmaamayo.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Waxay ka caawisaa hirgelinta `split` gaar ahaan `NodeType`, iyadoo la daryeelayo xogta caleen.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Wuxuu u kala jajabaa guntinta hoose sedex qaybood:
    ///
    /// - Noodhka ayaa loo jarjarey kaliya inuu kujiro lammaanaha qiimaha muhiimka u ah bidix ee gacantan.
    /// - Furaha iyo qiimaha ay tilmaamtay gacan-ku-haynta ayaa la soo saaray.
    /// - Dhammaan lammaanayaasha qiimaha-muhiimka ah ee midigta gacan-qabashada ah ayaa la gelinayaa noodh cusub oo loo qoondeeyey.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Waxay ka saareysaa lammaanaha qiimaha-muhiimka ah ee lagu tilmaamayo gacan-ku-haynta oo dib u soo celinaya, oo ay weheliso edge ee labada lamaane ee qiimaha muhiimka ahi ku burbureen.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Wuxuu u kala jajabaa guntinta hoose sedex qaybood:
    ///
    /// - Noodhka ayaa loo jarjaray oo kaliya inuu ka koobnaado cidhifyada iyo lammaanaha qiimaha-muhiimka u ah dhinaca bidix ee gacantan.
    /// - Furaha iyo qiimaha ay tilmaamtay gacan-ku-haynta ayaa la soo saaray.
    /// - Dhammaan geesaha iyo lammaanaha qiimaha-muhiimka ah ee midigta gacan-ku-haynta ayaa la gelinayaa noodh cusub oo loo qoondeeyey.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Waxay u taagan tahay kalfadhi lagu qiimeynayo laguna sameynayo hawl isku dheelitirnaan ah oo ku wareegsan lammaane-qiime-gudaha ah.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Waxay doorataa xaalad dheellitiran oo ku lug leh guntinta cunug ahaan, sidaasna u dhexeysa KV isla markiiba bidixda ama midigta barta waalidka.
    /// Sooceliyaa `Err` haddii uusan waalid jirin.
    /// Panics haddii waalidku faaruq yahay.
    ///
    /// Wuxuu doorbidayaa dhinaca bidix, inuu noqdo kan ugufiican hadii noodhka la siiyay si uun hoos loo dhigo, macnaha halkan kaliya wuxuu ka leeyahay waxyaabo kayar kan walaalkiis bidix iyo kan saxda ah ee walaalkiis ah, hadii ay jiraan.
    /// Xaaladdaas, ku biirista walaalka bidix ayaa ka dhakhso badan, maaddaama aan u baahannahay oo keliya inaan dhaqaajinno aaladda N ee barta, halkii aan u leexan lahayn dhinaca midig oo aan u dhaqaaqi lahayn wax ka badan N walxaha hore.
    /// Ka xadida walaalka bidix sidoo kale caadi ahaan way dhakhso badan tahay, maaddaama aan u baahanahay oo keliya inaan u leexanno cunsurrada N qaybood oo midigta ah, halkii aan ugu yaraan bidix ugu beddeli lahayn ugu yaraan N qaybaha walaalka.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Wuxuu soo celiyaa haddii isku biiritaanku suurtagal yahay, yacni, haddii ay jirto qol ku filan oo ku yaal buundada oo lagu daro KV-ga dhexe iyo labada node ee isku dhow.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Waxay qabataa midow waxayna u ogolaaneysaa xiritaanka go'aaminta waxa lagu noqonayo.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // BADBAADADA: dhererka qanjidhada la isku daray waa mid ka hooseeya dhererka
                // of node of edge this, sidaas kor eber, sidaas darteed iyagu waa gudaha.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Waxay ku milmayaan qiimaha labada waalid ee muhiimka ah iyo labada nugul ee isku dhow ee galka ilmaha bidix oo ay soo celinayaan guntinta waalidku soo yaraaday.
    ///
    ///
    /// Panics haddii aan nahay `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Waxay ku milmayaan qiimaha labada waalid ee muhiimka ah iyo labada nugul ee isku dhow ee galka ilmaha bidix oo ay soo celinayaan noodhka ilmaha.
    ///
    ///
    /// Panics haddii aan nahay `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Wuxuu isku daraa labada waalid ee qiimaha-muhiimka ah iyo labada nugul ee isku-dhow ee galka ilmaha bidix wuxuuna soo celiyaa aaladda edge ee noodhka cunugga halkaas oo cunuggii la raadraacay ee edge uu ku dhammaaday,
    ///
    ///
    /// Panics haddii aan nahay `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Waxay ka saareysaa lambarada qiimaha-muhiimka ah canugga bidix waxayna dhigeysaa keydka qiimaha muhiimka ah ee waalidka, iyadoo lagu riixayo waalidkii hore ee qiimaha-muhiimka ahaa canugga saxda ah.
    ///
    /// Waxay ku celisaa xaraf edge cunugga saxda ah una dhigma halka asalka edge ee lagu qeexay `track_right_edge_idx` uu ku dhammaaday.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Waxay ka saareysaa lammaanaha qiimaha muhiimka ah ilmaha saxda ah waxayna dhigeysaa keydka qiimaha muhiimka ah ee waalidka, iyadoo riixeysa waalidkii hore ee qiimaha-muhiimka ahaa canugga bidix.
    ///
    /// Waxay ku celisaa gacan qabashada edge cunuga bidix ee ay qeexday `track_left_edge_idx`, kaas oo aan dhaqaaqin.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Tani xatooyo la mid ah `steal_left` laakiin xatooyo cunsurro badan hal mar.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Hubso inaan si ammaan ah wax u xadin karno.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Dhaqaaq xogta caleen.
            {
                // U bannee meel walxaha la xaday ilmaha saxda ah.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // U dhaqaaq canugga bidix una dhaqaaji midig.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // U wareeji lammaanaha bidix-ugu badan waalidka.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // U qaad labada lammaane ee qiimaha-fure u ah ilmaha saxda ah.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // U bannee meel geesaha la soo xaday.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Xatoo geesaha.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Xirmooyinka isku-dhafan ee `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Hubso inaan si ammaan ah wax u xadin karno.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Dhaqaaq xogta caleen.
            {
                // U dhaqaaji labada lammaane ee midig-dhaca ah.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // U dhaqaaq labada lammaane ee qiimaha-fure u ah ilmaha bidix.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // U dhaqaaq canugga midigta bidix.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Buuxi farqiga halka walxaha la xado ay ahaan jireen.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Xatoo geesaha.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Ku buuxi farqiga meeshii geesaha la xadi jiray ay ahaan jireen.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Wuxuu meesha ka saarayaa wixii macluumaad ah ee taagan ee sheegaya in noodhadhkani yahay node `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Wuxuu meesha ka saarayaa wixii macluumaad ah ee taagan ee sheegaya in noodhadhkani yahay node `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Wuxuu hubiyaa in guntinta hoose ay tahay xumbada `Internal` ama node `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// U wareeji dib u habeynta ka dib `self` hal noodh una gudbo mid kale.`right` waa inuu madhan yahay.
    /// edge-kii ugu horreeyay ee `right` wali isma beddelin.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Natiijada galinta, markii buro loo baahdo in lagu ballaariyo wixii ka baxsan awooddeeda.
pub struct SplitResult<'a, K, V, NodeType> {
    // Node la beddelay geedka jira ee canaasirta iyo geesaha ka tirsan bidixda `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Furaha iyo qiimaha qaar baa kala jabay, oo la gelinayaa meelo kale.
    pub kv: (K, V),
    // Lahaansho, aan xirneyn, noodh cusub oo leh walxo iyo geesaha ka tirsan midigta `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Hadday tixraacyada noodhka ah ee nooca amaahdu u oggolaanayaan inay u gudbaan qaybaha kale ee geedka.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal uma baahna, waxay ku dhacdaa iyadoo la adeegsanayo natiijada `borrow_mut`.
        // Adoo curyaaminaya socodka, oo kaliya abuurista tixraacyo cusub oo xididdada ah, waxaan ognahay in tixraac kasta oo nooca `Owned` ah inuu yahay xidid xidid.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Gelisaa qiimo qayb ka mid ah walxaha la bilaabay oo ay ku xigto hal cunsur oo aan la aqoon.
///
/// # Safety
/// Jeexku wuxuu leeyahay in kabadan `idx` xubno.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Waxay ka saareysaa oo ay soocelineysaa qiime qeyb kamid ah walxaha la bilaabay, iyadoo laga tagayo hal cunsur oo aan la ogaanin.
///
///
/// # Safety
/// Jeexku wuxuu leeyahay in kabadan `idx` xubno.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Dhinacyada ayuu u dhaqaajiyaa qeybta bidix `distance`.
///
/// # Safety
/// Jeexku wuxuu leeyahay ugu yaraan xubno `distance` ah.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Cunsuriyada wuxuu ku wareejiyaa jeex jeexan `distance` dhanka midig.
///
/// # Safety
/// Jeexku wuxuu leeyahay ugu yaraan xubno `distance` ah.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Waxay ka wareejineysaa dhammaan qiimayaasha qayb ka mid ah walxaha la bilaabay isla markaana u wareejinaya qayb ka mid ah walxaha aan la ogeyn, iyadoo looga tegayo `src` iyadoo aan la aqoon.
///
/// Waxay u shaqaysaa sida `dst.copy_from_slice(src)` laakiin uma baahna `T` inuu noqdo `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;