use core::marker::PhantomData;
use core::ptr::NonNull;

/// Moodelladu waxay u yihiin dib-u-eegis tixraac gaar ah, markaad ogaato in dib-u-soo-celinta iyo dhammaan faracyadeeda (ie, dhammaan tilmaamayaasha iyo tixraacyada laga soo qaatay) aan dib dambe loo isticmaali doonin mar uun, ka dib markaa aad rabto inaad mar labaad isticmaasho tixraaca gaarka ah .
///
///
/// Hubiyaha amaahdu wuxuu inta badan kuu hayaa isku-dul-qaadashada amaahda adiga, laakiin qaar ka mid ah socodka kontoroolka ee ku guuleysta isku-darka ayaa aad ugu dhib badan isku-duwaha inuu raaco.
/// `DormantMutRef` wuxuu kuu ogolaanayaa inaad iska hubiso amaahda naftaada, adigoo wali muujinaya dabeecadeeda isdulsaartay, iyo soo koobida koodhka tilmaamaha cayriin ee loo baahan yahay in lagu sameeyo tan iyada oo aan la sifeynin dabeecad.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Qabso amaah gaar ah, isla markiibana dib u soo cesho.
    /// Isku soo wada duuboo, inta uu nool yahay tixraaca cusubi wuxuu la mid yahay cimriga tixraaca asalka ah, laakiin adiga promise si aad ugu isticmaasho muddo gaaban.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // BADBAADADA: Waxaan amaahda ku haysannaa inta u dhexeysa 'a illaa `_marker`, waana soo bandhigeynaa
        // kaliya tixraacan, markaa waa mid gaar ah.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// U noqo deynta gaarka ah ee markii hore la qabtay.
    ///
    /// # Safety
    ///
    /// Dib-u-helku waa inuu dhammaadaa, yacni, tixraaca ay soo celisay `new` iyo dhammaan tilmaamayaasha iyo tixraacyada laga soo qaatay, waa inaan dib dambe loo isticmaalin.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // BADBAADADA: Xaaladaheena nabadgelyada ayaa tilmaamaya tixraackani mar kale waa mid gaar ah.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;