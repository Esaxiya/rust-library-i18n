use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Waa loo wada dhan yahay si loo raadiyo, sida `Bound::Included(T)` oo kale.
    Included(T),
    /// Xirnaan gaar ah oo la raadinayo, sida `Bound::Excluded(T)` oo kale.
    Excluded(T),
    /// Kuxiran shuruud la'aan, sida `Bound::Unbounded` oo kale.
    AllIncluded,
    /// Xadhig aan shuruud lahayn
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Wuxuu fiiriyaa fure la siiyay geed hoosaad (sub) geed madax u yahay, soo noqnoqoshada.
    /// Sooceliyaa `Found` leh gacan ku haynta KV u dhigma, haddii ay jirto.
    /// Haddii kale, wuxuu soo celiyaa `GoDown` oo leh gacanta caleenta edge halkaasoo furaha iska leh.
    ///
    /// Natiijadu waa macno kaliya haddii geedka lagu dalbado furaha, sida geedka ku jira `BTreeMap` uu yahay.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Waxay u dhaadhacdaa noodhka ugu dhow halka edge ee u dhigma xadka hoose ee kaladuwan uu ka duwan yahay edge oo u dhigma xarka sare, ie, noodhka ugu dhow oo leh ugu yaraan hal fure oo ku jira baaxadda.
    ///
    ///
    /// Haddii la helo, wuxuu soo celiyaa `Ok` oo leh noodhkaas, labada tilmaamood ee 'edge indices' ayaa ku jira xaddidaadda baaxadda, iyo labada xad ee u dhigma ee ku sii socoshada baaritaanka ee noodhadhka ilmaha, haddii ay noodhku yahay mid gudaha ah.
    ///
    /// Haddii aan la helin, wuxuu soo celinayaa `Err` oo leh caleen edge oo u dhiganta dhammaan baaxadda.
    ///
    /// Natiijadu waa macno kaliya haddii geedka lagu dalbado fure.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Khariidaynta is-beddelayaashan waa in laga fogaadaa.
        // Waxaan u maleyneynaa in xuduudaha uu soo sheegay `range` ay sidiisii ahaanayaan, laakiin hirgelinta khilaafku wuu isbeddeli karaa inta udhaxeysa wicitaanada (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Wuxuu ka helaa edge noodhka xaddidaya xadka hoose ee kaladuwanaanta.
    /// Sidoo kale wuxuu soo celiyaa xarka hoose si loogu isticmaalo sii wadida baaritaanka ee ku habboon node node, haddii `self` uu yahay node gudaha ah.
    ///
    ///
    /// Natiijadu waa macno kaliya haddii geedka lagu dalbado fure.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Jilbaha `find_lower_bound_edge` ee xarka sare.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Waxay fiirisaa furaha la siiyay ee ku yaal barta, dib u noqosho la'aan.
    /// Sooceliyaa `Found` leh gacan ku haynta KV u dhigma, haddii ay jirto.
    /// Haddii kale, wuxuu soo celiyaa `GoDown` leh gacan ku haynta edge halkaasoo fure laga heli karo (haddii buqcaddu tahay gudaha) ama halka furaha la gelin karo.
    ///
    ///
    /// Natiijadu waa macno kaliya haddii geedka lagu dalbado furaha, sida geedka ku jira `BTreeMap` uu yahay.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Soocelinaya midkood tusmada KV ee barta ku taal furaha (ama wax u dhigma), ama tusmada edge halka uu furaha iska leeyahay.
    ///
    ///
    /// Natiijadu waa macno kaliya haddii geedka lagu dalbado furaha, sida geedka ku jira `BTreeMap` uu yahay.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Wuxuu kahelaa tusmada 'edge' node ee xaddidaya xadka hoose ee kaladuwanaanta.
    /// Sidoo kale wuxuu soo celiyaa xarka hoose si loogu isticmaalo sii wadida baaritaanka ee ku habboon node node, haddii `self` uu yahay node gudaha ah.
    ///
    ///
    /// Natiijadu waa macno kaliya haddii geedka lagu dalbado fure.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Jilbaha `find_lower_bound_index` ee xarka sare.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}