//! Liis laba-laaban oo lalaxiriira noodhadh ay leeyihiin.
//!
//! `LinkedList` wuxuu oggol yahay riixista iyo boodboodka walxaha dhammaadka waqtiga joogtada ah.
//!
//! NOTE: Had iyo jeer way kafiican tahay in la isticmaalo [`Vec`] ama [`VecDeque`] maxaa yeelay weelasha isku-dhafan ee isku-xiran guud ahaan waa kuwo dhaqso badan, xasuus badan, oo si fiican u isticmaala kaydinta CPU.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Liis laba-laaban oo lalaxiriira noodhadh ay leeyihiin.
///
/// `LinkedList` wuxuu oggol yahay riixista iyo boodboodka walxaha dhammaadka waqtiga joogtada ah.
///
/// NOTE: Waxaa had iyo jeer ka fiican in la isticmaalo `Vec` ama `VecDeque` waxaa ugu wacan in weelasha soo diyaariyeen ku salaysan guud ahaan dhaqso yihiin, xusuusta ku ool ah, oo si fiican loo isticmaalo kayd processor.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Kucelceliyaha waxyaabaha ka kooban `LinkedList`.
///
/// `struct` kan waxaa sameeyay [`LinkedList::iter()`].
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Ka saar dhanka `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Sooceliyaha isbeddelaya ee ka sarreeya cunsurrada `LinkedList`.
///
/// `struct` kan waxaa sameeyay [`LinkedList::iter_mut()`].
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Annagu * gaar uma lihin liistada oo dhan halkan, tixraacyada node-ka `element` waxaa dhiibtay soo-saaraha!Marka ka taxaddar markaad isticmaaleyso tan;hababka loo yaqaan waa inay ogaadaan inay jiri karaan tilmaamayaal magac u yaal `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Kucelceliyaha lahaanshaha cunsurrada `LinkedList`.
///
/// `struct`-kan waxaa abuuray habka [`into_iter`] ee [`LinkedList`] (oo ay bixiso `IntoIterator` trait).
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// hababka gaarka loo leeyahay
impl<T> LinkedList<T> {
    /// Waxay ku daraysaa noodhka qaybta hore ee liiska.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Qaabkani wuxuu taxaddar siinayaa inaan loo abuurin tixraacyo isku-beddel ah oo ku saabsan dhammaan noodhadhka, si loo ilaaliyo ansaxnimada tilmaamayaasha magac-u-dhaca ee `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Ma abuurayo tixraacyo cusub oo isbeddelaya (unique!) oo is dul saaran `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Wuxuu saarayaa oo soo celinayaa guntinta hore ee liiska.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Qaabkani wuxuu taxaddar siinayaa inaan loo abuurin tixraacyo isku-beddel ah oo ku saabsan dhammaan noodhadhka, si loo ilaaliyo ansaxnimada tilmaamayaasha magac-u-dhaca ee `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Ma abuurayo tixraacyo cusub oo isbeddelaya (unique!) oo is dul saaran `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Waxay ku daraysaa noodhka qaybta dambe ee liiska.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Qaabkani wuxuu taxaddar siinayaa inaan loo abuurin tixraacyo isku-beddel ah oo ku saabsan dhammaan noodhadhka, si loo ilaaliyo ansaxnimada tilmaamayaasha magac-u-dhaca ee `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Ma abuurayo tixraacyo cusub oo isbeddelaya (unique!) oo is dul saaran `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Wuxuu saaraa oo soo celiyaa guntinta dambe ee liiska.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Qaabkani wuxuu taxaddar siinayaa inaan loo abuurin tixraacyo isku-beddel ah oo ku saabsan dhammaan noodhadhka, si loo ilaaliyo ansaxnimada tilmaamayaasha magac-u-dhaca ee `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Ma abuurayo tixraacyo cusub oo isbeddelaya (unique!) oo is dul saaran `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Wuxuu ka gooyaa noodhka la cayimay liistada hadda jirta.
    ///
    /// Digniin: tani ma hubin doonto in noodhka la bixiyay uu ka tirsan yahay liiska hadda jira.
    ///
    /// Qaabkani wuxuu taxaddar siinayaa inaan loo abuurin tixraacyo la beddeli karo oo loo yaqaan `element`, si loo ilaaliyo ansaxnimada tilmaamayaasha magac u yaal.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // midkani annagaa iska leh hadda, waxaan abuuri karnaa &mut.

        // Ma abuurayo tixraacyo cusub oo isbeddelaya (unique!) oo is dul saaran `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // buundadani waa noodhka madaxa
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // buqcadani waa noodhka dabada
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Waxay kala jajabisaa noodhadh taxane ah oo u dhexeeya laba noodhyo jira.
    ///
    /// Digniin: kani ma hubin doono in noodhka la bixiyay uu ka tirsan yahay labada liis ee jira.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Qaabkani wuxuu taxaddar siinayaa inaan loo abuurin tixraacyo badan oo isku-beddel ah oo ku saabsan guntimaha oo dhan isla waqtigaas, si loo ilaaliyo ansaxnimada tilmaamaha tilmaamaya `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Wuxuu kala soocayaa dhammaan noodhka liistada ku xiran oo ah taxane burooyin ah.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Qaybta kala-baxda ayaa ah noodhka madaxa cusub ee qaybta labaad
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Hagaaji ptr madaxa qeybta labaad
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Qaybta kala-baxda waa noodhka cusub ee qaybta hore waxayna leedahay madaxa qaybta labaad.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Hagaaji dabada ptr ee qaybta hore
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Waxay abuurtaa `LinkedList<T>` madhan.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Waxay abuurtaa `LinkedList` madhan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Dhaqdhaqaaqa dhamaan walxaha laga bilaabo `other` ilaa dhamaadka liiska.
    ///
    /// Tani waxay dib u isticmaashaa dhammaan noodhadhka ka yimaada `other` waxayna u wareejisaa `self`.
    /// Hawlgalkan ka dib, `other` ayaa madhan.
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(1) waqtiga iyo *O*(1) xusuusta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` waa iska caadi halkan sababtoo ah waxaan marin gaar ah u leenahay dhammaan liisaska.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Dhaqdhaqaaqa dhammaan walxaha laga bilaabo `other` ilaa bilowga liiska.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` waa iska caadi halkan sababtoo ah waxaan marin gaar ah u leenahay dhammaan liisaska.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Waxay bixisaa soo-wade hore.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Waxay siisaa sheege hormaris ah oo leh tixraacyo la beddeli karo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Waxay ku siisaa tilmaame barta hore.
    ///
    /// Calaamaduhu waxay tilmaameysaa "ghost" non-element haddii liistadu madhan tahay.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Waxay ku siisaa tilmaame hawlgallada tifaftirka qaybta hore.
    ///
    /// Calaamaduhu waxay tilmaameysaa "ghost" non-element haddii liistadu madhan tahay.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Waxay ku siisaa tilmaame qeybta dambe.
    ///
    /// Calaamaduhu waxay tilmaameysaa "ghost" non-element haddii liistadu madhan tahay.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Waxay ku siisaa tilmaame hawlgallada tifaftirka qeybta dambe.
    ///
    /// Calaamaduhu waxay tilmaameysaa "ghost" non-element haddii liistadu madhan tahay.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Sooceliyaa `true` haddii `LinkedList` madhan yahay.
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(1) waqti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Sooceliyaa dhererka `LinkedList`.
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(1) waqti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Ka saaraa dhammaan walxaha `LinkedList`.
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(*n*) waqtiga.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Sooceliyaa `true` haddii `LinkedList` ku jira element ah simanyihiin in qiimaha la siiyey.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Waxay siisaa tixraac qaybta hore, ama `None` haddii liistadu madhan tahay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Waxay bixiyaan tixraac mutable in element hore, ama `None` haddii liiska waa faaruq.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Waxay siisaa tixraac qaybta dambe, ama `None` haddii liistadu madhan tahay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Waxay siisaa tixraac la beddeli karo qaybta dambe, ama `None` haddii liistadu madhan tahay.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Liiska ayuu ku daraa marka hore liiska.
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(1) waqti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Waxay ka saartaa curiyaha koowaad oo soo celisaa, ama `None` haddii liistadu madhan tahay.
    ///
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(1) waqti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Waxay ku lifaaqan tahay curiyaha dhabarka liiska.
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(1) waqti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Liistada ayuu ka saaraa liiska oo wuu soo celiyaa, ama `None` haddii uu madhan yahay.
    ///
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(1) waqti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Liiska wuxuu u kala qeybiyaa labo tusmo.
    /// Soo celiyaa wax walba kadib tusmada la bixiyay, oo ay kujiraan tusmada.
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(*n*) waqtiga.
    ///
    /// # Panics
    ///
    /// Panics haddii `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Hoosta, waxaan usoconaa dhanka 'n-1`th node, ama bilowga ama dhamaadka, taas oo kuxiran hadba kan dhaqsaha badan.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // halkii aan ka boodayn lahayn adeegsiga .skip() (taas oo abuureysa qaab dhismeed cusub), waxaan uga boodnaa gacanta si aan u geli karno qaybta madaxa iyada oo aan ku xirnayn faahfaahinta fulinta Skip
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // fiican inaad ka bilowdo dhamaadka
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Waxay ka saareysaa curiyaha tusmada la siiyay oo soo celinaysaa.
    ///
    /// Hawlgalkani waa inuu ku xisaabtamo *O*(*n*) waqtiga.
    ///
    /// # Panics
    /// Panics hadday tahay>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Hoosta, waxaan u jiheysiineynaa barta ku taal tusmada la siiyay, midkood bilowga ama dhamaadka, taas oo kuxiran hadba kan ka dheereeya.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Waxay abuurtaa soo noqnoqe adeegsade xiritaanka si loo go'aamiyo haddii walxo laga saarayo.
    ///
    /// Haddii xiritaanku run ku soo noqdo, markaa curiyaha ayaa laga saaraa oo la dhalaa.
    /// Hadday xiritaanku been ku soo noqoto, cunsurku wuxuu ku jiri doonaa liiska mana soo saari doono soo-saaraha.
    ///
    /// Xusuusnow in `drain_filter` ay kuu oggolaanayso inaad beddesho qayb kasta oo ka mid ah xiritaanka shaandhada, iyadoon loo eegin inaad dooratay inaad haysato ama ka saarto.
    ///
    ///
    /// # Examples
    ///
    /// U kala qaadista liistada fiidnimo iyo qasaaro, dib u adeegsiga liistada asalka ah:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // iska ilaali arrimaha amaahda.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Ku sii wad isla wareegga aan hoos ku sameyno.Tani waxay socotaa oo keliya marka wax burburiya uu argagaxo.
                // Haddii midkale oo panics ah kani soo ridi doono.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Waxaad ubaahantahay nolol aan xad lahayn si aad uhesho 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Waxaad ubaahantahay nolol aan xad lahayn si aad uhesho 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Waxaad ubaahantahay nolol aan xad lahayn si aad uhesho 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Waxaad ubaahantahay nolol aan xad lahayn si aad uhesho 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Calaamadee ka weyn `LinkedList`.
///
/// `Cursor` waa sida soo-noq-noqosho oo kale, marka laga reebo inay si xor ah u raadin karto hore iyo gadaal.
///
/// Calaamadeeyayaashu had iyo jeer waxay ku nastaan inta udhaxeysa laba walxood oo ku jira liiska, iyo isugeyn qaab macquul ah oo wareegsan.
/// Si tan loo waafajiyo, waxaa jira "ghost" non-element oo soo saara `None` inta udhaxeysa madaxa iyo dabada liiska.
///
///
/// Markii la abuuray, calaamaduhu waxay ka bilaabmaan xagga hore ee liiska, ama "ghost"-aan curiye ahayn haddii liistadu madhan tahay.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// Calaamadeeye ka badan `LinkedList` oo leh hawlgallo tafatir ah.
///
/// `Cursor` waa sida soo-celinta oo kale, marka laga reebo inay si xor ah u raadin karto dib-u-socod, iyo inay si ammaan ah u beddeli karto liiska inta lagu jiro soo-celinta.
/// Tani waa sababta oo ah inta ay nooshahay tixraacyadeeda soo saarku waxay kuxiran yihiin noloshiisa, halkii ay ka ahaan lahayd oo keliya liistada hoose.
/// Taas macnaheedu waa calaamadeeyaashu ma soo saari karaan walxo badan hal mar.
///
/// Calaamadeeyayaashu had iyo jeer waxay ku nastaan inta udhaxeysa laba walxood oo ku jira liiska, iyo isugeyn qaab macquul ah oo wareegsan.
/// Si tan loo waafajiyo, waxaa jira "ghost" non-element oo soo saara `None` inta udhaxeysa madaxa iyo dabada liiska.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Sooceliyaa tusmada booska calaamadeeyaha gudaha `LinkedList`.
    ///
    /// Tani waxay soo celinaysaa `None` haddii calaamaddu hadda tilmaamayso "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Waxay u guureysaa calaamadda qeybta xigta ee `LinkedList`.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element markaa tani waxay u wareejineysaa curiyaha koowaad ee `LinkedList`.
    /// Haddii ay tilmaamayso curiyihii ugu dambeeyay ee `LinkedList` markaa tani waxay u wareejin doontaa "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Cunsur aan hadda jirnay ma jirin;tilmaamuhu wuxuu fadhiyey booska bilowga Cunsurka soo socda waa inuu noqdaa madaxa liiska
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Waxaan leenahay cunsur hore, haddaba aan u gudubno ku xiga
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Waxay u guureysaa calaamadda culeyska hore ee `LinkedList`.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dib tani waxay u wareejin doontaa cunsurkii ugu dambeeyay ee `LinkedList`.
    /// Haddii ay tilmaamayso curiyaha koowaad ee `LinkedList` markaa tani waxay u wareejin doontaa "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // No hadda.Waxaan joognaa bilowga liiska.Waxba ha soo kordhin oo u bood ilaa dhamaadka.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Hayso hordhacU haay oo u gudub cunsurkii hore.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Soocelin tixraac cunsurku tilmaamku hadda tilmaamayo.
    ///
    /// Tani waxay soo celinaysaa `None` haddii calaamaddu hadda tilmaamayso "ghost" non-element.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Soocelin tixraac cunsurka xiga.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dib kani wuxuu soo celinayaa cunsurkii ugu horreeyay ee `LinkedList`.
    /// Haddii ay tilmaamayso curiyihii ugu dambeeyay ee `LinkedList` markaa kani wuxuu soo celinayaa `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Sooceliyaa inay marjic u element hore.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dib kani wuxuu soo celinayaa cunsurkii ugu dambeeyay ee `LinkedList`.
    /// Haddii ay tilmaamayso curiyaha koowaad ee `LinkedList` markaa kani wuxuu soo celinayaa `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Sooceliyaa tusmada booska calaamadeeyaha gudaha `LinkedList`.
    ///
    /// Tani waxay soo celinaysaa `None` haddii calaamaddu hadda tilmaamayso "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Waxay u guureysaa calaamadda qeybta xigta ee `LinkedList`.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element markaa tani waxay u wareejineysaa curiyaha koowaad ee `LinkedList`.
    /// Haddii ay tilmaamayso curiyihii ugu dambeeyay ee `LinkedList` markaa tani waxay u wareejin doontaa "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Cunsur aan hadda jirnay ma jirin;tilmaamuhu wuxuu fadhiyey booska bilowga Cunsurka soo socda waa inuu noqdaa madaxa liiska
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Waxaan leenahay cunsur hore, haddaba aan u gudubno ku xiga
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Waxay u guureysaa calaamadda culeyska hore ee `LinkedList`.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dib tani waxay u wareejin doontaa cunsurkii ugu dambeeyay ee `LinkedList`.
    /// Haddii ay tilmaamayso curiyaha koowaad ee `LinkedList` markaa tani waxay u wareejin doontaa "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // No hadda.Waxaan joognaa bilowga liiska.Waxba ha soo kordhin oo u bood ilaa dhamaadka.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Hayso hordhacU haay oo u gudub cunsurkii hore.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Soocelin tixraac cunsurku tilmaamku hadda tilmaamayo.
    ///
    /// Tani waxay soo celinaysaa `None` haddii calaamaddu hadda tilmaamayso "ghost" non-element.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Soocelin tixraac cunsurka xiga.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dib kani wuxuu soo celinayaa cunsurkii ugu horreeyay ee `LinkedList`.
    /// Haddii ay tilmaamayso curiyihii ugu dambeeyay ee `LinkedList` markaa kani wuxuu soo celinayaa `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Sooceliyaa inay marjic u element hore.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dib kani wuxuu soo celinayaa cunsurkii ugu dambeeyay ee `LinkedList`.
    /// Haddii ay tilmaamayso curiyaha koowaad ee `LinkedList` markaa kani wuxuu soo celinayaa `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Sooceliyaa tilmaam-akhrin kaliya tilmaamaya curiyaha hadda jira.
    ///
    /// Nolosha `Cursor` ee la soo celiyey waxay ku xidhan tahay tan `CursorMut`, taas oo macnaheedu yahay in aanu noolaan karin `CursorMut` iyo in `CursorMut` la qaboojiyey inta uu nool yahay `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Hada howlaha tafatirka liiska

impl<'a, T> CursorMut<'a, T> {
    /// Geliya qayb cusub `LinkedList` ka dib midka hada socda.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dibna curiye cusub ayaa la gelinayaa wejiga hore ee `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Heerka aan-cunsureedka ee "ghost" ayaa is beddelay.
                self.index = self.list.len;
            }
        }
    }

    /// Gelinaya qayb cusub `LinkedList` ka hor midka hadda socda.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dib ayaa curiyaha cusub la gelinayaa dhamaadka `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Ka saaraysaa curiyaha hadda jira `LinkedList`.
    ///
    /// Cunsurihii la saaray waa la soo celiyey, calaamadihiina waxaa loo dhaqaaqay inuu tilmaamo cunsurka xiga ee `LinkedList`.
    ///
    ///
    /// Haddii tilmaamuhu uu hadda tilmaamayo "ghost" non-element ka dib markaa cunsur lama saarayo oo `None` ayaa la soo celinayaa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Waxay ka saaraysaa curiyaha hadda `LinkedList` iyadoon lala wareegin noodhka liiska.
    ///
    /// Noodhka la saaray ayaa loo soo celiyey sidii `LinkedList` cusub oo ay ku jirto oo keliya buqshaddan.
    /// Calaamadda ayaa loo dhaqaaqay si loo tilmaamo cunsurka xiga ee hadda ah `LinkedList`.
    ///
    /// Haddii tilmaamuhu uu hadda tilmaamayo "ghost" non-element ka dib markaa cunsur lama saarayo oo `None` ayaa la soo celinayaa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Geliya walxaha ka imanaya `LinkedList` kadib midka hada socda.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dibna walxaha cusub ayaa la gelinayaa bilowga `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Heerka aan-cunsureedka ee "ghost" ayaa is beddelay.
                self.index = self.list.len;
            }
        }
    }

    /// Geliya walxaha ka imanaya `LinkedList` ka hor midka hadda socda.
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dibna qaybaha cusub ayaa la gelinayaa dhamaadka `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Liiska wuxuu u kala qaadaa labo kadib curiyaha hadda jira.
    /// Tani waxay soo celin doontaa liis cusub oo ka kooban wax walba tilmaamaha ka dib, iyadoo liiskii asalka ahaa uu wax walba ka horreeyay.
    ///
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dibna dhammaan waxyaabaha ku jira `LinkedList` waa la dhaqaajinayaa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Heerka aan-cunsureedka ee "ghost" wuxuu isu beddelay 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Liiska wuxuu u kala qaadaa labo ka hor curiyaha hadda jira.
    /// Tani waxay soo celin doontaa liis cusub oo ka kooban wax walba tilmaamaha kahor, iyadoo liiskii asalka ahaa ay wax walba hayaan wixii ka dambeeyay.
    ///
    ///
    /// Haddii tilmaamuhu tilmaamayo "ghost" non-element ka dibna dhammaan waxyaabaha ku jira `LinkedList` waa la dhaqaajinayaa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Falanqeeye soosaarid ah oo lagu soo saaray wicitaanka `drain_filter` ee LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` waa caadi marka la tixraaco tixraacyada `element`.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Liistada ayuu u adeegsanayaa soo noqnoqod keenaya cunsurro qiime ahaan.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Hubso in `LinkedList` iyo tarjumeyaasheeda akhriska keliya ku kala duwan yihiin noocyadooda.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}