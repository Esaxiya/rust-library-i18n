//! Saf saf mudnaan leh ayaa lagu hirgeliyay taallo laba geesood ah.
//!
//! Gelinta iyo soo-saarista curiyaha ugu weyn waxay leeyihiin isku-buuqsanaanta waqtiga *O*(log(*n*)).
//! Hubinta curiyaha ugu weyn waa *O*(1).U beddelashada vector qashin binary ayaa lagu samayn karaa goobta dhexdeeda, waxayna leedahay kakanaanta *O*(*n*).
//! Taallada laba-geesoodka ah ayaa sidoo kale loo rogi karaa vector kala-saar ah oo goobta dhexdeeda ah, taas oo u oggolaanaysa in loo isticmaalo *O*(*n*\*log(* n*)) meel-taal ah.
//!
//! # Examples
//!
//! Tani waa tusaale weyn oo hirgeliya [Dijkstra's algorithm][dijkstra] si loo xalliyo [shortest path problem][sssp] ee [directed graph][dir_graph].
//!
//! Waxay muujineysaa sida loo isticmaalo [`BinaryHeap`] noocyada caadada ah.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Safka mudnaanta ayaa kuxiran `Ord`.
//! // Si cad u dhaqan geli trait markaa safku wuxuu noqdaa min-taallo halkii laga dhigi lahaa max-taallo.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Fiiro u yeelo in anaga aan dalabka ku rogno kharashka.
//!         // Haddii ay dhacdo isku dheelitir waxaan isbarbar dhigeynaa jagooyinka, talaabadani waa lagama maarmaan si loo sameeyo hirgelinta `PartialEq` iyo `Ord` mid iswaafaqsan.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` u baahan in la hirgaliyo sidoo kale.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Noodh kasta wuxuu u taagan yahay sidii `usize`, fulin gaaban.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra dariiqa ugu gaaban algorithm.
//!
//! // Ka bilow `start` oo isticmaal `dist` si aad ula socoto masaafada ugu gaaban ee hadda u jirta noodh kasta.Hirgelintaani ma ahan mid xasuusta ku habboon maxaa yeelay waxay ku reebi kartaa noodhadh nuqul ah safka.
//! //
//! // Waxay sidoo kale u adeegsaneysaa `usize::MAX` qiime ahaan sentinel, fulin fudud.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=Masaafada ugu gaaban hadda laga bilaabo `start` ilaa `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Waxaan joognaa `start`, oo leh qiimo eber ah
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Baadh xuduuda leh noodhadhka qiimaha hoose marka hore (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Beddel ahaan waan sii wadi karnay inaan helno dhammaan waddooyinka ugu gaaban
//!         if position == goal { return Some(cost); }
//!
//!         // Muhiim maadaama laga yaabo inaan horeyba u helnay dariiq ka wanaagsan
//!         if cost > dist[position] { continue; }
//!
//!         // Baqdin kasta oo aan gaari karno, fiiri haddii aan heli karno waddo leh qiime jaban oo maraya buqdan
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Hadday sidaas tahay, ku dar xadka oo sii wad
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Nasashada, waxaan hadda helnay dariiq ka wanaagsan
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Hadafka aan la gaari karin
//!     None
//! }
//!
//! fn main() {
//!     // Kani waa garaafka tooska ah ee aan isticmaali doonno.
//!     // Lambarada noodhka waxay u dhigmaan gobollada kala duwan, iyo miisaanka edge wuxuu astaan u yahay qiimaha ka guurista hal noodhadh ilaa mid kale.
//!     //
//!     // Ogsoonow in geesaha ay yihiin hal dhinac.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Jaantusku wuxuu u taagan yahay liistada isku dhejiska halkaas oo tusmo kasta, oo u dhiganta qiimaha node, ay leedahay liiska geesaha baxaya.
//!     // Lagu xushay waxqabadkeeda
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Noodhka 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Noodh 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Noodhka 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Noodhka 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Saf saf mudnaan leh ayaa lagu hirgeliyay taallo laba geesood ah.
///
/// Tani waxay noqon doontaa taako badan.
///
/// Waa khalad caqli gal ah in sheyga wax laga badalo si sheyga amarkiisu ugu qaraabto shey kasta oo kale, sida lagu go'aamiyay `Ord` trait, wuu isbadalaa inta uu ku jiro taalada.
///
/// Tani caadi ahaan waa suurtagal keliya iyada oo loo marayo `Cell`, `RefCell`, dawlad caalami ah, I/O, ama koodh aan aamin ahayn.
/// Akhlaaqda ka dhalatey qaladkan caqliga ah lama qeexin, laakiin ma keeni doonto dhaqan aan la qeexin.
/// Tan waxaa ka mid noqon kara panics, natiijooyin qaldan, ilmo soo ridid, xusuus daadasho, iyo joojin la'aan.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Nooca fekerku wuxuu noo ogolaanayaa inaan ka tagno saxiix nooc cad ah (kaasoo noqon lahaa `BinaryHeap<i32>` tusaalahan).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Waxaan u adeegsan karnaa fiirinta si aan u eegno sheyga xiga ee tuulmada.
/// // Xaaladdan oo kale, ma jiraan wax shey ah oo halkaas ku yaal markaa sidaas darteed waxba kama helno.
/// assert_eq!(heap.peek(), None);
///
/// // Aynu ku darno xoogaa dhibco ah ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Hada peek ayaa muujinaya shayga ugu muhiimsan tuulmada.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Waan hubin karnaa dhererka taallo.
/// assert_eq!(heap.len(), 3);
///
/// // Waxaan dulmarin karnaa waxyaabaha ku jira tuulmada, inkasta oo si nidaamsan loogu soo celiyay.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Haddii aan baddalno buundooyinkan, waa inay ku soo noqdaan siday u kala horreeyaan.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Waxaan ka nadiifin karnaa tuulmada waxyaabaha haray.
/// heap.clear();
///
/// // Taalladu waa inay hadda noqotaa mid madhan.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Midkoodna `std::cmp::Reverse` ama dhaqan gelin `Ord` ah ayaa loo isticmaali karaa in laga sameeyo `BinaryHeap` min-heap.
/// Tani waxay ka dhigaysaa `heap.pop()` inuu soo celiyo qiimaha ugu yar halkii kan ugu weynaa.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Ku duub qiimaha `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Haddii aan ku soo baxno dhibcahaas hadda, waa inay ku soo noqdaan sida ay u kala horreeyaan.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Kakanaanta waqtiga
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Qiimaha `push` waa kharash la filayo;dukumiintiga habka ayaa siinaya falanqeyn faahfaahsan.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Qaab dhismeedka duubaya tixraac isbeddel ah oo ku saabsan sheyga ugu weyn ee `BinaryHeap`.
///
///
/// `struct`-kan waxaa abuuray habka [`peek_mut`] ee [`BinaryHeap`].
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // BADBAADADA: PeekMut waxaa kaliya loogu talagaly tuulmooyin aan madhaneyn.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // BADBAADO: PeekMut waxaa kaliya loogu talagalay in lagu tuuro tuulmado aan madhanayn
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // BADBAADO: PeekMut waxaa kaliya loogu talagalay in lagu tuuro tuulmado aan madhanayn
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Waxay ka saareysaa qiimaha la fiirsaday taalada oo dib ayey u soo celineysaa.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Waxay abuurtaa `BinaryHeap<T>` madhan.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Waxay abuurtaa `BinaryHeap` madhan oo ah isku darka max.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Waxay abuurtaa `BinaryHeap` madhan oo leh awood gaar ah.
    /// Tani preallocates xasuus ku filan walxaha `capacity`, si `BinaryHeap` ma aha in dib loo qoondeeyo ilaa ay ka kooban tahay ugu yaraan qiyam badan.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Sooceliyaa tixraac isbeddel ah oo ku saabsan sheyga ugu weyn ee ku jira qashinka, ama `None` haddii ay madhan tahay.
    ///
    /// Note: Haddii qiimaha `PeekMut` la daadsho, tuulmadu waxay ku jiri kartaa xaalad aan is waafaqsanayn.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Kakanaanta waqtiga
    ///
    /// Haddii sheyga wax laga beddelay markaa kakanaanta waqtiga ugu xun ee xaaladdu waa *O*(log(*n*)), haddii kale waa *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Wuxuu ka soo saaraa sheyga ugu weyn xalka binary wuuna soo celiyaa, ama `None` hadii uu madhan yahay.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Kakanaanta waqtiga
    ///
    /// Kharashka ugu xun ee `pop` ee ku yaal taallo ay ku jiraan *n* walxaha waa *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // AMMAAN: !self.is_empty() macnaheedu waa self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Shayga ku tuuraya tuubada binary.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Kakanaanta waqtiga
    ///
    /// Qiimaha la filayo ee `push`, celcelis ahaan amar kasta oo suurtagal ah ee walxaha la riixayo, iyo tiro badan oo ku filan oo la riixo, waa *O*(1).
    ///
    /// Tani waa qiyaasta qiimaha ugu macnaha badan marka la riixayo walxaha aan * horeyba u ahayn qaab kasta oo la soocay.
    ///
    /// Kakanaanta waqtiga ayaa hoos u dhacda haddii walxaha lagu riixo sida ugu sareysa.
    /// Xaaladda ugu xun, walxaha ayaa lagu riixaa iyada oo kor loo qaadayo nidaamka kala-soocida ah kharashka isugeynta ee riix kasta waa *O*(log(*n*)) oo ka dhan ah taallo ay ku jiraan *n* walxo.
    ///
    /// Kiiska ugu xun ee *hal* wicitaan ee `push` waa *O*(*n*).Xaaladda ugu xun waxay dhacdaa markii awoodda dhammaato oo ay u baahan tahay cabir.
    /// Qiimaha dib-u-habeynta ayaa lagu shaaciyey tirooyinkii hore.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // BADBAADADA: Tan iyo markii aan riixnay shay cusub taas macnaheedu waa taas
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Ku cuntaa `BinaryHeap` kuna soo celiyaa vector isku xigxigsan (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // BADBAADADA: `end` wuxuu ka socdaa `self.len() - 1` illaa 1 (labadaba waa lagu daray),
            //  markaa had iyo jeer waa tusmo sax ah oo lagu galo.
            //  Waa ammaan in la helo tusmada 0 (ie `ptr`), maxaa yeelay
            //  1 <=dhammaad <self.len(), oo macnaheedu yahay self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // BADBAADADA: `end` wuxuu ka socdaa `self.len() - 1` illaa 1 (labadaba waa lagu daray) sidaa darteed:
            //  0 <1 <=dhammaad <= self.len(), 1 <self.len() Oo macnaheedu yahay 0 <dhammaad iyo dhammaad <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Hirgelinta sift_up iyo sift_down waxay isticmaalaan baloogyo aan badbaado lahayn si looga saaro cunsur ka baxsan vector (oo looga tago dalool gadaashiisa), kuwa kale la wareego oo walxaha laga saaray dib ugu celiyo vector meesha ugu dambeysa ee godka.
    //
    // Nooca `Hole` ayaa loo adeegsadaa inuu matalo tan, oo hubi in daloolka dib loo buuxiyo dhamaadka baaxadiisa, xitaa panic.
    // Isticmaalka daloolku waxay yareyneysaa qodobka joogtada ah ee la barbardhigayo adeegsiga isku beddelashada, taas oo ku lug leh laba jeer dhaqdhaqaaqyo badan.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Wicitaanku waa inuu damaanad qaadaa `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Ka soo saar qiimaha `pos` oo samee god.
        // BADBAADADA: Wicitaanku wuxuu dammaanad qaadayaa pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // AMMAAN: hole.pos()> bilow>=0, oo macnaheedu yahay hole.pos()> 0
            //  oo markaa hole.pos(), 1 ma soo qulquli karo.
            //  Tani waxay dammaanad ka qaadaysaa waalidkaas <hole.pos() marka waa tixraac ansax ah iyo sidoo kale!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // BADBAADADA: Waxay la mid tahay sida kor ku xusan
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Cunsur ku qaad `pos` oo hoos ugu dhaadhac meesha taallada, halka carruurteedu ka waaweyn yihiin.
    ///
    ///
    /// # Safety
    ///
    /// Wicitaanku waa inuu damaanad qaadaa `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // BADBAADADA: Wicitaanku wuxuu dammaanad qaadayaa in pos <dhamaadka <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop aan isbeddelin: cunug==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // isbarbar dhig midda ugu weyn labada carruur AMMAAN: cunug <dhammaad, 1 <self.len() iyo cunug + 1 <dhammaad <= self.len(), markaa iyagu waa tixraacyo sax ah.
            //
            //  cunug==2 *hole.pos() + 1!= hole.pos() iyo cunug + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 ama 2* hole.pos() + 2 wuu qarqi karaa hadii T yahay ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // hadaan horeyba ujirno, jooji.
            // BADBAADADA: cunuggu hadda waa cunuggii hore ama cunuggii hore + 1
            //  Waxaan horey u xaqiijinay in labaduba <self.len() iyo!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // AMMAANKA: waa isku mid sida kor ku xusan.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // AMMAANKA: &&wareegga gaaban, oo macnaheedu yahay taas
        //  xaalad labaad waa run run ilmahaas==dhammaad, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // AMMAANKA: canugga waxaa horey loo cadeeyay inuu yahay tusmo sax ah iyo
            //  canug==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Wicitaanku waa inuu damaanad qaadaa `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // BADBAADADA: pos <len waxaa dammaanad qaadaya soo wacaha iyo
        //  cad len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Cunsur ku qaad `pos` oo u dhaqaaq dhanka hoose ee tuulmada, ka dibna u kala shaandhee meeshiisa.
    ///
    ///
    /// Note: Tani way dhakhso badan tahay markii cunsurka la og yahay inuu weyn yahay/u dhow yahay xagga hoose.
    ///
    /// # Safety
    ///
    /// Wicitaanku waa inuu damaanad qaadaa `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // BADBAADADA: Wicitaanku wuxuu dammaanad qaadayaa pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop aan isbeddelin: cunug==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // BADBAADADA: ilmaha <dhammaadka, 1 <self.len() iyo
            //  cunuga + 1 <dhamaadka <= self.len(), marka iyagu waa tusmoyin sax ah.
            //  cunug==2 *hole.pos() + 1!= hole.pos() iyo cunug + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 ama 2* hole.pos() + 2 wuu qarqi karaa hadii T yahay ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // BADBAADADA: Waxay la mid tahay sida kor ku xusan
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // AMMAAN: cunug==dhammaad, 1 <self.len(), marka waa tixraac sax ah
            //  iyo ilmaha==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // BADBAADADA: pos waa booska godka waana la caddeeyay mar hore
        //  inuu noqdo tusmo sax ah.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // BADBAADADA: n waxay ka bilaabataa self.len()/2 waxayna u dhaadhacdaa 0.
            //  Xaaladda keliya ee goorma! (N <self.len()) waa haddii self.len() ==0, laakiin waxaa meesha ka saaray xaaladda wareegga.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Waxay u guurisaa dhammaan walxaha `other` `self`, iyadoo laga tegayo `other` madhan.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` qaadataa hawlgallada O(len1 + len2) iyo qiyaastii 2 *(len1 + len2) isbarbardhigga kiiska ugu xun halka `extend` uu qaadayo hawlgallada O(len2* log(len1)) iyo qiyaastii 1 *len2* log_2(len1) isbarbardhigga kiisaska ugu xun, isagoo u maleynaya len1>= len2.
        // Tuulmooyin waaweyn, barta isgoysku kama sii soconayso sababtan waxaana loo go'aamiyay si awood leh.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Waxay soo celisaa soo-celiyaha soo-ceshano cunsurro sidii ay u kala horreeyeen.
    /// Curiyeyaasha la soo saaray ayaa laga saarayaa halkii ay ku taallay asalkeedii.
    /// Walxaha haray waxaa laga soo saari doonaa dhibcaha dalab ahaan.
    ///
    /// Note:
    /// * `.drain_sorted()` waa *O*(*n*\*log(* n*)); aad uga gaabiyaa `.drain()`.
    ///   Waa inaad u isticmaashaa tan dambe kiisaska badankood.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // wuxuu ka saaraa dhammaan walxaha sida ay isugu xigaan
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Haysanayaa kaliya walxaha uu cayimay saadaashu.
    ///
    /// Si kale haddii loo dhigo, ka saar dhammaan walxaha `e` sida `f(&e)` u soo celiyo `false`.
    /// Cunsurrada waxaa lagu soo booqday si aan kala sooc lahayn (oo aan la cayimin).
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // kaliya hayso xitaa lambarro
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Sooceliyaa sooceliyaha booqda dhammaan qiimayaasha salka hoose vector, si amar la'aan ah.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ku daabac 1, 2, 3, 4 si amar la'aan ah
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Waxay soo celisaa soo-celiyaha soo-ceshano cunsurro sidii ay u kala horreeyeen.
    /// Habkani wuxuu cunaa tuulmigii asalka ahaa.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Soo celiyaa sheyga ugu weyn ee ku jira qashinka, ama `None` haddii uu madhan yahay.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Kakanaanta waqtiga
    ///
    /// Qiimaha waa *O*(1) xaalada ugu xun.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Soo celiyaa tirada cunsurooyinka taangiga binary ku hayaa iyada oo aan dib loo sii qoondeyn.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Waxay keyd u tahay awoodda ugu yar ee saxda ah `additional` canaasiir dheeri ah oo la gelinayo `BinaryHeap` la siiyay.
    /// Waxba ma qabanayso haddii awoodda mar horeba ku filan tahay.
    ///
    /// Ogsoonow in qoondeeyaha uu siin karo ururinta meel ka badan inta ay codsato.
    /// Sidaa darteed kartida laguma halayn karo inay si uun ugu yartahay.
    /// Doorbido [`reserve`] haddii la filayo gelinta future.
    ///
    /// # Panics
    ///
    /// Panics haddii awoodda cusubi buux dhaafiso `usize`.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Waxay keyd u tahay ugu yaraan `additional` canaasiir dheeri ah oo la gelinayo `BinaryHeap`.
    /// Ururinta ayaa laga yaabaa inay keydiso meelo badan si looga fogaado dib-u-dejinno badan
    ///
    /// # Panics
    ///
    /// Panics haddii awoodda cusubi buux dhaafiso `usize`.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Tuur inta ugu badan ee suurtagal ah.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Meesha ka saar awoodda leh xarka hoose.
    ///
    /// Awoodda ayaa sii ahaan doonta ugu yaraan mid weyn sida dhererka iyo qiimaha la keenay.
    ///
    ///
    /// Haddii awoodda hadda jirta ay ka yar tahay xadka ugu hooseeya, tani waa maya-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Waxay u isticmaashaa `BinaryHeap` waxayna kusoo celisaa salka vector si aan loo kala xigin.
    ///
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Si daabacan ayaan u daabici doonaa
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Soocelisaa dhererka taangiga binary.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Hubinta haddii qashinka binary uu faaruq yahay.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Wuxuu tirtirayaa tuubada binary, iyadoo kucelcelinaysa waxyaalihii laga saaray waxyaabaha soo saaray.
    ///
    /// Cunsurrada waxaa loo saaraa si amar la'aan ah.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Waxyaalaha oo dhan ka soo daadinaya qashinka
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Hole wuxuu u taagan yahay dalool jeex ah tusaale ahaan, tusmo aan qiimo sax ah lahayn (maxaa yeelay waa laga soo guuray ama waa la labalaabay).
///
/// Dhibic, `Hole` ayaa dib u soo celin doonta jeexista iyadoo la buuxinayo booska godka qiimaha markii hore laga saaray.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Abuur `Hole` cusub tusmada `pos`.
    ///
    /// Amaan ma leh maxaa yeelay pos waa inay ku jirtaa jeega xogta.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos waa inuu ku dhex jiraa jeex
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Soocelin tixraac cunsurka la saaray.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Kucelceliyaha tixraaca curiye `index`.
    ///
    /// Amaan ma leh maxaa yeelay tusmada waa inay ku dhex jirtaa jeega xogta oo aysan u dhigmin pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// God u dhaqaaq meel cusub
    ///
    /// Amaan ma leh maxaa yeelay tusmada waa inay ku dhex jirtaa jeega xogta oo aysan u dhigmin pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // godka buuxi markale
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Kucelceliyaha waxyaabaha ka kooban `BinaryHeap`.
///
/// `struct` kan waxaa sameeyay [`BinaryHeap::iter()`].
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Ka saar dhanka `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Kucelceliyaha lahaanshaha cunsurrada `BinaryHeap`.
///
/// `struct`-kan waxaa sameeyay [`BinaryHeap::into_iter()`] (oo ay bixiso `IntoIterator` trait).
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Ku celceliyaha dheecaanka ka saaraya cunsurrada `BinaryHeap`.
///
/// `struct` kan waxaa sameeyay [`BinaryHeap::drain()`].
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Ku celceliyaha dheecaanka ka saaraya cunsurrada `BinaryHeap`.
///
/// `struct` kan waxaa sameeyay [`BinaryHeap::drain_sorted()`].
/// Eeg dukumiintiyadeeda wixii intaa ka badan.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Waxay ka saareysaa walxo fara badan siday isugu xigaan.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// U rogaa `Vec<T>` una beddelaa `BinaryHeap<T>`.
    ///
    /// Beddelaadani waxay ku dhacdaa goobta, waxayna leedahay *O*(*n*) kakanaanta waqtiga.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// U rogaa `BinaryHeap<T>` una beddelaa `Vec<T>`.
    ///
    /// Beddelaadani uma baahna dhaqdhaqaaq xog ama qoondayn, waxayna leedahay kakanaansho waqti joogto ah.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Waxay abuurtaa soosaara wax cunaya, taasi waa, mid qiime kasta ka saarta qashinka binary-ga si amar la`aan ah.
    /// Taallada binaryka lama isticmaali karo ka dib markii tan la waco.
    ///
    /// # Examples
    ///
    /// Adeegsiga aasaasiga ah:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ku daabac 1, 2, 3, 4 si amar la'aan ah
    /// for x in heap.into_iter() {
    ///     // x wuxuu leeyahay nooca i32, ma ahan &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}