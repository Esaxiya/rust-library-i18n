#![stable(feature = "wake_trait", since = "1.51.0")]
//! Noocyada iyo Traits ee loogu talagalay la shaqeynta shaqooyinka aan caadiga ahayn.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Hirgelinta toosinta hawl fuliyaha.
///
/// trait-kan waxaa loo isticmaali karaa in lagu abuuro [`Waker`].
/// Fuliye ayaa qeexi kara hirgelinta trait, oo u adeegsan kara taas inuu dhiso Waker si uu ugu gudbiyo howlaha lagu fulinayo fuliyahaas.
///
/// trait Tani waa xasuus-ammaan ah oo kale ergonomic in dhismaha [`RawWaker`] ah.
/// Waxay taageertaa naqshadeynta fuliyaha guud ee xogta loo isticmaalay in lagu toosiyo hawl lagu kaydiyo [`Arc`].
/// Qaar ka mid ah fuliyaasha (gaar ahaan kuwa loogu talagalay nidaamyada gundhigga ah) ma isticmaali karaan API-kan, waana sababta [`RawWaker`] ay u jirto beddel ahaan nidaamyadaas.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Hawlaha aasaasiga ah ee `block_on` ee qaata future oo ku socodsiiya dhammaystirka dunta hadda jirta.
///
/// **Note:** Tusaalahan wuxuu ka ganacsadaa saxnaanta fudeydka.
/// Si looga hortago xilku, fulintii saarka-fasalka sidoo kale u baahan doonaa in ay la tacaalaan calls dhexe si `thread::unpark` iyo sidoo kale ducadaas nested.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Toos ah oo toosiya dunta hadda socota markii la waco.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Ku orod future dhammaystir mawjadda hadda jirta.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Bixi future si markaa loo codeeyo.
///     let mut fut = Box::pin(fut);
///
///     // Abuur macno cusub oo loo gudbiyo future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Orod future si dhamaystirka.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Ka kac hawshan.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Ka kac hawshan adiga oo aan cunin kan toosiyaha ah.
    ///
    /// Haddii fuliyaha uu taageero qaab jaban oo lagu toosiyo isagoon cunin kan toosiyaha ah, waa inuu ka takhalusaa qaabkan.
    /// Sida caadiga ah, waxay isku dhejisaa [`Arc`] waxayna ku wacdaa [`wake`] dhalada.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // BADBAADADA: Tani waa ammaan maxaa yeelay raw_waker si ammaan ah ayuu wax u dhisaa
        // RawWaker ka yimid Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Shaqadan gaarka loo leeyahay ee lagu dhisayo RawWaker waa la isticmaalay, halkii laga isticmaali lahaa
// taas oo ku soo bandhigeysa sawirka `From<Arc<W>> for RawWaker` impl', si loo hubiyo in amniga `From<Arc<W>> for Waker` uusan ku xirneyn dirista saxda ah ee 'trait', taa bedelkeed labaduba waxay ugu yeeraan shaqadan si toos ah iyo si cad.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Kordhinta tirinta tixraaca qaansada si loo kabo.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Ku qiimee qiimaha, u wareejinta Arc-ga waxqabadka Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Tixraac ku soo qaad, ku duub tooso ManuallyDrop si aad uga fogaato daadinta
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Hoos u dhac ku yimaada tirinta tixraaca Arc ee hoos u dhaca
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}