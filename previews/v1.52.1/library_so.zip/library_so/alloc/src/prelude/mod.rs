//! Qoondaynta Prelude
//!
//! Ujeedada qaybtani waa in la yareeyo soo dejinta waxyaabaha sida caadiga ah loo isticmaalo ee `alloc` crate iyadoo lagu darayo soo dejin caalami ah dusha sare ee modules:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;