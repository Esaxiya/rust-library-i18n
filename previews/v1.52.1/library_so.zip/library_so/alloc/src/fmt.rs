//! Adeegyada qaabeynta iyo daabacaadda ``String`s.
//!
//! Qaybtani waxay kakoobantahay taageerada waqtiga-socda ee [`format!`] kordhinta jumlada.
//! Macro-kan waxaa lagu hirgeliyaa isku-duwaha si uu u sii daayo wicitaannada qaybtan si loogu qaabeeyo doodaha xilliyada ay socdaan xargaha.
//!
//! # Usage
//!
//! Mashiinka [`format!`] waxaa loogu talagalay in lagu barto kuwa ka imanaya shaqooyinka C `printf`/`fprintf` ama Python's `str.format` function.
//!
//! Tusaalooyinka qaar ee kordhinta [`format!`] waa:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" oo leh eber hogaaminaya
//! ```
//!
//! Kuwaas waxaad ka arki kartaa in dooda ugu horeysa ay tahay xarig qaab.Waxaa looga baahan yahay iskuxiraha inuu kani noqdo xarig xarig ah;ma noqon karo doorsoome la soo gudbiyey (si loo sameeyo hubinta ansaxnimada).
//! Isku-dubaridaha ayaa markaa ka baaraandegaya xarigga qaabka oo go'aaminaya haddii liiska doodaha la bixiyay ay ku habboon yihiin in loo gudbiyo xariggan qaabkan ah.
//!
//! Si hal qiimo loogu beddelo xarig, isticmaal habka [`to_string`].Tani waxay isticmaali doontaa qaabeynta [`Display`] trait.
//!
//! ## Xuduudaha mansabka
//!
//! Dood kasta oo qaabeynta ah ayaa loo oggol yahay inay caddeyso doodda qiimaheeda ay tixraaceyso, haddii laga tagona waxaa loo maleynayaa inay tahay "the next argument".
//! Tusaale ahaan, xarigga qaabka `{} {} {}` wuxuu qaadan lahaa seddex beeg, waxaana loo qaabeyn doonaa si isku mid ah sida loo siiyay.
//! Qaabka qaabka `{2} {1} {0}`, si kastaba ha noqotee, wuxuu u qaabeyn lahaa doodaha qaab isku xigxiga.
//!
//! Waxyaabaha ayaa heli kara wax yar oo khiyaano ah markaad bilowdo inaad isku dhexgasho labada nooc ee tilmaamayaasha booska.Sifeeyaha "next argument" waxaa loo maleyn karaa inuu yahay mid kahadlaya dooda.
//! Mar kasta oo specifier "next argument" ah waxaa loo arkaa, horumarka iterator ah.Tani waxay u horseedaa dabeecad sidan ah:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Ka-hadalka gudaha ee ku saabsan doodda lama hor marin markii ugu horreysay ee la arko `{}`, sidaas darteed wuxuu daabacaa doodda koowaad.Kadib markuu gaaro `{}`-da labaad, soo-nooleyaha ayaa horey ugu sii gudbay doodda labaad.
//! Asal ahaan, halbeegyada si cad u magacaabaya dooddooda ma saameyn doonaan xuduudaha aan magacaabin dood marka la eego tilmaamayaasha jagada.
//!
//! Xarig qaab ayaa loo baahan yahay si loo isticmaalo dhammaan doodahiisa, haddii kale waa qalad isku-dubbarid ah.Waxaad u gudbin kartaa isla doodda in kabadan hal jeer xariga qaabka.
//!
//! ## Xuduudaha la magacaabay
//!
//! Rust lafteeda malahan wax u eg Python oo u dhigma cabirrada la magacaabay ee shaqaynta, laakiin macro [`format!`] waa fidin cajaa'ib u oggolaanaysa inay ka faa'iideysato xuduudaha la magacaabay.
//! Xuduudaha la magacaabay ayaa ku taxan dhamaadka liiska doodda oo waxay leeyihiin qaab:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Tusaale ahaan, muujinta soo socota ee [`format!`] dhammaantood waxay adeegsadaan dood la magacaabay:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Wax ansax ah ma ahan in la dhigo xuduudaha mowqifka (kuwa aan magacyo laheyn) doodaha magacyada ka dib.Sida xuduudaha mowqifka, ma aha ansax in la bixiyo cabbiro la magacaabay oo aan loo isticmaalin xarigga qaabka.
//!
//! # Halbeegyada qaabaynta
//!
//! Dood kasta oo la qaabeynayo waxaa loo beddeli karaa dhowr astaamood oo qaabeyn ah (oo u dhiganta `format_spec` ee [the syntax](#syntax)). Xuduudahaani waxay saameynayaan matalaadda xarigga waxa la qaabeynayo.
//!
//! ## Width
//!
//! ```
//! // Dhamaan daabacaadan "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Tani waa halbeegga loogu talagalay "minimum width" ee qaabku u baahan yahay inuu qaato.
//! Haddii qiimaha xadhiggu aanu buuxin astaamahan badan, markaa suufka lagu qeexay fill/alignment ayaa loo isticmaali doonaa inuu qaato booska loo baahan yahay (eeg hoos).
//!
//! Qiimaha ballaca sidoo kale waxaa loo bixin karaa sida [`usize`] liiska xuduudaha iyadoo lagu darayo postfix `$`, oo tilmaamaysa in dooda labaad ay tahay [`usize`] oo tilmaamaysa ballaca.
//!
//! Iyadoo lagu tilmaamayo in muran la Saan doolarka uusan saamayn ku lahayn counter "next argument" ah, sidaas darteed waa sida caadiga ah fikrad wanaagsan in ay tixraac dood by meel, ama isticmaal dood magacaabay a.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Dabeecadda buuxinta ikhtiyaariga ah iyo iswaafajinta waxaa la siiyaa si caadi ah iyadoo lala socdo xaddiga [`width`](#width).Waa in lagu qeexaa kahor `width`, isla `:` kadib.
//! Tani waxay muujineysaa in haddii qiimaha la qaabeynayo uu ka yar yahay `width` astaamo dheeri ah lagu daabici doono hareeraheeda.
//! Buuxinta waxay ku timaaddaa noocyada soo socda ee iswaafajinta kala duwan:
//!
//! * `[fill]<` - dooddu bidix ayey u dhigantahay tiirarka `width`
//! * `[fill]^` - dooddu waxay kuxirantahay xarunta tiirarka `width`
//! * `[fill]>` - dooddu waxay ku qumman tahay tiirarka `width`
//!
//! [fill/alignment](#fillalignment)-kii ugu dambeeyay ee tirooyinka aan tirade lahayn waa meel bannaan oo bidix ku toosan.Astaamaha loogu talagalay lambarrada nambarada sidoo kale waa astaamo meel bannaan laakiin la jaanqaadaysa midig.
//! Haddii calanka `0` (hoos fiiri) loo cayimay lambarro, markaa astaamaha buuxintiisa aan tooska ahayn waa `0`.
//!
//! Ogsoonow in isku toosinta laga yaabo in aysan fulinin noocyada qaar.Gaar ahaan, guud ahaan looma hirgelin `Debug` trait.
//! Qaab wanaagsan oo loo hubiyo in suufka la mariyo ayaa ah in qaab loo dejiyo talooyinkaaga, ka dibna suufka xariggan ka dhasha si aad u hesho wax soo saarkaaga:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hello Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Kuwani dhammaantood waa calammo wax ka beddelaya dhaqanka qaabeeyaha.
//!
//! * `+` - Tan waxaa loogu talagalay noocyada lambarrada waxayna muujineysaa in calaamadda marwalba la daabaco.Calaamadaha togan waligood laguma daabaco asal ahaan, calaamadda tabanna waxaa kaliya loogu qoraa asal ahaan `Signed` trait.
//! Calankani wuxuu muujinayaa in calaamadda saxda ah (`+` ama `-`) had iyo jeer la daabaco.
//! * `-` - Hadda lama isticmaalin
//! * `#` - Calankani wuxuu tilmaamayaa in qaabka "alternate" ee daabacaadda loo isticmaalo.Foomamka kale ayaa ah:
//!     * `#?` - quruxsan-daabac qaabeynta [`Debug`]
//!     * `#x` - wuxuu doodda ka hormariyaa `0x`
//!     * `#X` - wuxuu doodda ka hormariyaa `0x`
//!     * `#b` - wuxuu doodda ka hormariyaa `0b`
//!     * `#o` - wuxuu doodda ka hormariyaa `0o`
//! * `0` - Tan waxaa loo isticmaalaa in lagu muujiyo qaabab isku dhafan in suufka loo maro `width` ay tahay in labadaba lagu sameeyo astaamo `0` ah iyo sidoo kale inuu noqdo mid calaamadeysan.
//! Qaab la mid ah `{:08}` wuxuu u soo saari doonaa `00000001` isku darka `1`, halka isla qaabku uu dhali doono `-0000001` isku-darka `-1`.
//! Ogsoonow in nooca diidmada ahi uu ka yar yahay eber kan ka wanaagsan midka wanaagsan.
//!         Xusuusnow in eber-xireyaasha marwalba la dhigo calaamadda ka dib (haddii ay jiraan) iyo ka hor lambarrada.Markii si wada jir ah loogu adeegsado calanka `#`, xeer la mid ah ayaa khuseeya: eber-ku-xirashada ayaa la geliyaa horgalaha ka dib laakiin ka hor lambarrada.
//!         Horgalaha waxaa lagu daray wadarta guud.
//!
//! ## Precision
//!
//! Noocyada aan tirada ahayn, tan waxaa loo qaadan karaa inay tahay "maximum width".
//! Haddii xarigga ka dhashay uu ka dheer yahay ballacgan, markaa waxaa loo jajabiyay astaamahan tirada badan iyo in qiimaha la jarjaray lagu sii daayay x00X sax ah, `alignment` iyo `width` haddii xuduudahaas la dejiyay.
//!
//! Noocyada muhiimka ah, tan waa la iska indhatiray.
//!
//! Noocyada sabayn-dhibic, tani waxay muujineysaa inta lambar ee ka dambeysa barta jajab tobanlaha waa in la daabaco.
//!
//! Waxaa jira seddex qaab oo macquul ah oo lagu qeexi karo `precision` la doonayo:
//!
//! 1. An abyoonaha `.N`:
//!
//!    Tirada intee le'eg ee `N` lafteedu waa sax.
//!
//! 2. Tirade ama magac ay ku xigto calaamadda doolarka ee `.N$`:
//!
//!    adeegso qaab *dood*`N` (oo waa inuu ahaadaa `usize`) sax ahaan.
//!
//! 3. Xiddig `.*`:
//!
//!    `.*` waxay ka dhigan tahay in `{...}`-kani uu la xiriiro *laba* qaab gal qaab halkii uu ka ahaan lahaa: soo gelinta hore waxay haysaa saxnaanta `usize`, tan labaadna waxay haysaa qiimaha la daabacayo.
//!    Xusuusnow in kiiskan, haddii mid adeegsado xarigga qaabka `{<arg>:<spec>.*}`, markaa qaybta `<arg>` waxaa loola jeedaa* qiimaha * si loo daabaco, iyo `precision` waa inuu ku yimaadaa gelinta ka horreysa `<arg>`.
//!
//! Tusaale ahaan, wicitaanada soo socda dhammaantood waxay daabacaan isla shay `Hello x is 0.01000`:
//!
//! ```
//! // Hello {arg 0 ("x")} waa {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hello {arg 1 ("x")} waa {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hello {arg 0 ("x")} waa {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} waa {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} waa {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} waa {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Halka kuwani:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! daabac saddex waxyaalood oo si weyn u kala duwan:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Luuqadaha barnaamijyada qaarkood, dabeecadaha howlaha qaabeynta xariga waxay kuxirantahay dejinta aaga nidaamka qalliinka.
//! Hawlaha qaab ee ay bixiso maktabadda caadiga ah ee 'Rust' ma laha wax fikrad ah oo deegaanka ah waxayna soo saari doonaan natiijooyin isku mid ah dhammaan nidaamyada iyadoon loo eegin qaabeynta adeegsadaha.
//!
//! Tusaale ahaan, nambarka soo socda ayaa had iyo jeer daabacan doona `1.5` xitaa haddii nidaamka deegaanka uu adeegsado kala-jajab tobanle aan ahayn dhibic.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! The characters suugaan `{` iyo `}` ka mid noqon kara string ah by iyaga horaysa la dabeecad la mid ah.Tusaale ahaan, astaamaha `{` waxaa lagu baxsaday `{{` halka astaamaha `}` lagu baxsaday `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Si loo soo koobo, halkan waxaad ka heli kartaa naxwaha buuxa ee xargaha qaabka.
//! Saan ee afka formatting isticmaalo waxaa laga luqado kale, sidaas darteed waa in aanay noqon mid aad u shisheeye.Doodaha waxaa loo qaabeeyey qaabka loo yaqaan Python, oo macnaheedu yahay in doodaha ay ku wareegsan yihiin `{}` halkii ay ka ahaan lahaayeen C-like `%`.
//! Naxwaha dhabta ah ee qaabeynta qaabeynta waa:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Naxwaha kor ku xusan, `text` kuma jiri karaan wax xaraf `'{'` ama `'}'` ah.
//!
//! # Qaabaynta traits
//!
//! Markii aad codsaneysid in dood loo qaabeeyo nooc gaar ah, runti waxaad codsaneysaa in muranku u dhigmo trait gaar ah.
//! Tani waxay u oggolaaneysaa noocyo badan oo dhab ah in lagu qaabeeyo `{:x}` (sida [`i8`] iyo sidoo kale [`isize`]).Khariidaynta hadda ee noocyada ilaa traits waa:
//!
//! * *waxba* ⇒ [`Display`]
//! * `?` 00 [`Debug`]
//! * `x?` ⇒ [`Debug`] la abyoonayaasha hexadecimal-kiis hoose
//! * `X?` ⇒ [`Debug`] oo leh tiro isugeyn hexadecimal ah
//! * `o` 00 [`Octal`]
//! * `x` 00 [`LowerHex`]
//! * `X` 00 [`UpperHex`]
//! * `p` 00 [`Pointer`]
//! * `b` 00 [`Binary`]
//! * `e` 00 [`LowerExp`]
//! * `E` 00 [`UpperExp`]
//!
//! Tan macnaheedu waxa weeye nooc kasta oo dood ah oo fuliya [`fmt::Binary`][`Binary`] trait ayaa markaa loo qaabeyn karaa `{:b}`.Waxqabadyo ayaa loogu talagalay traits kuwan noocyo fara badan oo maktabadda caadiga ah sidoo kale.
//!
//! Haddii aan qaab lagu cayimin (sida `{}` ama `{:6}`), markaa qaabka trait loo adeegsaday waa [`Display`] trait.
//!
//! Markaad u hirgelinayso qaab trait noocaaga ah, waa inaad hirgelisaa qaab saxiixa ah:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // noocayaga caadada ah
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Noocaaga waxaa loo gudbin doonaa `self` tixraac ahaan, ka dibna shaqadu waa inay ku sii deysaa wax soo saar durdurka `f.buf`.Waxay ku xiran tahay qaab kasta hirgelinta trait inay si sax ah ugu hoggaansanto xuduudaha qaabeynta la codsaday.
//! Qiyamka cabirradan ayaa lagu qori doonaa aagagga dhismaha [`Formatter`].Si tan looga caawiyo, qaabdhismeedka [`Formatter`] wuxuu kaloo bixiyaa habab caawiyayaal ah.
//!
//! Intaa waxaa sii dheer, qiimaha soo noqoshada shaqadani waa [`fmt::Result`] oo ah nooc magac u ah [``Result`] '' <(), ``('' std: : fmt::Error`] ``>.
//! Qaabeynta hirgelinta waa inay hubisaa inay khaladaadka ka faafiyaan [`Formatter`] (tusaale ahaan, markaad wacayso [`write!`]).
//! Si kastaba ha noqotee, waa inaysan waligood soo celin khaladaadka si khiyaano leh.
//! Taasi waa, hirgelinta qaabeynta waa inay noqotaa oo ay soo celin kartaa qalad keliya haddii marin-dhaafkii [`Formatter`] uu khalad soo celiyo.
//! Tani waa sababta oo ah, liddi ku ah waxa saxeexa shaqadu soo jeedin karo, qaabaynta xariggu waa hawl aan la tirtiri karin.
//! Shaqadani waxay soo celineysaa oo keliya natiijo sababtoo ah qorista durdurka hoose ayaa laga yaabaa inay guul darreysato waana inay keentaa hab lagu faafin karo xaqiiqda ah in qalad dhacay dib loo soo celiyey.
//!
//! Tusaalaha hirgelinta qaabka traits wuxuu u ekaan doonaa:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Qiimaha `f` wuxuu hirgeliyaa `Write` trait, taas oo ah waxa qor!macro ayaa sugeysa.
//!         // Ogsoonow in qaabeyntan ay iska indhatireyso calammada kala duwan ee loo bixiyay qaabeynta xargaha.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits kala duwan ayaa u oggolaanaya qaabab kala duwan oo wax soo saar nooc ah.
//! // Micnaha qaabkan waa in la daabaco baaxadda vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Ku ixtiraam calanka qaabeynta adoo adeegsanaya habka caawiyaha ee `pad_integral` shayga Foomka.
//!         // Eeg dukumiintiga habka wixii faahfaahin ah, iyo shaqada `pad` waxaa loo isticmaali karaa in lagu xiro xargaha.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Labadan qaabeynta traits waxay leeyihiin ujeedooyin kala duwan:
//!
//! - [`fmt::Display`][`Display`] hirgelinta waxay cadeyneysaa in nooca si daacad ah loogu matali karo inuu yahay xarig UTF-8 marwalba.Waa **maahan** in lafilayo in dhamaan noocyadu ay hirgeliyaan [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] fulintii waa in la fuliyo dhammaan noocyada ** ** dadweynaha.
//!   Output caadi ahaan u matali doonta gobolka gudaha sida daacad ah intii suurtogal ah.
//!   Ujeedada trait [`Debug`] waa in ay fududeeyaan debugging code Rust.Xaaladaha badankood, isticmaalka `#[derive(Debug)]` waa ku filan oo lagula taliyay.
//!
//! Qaar ka mid ah tusaalooyinka wax soo saarka labada traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macros la xiriira
//!
//! Waxaa jira tiro macros ah oo laxiriira qoyska [`format!`].Kuwa hadda la hirgaliyay waa:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Tan iyo [`writeln!`] waa labo makarood oo loo isticmaalo in lagu sii daayo xarigga qaab durdur cayiman.Tan waxaa loo isticmaalaa in looga hortago qoondeynta dhexe ee xargaha qaabkeeda taa badalkeedana si toos ah loo qoro wax soo saarka.
//! Hooska hoostiisa, shaqadani waxay si dhab ah u codsaneysaa waxqabadka [`write_fmt`] ee lagu qeexay [`std::io::Write`] trait.
//! Tusaale adeegsiga waa:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Tan iyo [`println!`] waxay u soo saaraan wax soo saarkooda stdout.Sidoo kale macruufka [`write!`] macro', ujeeddada macrooyinkan ayaa ah in laga fogaado qoondaynta dhexe marka la daabacayo wax soo saarka.Tusaale adeegsiga waa:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Masaarida [`eprint!`] iyo [`eprintln!`] waxay lamid yihiin [`print!`] iyo [`println!`], siday u kala horreeyaan, marka laga reebo inay u soo saaraan wax soo saarkooda stderr.
//!
//! ### `format_args!`
//!
//! Kani waa macro cajiib ah oo loo adeegsado inuu si ammaan ah ugu gudbo shay mugdi ku jiro oo sharaxaya xarigga qaabka.Shaygaani uma baahna wax qoondeyn ah oo loo qoondeeyo si loo abuuro, wuxuuna kaliya tixraacaa macluumaadka ku saabsan xargaha
//! Hooska hoostiisa, dhammaan makaraasyada la xiriira waxaa lagu hirgeliyaa tan tan.
//! Marka hore, tusaale ahaan isticmaalka qaarkood waa:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Natiijada makro [`format_args!`] waa qiime nooc [`fmt::Arguments`] ah.
//! Qaab-dhismeedkan ayaa markaa loo gudbin karaa shaqooyinka [`write`] iyo [`format`] ee ku jira qaybtan si loo farsameeyo xarigga qaabka.
//! Ujeedada macro-kani waa in xitaa laga sii hortago qoondaynta dhexdhexaadka ah marka lala macaamilayo xargaha qaabeynta.
//!
//! Tusaale ahaan, maktabadda jaridda waxay isticmaali kartaa qaabeynta qaabeynta caadiga ah, laakiin waxay gudaha ku dhex mari doontaa qaab-dhismeedkan illaa iyo inta laga go'aaminayo halka ay wax-soo-saarku tagayo.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Hawsha `format` waxay qaadataa qaab dhismeedka [`Arguments`] waxayna soo celisaa xarigga qaabaysan ee ka dhashay.
///
///
/// Tusaale ahaan [`Arguments`] waxaa la abuuray karaa Dhaqale [`format_args!`] ah.
///
/// # Examples
///
/// Adeegsiga aasaasiga ah:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Fadlan la soco in isticmaalka [`format!`] laga yaabo in laga doorbido.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}