#![stable(feature = "rust1", since = "1.0.0")]

//! Tilmaamayaasha tixraaca tirinta tixraaca dunta.
//!
//! Ka eeg dukumintiyada [`Arc<T>`][Arc] wixii faahfaahin dheeraad ah.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Xaddid jilicsan oo ku saabsan xaddiga tixraacyada ee laga yaabo in lagu sameeyo `Arc`.
///
/// Ka gudubka xadkaani wuxuu soo ridi doonaa barnaamijkaaga (in kasta oo aan daruuri ahayn) tixraacyada _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ma taageerayo deyrka xusuusta.
// Si looga fogaado warbixinnada been abuurka ah ee ku saabsan hirgelinta Arc/Weak isticmaal culeyska atomiga si aad u waafajiso.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Tilmaame tixraaca tirinta tixraaca dunta-aaminka ah.'Arc' wuxuu u taagan yahay 'Atomically Reference Counted'.
///
/// Nooca `Arc<T>` wuxuu bixiyaa lahaansho wadaag ah qiimaha nooca `T`, oo loogu qoondeeyay taalada.U yeedhista [`clone`][clone] ee `Arc` waxay soosaartaa tusaale cusub oo ah `Arc`, taas oo tilmaamaysa isla qoondaynta meesha taal ee ah isha isha `Arc`, iyadoo la kordhinayo tirinta tixraaca.
/// Marka tilmaamaha ugu dambeeya ee `Arc` ee qoondaynta la baabi'iyo, qiimaha ku kaydsan qoondayntaas (oo badanaa loo yaqaan "inner value") ayaa sidoo kale hoos u dhacaya.
///
/// Tixraacyada la wadaago ee Rust uma oggolaanayaan isku beddelid asal ahaan, iyo `Arc` ma aha mid ka reeban: guud ahaan ma heli kartid tixraac isbeddel ah oo ku saabsan wax gudaha `Arc` ah.Haddii aad u baahan tahay inaad ka beddelato `Arc`, isticmaal [`Mutex`][mutex], [`RwLock`][rwlock], ama mid ka mid ah noocyada [`Atomic`][atomic].
///
/// ## Badbaadada dunta
///
/// Si ka duwan [`Rc<T>`], `Arc<T>` isticmaalaa hawlaha qaaradda for tirinta tixraaca ay.Taas macnaheedu waa inay tahay mid xasilloon.Faa`iido darrada jirta ayaa ah in howlaha atomiga ay ka qaalisan yihiin marinnada xusuusta caadiga ah.Haddii aadan wadaagaynin qoondeyn tixraac lagu tiriyay inta udhaxeysa dunta, tixgeli inaad u adeegsato [`Rc<T>`] hoosta hoose.
/// [`Rc<T>`] waa badbaado aamin ah, maxaa yeelay iskuduwaha ayaa qaban doona isku day kasta oo lagu dirayo [`Rc<T>`] inta udhaxeysa taxanaha.
/// Si kastaba ha noqotee, maktabaddu waxay dooran kartaa `Arc<T>` si macaamiisha maktabadda loogu siiyo dabacsanaan badan.
///
/// `Arc<T>` fulin doona [`Send`] iyo [`Sync`] ilaa iyo inta `T` fulinayo [`Send`] iyo [`Sync`].
/// Maxaad ugu ridi kartaa nooca '0-thread-safe-type `T` `Arc<T>` 'si aad uga dhigto mid xasilloon?Tani waxay noqon kartaa yara counter-dareen leh marka hore, ka dib oo dhan, ma aha meesha ugu nabadgelyada thread `Arc<T>`?Furaha ayaa ah tan: `Arc<T>` waxay ka dhigeysaa mid taxaddar leh aamin ka lahaanshaha lahaansho fara badan oo isku xog ah, laakiin kuma darin nabadgelyada dunta xogteeda.
///
/// Tixgeli ``Arc <'[' RefCell<T>`` `` ''.
/// [`RefCell<T>`] ma aha [`Sync`], oo haddii `Arc<T>` had iyo jeer ahaa [`Send`], ``Arc <'[' RefCell<T>`` '' 'sidoo kale wuxuu ahaan lahaa
/// Laakiin markaa dhibaato ayaan la kulmi doonnaa:
/// [`RefCell<T>`] ma aha dun ammaan ah;waxay la socotaa tirinta amaahda iyadoo la adeegsanayo hawlgallada non-atomiga.
///
/// Dhamaadka, tani waxay ka dhigan tahay inaad u baahan karto inaad isbarbar dhigto `Arc<T>` iyo nooc ka mid ah nooca [`std::sync`], badanaa [`Mutex<T>`][mutex].
///
/// ## Jebinta wareegyada leh `Weak`
///
/// Habka [`downgrade`][downgrade] waxaa loo isticmaali karaa in lagu abuuro tilmaame [`Weak`] aan lahayn.Tilmaamaha [`Weak`] wuxuu noqon karaa ['casriyayn'][casriyayn] d d ah `Arc`, laakiin kani wuxuu kusoo laaban doonaa [`None`] haddii qiimaha ku keydsanaanta qoondaynta horay loo daadiyay.
/// Si kale haddii loo dhigo, tilmaamayaasha `Weak` ma sii hayaan qiimaha ku jira qoondaynta;si kastaba ha noqotee,*way* ilaaliyaan qoondaynta (dukaanka taakulaynta qiimaha).
///
/// Wareeg u dhexeeya tilmaamayaasha `Arc` waligood lama kala bixin doono.
/// Sababtaas awgeed, [`Weak`] waxaa loo isticmaalaa in lagu jebiyo wareegyada.Tusaale ahaan, geedku wuxuu yeelan karaa tilmaamayaal xoog leh oo ah `Arc` oo ka yimaada nodeyaasha waalidka ee carruurta, iyo tilmaamaha [`Weak`] ee carruurta dib ugulaabanaya waalidkood.
///
/// # Tixraacyada dharka
///
/// Abuuritaanka tixraac cusub oo tilmaame jira oo la tiriyay ayaa la sameeyaa iyadoo la adeegsanayo `Clone` trait oo loo hirgaliyay [`Arc<T>`][Arc] iyo [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Labada qoraal ee hoose waxay u dhigmaan.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, iyo foo waa dhamaantood Arcs oo tilmaamaya isla goobta xusuusta
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` si otomaatig ah uga gaabinta `T` (iyada oo loo marayo [`Deref`][deref] trait), markaa waad wici kartaa ``hababka T` ee qiimaha nooca `Arc<T>`.Si looga fogaado isku dhaca magacyada hababka T`, hababka `Arc<T>` laftiisa waa shaqooyin la xiriira, oo loo yaqaan [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// Arc<T>Fulinteeda 'traits' sida `Clone` sidoo kale waxaa loogu yeeri karaa iyadoo la adeegsanayo jumlo aqoon buuxda u leh.
/// Dadka qaarkiis waxay doorbidaan inay adeegsadaan adeegsi buuxda oo aqoon u leh, halka qaar kalena doorbidaan adeegsiga habka loo yaqaan 'Syntax'.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Qaaciddada habka loo yaqaan 'Method-call'
/// let arc2 = arc.clone();
/// // Qaamuus buuxa oo aqoon leh
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] si otomaatig ah ugama dhigeyso `T`, maxaa yeelay qiimaha gudaha ayaa laga yaabaa in mar horeba hoos loo dhigay.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Wadaagista qaar ka mid ah macluumaadka aan beddelmi karin dhexeeya threads:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Ogsoonow inaan **aanaan** ku qaadin imtixaannada halkan.
// Dhismayaasha windows aad ayey u faraxsan yihiin haddii xariggu ka sarreeyo dunta weyn kadibna ka baxo isla waqti isku mid ah (wax dhiman) sidaas darteed waxaan iska ilaalinaynaa tan gebi ahaanba annaga oo aan wadin imtixaannadan.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Wadaagista [`AtomicUsize`] isbeddelaya:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Ka eeg [`rc` documentation][rc_examples] tusaalooyin dheeri ah oo ku saabsan tirinta tixraaca guud ahaan.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` waa nooc ka mid ah [`Arc`] oo haya tixraac aan lahayn lahaanshaha qoondaynta la maareeyay.
/// Qoondaynta waxaa lagu helayaa iyada oo wacaya [`upgrade`] tilmaamaha `Weak`, kaas oo soo celinaya [``Xulasho ']' '<`[' 'Arc`]' '<T>>``.
///
/// Tan iyo tixraaca `Weak` a ma tirin xagga lahaanshaha, ma ka hortagi doontaa qiimaha ku kaydsan qoondaynta ka hoos, iyo `Weak` laftiisa ka dhigaa jirin damaanado ku saabsan qiimaha weli joogo.
///
/// Markaa waxay soo celin kartaa [`None`] markii [`` upgrade '] d.
/// Xusuusnow si kastaba ha noqotee in tixraaca `Weak`*uusan* ka hortageynin qoondaynta lafteeda (dukaanka taakuleynta) in aan la kala bixin.
///
/// Tilmaame-tilmaameedka `Weak` wuxuu faa'iido u leeyahay inuu hayo tixraac ku-meel-gaar ah oo ku saabsan qoondaynta ay maamusho [`Arc`] iyada oo aan laga horjoogsanaynin qiimaha gudaha ee hoos u dhaca.
/// Waxaa sidoo kale loo isticmaalaa in looga hortago tixraacyada wareegsan ee udhaxeeya tilmaamayaasha [`Arc`], maadaama tixraacyada wadaagga ah aysan waligood ogolaan doonin in [`Arc`] la tuuro.
/// Tusaale ahaan, geed ku yeelan karto tilmaamo [`Arc`] xoog leh ka qanjidhada waalidka carruurta, iyo tilmaamo `Weak` ka dib carruurta waalidkood.
///
/// Habka caadiga ah ee lagu helo tilmaamaha `Weak` waa in la waco [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Kani waa `NonNull` si loogu oggolaado in leysku habeeyo nooca noocan oo kale ah, laakiin maahan tilmaame sax ah.
    //
    // `Weak::new` Tani waxay u dejineysaa `usize::MAX` si aysan ugu baahnayn inay meel ugu qoondo taallo.
    // Taasi maahan qiime tilmaame dhab ah uu waligiis yeelan doono maxaa yeelay RcBox wuxuu leeyahay iswaafajin ugu yaraan 2.
    // Tani waxay suurtagal tahay oo keliya marka `T: Sized`;unsized `T` never dangle.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Tani waa repr(C) illaa future-caddeyn ka dhan ah dib-u-soo-noqoshada berrinka, taas oo faragelinaysa haddii kale [into|from]_raw() oo ammaan ah oo noocyada gudaha ah ee la gudbi karo.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // qiimaha usize::MAX wuxuu u shaqeeyaa sidii waardiye si ku meel gaar ah "locking" awood u leh inuu kiciyo tilmaamayaasha daciifka ah ama hoos u dhigo kuwa adag;tan waxaa loo isticmaalaa in looga fogaado jinsiyadaha `make_mut` iyo `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Wuxuu dhisaa `Arc<T>` cusub.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Ku bilow tirinta tilmaanta daciifka ah 1 oo ah tilmaanta daciifka ah ee ay hayaan dhamaan tilmaamayaasha xoogan ee (kinda), eeg std/rc.rs wixii faahfaahin dheeri ah
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Wuxuu dhisaa `Arc<T>` cusub adoo adeegsanaya tixraac daciif ah oo naftiisa ah.
    /// Isku dayga inaad cusboonaysiiso tixraaca daciifka ah ka hor intaanay hawshani soo laaban waxay keenaysaa qiime `None` ah.
    /// Si kastaba ha noqotee, tixraaca daciifka ah waxaa laga yaabaa in si xor ah loo duubay oo loo kaydiyo si loo isticmaalo wakhti dambe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Gudaha ku dhis gobolka "uninitialized" adigoo tixraacaya hal daciif.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Waa muhiim inaanaan ka tanaasulin lahaanshaha tilmaamaha daciifka ah, haddii kale xusuusta waxaa laga yaabaa inay xoroobaan waqtiga `data_fn` soo laabanayo.
        // Haddii aan runtii dooneynay inaan ka gudubno lahaanshaha, waxaan abuuri karnaa tilmaame daciif ah oo dheeri ah nafteena, laakiin tani waxay sababi doontaa cusbooneysiin dheeri ah oo ku saabsan tirinta tixraaca daciifka ah ee laga yaabo inaan loo baahnayn haddii kale.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Hadda waxaan si sax ah u bilaabi karnaa qiimaha gudaha oo waxaan u rogi karnaa tixraackeena daciifka ah tixraac adag.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Waxyaabaha kor ku xusan ku qor goobta xogta waa inay u muuqdaan nooc kasta oo fiiro gaar ah u leh tiro aan eber lahayn.
            // Sidaa darteed waxaan u baahan nahay ugu yaraan "Release" xigsiin si ay u waafajinta la `compare_exchange_weak` ee `Weak::upgrade`.
            //
            // "Acquire" amar looma baahna.
            // Markaad tixgelinayso dabeecadaha suurtagalka ah ee `data_fn` waxaan kaliya u baahanahay inaan fiirino waxa ay ku qaban karto tixraaca `Weak` aan la cusbooneysiin karin:
            //
            // - Waxaa awoodo *Gadzhiyev*`Weak` ah, sii kordhaya tirada tixraaca daciif ah.
            // - Waxay hoos u dhigi kartaa kuwaas, hoos u dhigista tirada tixraaca daciifka ah (laakiin marnaba eber).
            //
            // Dhibaatooyinkan waxyeeladu nama saameeyaan sinnaba, mana jiraan waxyeellooyin kale oo suurtagal ah oo suurtagal ah oo leh koodh nabdoon oo keliya.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Tixraacyada adag waa inay si wada jir ah u yeeshaan tixraac daciif ah oo la wadaago, marka ha u horseedin burburiyaha tixraackeenna daciifka ah ee hore.
        //
        mem::forget(weak);
        strong
    }

    /// Wuxuu ku dhisaa `Arc` cusub waxyaalaha aan la ogeyn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Wuxuu dhisaa `Arc` cusub oo leh waxyaalo aan la ogaan karin, iyadoo xusuusta lagu buuxinayo bayooyinka `0`.
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Wuxuu dhisaa `Pin<Arc<T>>` cusub.
    /// Haddii `T` uusan hirgelin `Unpin`, markaa `data` waxaa lagu dhejin doonaa xusuusta oo aan la dhaqaajin karin.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Waxay dhistaa `Arc<T>` cusub, oo soo celisa qalad haddii qoondayntu dhacdo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Ku bilow tirinta tilmaanta daciifka ah 1 oo ah tilmaanta daciifka ah ee ay hayaan dhamaan tilmaamayaasha xoogan ee (kinda), eeg std/rc.rs wixii faahfaahin dheeri ah
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Dhista `Arc` cusub waxyaabaha uninitialized, soo laabtay qalad haddii qoondaynta guuldareysto.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Wuxuu dhisaa `Arc` cusub oo leh waxyaabo aan la ogaan karin, iyadoo xusuusta laga buuxiyo `0` bytes, oo soo celiya qalad haddii qoondayntu dhacdo.
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Soocelinta qiimaha gudaha, haddii `Arc` uu leeyahay hal tixraac adag.
    ///
    /// Haddii kale, [`Err`] waxaa lagu soo celiyaa isla `Arc` ee lagu gudbiyay.
    ///
    ///
    /// Tani way guuleysan doontaa xitaa haddii ay jiraan tixraacyo daciif ah oo muuqda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Samee tilmaame daciif ah si aad u nadiifiso tixraaca maldahan ee xoogga-daciifka ah
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Waxay dhistaa jeex cusub oo atom ahaan tixraac ahaan loo tiriyay oo ay ku jiraan waxyaabo aan la ogeyn.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Waxay dhistaa jeex cusub oo atom ahaan tixraac ahaan loo tiriyay oo ay ku jiraan waxyaabo aan la ogaan karin, iyadoo xusuusta lagu buuxinayo `0` bytes.
    ///
    ///
    /// Ka eeg [`MaybeUninit::zeroed`][zeroed] tusaalooyinka isticmaalka saxda iyo khaldan ee habkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Ku beddelaya `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Sida [`MaybeUninit::assume_init`] oo kale, waxay u taal qofka soo waca inuu dammaanad qaado in qiimaha gudaha uu dhab ahaantii ku jiro xaalad bilow ah.
    ///
    /// U yeerida tan markii waxyaabaha aan wali si buuxda loo bilaabin ay sababaan dhaqamo aan la qeexin isla markiiba.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Ku beddelaya `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Sida [`MaybeUninit::assume_init`] oo kale, waxay u taal qofka soo waca inuu dammaanad qaado in qiimaha gudaha uu dhab ahaantii ku jiro xaalad bilow ah.
    ///
    /// U yeerida tan markii waxyaabaha aan wali si buuxda loo bilaabin ay sababaan dhaqamo aan la qeexin isla markiiba.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Bilaabidda dib loo dhigay:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Wuxuu adeegsadaa `Arc`, isagoo soo celinaya tilmaamaha duuban.
    ///
    /// Si looga fogaado dillaac xusuusta tilmaamaha waa in ay dib u la gediyay in `Arc` ah oo isticmaalaya [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Waxay siisaa tilmaame cayriin xogta.
    ///
    /// dacwadood ayaa waxaa lagu ma saameeyeen sinaba iyo `Arc` aan la wada baabbi'iyey.
    /// Tilmaameyuhu wuu shaqeynayaa illaa inta ay jiraan xisaab celin xoog leh oo ku jirta `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // BADBAADADA: Tani ma mari karto Deref::deref ama RcBoxPtr::inner maxaa yeelay
        // Tan waxaa looga baahan yahay inay sii haysato xaqiijinta raw/mut sida tusaale
        // `get_mut` ku qori karaa tilmaamaha ka dib marka Rc-ka laga soo kabsado illaa `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Wuxuu ka dhisaa `Arc<T>` tilmaame cayriin.
    ///
    /// pointer xumu waa in hore loo soo celiyo call a in [`Arc<U>::into_raw`][into_raw] meesha `U` waa in ay leeyihiin size isla iyo in lays sida `T`.
    /// Tani waa wax aan run ahayn haddii `U` ay tahay `T`.
    /// Xusuusnow haddii `U` uusan ahayn `T` laakiin uu isku cabir iyo is waafajin yahay, tani asal ahaan waa sida gudbinta tixraacyada noocyada kala duwan.
    /// Eeg [`mem::transmute`][transmute] si aad u hesho macluumaad dheeraad ah oo ku saabsan waxa xaddidaadda khuseeya kiiskan.
    ///
    /// Isticmaalaha `from_raw` waa inuu hubiyaa in qiimo gaar ah oo ah `T` hal mar oo keliya hoos loo dhigay.
    ///
    /// Shaqadani waa mid aan amaan ahayn sababta oo ah adeegsiga aan habooneyn wuxuu u horseedi karaa xusuusta amaan la'aan, xitaa haddii `Arc<T>` soo laabtay aan waligiis la helin.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Dib ugu noqo `Arc` si looga hortago daadashada.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Wicitaano dheeri ah oo loo diro `Arc::from_raw(x_ptr)` waxay noqon doonaan kuwo aan aamin ahayn.
    /// }
    ///
    /// // Xusuusta ayaa la fasaxay markii `x` uu ka baxay baaxadda kor ku xusan, markaa `x_ptr` hadda wuu sii fiiqmayaa!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Dib uga noqo dejinta si aad uhesho ArcInner asalka ah.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Waxay u sameysaa tilmaame cusub [`Weak`] qeybintaan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Nasashadaani waa caadi maxaa yeelay waxaan hubinaynaa qiimaha ku jira CAS ee hoose.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // hubi haddii miisaanka daciifka ahi uu hadda yahay "locked";hadday sidaas tahay, wareeji.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: koodhkani hadda wuxuu iska indhatirayaa suurtagalnimada buux dhaafka
            // galay usize::MAX;guud ahaan Rc iyo Arc labaduba waxay u baahan yihiin in la waafajiyo si loola tacaalo xad dhaafka.
            //

            // Si ka duwan sida loo yaqaan Clone(), waxaan u baahanahay tan inaan noqonno Aqbal aqbal si aan ula jaanqaadno qorista ka imaaneysa `is_unique`, si ay dhacdooyinka kahor qoristaas u dhacaan kahor aqrintaan.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Hubi in annaga oo aan abuuro tabar soo laadlaada
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Wuxuu helayaa tirada tilmaamayaasha [`Weak`] ee qoondayntan.
    ///
    /// # Safety
    ///
    /// Habkani laftiisu waa badbaado, laakiin u isticmaalkiisa si sax ah wuxuu u baahan yahay daryeel dheeri ah.
    /// Mawduuc kale ayaa beddeli kara tirada daciifka ah wakhti kasta, oo ay ku jiraan inta udhaxeysa wicitaankan iyo ku shaqeynta natiijada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Caddayntani waa mid go'aan qaadasho leh maxaa yeelay ma wadaagin `Arc` ama `Weak` inta udhaxeysa dunta.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Haddii tirinta daciif ah ayaa hadda qufulan, qiimaha count ahaa 0 wax yar ka hor qaadashada qufulka.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Waxay helaysaa tirada tilmaamayaasha (`Arc`) ee xoogan qoondayntan.
    ///
    /// # Safety
    ///
    /// Habkani laftiisu waa badbaado, laakiin u isticmaalkiisa si sax ah wuxuu u baahan yahay daryeel dheeri ah.
    /// Mawduuc kale ayaa beddeli kara tirinta xoogga leh wakhti kasta, oo ay ku jiraan inta u dhexeysa wicitaankan iyo ku-simaha natiijada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Caddayntani waa mid go'aan qaadasho leh maxaa yeelay ma wadaagin `Arc` inta udhaxeysa dunta.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Kordhinta tirinta tixraaca adag ee `Arc<T>` ee kuxiran tilmaamaha la bixiyay mid mid.
    ///
    /// # Safety
    ///
    /// Tilmaameyuhu waa inuu kuhelaa `Arc::into_raw`, tusaalaha laxiriira `Arc` waa inuu ansax yahay (ie
    /// Tirada adag waa inay ahaataa ugu yaraan 1) inta habkaani socdo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Caddayntani waa mid go'aan qaadasho leh maxaa yeelay ma wadaagin `Arc` inta udhaxeysa dunta.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Hayso Arc, laakiin ha taaban dib-u-cusbooneysiinta adigoo ku duubaya ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Hadda kororka dib u tirinta, laakiin ha dhigin mid cusub
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Hoos u dhac ku yimaada tirinta tixraaca adag ee `Arc<T>` ee la xiriirta tilmaamaha la bixiyay mid mid.
    ///
    /// # Safety
    ///
    /// Tilmaameyuhu waa inuu kuhelaa `Arc::into_raw`, tusaalaha laxiriira `Arc` waa inuu ansax yahay (ie
    /// Tirada xoogan waa inay ahaataa uguyaraan 1) marka aad wacayso habkan.
    /// Qaabkan waxaa loo isticmaali karaa in lagu sii daayo `Arc`-ka ugu dambeeya iyo keydinta taakuleynta, laakiin ** waa in aan loo yeerin ka dib marka la soo daayo ugu dambeeya `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Sheegashooyinkaasi waa kuwo go'aaminaya maxaa yeelay ma wadaagin `Arc` inta udhaxeysa dunta.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Amni darradu waa hagaagsan tahay maxaa yeelay inta qaanadani nooshahay waxaa naloo ballan qaadayaa in tilmaamaha gudaha uu ansax yahay.
        // Intaas waxaa sii dheer, waxaan ognahay in qaabdhismeedka `ArcInner` laftiisu uu yahay `Sync` maxaa yeelay xogta gudaha waa `Sync` sidoo kale, sidaa darteed waxaan ku faraxsanahay inaan amaah ku siino tilmaame aan beddelmi karin waxyaabahaas.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Qeyb aan kujirin `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Burburi xogta waqtigaan, inkasta oo laga yaabo in aanan lacag la'aan qoondaynta sanduuqa laftiisa (weli waxaa jiri kara tilmaamayaal daciif ah oo jiifa).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Ku tuur daciifinta daciifka ah ee wadajirka ah ee ay hayaan dhammaan tixraacyada adag
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Dib `true` haddii labada `dhibic Arc`s in qoondaynta isku mid ah (in a xididka la mid ah [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Wuxuu u qoondeeyaa `ArcInner<T>` oo leh boos ku filan qiime gudaha ah oo suuragal ah in aan la qiyaasi karin halkaasoo qiimaha uu ku yaal qaabka loo bixiyay.
    ///
    /// Hawsha `mem_to_arcinner` waxaa loogu yeeraa tilmaamaha xogta waana inay dib ugu soo celiso tilmaame (suurta gal ah dufan)-`ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Xisaabi khariidad adoo isticmaalaya qaabeynta qiimaha la siiyay.
        // Markii hore, qaabka waxaa loo xisaabiyaa on hadal `&*(ptr as* const ArcInner<T>)` ah, laakiin tani abuuray tixraac misaligned (eeg #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Wuxuu u qoondeeyaa `ArcInner<T>` oo leh boos ku filan qiime gudaha ah oo macquul ah oo aan la qiyaasi karin halkaasoo qiimaha uu ku yaal qaabeynta la siiyay, iyadoo la soo celinayo qalad haddii qoondayntu dhacdo.
    ///
    ///
    /// Hawsha `mem_to_arcinner` waxaa loogu yeeraa tilmaamaha xogta waana inay dib ugu soo celiso tilmaame (suurta gal ah dufan)-`ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Xisaabi khariidad adoo isticmaalaya qaabeynta qiimaha la siiyay.
        // Markii hore, qaabka waxaa loo xisaabiyaa on hadal `&*(ptr as* const ArcInner<T>)` ah, laakiin tani abuuray tixraac misaligned (eeg #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // In la bilaabo ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Wuxuu u qoondeeyaa `ArcInner<T>` oo leh boos ku filan qiime gudaha ah oo aan la qiyaasi karin.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // U qoondee `ArcInner<T>` adoo isticmaalaya qiimaha la siiyay.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nuqul ku qiimee sida bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Xoreyso qoondaynta adigoon hoos u dhigin waxyaabaha ku jira
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Wuxuu u qoondeeyay `ArcInner<[T]>` dhererka la siiyay.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Nuqul ka soo jeex jeex jeexan Arc cusub oo loo qoondeeyay <\[T\]>
    ///
    /// Amaan maleh maxaa yeelay qofka soo wacaya waa inuu ama lahaadaa lahaanshaha ama xiraa `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Wuxuu ka dhisayaa `Arc<[T]>` qalabka wax soosaara ee lagu yaqaan inuu cabbirkiisu le'eg yahay.
    ///
    /// Dabeecadda lama qeexin haddii cabbirka uu qaldan yahay.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic ilaali inta lagu gudajiraayo walxaha T.
        // Haddii ay dhacdo panic, canaasiirta lagu qoray ArcInner-ka cusub waa la tuurayaa, ka dibna xusuusta ayaa la sii deynayaa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Tilmaame-baraha koowaad
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Dhamaan way cadahay.Ha illoobin askartu wuxuu si aysan u lacag la'aan ArcInner cusub.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Takhasuska trait waxaa loo adeegsaday `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Waxay ka kooban tahay tilmaame tilmaame `Arc` ah.
    ///
    /// Tani waxay ku abuureysaa tilmaame kale isla qoondaynta, kordhinta tirinta tixraaca adag.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Isticmaalka amar raaxo leh halkan waa caadi, maadaama aqoonta tixraaca asalka ahi ay ka hortageyso mawduucyada kale inay si khaldan u tirtiraan shayga.
        //
        // Sida lagu sharraxay [Boost documentation][1], Kordhinta miiska tixraaca marwalba waxaa lagu sameyn karaa Memory_order_relaxed: Tixraacyada cusub ee shayga waxaa laga sameyn karaa oo keliya tixraac jira, iyo gudbinta tixraac jira oo ka socda hal xarig oo loo maro mid kale waa inuu horeyba u bixiyaa wixii isku-dhafan ee loo baahan yahay.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Si kastaba ha ahaatee waxaan u baahan nahay in la ilaaliyo refcounts weyn ay dhacdo in qof `midka ah in: : forget`ing labada cirif.
        // Haddii aynaan sidan yeelin tiradu way buuxsami kartaa dadka isticmaalana bilaash bay isticmaali doonaan.
        // Waxaan cunsuriyad ku qancineynaa `isize::MAX` iyadoo loo maleynayo inaysan jirin ~2 bilyan oo xargo ah oo kordhinaya tirinta tixraaca hal mar.
        //
        // Tani branch waligeed laguma qaadan doono barnaamij kasta oo macquul ah.
        //
        // Waan iska soo ridi karnaa maxaa yeelay barnaamijka noocan oo kale ah ayaa si aad ah u xumaaday, mana daneynayno inaan taageerno.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Waxay ka dhigaysaa tixraac la beddeli karo `Arc` la siiyay.
    ///
    /// Haddii ay jiraan tilmaamayaal kale oo ah `Arc` ama [`Weak`] isla qoondaynta, markaa `make_mut` waxay abuuri doontaa qoondeyn cusub waxayna ku baryi doontaa [`clone`][clone] qiimaha gudaha si loo hubiyo lahaanshaha gaarka ah.
    /// Tan waxaa sidoo kale loo yaqaan 'clone-on-write'.
    ///
    /// Ogsoonow in tani ka duwan tahay dabeecadda [`Rc::make_mut`] taas oo kala saareysa tilmaamayaasha `Weak` ee haray.
    ///
    /// Sidoo kale eeg [`get_mut`][get_mut], oo fashilmi doona halkii aad ka ahaan lahayd cloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Wax isku darsan doonin
    /// let mut other_data = Arc::clone(&data); // Ma isku dhejin doonaan xogta gudaha
    /// *Arc::make_mut(&mut data) += 1;         // Clones xogta gudaha
    /// *Arc::make_mut(&mut data) += 1;         // Wax isku darsan doonin
    /// *Arc::make_mut(&mut other_data) *= 2;   // Wax isku darsan doonin
    ///
    /// // Hadda `data` iyo `other_data` ayaa tilmaamaya qoondaynno kala duwan.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Ogow waxaan haynaa tixraac adag iyo tixraac daciif ah.
        // Marka, sii deynta tixraaceena xoogan kaliya kaligeed, kaligeed, ma sababi doonto in xusuusta la kala qaado.
        //
        // U adeegso Acquire si aad u hubiso inaan u aragno wax qoraal ah `weak` oo dhacaya ka hor inta aan la sii deyn (sida, hoos u dhaca) illaa `strong`.
        // Tan iyo markii aanu qaban count daciif ah, waxaa jira fursad ma ArcInner laftiisa la deallocated laga yaabaa.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Tilmaame kale oo xoog leh ayaa jira, markaa waa inaan isku dhejinno.
            // Sii-u-qoondee xusuusta si aad ugu oggolaato qorista qiimaha cufan si toos ah.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // ku filan Dabacsan ee kor ku xusan maxaa yeelay taasi waxay aasaas ahaan waa ayna ah: waxa aan had iyo jeer inaan orotonno Waxaana tilmaamo daciif ah la hoos.
            // Kiiskii ugu xumaa, waxaan aakhirkii u qoondeynay Arc cusub oo aan loo baahnayn.
            //

            // Waxaan ka saarnay garoonkii ugu dambeeyay ee xooganaa, laakiin waxaa jira habab dheeri ah oo daciif ah.
            // Waxaan u guurineynaa waxyaabaha kujira Arc cusub, oo waxaan burin doonaa kuwa kale ee daciifka ah.
            //

            // Ogsoonow inaysan macquul ahayn in akhriska `weak` uu dhaliyo usize::MAX (yacni, qufulan), maadaama tirada daciifka ah kaliya lagu xiri karo dunta tixraac adag leh.
            //
            //

            // Muuji tilmaamaheena daciifka ah ee gaarka ah, si ay u nadiifiso ArcInner sida loogu baahan yahay.
            //
            let _weak = Weak { ptr: this.ptr };

            // Kaliya waa xadi karaa xogta, waxa kaliya ee haray waa Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Waxaan ahayn tixraaca kaliya ee noocuu doono ha ahaadee;dib ugu soo noqo tirinta tirinta xoogga leh.
            //
            this.inner().strong.store(1, Release);
        }

        // Sida `get_mut()`, unsafety waa ok maxaa yeelay, tixraaca ahaa mid gaar ah in la bilaabo, ama cloning waxyaabaha ku noqday mid ka mid ah.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Ku soo celiyaa tixraac la beddeli karo `Arc` la siiyay, haddii aysan jirin tilmaamayaal kale oo ah `Arc` ama [`Weak`] isla qoondayntaas.
    ///
    ///
    /// Soocelinta [`None`] haddii kale, maxaa yeelay ammaan ma ahan in la beddelo qiimaha la wadaago.
    ///
    /// Sidoo kale eeg [`make_mut`][make_mut], kaas oo [`clone`][clone] ka dhigi doona qiimaha gudaha marka ay jiraan tilmaamayaal kale.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Amni darradan waa ok maxaa yeelay waxaa naloo ballan qaaday in tilmaamaha la soo celiyey uu yahay tilmaamaha *kaliya* ee weligiis lagu soo celin doono T.
            // Tixraac tixraaceena waxaa la damaanad qaaday inuu yahay 1 markan, waxaana ubaahanahay Arc laftiisa inuu noqdo `mut`, marka waxaan soo celinaynaa tixraaca kaliya ee suuragalka ah ee xogta gudaha.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Ku soo celiyaa tixraac la beddeli karo `Arc` la siiyay, iyada oo aan la hubin.
    ///
    /// Sidoo kale eeg [`get_mut`], oo amaan ah oo sameeya jeegag haboon.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Tilmaamayaal kasta oo kale oo ah `Arc` ama [`Weak`] isla qoondayntaas waa inaan laga gudbin muddada muddada amaahda la soo celiyey.
    ///
    /// Tani waa wax aan macquul ahayn haddii aysan jirin tilmaamahan oo kale, tusaale ahaan isla markiiba ka dib `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Waxaan ka taxaddarnaa inaan *aanan* abuurin tixraac daboolaya meelaha "count", maaddaama tani ay ku habboon tahay helitaan isku mid ah tixraaca tixraaca (tusaale.
        // by `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Go'aami in tani ay tahay tixraaca u gaarka ah (oo ay ku jiraan dib-u-celinta daciifka ah) ee xogta salka ku haysa.
    ///
    ///
    /// Ogsoonow in tani u baahan tahay inaad xirto tirinta tirade daciifka ah.
    fn is_unique(&mut self) -> bool {
        // quful tirinta tilmaanta daciifka ah haddii aan u muuqanno inaan haysano tilmaamaha daciifka ah oo keliya.
        //
        // Sumadda soo iibinta halkan waxay xaqiijineysaa dhacdo-kahor xiriir lala yeesho wax qoraal ah `strong` (gaar ahaan `Weak::upgrade`) kahor hoos u dhaca tirada `weak` (iyada oo loo marayo `Weak::drop`, oo adeegsata sii deynta).
        // Haddii dib loo cusbooneysiiyey dib-u-hagaajinta daciifka ah ee la cusbooneysiiyey, CAS halkan ayaa ku fashilmi doonta sidaa darteed dan kama gelinno inaan is waafajino.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Tani waxay u baahan tahay inay noqoto `Acquire` si loogu waafajiyo hoos u dhaca miisaanka `strong` ee `drop`-marin u helka kaliya ee dhaca markay jiraan laakiin tixraaca ugu dambeeya la tuurayo.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Siidaynta halkan lagu qoro waxay la jaanqaadaysaa akhriska `downgrade`, iyadoo si wax ku ool ah looga hortagayo akhrinta kore ee `strong` inay dhacdo ka dib qorista.
            //
            //
            self.inner().weak.store(1, Release); // fur qufulka
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Dhibcaha `Arc`.
    ///
    /// Tani waxay yareyn doontaa tirinta tixraaca adag.
    /// Haddii tirinta tixraaca adag ay gaarto eber markaa tixraacyada kale ee kaliya (haddii ay jiraan) waa [`Weak`], sidaas darteed waxaan `drop` u nahay qiimaha gudaha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Waxba ma daabacdo
    /// drop(foo2);   // Daabacaadda "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Maxaa yeelay, `fetch_sub` waa hore u qaaradda, waxaannu uma baahna in ay waafajinta leh threads kale haddii aynu doonayno inaynu u tirtirto shayga.
        // Isla caqligani wuxuu khuseeyaa `fetch_sub` hoose illaa tirinta `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Xayndaabkan ayaa loo baahan yahay si looga hortago dib u soo celinta isticmaalka xogta iyo tirtirka xogta.
        // Sababtoo ah waxaa lagu calaamadeeyay `Release`, hoos u dhaca tirinta tixraaca ayaa iswaafajinaya xayndaabka `Acquire`.
        // Tan macnaheedu waa adeegsiga xogta waxay dhacdaa kahor intaan la yareynin tirinta tixraaca, ee dhacda kahor xayndaabkaan, kaasoo dhaca kahor tirtirka xogta.
        //
        // Sida lagu sharaxay [Boost documentation][1],
        //
        // > Waxaa muhiim ah in lagu dhaqangaliyo marin kasta oo suuragal ah in shayga lagu helo hal
        // > thread (iyada oo tixraac ah ee hadda jira) si *dhici hor takhalusid*
        // > shayga dun dun ah oo kala duwan.Tan waxaa lagu gaaraa "release"
        // > hawlgalka ka dib markaad ka tagto tixraac (marin kasta oo loo helo shayga
        // > iyada oo la adeegsanayo tixraacan waa in sida muuqata horay u dhacday), iyo an
        // > "acquire" hawlgalka ka hor inta aan la tirtirin shayga.
        //
        // Gaar ahaan, in kasta oo waxyaabaha ku jira Arc badanaa aan la beddeli karin, haddana waxaa suurtagal ah in gudaha lagu qoro wax u eg Mutex<T>.
        // Maaddaama Mutex aan la helin markii la tirtiro, kuma kalsoonaan karno macquuladiisa isku xirnaanta si aan ugu qoro dunta Mawduuca u muuqda burburiyaha ku socda dunta B.
        //
        //
        // Sidoo kale ogsoonow in bowd u bartaan halkan karin u badan tahay in la bedelaa load bartaan ah, taas oo hagaajin karo waxqabadka xaaladaha aadka loo diriray.Fiiri [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Isku dayaan in ay dullaysnaan `Arc<dyn Any + Send + Sync>` ah nooca la taaban karo ah.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Waxay dhistaa `Weak<T>` cusub, iyadoon loo qoondeyn wax xusuus ah.
    /// Wicitaanka [`upgrade`] qiimaha soo celinta had iyo jeer wuxuu siiyaa [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Nooca Caawiyaha si uu ugu oggolaado helitaanka tixraaca tirinta adigoon wax caddeyn ah ka sameynin goobta xogta.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Kucelinaya tilmaame cayriin shayga `T` ee uu tilmaamay `Weak<T>`.
    ///
    /// pointer waa ansax ah oo keliya haddii ay jiraan qaar ka mid ah tixraac xoog leh.
    /// Tilmaamuhu waxaa laga yaabaa inuu lumayo, oo aan la jaanqaadin ama xitaa haddii kale uu yahay [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Labaduba waxay tilmaamayaan isla shay
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Kuwa halkan ku xoog badan ayaa sii nooleeya, markaa wali waanu heli karnaa shayga.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Laakiin intaa ka badan maahan.
    /// // Waan sameyn karnaa weak.as_ptr(), laakiin helitaanka tilmaanta waxay u horseedi doontaa dabeecad aan la qeexin.
    /// // assert_eq! ("hello", amaan ma aha {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Haddii tilmaamuhu liqay, waxaan toos ugu soo celinayna waardiyaha.
            // Tani ma noqon karto cinwaan xaddidan oo lacag bixin ah, maadaama mushahar bixinta ugu yaraan ay la jaanqaadayso ArcInner (usize).
            ptr as *const T
        } else {
            // BADBAADADA: haddii qatarta khaldan ay ku soo noqoto been, markaa tilmaame waa la diidi karaa.
            // Mushaharka ayaa hoos loo dhigi karaa xilligan, waana inaan ilaalino caddaynta, markaa isticmaal tilmaam tilmaame cayriin.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Waxay isticmaashaa `Weak<T>` waxayna u rogtaa tilmaame cayriin.
    ///
    /// Tani waxay u beddeleysaa tilmaame daciif ah tilmaame ceyriin ah, iyadoo weli la ilaalinayo lahaanshaha hal tixraac daciif ah (tirada daciifka ah wax kama beddelayso hawlgalkan).
    /// Dib ayaa loogu celin karaa `Weak<T>` iyadoo la socota [`from_raw`].
    ///
    /// Xayiraadaha isku midka ah ee marin u helista bartilmaameedka tilmaame sida [`as_ptr`] ayaa lagu dabaqayaa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Waxay u rogeysaa tilmaame ceyriin oo ay horey u sameysay [`into_raw`] dib ugu laabo `Weak<T>`.
    ///
    /// Tan waxaa loo isticmaali karaa in si badbaado leh loogu helo tixraac xoog leh (adoo wacaya [`upgrade`] goor dambe) ama in lagu wareejiyo tirinta daciifka ah iyadoo la dhigayo `Weak<T>`.
    ///
    /// Waxay qaadataa lahaanshaha hal tixraac daciif ah (marka laga reebo tilmaamayaasha ay abuureen [`new`], maadaama kuwani aysan waxba iska lahayn; habka wali wuu ku shaqeeyaa iyaga).
    ///
    /// # Safety
    ///
    /// Tilmaameyuhu waa inuu ka yimid [`into_raw`] waana inuu weli lahaadaa tixraackiisa daciifka ah.
    ///
    /// Waa loo oggol yahay tirinta xoogga leh inay ahaato 0 waqtiga wicitaanka tan.
    /// Si kastaba ha noqotee, tani waxay la wareegeysaa lahaanshaha hal tixraac daciif ah oo hadda matalaya tilmaame cayriin ah (tirada daciifka ah waxba kama beddeli karto hawlgalkan) sidaas darteedna waa in lagu lamaaniyaa wicitaankii hore ee [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Hoos u dhaca tirada ugu dambeysa ee daciifka ah.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Ka eeg Weak::as_ptr macnaha guud ee ku saabsan sida tilmaamaha tilmaamaha loo soo qaatay.

        let ptr = if is_dangling(ptr as *mut T) {
            // Tani waa liicliic liidata.
            ptr as *mut ArcInner<T>
        } else {
            // Haddii kale, waxaan u damaanad qaaday tilmaamaha ka tabar yar nondangling yimid.
            // BADBAADADA: data_offset waa badbaado in la waco, maadaama tixraacayaasha ptr ay yihiin dhab (suurtagal ah in hoos loo dhigo) T.
            let offset = unsafe { data_offset(ptr) };
            // Sidaa awgeed, waxaan dib uga laabaneynaa dejinta si aan u helno dhammaan RcBox.
            // BADBAADADA: tilmaamuhu wuxuu asal ahaan ka yimid Weak, marka isweydaarsigani waa aamin.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BADBAADADA: hadda waxaan soo ceshanay tilmaamihi daciifka ahaa ee asalka ahaa, markaa abuuri kara kuwa liita.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Isku dayga lagu hagaajinayo tilmaamaha `Weak` ilaa [`Arc`], dib u dhigista hoos udhaca qiimaha gudaha hadii lagu guuleysto.
    ///
    ///
    /// Soocelinayaa [`None`] haddii sicirka gudaha tan iyo markaas la daadiyey.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Baabi'i dhammaan tilmaamayaasha xoogga leh.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Waxaan u adeegsanaa wareegga 'CAS loop' si aan u kordhinno tirada xooggan halkii aan ka heli lahayn fetch_add maadaama shaqadani aysan waligeed ka qaadin tirinta tixraaca eber illaa mid.
        //
        //
        let inner = self.inner()?;

        // Xamuul raaxo leh maxaa yeelay qoraal kasta oo 0 ah oo aan daawan karno wuxuu ka tagayaa berrinka xaalad joogto ah oo eber ah (sidaas darteed akhrinta "stale" ee 0 way fiicantahay), iyo qiime kasta oo kale waxaa lagu xaqiijiyay CAS hoose.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Ka eeg faallooyinka `Arc::clone` sababta aan tan u sameyno (`mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Nasashada waa ufiican tahay kiiska guuldarada maxaa yeelay wax rajo ah kama qabno gobolka cusub.
            // Soo iibso ayaa lagama maarmaan u ah kiiska guusha si loogu waafajiyo `Arc::new_cyclic`, marka qiimaha gudaha la bilaabi karo ka dib tixraacyada `Weak` horeyba loo abuuray.
            // Xaaladdaas, waxaan rajeyneynaa inaan ilaalino qiimaha si buuxda loo bilaabay.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // wax aan kor lagu hubin
                Err(old) => n = old,
            }
        }
    }

    /// Wuxuu helayaa tirada tilmaamayaasha (`Arc`) ee xoogan ee tilmaamaya qoondaynta.
    ///
    /// Haddii `self` la abuuray iyadoo la adeegsanayo [`Weak::new`], tani waxay soo celin doontaa 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Wuxuu helayaa kudhowaad tirada tilmaamayaasha `Weak` ee tilmaamaya qoondaynta.
    ///
    /// Haddii `self` la abuuray iyadoo la adeegsanayo [`Weak::new`], ama haddii aysan jirin tilmaamayaal adag oo haray, tani waxay soo celin doontaa 0.
    ///
    /// # Accuracy
    ///
    /// Faahfaahinta fulinta awgood, qiimaha la soo celiyey wuxuu ku xirnaan karaa 1 jiho kasta marka mawduucyada kale ay maareynayaan wax kasta oo ah 'Arc' ama 'Weak' oo tilmaamaya isla qoondaynta.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Tan iyo markii aan aragnay inay jirto ugu yaraan hal tilmaame xoog leh ka dib markaan aqrinay tirada daciifka ah, waxaan ognahay in tixraaca daciifka ah ee muuqda (uu jiro markasta oo tixraacyo adag ay noolyihiin) ay wali jirtay markii aan u kuur galnay tirinta daciifka ah, sidaas darteedna aan si badbaado leh uga goyn karno.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Sooceliyaa `None` marka tilmaamuhu lulayo oo aysan jirin `ArcInner` loo qoondeeyay, (ie, markii `Weak` kan la abuuray `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Waxaan ka taxaddarnaa in *aan* abuurin tixraac daboolaya aagga "data", maaddaama aagga isku beddeli karo isla mar ahaantaana (tusaale ahaan, haddii `Arc`-kii ugu dambeeyay la tuuray, aagga xogta ayaa lagu ridi doonaa goobta).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Soocelinayaa `true` haddii labada ``Weak`s ay tilmaamayaan isla qoondaynta (oo lamid ah [`ptr::eq`]), ama haddii labaduba aysan tilmaamin wax qoondayn ah (maxaa yeelay waxaa lagu abuuray `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Maaddaama tan la isbarbar dhigayo tilmaamayaasha waxay ka dhigan tahay in `Weak::new()` ay isbarbar dhigi doonaan, in kasta oo aysan tilmaamayn wax qoondeyn ah.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Isbarbardhiga `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Waxay ka kooban tahay tilmaame tilmaame `Weak` ah oo tilmaamaya isla qoondaynta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Ka eeg faallooyinka Arc::clone() sababta ay tani u dabacsan tahay.
        // Tani waxay isticmaali kartaa fetch_add (iska indha tirinta qufulka) maxaa yeelay tirada daciifka ah ayaa kaliya xiran halka aysan * jirin tilmaamayaal kale oo daciif ah oo jira.
        //
        // (Marka ma wadi karno koodhkan markaa).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Eeg comments in Arc::clone() waayo sababta aan arrintan loo sameeyo (waayo, mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Wuxuu dhisaa `Weak<T>` cusub, iyadoon loo qoondeynin xusuusta.
    /// Wicitaanka [`upgrade`] qiimaha soo celinta had iyo jeer wuxuu siiyaa [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Dhibcaha tilmaamaha `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Waxba ma daabacdo
    /// drop(foo);        // Daabacaadda "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Haddii aan ogaanno inaan nahay tilmaamihii ugu dambeeyay ee daciif ah, ka dibna waqtigiisii aan ku wareejin lahayn xogta gebi ahaanba.Eeg dooda ku jirta Arc::drop() ee ku saabsan amarada xusuusta
        //
        // Muhiim maahan in laga hubiyo halkaan xiran, maxaa yeelay tirada daciifka ah waa la xiri karaa oo keliya haddii uu jiro si sax ah hal diidmo daciif ah, taasoo la micno ah in hoos u dhaca kaliya uu markaa kadib ku sii socon karo ON garsooraha daciifka ah ee haray, oo dhici kara oo keliya marka qufulka la sii daayo.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Waxaan halkaan ku sameyneynaa takhasuskaan, mana ahan sida ugu wanaagsan ee wax looga qaban karo `&T`, maxaa yeelay waxay si kale ugu darsan laheyd kharash dhamaan baaritaanada sinnaanta ee ku saabsan refs.
/// Waxaan u qaadaneynaa in 'Arc's-ka loo adeegsado in lagu keydiyo qiimayaal waaweyn, oo gaabis ku ah isku-dheelitirnaanta, laakiin sidoo kale culus in la hubiyo sinnaanta, taas oo keeneysa in qarashkan uu si fudud ku bixiyo.
///
/// Waxay sidoo kale u badan tahay inay yeelato laba dhejis oo `Arc` ah, oo tilmaamaya isla qiime, in ka badan laba&T`s.
///
/// Waxaan tan sameyn karnaa oo keliya markii `T: Eq` uu yahay `PartialEq` laga yaabo inuu si ula kac ah u noqnoqon karin.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Sinnaanta laba ``Arc`s.
    ///
    /// Laba `` Arc '' waa u siman yihiin haddii qiimayaashooda gudaha ay siman yihiin, xitaa haddii ay ku keydsan yihiin qoondayn kala duwan.
    ///
    /// Haddii `T` sidoo kale fuliyo `Eq` (oo muujinaysa falcelin la'aanta sinnaanta), laba `` Arc '' oo tilmaamaya isla qoondayntu marwalba way siman yihiin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Sinnaan la'aanta laba ``Arc`s.
    ///
    /// Laba `` Arc '' waa sinnaan haddii qiyamkooda gudaha uusan sinnayn.
    ///
    /// Haddii `T` sidoo kale fulisaa `Eq` (micnahoodu yahay soo celinta sinaanta), laba `Arc`s in dhibic si ay qiime isku mid marnaba kuwa aan qummanaynu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Isbarbardhig qayb ahaan ah laba ``Arc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `partial_cmp()` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ka yar-barbardhigga laba `` Arc ''.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `<` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'In ka yar ama u dhiganta' isbarbardhigga laba `` Arc ''.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `<=` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Isbarbardhig ka weyn-labo 'Arc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `>` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Ka weyn ama u dhigma' isbarbardhigga laba 'Arc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `>=` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Marka la barbardhigo muddo laba `Arc`s.
    ///
    /// Labadaba waxaa la isbarbar dhigayaa iyagoo ugu yeeraya `cmp()` qiimahooda gudaha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Waxay abuurtaa `Arc<T>` cusub, oo leh qiimaha `Default` ee `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// U qoondee jeex tixraac lagu tiriyay oo ku buuxi alaabada 'v`
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// U qoondee `str` tixraac la tiriyay ah oo nuqul ka dhig `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// U qoondee `str` tixraac la tiriyay ah oo nuqul ka dhig `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// U wareeji shay sanduuq leh qoondeyn cusub oo tixraac leh.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// U qoondee jeex tixraac la tiriyay oo guur waxyaabaha `` v ''.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // U ogolow VEC in ay lacag la'aan ah oo ay xasuusta, laakiin uma ay baabbi'in ku jira
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Waxay ku qaadataa cunsur kasta `Iterator` wuxuuna ku ururiyaa `Arc<[T]>`.
    ///
    /// # Sifooyinka waxqabadka
    ///
    /// ## Kiiska guud
    ///
    /// Xaalada guud, aruurinta `Arc<[T]>` waxaa lagu sameeyaa marka hore aruurinta `Vec<T>`.Taasi waa, marka la qorayo waxyaabaha soo socda:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// tani waxay u dhaqantaa sidii inaan u qornay:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Qaybta ugu horreysa ee qoondaynta ayaa halkan ka dhacaysa.
    ///     .into(); // Qoondaynta labaad ee `Arc<[T]>` ayaa halkan ka dhacaysa.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Tani qoondeeyo doonaa inta ugu badan ee loogu baahan yahay dhismaha `Vec<T>` ka dibna waxaa loo qoondeeyo doonaa mar jeestay `Vec<T>` galay `Arc<[T]>` ah.
    ///
    ///
    /// ## Kiciyayaal dherer la yaqaan ah
    ///
    /// Markuu `Iterator`-kaaga fuliyo `TrustedLen` oo uu cabirkiisu sax yahay, hal qoondeyn ayaa loo sameyn doonaa `Arc<[T]>`.Tusaale ahaan:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Just hal qoondaynta halkan dhacaya.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Takhasuska trait loo adeegsaday aruurinta `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Tani waa kiiska loogu talagalay soosaaraha `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BADBAADADA: Waxaan u baahanahay inaan hubino in soo-jeediyaha uu leeyahay dherer sax ah oo aan leenahay.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Ku noqo hirgelinta caadiga ah.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Iska ay kabayso gudahood `ArcInner` ah payload ka dambeeya Daliil.
///
/// # Safety
///
/// Tilmaamuhu waa inuu tilmaamaa (oo uu hayaa metadata sax ah) tusaale ahaan hore oo ansax ah oo ah T, laakiin T-ga waa la oggol yahay in la tuuro.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Isku hagaaji qiimaha aan la qiyaasi karin ilaa dhamaadka ArcInner.
    // Sababtoo ah RcBox waa repr(C), had iyo jeer waxay noqon doontaa berrinkii ugu dambeeyay ee xusuusta.
    // BADBAADADA: maaddaama noocyada kaliya ee aan la qiyaasi karin ay yihiin xaleefyo, walxaha trait,
    // iyo noocyada bannaanka, shuruudda amniga gelinta ayaa hadda ku filan in lagu qanciyo shuruudaha align_of_val_raw;kani waa faahfaahinta fulinta ee luuqada oo aan lagu tiirsanaan karin wixii ka baxsan std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}