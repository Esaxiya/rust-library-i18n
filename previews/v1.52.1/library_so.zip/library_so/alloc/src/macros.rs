/// Waxay abuurtaa [`Vec`] oo ay ku jiraan doodaha.
///
/// `vec!` Waxay u oggolaaneysaa ``Vec`s in lagu qeexo isla qaabeynta tibaaxaha soo diyaarinta ''
/// Waxaa jira laba nooc oo makro ah:
///
/// - Abuur [`Vec`] oo ka kooban liistada waxyaabaha la siiyay:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Ka abuur [`Vec`] walxaha iyo cabirka la siiyay:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Xusuusnow in si ka duwan tibaaxaha isdabajoogga ah qaabeyntaani ay taageerayso dhammaan walxaha fuliya [`Clone`] iyo tirada walxaha maahan inay ahaato mid joogto ah.
///
/// Tani waxay u adeegsan doontaa `clone` inay nuqul ka sameyso muujinta, marka qofku waa inuu ka taxaddaraa tan isagoo adeegsanaya noocyo leh hirgelin aan caadi ahayn oo `Clone` ah.
/// Tusaale ahaan, `vec![Rc::new(1);5] `` wuxuu abuuri doonaa vector oo ka kooban shan tixraac oo isku mid ah qiimaha iskudarka tirada, ee ma ahan shan tixraac oo tilmaamaya iskudhaf madaxbannaan.
///
///
/// Sidoo kale, la soco in `vec![expr; 0]` la ogol yahay, soona saaro vector madhan.
/// Tani wali wey qiimeyn doontaa `expr`, si kastaba ha noqotee, isla markiiba waxay hoos u dhigi doontaa qiimaha ka soo baxa, markaa ka taxaddar dhibaatooyinka soo raaca.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): leh cfg(test) habka `[T]::into_vec` ee dabiiciga ah, ee looga baahan yahay qeexitaankan macro, lama heli karo.
// Taabadalkeed isticmaal waxqabadka `slice::into_vec` kaas oo kaliya laguheli karo cfg(test) NB fiiri qaybta slice::hack ee slice.rs wixii macluumaad dheeri ah
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Waxay abuurtaa `String` iyadoo la adeegsanayo isdhaafsiga muujinta waqtiga shaqada.
///
/// Dooda ugu horeysa ee `format!` hesho waa xarig qaab.Tani waa inay ahaataa xarig xarig ah.Awooda xarigga qaabeynta wuxuu kujiraa '{}' kujira.
///
/// Xuduudaha dheeraadka ah ee loo gudbiyay `format!` waxay bedelayaan `` {'' ka dhexjira xarigga qaabeynta sida ay u kala horeyso la bixiyay mooyee haddii aan la isticmaalin cabirrada la magacaabay ama mowqifka;fiiri [`std::fmt`] wixii macluumaad dheeraad ah.
///
///
/// Isticmaalka guud ee loo yaqaan `format!` waa isku xirnaansho iyo isku xirnaanta xargaha.
/// Isla heshiiska ayaa loo adeegsadaa macruufka [`print!`] iyo [`write!`] macros', waxay kuxirantahay halka loogu talagay ee xarigga.
///
/// Si hal qiimo loogu beddelo xarig, isticmaal habka [`to_string`].Tani waxay isticmaali doontaa qaabeynta [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics haddii qaabeynta trait hirgelinta qaladku soo celiyo.
/// Tani waxay muujineysaa dhaqan gelin qaldan maadaama `fmt::Write for String` uusan waligiis soo celin khalad laftiisa.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Ku qasbi noodhe AST si loo muujiyo si loo hagaajiyo cilad-sheegista qaabka qaabka.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}